/* 
 * File:   llc_ctrl.h
 * Author: kiranmeravanagi
 *
 * Created on 2 October, 2020, 3:51 PM
 */


#ifndef LLC_CTRL_H
#define	LLC_CTRL_H

#ifdef	__cplusplus
extern "C" {
#endif

    /*******************************************************************************
     * Local constants and macros (private to module)
     ******************************************************************************/
    /*******************************************************************************
     * Global constants and macros
     ******************************************************************************/
#include "Rtv.h"
#include "McuClock.h"
    
#define PHASESHIFT_ENABLE     0

#define MAX_FREQUENCY         300E3 
#define MIN_FREQUENCY         95E3 
#define MAX_FREQUENCY_SS      500E3 
#define MIN_FREQUENCY_SS      95E3  
#define RESONANT_FREQUENCY    100E3   
#define SR_SAFE_FREQUENCY     102E3   
#define CT_PEAK_FREQUENCY     220E3 
#define CT_MIN_FREQUENCY      135E3

#define BURST_FREQUENCY         175E3 //190  150
#define MG_MAX_NOR_OPER_FREQ    185E3 //250  155
#define MG_MAX_NOR_SAFE_FREQ    200E3 //300  165

#define RESONANT_PERIOD      (unsigned int)(PWMCLOCKFREQ / RESONANT_FREQUENCY / 2)
#define MIN_PERIOD           (unsigned int)(PWMCLOCKFREQ / MAX_FREQUENCY / 2)
#define MAX_PERIOD           (unsigned int)(PWMCLOCKFREQ / MIN_FREQUENCY / 2)
#define MIN_PERIOD_SS        (unsigned int)(PWMCLOCKFREQ / MAX_FREQUENCY_SS / 2)
#define MAX_PERIOD_SS        (unsigned int)(PWMCLOCKFREQ / MIN_FREQUENCY_SS / 2)
#define MAX_PERIOD_SAFE      (unsigned int)(PWMCLOCKFREQ / 220E3 / 2)
#define SR_SAFE_PERIOD       (unsigned int)(PWMCLOCKFREQ / SR_SAFE_FREQUENCY / 2)
#define CT_PEAK_PERIOD       (unsigned int)(PWMCLOCKFREQ / CT_PEAK_FREQUENCY / 2)  
#define CT_MIN_PERIOD        (unsigned int)(PWMCLOCKFREQ / CT_MIN_FREQUENCY  / 2)

#define BURST_PERIOD          (unsigned int)(PWMCLOCKFREQ / BURST_FREQUENCY / 2)
#define MG_MIN_NOR_OPER_PERI  (unsigned int)(PWMCLOCKFREQ / MG_MAX_NOR_OPER_FREQ / 2)
#define MG_MIN_NOR_SAFE_PERI  (unsigned int)(PWMCLOCKFREQ / MG_MAX_NOR_SAFE_FREQ  / 2)

#define MG_SHIFT_MAX         700      
#define MAX_u0_V             (unsigned int)MAX_PERIOD  
#define MIN_u0_V             (unsigned int)MIN_PERIOD 
#define MAX_u0_V_SS          (unsigned int)MAX_PERIOD_SS  
#define MIN_u0_V_SS          (unsigned int)MIN_PERIOD_SS 
#define MIN_u0_V_OP          (unsigned int)MG_MIN_NOR_OPER_PERI 
#define LLC_HB_DEADTIME          550        //1.06ns *300
#define LLC_HB_BURST_DEADTIME    550    
#define LLC_HB_START_DEADTIME    550      
#define MAX_SR_ONTIME        (unsigned int)((PWMCLOCKFREQ / RESONANT_FREQUENCY / 2) - 300) 
#define SR_SAFE_ONTIME       (unsigned int)(MAX_SR_ONTIME - 300) 

#define Max_V1Out_LOOP      71.28 
#define MG_MAX_V1_SENSE     72.28    
#define V1_Ref_Set          49.00    
#define MG_V1_RATE_SENSE_DIV_LOOP Q12(MG_MAX_V1_SENSE / Max_V1Out_LOOP)     

#define V1_REF_SET_DEFAULT        Q12(V1_Ref_Set / Max_V1Out_LOOP)   

#define MAXERROR		          Q12(5.0 / Max_V1Out_LOOP)
#define MINERROR                  Q12(-5.0 / Max_V1Out_LOOP)
    /********************************************/
#define N_SS                 13

#define V1_SS_FACTOR_ML      (unsigned int)(((unsigned long)V1_REF_SET_DEFAULT << N_SS) / (100.0 * 7))
#define V1_SS_FACTOR_ZL      (unsigned int)(((unsigned long)V1_REF_SET_DEFAULT << N_SS) / (15.0 * 7))

#define V1_SS_FACTOR_K       V1_SS_FACTOR_ZL - V1_SS_FACTOR_ML 

#define K1_CCL               Q10(0.3)
#define K2_CCL               Q10(-0.28)      
    /*******************************************************************************
     * Global data
     ******************************************************************************/

    /*******************************************************************************
     * Global function prototypes
     ******************************************************************************/
    extern void InitCtrlLoop(void);


#ifdef	__cplusplus
}
#endif

#endif	/* LLC_CTRL_H */

