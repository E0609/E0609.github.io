/* 
 * File:   Timer_ISR.h
 * Author: Kiran
 *
 * Created on 2 October, 2020, 3:49 PM
 */

#ifndef TIMER_ISR_H
#define	TIMER_ISR_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "global.h"      
    /*******************************************************************************
     * Global constants and macros (public to other modules)
     ******************************************************************************/
    extern uint8 u8CTOCCnt;


    /*******************************************************************************
     * Global function prototypes (public to other modules)
     ******************************************************************************/
    extern void TIMER_SchDataInit(void);
    

#ifdef	__cplusplus
}
#endif

#endif	/* TIMER_ISR_H */



