/** *****************************************************************************
 * \file    
 * \brief   Scheme of task processing
 *
 * \section AUTHOR
 *    1. 
 *
 * \section SVN
 *  $Date$
 *  $Author$
 *  $Revision$
 *
 * \section LICENSE
 * Copyright (c) 
 * All rights reserved.
 *******************************************************************************/

/*******************************************************************************
 * Included header
 ******************************************************************************/

#include <p33EP128GS708.h>
#include "global.h"
#include "Rtv.h"
#include <xc.h>

/* Module header */
#include "Dig_InOut.h"
#include "Timer_ISR.h"
#include "McuUart1.h"
#include "UartComm.h"
#include "PsuState.h"
#include "Protection.h"
/*******************************************************************************
 * Included header
 ******************************************************************************/

/*******************************************************************************
 * Local constants and macros (private to module)
 ******************************************************************************/

/*******************************************************************************
 * Local data types (private globals / structs / enums)
 ******************************************************************************/
typedef struct MG_stPsuFlowControl_
{
  uint16 u16BasicStepper;
  uint16 u16OnemsStepper;
  uint16 u16TenmsStepper;
} MG_stPsuFlowControl;

/*******************************************************************************
 * Local data (private to module)
 ******************************************************************************/
volatile MG_stPsuFlowControl mg_stPsuFlowCtrl;

/*******************************************************************************
 * Global data (public to other modules)
 ******************************************************************************/
uint8 u8CTOCCnt;
/*******************************************************************************
 * Local function prototypes (private to module)
 ******************************************************************************/

/*******************************************************************************
 * Global functions (public to other modules)
 ******************************************************************************/

/*******************************************************************************
 * \brief         Initialize Timer Schedule data management
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void TIMER_SchDataInit(void)
{
  mg_stPsuFlowCtrl.u16BasicStepper = 0;
  mg_stPsuFlowCtrl.u16OnemsStepper = 0;
  mg_stPsuFlowCtrl.u16TenmsStepper = 0;
} /* TIMER_SchDataInit */

/** ****************************************************************************
 * \brief     Time slicing 100us. called in endless loop.
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *****************************************************************************/
void __attribute__((__interrupt__, no_auto_psv)) _T3Interrupt(void)
{

  DIO_ReadAllDigitalInputs();
  PSUstate_V1StatusControl();
  DIO_WriteAllDigitalOutputs();

  UART1_RxData();
  UART1_TxData();
  mg_stPsuFlowCtrl.u16BasicStepper++;
  switch (mg_stPsuFlowCtrl.u16BasicStepper) {
    /* 100us per step - one step every 1ms  */
  case 1:
  {

    break;
  }
  case 2:
  {
     
    break;
  }
  case 3:
  {
    UART1_TmOutMon();
    
    break;
  }
  case 4:
  {
    RTV_vV1AnalogFilter();
    PROTECT_V1Curr();
    break;
  }
  case 5:
  {

    break;
  }
  case 6:
  {

    break;
  }
  case 7:
  {

    break;
  }
  case 8:
  {
    INTCOM1_GetRxData();
    break;
  }
  case 9:
  {
    break;
  }
  case 10:
  default:
  {
    mg_stPsuFlowCtrl.u16OnemsStepper++;
    switch (mg_stPsuFlowCtrl.u16OnemsStepper) {
      /* 1ms per step - one step every 10ms */
    case 1:
    {
      PROTECT_V1OcPointset();
        
      break;
    }
    case 2:
    {
      break;
    }
    case 3:
    {
      break;
    }
    case 4:
    {

      break;
    }
    case 5:
    {

      break;
    }
    case 6:
    {


      break;
    }
    case 7:
    {

      break;
    }
    case 8:
    {
 
      break;
    }
    case 9:
    {

      break;
    }
    case 10:
    default:
    {
      mg_stPsuFlowCtrl.u16TenmsStepper++;
      switch (mg_stPsuFlowCtrl.u16TenmsStepper) {
        /* 10ms per step - one step every 100ms  */
      case 1:
      {

        break;
      }
      case 2:
      {

        break;
      }
      case 3:
      {
        break;
      }
      case 4:
      {
          
        break;
      }
      case 5:
      {

        break;
      }
      case 6:
      {
          
        break;
      }
      case 7:
      {
        break;
      }
      case 8:
      {
        break;
      }
      case 9:
      {
        break;
      }
      case 10:
      default:
      {
        mg_stPsuFlowCtrl.u16TenmsStepper = 0;
        break;
      }
      } /* end of switch(tPsuFlowControl.u8TenmsStepper) */
      mg_stPsuFlowCtrl.u16OnemsStepper = 0;
      break;
    }
    } /* end of switch(tPsuFlowControl.u8OnemsStepper) */
    mg_stPsuFlowCtrl.u16BasicStepper = 0;
    break;
  }
  } /* end of switch (tPsuFlowControl.u8BasicStepper) */
  _T3IF = 0;
}