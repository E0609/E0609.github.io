/** ****************************************************************************
 * \file    Protection.c
 * \brief   output monitor control
 *
 * \section AUTHOR
 *    1. 
 *
 * \section SVN
 *  $Date$
 *  $Author$
 *  $Revision$
 *
 * \section LICENSE
 * Copyright (c) 
 * All rights reserved.
 *******************************************************************************/

/*******************************************************************************
 * Included header
 ******************************************************************************/
#include <global.h>
#include "Rtv.h"

/* Module header */
#define MONCTRL_EXPORT_H
#include "McuAdc.h"
#include "McuGPIO.h"
#include "Protection.h"
#include "Rtv_Uart.h"

/*******************************************************************************
 * Local constants and macros (private to module)
 ******************************************************************************/

/* Macro use for output judgment */
#define MG_U16Q12_V1_OVP_THR_HI       Q12(53.0 / U16Q12_V1_MAX_INT)
#define MG_U16Q12_V1_OVP_THR_LO       Q12(53.9 / U16Q12_V1_MAX_INT)
#define MG_U16Q12_V1_OVW_THR_HI       Q12(53.8 / U16Q12_V1_MAX_INT)
#define MG_U16Q12_V1_OVW_THR_LO       Q12(53.4 / U16Q12_V1_MAX_INT)


#define MG_U16Q12_V1_SCP_THR_LO       Q12(38.0 / U16Q12_V1_MAX_INT)


#define MG_U16_V1_OCP_THR_HI_HL    Q12(U16Q12_I1_HL_FULL_LOAD * 0.15 / U16Q12_I1_MAX)   /* 120% load*/
#define MG_U16_V1_OCP_THR_LO_HL    Q12(U16Q12_I1_HL_FULL_LOAD * 0.10 / U16Q12_I1_MAX)
#define MG_U16_V1_OCW_THR_HI_HL    Q12(U16Q12_I1_HL_FULL_LOAD * 1.08 / U16Q12_I1_MAX)
#define MG_U16_V1_OCW_THR_LO_HL    Q12(U16Q12_I1_HL_FULL_LOAD * 1.05 / U16Q12_I1_MAX)

#define MG_U16Q12_V1_SCP_HL_THR       Q12(1.30 * U16Q12_I1_HL_FULL_LOAD / U16Q12_I1_MAX)



#define MG_U16_V1_OVP_SET_TM           2
#define MG_U16_V1_OVW_SET_TM           10
#define MG_U16_V1_OVW_CLEAR_TM         10


#define MG_U16_I1_FAST_OCP_SET_TM      50
#define MG_U16_V1_CCL_SCP_SET_TM       5
#define MG_U16_V1_SCP_SET_TM           30
#define MG_U16_V1_OC_RESET_TM          5000

/*******************************************************************************
 * Global data types (private typedefs / structs / enums)
 ******************************************************************************/
volatile GLOBAL_U_U16BIT stV1FaultFlag00, stLatchFaultFlag00;  
volatile GLOBAL_U_U16BIT stVoutStateFlag, stSysStateFlag00, stSysStateFlag01;
uint16 u16StartMonV1UvpCnt = 0;
/*******************************************************************************
 * Local data (private to module)
 ******************************************************************************/
static uint16 MON_u16V1OcpHi = MG_U16_V1_OCP_THR_HI_HL;
static uint16 MON_u16V1OcpLo = MG_U16_V1_OCP_THR_LO_HL;

static uint16 MON_u16V1OcwHi = MG_U16_V1_OCW_THR_HI_HL;
static uint16 MON_u16V1OcwLo = MG_U16_V1_OCW_THR_LO_HL;

static uint16 MON_u16V1ScpHi = MG_U16Q12_V1_SCP_HL_THR;

/*******************************************************************************
 * Local function prototypes (private to module)
 ******************************************************************************/

/*******************************************************************************
 * Global functions (public to other modules)
 ******************************************************************************/
void PROTECT_V1OcPointset(void);
void PROTECT_DataInit(void);
void PROTECT_V1Volt(void);
void PROTECT_V1Curr(void);

/********************************************************************************
 * \brief         Initial all status flags
 *
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PROTECT_DataInit(void)
{
  stV1FaultFlag00.ALL = 0U;
  stVoutStateFlag.ALL = 0U;
  stSysStateFlag00.ALL = 0U;
  stSysStateFlag01.ALL = 0U;
}


/********************************************************************************
 * \brief         Check LLC 50V voltage is OK or not
 *                Called in Timer_ISR.c every 100us
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PROTECT_V1Volt(void)
{
  static uint16 u16MonV1OVPDly = 0;

  /* V1 ovp monitor */
  if ((stAdcBufResult.u16AdcBufV1VoltVEA > MG_U16Q12_V1_OVP_THR_HI) || (FALSE != FLG_B_V1_FW_FAST_OVP))
  {
    if ((u16MonV1OVPDly < MG_U16_V1_OVP_SET_TM) && (FALSE == FLG_B_V1_FW_FAST_OVP))
    {
      u16MonV1OVPDly++;
    }
    else
    {
      FLG_B_V1_FAULT_LATCH = 1;
      FLG_B_LLC_V1_FW_OVP = 1;
      FLG_B_LLC_V1_FW_OVW = 1; 
      u16MonV1OVPDly = 0;
    }
  }
  else if (stAdcBufResult.u16AdcBufV1VoltVEA < MG_U16Q12_V1_OVP_THR_LO)
  {
    if (u16MonV1OVPDly > 0)
    {
      u16MonV1OVPDly--;
    }
  }
  /* V1 ovw monitor */
  DEBOUNCE_SET_CLR_2(FLG_B_LLC_V1_FW_OVW, /* The flag set or reset */
                     stAdcBufResult.u16AdcBufV1VoltVEA > MG_U16Q12_V1_OVW_THR_HI, /* set flag conditaion */
                     stAdcBufResult.u16AdcBufV1VoltVEA < MG_U16Q12_V1_OVW_THR_LO, /* rest flag conditation */
                     MG_U16_V1_OVW_SET_TM, /* set time */
                     MG_U16_V1_OVW_CLEAR_TM); /* reset time */

  /* reset time */
}

/********************************************************************************
 * \brief         Check main output current is OK or not
 *                 Called in Timer_ISR.c every 1ms
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PROTECT_V1Curr(void)
{
  static uint32 u32ScpDly = 0;
  static uint32 u32OcpDly = 0;
  static uint16 u16OcpResetCnt = 0;

  if (OFF != FLG_B_V1_STATE)
  {
    if ((stAdcBufResult.u16AdcBufV1Curr > MON_u16V1ScpHi) && (stAdcBufResult.u16AdcBufV1VoltVEA < MG_U16Q12_V1_SCP_THR_LO))
    {
      u16OcpResetCnt = 0;

      if (u32ScpDly < MG_U16_V1_SCP_SET_TM)
      {
        u32ScpDly++;
      }
      else
      {
        FLG_B_LLC_V1_OCW = TRUE;
        FLG_B_V1_SCP_TEMP = TRUE;
        FLG_B_LLC_V1_OCP = TRUE;
        FLG_B_V1_FAULT_LATCH = 1;
        u32ScpDly = 0;
      }
    }
    else if (aAdcAverage[MG_U8_ADC_INDEX_V1_CURR].u16q12Avg > MON_u16V1OcpHi)
    {
      u16OcpResetCnt = 0;
      if (u32OcpDly < MG_U16_I1_FAST_OCP_SET_TM)
      {
        u32OcpDly++;
      }
      else
      {
        FLG_B_LLC_V1_OCW = TRUE;
        FLG_B_V1_SCP_TEMP = FALSE;
        FLG_B_LLC_V1_OCP = TRUE;
        FLG_B_V1_FAULT_LATCH = 1;
        u32OcpDly = 0;
      }
    }
    else if (aAdcAverage[MG_U8_ADC_INDEX_V1_CURR].u16q12Avg < MON_u16V1OcpLo)
    {
      if (u32ScpDly > 0)
      {
        u32ScpDly--;
      }
      if (u32OcpDly > 0)
      {
        u32OcpDly--;
      }
      if (u16OcpResetCnt > MG_U16_V1_OC_RESET_TM)
      {
        u32ScpDly = 0;
        u32OcpDly = 0;
      }
      else
      {
        u16OcpResetCnt++;
      }
    }
  }
  else
  {
    u32ScpDly = 0;
    u32OcpDly = 0;
  }

}

/********************************************************************************
 * \brief         V1 OC value set
 *
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PROTECT_V1OcPointset(void)
{
  /***************** V1 OC value set ********************/

  MON_u16V1OcpHi = MG_U16_V1_OCP_THR_HI_HL;
  MON_u16V1OcpLo = MG_U16_V1_OCP_THR_LO_HL;

  MON_u16V1OcwHi = MG_U16_V1_OCW_THR_HI_HL;
  MON_u16V1OcwLo = MG_U16_V1_OCW_THR_LO_HL;

  u16_CclHhrLow = LLCCTRL_I1OUT_CC_LO_HL;

  MON_u16V1ScpHi = MG_U16Q12_V1_SCP_HL_THR;

  if (0 == FLG_B_V1_SOFT_START)
  {
    CMP2DAC = V1_CT_HL_NORMAL_CMP_SET;
    u16_CclHhrHigh = LLCCTRL_I1OUT_CC_HI_HL;
  }
  else
  {

    CMP2DAC = V1_CT_HL_START_CMP_SET;
    u16_CclHhrHigh = LLCCTRL_I1OUT_CC_HI_HL;
  }

}