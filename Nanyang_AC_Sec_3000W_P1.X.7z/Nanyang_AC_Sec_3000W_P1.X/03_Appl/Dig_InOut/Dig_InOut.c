/*******************************************************************************
 * \file    Dig_InOut.c
 * \brief   Read digital input GPIO and write digital output GPIO
 *
 * \section AUTHOR
 *    1. Kiran
 *
 * \section SVN
 *  $Date$
 *  $Author$
 *  $Revision$
 *
 * \section LICENSE
 * Copyright (c) 
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * Included header
 ******************************************************************************/

#include "global.h"

/* Module header */
#include "McuGPIO.h"
#include "Dig_InOut.h"
#include "Protection.h"
#include "Rtv.h"

/*******************************************************************************
 * Local constants and macros (private to module)
 ******************************************************************************/
#define MG_INPUT_OK_SET_TIME         ((uint16)1000)
#define MG_INPUT_OK_CLEAR_TIME       ((uint16)10)
#define MG_BULK_OK_SET_TIME          ((uint16)10)
#define MG_BULK_OK_CLEAR_TIME        ((uint16)10)

/*******************************************************************************
 * Local data (private to module)
 ******************************************************************************/


/*******************************************************************************
 * Global functions (public to other modules)
 ******************************************************************************/

void DIO_WriteAllDigitalOutputs(void);

/******************************************************************************
 * \brief     Read all input IO status
 *            called every 100us in schm.c
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *****************************************************************************/
void DIO_ReadAllDigitalInputs(void)
{

  /* input ok signal read */
  DEBOUNCE_SET_CLR_2(FLG_DI_VIN_FRO_PRI_OK,
                     PORT_IN_VIN_FRO_PRI_IS_OK,
                     PORT_IN_VIN_FRO_PRI_IS_NO_OK,
                     MG_INPUT_OK_SET_TIME,
                     MG_INPUT_OK_CLEAR_TIME);
  FLG_B_INPUT_OK = FLG_DI_VIN_FRO_PRI_OK;

  /* BULK ok signal read */
  DEBOUNCE_SET_CLR_2(FLG_DI_BULK_FRO_PRI_OK,
                     PORT_IN_VBULK_FRO_PRI_IS_OK,
                     PORT_IN_VBULK_FRO_PRI_IS_NO_OK,
                     MG_BULK_OK_SET_TIME,
                     MG_BULK_OK_CLEAR_TIME);
  FLG_B_BULK_OK = FLG_DI_BULK_FRO_PRI_OK;

} /* DIO_vReadAllDigitalInputs() */

/******************************************************************************
 * \brief     Write all input IO status       100us
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *****************************************************************************/
void DIO_WriteAllDigitalOutputs(void)
{


}


