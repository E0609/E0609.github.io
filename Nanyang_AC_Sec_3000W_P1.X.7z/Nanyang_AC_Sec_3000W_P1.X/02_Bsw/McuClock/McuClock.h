/** *****************************************************************************
 * \file    McuClock.h
 * \brief   Global interface for McuClock.c
 *
 * \section AUTHOR
 *    1. Kiran
 *
 * \section SVN
 *  $Date$
 *  $Author$
 *  $Revision$
 *
 * \section LICENSE
 * Copyright (c) Lite-On Singapore Pte Ltd
 * All rights reserved.
 ***************************************************************************** */

#ifndef MCUCLOCK_H
#define MCUCLOCK_H
#ifdef __cplusplus
extern "C" {
#endif


    /*******************************************************************************
     * Global data types (globals / structs / enums)
     ******************************************************************************/

    /*******************************************************************************
     * Global data
     ******************************************************************************/

#define FRC_OSC     // if use internal FRC  osc

#define FCY                    59881250       /* FCY = FOSC/2 - freq in Hz*/ 
#define PWMCLOCKFREQ           943360000      //130426 117.92*8*1000000

#define PERIOD_CONTROL_LOOP    898     /* Counter value for 15uS timer at 59.88125MHz fcl */  // 15uS
#define PERIOD_FAN_CAPTURE     14970   /* Setting of maximum capture time */            // 250uS  
#define PERIOD_MAIN_LOOP       5988    /* Counter value for 100uS timer at 59.88125MHz fcl */ // 100uS 5988

    /*******************************************************************************
     * Global function prototypes
     ******************************************************************************/
extern void Mcu_SysClkHwInit(void);
    
    
#ifdef __cplusplus
}
#endif
#endif /* __APPL_SYS_H */





