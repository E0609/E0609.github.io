/** *****************************************************************************
 * \file    McuTimer.c
 * \brief   MCU Timer configurations
 *
 * \section AUTHOR
 *    1. Kiran
 *
 * \section SVN
 *  $Date$
 *  $Author$
 *  $Revision$
 *
 * \section LICENSE
 * Copyright (c) 
 * All rights reserved.
 *******************************************************************************/

/*******************************************************************************
 * Included header
 ******************************************************************************/
#include <p33EP128GS708.h>

/* Module header */
#include "McuTimer.h"
#include "McuClock.h"
#include "Rtv.h"
/*******************************************************************************
 * Local constants and macros (private to module)
 ******************************************************************************/

/*******************************************************************************
 * Local data types (private globals / structs / enums)
 ******************************************************************************/


/*******************************************************************************
 * Global data (public to other modules)
 ******************************************************************************/

/*******************************************************************************
 * Local function prototypes (private to module)
 ******************************************************************************/

/*******************************************************************************
 * Global functions (public to other modules)
 ******************************************************************************/
void Mcu_TMRHwInit(void);

/*******************************************************************************
 * \brief         Initialize and configure timer modules for 200us system time slice
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 ******************************************************************************/
void Mcu_TMRHwInit(void)
{
  /***** Timer1 initialization --- control loop timer 15us ****/
  T1CONbits.TON = 0; /* Stop timer */
  T1CONbits.TCKPS = 0; /* Set prescaler to 1:1 */
  T1CONbits.TCS = 0; /* Use internal clock */
  T1CONbits.TGATE = 0; /* Disable gated time accumulation */
  TMR1 = 0; /* Reset timer value */
  PR1 = PERIOD_CONTROL_LOOP; /* Set time 15us */

  IPC0bits.T1IP = T1_INT_PRIO; /* Set priority */
  IFS0bits.T1IF = 0; /* Reset interrupt flag */
  IEC0bits.T1IE = 0; /* disable interrupt */

  /***** Timer3 initialization --- time base 100us****/
  T3CONbits.TON = 0; /* Stop timer */
  T3CONbits.TCKPS = 0; /* Set prescaler to 1:1 */
  T3CONbits.TCS = 0; /* Use internal clock */
  T3CONbits.TGATE = 0; /* Disable gated time accumulation */
  TMR3 = 0; /* Reset timer value */
  PR3 = PERIOD_MAIN_LOOP; /* Set time 100us */

  _T3IP = T3_INT_PRIO; /* Set priority */
  _T3IF = 0; /* Reset interrupt flag */
  _T3IE = 1; /* enable interrupt */

  T1CONbits.TON = 1; /* Start timer */
  T3CONbits.TON = 1; /* Start timer */
  /* Timer1 will be started at the end of sec_init(),
   * after all other modules have been initialized.
   */
}



