/********************************************************************************
 * \file    McuTimer.h
 * \brief   
 *
 * \section AUTHOR
 *    1. Kiran
 *
 * \section SVN
 *  $Date$
 *  $Author$
 *  $Revision$
 *
 * \section LICENSE
 * Copyright (c) 
 * All rights reserved.
 *******************************************************************************/

#ifndef MCUTIMER_H
#define	MCUTIMER_H

#ifdef	__cplusplus
extern "C" {
#endif

    extern void Mcu_TMRHwInit(void);

#ifdef	__cplusplus
}
#endif

#endif	/* MCUTIMER_H */

