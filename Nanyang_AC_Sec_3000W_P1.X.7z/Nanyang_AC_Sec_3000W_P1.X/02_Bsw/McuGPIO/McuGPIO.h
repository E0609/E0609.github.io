/* 
 * File:   McuGPIO.h
 * Author: Kiran
 * Description : Interface for GPIO
 * 
 * Created on 29 September, 2020, 1:59 PM
 * 
 * \section LICENSE
 * Copyright (c) 
 * All rights reserved.
 */

#ifndef MCUGPIO_H
#define	MCUGPIO_H

#ifdef	__cplusplus
extern "C" {
#endif

#include <p33EP128GS708.h>
#include "global.h"
#include "Rtv.h"

    /*******************************************************************************
     * Local constants and macros (private to module)
     ******************************************************************************/
#define MG_PIN_INPUT_DIRECTION    1         //Microchip Pin Input Direction
#define MG_PIN_OUTPUT_DIRECTION   0

#define MG_PIN_ANALOG             1         //Microchip Pin Analog Select
#define MG_PIN_DIGITAL            0

#define MG_PIN_OUTPUT_HIGH        1
#define MG_PIN_OUTPUT_LOW         0

    /*********************** Digital output pin register ***********************************/
#define DIO_PFC_OFF                       LATEbits.LATE13   
#define DIO_ISHARE_EN                     LATDbits.LATD12 
#define DIO_V1_D2D_EN                     LATCbits.LATC5 
#define DIO_V1_ORING_DRV_EN               LATEbits.LATE4  
    /**************** set digital output pin High/Low status  ******************************/
#define PORT_OUT_V1_ISHARE_EN           { DIO_ISHARE_EN = 0;\
                                          FLG_DO_V1_ISHARE_ON = 1; }
#define PORT_OUT_V1_ISHARE_DIS          { DIO_ISHARE_EN = 1;\
                                          FLG_DO_V1_ISHARE_ON = 0; }
#define PORT_OUT_V1_ORING_EN            { DIO_V1_ORING_DRV_EN = 1;\
                                          FLG_DO_V1_ORING_CTRL_EN = 1; }
#define PORT_OUT_V1_ORING_DIS           { DIO_V1_ORING_DRV_EN = 0;\
                                          FLG_DO_V1_ORING_CTRL_EN = 0; }
#define PORT_OUT_V1_OUTPUT_EN           { DIO_V1_D2D_EN = 1;\
                                          FLG_DO_V1_OUTPUT_EN = 1; }
#define PORT_OUT_V1_OUTPUT_DIS          { DIO_V1_D2D_EN = 0;\
                                          FLG_DO_V1_OUTPUT_EN = 0; }
    /******************** Digital input pin register ********************************/
#define DIO_VIN_OK_FRO_PRI_HIP            PORTEbits.RE12   
#define DIO_BULK_OK_FRO_PRI_HIP           PORTCbits.RC4    
#define DIO_V1_PSON_ACTIVE_HIP            PORTEbits.RE8   
    /**************** set digital input pin High/Low status  *******************************/
#define PORT_IN_VIN_FRO_PRI_IS_OK        ( FALSE == DIO_VIN_OK_FRO_PRI_HIP )
#define PORT_IN_VIN_FRO_PRI_IS_NO_OK     ( FALSE != DIO_VIN_OK_FRO_PRI_HIP )
#define PORT_IN_VBULK_FRO_PRI_IS_OK      ( FALSE == DIO_BULK_OK_FRO_PRI_HIP )
#define PORT_IN_VBULK_FRO_PRI_IS_NO_OK   ( FALSE != DIO_BULK_OK_FRO_PRI_HIP )
#define PORT_IN_PSON_IS_ACTIVE           ( FALSE == DIO_V1_PSON_ACTIVE_HIP )
#define PORT_IN_PSON_IS_INACTIVE         ( FALSE != DIO_V1_PSON_ACTIVE_HIP )
    /*******************************************************************************
     * Global data types (globals / structs / enums)
     ******************************************************************************/

    /*******************************************************************************
     * Global data types (typedefs / structs / enums)
     ******************************************************************************/

    /*******************************************************************************
     * Global function prototypes (public to other modules)
     ******************************************************************************/
    extern void Mcu_GPIOHwInit(void);


#ifdef	__cplusplus
}
#endif

#endif	/* MCUGPIO_H */

