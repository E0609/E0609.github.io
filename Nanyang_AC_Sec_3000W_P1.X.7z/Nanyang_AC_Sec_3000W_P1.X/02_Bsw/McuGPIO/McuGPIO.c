/** *****************************************************************************
 * \file    McuGPIO.c
 * \brief   MCU IO port configurations
 *
 * \section AUTHOR
 *    1. Kiran
 *
 * \section SVN
 *  $Date$
 *  $Author$
 *  $Revision$
 *
 * \section LICENSE
 * Copyright (c) Lite-On Singapore Pte Ltd
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * Included header
 ******************************************************************************/

/* Module header */
#include "McuGPIO.h"

/*******************************************************************************
 * Local constants and macros (private to module)
 ******************************************************************************/

/*******************************************************************************
 * Local data types (private globals / structs / enums)
 ******************************************************************************/

/*******************************************************************************
 * Local data (private to module)
 ******************************************************************************/

/*******************************************************************************
 * Global data (public to other modules)
 ******************************************************************************/

/*******************************************************************************
 * Local function prototypes (private to module)
 ******************************************************************************/

/*******************************************************************************
 * Global functions (public to other modules)
 ******************************************************************************/

/*******************************************************************************
 * Local functions (private to module)
 ******************************************************************************/

/*******************************************************************************
 * Function:        Init_Gpio
 *
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     Initialize the general purpose IO (GPIO)
 *
 ******************************************************************************/
void Mcu_GPIOHwInit(void)
{
  /* Set PORT as input or output    * 1 = input (default)   * 0 = output */

  LATA = 0x0000;
  TRISA = 0xffff;   //MC_PIN_INPUT_DIRECTION;
  ANSELA = 0x0000;  //MC_PIN_DIGITAL;
  /* ISHARE_EXT Pin17 */
  TRISAbits.TRISA0 = MG_PIN_INPUT_DIRECTION;
  ANSELAbits.ANSA0 = MG_PIN_ANALOG;

  /* 50V_DET(50V Before Oring) Pin18 */
  TRISAbits.TRISA1 = MG_PIN_INPUT_DIRECTION;
  ANSELAbits.ANSA1 = MG_PIN_ANALOG;

  /* ISHARE_INT Pin19 */
  TRISAbits.TRISA2 = MG_PIN_INPUT_DIRECTION;
  ANSELAbits.ANSA2 = MG_PIN_ANALOG;

  /*FAN_PWM Pin3*/
  TRISAbits.TRISA3 = MG_PIN_OUTPUT_DIRECTION;

  /* ISHARE_REF_PWM Pin2 */
  TRISAbits.TRISA4 = MG_PIN_OUTPUT_DIRECTION;

  LATB = 0x0000;
  TRISB = 0xffff;   //MC_PIN_INPUT_DIRECTION;
  ANSELB = 0x0000;  //MC_PIN_DIGITAL;
  /* 50V_IOUT Pin20 */
  TRISBbits.TRISB0 = MG_PIN_INPUT_DIRECTION;
  ANSELBbits.ANSB0 = MG_PIN_ANALOG;

  /* Vd_MASTER_G2 (Vd sense SR)  Pin34 */
  TRISBbits.TRISB1 = MG_PIN_INPUT_DIRECTION;
  ANSELBbits.ANSB1 = MG_PIN_ANALOG;

  /* Vd_SLAVE_G2 AN7 / CMP3D Pin35 */
  TRISBbits.TRISB2 = MG_PIN_INPUT_DIRECTION;
  ANSELBbits.ANSB2 = MG_PIN_ANALOG;

  /* SCL_INTERNAL Pin40 */
  TRISBbits.TRISB3 = MG_PIN_INPUT_DIRECTION;
  ANSELBbits.ANSB3 = MG_PIN_DIGITAL;

  /* DEBUG_TX_SEC Pin41 */
  TRISBbits.TRISB4 = MG_PIN_OUTPUT_DIRECTION;

  /* CANH Pin58 */
  TRISBbits.TRISB5 = MG_PIN_INPUT_DIRECTION;
  ANSELBbits.ANSB5 = MG_PIN_DIGITAL;

  /* PGED_SEC Pin60 */
  TRISBbits.TRISB6 = MG_PIN_INPUT_DIRECTION;
  ANSELBbits.ANSB6 = MG_PIN_DIGITAL;

  /* PGEC_SEC Pin61 */
  TRISBbits.TRISB7 = MG_PIN_INPUT_DIRECTION;
  ANSELBbits.ANSB7 = MG_PIN_DIGITAL;

  /* UART_RX Pin55 */
  TRISBbits.TRISB8 = MG_PIN_INPUT_DIRECTION;

  /* 50V_Remote Pin21 */
  TRISBbits.TRISB9 = MG_PIN_INPUT_DIRECTION;
  ANSELBbits.ANSB9 = MG_PIN_ANALOG;

  /* SR_MASTER_G1_PWM  Pin76 */
  TRISBbits.TRISB11 = MG_PIN_OUTPUT_DIRECTION;

  /* SR_MASTER_G2_PWM  Pin77 */
  TRISBbits.TRISB12 = MG_PIN_OUTPUT_DIRECTION;

  /* Unused  Pin78 */
  TRISBbits.TRISB13 = MG_PIN_OUTPUT_DIRECTION;

  /* Unused  Pin79 */
  TRISBbits.TRISB14 = MG_PIN_OUTPUT_DIRECTION;

  /* UART_TX Pin56 */
  TRISBbits.TRISB15 = MG_PIN_OUTPUT_DIRECTION;

  LATC = 0x0000;
  TRISC = 0xffff;   //MC_PIN_INPUT_DIRECTION;
  ANSELC = 0x0000;  //MC_PIN_DIGITAL;
  /* Set PORTC as input or output */
  
  /* LED2 Pin6 */
  TRISCbits.TRISC0 = MG_PIN_OUTPUT_DIRECTION;

  /* Vd_MASTER_G1 (Vd Sense SR) Pin33 */
  TRISCbits.TRISC1 = MG_PIN_INPUT_DIRECTION;
  ANSELCbits.ANSC1 = MG_PIN_ANALOG;

  /*Temp_PRI  AN9 Pin45 */
  TRISCbits.TRISC2 = MG_PIN_INPUT_DIRECTION;
  ANSELCbits.ANSC2 = MG_PIN_ANALOG;

  /* LLC_G2_PWM  Pin69 */
  TRISCbits.TRISC3 = MG_PIN_OUTPUT_DIRECTION;

  /* PFC_NOK_SEC Pin62 */
  TRISCbits.TRISC4 = MG_PIN_INPUT_DIRECTION;
  ANSELCbits.ANSC4 = MG_PIN_DIGITAL;

  /* D2D_LLC_EN Pin65 */
  TRISCbits.TRISC5 = MG_PIN_OUTPUT_DIRECTION;
  ANSELCbits.ANSC5 = MG_PIN_DIGITAL;

  /* 2.5V_ADC_REF AN17 Pin66 */
  TRISCbits.TRISC6 = MG_PIN_INPUT_DIRECTION;
  ANSELCbits.ANSC6 = MG_PIN_ANALOG;
  
  /* PMBUS_SDA Pin46 */
  TRISCbits.TRISC7 = MG_PIN_INPUT_DIRECTION;

  /* PMBUS_SCL Pin47 */
  TRISCbits.TRISC8 = MG_PIN_INPUT_DIRECTION;

  /* Temp_SR AN11  Pin29 */
  TRISCbits.TRISC9 = MG_PIN_INPUT_DIRECTION;
  ANSELCbits.ANSC9 = MG_PIN_ANALOG;

  /* Temp_XFMR AN10  Pin30 */
  TRISCbits.TRISC10 = MG_PIN_INPUT_DIRECTION;
  ANSELCbits.ANSC10 = MG_PIN_ANALOG;

  /* Temp_Connector AN14  Pin16 */
  TRISCbits.TRISC12 = MG_PIN_INPUT_DIRECTION;
  ANSELCbits.ANSC12 = MG_PIN_ANALOG;

  /* ACOK_TO_SYS Pin7 */
  TRISCbits.TRISC13 = MG_PIN_OUTPUT_DIRECTION;

  /* DEBUG_RX_SEC Pin42*/
  TRISCbits.TRISC14 = MG_PIN_INPUT_DIRECTION;

  /* SDA_INTERNAL Pin39*/
  TRISCbits.TRISC15 = MG_PIN_INPUT_DIRECTION;

  LATD = 0x0000;
  TRISD = 0xffff;   //MC_PIN_INPUT_DIRECTION;
  ANSELD = 0x0000;  //MC_PIN_DIGITAL;
  
  /* Set PORTD as input or output */
  /* CANL Pin59*/
  TRISDbits.TRISD0 = MG_PIN_OUTPUT_DIRECTION;
  
  /*SR_MASTER_G3_PWM Pin80*/
  TRISDbits.TRISD1 = MG_PIN_OUTPUT_DIRECTION;

  /* Vd_SLAVE_G1 (Vd Sense SR) Pin36 */
  TRISDbits.TRISD2 = MG_PIN_INPUT_DIRECTION;
  ANSELDbits.ANSD2 = MG_PIN_ANALOG;

  /* SR_MASTER_G4_PWM Pin1 */
  TRISDbits.TRISD3 = MG_PIN_OUTPUT_DIRECTION;

  /* SR_SLAVE_G1_PWM Pin72*/
  TRISDbits.TRISD4 = MG_PIN_OUTPUT_DIRECTION;

  /*I_LLC_0X (zero crossing) Pin67*/
  TRISDbits.TRISD5 = MG_PIN_INPUT_DIRECTION;
  ANSELDbits.ANSD5 = MG_PIN_DIGITAL; 
  
  /*LLC_G1_PWM Pin68*/
  TRISDbits.TRISD6 = MG_PIN_OUTPUT_DIRECTION;

  /* T_PRI Pin27*/
  TRISDbits.TRISD7 = MG_PIN_INPUT_DIRECTION;
  ANSELDbits.ANSD7 = MG_PIN_ANALOG;

  /*I_LLC_PRI (Pri Switching current) AN5 Pin54*/
  TRISDbits.TRISD8 = MG_PIN_INPUT_DIRECTION;
  ANSELDbits.ANSD8 = MG_PIN_ANALOG;
  
  /* Addr_I2C_A1 Pin50*/
  TRISDbits.TRISD9 = MG_PIN_INPUT_DIRECTION;

  /* Sync_START Pin8*/
  TRISDbits.TRISD10 = MG_PIN_INPUT_DIRECTION;

  /* FAN_SPEED Pin57*/
  TRISDbits.TRISD11 = MG_PIN_INPUT_DIRECTION;
  
  /* Ishare_DIS  Pin10*/
  TRISDbits.TRISD12 = MG_PIN_OUTPUT_DIRECTION;

  /* Reserved DACOUT  Pin 28*/
  TRISDbits.TRISD13 = MG_PIN_INPUT_DIRECTION;
  ANSELDbits.ANSD13 = MG_PIN_ANALOG;

  /* Addr_I2C_A0 Pin49*/
  TRISDbits.TRISD14 = MG_PIN_INPUT_DIRECTION;

  /* SR_SLAVE_G2_PWM Pin73 */
  TRISDbits.TRISD15 = MG_PIN_OUTPUT_DIRECTION;
 
  LATE = 0x0000;
  TRISE = 0xffff;   //MC_PIN_INPUT_DIRECTION;
  ANSELE = 0x0000;  //MC_PIN_DIGITAL;
  
    /* Set PORTE as input or output */
  /* PSKILL Pin4*/
  TRISEbits.TRISE0 = MG_PIN_INPUT_DIRECTION;
  
  /*LED1 Pin5*/
  TRISEbits.TRISE1 = MG_PIN_OUTPUT_DIRECTION;

  /* SYNC_CTRL Pin13 */
  TRISEbits.TRISE2 = MG_PIN_OUTPUT_DIRECTION;

  /* SEL_VOUT Pin14 */
  TRISEbits.TRISE3 = MG_PIN_INPUT_DIRECTION;

  /* 50V_OR_DRI_EN Pin22*/
  PORT_OUT_V1_ORING_DIS;
  TRISEbits.TRISE4 = MG_PIN_OUTPUT_DIRECTION;

  /*PMBUS_ALERT(SMB_ALERT) Pin23*/
//  PROT_OUT_V1_OUTPUT_DIS;  
  TRISEbits.TRISE5 = MG_PIN_OUTPUT_DIRECTION;
  
  /* SR_DIS Pin37*/
  TRISEbits.TRISE6 = MG_PIN_OUTPUT_DIRECTION;

  /* THROTTLE Pin38*/
  TRISEbits.TRISE7 = MG_PIN_INPUT_DIRECTION;

  /* PSON Pin43*/
  TRISEbits.TRISE8 = MG_PIN_INPUT_DIRECTION;
  
  /* PWOK Pin44*/
//  PROT_OUT_PWOK_TO_SYS_NOT_OK; 
  TRISEbits.TRISE9 = MG_PIN_OUTPUT_DIRECTION;

  /* Addr_I2C_A2 Pin52*/
  TRISEbits.TRISE10 = MG_PIN_INPUT_DIRECTION;

  /* Addr_I2C_A3 Pin53*/
  TRISEbits.TRISE11 = MG_PIN_INPUT_DIRECTION;
  
  /* AC_NOK_SEC  Pin63*/
  TRISEbits.TRISE12 = MG_PIN_INPUT_DIRECTION;

  /* PFC_OFF_SEC  Pin 64*/
  TRISEbits.TRISE13 = MG_PIN_OUTPUT_DIRECTION;

  /* SR_SLAVE_G4 Pin74*/
  TRISEbits.TRISE14 = MG_PIN_OUTPUT_DIRECTION;

  /* SR_SLAVE_G3 Pin75 */
  TRISEbits.TRISE15 = MG_PIN_OUTPUT_DIRECTION;
  
  /*
   * Set PORTx as open-drain or push-pull
   * 1 = open-drain (5V)
   * 0 = push-pull  (default)
   */
  ODCCbits.ODCC8 = 1; // uC_SCL
  ODCCbits.ODCC7 = 1; // uC_SDA
  ODCCbits.ODCC15 = 1; //uC_SDA_Internal
  ODCBbits.ODCB3 = 1; //uC_SCL_Internal
}

