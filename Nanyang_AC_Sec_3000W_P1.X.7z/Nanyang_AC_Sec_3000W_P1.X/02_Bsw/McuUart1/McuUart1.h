/* 
 * File:   McuUart1.h
 * Author: Kiran
 *
 * Created on 7 August, 2020, 4:28 PM
 */

#ifndef MCUUART1_H
#define	MCUUART1_H

#ifdef	__cplusplus
extern "C" {
#endif


    /*******************************************************************************
     * Global function prototypes (public to other modules)
     ******************************************************************************/

    /** *****************************************************************************
     * \brief         Initialize the UART1 peripheral (between com and pri) 
     *                
     *
     * \param[in]     -
     * \param[in,out] -
     * \param[out]    -
     *
     * \return        -
     *
     ***************************************************************************** */
    extern void Mcu_Uart1HwInit(void);

    /** *****************************************************************************
     * \brief         Uart relative data init
     *
     * \param[in]     -
     * \param[in,out] -
     * \param[out]    -
     *
     * \return        -
     *
     ***************************************************************************** */
    extern void UART1_DataInit(void);

    /** *****************************************************************************
     * \brief         TX data by UART1
     *
     *
     * \param[in]     -
     * \param[in,out] -
     * \param[out]    -
     *
     * \return        -
     *
     ***************************************************************************** */
    extern void UART1_TxData(void);

    /** *****************************************************************************
     * \brief         RX data by UART1
     *
     *
     * \param[in]     -
     * \param[in,out] -
     * \param[out]    -
     *
     * \return        -
     *
     ***************************************************************************** */
    extern void UART1_RxData(void);

    /** *****************************************************************************
     * \brief         Monitor UART1 timeout
     *                
     *
     * \param[in]     -
     * \param[in,out] -
     * \param[out]    -
     *
     * \return        -
     *
     ***************************************************************************** */
    extern void UART1_TmOutMon(void);


#ifdef	__cplusplus
}
#endif

#endif	/* MCUUART1_H */

