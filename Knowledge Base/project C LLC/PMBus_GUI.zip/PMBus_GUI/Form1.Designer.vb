﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.RadioButton17 = New System.Windows.Forms.RadioButton()
        Me.RadioButton16 = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown1 = New System.Windows.Forms.NumericUpDown()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.RadioButton9 = New System.Windows.Forms.RadioButton()
        Me.RadioButton10 = New System.Windows.Forms.RadioButton()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Button14 = New System.Windows.Forms.Button()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.NumericUpDown7 = New System.Windows.Forms.NumericUpDown()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripProgressBar1 = New System.Windows.Forms.ToolStripProgressBar()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.RadioButton11 = New System.Windows.Forms.RadioButton()
        Me.TabPage9 = New System.Windows.Forms.TabPage()
        Me.TextBox18 = New System.Windows.Forms.TextBox()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.TextBox15 = New System.Windows.Forms.TextBox()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.TextBox14 = New System.Windows.Forms.TextBox()
        Me.TextBox13 = New System.Windows.Forms.TextBox()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Button48 = New System.Windows.Forms.Button()
        Me.DataGridView4 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Label151 = New System.Windows.Forms.Label()
        Me.NumericUpDown2 = New System.Windows.Forms.NumericUpDown()
        Me.TextBox28 = New System.Windows.Forms.TextBox()
        Me.Button29 = New System.Windows.Forms.Button()
        Me.Button26 = New System.Windows.Forms.Button()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.TextBox17 = New System.Windows.Forms.TextBox()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.CheckBox4 = New System.Windows.Forms.CheckBox()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.TextBox16 = New System.Windows.Forms.TextBox()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.CheckBox3 = New System.Windows.Forms.CheckBox()
        Me.CheckBox72 = New System.Windows.Forms.CheckBox()
        Me.CheckBox73 = New System.Windows.Forms.CheckBox()
        Me.CheckBox74 = New System.Windows.Forms.CheckBox()
        Me.Label206 = New System.Windows.Forms.Label()
        Me.TextBox51 = New System.Windows.Forms.TextBox()
        Me.NumericUpDown12 = New System.Windows.Forms.NumericUpDown()
        Me.Button49 = New System.Windows.Forms.Button()
        Me.NumericUpDown16 = New System.Windows.Forms.NumericUpDown()
        Me.Button50 = New System.Windows.Forms.Button()
        Me.Button56 = New System.Windows.Forms.Button()
        Me.Label201 = New System.Windows.Forms.Label()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Label232 = New System.Windows.Forms.Label()
        Me.Label230 = New System.Windows.Forms.Label()
        Me.Label90 = New System.Windows.Forms.Label()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.Label222 = New System.Windows.Forms.Label()
        Me.Label220 = New System.Windows.Forms.Label()
        Me.Label348 = New System.Windows.Forms.Label()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.NumericUpDown21 = New System.Windows.Forms.NumericUpDown()
        Me.Label275 = New System.Windows.Forms.Label()
        Me.Label327 = New System.Windows.Forms.Label()
        Me.Label272 = New System.Windows.Forms.Label()
        Me.Label269 = New System.Windows.Forms.Label()
        Me.Button103 = New System.Windows.Forms.Button()
        Me.Label268 = New System.Windows.Forms.Label()
        Me.Button104 = New System.Windows.Forms.Button()
        Me.Label264 = New System.Windows.Forms.Label()
        Me.CheckBox6 = New System.Windows.Forms.CheckBox()
        Me.Label252 = New System.Windows.Forms.Label()
        Me.CheckBox7 = New System.Windows.Forms.CheckBox()
        Me.Label246 = New System.Windows.Forms.Label()
        Me.CheckBox8 = New System.Windows.Forms.CheckBox()
        Me.TextBox89 = New System.Windows.Forms.TextBox()
        Me.CheckBox9 = New System.Windows.Forms.CheckBox()
        Me.TextBox27 = New System.Windows.Forms.TextBox()
        Me.CheckBox10 = New System.Windows.Forms.CheckBox()
        Me.CheckBox20 = New System.Windows.Forms.CheckBox()
        Me.CheckBox11 = New System.Windows.Forms.CheckBox()
        Me.CheckBox19 = New System.Windows.Forms.CheckBox()
        Me.CheckBox12 = New System.Windows.Forms.CheckBox()
        Me.CheckBox18 = New System.Windows.Forms.CheckBox()
        Me.CheckBox69 = New System.Windows.Forms.CheckBox()
        Me.CheckBox17 = New System.Windows.Forms.CheckBox()
        Me.TextBox31 = New System.Windows.Forms.TextBox()
        Me.CheckBox16 = New System.Windows.Forms.CheckBox()
        Me.TextBox84 = New System.Windows.Forms.TextBox()
        Me.CheckBox15 = New System.Windows.Forms.CheckBox()
        Me.Label347 = New System.Windows.Forms.Label()
        Me.CheckBox14 = New System.Windows.Forms.CheckBox()
        Me.CheckBox13 = New System.Windows.Forms.CheckBox()
        Me.TextBox26 = New System.Windows.Forms.TextBox()
        Me.TextBox23 = New System.Windows.Forms.TextBox()
        Me.Label131 = New System.Windows.Forms.Label()
        Me.CheckBox28 = New System.Windows.Forms.CheckBox()
        Me.Label279 = New System.Windows.Forms.Label()
        Me.CheckBox27 = New System.Windows.Forms.CheckBox()
        Me.Label277 = New System.Windows.Forms.Label()
        Me.CheckBox26 = New System.Windows.Forms.CheckBox()
        Me.Label276 = New System.Windows.Forms.Label()
        Me.CheckBox25 = New System.Windows.Forms.CheckBox()
        Me.CheckBox24 = New System.Windows.Forms.CheckBox()
        Me.Button101 = New System.Windows.Forms.Button()
        Me.CheckBox23 = New System.Windows.Forms.CheckBox()
        Me.Button102 = New System.Windows.Forms.Button()
        Me.CheckBox22 = New System.Windows.Forms.CheckBox()
        Me.Button99 = New System.Windows.Forms.Button()
        Me.CheckBox21 = New System.Windows.Forms.CheckBox()
        Me.Button100 = New System.Windows.Forms.Button()
        Me.TextBox22 = New System.Windows.Forms.TextBox()
        Me.Button97 = New System.Windows.Forms.Button()
        Me.TextBox21 = New System.Windows.Forms.TextBox()
        Me.Button98 = New System.Windows.Forms.Button()
        Me.CheckBox36 = New System.Windows.Forms.CheckBox()
        Me.Button95 = New System.Windows.Forms.Button()
        Me.CheckBox35 = New System.Windows.Forms.CheckBox()
        Me.Button96 = New System.Windows.Forms.Button()
        Me.CheckBox34 = New System.Windows.Forms.CheckBox()
        Me.Button91 = New System.Windows.Forms.Button()
        Me.CheckBox33 = New System.Windows.Forms.CheckBox()
        Me.Button92 = New System.Windows.Forms.Button()
        Me.CheckBox32 = New System.Windows.Forms.CheckBox()
        Me.Button89 = New System.Windows.Forms.Button()
        Me.CheckBox31 = New System.Windows.Forms.CheckBox()
        Me.Button90 = New System.Windows.Forms.Button()
        Me.CheckBox30 = New System.Windows.Forms.CheckBox()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.CheckBox29 = New System.Windows.Forms.CheckBox()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.TextBox20 = New System.Windows.Forms.TextBox()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.CheckBox44 = New System.Windows.Forms.CheckBox()
        Me.Label89 = New System.Windows.Forms.Label()
        Me.CheckBox43 = New System.Windows.Forms.CheckBox()
        Me.CheckBox42 = New System.Windows.Forms.CheckBox()
        Me.CheckBox41 = New System.Windows.Forms.CheckBox()
        Me.CheckBox40 = New System.Windows.Forms.CheckBox()
        Me.Label95 = New System.Windows.Forms.Label()
        Me.CheckBox39 = New System.Windows.Forms.CheckBox()
        Me.Label125 = New System.Windows.Forms.Label()
        Me.CheckBox38 = New System.Windows.Forms.CheckBox()
        Me.Label127 = New System.Windows.Forms.Label()
        Me.CheckBox37 = New System.Windows.Forms.CheckBox()
        Me.Label134 = New System.Windows.Forms.Label()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.Label135 = New System.Windows.Forms.Label()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.CheckBox61 = New System.Windows.Forms.CheckBox()
        Me.CheckBox52 = New System.Windows.Forms.CheckBox()
        Me.CheckBox62 = New System.Windows.Forms.CheckBox()
        Me.CheckBox51 = New System.Windows.Forms.CheckBox()
        Me.CheckBox63 = New System.Windows.Forms.CheckBox()
        Me.CheckBox50 = New System.Windows.Forms.CheckBox()
        Me.CheckBox64 = New System.Windows.Forms.CheckBox()
        Me.CheckBox49 = New System.Windows.Forms.CheckBox()
        Me.CheckBox65 = New System.Windows.Forms.CheckBox()
        Me.CheckBox48 = New System.Windows.Forms.CheckBox()
        Me.CheckBox66 = New System.Windows.Forms.CheckBox()
        Me.CheckBox47 = New System.Windows.Forms.CheckBox()
        Me.CheckBox67 = New System.Windows.Forms.CheckBox()
        Me.CheckBox46 = New System.Windows.Forms.CheckBox()
        Me.CheckBox68 = New System.Windows.Forms.CheckBox()
        Me.CheckBox45 = New System.Windows.Forms.CheckBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.CheckBox53 = New System.Windows.Forms.CheckBox()
        Me.CheckBox60 = New System.Windows.Forms.CheckBox()
        Me.CheckBox54 = New System.Windows.Forms.CheckBox()
        Me.CheckBox59 = New System.Windows.Forms.CheckBox()
        Me.CheckBox55 = New System.Windows.Forms.CheckBox()
        Me.CheckBox58 = New System.Windows.Forms.CheckBox()
        Me.CheckBox56 = New System.Windows.Forms.CheckBox()
        Me.CheckBox57 = New System.Windows.Forms.CheckBox()
        Me.TabPage11 = New System.Windows.Forms.TabPage()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Label236 = New System.Windows.Forms.Label()
        Me.Label238 = New System.Windows.Forms.Label()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Label203 = New System.Windows.Forms.Label()
        Me.PictureBox39 = New System.Windows.Forms.PictureBox()
        Me.PictureBox43 = New System.Windows.Forms.PictureBox()
        Me.PictureBox47 = New System.Windows.Forms.PictureBox()
        Me.PictureBox51 = New System.Windows.Forms.PictureBox()
        Me.PictureBox55 = New System.Windows.Forms.PictureBox()
        Me.PictureBox59 = New System.Windows.Forms.PictureBox()
        Me.PictureBox63 = New System.Windows.Forms.PictureBox()
        Me.PictureBox64 = New System.Windows.Forms.PictureBox()
        Me.Label98 = New System.Windows.Forms.Label()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.Label182 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label167 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label93 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.TabControl2 = New System.Windows.Forms.TabControl()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.Label87 = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label419 = New System.Windows.Forms.Label()
        Me.Label418 = New System.Windows.Forms.Label()
        Me.Label417 = New System.Windows.Forms.Label()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label198 = New System.Windows.Forms.Label()
        Me.PictureBox169 = New System.Windows.Forms.PictureBox()
        Me.PictureBox170 = New System.Windows.Forms.PictureBox()
        Me.PictureBox171 = New System.Windows.Forms.PictureBox()
        Me.PictureBox172 = New System.Windows.Forms.PictureBox()
        Me.PictureBox173 = New System.Windows.Forms.PictureBox()
        Me.PictureBox174 = New System.Windows.Forms.PictureBox()
        Me.PictureBox175 = New System.Windows.Forms.PictureBox()
        Me.PictureBox176 = New System.Windows.Forms.PictureBox()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.Label177 = New System.Windows.Forms.Label()
        Me.PictureBox32 = New System.Windows.Forms.PictureBox()
        Me.PictureBox168 = New System.Windows.Forms.PictureBox()
        Me.PictureBox62 = New System.Windows.Forms.PictureBox()
        Me.PictureBox31 = New System.Windows.Forms.PictureBox()
        Me.PictureBox167 = New System.Windows.Forms.PictureBox()
        Me.PictureBox61 = New System.Windows.Forms.PictureBox()
        Me.PictureBox24 = New System.Windows.Forms.PictureBox()
        Me.PictureBox60 = New System.Windows.Forms.PictureBox()
        Me.PictureBox23 = New System.Windows.Forms.PictureBox()
        Me.PictureBox16 = New System.Windows.Forms.PictureBox()
        Me.PictureBox58 = New System.Windows.Forms.PictureBox()
        Me.PictureBox30 = New System.Windows.Forms.PictureBox()
        Me.PictureBox166 = New System.Windows.Forms.PictureBox()
        Me.PictureBox57 = New System.Windows.Forms.PictureBox()
        Me.PictureBox15 = New System.Windows.Forms.PictureBox()
        Me.PictureBox56 = New System.Windows.Forms.PictureBox()
        Me.PictureBox22 = New System.Windows.Forms.PictureBox()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.PictureBox54 = New System.Windows.Forms.PictureBox()
        Me.PictureBox29 = New System.Windows.Forms.PictureBox()
        Me.PictureBox165 = New System.Windows.Forms.PictureBox()
        Me.PictureBox53 = New System.Windows.Forms.PictureBox()
        Me.PictureBox14 = New System.Windows.Forms.PictureBox()
        Me.PictureBox52 = New System.Windows.Forms.PictureBox()
        Me.PictureBox21 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox50 = New System.Windows.Forms.PictureBox()
        Me.PictureBox28 = New System.Windows.Forms.PictureBox()
        Me.PictureBox164 = New System.Windows.Forms.PictureBox()
        Me.PictureBox49 = New System.Windows.Forms.PictureBox()
        Me.PictureBox13 = New System.Windows.Forms.PictureBox()
        Me.PictureBox48 = New System.Windows.Forms.PictureBox()
        Me.PictureBox20 = New System.Windows.Forms.PictureBox()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.PictureBox46 = New System.Windows.Forms.PictureBox()
        Me.PictureBox27 = New System.Windows.Forms.PictureBox()
        Me.PictureBox163 = New System.Windows.Forms.PictureBox()
        Me.PictureBox45 = New System.Windows.Forms.PictureBox()
        Me.PictureBox12 = New System.Windows.Forms.PictureBox()
        Me.PictureBox44 = New System.Windows.Forms.PictureBox()
        Me.PictureBox19 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox42 = New System.Windows.Forms.PictureBox()
        Me.PictureBox26 = New System.Windows.Forms.PictureBox()
        Me.PictureBox162 = New System.Windows.Forms.PictureBox()
        Me.PictureBox41 = New System.Windows.Forms.PictureBox()
        Me.PictureBox11 = New System.Windows.Forms.PictureBox()
        Me.PictureBox40 = New System.Windows.Forms.PictureBox()
        Me.PictureBox18 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PictureBox38 = New System.Windows.Forms.PictureBox()
        Me.PictureBox25 = New System.Windows.Forms.PictureBox()
        Me.PictureBox161 = New System.Windows.Forms.PictureBox()
        Me.PictureBox37 = New System.Windows.Forms.PictureBox()
        Me.PictureBox10 = New System.Windows.Forms.PictureBox()
        Me.PictureBox36 = New System.Windows.Forms.PictureBox()
        Me.PictureBox17 = New System.Windows.Forms.PictureBox()
        Me.PictureBox35 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox34 = New System.Windows.Forms.PictureBox()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.PictureBox33 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.TabPage19 = New System.Windows.Forms.TabPage()
        Me.GroupBox11 = New System.Windows.Forms.GroupBox()
        Me.TextBox19 = New System.Windows.Forms.TextBox()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.Label398 = New System.Windows.Forms.Label()
        Me.Label397 = New System.Windows.Forms.Label()
        Me.TextBox121 = New System.Windows.Forms.TextBox()
        Me.TextBox56 = New System.Windows.Forms.TextBox()
        Me.TextBox63 = New System.Windows.Forms.TextBox()
        Me.TextBox64 = New System.Windows.Forms.TextBox()
        Me.Label214 = New System.Windows.Forms.Label()
        Me.Button63 = New System.Windows.Forms.Button()
        Me.Label216 = New System.Windows.Forms.Label()
        Me.ComboBox3 = New System.Windows.Forms.ComboBox()
        Me.Label217 = New System.Windows.Forms.Label()
        Me.Label219 = New System.Windows.Forms.Label()
        Me.Label343 = New System.Windows.Forms.Label()
        Me.Label301 = New System.Windows.Forms.Label()
        Me.TextBox75 = New System.Windows.Forms.TextBox()
        Me.TextBox71 = New System.Windows.Forms.TextBox()
        Me.Label288 = New System.Windows.Forms.Label()
        Me.Label280 = New System.Windows.Forms.Label()
        Me.Label242 = New System.Windows.Forms.Label()
        Me.Label243 = New System.Windows.Forms.Label()
        Me.Label244 = New System.Windows.Forms.Label()
        Me.TextBox68 = New System.Windows.Forms.TextBox()
        Me.TextBox69 = New System.Windows.Forms.TextBox()
        Me.NumericUpDown17 = New System.Windows.Forms.NumericUpDown()
        Me.Label240 = New System.Windows.Forms.Label()
        Me.Label239 = New System.Windows.Forms.Label()
        Me.Label237 = New System.Windows.Forms.Label()
        Me.Label234 = New System.Windows.Forms.Label()
        Me.TextBox32 = New System.Windows.Forms.TextBox()
        Me.NumericUpDown15 = New System.Windows.Forms.NumericUpDown()
        Me.Button105 = New System.Windows.Forms.Button()
        Me.Button106 = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Cmd = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn18 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn19 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn21 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown7, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.StatusStrip1.SuspendLayout()
        Me.TabPage9.SuspendLayout()
        CType(Me.DataGridView4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox4.SuspendLayout()
        CType(Me.NumericUpDown2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown16, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        CType(Me.NumericUpDown21, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage11.SuspendLayout()
        CType(Me.PictureBox39, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox43, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox47, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox51, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox55, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox59, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox63, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox64, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage1.SuspendLayout()
        Me.TabControl2.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        CType(Me.PictureBox169, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox170, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox171, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox172, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox173, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox174, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox175, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox176, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox32, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox168, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox62, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox31, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox167, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox61, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox24, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox60, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox23, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox16, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox58, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox30, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox166, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox57, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox56, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox22, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox54, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox29, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox165, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox53, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox52, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox21, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox50, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox28, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox164, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox49, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox48, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox20, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox46, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox27, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox163, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox45, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox44, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox19, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox42, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox26, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox162, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox41, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox40, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox18, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox38, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox25, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox161, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox37, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox36, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox17, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox35, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox34, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox33, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage7.SuspendLayout()
        Me.TabPage19.SuspendLayout()
        Me.GroupBox11.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        CType(Me.NumericUpDown17, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControl1.SuspendLayout()
        Me.SuspendLayout()
        '
        'RichTextBox1
        '
        Me.RichTextBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.RichTextBox1.Location = New System.Drawing.Point(6, 8)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.ReadOnly = True
        Me.RichTextBox1.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical
        Me.RichTextBox1.Size = New System.Drawing.Size(470, 74)
        Me.RichTextBox1.TabIndex = 535
        Me.RichTextBox1.Text = ""
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Transparent
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(559, 47)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(61, 34)
        Me.Button2.TabIndex = 537
        Me.Button2.Text = "Poll"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(482, 47)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(61, 35)
        Me.Button3.TabIndex = 536
        Me.Button3.Text = "Read Once"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(645, 18)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(46, 13)
        Me.Label1.TabIndex = 541
        Me.Label1.Text = "PMBus"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(709, 11)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(116, 13)
        Me.Label3.TabIndex = 539
        Me.Label3.Text = "Set I2C Frequency:"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(545, 2)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(92, 15)
        Me.Label29.TabIndex = 538
        Me.Label29.Text = "Polling Delay"
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Enabled = False
        Me.CheckBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox2.Location = New System.Drawing.Point(850, 49)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(96, 17)
        Me.CheckBox2.TabIndex = 551
        Me.CheckBox2.Text = "Enable MUX"
        Me.CheckBox2.UseVisualStyleBackColor = True
        Me.CheckBox2.Visible = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(624, 31)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(81, 13)
        Me.Label2.TabIndex = 540
        Me.Label2.Text = "Device Addr."
        '
        'RadioButton17
        '
        Me.RadioButton17.AutoCheck = False
        Me.RadioButton17.AutoSize = True
        Me.RadioButton17.BackColor = System.Drawing.Color.Transparent
        Me.RadioButton17.Checked = True
        Me.RadioButton17.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton17.Location = New System.Drawing.Point(726, 32)
        Me.RadioButton17.Name = "RadioButton17"
        Me.RadioButton17.Size = New System.Drawing.Size(79, 19)
        Me.RadioButton17.TabIndex = 542
        Me.RadioButton17.TabStop = True
        Me.RadioButton17.Text = "100 KHz"
        Me.RadioButton17.UseVisualStyleBackColor = False
        '
        'RadioButton16
        '
        Me.RadioButton16.AutoCheck = False
        Me.RadioButton16.AutoSize = True
        Me.RadioButton16.BackColor = System.Drawing.Color.Transparent
        Me.RadioButton16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton16.Location = New System.Drawing.Point(726, 57)
        Me.RadioButton16.Name = "RadioButton16"
        Me.RadioButton16.Size = New System.Drawing.Size(79, 19)
        Me.RadioButton16.TabIndex = 543
        Me.RadioButton16.Text = "400 KHz"
        Me.RadioButton16.UseVisualStyleBackColor = False
        '
        'NumericUpDown1
        '
        Me.NumericUpDown1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericUpDown1.Hexadecimal = True
        Me.NumericUpDown1.Increment = New Decimal(New Integer() {2, 0, 0, 0})
        Me.NumericUpDown1.Location = New System.Drawing.Point(633, 54)
        Me.NumericUpDown1.Maximum = New Decimal(New Integer() {188, 0, 0, 0})
        Me.NumericUpDown1.Minimum = New Decimal(New Integer() {176, 0, 0, 0})
        Me.NumericUpDown1.Name = "NumericUpDown1"
        Me.NumericUpDown1.Size = New System.Drawing.Size(62, 22)
        Me.NumericUpDown1.TabIndex = 545
        Me.NumericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown1.Value = New Decimal(New Integer() {182, 0, 0, 0})
        '
        'SaveFileDialog1
        '
        Me.SaveFileDialog1.FileName = "Pico_AC_Pri_Rev_xxxx.hex"
        Me.SaveFileDialog1.Filter = "Binary File|*.bin|All Files|*.*"
        Me.SaveFileDialog1.InitialDirectory = "C:\Users\Meravanagikiran\DocumentsPicoAC_Sec.X"
        '
        'RadioButton9
        '
        Me.RadioButton9.AutoCheck = False
        Me.RadioButton9.AutoSize = True
        Me.RadioButton9.BackColor = System.Drawing.Color.Transparent
        Me.RadioButton9.Enabled = False
        Me.RadioButton9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton9.Location = New System.Drawing.Point(965, 16)
        Me.RadioButton9.Name = "RadioButton9"
        Me.RadioButton9.Size = New System.Drawing.Size(61, 19)
        Me.RadioButton9.TabIndex = 548
        Me.RadioButton9.Text = "PSU1"
        Me.RadioButton9.UseVisualStyleBackColor = False
        Me.RadioButton9.Visible = False
        '
        'RadioButton10
        '
        Me.RadioButton10.AutoCheck = False
        Me.RadioButton10.AutoSize = True
        Me.RadioButton10.BackColor = System.Drawing.Color.Transparent
        Me.RadioButton10.Enabled = False
        Me.RadioButton10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton10.Location = New System.Drawing.Point(965, 36)
        Me.RadioButton10.Name = "RadioButton10"
        Me.RadioButton10.Size = New System.Drawing.Size(61, 19)
        Me.RadioButton10.TabIndex = 549
        Me.RadioButton10.Text = "PSU2"
        Me.RadioButton10.UseVisualStyleBackColor = False
        Me.RadioButton10.Visible = False
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 10
        '
        'Button14
        '
        Me.Button14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button14.Location = New System.Drawing.Point(482, 8)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(61, 33)
        Me.Button14.TabIndex = 544
        Me.Button14.Text = "PKSA"
        Me.Button14.UseVisualStyleBackColor = True
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Checked = True
        Me.CheckBox1.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox1.Location = New System.Drawing.Point(850, 25)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(93, 17)
        Me.CheckBox1.TabIndex = 546
        Me.CheckBox1.Text = "Enable PEC"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'NumericUpDown7
        '
        Me.NumericUpDown7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericUpDown7.Increment = New Decimal(New Integer() {100, 0, 0, 0})
        Me.NumericUpDown7.Location = New System.Drawing.Point(556, 21)
        Me.NumericUpDown7.Maximum = New Decimal(New Integer() {5000, 0, 0, 0})
        Me.NumericUpDown7.Minimum = New Decimal(New Integer() {500, 0, 0, 0})
        Me.NumericUpDown7.Name = "NumericUpDown7"
        Me.NumericUpDown7.Size = New System.Drawing.Size(62, 21)
        Me.NumericUpDown7.TabIndex = 534
        Me.NumericUpDown7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown7.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left
        Me.NumericUpDown7.Value = New Decimal(New Integer() {500, 0, 0, 0})
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.StatusStrip1.AutoSize = False
        Me.StatusStrip1.Dock = System.Windows.Forms.DockStyle.None
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel2, Me.ToolStripProgressBar1, Me.ToolStripStatusLabel1})
        Me.StatusStrip1.Location = New System.Drawing.Point(4, 649)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(1056, 25)
        Me.StatusStrip1.TabIndex = 552
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.AutoSize = False
        Me.ToolStripStatusLabel2.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold)
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(480, 20)
        '
        'ToolStripProgressBar1
        '
        Me.ToolStripProgressBar1.ForeColor = System.Drawing.Color.Lime
        Me.ToolStripProgressBar1.Name = "ToolStripProgressBar1"
        Me.ToolStripProgressBar1.Size = New System.Drawing.Size(300, 19)
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.AutoSize = False
        Me.ToolStripStatusLabel1.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.ToolStripStatusLabel1.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me.ToolStripStatusLabel1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ToolStripStatusLabel1.Font = New System.Drawing.Font("Times New Roman", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(250, 20)
        '
        'Timer2
        '
        Me.Timer2.Enabled = True
        Me.Timer2.Interval = 1000
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        Me.OpenFileDialog1.Filter = "Primary MCU Setting Files|*.pri|All Files|*.*"
        Me.OpenFileDialog1.InitialDirectory = "C:\Users\Meravanagikiran\Documents"
        Me.OpenFileDialog1.RestoreDirectory = True
        '
        'RadioButton11
        '
        Me.RadioButton11.AutoCheck = False
        Me.RadioButton11.AutoSize = True
        Me.RadioButton11.BackColor = System.Drawing.Color.Transparent
        Me.RadioButton11.Enabled = False
        Me.RadioButton11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton11.Location = New System.Drawing.Point(965, 56)
        Me.RadioButton11.Name = "RadioButton11"
        Me.RadioButton11.Size = New System.Drawing.Size(61, 19)
        Me.RadioButton11.TabIndex = 550
        Me.RadioButton11.Text = "PSU3"
        Me.RadioButton11.UseVisualStyleBackColor = False
        Me.RadioButton11.Visible = False
        '
        'TabPage9
        '
        Me.TabPage9.BackColor = System.Drawing.Color.AliceBlue
        Me.TabPage9.Controls.Add(Me.TextBox18)
        Me.TabPage9.Controls.Add(Me.Button25)
        Me.TabPage9.Controls.Add(Me.TextBox15)
        Me.TabPage9.Controls.Add(Me.Button22)
        Me.TabPage9.Controls.Add(Me.Label67)
        Me.TabPage9.Controls.Add(Me.Label66)
        Me.TabPage9.Controls.Add(Me.Label51)
        Me.TabPage9.Controls.Add(Me.TextBox14)
        Me.TabPage9.Controls.Add(Me.TextBox13)
        Me.TabPage9.Controls.Add(Me.TextBox12)
        Me.TabPage9.Controls.Add(Me.TextBox11)
        Me.TabPage9.Controls.Add(Me.TextBox9)
        Me.TabPage9.Controls.Add(Me.Button20)
        Me.TabPage9.Controls.Add(Me.TextBox8)
        Me.TabPage9.Controls.Add(Me.Button19)
        Me.TabPage9.Controls.Add(Me.Button48)
        Me.TabPage9.Controls.Add(Me.DataGridView4)
        Me.TabPage9.Location = New System.Drawing.Point(4, 25)
        Me.TabPage9.Name = "TabPage9"
        Me.TabPage9.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage9.Size = New System.Drawing.Size(601, 483)
        Me.TabPage9.TabIndex = 2
        Me.TabPage9.Text = "PMBus Constant Data"
        '
        'TextBox18
        '
        Me.TextBox18.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox18.Enabled = False
        Me.TextBox18.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox18.Location = New System.Drawing.Point(448, 437)
        Me.TextBox18.Multiline = True
        Me.TextBox18.Name = "TextBox18"
        Me.TextBox18.ReadOnly = True
        Me.TextBox18.Size = New System.Drawing.Size(138, 34)
        Me.TextBox18.TabIndex = 518
        Me.TextBox18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.TextBox18.Visible = False
        '
        'Button25
        '
        Me.Button25.BackColor = System.Drawing.Color.Transparent
        Me.Button25.Enabled = False
        Me.Button25.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button25.Location = New System.Drawing.Point(458, 391)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(125, 40)
        Me.Button25.TabIndex = 517
        Me.Button25.Text = "READ EOUT Coefficient(30h)"
        Me.Button25.UseVisualStyleBackColor = False
        Me.Button25.Visible = False
        '
        'TextBox15
        '
        Me.TextBox15.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox15.Enabled = False
        Me.TextBox15.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox15.Location = New System.Drawing.Point(450, 339)
        Me.TextBox15.Multiline = True
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.ReadOnly = True
        Me.TextBox15.Size = New System.Drawing.Size(138, 34)
        Me.TextBox15.TabIndex = 516
        Me.TextBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.TextBox15.Visible = False
        Me.TextBox15.WordWrap = False
        '
        'Button22
        '
        Me.Button22.BackColor = System.Drawing.Color.Transparent
        Me.Button22.Enabled = False
        Me.Button22.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button22.Location = New System.Drawing.Point(459, 292)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(127, 40)
        Me.Button22.TabIndex = 515
        Me.Button22.Text = "READ EIN Coefficient(30h)"
        Me.Button22.UseVisualStyleBackColor = False
        Me.Button22.Visible = False
        '
        'Label67
        '
        Me.Label67.AutoSize = True
        Me.Label67.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label67.Location = New System.Drawing.Point(215, 345)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(85, 13)
        Me.Label67.TabIndex = 514
        Me.Label67.Text = "Sample Count"
        '
        'Label66
        '
        Me.Label66.AutoSize = True
        Me.Label66.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label66.Location = New System.Drawing.Point(129, 341)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(64, 26)
        Me.Label66.TabIndex = 513
        Me.Label66.Text = "Roll Over " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "   Count"
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label51.Location = New System.Drawing.Point(22, 342)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(77, 26)
        Me.Label51.TabIndex = 512
        Me.Label51.Text = "Accumalted " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "    Power"
        '
        'TextBox14
        '
        Me.TextBox14.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox14.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox14.Location = New System.Drawing.Point(217, 417)
        Me.TextBox14.Multiline = True
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.ReadOnly = True
        Me.TextBox14.Size = New System.Drawing.Size(82, 34)
        Me.TextBox14.TabIndex = 511
        Me.TextBox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox13
        '
        Me.TextBox13.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox13.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox13.Location = New System.Drawing.Point(121, 417)
        Me.TextBox13.Multiline = True
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.ReadOnly = True
        Me.TextBox13.Size = New System.Drawing.Size(82, 34)
        Me.TextBox13.TabIndex = 510
        Me.TextBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox12
        '
        Me.TextBox12.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox12.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox12.Location = New System.Drawing.Point(215, 371)
        Me.TextBox12.Multiline = True
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.ReadOnly = True
        Me.TextBox12.Size = New System.Drawing.Size(82, 34)
        Me.TextBox12.TabIndex = 509
        Me.TextBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox11
        '
        Me.TextBox11.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox11.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox11.Location = New System.Drawing.Point(122, 371)
        Me.TextBox11.Multiline = True
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.ReadOnly = True
        Me.TextBox11.Size = New System.Drawing.Size(82, 34)
        Me.TextBox11.TabIndex = 508
        Me.TextBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox9
        '
        Me.TextBox9.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox9.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox9.Location = New System.Drawing.Point(15, 417)
        Me.TextBox9.Multiline = True
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.ReadOnly = True
        Me.TextBox9.Size = New System.Drawing.Size(82, 34)
        Me.TextBox9.TabIndex = 507
        Me.TextBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Button20
        '
        Me.Button20.BackColor = System.Drawing.Color.Transparent
        Me.Button20.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button20.Location = New System.Drawing.Point(314, 411)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(94, 40)
        Me.Button20.TabIndex = 506
        Me.Button20.Text = "READ EOUT"
        Me.Button20.UseVisualStyleBackColor = False
        '
        'TextBox8
        '
        Me.TextBox8.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox8.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox8.Location = New System.Drawing.Point(15, 371)
        Me.TextBox8.Multiline = True
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.ReadOnly = True
        Me.TextBox8.Size = New System.Drawing.Size(82, 34)
        Me.TextBox8.TabIndex = 505
        Me.TextBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Button19
        '
        Me.Button19.BackColor = System.Drawing.Color.Transparent
        Me.Button19.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button19.Location = New System.Drawing.Point(314, 365)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(96, 40)
        Me.Button19.TabIndex = 504
        Me.Button19.Text = "READ EIN"
        Me.Button19.UseVisualStyleBackColor = False
        '
        'Button48
        '
        Me.Button48.BackColor = System.Drawing.Color.Transparent
        Me.Button48.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button48.Location = New System.Drawing.Point(457, 6)
        Me.Button48.Name = "Button48"
        Me.Button48.Size = New System.Drawing.Size(121, 50)
        Me.Button48.TabIndex = 423
        Me.Button48.Text = "Read All Constant Data"
        Me.Button48.UseVisualStyleBackColor = False
        '
        'DataGridView4
        '
        Me.DataGridView4.AllowUserToDeleteRows = False
        Me.DataGridView4.AllowUserToResizeColumns = False
        Me.DataGridView4.AllowUserToResizeRows = False
        Me.DataGridView4.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        Me.DataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.DataGridView4.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn9, Me.DataGridViewTextBoxColumn10, Me.DataGridViewTextBoxColumn11, Me.DataGridViewTextBoxColumn12, Me.DataGridViewTextBoxColumn13})
        Me.DataGridView4.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.DataGridView4.GridColor = System.Drawing.SystemColors.Control
        Me.DataGridView4.Location = New System.Drawing.Point(6, 6)
        Me.DataGridView4.MultiSelect = False
        Me.DataGridView4.Name = "DataGridView4"
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.ControlDark
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.NullValue = "0"
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView4.RowHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.DataGridView4.RowHeadersVisible = False
        Me.DataGridView4.RowHeadersWidth = 195
        Me.DataGridView4.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.DataGridView4.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.DataGridView4.RowTemplate.DefaultCellStyle.Font = New System.Drawing.Font("Arial Narrow", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DataGridView4.RowTemplate.Height = 19
        Me.DataGridView4.RowTemplate.ReadOnly = True
        Me.DataGridView4.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.DataGridView4.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.DataGridView4.Size = New System.Drawing.Size(429, 326)
        Me.DataGridView4.TabIndex = 422
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.HeaderText = "Cmd"
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        Me.DataGridViewTextBoxColumn9.Width = 35
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.HeaderText = "Command Name"
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        Me.DataGridViewTextBoxColumn10.Width = 130
        '
        'DataGridViewTextBoxColumn11
        '
        Me.DataGridViewTextBoxColumn11.HeaderText = "With PEC"
        Me.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11"
        Me.DataGridViewTextBoxColumn11.Width = 88
        '
        'DataGridViewTextBoxColumn12
        '
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DataGridViewTextBoxColumn12.DefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridViewTextBoxColumn12.HeaderText = "Hex Data"
        Me.DataGridViewTextBoxColumn12.Name = "DataGridViewTextBoxColumn12"
        Me.DataGridViewTextBoxColumn12.Width = 84
        '
        'DataGridViewTextBoxColumn13
        '
        Me.DataGridViewTextBoxColumn13.HeaderText = "Actual"
        Me.DataGridViewTextBoxColumn13.Name = "DataGridViewTextBoxColumn13"
        Me.DataGridViewTextBoxColumn13.Width = 90
        '
        'Label78
        '
        Me.Label78.AutoSize = True
        Me.Label78.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold)
        Me.Label78.Location = New System.Drawing.Point(277, 229)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(0, 13)
        Me.Label78.TabIndex = 464
        Me.Label78.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Label151)
        Me.GroupBox4.Controls.Add(Me.NumericUpDown2)
        Me.GroupBox4.Controls.Add(Me.TextBox28)
        Me.GroupBox4.Controls.Add(Me.Button29)
        Me.GroupBox4.Controls.Add(Me.Button26)
        Me.GroupBox4.Controls.Add(Me.Label69)
        Me.GroupBox4.Controls.Add(Me.TextBox17)
        Me.GroupBox4.Controls.Add(Me.Button24)
        Me.GroupBox4.Controls.Add(Me.CheckBox4)
        Me.GroupBox4.Controls.Add(Me.Label68)
        Me.GroupBox4.Controls.Add(Me.TextBox16)
        Me.GroupBox4.Controls.Add(Me.Button23)
        Me.GroupBox4.Controls.Add(Me.CheckBox3)
        Me.GroupBox4.Controls.Add(Me.CheckBox72)
        Me.GroupBox4.Controls.Add(Me.CheckBox73)
        Me.GroupBox4.Controls.Add(Me.CheckBox74)
        Me.GroupBox4.Controls.Add(Me.Label206)
        Me.GroupBox4.Controls.Add(Me.TextBox51)
        Me.GroupBox4.Controls.Add(Me.NumericUpDown12)
        Me.GroupBox4.Controls.Add(Me.Button49)
        Me.GroupBox4.Controls.Add(Me.NumericUpDown16)
        Me.GroupBox4.Controls.Add(Me.Button50)
        Me.GroupBox4.Controls.Add(Me.Button56)
        Me.GroupBox4.Controls.Add(Me.Label201)
        Me.GroupBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.Location = New System.Drawing.Point(3, 6)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(592, 198)
        Me.GroupBox4.TabIndex = 469
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Page(01h) / Fan(3Bh)"
        '
        'Label151
        '
        Me.Label151.AutoSize = True
        Me.Label151.BackColor = System.Drawing.Color.GreenYellow
        Me.Label151.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label151.Location = New System.Drawing.Point(425, 113)
        Me.Label151.Name = "Label151"
        Me.Label151.Size = New System.Drawing.Size(102, 13)
        Me.Label151.TabIndex = 495
        Me.Label151.Text = "Vbulk 400+(D0h)"
        '
        'NumericUpDown2
        '
        Me.NumericUpDown2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericUpDown2.Location = New System.Drawing.Point(405, 130)
        Me.NumericUpDown2.Maximum = New Decimal(New Integer() {101, 0, 0, 0})
        Me.NumericUpDown2.Name = "NumericUpDown2"
        Me.NumericUpDown2.Size = New System.Drawing.Size(54, 23)
        Me.NumericUpDown2.TabIndex = 494
        Me.NumericUpDown2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox28
        '
        Me.TextBox28.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox28.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox28.Location = New System.Drawing.Point(405, 163)
        Me.TextBox28.Multiline = True
        Me.TextBox28.Name = "TextBox28"
        Me.TextBox28.ReadOnly = True
        Me.TextBox28.Size = New System.Drawing.Size(52, 28)
        Me.TextBox28.TabIndex = 493
        Me.TextBox28.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Button29
        '
        Me.Button29.BackColor = System.Drawing.Color.Transparent
        Me.Button29.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button29.Location = New System.Drawing.Point(475, 163)
        Me.Button29.Name = "Button29"
        Me.Button29.Size = New System.Drawing.Size(100, 29)
        Me.Button29.TabIndex = 492
        Me.Button29.Text = "Read Vbulk"
        Me.Button29.UseVisualStyleBackColor = False
        '
        'Button26
        '
        Me.Button26.BackColor = System.Drawing.Color.Transparent
        Me.Button26.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button26.Location = New System.Drawing.Point(475, 130)
        Me.Button26.Name = "Button26"
        Me.Button26.Size = New System.Drawing.Size(100, 27)
        Me.Button26.TabIndex = 491
        Me.Button26.Text = "SET Vbulk"
        Me.Button26.UseVisualStyleBackColor = False
        '
        'Label69
        '
        Me.Label69.AutoSize = True
        Me.Label69.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label69.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label69.Location = New System.Drawing.Point(13, 169)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(185, 13)
        Me.Label69.TabIndex = 490
        Me.Label69.Text = "On Off Confi Status Description"
        '
        'TextBox17
        '
        Me.TextBox17.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox17.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox17.Location = New System.Drawing.Point(207, 143)
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.ReadOnly = True
        Me.TextBox17.Size = New System.Drawing.Size(28, 23)
        Me.TextBox17.TabIndex = 489
        Me.TextBox17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Button24
        '
        Me.Button24.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button24.Location = New System.Drawing.Point(247, 142)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(64, 23)
        Me.Button24.TabIndex = 488
        Me.Button24.Text = "Read"
        Me.Button24.UseVisualStyleBackColor = True
        '
        'CheckBox4
        '
        Me.CheckBox4.AutoSize = True
        Me.CheckBox4.Checked = True
        Me.CheckBox4.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox4.Location = New System.Drawing.Point(27, 119)
        Me.CheckBox4.Name = "CheckBox4"
        Me.CheckBox4.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox4.TabIndex = 487
        Me.CheckBox4.UseVisualStyleBackColor = True
        '
        'Label68
        '
        Me.Label68.AutoSize = True
        Me.Label68.BackColor = System.Drawing.Color.GreenYellow
        Me.Label68.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label68.Location = New System.Drawing.Point(35, 99)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(137, 13)
        Me.Label68.TabIndex = 485
        Me.Label68.Text = "ON_OFF_CONFIG(02h)"
        '
        'TextBox16
        '
        Me.TextBox16.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.TextBox16.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox16.Location = New System.Drawing.Point(207, 114)
        Me.TextBox16.MaxLength = 2
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.ReadOnly = True
        Me.TextBox16.Size = New System.Drawing.Size(27, 23)
        Me.TextBox16.TabIndex = 484
        '
        'Button23
        '
        Me.Button23.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button23.Location = New System.Drawing.Point(247, 113)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(64, 23)
        Me.Button23.TabIndex = 483
        Me.Button23.Text = "Write"
        Me.Button23.UseVisualStyleBackColor = True
        '
        'CheckBox3
        '
        Me.CheckBox3.AutoSize = True
        Me.CheckBox3.Checked = True
        Me.CheckBox3.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox3.Enabled = False
        Me.CheckBox3.Location = New System.Drawing.Point(165, 119)
        Me.CheckBox3.Name = "CheckBox3"
        Me.CheckBox3.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox3.TabIndex = 475
        Me.CheckBox3.UseVisualStyleBackColor = True
        '
        'CheckBox72
        '
        Me.CheckBox72.AutoSize = True
        Me.CheckBox72.Checked = True
        Me.CheckBox72.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox72.Location = New System.Drawing.Point(62, 119)
        Me.CheckBox72.Name = "CheckBox72"
        Me.CheckBox72.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox72.TabIndex = 480
        Me.CheckBox72.UseVisualStyleBackColor = True
        '
        'CheckBox73
        '
        Me.CheckBox73.AutoSize = True
        Me.CheckBox73.Checked = True
        Me.CheckBox73.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox73.Location = New System.Drawing.Point(96, 119)
        Me.CheckBox73.Name = "CheckBox73"
        Me.CheckBox73.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox73.TabIndex = 481
        Me.CheckBox73.UseVisualStyleBackColor = True
        '
        'CheckBox74
        '
        Me.CheckBox74.AutoSize = True
        Me.CheckBox74.Enabled = False
        Me.CheckBox74.Location = New System.Drawing.Point(131, 119)
        Me.CheckBox74.Name = "CheckBox74"
        Me.CheckBox74.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox74.TabIndex = 482
        Me.CheckBox74.UseVisualStyleBackColor = True
        '
        'Label206
        '
        Me.Label206.AutoSize = True
        Me.Label206.BackColor = System.Drawing.Color.GreenYellow
        Me.Label206.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label206.Location = New System.Drawing.Point(437, 19)
        Me.Label206.Name = "Label206"
        Me.Label206.Size = New System.Drawing.Size(58, 13)
        Me.Label206.TabIndex = 471
        Me.Label206.Text = "Fan(3Bh)"
        '
        'TextBox51
        '
        Me.TextBox51.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox51.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox51.Location = New System.Drawing.Point(405, 66)
        Me.TextBox51.Multiline = True
        Me.TextBox51.Name = "TextBox51"
        Me.TextBox51.ReadOnly = True
        Me.TextBox51.Size = New System.Drawing.Size(52, 23)
        Me.TextBox51.TabIndex = 420
        Me.TextBox51.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericUpDown12
        '
        Me.NumericUpDown12.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericUpDown12.Location = New System.Drawing.Point(405, 35)
        Me.NumericUpDown12.Maximum = New Decimal(New Integer() {101, 0, 0, 0})
        Me.NumericUpDown12.Name = "NumericUpDown12"
        Me.NumericUpDown12.Size = New System.Drawing.Size(54, 23)
        Me.NumericUpDown12.TabIndex = 420
        Me.NumericUpDown12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown12.Value = New Decimal(New Integer() {20, 0, 0, 0})
        '
        'Button49
        '
        Me.Button49.BackColor = System.Drawing.Color.Transparent
        Me.Button49.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button49.Location = New System.Drawing.Point(475, 64)
        Me.Button49.Name = "Button49"
        Me.Button49.Size = New System.Drawing.Size(82, 25)
        Me.Button49.TabIndex = 419
        Me.Button49.Text = "Read Duty"
        Me.Button49.UseVisualStyleBackColor = False
        '
        'NumericUpDown16
        '
        Me.NumericUpDown16.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericUpDown16.Location = New System.Drawing.Point(43, 49)
        Me.NumericUpDown16.Maximum = New Decimal(New Integer() {255, 0, 0, 0})
        Me.NumericUpDown16.Name = "NumericUpDown16"
        Me.NumericUpDown16.Size = New System.Drawing.Size(62, 23)
        Me.NumericUpDown16.TabIndex = 471
        Me.NumericUpDown16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Button50
        '
        Me.Button50.BackColor = System.Drawing.Color.Transparent
        Me.Button50.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button50.Location = New System.Drawing.Point(475, 35)
        Me.Button50.Name = "Button50"
        Me.Button50.Size = New System.Drawing.Size(82, 23)
        Me.Button50.TabIndex = 419
        Me.Button50.Text = "SET Duty"
        Me.Button50.UseVisualStyleBackColor = False
        '
        'Button56
        '
        Me.Button56.BackColor = System.Drawing.Color.Transparent
        Me.Button56.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button56.Location = New System.Drawing.Point(108, 47)
        Me.Button56.Name = "Button56"
        Me.Button56.Size = New System.Drawing.Size(64, 25)
        Me.Button56.TabIndex = 470
        Me.Button56.Text = "Page"
        Me.Button56.UseVisualStyleBackColor = False
        '
        'Label201
        '
        Me.Label201.AutoSize = True
        Me.Label201.BackColor = System.Drawing.Color.GreenYellow
        Me.Label201.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label201.Location = New System.Drawing.Point(64, 27)
        Me.Label201.Name = "Label201"
        Me.Label201.Size = New System.Drawing.Size(69, 13)
        Me.Label201.TabIndex = 469
        Me.Label201.Text = "PAGE(01h)"
        '
        'TextBox3
        '
        Me.TextBox3.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.TextBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox3.Location = New System.Drawing.Point(171, 182)
        Me.TextBox3.MaxLength = 2
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.ReadOnly = True
        Me.TextBox3.Size = New System.Drawing.Size(27, 23)
        Me.TextBox3.TabIndex = 475
        '
        'GroupBox5
        '
        Me.GroupBox5.BackColor = System.Drawing.Color.AliceBlue
        Me.GroupBox5.Controls.Add(Me.Label232)
        Me.GroupBox5.Controls.Add(Me.Label230)
        Me.GroupBox5.Controls.Add(Me.Label90)
        Me.GroupBox5.Controls.Add(Me.Label83)
        Me.GroupBox5.Controls.Add(Me.Label81)
        Me.GroupBox5.Controls.Add(Me.Label222)
        Me.GroupBox5.Controls.Add(Me.Label220)
        Me.GroupBox5.Controls.Add(Me.TextBox3)
        Me.GroupBox5.Controls.Add(Me.Label348)
        Me.GroupBox5.Controls.Add(Me.Button7)
        Me.GroupBox5.Controls.Add(Me.Button4)
        Me.GroupBox5.Controls.Add(Me.NumericUpDown21)
        Me.GroupBox5.Controls.Add(Me.Label275)
        Me.GroupBox5.Controls.Add(Me.Label327)
        Me.GroupBox5.Controls.Add(Me.Label272)
        Me.GroupBox5.Controls.Add(Me.Label269)
        Me.GroupBox5.Controls.Add(Me.Button103)
        Me.GroupBox5.Controls.Add(Me.Label268)
        Me.GroupBox5.Controls.Add(Me.Button104)
        Me.GroupBox5.Controls.Add(Me.Label264)
        Me.GroupBox5.Controls.Add(Me.CheckBox6)
        Me.GroupBox5.Controls.Add(Me.Label252)
        Me.GroupBox5.Controls.Add(Me.CheckBox7)
        Me.GroupBox5.Controls.Add(Me.Label246)
        Me.GroupBox5.Controls.Add(Me.CheckBox8)
        Me.GroupBox5.Controls.Add(Me.TextBox89)
        Me.GroupBox5.Controls.Add(Me.CheckBox9)
        Me.GroupBox5.Controls.Add(Me.TextBox27)
        Me.GroupBox5.Controls.Add(Me.CheckBox10)
        Me.GroupBox5.Controls.Add(Me.CheckBox20)
        Me.GroupBox5.Controls.Add(Me.CheckBox11)
        Me.GroupBox5.Controls.Add(Me.CheckBox19)
        Me.GroupBox5.Controls.Add(Me.CheckBox12)
        Me.GroupBox5.Controls.Add(Me.CheckBox18)
        Me.GroupBox5.Controls.Add(Me.CheckBox69)
        Me.GroupBox5.Controls.Add(Me.CheckBox17)
        Me.GroupBox5.Controls.Add(Me.TextBox31)
        Me.GroupBox5.Controls.Add(Me.CheckBox16)
        Me.GroupBox5.Controls.Add(Me.TextBox84)
        Me.GroupBox5.Controls.Add(Me.CheckBox15)
        Me.GroupBox5.Controls.Add(Me.Label347)
        Me.GroupBox5.Controls.Add(Me.CheckBox14)
        Me.GroupBox5.Controls.Add(Me.CheckBox13)
        Me.GroupBox5.Controls.Add(Me.TextBox26)
        Me.GroupBox5.Controls.Add(Me.TextBox23)
        Me.GroupBox5.Controls.Add(Me.Label131)
        Me.GroupBox5.Controls.Add(Me.CheckBox28)
        Me.GroupBox5.Controls.Add(Me.Label279)
        Me.GroupBox5.Controls.Add(Me.CheckBox27)
        Me.GroupBox5.Controls.Add(Me.Label277)
        Me.GroupBox5.Controls.Add(Me.CheckBox26)
        Me.GroupBox5.Controls.Add(Me.Label276)
        Me.GroupBox5.Controls.Add(Me.CheckBox25)
        Me.GroupBox5.Controls.Add(Me.CheckBox24)
        Me.GroupBox5.Controls.Add(Me.Button101)
        Me.GroupBox5.Controls.Add(Me.CheckBox23)
        Me.GroupBox5.Controls.Add(Me.Button102)
        Me.GroupBox5.Controls.Add(Me.CheckBox22)
        Me.GroupBox5.Controls.Add(Me.Button99)
        Me.GroupBox5.Controls.Add(Me.CheckBox21)
        Me.GroupBox5.Controls.Add(Me.Button100)
        Me.GroupBox5.Controls.Add(Me.TextBox22)
        Me.GroupBox5.Controls.Add(Me.Button97)
        Me.GroupBox5.Controls.Add(Me.TextBox21)
        Me.GroupBox5.Controls.Add(Me.Button98)
        Me.GroupBox5.Controls.Add(Me.CheckBox36)
        Me.GroupBox5.Controls.Add(Me.Button95)
        Me.GroupBox5.Controls.Add(Me.CheckBox35)
        Me.GroupBox5.Controls.Add(Me.Button96)
        Me.GroupBox5.Controls.Add(Me.CheckBox34)
        Me.GroupBox5.Controls.Add(Me.Button91)
        Me.GroupBox5.Controls.Add(Me.CheckBox33)
        Me.GroupBox5.Controls.Add(Me.Button92)
        Me.GroupBox5.Controls.Add(Me.CheckBox32)
        Me.GroupBox5.Controls.Add(Me.Button89)
        Me.GroupBox5.Controls.Add(Me.CheckBox31)
        Me.GroupBox5.Controls.Add(Me.Button90)
        Me.GroupBox5.Controls.Add(Me.CheckBox30)
        Me.GroupBox5.Controls.Add(Me.Label76)
        Me.GroupBox5.Controls.Add(Me.CheckBox29)
        Me.GroupBox5.Controls.Add(Me.Label77)
        Me.GroupBox5.Controls.Add(Me.TextBox20)
        Me.GroupBox5.Controls.Add(Me.Label79)
        Me.GroupBox5.Controls.Add(Me.TextBox7)
        Me.GroupBox5.Controls.Add(Me.Label80)
        Me.GroupBox5.Controls.Add(Me.CheckBox44)
        Me.GroupBox5.Controls.Add(Me.Label89)
        Me.GroupBox5.Controls.Add(Me.CheckBox43)
        Me.GroupBox5.Controls.Add(Me.CheckBox42)
        Me.GroupBox5.Controls.Add(Me.CheckBox41)
        Me.GroupBox5.Controls.Add(Me.CheckBox40)
        Me.GroupBox5.Controls.Add(Me.Label95)
        Me.GroupBox5.Controls.Add(Me.CheckBox39)
        Me.GroupBox5.Controls.Add(Me.Label125)
        Me.GroupBox5.Controls.Add(Me.CheckBox38)
        Me.GroupBox5.Controls.Add(Me.Label127)
        Me.GroupBox5.Controls.Add(Me.CheckBox37)
        Me.GroupBox5.Controls.Add(Me.Label134)
        Me.GroupBox5.Controls.Add(Me.TextBox6)
        Me.GroupBox5.Controls.Add(Me.Label135)
        Me.GroupBox5.Controls.Add(Me.TextBox5)
        Me.GroupBox5.Controls.Add(Me.CheckBox61)
        Me.GroupBox5.Controls.Add(Me.CheckBox52)
        Me.GroupBox5.Controls.Add(Me.CheckBox62)
        Me.GroupBox5.Controls.Add(Me.CheckBox51)
        Me.GroupBox5.Controls.Add(Me.CheckBox63)
        Me.GroupBox5.Controls.Add(Me.CheckBox50)
        Me.GroupBox5.Controls.Add(Me.CheckBox64)
        Me.GroupBox5.Controls.Add(Me.CheckBox49)
        Me.GroupBox5.Controls.Add(Me.CheckBox65)
        Me.GroupBox5.Controls.Add(Me.CheckBox48)
        Me.GroupBox5.Controls.Add(Me.CheckBox66)
        Me.GroupBox5.Controls.Add(Me.CheckBox47)
        Me.GroupBox5.Controls.Add(Me.CheckBox67)
        Me.GroupBox5.Controls.Add(Me.CheckBox46)
        Me.GroupBox5.Controls.Add(Me.CheckBox68)
        Me.GroupBox5.Controls.Add(Me.CheckBox45)
        Me.GroupBox5.Controls.Add(Me.TextBox1)
        Me.GroupBox5.Controls.Add(Me.TextBox4)
        Me.GroupBox5.Controls.Add(Me.TextBox2)
        Me.GroupBox5.Controls.Add(Me.CheckBox53)
        Me.GroupBox5.Controls.Add(Me.CheckBox60)
        Me.GroupBox5.Controls.Add(Me.CheckBox54)
        Me.GroupBox5.Controls.Add(Me.CheckBox59)
        Me.GroupBox5.Controls.Add(Me.CheckBox55)
        Me.GroupBox5.Controls.Add(Me.CheckBox58)
        Me.GroupBox5.Controls.Add(Me.CheckBox56)
        Me.GroupBox5.Controls.Add(Me.CheckBox57)
        Me.GroupBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox5.Location = New System.Drawing.Point(6, 0)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(589, 318)
        Me.GroupBox5.TabIndex = 476
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "SMB_Alert Making Conjunction  With Page Plus Write"
        '
        'Label232
        '
        Me.Label232.AutoSize = True
        Me.Label232.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label232.Location = New System.Drawing.Point(378, 262)
        Me.Label232.Name = "Label232"
        Me.Label232.Size = New System.Drawing.Size(37, 9)
        Me.Label232.TabIndex = 482
        Me.Label232.Text = "Oring_Flt"
        '
        'Label230
        '
        Me.Label230.AutoSize = True
        Me.Label230.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label230.Location = New System.Drawing.Point(414, 262)
        Me.Label230.Name = "Label230"
        Me.Label230.Size = New System.Drawing.Size(27, 9)
        Me.Label230.TabIndex = 481
        Me.Label230.Text = "Invalid"
        '
        'Label90
        '
        Me.Label90.AutoSize = True
        Me.Label90.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label90.Location = New System.Drawing.Point(416, 176)
        Me.Label90.Name = "Label90"
        Me.Label90.Size = New System.Drawing.Size(24, 9)
        Me.Label90.TabIndex = 480
        Me.Label90.Text = "MEM"
        '
        'Label83
        '
        Me.Label83.AutoSize = True
        Me.Label83.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label83.Location = New System.Drawing.Point(382, 177)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(31, 9)
        Me.Label83.TabIndex = 479
        Me.Label83.Text = "COMM"
        '
        'Label81
        '
        Me.Label81.AutoSize = True
        Me.Label81.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label81.Location = New System.Drawing.Point(323, 177)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(33, 9)
        Me.Label81.TabIndex = 478
        Me.Label81.Text = "PRCSR"
        '
        'Label222
        '
        Me.Label222.AutoSize = True
        Me.Label222.Enabled = False
        Me.Label222.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label222.Location = New System.Drawing.Point(518, 46)
        Me.Label222.Name = "Label222"
        Me.Label222.Size = New System.Drawing.Size(58, 12)
        Me.Label222.TabIndex = 477
        Me.Label222.Text = "BW_BRPC"
        Me.Label222.Visible = False
        '
        'Label220
        '
        Me.Label220.AutoSize = True
        Me.Label220.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label220.Location = New System.Drawing.Point(440, 45)
        Me.Label220.Name = "Label220"
        Me.Label220.Size = New System.Drawing.Size(63, 12)
        Me.Label220.TabIndex = 476
        Me.Label220.Text = "Write Block"
        '
        'Label348
        '
        Me.Label348.AutoSize = True
        Me.Label348.BackColor = System.Drawing.Color.Yellow
        Me.Label348.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label348.Location = New System.Drawing.Point(80, 40)
        Me.Label348.Name = "Label348"
        Me.Label348.Size = New System.Drawing.Size(45, 17)
        Me.Label348.TabIndex = 474
        Me.Label348.Text = "Page"
        '
        'Button7
        '
        Me.Button7.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button7.Location = New System.Drawing.Point(442, 65)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(62, 23)
        Me.Button7.TabIndex = 281
        Me.Button7.Text = "Write"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Enabled = False
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Location = New System.Drawing.Point(517, 65)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(62, 23)
        Me.Button4.TabIndex = 282
        Me.Button4.Text = "Read"
        Me.Button4.UseVisualStyleBackColor = True
        Me.Button4.Visible = False
        '
        'NumericUpDown21
        '
        Me.NumericUpDown21.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericUpDown21.Location = New System.Drawing.Point(133, 37)
        Me.NumericUpDown21.Maximum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown21.Name = "NumericUpDown21"
        Me.NumericUpDown21.Size = New System.Drawing.Size(65, 23)
        Me.NumericUpDown21.TabIndex = 473
        Me.NumericUpDown21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label275
        '
        Me.Label275.AutoSize = True
        Me.Label275.BackColor = System.Drawing.Color.Yellow
        Me.Label275.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label275.Location = New System.Drawing.Point(25, 69)
        Me.Label275.Name = "Label275"
        Me.Label275.Size = New System.Drawing.Size(102, 17)
        Me.Label275.TabIndex = 283
        Me.Label275.Text = "Status VOUT"
        '
        'Label327
        '
        Me.Label327.AutoSize = True
        Me.Label327.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label327.Location = New System.Drawing.Point(409, 234)
        Me.Label327.Name = "Label327"
        Me.Label327.Size = New System.Drawing.Size(38, 9)
        Me.Label327.TabIndex = 419
        Me.Label327.Text = "VSB_FLT"
        '
        'Label272
        '
        Me.Label272.AutoSize = True
        Me.Label272.BackColor = System.Drawing.Color.Yellow
        Me.Label272.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label272.Location = New System.Drawing.Point(31, 95)
        Me.Label272.Name = "Label272"
        Me.Label272.Size = New System.Drawing.Size(96, 17)
        Me.Label272.TabIndex = 284
        Me.Label272.Text = "Status IOUT"
        '
        'Label269
        '
        Me.Label269.AutoSize = True
        Me.Label269.BackColor = System.Drawing.Color.Yellow
        Me.Label269.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label269.Location = New System.Drawing.Point(28, 152)
        Me.Label269.Name = "Label269"
        Me.Label269.Size = New System.Drawing.Size(99, 17)
        Me.Label269.TabIndex = 285
        Me.Label269.Text = "Status Temp"
        '
        'Button103
        '
        Me.Button103.Enabled = False
        Me.Button103.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button103.Location = New System.Drawing.Point(517, 268)
        Me.Button103.Name = "Button103"
        Me.Button103.Size = New System.Drawing.Size(62, 23)
        Me.Button103.TabIndex = 417
        Me.Button103.Text = "Read"
        Me.Button103.UseVisualStyleBackColor = True
        Me.Button103.Visible = False
        '
        'Label268
        '
        Me.Label268.AutoSize = True
        Me.Label268.BackColor = System.Drawing.Color.Yellow
        Me.Label268.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label268.Location = New System.Drawing.Point(22, 124)
        Me.Label268.Name = "Label268"
        Me.Label268.Size = New System.Drawing.Size(105, 17)
        Me.Label268.TabIndex = 286
        Me.Label268.Text = "Status INPUT"
        '
        'Button104
        '
        Me.Button104.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button104.Location = New System.Drawing.Point(442, 268)
        Me.Button104.Name = "Button104"
        Me.Button104.Size = New System.Drawing.Size(62, 23)
        Me.Button104.TabIndex = 416
        Me.Button104.Text = "Write"
        Me.Button104.UseVisualStyleBackColor = True
        '
        'Label264
        '
        Me.Label264.AutoSize = True
        Me.Label264.BackColor = System.Drawing.Color.Yellow
        Me.Label264.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label264.Location = New System.Drawing.Point(11, 218)
        Me.Label264.Name = "Label264"
        Me.Label264.Size = New System.Drawing.Size(116, 17)
        Me.Label264.TabIndex = 287
        Me.Label264.Text = "Status FAN_12"
        '
        'CheckBox6
        '
        Me.CheckBox6.AutoSize = True
        Me.CheckBox6.Location = New System.Drawing.Point(391, 274)
        Me.CheckBox6.Name = "CheckBox6"
        Me.CheckBox6.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox6.TabIndex = 415
        Me.CheckBox6.UseVisualStyleBackColor = True
        '
        'Label252
        '
        Me.Label252.AutoSize = True
        Me.Label252.BackColor = System.Drawing.Color.Yellow
        Me.Label252.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label252.Location = New System.Drawing.Point(38, 186)
        Me.Label252.Name = "Label252"
        Me.Label252.Size = New System.Drawing.Size(90, 17)
        Me.Label252.TabIndex = 288
        Me.Label252.Text = "Status CML"
        '
        'CheckBox7
        '
        Me.CheckBox7.AutoSize = True
        Me.CheckBox7.Location = New System.Drawing.Point(361, 274)
        Me.CheckBox7.Name = "CheckBox7"
        Me.CheckBox7.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox7.TabIndex = 414
        Me.CheckBox7.UseVisualStyleBackColor = True
        '
        'Label246
        '
        Me.Label246.AutoSize = True
        Me.Label246.BackColor = System.Drawing.Color.Yellow
        Me.Label246.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label246.Location = New System.Drawing.Point(38, 244)
        Me.Label246.Name = "Label246"
        Me.Label246.Size = New System.Drawing.Size(91, 17)
        Me.Label246.TabIndex = 289
        Me.Label246.Text = "Status MFR"
        '
        'CheckBox8
        '
        Me.CheckBox8.AutoSize = True
        Me.CheckBox8.Location = New System.Drawing.Point(331, 274)
        Me.CheckBox8.Name = "CheckBox8"
        Me.CheckBox8.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox8.TabIndex = 413
        Me.CheckBox8.UseVisualStyleBackColor = True
        '
        'TextBox89
        '
        Me.TextBox89.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox89.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox89.Location = New System.Drawing.Point(133, 66)
        Me.TextBox89.MaxLength = 2
        Me.TextBox89.Name = "TextBox89"
        Me.TextBox89.ReadOnly = True
        Me.TextBox89.Size = New System.Drawing.Size(27, 23)
        Me.TextBox89.TabIndex = 300
        '
        'CheckBox9
        '
        Me.CheckBox9.AutoSize = True
        Me.CheckBox9.Location = New System.Drawing.Point(301, 274)
        Me.CheckBox9.Name = "CheckBox9"
        Me.CheckBox9.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox9.TabIndex = 412
        Me.CheckBox9.UseVisualStyleBackColor = True
        '
        'TextBox27
        '
        Me.TextBox27.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.TextBox27.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox27.Location = New System.Drawing.Point(171, 66)
        Me.TextBox27.MaxLength = 2
        Me.TextBox27.Name = "TextBox27"
        Me.TextBox27.ReadOnly = True
        Me.TextBox27.Size = New System.Drawing.Size(27, 23)
        Me.TextBox27.TabIndex = 301
        '
        'CheckBox10
        '
        Me.CheckBox10.AutoSize = True
        Me.CheckBox10.Location = New System.Drawing.Point(271, 274)
        Me.CheckBox10.Name = "CheckBox10"
        Me.CheckBox10.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox10.TabIndex = 411
        Me.CheckBox10.UseVisualStyleBackColor = True
        '
        'CheckBox20
        '
        Me.CheckBox20.AutoSize = True
        Me.CheckBox20.Location = New System.Drawing.Point(421, 70)
        Me.CheckBox20.Name = "CheckBox20"
        Me.CheckBox20.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox20.TabIndex = 302
        Me.CheckBox20.UseVisualStyleBackColor = True
        '
        'CheckBox11
        '
        Me.CheckBox11.AutoSize = True
        Me.CheckBox11.Location = New System.Drawing.Point(241, 274)
        Me.CheckBox11.Name = "CheckBox11"
        Me.CheckBox11.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox11.TabIndex = 410
        Me.CheckBox11.UseVisualStyleBackColor = True
        '
        'CheckBox19
        '
        Me.CheckBox19.AutoSize = True
        Me.CheckBox19.Location = New System.Drawing.Point(211, 71)
        Me.CheckBox19.Name = "CheckBox19"
        Me.CheckBox19.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox19.TabIndex = 303
        Me.CheckBox19.UseVisualStyleBackColor = True
        '
        'CheckBox12
        '
        Me.CheckBox12.AutoSize = True
        Me.CheckBox12.Location = New System.Drawing.Point(211, 274)
        Me.CheckBox12.Name = "CheckBox12"
        Me.CheckBox12.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox12.TabIndex = 409
        Me.CheckBox12.UseVisualStyleBackColor = True
        '
        'CheckBox18
        '
        Me.CheckBox18.AutoSize = True
        Me.CheckBox18.Location = New System.Drawing.Point(241, 71)
        Me.CheckBox18.Name = "CheckBox18"
        Me.CheckBox18.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox18.TabIndex = 304
        Me.CheckBox18.UseVisualStyleBackColor = True
        '
        'CheckBox69
        '
        Me.CheckBox69.AutoSize = True
        Me.CheckBox69.Location = New System.Drawing.Point(421, 273)
        Me.CheckBox69.Name = "CheckBox69"
        Me.CheckBox69.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox69.TabIndex = 408
        Me.CheckBox69.UseVisualStyleBackColor = True
        '
        'CheckBox17
        '
        Me.CheckBox17.AutoSize = True
        Me.CheckBox17.Location = New System.Drawing.Point(271, 71)
        Me.CheckBox17.Name = "CheckBox17"
        Me.CheckBox17.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox17.TabIndex = 305
        Me.CheckBox17.UseVisualStyleBackColor = True
        '
        'TextBox31
        '
        Me.TextBox31.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.TextBox31.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox31.Location = New System.Drawing.Point(171, 269)
        Me.TextBox31.MaxLength = 2
        Me.TextBox31.Name = "TextBox31"
        Me.TextBox31.ReadOnly = True
        Me.TextBox31.Size = New System.Drawing.Size(27, 23)
        Me.TextBox31.TabIndex = 407
        '
        'CheckBox16
        '
        Me.CheckBox16.AutoSize = True
        Me.CheckBox16.Location = New System.Drawing.Point(301, 71)
        Me.CheckBox16.Name = "CheckBox16"
        Me.CheckBox16.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox16.TabIndex = 306
        Me.CheckBox16.UseVisualStyleBackColor = True
        '
        'TextBox84
        '
        Me.TextBox84.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox84.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox84.Location = New System.Drawing.Point(133, 269)
        Me.TextBox84.MaxLength = 2
        Me.TextBox84.Name = "TextBox84"
        Me.TextBox84.ReadOnly = True
        Me.TextBox84.Size = New System.Drawing.Size(27, 23)
        Me.TextBox84.TabIndex = 406
        '
        'CheckBox15
        '
        Me.CheckBox15.AutoSize = True
        Me.CheckBox15.Location = New System.Drawing.Point(331, 71)
        Me.CheckBox15.Name = "CheckBox15"
        Me.CheckBox15.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox15.TabIndex = 307
        Me.CheckBox15.UseVisualStyleBackColor = True
        '
        'Label347
        '
        Me.Label347.AutoSize = True
        Me.Label347.BackColor = System.Drawing.Color.Yellow
        Me.Label347.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label347.Location = New System.Drawing.Point(15, 273)
        Me.Label347.Name = "Label347"
        Me.Label347.Size = New System.Drawing.Size(113, 17)
        Me.Label347.TabIndex = 405
        Me.Label347.Text = "Status OTHER"
        '
        'CheckBox14
        '
        Me.CheckBox14.AutoSize = True
        Me.CheckBox14.Location = New System.Drawing.Point(361, 71)
        Me.CheckBox14.Name = "CheckBox14"
        Me.CheckBox14.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox14.TabIndex = 308
        Me.CheckBox14.UseVisualStyleBackColor = True
        '
        'CheckBox13
        '
        Me.CheckBox13.AutoSize = True
        Me.CheckBox13.Location = New System.Drawing.Point(391, 71)
        Me.CheckBox13.Name = "CheckBox13"
        Me.CheckBox13.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox13.TabIndex = 309
        Me.CheckBox13.UseVisualStyleBackColor = True
        '
        'TextBox26
        '
        Me.TextBox26.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox26.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox26.Location = New System.Drawing.Point(133, 95)
        Me.TextBox26.MaxLength = 2
        Me.TextBox26.Name = "TextBox26"
        Me.TextBox26.ReadOnly = True
        Me.TextBox26.Size = New System.Drawing.Size(27, 23)
        Me.TextBox26.TabIndex = 310
        '
        'TextBox23
        '
        Me.TextBox23.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.TextBox23.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox23.Location = New System.Drawing.Point(171, 95)
        Me.TextBox23.MaxLength = 2
        Me.TextBox23.Name = "TextBox23"
        Me.TextBox23.ReadOnly = True
        Me.TextBox23.Size = New System.Drawing.Size(27, 23)
        Me.TextBox23.TabIndex = 311
        '
        'Label131
        '
        Me.Label131.AutoSize = True
        Me.Label131.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label131.Location = New System.Drawing.Point(300, 119)
        Me.Label131.Name = "Label131"
        Me.Label131.Size = New System.Drawing.Size(16, 9)
        Me.Label131.TabIndex = 401
        Me.Label131.Text = "UV"
        '
        'CheckBox28
        '
        Me.CheckBox28.AutoSize = True
        Me.CheckBox28.Location = New System.Drawing.Point(421, 99)
        Me.CheckBox28.Name = "CheckBox28"
        Me.CheckBox28.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox28.TabIndex = 312
        Me.CheckBox28.UseVisualStyleBackColor = True
        '
        'Label279
        '
        Me.Label279.AutoSize = True
        Me.Label279.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label279.Location = New System.Drawing.Point(237, 119)
        Me.Label279.Name = "Label279"
        Me.Label279.Size = New System.Drawing.Size(24, 9)
        Me.Label279.TabIndex = 400
        Me.Label279.Text = "OVW"
        '
        'CheckBox27
        '
        Me.CheckBox27.AutoSize = True
        Me.CheckBox27.Location = New System.Drawing.Point(211, 100)
        Me.CheckBox27.Name = "CheckBox27"
        Me.CheckBox27.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox27.TabIndex = 313
        Me.CheckBox27.UseVisualStyleBackColor = True
        '
        'Label277
        '
        Me.Label277.AutoSize = True
        Me.Label277.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label277.Location = New System.Drawing.Point(210, 119)
        Me.Label277.Name = "Label277"
        Me.Label277.Size = New System.Drawing.Size(16, 9)
        Me.Label277.TabIndex = 399
        Me.Label277.Text = "OV"
        '
        'CheckBox26
        '
        Me.CheckBox26.AutoSize = True
        Me.CheckBox26.Location = New System.Drawing.Point(241, 100)
        Me.CheckBox26.Name = "CheckBox26"
        Me.CheckBox26.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox26.TabIndex = 314
        Me.CheckBox26.UseVisualStyleBackColor = True
        '
        'Label276
        '
        Me.Label276.AutoSize = True
        Me.Label276.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label276.Location = New System.Drawing.Point(266, 89)
        Me.Label276.Name = "Label276"
        Me.Label276.Size = New System.Drawing.Size(25, 9)
        Me.Label276.TabIndex = 398
        Me.Label276.Text = "OCW"
        '
        'CheckBox25
        '
        Me.CheckBox25.AutoSize = True
        Me.CheckBox25.Location = New System.Drawing.Point(271, 100)
        Me.CheckBox25.Name = "CheckBox25"
        Me.CheckBox25.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox25.TabIndex = 315
        Me.CheckBox25.UseVisualStyleBackColor = True
        '
        'CheckBox24
        '
        Me.CheckBox24.AutoSize = True
        Me.CheckBox24.Location = New System.Drawing.Point(301, 100)
        Me.CheckBox24.Name = "CheckBox24"
        Me.CheckBox24.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox24.TabIndex = 316
        Me.CheckBox24.UseVisualStyleBackColor = True
        '
        'Button101
        '
        Me.Button101.Enabled = False
        Me.Button101.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button101.Location = New System.Drawing.Point(517, 239)
        Me.Button101.Name = "Button101"
        Me.Button101.Size = New System.Drawing.Size(62, 23)
        Me.Button101.TabIndex = 396
        Me.Button101.Text = "Read"
        Me.Button101.UseVisualStyleBackColor = True
        Me.Button101.Visible = False
        '
        'CheckBox23
        '
        Me.CheckBox23.AutoSize = True
        Me.CheckBox23.Location = New System.Drawing.Point(331, 100)
        Me.CheckBox23.Name = "CheckBox23"
        Me.CheckBox23.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox23.TabIndex = 317
        Me.CheckBox23.UseVisualStyleBackColor = True
        '
        'Button102
        '
        Me.Button102.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button102.Location = New System.Drawing.Point(442, 239)
        Me.Button102.Name = "Button102"
        Me.Button102.Size = New System.Drawing.Size(62, 23)
        Me.Button102.TabIndex = 395
        Me.Button102.Text = "Write"
        Me.Button102.UseVisualStyleBackColor = True
        '
        'CheckBox22
        '
        Me.CheckBox22.AutoSize = True
        Me.CheckBox22.Location = New System.Drawing.Point(361, 100)
        Me.CheckBox22.Name = "CheckBox22"
        Me.CheckBox22.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox22.TabIndex = 318
        Me.CheckBox22.UseVisualStyleBackColor = True
        '
        'Button99
        '
        Me.Button99.Enabled = False
        Me.Button99.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button99.Location = New System.Drawing.Point(517, 181)
        Me.Button99.Name = "Button99"
        Me.Button99.Size = New System.Drawing.Size(62, 23)
        Me.Button99.TabIndex = 394
        Me.Button99.Text = "Read"
        Me.Button99.UseVisualStyleBackColor = True
        Me.Button99.Visible = False
        '
        'CheckBox21
        '
        Me.CheckBox21.AutoSize = True
        Me.CheckBox21.Location = New System.Drawing.Point(391, 100)
        Me.CheckBox21.Name = "CheckBox21"
        Me.CheckBox21.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox21.TabIndex = 319
        Me.CheckBox21.UseVisualStyleBackColor = True
        '
        'Button100
        '
        Me.Button100.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button100.Location = New System.Drawing.Point(442, 181)
        Me.Button100.Name = "Button100"
        Me.Button100.Size = New System.Drawing.Size(62, 23)
        Me.Button100.TabIndex = 393
        Me.Button100.Text = "Write"
        Me.Button100.UseVisualStyleBackColor = True
        '
        'TextBox22
        '
        Me.TextBox22.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox22.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox22.Location = New System.Drawing.Point(133, 153)
        Me.TextBox22.MaxLength = 2
        Me.TextBox22.Name = "TextBox22"
        Me.TextBox22.ReadOnly = True
        Me.TextBox22.Size = New System.Drawing.Size(27, 23)
        Me.TextBox22.TabIndex = 320
        '
        'Button97
        '
        Me.Button97.Enabled = False
        Me.Button97.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button97.Location = New System.Drawing.Point(517, 210)
        Me.Button97.Name = "Button97"
        Me.Button97.Size = New System.Drawing.Size(62, 23)
        Me.Button97.TabIndex = 392
        Me.Button97.Text = "Read"
        Me.Button97.UseVisualStyleBackColor = True
        Me.Button97.Visible = False
        '
        'TextBox21
        '
        Me.TextBox21.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.TextBox21.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox21.Location = New System.Drawing.Point(171, 153)
        Me.TextBox21.MaxLength = 2
        Me.TextBox21.Name = "TextBox21"
        Me.TextBox21.ReadOnly = True
        Me.TextBox21.Size = New System.Drawing.Size(27, 23)
        Me.TextBox21.TabIndex = 321
        '
        'Button98
        '
        Me.Button98.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button98.Location = New System.Drawing.Point(442, 210)
        Me.Button98.Name = "Button98"
        Me.Button98.Size = New System.Drawing.Size(62, 23)
        Me.Button98.TabIndex = 391
        Me.Button98.Text = "Write"
        Me.Button98.UseVisualStyleBackColor = True
        '
        'CheckBox36
        '
        Me.CheckBox36.AutoSize = True
        Me.CheckBox36.Location = New System.Drawing.Point(421, 157)
        Me.CheckBox36.Name = "CheckBox36"
        Me.CheckBox36.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox36.TabIndex = 322
        Me.CheckBox36.UseVisualStyleBackColor = True
        '
        'Button95
        '
        Me.Button95.Enabled = False
        Me.Button95.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button95.Location = New System.Drawing.Point(517, 123)
        Me.Button95.Name = "Button95"
        Me.Button95.Size = New System.Drawing.Size(62, 23)
        Me.Button95.TabIndex = 390
        Me.Button95.Text = "Read"
        Me.Button95.UseVisualStyleBackColor = True
        Me.Button95.Visible = False
        '
        'CheckBox35
        '
        Me.CheckBox35.AutoSize = True
        Me.CheckBox35.Location = New System.Drawing.Point(211, 158)
        Me.CheckBox35.Name = "CheckBox35"
        Me.CheckBox35.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox35.TabIndex = 323
        Me.CheckBox35.UseVisualStyleBackColor = True
        '
        'Button96
        '
        Me.Button96.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button96.Location = New System.Drawing.Point(442, 123)
        Me.Button96.Name = "Button96"
        Me.Button96.Size = New System.Drawing.Size(62, 23)
        Me.Button96.TabIndex = 389
        Me.Button96.Text = "Write"
        Me.Button96.UseVisualStyleBackColor = True
        '
        'CheckBox34
        '
        Me.CheckBox34.AutoSize = True
        Me.CheckBox34.Location = New System.Drawing.Point(241, 158)
        Me.CheckBox34.Name = "CheckBox34"
        Me.CheckBox34.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox34.TabIndex = 324
        Me.CheckBox34.UseVisualStyleBackColor = True
        '
        'Button91
        '
        Me.Button91.Enabled = False
        Me.Button91.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button91.Location = New System.Drawing.Point(517, 152)
        Me.Button91.Name = "Button91"
        Me.Button91.Size = New System.Drawing.Size(62, 23)
        Me.Button91.TabIndex = 388
        Me.Button91.Text = "Read"
        Me.Button91.UseVisualStyleBackColor = True
        Me.Button91.Visible = False
        '
        'CheckBox33
        '
        Me.CheckBox33.AutoSize = True
        Me.CheckBox33.Location = New System.Drawing.Point(271, 158)
        Me.CheckBox33.Name = "CheckBox33"
        Me.CheckBox33.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox33.TabIndex = 325
        Me.CheckBox33.UseVisualStyleBackColor = True
        '
        'Button92
        '
        Me.Button92.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button92.Location = New System.Drawing.Point(442, 152)
        Me.Button92.Name = "Button92"
        Me.Button92.Size = New System.Drawing.Size(62, 23)
        Me.Button92.TabIndex = 387
        Me.Button92.Text = "Write"
        Me.Button92.UseVisualStyleBackColor = True
        '
        'CheckBox32
        '
        Me.CheckBox32.AutoSize = True
        Me.CheckBox32.Location = New System.Drawing.Point(301, 158)
        Me.CheckBox32.Name = "CheckBox32"
        Me.CheckBox32.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox32.TabIndex = 326
        Me.CheckBox32.UseVisualStyleBackColor = True
        '
        'Button89
        '
        Me.Button89.Enabled = False
        Me.Button89.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button89.Location = New System.Drawing.Point(517, 94)
        Me.Button89.Name = "Button89"
        Me.Button89.Size = New System.Drawing.Size(62, 23)
        Me.Button89.TabIndex = 386
        Me.Button89.Text = "Read"
        Me.Button89.UseVisualStyleBackColor = True
        Me.Button89.Visible = False
        '
        'CheckBox31
        '
        Me.CheckBox31.AutoSize = True
        Me.CheckBox31.Location = New System.Drawing.Point(331, 158)
        Me.CheckBox31.Name = "CheckBox31"
        Me.CheckBox31.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox31.TabIndex = 327
        Me.CheckBox31.UseVisualStyleBackColor = True
        '
        'Button90
        '
        Me.Button90.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button90.Location = New System.Drawing.Point(442, 94)
        Me.Button90.Name = "Button90"
        Me.Button90.Size = New System.Drawing.Size(62, 23)
        Me.Button90.TabIndex = 385
        Me.Button90.Text = "Write"
        Me.Button90.UseVisualStyleBackColor = True
        '
        'CheckBox30
        '
        Me.CheckBox30.AutoSize = True
        Me.CheckBox30.Location = New System.Drawing.Point(361, 158)
        Me.CheckBox30.Name = "CheckBox30"
        Me.CheckBox30.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox30.TabIndex = 328
        Me.CheckBox30.UseVisualStyleBackColor = True
        '
        'Label76
        '
        Me.Label76.AutoSize = True
        Me.Label76.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label76.Location = New System.Drawing.Point(265, 176)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(31, 9)
        Me.Label76.TabIndex = 384
        Me.Label76.Text = "PEC Er"
        '
        'CheckBox29
        '
        Me.CheckBox29.AutoSize = True
        Me.CheckBox29.Location = New System.Drawing.Point(391, 158)
        Me.CheckBox29.Name = "CheckBox29"
        Me.CheckBox29.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox29.TabIndex = 329
        Me.CheckBox29.UseVisualStyleBackColor = True
        '
        'Label77
        '
        Me.Label77.AutoSize = True
        Me.Label77.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label77.Location = New System.Drawing.Point(230, 175)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(36, 9)
        Me.Label77.TabIndex = 383
        Me.Label77.Text = "US_Data"
        '
        'TextBox20
        '
        Me.TextBox20.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox20.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox20.Location = New System.Drawing.Point(133, 124)
        Me.TextBox20.MaxLength = 2
        Me.TextBox20.Name = "TextBox20"
        Me.TextBox20.ReadOnly = True
        Me.TextBox20.Size = New System.Drawing.Size(27, 23)
        Me.TextBox20.TabIndex = 330
        '
        'Label79
        '
        Me.Label79.AutoSize = True
        Me.Label79.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label79.Location = New System.Drawing.Point(197, 175)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(35, 9)
        Me.Label79.TabIndex = 382
        Me.Label79.Text = "US Cmd"
        '
        'TextBox7
        '
        Me.TextBox7.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.TextBox7.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox7.Location = New System.Drawing.Point(171, 124)
        Me.TextBox7.MaxLength = 2
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.ReadOnly = True
        Me.TextBox7.Size = New System.Drawing.Size(27, 23)
        Me.TextBox7.TabIndex = 331
        '
        'Label80
        '
        Me.Label80.AutoSize = True
        Me.Label80.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label80.Location = New System.Drawing.Point(323, 205)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(35, 9)
        Me.Label80.TabIndex = 381
        Me.Label80.Text = "F1_OVR"
        '
        'CheckBox44
        '
        Me.CheckBox44.AutoSize = True
        Me.CheckBox44.Location = New System.Drawing.Point(421, 128)
        Me.CheckBox44.Name = "CheckBox44"
        Me.CheckBox44.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox44.TabIndex = 332
        Me.CheckBox44.UseVisualStyleBackColor = True
        '
        'Label89
        '
        Me.Label89.AutoSize = True
        Me.Label89.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label89.Location = New System.Drawing.Point(204, 205)
        Me.Label89.Name = "Label89"
        Me.Label89.Size = New System.Drawing.Size(31, 9)
        Me.Label89.TabIndex = 380
        Me.Label89.Text = "F1_Fail"
        '
        'CheckBox43
        '
        Me.CheckBox43.AutoSize = True
        Me.CheckBox43.Location = New System.Drawing.Point(211, 129)
        Me.CheckBox43.Name = "CheckBox43"
        Me.CheckBox43.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox43.TabIndex = 333
        Me.CheckBox43.UseVisualStyleBackColor = True
        '
        'CheckBox42
        '
        Me.CheckBox42.AutoSize = True
        Me.CheckBox42.Checked = True
        Me.CheckBox42.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox42.Location = New System.Drawing.Point(241, 129)
        Me.CheckBox42.Name = "CheckBox42"
        Me.CheckBox42.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox42.TabIndex = 334
        Me.CheckBox42.UseVisualStyleBackColor = True
        '
        'CheckBox41
        '
        Me.CheckBox41.AutoSize = True
        Me.CheckBox41.Location = New System.Drawing.Point(271, 129)
        Me.CheckBox41.Name = "CheckBox41"
        Me.CheckBox41.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox41.TabIndex = 335
        Me.CheckBox41.UseVisualStyleBackColor = True
        '
        'CheckBox40
        '
        Me.CheckBox40.AutoSize = True
        Me.CheckBox40.Location = New System.Drawing.Point(301, 129)
        Me.CheckBox40.Name = "CheckBox40"
        Me.CheckBox40.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox40.TabIndex = 336
        Me.CheckBox40.UseVisualStyleBackColor = True
        '
        'Label95
        '
        Me.Label95.AutoSize = True
        Me.Label95.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label95.Location = New System.Drawing.Point(235, 148)
        Me.Label95.Name = "Label95"
        Me.Label95.Size = New System.Drawing.Size(24, 9)
        Me.Label95.TabIndex = 376
        Me.Label95.Text = "OTW"
        '
        'CheckBox39
        '
        Me.CheckBox39.AutoSize = True
        Me.CheckBox39.Location = New System.Drawing.Point(331, 129)
        Me.CheckBox39.Name = "CheckBox39"
        Me.CheckBox39.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox39.TabIndex = 337
        Me.CheckBox39.UseVisualStyleBackColor = True
        '
        'Label125
        '
        Me.Label125.AutoSize = True
        Me.Label125.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label125.Location = New System.Drawing.Point(207, 148)
        Me.Label125.Name = "Label125"
        Me.Label125.Size = New System.Drawing.Size(21, 9)
        Me.Label125.TabIndex = 375
        Me.Label125.Text = "OTF"
        '
        'CheckBox38
        '
        Me.CheckBox38.AutoSize = True
        Me.CheckBox38.Location = New System.Drawing.Point(361, 129)
        Me.CheckBox38.Name = "CheckBox38"
        Me.CheckBox38.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox38.TabIndex = 338
        Me.CheckBox38.UseVisualStyleBackColor = True
        '
        'Label127
        '
        Me.Label127.AutoSize = True
        Me.Label127.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label127.Location = New System.Drawing.Point(210, 89)
        Me.Label127.Name = "Label127"
        Me.Label127.Size = New System.Drawing.Size(17, 9)
        Me.Label127.TabIndex = 374
        Me.Label127.Text = "OC"
        '
        'CheckBox37
        '
        Me.CheckBox37.AutoSize = True
        Me.CheckBox37.Location = New System.Drawing.Point(391, 129)
        Me.CheckBox37.Name = "CheckBox37"
        Me.CheckBox37.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox37.TabIndex = 339
        Me.CheckBox37.UseVisualStyleBackColor = True
        '
        'Label134
        '
        Me.Label134.AutoSize = True
        Me.Label134.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label134.Location = New System.Drawing.Point(300, 61)
        Me.Label134.Name = "Label134"
        Me.Label134.Size = New System.Drawing.Size(16, 9)
        Me.Label134.TabIndex = 372
        Me.Label134.Text = "UV"
        '
        'TextBox6
        '
        Me.TextBox6.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox6.Location = New System.Drawing.Point(133, 211)
        Me.TextBox6.MaxLength = 2
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.ReadOnly = True
        Me.TextBox6.Size = New System.Drawing.Size(27, 23)
        Me.TextBox6.TabIndex = 340
        '
        'Label135
        '
        Me.Label135.AutoSize = True
        Me.Label135.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label135.Location = New System.Drawing.Point(209, 61)
        Me.Label135.Name = "Label135"
        Me.Label135.Size = New System.Drawing.Size(16, 9)
        Me.Label135.TabIndex = 371
        Me.Label135.Text = "OV"
        '
        'TextBox5
        '
        Me.TextBox5.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.TextBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox5.Location = New System.Drawing.Point(171, 211)
        Me.TextBox5.MaxLength = 2
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.ReadOnly = True
        Me.TextBox5.Size = New System.Drawing.Size(27, 23)
        Me.TextBox5.TabIndex = 341
        '
        'CheckBox61
        '
        Me.CheckBox61.AutoSize = True
        Me.CheckBox61.Location = New System.Drawing.Point(391, 245)
        Me.CheckBox61.Name = "CheckBox61"
        Me.CheckBox61.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox61.TabIndex = 369
        Me.CheckBox61.UseVisualStyleBackColor = True
        '
        'CheckBox52
        '
        Me.CheckBox52.AutoSize = True
        Me.CheckBox52.Location = New System.Drawing.Point(421, 215)
        Me.CheckBox52.Name = "CheckBox52"
        Me.CheckBox52.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox52.TabIndex = 342
        Me.CheckBox52.UseVisualStyleBackColor = True
        '
        'CheckBox62
        '
        Me.CheckBox62.AutoSize = True
        Me.CheckBox62.Location = New System.Drawing.Point(361, 245)
        Me.CheckBox62.Name = "CheckBox62"
        Me.CheckBox62.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox62.TabIndex = 368
        Me.CheckBox62.UseVisualStyleBackColor = True
        '
        'CheckBox51
        '
        Me.CheckBox51.AutoSize = True
        Me.CheckBox51.Location = New System.Drawing.Point(211, 216)
        Me.CheckBox51.Name = "CheckBox51"
        Me.CheckBox51.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox51.TabIndex = 343
        Me.CheckBox51.UseVisualStyleBackColor = True
        '
        'CheckBox63
        '
        Me.CheckBox63.AutoSize = True
        Me.CheckBox63.Location = New System.Drawing.Point(331, 245)
        Me.CheckBox63.Name = "CheckBox63"
        Me.CheckBox63.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox63.TabIndex = 367
        Me.CheckBox63.UseVisualStyleBackColor = True
        '
        'CheckBox50
        '
        Me.CheckBox50.AutoSize = True
        Me.CheckBox50.Location = New System.Drawing.Point(241, 216)
        Me.CheckBox50.Name = "CheckBox50"
        Me.CheckBox50.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox50.TabIndex = 344
        Me.CheckBox50.UseVisualStyleBackColor = True
        '
        'CheckBox64
        '
        Me.CheckBox64.AutoSize = True
        Me.CheckBox64.Location = New System.Drawing.Point(301, 245)
        Me.CheckBox64.Name = "CheckBox64"
        Me.CheckBox64.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox64.TabIndex = 366
        Me.CheckBox64.UseVisualStyleBackColor = True
        '
        'CheckBox49
        '
        Me.CheckBox49.AutoSize = True
        Me.CheckBox49.Location = New System.Drawing.Point(271, 216)
        Me.CheckBox49.Name = "CheckBox49"
        Me.CheckBox49.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox49.TabIndex = 345
        Me.CheckBox49.UseVisualStyleBackColor = True
        '
        'CheckBox65
        '
        Me.CheckBox65.AutoSize = True
        Me.CheckBox65.Location = New System.Drawing.Point(271, 245)
        Me.CheckBox65.Name = "CheckBox65"
        Me.CheckBox65.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox65.TabIndex = 365
        Me.CheckBox65.UseVisualStyleBackColor = True
        '
        'CheckBox48
        '
        Me.CheckBox48.AutoSize = True
        Me.CheckBox48.Location = New System.Drawing.Point(301, 216)
        Me.CheckBox48.Name = "CheckBox48"
        Me.CheckBox48.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox48.TabIndex = 346
        Me.CheckBox48.UseVisualStyleBackColor = True
        '
        'CheckBox66
        '
        Me.CheckBox66.AutoSize = True
        Me.CheckBox66.Location = New System.Drawing.Point(241, 245)
        Me.CheckBox66.Name = "CheckBox66"
        Me.CheckBox66.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox66.TabIndex = 364
        Me.CheckBox66.UseVisualStyleBackColor = True
        '
        'CheckBox47
        '
        Me.CheckBox47.AutoSize = True
        Me.CheckBox47.Checked = True
        Me.CheckBox47.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox47.Location = New System.Drawing.Point(331, 216)
        Me.CheckBox47.Name = "CheckBox47"
        Me.CheckBox47.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox47.TabIndex = 347
        Me.CheckBox47.UseVisualStyleBackColor = True
        '
        'CheckBox67
        '
        Me.CheckBox67.AutoSize = True
        Me.CheckBox67.Location = New System.Drawing.Point(211, 245)
        Me.CheckBox67.Name = "CheckBox67"
        Me.CheckBox67.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox67.TabIndex = 363
        Me.CheckBox67.UseVisualStyleBackColor = True
        '
        'CheckBox46
        '
        Me.CheckBox46.AutoSize = True
        Me.CheckBox46.Location = New System.Drawing.Point(361, 216)
        Me.CheckBox46.Name = "CheckBox46"
        Me.CheckBox46.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox46.TabIndex = 348
        Me.CheckBox46.UseVisualStyleBackColor = True
        '
        'CheckBox68
        '
        Me.CheckBox68.AutoSize = True
        Me.CheckBox68.Location = New System.Drawing.Point(421, 244)
        Me.CheckBox68.Name = "CheckBox68"
        Me.CheckBox68.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox68.TabIndex = 362
        Me.CheckBox68.UseVisualStyleBackColor = True
        '
        'CheckBox45
        '
        Me.CheckBox45.AutoSize = True
        Me.CheckBox45.Location = New System.Drawing.Point(391, 216)
        Me.CheckBox45.Name = "CheckBox45"
        Me.CheckBox45.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox45.TabIndex = 349
        Me.CheckBox45.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(171, 240)
        Me.TextBox1.MaxLength = 2
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.Size = New System.Drawing.Size(27, 23)
        Me.TextBox1.TabIndex = 361
        '
        'TextBox4
        '
        Me.TextBox4.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox4.Location = New System.Drawing.Point(133, 182)
        Me.TextBox4.MaxLength = 2
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.ReadOnly = True
        Me.TextBox4.Size = New System.Drawing.Size(27, 23)
        Me.TextBox4.TabIndex = 350
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.Location = New System.Drawing.Point(133, 240)
        Me.TextBox2.MaxLength = 2
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ReadOnly = True
        Me.TextBox2.Size = New System.Drawing.Size(27, 23)
        Me.TextBox2.TabIndex = 360
        '
        'CheckBox53
        '
        Me.CheckBox53.AutoSize = True
        Me.CheckBox53.Location = New System.Drawing.Point(391, 187)
        Me.CheckBox53.Name = "CheckBox53"
        Me.CheckBox53.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox53.TabIndex = 359
        Me.CheckBox53.UseVisualStyleBackColor = True
        '
        'CheckBox60
        '
        Me.CheckBox60.AutoSize = True
        Me.CheckBox60.Location = New System.Drawing.Point(421, 186)
        Me.CheckBox60.Name = "CheckBox60"
        Me.CheckBox60.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox60.TabIndex = 352
        Me.CheckBox60.UseVisualStyleBackColor = True
        '
        'CheckBox54
        '
        Me.CheckBox54.AutoSize = True
        Me.CheckBox54.Location = New System.Drawing.Point(361, 187)
        Me.CheckBox54.Name = "CheckBox54"
        Me.CheckBox54.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox54.TabIndex = 358
        Me.CheckBox54.UseVisualStyleBackColor = True
        '
        'CheckBox59
        '
        Me.CheckBox59.AutoSize = True
        Me.CheckBox59.Checked = True
        Me.CheckBox59.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox59.Location = New System.Drawing.Point(211, 187)
        Me.CheckBox59.Name = "CheckBox59"
        Me.CheckBox59.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox59.TabIndex = 353
        Me.CheckBox59.UseVisualStyleBackColor = True
        '
        'CheckBox55
        '
        Me.CheckBox55.AutoSize = True
        Me.CheckBox55.Location = New System.Drawing.Point(331, 187)
        Me.CheckBox55.Name = "CheckBox55"
        Me.CheckBox55.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox55.TabIndex = 357
        Me.CheckBox55.UseVisualStyleBackColor = True
        '
        'CheckBox58
        '
        Me.CheckBox58.AutoSize = True
        Me.CheckBox58.Checked = True
        Me.CheckBox58.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox58.Location = New System.Drawing.Point(241, 187)
        Me.CheckBox58.Name = "CheckBox58"
        Me.CheckBox58.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox58.TabIndex = 354
        Me.CheckBox58.UseVisualStyleBackColor = True
        '
        'CheckBox56
        '
        Me.CheckBox56.AutoSize = True
        Me.CheckBox56.Location = New System.Drawing.Point(301, 187)
        Me.CheckBox56.Name = "CheckBox56"
        Me.CheckBox56.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox56.TabIndex = 356
        Me.CheckBox56.UseVisualStyleBackColor = True
        '
        'CheckBox57
        '
        Me.CheckBox57.AutoSize = True
        Me.CheckBox57.Location = New System.Drawing.Point(271, 187)
        Me.CheckBox57.Name = "CheckBox57"
        Me.CheckBox57.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox57.TabIndex = 355
        Me.CheckBox57.UseVisualStyleBackColor = True
        '
        'TabPage11
        '
        Me.TabPage11.BackColor = System.Drawing.Color.AliceBlue
        Me.TabPage11.Controls.Add(Me.Button6)
        Me.TabPage11.Controls.Add(Me.Button11)
        Me.TabPage11.Controls.Add(Me.Button15)
        Me.TabPage11.Controls.Add(Me.GroupBox5)
        Me.TabPage11.Location = New System.Drawing.Point(4, 25)
        Me.TabPage11.Name = "TabPage11"
        Me.TabPage11.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage11.Size = New System.Drawing.Size(601, 483)
        Me.TabPage11.TabIndex = 6
        Me.TabPage11.Text = "SMB_Alert_Mask"
        '
        'Button6
        '
        Me.Button6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.Location = New System.Drawing.Point(207, 364)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(145, 51)
        Me.Button6.TabIndex = 479
        Me.Button6.Text = "Pause Data Capture"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button11.Location = New System.Drawing.Point(370, 364)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(145, 51)
        Me.Button11.TabIndex = 478
        Me.Button11.Text = "Stop Data Capture"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button15
        '
        Me.Button15.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button15.Location = New System.Drawing.Point(43, 364)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(145, 51)
        Me.Button15.TabIndex = 477
        Me.Button15.Text = "Start Data Capture"
        Me.Button15.UseVisualStyleBackColor = True
        '
        'Label236
        '
        Me.Label236.AutoSize = True
        Me.Label236.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label236.Location = New System.Drawing.Point(536, 359)
        Me.Label236.Name = "Label236"
        Me.Label236.Size = New System.Drawing.Size(40, 12)
        Me.Label236.TabIndex = 479
        Me.Label236.Text = "Invalid"
        '
        'Label238
        '
        Me.Label238.AutoSize = True
        Me.Label238.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label238.Location = New System.Drawing.Point(313, 278)
        Me.Label238.Name = "Label238"
        Me.Label238.Size = New System.Drawing.Size(45, 12)
        Me.Label238.TabIndex = 477
        Me.Label238.Text = "F1 OVR"
        '
        'Button17
        '
        Me.Button17.BackColor = System.Drawing.Color.Transparent
        Me.Button17.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button17.Location = New System.Drawing.Point(20, 450)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(105, 26)
        Me.Button17.TabIndex = 472
        Me.Button17.Text = "PSU ON"
        Me.Button17.UseVisualStyleBackColor = False
        '
        'Button16
        '
        Me.Button16.BackColor = System.Drawing.Color.Transparent
        Me.Button16.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button16.Location = New System.Drawing.Point(145, 450)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(105, 26)
        Me.Button16.TabIndex = 473
        Me.Button16.Text = "PSU OFF"
        Me.Button16.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.Transparent
        Me.Button5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.Location = New System.Drawing.Point(294, 448)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(83, 32)
        Me.Button5.TabIndex = 469
        Me.Button5.Text = "Clear Faults"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'Label203
        '
        Me.Label203.AutoSize = True
        Me.Label203.BackColor = System.Drawing.Color.Transparent
        Me.Label203.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.Label203.Location = New System.Drawing.Point(15, 346)
        Me.Label203.Name = "Label203"
        Me.Label203.Size = New System.Drawing.Size(103, 13)
        Me.Label203.TabIndex = 428
        Me.Label203.Text = "STATUS OTHER"
        '
        'PictureBox39
        '
        Me.PictureBox39.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox39.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox39.Location = New System.Drawing.Point(44, 374)
        Me.PictureBox39.Name = "PictureBox39"
        Me.PictureBox39.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox39.TabIndex = 427
        Me.PictureBox39.TabStop = False
        '
        'PictureBox43
        '
        Me.PictureBox43.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox43.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox43.Location = New System.Drawing.Point(332, 374)
        Me.PictureBox43.Name = "PictureBox43"
        Me.PictureBox43.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox43.TabIndex = 426
        Me.PictureBox43.TabStop = False
        '
        'PictureBox47
        '
        Me.PictureBox47.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox47.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox47.Location = New System.Drawing.Point(116, 374)
        Me.PictureBox47.Name = "PictureBox47"
        Me.PictureBox47.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox47.TabIndex = 421
        Me.PictureBox47.TabStop = False
        '
        'PictureBox51
        '
        Me.PictureBox51.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox51.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox51.Location = New System.Drawing.Point(476, 374)
        Me.PictureBox51.Name = "PictureBox51"
        Me.PictureBox51.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox51.TabIndex = 420
        Me.PictureBox51.TabStop = False
        '
        'PictureBox55
        '
        Me.PictureBox55.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox55.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox55.Location = New System.Drawing.Point(188, 374)
        Me.PictureBox55.Name = "PictureBox55"
        Me.PictureBox55.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox55.TabIndex = 425
        Me.PictureBox55.TabStop = False
        '
        'PictureBox59
        '
        Me.PictureBox59.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox59.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox59.Location = New System.Drawing.Point(404, 374)
        Me.PictureBox59.Name = "PictureBox59"
        Me.PictureBox59.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox59.TabIndex = 424
        Me.PictureBox59.TabStop = False
        '
        'PictureBox63
        '
        Me.PictureBox63.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox63.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox63.Location = New System.Drawing.Point(260, 374)
        Me.PictureBox63.Name = "PictureBox63"
        Me.PictureBox63.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox63.TabIndex = 423
        Me.PictureBox63.TabStop = False
        '
        'PictureBox64
        '
        Me.PictureBox64.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox64.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox64.Location = New System.Drawing.Point(548, 374)
        Me.PictureBox64.Name = "PictureBox64"
        Me.PictureBox64.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox64.TabIndex = 422
        Me.PictureBox64.TabStop = False
        '
        'Label98
        '
        Me.Label98.AutoSize = True
        Me.Label98.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label98.Location = New System.Drawing.Point(29, 278)
        Me.Label98.Name = "Label98"
        Me.Label98.Size = New System.Drawing.Size(46, 12)
        Me.Label98.TabIndex = 360
        Me.Label98.Text = "F1 FAIL"
        '
        'Label70
        '
        Me.Label70.AutoSize = True
        Me.Label70.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label70.Location = New System.Drawing.Point(467, 317)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(31, 12)
        Me.Label70.TabIndex = 360
        Me.Label70.Text = "COM"
        '
        'Label182
        '
        Me.Label182.AutoSize = True
        Me.Label182.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label182.Location = New System.Drawing.Point(538, 23)
        Me.Label182.Name = "Label182"
        Me.Label182.Size = New System.Drawing.Size(36, 12)
        Me.Label182.TabIndex = 360
        Me.Label182.Text = "NONE"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label8.Location = New System.Drawing.Point(469, 22)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(29, 12)
        Me.Label8.TabIndex = 360
        Me.Label8.Text = "CML"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label7.Location = New System.Drawing.Point(392, 22)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(35, 12)
        Me.Label7.TabIndex = 360
        Me.Label7.Text = "TEMP"
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label55.Location = New System.Drawing.Point(462, 66)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(42, 12)
        Me.Label55.TabIndex = 360
        Me.Label55.Text = "OTHER"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label15.Location = New System.Drawing.Point(327, 65)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(26, 12)
        Me.Label15.TabIndex = 360
        Me.Label15.Text = "#PG"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label6.Location = New System.Drawing.Point(318, 22)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(47, 12)
        Me.Label6.TabIndex = 360
        Me.Label6.Text = "VIN_UV"
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label58.Location = New System.Drawing.Point(168, 317)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(53, 12)
        Me.Label58.TabIndex = 360
        Me.Label58.Text = "INV_PEC"
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label56.Location = New System.Drawing.Point(240, 193)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(51, 12)
        Me.Label56.TabIndex = 360
        Me.Label56.Text = "VIN UVF"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label5.Location = New System.Drawing.Point(240, 22)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(53, 12)
        Me.Label5.TabIndex = 360
        Me.Label5.Text = "IOUT_OC"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label34.Location = New System.Drawing.Point(180, 150)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(31, 12)
        Me.Label34.TabIndex = 360
        Me.Label34.Text = "OCW"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label22.Location = New System.Drawing.Point(255, 109)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(28, 12)
        Me.Label22.TabIndex = 360
        Me.Label22.Text = "UVP"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label13.Location = New System.Drawing.Point(175, 65)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(38, 12)
        Me.Label13.TabIndex = 360
        Me.Label13.Text = "INPUT"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label4.Location = New System.Drawing.Point(168, 22)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(57, 12)
        Me.Label4.TabIndex = 360
        Me.Label4.Text = "VOUT_OV"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label33.Location = New System.Drawing.Point(98, 150)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(48, 12)
        Me.Label33.TabIndex = 360
        Me.Label33.Text = "OCP_LV"
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label50.Location = New System.Drawing.Point(96, 317)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(61, 12)
        Me.Label50.TabIndex = 360
        Me.Label50.Text = "INV_DATA"
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label49.Location = New System.Drawing.Point(109, 237)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(29, 12)
        Me.Label49.TabIndex = 360
        Me.Label49.Text = "OTW"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label12.Location = New System.Drawing.Point(96, 65)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(64, 12)
        Me.Label12.TabIndex = 360
        Me.Label12.Text = "IOUT/POUT"
        '
        'Label167
        '
        Me.Label167.AutoSize = True
        Me.Label167.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label167.Location = New System.Drawing.Point(24, 193)
        Me.Label167.Name = "Label167"
        Me.Label167.Size = New System.Drawing.Size(51, 12)
        Me.Label167.TabIndex = 360
        Me.Label167.Text = "VIN OVF"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label48.Location = New System.Drawing.Point(96, 193)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(54, 12)
        Me.Label48.TabIndex = 360
        Me.Label48.Text = "VIN OVW"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label9.Location = New System.Drawing.Point(109, 22)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(27, 12)
        Me.Label9.TabIndex = 360
        Me.Label9.Text = "OFF"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label31.Location = New System.Drawing.Point(39, 150)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(28, 12)
        Me.Label31.TabIndex = 360
        Me.Label31.Text = "OCP"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label46.Location = New System.Drawing.Point(27, 317)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(57, 12)
        Me.Label46.TabIndex = 360
        Me.Label46.Text = "INV_CMD"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label20.Location = New System.Drawing.Point(39, 109)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(28, 12)
        Me.Label20.TabIndex = 360
        Me.Label20.Text = "OVP"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label45.Location = New System.Drawing.Point(39, 237)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(26, 12)
        Me.Label45.TabIndex = 360
        Me.Label45.Text = "OTP"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label11.Location = New System.Drawing.Point(34, 65)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(35, 12)
        Me.Label11.TabIndex = 360
        Me.Label11.Text = "VOUT"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label32.Location = New System.Drawing.Point(34, 22)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(33, 12)
        Me.Label32.TabIndex = 360
        Me.Label32.Text = "BUSY"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.BackColor = System.Drawing.Color.Transparent
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.Label28.Location = New System.Drawing.Point(12, 136)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(90, 13)
        Me.Label28.TabIndex = 359
        Me.Label28.Text = "STATUS IOUT"
        '
        'Label93
        '
        Me.Label93.AutoSize = True
        Me.Label93.BackColor = System.Drawing.Color.Transparent
        Me.Label93.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.Label93.Location = New System.Drawing.Point(12, 262)
        Me.Label93.Name = "Label93"
        Me.Label93.Size = New System.Drawing.Size(115, 13)
        Me.Label93.TabIndex = 359
        Me.Label93.Text = "STATUS Fans_1_2"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.BackColor = System.Drawing.Color.Transparent
        Me.Label42.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.Label42.Location = New System.Drawing.Point(12, 304)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(85, 13)
        Me.Label42.TabIndex = 359
        Me.Label42.Text = "STATUS CML"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.Label10.Location = New System.Drawing.Point(12, 50)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(137, 13)
        Me.Label10.TabIndex = 359
        Me.Label10.Text = "STATUS WORD (MSB)"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.BackColor = System.Drawing.Color.Transparent
        Me.Label40.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.Label40.Location = New System.Drawing.Point(12, 178)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(98, 13)
        Me.Label40.TabIndex = 359
        Me.Label40.Text = "STATUS INPUT"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.BackColor = System.Drawing.Color.Transparent
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.Label19.Location = New System.Drawing.Point(12, 94)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(94, 13)
        Me.Label19.TabIndex = 359
        Me.Label19.Text = "STATUS VOUT"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.BackColor = System.Drawing.Color.Transparent
        Me.Label41.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.Label41.Location = New System.Drawing.Point(12, 222)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(153, 13)
        Me.Label41.TabIndex = 359
        Me.Label41.Text = "STATUS TEMPERATURE"
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.FloralWhite
        Me.TabPage1.Controls.Add(Me.TabControl2)
        Me.TabPage1.Controls.Add(Me.DataGridView1)
        Me.TabPage1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPage1.Location = New System.Drawing.Point(4, 32)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1045, 524)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "PMBus Data"
        '
        'TabControl2
        '
        Me.TabControl2.Appearance = System.Windows.Forms.TabAppearance.Buttons
        Me.TabControl2.Controls.Add(Me.TabPage6)
        Me.TabControl2.Controls.Add(Me.TabPage7)
        Me.TabControl2.Controls.Add(Me.TabPage9)
        Me.TabControl2.Controls.Add(Me.TabPage11)
        Me.TabControl2.Controls.Add(Me.TabPage19)
        Me.TabControl2.Location = New System.Drawing.Point(436, 6)
        Me.TabControl2.Name = "TabControl2"
        Me.TabControl2.SelectedIndex = 0
        Me.TabControl2.Size = New System.Drawing.Size(609, 512)
        Me.TabControl2.TabIndex = 47
        '
        'TabPage6
        '
        Me.TabPage6.BackColor = System.Drawing.Color.AliceBlue
        Me.TabPage6.Controls.Add(Me.Label87)
        Me.TabPage6.Controls.Add(Me.Label60)
        Me.TabPage6.Controls.Add(Me.Label52)
        Me.TabPage6.Controls.Add(Me.Label23)
        Me.TabPage6.Controls.Add(Me.Label21)
        Me.TabPage6.Controls.Add(Me.Label419)
        Me.TabPage6.Controls.Add(Me.Label418)
        Me.TabPage6.Controls.Add(Me.Label417)
        Me.TabPage6.Controls.Add(Me.Label236)
        Me.TabPage6.Controls.Add(Me.Label238)
        Me.TabPage6.Controls.Add(Me.Button17)
        Me.TabPage6.Controls.Add(Me.Button16)
        Me.TabPage6.Controls.Add(Me.Label85)
        Me.TabPage6.Controls.Add(Me.Label43)
        Me.TabPage6.Controls.Add(Me.Button5)
        Me.TabPage6.Controls.Add(Me.Label198)
        Me.TabPage6.Controls.Add(Me.PictureBox169)
        Me.TabPage6.Controls.Add(Me.PictureBox170)
        Me.TabPage6.Controls.Add(Me.PictureBox171)
        Me.TabPage6.Controls.Add(Me.PictureBox172)
        Me.TabPage6.Controls.Add(Me.PictureBox173)
        Me.TabPage6.Controls.Add(Me.PictureBox174)
        Me.TabPage6.Controls.Add(Me.PictureBox175)
        Me.TabPage6.Controls.Add(Me.PictureBox176)
        Me.TabPage6.Controls.Add(Me.Label203)
        Me.TabPage6.Controls.Add(Me.PictureBox39)
        Me.TabPage6.Controls.Add(Me.PictureBox43)
        Me.TabPage6.Controls.Add(Me.PictureBox47)
        Me.TabPage6.Controls.Add(Me.PictureBox51)
        Me.TabPage6.Controls.Add(Me.PictureBox55)
        Me.TabPage6.Controls.Add(Me.PictureBox59)
        Me.TabPage6.Controls.Add(Me.PictureBox63)
        Me.TabPage6.Controls.Add(Me.PictureBox64)
        Me.TabPage6.Controls.Add(Me.Label98)
        Me.TabPage6.Controls.Add(Me.Label61)
        Me.TabPage6.Controls.Add(Me.Label70)
        Me.TabPage6.Controls.Add(Me.Label182)
        Me.TabPage6.Controls.Add(Me.Label8)
        Me.TabPage6.Controls.Add(Me.Label7)
        Me.TabPage6.Controls.Add(Me.Label55)
        Me.TabPage6.Controls.Add(Me.Label15)
        Me.TabPage6.Controls.Add(Me.Label6)
        Me.TabPage6.Controls.Add(Me.Label58)
        Me.TabPage6.Controls.Add(Me.Label56)
        Me.TabPage6.Controls.Add(Me.Label5)
        Me.TabPage6.Controls.Add(Me.Label34)
        Me.TabPage6.Controls.Add(Me.Label22)
        Me.TabPage6.Controls.Add(Me.Label13)
        Me.TabPage6.Controls.Add(Me.Label4)
        Me.TabPage6.Controls.Add(Me.Label33)
        Me.TabPage6.Controls.Add(Me.Label50)
        Me.TabPage6.Controls.Add(Me.Label49)
        Me.TabPage6.Controls.Add(Me.Label12)
        Me.TabPage6.Controls.Add(Me.Label167)
        Me.TabPage6.Controls.Add(Me.Label48)
        Me.TabPage6.Controls.Add(Me.Label9)
        Me.TabPage6.Controls.Add(Me.Label31)
        Me.TabPage6.Controls.Add(Me.Label46)
        Me.TabPage6.Controls.Add(Me.Label20)
        Me.TabPage6.Controls.Add(Me.Label45)
        Me.TabPage6.Controls.Add(Me.Label11)
        Me.TabPage6.Controls.Add(Me.Label32)
        Me.TabPage6.Controls.Add(Me.Label28)
        Me.TabPage6.Controls.Add(Me.Label93)
        Me.TabPage6.Controls.Add(Me.Label42)
        Me.TabPage6.Controls.Add(Me.Label19)
        Me.TabPage6.Controls.Add(Me.Label41)
        Me.TabPage6.Controls.Add(Me.Label10)
        Me.TabPage6.Controls.Add(Me.Label40)
        Me.TabPage6.Controls.Add(Me.Label177)
        Me.TabPage6.Controls.Add(Me.PictureBox32)
        Me.TabPage6.Controls.Add(Me.PictureBox168)
        Me.TabPage6.Controls.Add(Me.PictureBox62)
        Me.TabPage6.Controls.Add(Me.PictureBox31)
        Me.TabPage6.Controls.Add(Me.PictureBox167)
        Me.TabPage6.Controls.Add(Me.PictureBox61)
        Me.TabPage6.Controls.Add(Me.PictureBox24)
        Me.TabPage6.Controls.Add(Me.PictureBox60)
        Me.TabPage6.Controls.Add(Me.PictureBox23)
        Me.TabPage6.Controls.Add(Me.PictureBox16)
        Me.TabPage6.Controls.Add(Me.PictureBox58)
        Me.TabPage6.Controls.Add(Me.PictureBox30)
        Me.TabPage6.Controls.Add(Me.PictureBox166)
        Me.TabPage6.Controls.Add(Me.PictureBox57)
        Me.TabPage6.Controls.Add(Me.PictureBox15)
        Me.TabPage6.Controls.Add(Me.PictureBox56)
        Me.TabPage6.Controls.Add(Me.PictureBox22)
        Me.TabPage6.Controls.Add(Me.PictureBox8)
        Me.TabPage6.Controls.Add(Me.PictureBox54)
        Me.TabPage6.Controls.Add(Me.PictureBox29)
        Me.TabPage6.Controls.Add(Me.PictureBox165)
        Me.TabPage6.Controls.Add(Me.PictureBox53)
        Me.TabPage6.Controls.Add(Me.PictureBox14)
        Me.TabPage6.Controls.Add(Me.PictureBox52)
        Me.TabPage6.Controls.Add(Me.PictureBox21)
        Me.TabPage6.Controls.Add(Me.PictureBox4)
        Me.TabPage6.Controls.Add(Me.PictureBox50)
        Me.TabPage6.Controls.Add(Me.PictureBox28)
        Me.TabPage6.Controls.Add(Me.PictureBox164)
        Me.TabPage6.Controls.Add(Me.PictureBox49)
        Me.TabPage6.Controls.Add(Me.PictureBox13)
        Me.TabPage6.Controls.Add(Me.PictureBox48)
        Me.TabPage6.Controls.Add(Me.PictureBox20)
        Me.TabPage6.Controls.Add(Me.PictureBox7)
        Me.TabPage6.Controls.Add(Me.PictureBox46)
        Me.TabPage6.Controls.Add(Me.PictureBox27)
        Me.TabPage6.Controls.Add(Me.PictureBox163)
        Me.TabPage6.Controls.Add(Me.PictureBox45)
        Me.TabPage6.Controls.Add(Me.PictureBox12)
        Me.TabPage6.Controls.Add(Me.PictureBox44)
        Me.TabPage6.Controls.Add(Me.PictureBox19)
        Me.TabPage6.Controls.Add(Me.PictureBox2)
        Me.TabPage6.Controls.Add(Me.PictureBox42)
        Me.TabPage6.Controls.Add(Me.PictureBox26)
        Me.TabPage6.Controls.Add(Me.PictureBox162)
        Me.TabPage6.Controls.Add(Me.PictureBox41)
        Me.TabPage6.Controls.Add(Me.PictureBox11)
        Me.TabPage6.Controls.Add(Me.PictureBox40)
        Me.TabPage6.Controls.Add(Me.PictureBox18)
        Me.TabPage6.Controls.Add(Me.PictureBox6)
        Me.TabPage6.Controls.Add(Me.PictureBox38)
        Me.TabPage6.Controls.Add(Me.PictureBox25)
        Me.TabPage6.Controls.Add(Me.PictureBox161)
        Me.TabPage6.Controls.Add(Me.PictureBox37)
        Me.TabPage6.Controls.Add(Me.PictureBox10)
        Me.TabPage6.Controls.Add(Me.PictureBox36)
        Me.TabPage6.Controls.Add(Me.PictureBox17)
        Me.TabPage6.Controls.Add(Me.PictureBox35)
        Me.TabPage6.Controls.Add(Me.PictureBox3)
        Me.TabPage6.Controls.Add(Me.PictureBox34)
        Me.TabPage6.Controls.Add(Me.PictureBox9)
        Me.TabPage6.Controls.Add(Me.PictureBox33)
        Me.TabPage6.Controls.Add(Me.PictureBox5)
        Me.TabPage6.Controls.Add(Me.PictureBox1)
        Me.TabPage6.Location = New System.Drawing.Point(4, 25)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(601, 483)
        Me.TabPage6.TabIndex = 0
        Me.TabPage6.Text = "PMBus Status"
        '
        'Label87
        '
        Me.Label87.AutoSize = True
        Me.Label87.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label87.Location = New System.Drawing.Point(534, 398)
        Me.Label87.Name = "Label87"
        Me.Label87.Size = New System.Drawing.Size(52, 12)
        Me.Label87.TabIndex = 490
        Me.Label87.Text = "VSB_FLT"
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label60.Location = New System.Drawing.Point(448, 359)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(79, 12)
        Me.Label60.TabIndex = 489
        Me.Label60.Text = "ORING FAULT"
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label52.Location = New System.Drawing.Point(538, 317)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(32, 12)
        Me.Label52.TabIndex = 488
        Me.Label52.Text = "MEM"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label23.Location = New System.Drawing.Point(302, 317)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(81, 12)
        Me.Label23.TabIndex = 487
        Me.Label23.Text = "PRCSR FAULT"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label21.Location = New System.Drawing.Point(308, 150)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(76, 12)
        Me.Label21.TabIndex = 486
        Me.Label21.Text = "ISHARE Fault"
        '
        'Label419
        '
        Me.Label419.AutoSize = True
        Me.Label419.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label419.Location = New System.Drawing.Point(529, 65)
        Me.Label419.Name = "Label419"
        Me.Label419.Size = New System.Drawing.Size(54, 12)
        Me.Label419.TabIndex = 485
        Me.Label419.Text = "UNKOWN"
        '
        'Label418
        '
        Me.Label418.AutoSize = True
        Me.Label418.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label418.Location = New System.Drawing.Point(396, 65)
        Me.Label418.Name = "Label418"
        Me.Label418.Size = New System.Drawing.Size(28, 12)
        Me.Label418.TabIndex = 484
        Me.Label418.Text = "FAN"
        '
        'Label417
        '
        Me.Label417.AutoSize = True
        Me.Label417.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label417.Location = New System.Drawing.Point(251, 65)
        Me.Label417.Name = "Label417"
        Me.Label417.Size = New System.Drawing.Size(30, 12)
        Me.Label417.TabIndex = 483
        Me.Label417.Text = "MFR"
        '
        'Label85
        '
        Me.Label85.AutoSize = True
        Me.Label85.BackColor = System.Drawing.Color.Transparent
        Me.Label85.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label85.Location = New System.Drawing.Point(50, 430)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(175, 13)
        Me.Label85.TabIndex = 471
        Me.Label85.Text = "OPERATION COMMAND(01h)"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.BackColor = System.Drawing.Color.Transparent
        Me.Label43.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.Location = New System.Drawing.Point(281, 430)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(103, 13)
        Me.Label43.TabIndex = 470
        Me.Label43.Text = "Clear Faults(03h)"
        '
        'Label198
        '
        Me.Label198.AutoSize = True
        Me.Label198.BackColor = System.Drawing.Color.Transparent
        Me.Label198.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.Label198.Location = New System.Drawing.Point(15, 386)
        Me.Label198.Name = "Label198"
        Me.Label198.Size = New System.Drawing.Size(86, 13)
        Me.Label198.TabIndex = 437
        Me.Label198.Text = "STATUS MFR"
        '
        'PictureBox169
        '
        Me.PictureBox169.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox169.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox169.Location = New System.Drawing.Point(45, 413)
        Me.PictureBox169.Name = "PictureBox169"
        Me.PictureBox169.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox169.TabIndex = 436
        Me.PictureBox169.TabStop = False
        '
        'PictureBox170
        '
        Me.PictureBox170.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox170.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox170.Location = New System.Drawing.Point(333, 413)
        Me.PictureBox170.Name = "PictureBox170"
        Me.PictureBox170.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox170.TabIndex = 435
        Me.PictureBox170.TabStop = False
        '
        'PictureBox171
        '
        Me.PictureBox171.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox171.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox171.Location = New System.Drawing.Point(117, 413)
        Me.PictureBox171.Name = "PictureBox171"
        Me.PictureBox171.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox171.TabIndex = 430
        Me.PictureBox171.TabStop = False
        '
        'PictureBox172
        '
        Me.PictureBox172.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox172.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox172.Location = New System.Drawing.Point(477, 413)
        Me.PictureBox172.Name = "PictureBox172"
        Me.PictureBox172.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox172.TabIndex = 429
        Me.PictureBox172.TabStop = False
        '
        'PictureBox173
        '
        Me.PictureBox173.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox173.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox173.Location = New System.Drawing.Point(189, 413)
        Me.PictureBox173.Name = "PictureBox173"
        Me.PictureBox173.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox173.TabIndex = 434
        Me.PictureBox173.TabStop = False
        '
        'PictureBox174
        '
        Me.PictureBox174.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox174.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox174.Location = New System.Drawing.Point(405, 413)
        Me.PictureBox174.Name = "PictureBox174"
        Me.PictureBox174.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox174.TabIndex = 433
        Me.PictureBox174.TabStop = False
        '
        'PictureBox175
        '
        Me.PictureBox175.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox175.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox175.Location = New System.Drawing.Point(261, 413)
        Me.PictureBox175.Name = "PictureBox175"
        Me.PictureBox175.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox175.TabIndex = 432
        Me.PictureBox175.TabStop = False
        '
        'PictureBox176
        '
        Me.PictureBox176.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox176.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox176.Location = New System.Drawing.Point(549, 413)
        Me.PictureBox176.Name = "PictureBox176"
        Me.PictureBox176.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox176.TabIndex = 431
        Me.PictureBox176.TabStop = False
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold)
        Me.Label61.Location = New System.Drawing.Point(176, 409)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(0, 13)
        Me.Label61.TabIndex = 360
        Me.Label61.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label177
        '
        Me.Label177.AutoSize = True
        Me.Label177.BackColor = System.Drawing.Color.Transparent
        Me.Label177.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.Label177.Location = New System.Drawing.Point(12, 7)
        Me.Label177.Name = "Label177"
        Me.Label177.Size = New System.Drawing.Size(92, 13)
        Me.Label177.TabIndex = 359
        Me.Label177.Text = "STATUS BYTE"
        '
        'PictureBox32
        '
        Me.PictureBox32.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox32.Location = New System.Drawing.Point(41, 165)
        Me.PictureBox32.Name = "PictureBox32"
        Me.PictureBox32.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox32.TabIndex = 0
        Me.PictureBox32.TabStop = False
        '
        'PictureBox168
        '
        Me.PictureBox168.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox168.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox168.Location = New System.Drawing.Point(41, 291)
        Me.PictureBox168.Name = "PictureBox168"
        Me.PictureBox168.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox168.TabIndex = 0
        Me.PictureBox168.TabStop = False
        '
        'PictureBox62
        '
        Me.PictureBox62.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox62.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox62.Location = New System.Drawing.Point(41, 332)
        Me.PictureBox62.Name = "PictureBox62"
        Me.PictureBox62.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox62.TabIndex = 0
        Me.PictureBox62.TabStop = False
        '
        'PictureBox31
        '
        Me.PictureBox31.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox31.Location = New System.Drawing.Point(329, 165)
        Me.PictureBox31.Name = "PictureBox31"
        Me.PictureBox31.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox31.TabIndex = 0
        Me.PictureBox31.TabStop = False
        '
        'PictureBox167
        '
        Me.PictureBox167.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox167.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox167.Location = New System.Drawing.Point(329, 291)
        Me.PictureBox167.Name = "PictureBox167"
        Me.PictureBox167.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox167.TabIndex = 0
        Me.PictureBox167.TabStop = False
        '
        'PictureBox61
        '
        Me.PictureBox61.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox61.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox61.Location = New System.Drawing.Point(329, 332)
        Me.PictureBox61.Name = "PictureBox61"
        Me.PictureBox61.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox61.TabIndex = 0
        Me.PictureBox61.TabStop = False
        '
        'PictureBox24
        '
        Me.PictureBox24.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox24.Location = New System.Drawing.Point(41, 124)
        Me.PictureBox24.Name = "PictureBox24"
        Me.PictureBox24.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox24.TabIndex = 0
        Me.PictureBox24.TabStop = False
        '
        'PictureBox60
        '
        Me.PictureBox60.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox60.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox60.Location = New System.Drawing.Point(41, 252)
        Me.PictureBox60.Name = "PictureBox60"
        Me.PictureBox60.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox60.TabIndex = 0
        Me.PictureBox60.TabStop = False
        '
        'PictureBox23
        '
        Me.PictureBox23.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox23.Location = New System.Drawing.Point(329, 124)
        Me.PictureBox23.Name = "PictureBox23"
        Me.PictureBox23.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox23.TabIndex = 0
        Me.PictureBox23.TabStop = False
        '
        'PictureBox16
        '
        Me.PictureBox16.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox16.Location = New System.Drawing.Point(41, 80)
        Me.PictureBox16.Name = "PictureBox16"
        Me.PictureBox16.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox16.TabIndex = 0
        Me.PictureBox16.TabStop = False
        '
        'PictureBox58
        '
        Me.PictureBox58.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox58.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox58.Location = New System.Drawing.Point(329, 252)
        Me.PictureBox58.Name = "PictureBox58"
        Me.PictureBox58.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox58.TabIndex = 0
        Me.PictureBox58.TabStop = False
        '
        'PictureBox30
        '
        Me.PictureBox30.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox30.Location = New System.Drawing.Point(113, 165)
        Me.PictureBox30.Name = "PictureBox30"
        Me.PictureBox30.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox30.TabIndex = 0
        Me.PictureBox30.TabStop = False
        '
        'PictureBox166
        '
        Me.PictureBox166.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox166.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox166.Location = New System.Drawing.Point(113, 291)
        Me.PictureBox166.Name = "PictureBox166"
        Me.PictureBox166.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox166.TabIndex = 0
        Me.PictureBox166.TabStop = False
        '
        'PictureBox57
        '
        Me.PictureBox57.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox57.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox57.Location = New System.Drawing.Point(113, 332)
        Me.PictureBox57.Name = "PictureBox57"
        Me.PictureBox57.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox57.TabIndex = 0
        Me.PictureBox57.TabStop = False
        '
        'PictureBox15
        '
        Me.PictureBox15.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox15.Location = New System.Drawing.Point(329, 80)
        Me.PictureBox15.Name = "PictureBox15"
        Me.PictureBox15.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox15.TabIndex = 0
        Me.PictureBox15.TabStop = False
        '
        'PictureBox56
        '
        Me.PictureBox56.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox56.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox56.Location = New System.Drawing.Point(41, 208)
        Me.PictureBox56.Name = "PictureBox56"
        Me.PictureBox56.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox56.TabIndex = 0
        Me.PictureBox56.TabStop = False
        '
        'PictureBox22
        '
        Me.PictureBox22.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox22.Location = New System.Drawing.Point(113, 124)
        Me.PictureBox22.Name = "PictureBox22"
        Me.PictureBox22.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox22.TabIndex = 0
        Me.PictureBox22.TabStop = False
        '
        'PictureBox8
        '
        Me.PictureBox8.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox8.Location = New System.Drawing.Point(41, 37)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox8.TabIndex = 0
        Me.PictureBox8.TabStop = False
        '
        'PictureBox54
        '
        Me.PictureBox54.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox54.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox54.Location = New System.Drawing.Point(113, 252)
        Me.PictureBox54.Name = "PictureBox54"
        Me.PictureBox54.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox54.TabIndex = 0
        Me.PictureBox54.TabStop = False
        '
        'PictureBox29
        '
        Me.PictureBox29.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox29.Location = New System.Drawing.Point(473, 165)
        Me.PictureBox29.Name = "PictureBox29"
        Me.PictureBox29.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox29.TabIndex = 0
        Me.PictureBox29.TabStop = False
        '
        'PictureBox165
        '
        Me.PictureBox165.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox165.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox165.Location = New System.Drawing.Point(473, 291)
        Me.PictureBox165.Name = "PictureBox165"
        Me.PictureBox165.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox165.TabIndex = 0
        Me.PictureBox165.TabStop = False
        '
        'PictureBox53
        '
        Me.PictureBox53.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox53.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox53.Location = New System.Drawing.Point(473, 332)
        Me.PictureBox53.Name = "PictureBox53"
        Me.PictureBox53.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox53.TabIndex = 0
        Me.PictureBox53.TabStop = False
        '
        'PictureBox14
        '
        Me.PictureBox14.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox14.Location = New System.Drawing.Point(113, 80)
        Me.PictureBox14.Name = "PictureBox14"
        Me.PictureBox14.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox14.TabIndex = 0
        Me.PictureBox14.TabStop = False
        '
        'PictureBox52
        '
        Me.PictureBox52.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox52.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox52.Location = New System.Drawing.Point(329, 208)
        Me.PictureBox52.Name = "PictureBox52"
        Me.PictureBox52.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox52.TabIndex = 0
        Me.PictureBox52.TabStop = False
        '
        'PictureBox21
        '
        Me.PictureBox21.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox21.Location = New System.Drawing.Point(473, 124)
        Me.PictureBox21.Name = "PictureBox21"
        Me.PictureBox21.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox21.TabIndex = 0
        Me.PictureBox21.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox4.Location = New System.Drawing.Point(329, 37)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox4.TabIndex = 0
        Me.PictureBox4.TabStop = False
        '
        'PictureBox50
        '
        Me.PictureBox50.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox50.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox50.Location = New System.Drawing.Point(473, 252)
        Me.PictureBox50.Name = "PictureBox50"
        Me.PictureBox50.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox50.TabIndex = 0
        Me.PictureBox50.TabStop = False
        '
        'PictureBox28
        '
        Me.PictureBox28.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox28.Location = New System.Drawing.Point(185, 165)
        Me.PictureBox28.Name = "PictureBox28"
        Me.PictureBox28.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox28.TabIndex = 0
        Me.PictureBox28.TabStop = False
        '
        'PictureBox164
        '
        Me.PictureBox164.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox164.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox164.Location = New System.Drawing.Point(185, 291)
        Me.PictureBox164.Name = "PictureBox164"
        Me.PictureBox164.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox164.TabIndex = 0
        Me.PictureBox164.TabStop = False
        '
        'PictureBox49
        '
        Me.PictureBox49.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox49.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox49.Location = New System.Drawing.Point(185, 332)
        Me.PictureBox49.Name = "PictureBox49"
        Me.PictureBox49.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox49.TabIndex = 0
        Me.PictureBox49.TabStop = False
        '
        'PictureBox13
        '
        Me.PictureBox13.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox13.Location = New System.Drawing.Point(473, 80)
        Me.PictureBox13.Name = "PictureBox13"
        Me.PictureBox13.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox13.TabIndex = 0
        Me.PictureBox13.TabStop = False
        '
        'PictureBox48
        '
        Me.PictureBox48.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox48.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox48.Location = New System.Drawing.Point(113, 208)
        Me.PictureBox48.Name = "PictureBox48"
        Me.PictureBox48.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox48.TabIndex = 0
        Me.PictureBox48.TabStop = False
        '
        'PictureBox20
        '
        Me.PictureBox20.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox20.Location = New System.Drawing.Point(185, 124)
        Me.PictureBox20.Name = "PictureBox20"
        Me.PictureBox20.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox20.TabIndex = 0
        Me.PictureBox20.TabStop = False
        '
        'PictureBox7
        '
        Me.PictureBox7.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox7.Location = New System.Drawing.Point(113, 37)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox7.TabIndex = 0
        Me.PictureBox7.TabStop = False
        '
        'PictureBox46
        '
        Me.PictureBox46.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox46.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox46.Location = New System.Drawing.Point(185, 252)
        Me.PictureBox46.Name = "PictureBox46"
        Me.PictureBox46.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox46.TabIndex = 0
        Me.PictureBox46.TabStop = False
        '
        'PictureBox27
        '
        Me.PictureBox27.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox27.Location = New System.Drawing.Point(401, 165)
        Me.PictureBox27.Name = "PictureBox27"
        Me.PictureBox27.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox27.TabIndex = 0
        Me.PictureBox27.TabStop = False
        '
        'PictureBox163
        '
        Me.PictureBox163.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox163.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox163.Location = New System.Drawing.Point(401, 291)
        Me.PictureBox163.Name = "PictureBox163"
        Me.PictureBox163.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox163.TabIndex = 0
        Me.PictureBox163.TabStop = False
        '
        'PictureBox45
        '
        Me.PictureBox45.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox45.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox45.Location = New System.Drawing.Point(401, 332)
        Me.PictureBox45.Name = "PictureBox45"
        Me.PictureBox45.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox45.TabIndex = 0
        Me.PictureBox45.TabStop = False
        '
        'PictureBox12
        '
        Me.PictureBox12.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox12.Location = New System.Drawing.Point(185, 80)
        Me.PictureBox12.Name = "PictureBox12"
        Me.PictureBox12.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox12.TabIndex = 0
        Me.PictureBox12.TabStop = False
        '
        'PictureBox44
        '
        Me.PictureBox44.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox44.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox44.Location = New System.Drawing.Point(473, 208)
        Me.PictureBox44.Name = "PictureBox44"
        Me.PictureBox44.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox44.TabIndex = 0
        Me.PictureBox44.TabStop = False
        '
        'PictureBox19
        '
        Me.PictureBox19.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox19.Location = New System.Drawing.Point(401, 124)
        Me.PictureBox19.Name = "PictureBox19"
        Me.PictureBox19.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox19.TabIndex = 0
        Me.PictureBox19.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox2.Location = New System.Drawing.Point(473, 37)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox2.TabIndex = 0
        Me.PictureBox2.TabStop = False
        '
        'PictureBox42
        '
        Me.PictureBox42.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox42.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox42.Location = New System.Drawing.Point(401, 252)
        Me.PictureBox42.Name = "PictureBox42"
        Me.PictureBox42.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox42.TabIndex = 0
        Me.PictureBox42.TabStop = False
        '
        'PictureBox26
        '
        Me.PictureBox26.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox26.Location = New System.Drawing.Point(257, 165)
        Me.PictureBox26.Name = "PictureBox26"
        Me.PictureBox26.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox26.TabIndex = 0
        Me.PictureBox26.TabStop = False
        '
        'PictureBox162
        '
        Me.PictureBox162.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox162.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox162.Location = New System.Drawing.Point(257, 291)
        Me.PictureBox162.Name = "PictureBox162"
        Me.PictureBox162.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox162.TabIndex = 0
        Me.PictureBox162.TabStop = False
        '
        'PictureBox41
        '
        Me.PictureBox41.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox41.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox41.Location = New System.Drawing.Point(257, 332)
        Me.PictureBox41.Name = "PictureBox41"
        Me.PictureBox41.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox41.TabIndex = 0
        Me.PictureBox41.TabStop = False
        '
        'PictureBox11
        '
        Me.PictureBox11.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox11.Location = New System.Drawing.Point(401, 80)
        Me.PictureBox11.Name = "PictureBox11"
        Me.PictureBox11.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox11.TabIndex = 0
        Me.PictureBox11.TabStop = False
        '
        'PictureBox40
        '
        Me.PictureBox40.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox40.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox40.Location = New System.Drawing.Point(185, 208)
        Me.PictureBox40.Name = "PictureBox40"
        Me.PictureBox40.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox40.TabIndex = 0
        Me.PictureBox40.TabStop = False
        '
        'PictureBox18
        '
        Me.PictureBox18.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox18.Location = New System.Drawing.Point(257, 124)
        Me.PictureBox18.Name = "PictureBox18"
        Me.PictureBox18.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox18.TabIndex = 0
        Me.PictureBox18.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox6.Location = New System.Drawing.Point(185, 37)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox6.TabIndex = 0
        Me.PictureBox6.TabStop = False
        '
        'PictureBox38
        '
        Me.PictureBox38.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox38.Location = New System.Drawing.Point(257, 252)
        Me.PictureBox38.Name = "PictureBox38"
        Me.PictureBox38.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox38.TabIndex = 0
        Me.PictureBox38.TabStop = False
        '
        'PictureBox25
        '
        Me.PictureBox25.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox25.Location = New System.Drawing.Point(545, 165)
        Me.PictureBox25.Name = "PictureBox25"
        Me.PictureBox25.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox25.TabIndex = 0
        Me.PictureBox25.TabStop = False
        '
        'PictureBox161
        '
        Me.PictureBox161.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox161.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox161.Location = New System.Drawing.Point(545, 291)
        Me.PictureBox161.Name = "PictureBox161"
        Me.PictureBox161.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox161.TabIndex = 0
        Me.PictureBox161.TabStop = False
        '
        'PictureBox37
        '
        Me.PictureBox37.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox37.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox37.Location = New System.Drawing.Point(545, 332)
        Me.PictureBox37.Name = "PictureBox37"
        Me.PictureBox37.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox37.TabIndex = 0
        Me.PictureBox37.TabStop = False
        '
        'PictureBox10
        '
        Me.PictureBox10.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox10.Location = New System.Drawing.Point(257, 80)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox10.TabIndex = 0
        Me.PictureBox10.TabStop = False
        '
        'PictureBox36
        '
        Me.PictureBox36.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox36.Location = New System.Drawing.Point(401, 208)
        Me.PictureBox36.Name = "PictureBox36"
        Me.PictureBox36.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox36.TabIndex = 0
        Me.PictureBox36.TabStop = False
        '
        'PictureBox17
        '
        Me.PictureBox17.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox17.Location = New System.Drawing.Point(545, 124)
        Me.PictureBox17.Name = "PictureBox17"
        Me.PictureBox17.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox17.TabIndex = 0
        Me.PictureBox17.TabStop = False
        '
        'PictureBox35
        '
        Me.PictureBox35.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox35.Location = New System.Drawing.Point(545, 252)
        Me.PictureBox35.Name = "PictureBox35"
        Me.PictureBox35.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox35.TabIndex = 0
        Me.PictureBox35.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox3.Location = New System.Drawing.Point(401, 37)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox3.TabIndex = 0
        Me.PictureBox3.TabStop = False
        '
        'PictureBox34
        '
        Me.PictureBox34.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox34.Location = New System.Drawing.Point(257, 208)
        Me.PictureBox34.Name = "PictureBox34"
        Me.PictureBox34.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox34.TabIndex = 0
        Me.PictureBox34.TabStop = False
        '
        'PictureBox9
        '
        Me.PictureBox9.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox9.Location = New System.Drawing.Point(545, 80)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox9.TabIndex = 0
        Me.PictureBox9.TabStop = False
        '
        'PictureBox33
        '
        Me.PictureBox33.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox33.Location = New System.Drawing.Point(545, 208)
        Me.PictureBox33.Name = "PictureBox33"
        Me.PictureBox33.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox33.TabIndex = 0
        Me.PictureBox33.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox5.Location = New System.Drawing.Point(257, 37)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox5.TabIndex = 0
        Me.PictureBox5.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox1.Location = New System.Drawing.Point(545, 37)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'TabPage7
        '
        Me.TabPage7.BackColor = System.Drawing.Color.AliceBlue
        Me.TabPage7.Controls.Add(Me.GroupBox4)
        Me.TabPage7.Controls.Add(Me.Label78)
        Me.TabPage7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPage7.Location = New System.Drawing.Point(4, 25)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage7.Size = New System.Drawing.Size(601, 483)
        Me.TabPage7.TabIndex = 1
        Me.TabPage7.Text = "PMBus Control"
        '
        'TabPage19
        '
        Me.TabPage19.BackColor = System.Drawing.Color.FloralWhite
        Me.TabPage19.Controls.Add(Me.GroupBox11)
        Me.TabPage19.Location = New System.Drawing.Point(4, 25)
        Me.TabPage19.Name = "TabPage19"
        Me.TabPage19.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage19.Size = New System.Drawing.Size(601, 483)
        Me.TabPage19.TabIndex = 7
        Me.TabPage19.Text = "Page Plus CMD"
        '
        'GroupBox11
        '
        Me.GroupBox11.BackColor = System.Drawing.Color.AliceBlue
        Me.GroupBox11.Controls.Add(Me.TextBox19)
        Me.GroupBox11.Controls.Add(Me.TextBox10)
        Me.GroupBox11.Controls.Add(Me.GroupBox8)
        Me.GroupBox11.Controls.Add(Me.Label343)
        Me.GroupBox11.Controls.Add(Me.Label301)
        Me.GroupBox11.Controls.Add(Me.TextBox75)
        Me.GroupBox11.Controls.Add(Me.TextBox71)
        Me.GroupBox11.Controls.Add(Me.Label288)
        Me.GroupBox11.Controls.Add(Me.Label280)
        Me.GroupBox11.Controls.Add(Me.Label242)
        Me.GroupBox11.Controls.Add(Me.Label243)
        Me.GroupBox11.Controls.Add(Me.Label244)
        Me.GroupBox11.Controls.Add(Me.TextBox68)
        Me.GroupBox11.Controls.Add(Me.TextBox69)
        Me.GroupBox11.Controls.Add(Me.NumericUpDown17)
        Me.GroupBox11.Controls.Add(Me.Label240)
        Me.GroupBox11.Controls.Add(Me.Label239)
        Me.GroupBox11.Controls.Add(Me.Label237)
        Me.GroupBox11.Controls.Add(Me.Label234)
        Me.GroupBox11.Controls.Add(Me.TextBox32)
        Me.GroupBox11.Controls.Add(Me.NumericUpDown15)
        Me.GroupBox11.Controls.Add(Me.Button105)
        Me.GroupBox11.Controls.Add(Me.Button106)
        Me.GroupBox11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox11.Location = New System.Drawing.Point(5, 5)
        Me.GroupBox11.Name = "GroupBox11"
        Me.GroupBox11.Size = New System.Drawing.Size(589, 471)
        Me.GroupBox11.TabIndex = 478
        Me.GroupBox11.TabStop = False
        Me.GroupBox11.Text = "PAGE PLUS WRITE / READ COMMAND"
        '
        'TextBox19
        '
        Me.TextBox19.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.TextBox19.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox19.Location = New System.Drawing.Point(323, 78)
        Me.TextBox19.MaxLength = 2
        Me.TextBox19.Name = "TextBox19"
        Me.TextBox19.Size = New System.Drawing.Size(70, 23)
        Me.TextBox19.TabIndex = 496
        Me.TextBox19.Text = "32"
        Me.TextBox19.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox10
        '
        Me.TextBox10.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.TextBox10.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox10.Location = New System.Drawing.Point(236, 78)
        Me.TextBox10.MaxLength = 2
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(50, 23)
        Me.TextBox10.TabIndex = 495
        Me.TextBox10.Text = "3B"
        Me.TextBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.Label398)
        Me.GroupBox8.Controls.Add(Me.Label397)
        Me.GroupBox8.Controls.Add(Me.TextBox121)
        Me.GroupBox8.Controls.Add(Me.TextBox56)
        Me.GroupBox8.Controls.Add(Me.TextBox63)
        Me.GroupBox8.Controls.Add(Me.TextBox64)
        Me.GroupBox8.Controls.Add(Me.Label214)
        Me.GroupBox8.Controls.Add(Me.Button63)
        Me.GroupBox8.Controls.Add(Me.Label216)
        Me.GroupBox8.Controls.Add(Me.ComboBox3)
        Me.GroupBox8.Controls.Add(Me.Label217)
        Me.GroupBox8.Controls.Add(Me.Label219)
        Me.GroupBox8.Enabled = False
        Me.GroupBox8.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox8.Location = New System.Drawing.Point(6, 348)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(577, 123)
        Me.GroupBox8.TabIndex = 494
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Query (1Ah)"
        Me.GroupBox8.Visible = False
        '
        'Label398
        '
        Me.Label398.AutoSize = True
        Me.Label398.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label398.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label398.Location = New System.Drawing.Point(222, 86)
        Me.Label398.Name = "Label398"
        Me.Label398.Size = New System.Drawing.Size(148, 13)
        Me.Label398.TabIndex = 474
        Me.Label398.Text = "Query Status Description"
        '
        'Label397
        '
        Me.Label397.AutoSize = True
        Me.Label397.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold)
        Me.Label397.Location = New System.Drawing.Point(59, 83)
        Me.Label397.Name = "Label397"
        Me.Label397.Size = New System.Drawing.Size(98, 15)
        Me.Label397.TabIndex = 422
        Me.Label397.Text = "Data Format : "
        '
        'TextBox121
        '
        Me.TextBox121.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox121.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox121.Location = New System.Drawing.Point(159, 81)
        Me.TextBox121.Name = "TextBox121"
        Me.TextBox121.ReadOnly = True
        Me.TextBox121.Size = New System.Drawing.Size(54, 23)
        Me.TextBox121.TabIndex = 421
        Me.TextBox121.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox56
        '
        Me.TextBox56.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox56.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox56.Location = New System.Drawing.Point(338, 49)
        Me.TextBox56.Name = "TextBox56"
        Me.TextBox56.ReadOnly = True
        Me.TextBox56.Size = New System.Drawing.Size(54, 23)
        Me.TextBox56.TabIndex = 420
        Me.TextBox56.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox63
        '
        Me.TextBox63.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox63.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox63.Location = New System.Drawing.Point(520, 49)
        Me.TextBox63.Name = "TextBox63"
        Me.TextBox63.ReadOnly = True
        Me.TextBox63.Size = New System.Drawing.Size(54, 23)
        Me.TextBox63.TabIndex = 420
        Me.TextBox63.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox64
        '
        Me.TextBox64.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox64.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox64.Location = New System.Drawing.Point(159, 49)
        Me.TextBox64.Name = "TextBox64"
        Me.TextBox64.ReadOnly = True
        Me.TextBox64.Size = New System.Drawing.Size(54, 23)
        Me.TextBox64.TabIndex = 420
        Me.TextBox64.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label214
        '
        Me.Label214.AutoSize = True
        Me.Label214.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold)
        Me.Label214.Location = New System.Drawing.Point(220, 53)
        Me.Label214.Name = "Label214"
        Me.Label214.Size = New System.Drawing.Size(122, 15)
        Me.Label214.TabIndex = 361
        Me.Label214.Text = "Write Supported : "
        '
        'Button63
        '
        Me.Button63.BackColor = System.Drawing.Color.Transparent
        Me.Button63.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button63.Location = New System.Drawing.Point(427, 15)
        Me.Button63.Name = "Button63"
        Me.Button63.Size = New System.Drawing.Size(137, 31)
        Me.Button63.TabIndex = 419
        Me.Button63.Text = "Send Query"
        Me.Button63.UseVisualStyleBackColor = False
        '
        'Label216
        '
        Me.Label216.AutoSize = True
        Me.Label216.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold)
        Me.Label216.Location = New System.Drawing.Point(396, 53)
        Me.Label216.Name = "Label216"
        Me.Label216.Size = New System.Drawing.Size(123, 15)
        Me.Label216.TabIndex = 361
        Me.Label216.Text = "Read Supported : "
        '
        'ComboBox3
        '
        Me.ComboBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox3.FormattingEnabled = True
        Me.ComboBox3.Items.AddRange(New Object() {"00h - PAGE", "01h - OPERATION", "02h - ON_OFF_CONFIG", "03h - CLEAR_FAULTS", "04h - PHASE", "05h - PAGE_PLUS_WRITE", "06h - PAGE_PLUS_READ", "07h - Reserved", "08h - Reserved", "09h - Reserved", "0Ah - Reserved", "0Bh - Reserved", "0Ch - Reserved", "0Dh - Reserved", "0Eh - Reserved", "0Fh - Reserved", "10h - WRITE_PROTECT", "11h - STORE_DEFAULT_ALL", "12h - RESTORE_DEFAULT_ALL", "13h - STORE_DEFAULT_CODE", "14h - RESTORE_DEFAULT_CODE", "15h - STORE_USER_ALL", "16h - RESTORE_USER_ALL", "17h - STORE_USER_CODE", "18h - RESTORE_USER_CODE", "19h - CAPABILITY", "1Ah - QUERY", "1Bh - SMBALERT_MASK", "1Ch - Reserved", "1Dh - Reserved", "1Eh - Reserved", "1Fh - Reserved", "20h - VOUT_MODE", "21h - VOUT_COMMAND", "22h - VOUT_TRIM", "23h - VOUT_CAL_OFFSET", "24h - VOUT_MAX", "25h - VOUT_MARGIN_HIGH", "26h - VOUT_MARGIN_LOW", "27h - VOUT_TRANSITION_RATE", "28h - VOUT_DROOP", "29h - VOUT_SCALE_LOOP", "2Ah - VOUT_SCALE_MONITOR", "2Bh - Reserved", "2Ch - Reserved", "2Dh - Reserved", "2Eh - Reserved", "2Fh - Reserved", "30h - COEFFICIENTS", "31h - POUT_MAX", "32h - MAX_DUTY", "33h - FREQUENCY_SWITCH", "34h - Reserved", "35h - VIN_ON", "36h - VIN_OFF", "37h - INTERLEAVE", "38h - IOUT_CAL_GAIN", "39h - IOUT_CAL_OFFSET", "3Ah - FAN_CONFIG_1_2", "3Bh - FAN_COMMAND_1", "3Ch - FAN_COMMAND_2", "3Dh - FAN_CONFIG_3_4", "3Eh - FAN_COMMAND_3", "3Fh - FAN_COMMAND_4", "40h - VOUT_OV_FAULT_LIMIT", "41h - VOUT_OV_FAULT_RESPONSE", "42h - VOUT_OV_WARN_LIMIT", "43h - VOUT_UV_WARN_LIMIT", "44h - VOUT_UV_FAULT_LIMIT", "45h - VOUT_UV_FAULT_RESPONSE", "46h - IOUT_OC_FAULT_LIMIT", "47h - IOUT_OC_FAULT_RESPONSE", "48h - IOUT_OC_LV_FAULT_LIMIT", "49h - IOUT_OC_LV_FAULT_RESPONSE", "4Ah - IOUT_OC_WARN_LIMIT", "4Bh - IOUT_UC_FAULT_LIMIT", "4Ch - IOUT_UC_FAULT_RESPONSE", "4Dh - Reserved", "4Eh - Reserved", "4Fh - OT_FAULT_LIMIT", "50h - OT_FAULT_RESPONSE", "51h - OT_WARN_LIMIT", "52h - UT_WARN_LIMIT", "53h - UT_FAULT_LIMIT", "54h - UT_FAULT_RESPONSE", "55h - VIN_OV_FAULT_LIMIT", "56h - VIN_OV_FAULT_RESPONSE", "57h - VIN_OV_WARN_LIMIT", "58h - VIN_UV_WARN_LIMIT", "59h - VIN_UV_FAULT_LIMIT", "5Ah - VIN_UV_FAULT_RESPONSE", "5Bh - IIN_OC_FAULT_LIMIT", "5Ch - IIN_OC_FAULT_RESPONSE", "5Dh - IIN_OC_WARN_LIMIT", "5Eh - POWER_GOOD_ON", "5Fh - POWER_GOOD_OFF", "60h - TON_DELAY", "61h - TON_RISE", "62h - TON_MAX_FAULT_LIMIT", "63h - TON_MAX_FAULT_RESPONSE", "64h - TOFF_DELAY", "65h - TOFF_FALL", "66h - TOFF_MAX_WARN_LIMIT", "67h - Reserved (Was Used In Revision 1.0)", "68h - POUT_OP_FAULT_LIMIT", "69h - POUT_OP_FAULT_RESPONSE", "6Ah - POUT_OP_WARN_LIMIT", "6Bh - PIN_OP_WARN_LIMIT", "6Ch - Reserved", "6Dh - Reserved", "6Eh - Reserved", "6Fh - Reserved", "70h - Reserved (Test Input Fuse A)", "71h - Reserved (Test Input Fuse B)", "72h - Reserved (Test Input OR-ing A)", "73h - Reserved (Test Input OR-ing B)", "74h - Reserved (Test Output OR-ing)", "75h - Reserved", "76h - Reserved", "77h - Reserved", "78h - STATUS_BYTE", "79h - STATUS_WORD", "7Ah - STATUS_VOUT", "7Bh - STATUS_IOUT", "7Ch - STATUS_INPUT", "7Dh - STATUS_TEMPERATURE", "7Eh - STATUS_CML", "7Fh - STATUS_OTHER", "80h - STATUS_MFR_SPECIFIC", "81h - STATUS_FANS_1_2", "82h - STATUS_FANS_3_4", "83h - Reserved", "84h - Reserved", "85h - Reserved", "86h - READ_EIN", "87h - READ_EOUT", "88h - READ_VIN", "89h - READ_IIN", "8Ah - READ_VCAP", "8Bh - READ_VOUT", "8Ch - READ_IOUT", "8Dh - READ_TEMPERATURE_1", "8Eh - READ_TEMPERATURE_2", "8Fh - READ_TEMPERATURE_3", "90h - READ_FAN_SPEED_1", "91h - READ_FAN_SPEED_2", "92h - READ_FAN_SPEED_3", "93h - READ_FAN_SPEED_4", "94h - READ_DUTY_CYCLE", "95h - READ_FREQUENCY", "96h - READ_POUT", "97h - READ_PIN", "98h - PMBUS_REVISION", "99h - MFR_ID", "9Ah - MFR_MODEL", "9Bh - MFR_REVISION", "9Ch - MFR_LOCATION", "9Dh - MFR_DATE", "9Eh - MFR_SERIAL", "9Fh - APP_PROFILE_SUPPORT", "A0h - MFR_VIN_MIN", "A1h - MFR_VIN_MAX", "A2h - MFR_IIN_MAX", "A3h - MFR_PIN_MAX", "A4h - MFR_VOUT_MIN", "A5h - MFR_VOUT_MAX", "A6h - MFR_IOUT_MAX", "A7h - MFR_POUT_MAX", "A8h - MFR_TAMBIENT_MAX", "A9h - MFR_TAMBIENT_MIN", "AAh - MFR_EFFICIENCY_LL", "ABh - MFR_EFFICIENCY_HL", "ACh - MFR_PIN_ACCURACY", "ADh - IC_DEVICE_ID", "AEh - IC_DEVICE_REV", "AFh - Reserved", "B0h - USER_DATA_00", "B1h - USER_DATA_01", "B2h - USER_DATA_02", "B3h - USER_DATA_03", "B4h - USER_DATA_04", "B5h - USER_DATA_05", "B6h - USER_DATA_06", "B7h - USER_DATA_07", "B8h - USER_DATA_08", "B9h - USER_DATA_09", "BAh - USER_DATA_10", "BBh - USER_DATA_11", "BCh - USER_DATA_12", "BDh - USER_DATA_13", "BEh - USER_DATA_14", "BFh - USER_DATA_15", "C0h - MFR_MAX_TEMP_1", "C1h - MFR_MAX_TEMP_2", "C2h - MFR_MAX_TEMP_3", "C3h - Reserved", "C4h - Reserved", "C5h - Reserved", "C6h - Reserved", "C7h - Reserved", "C8h - Reserved", "C9h - Reserved", "CAh - Reserved", "CBh - Reserved", "CCh - Reserved", "CDh - Reserved", "CEh - Reserved", "CFh - Reserved", "D0h - MFR_SPECIFIC_00", "D1h - MFR_SPECIFIC_01", "D2h - VSB_STATUS_VOUT", "D3h - VSB_STATUS_IOUT", "D4h - MFR_SPECIFIC_04", "D5h - MFR_FW_REVISION", "D6h - Watchdog_reset_counter", "D7h - Watchdog_timer", "D8h - Watchdog_control_port1", "D9h - Watchdog_control_port2", "DAh - PS_OK_Contorl", "DBh - HEALTH_CHECK_Enable", "DCh - Health_Check_Status_and_Result", "DDh - Clear_Health_Check_Failure", "DEh - MFR_BLACK_BOX", "DFh - MFR_CLEAR_BLACK_ BOX", "E0h - MFR_SPECIFIC_16", "E1h - MFR_SPECIFIC_17", "E2h - MFR_SPECIFIC_18", "E3h - MFR_SPECIFIC_19", "E4h - MFR_SPECIFIC_20", "E5h - MFR_POS_TOTAL", "E6h - MFR_POS_LAST", "E7h - MFR_SPECIFIC_23", "E8h - MFR_SPECIFIC_24", "E9h - MFR_SPECIFIC_25", "EAh - Eeprom_WR_Protect", "EBh - MFR_SPECIFIC_27", "ECh - Scratch_Pad_Area", "EDh - MFR_SPECIFIC_29", "EEh - VSB_ READ_VOUT", "EFh - VSB_ READ_IOUT", "F0h - Unlock_FW_UP_MODE", "F1h - Set_Boot_Flag", "F2h - Tx_Upload_Data_to_RAM", "F3h - MFR_SPECIFIC_35", "F4h - Bootloader Status", "F5h - MFR_SPECIFIC_37", "F6h - MFR_SPECIFIC_38", "F7h - MFR_SPECIFIC_39", "F8h - MFR_SPECIFIC_40", "F9h - MFR_SPECIFIC_41", "FAh - MFR_SPECIFIC_42", "FBh - MFR_SPECIFIC_43", "FCh - MFR_SPECIFIC_44", "FDh - MFR_SPECIFIC_45", "FEh - MFR_SPECIFIC_COMMAND EXT"})
        Me.ComboBox3.Location = New System.Drawing.Point(136, 21)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(282, 21)
        Me.ComboBox3.TabIndex = 362
        Me.ComboBox3.Text = "00h - PAGE"
        '
        'Label217
        '
        Me.Label217.AutoSize = True
        Me.Label217.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold)
        Me.Label217.Location = New System.Drawing.Point(4, 53)
        Me.Label217.Name = "Label217"
        Me.Label217.Size = New System.Drawing.Size(154, 15)
        Me.Label217.TabIndex = 361
        Me.Label217.Text = "Command Supported : "
        '
        'Label219
        '
        Me.Label219.AutoSize = True
        Me.Label219.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold)
        Me.Label219.Location = New System.Drawing.Point(6, 22)
        Me.Label219.Name = "Label219"
        Me.Label219.Size = New System.Drawing.Size(124, 15)
        Me.Label219.TabIndex = 361
        Me.Label219.Text = "Select Command :"
        '
        'Label343
        '
        Me.Label343.AutoSize = True
        Me.Label343.Enabled = False
        Me.Label343.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label343.Location = New System.Drawing.Point(362, 169)
        Me.Label343.Name = "Label343"
        Me.Label343.Size = New System.Drawing.Size(35, 12)
        Me.Label343.TabIndex = 493
        Me.Label343.Text = "DATA"
        Me.Label343.Visible = False
        '
        'Label301
        '
        Me.Label301.AutoSize = True
        Me.Label301.Enabled = False
        Me.Label301.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label301.Location = New System.Drawing.Point(275, 169)
        Me.Label301.Name = "Label301"
        Me.Label301.Size = New System.Drawing.Size(72, 12)
        Me.Label301.TabIndex = 492
        Me.Label301.Text = "BYTE COUNT"
        Me.Label301.Visible = False
        '
        'TextBox75
        '
        Me.TextBox75.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox75.Enabled = False
        Me.TextBox75.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox75.Location = New System.Drawing.Point(275, 192)
        Me.TextBox75.MaxLength = 2
        Me.TextBox75.Multiline = True
        Me.TextBox75.Name = "TextBox75"
        Me.TextBox75.ReadOnly = True
        Me.TextBox75.Size = New System.Drawing.Size(38, 25)
        Me.TextBox75.TabIndex = 491
        Me.TextBox75.Visible = False
        '
        'TextBox71
        '
        Me.TextBox71.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox71.Enabled = False
        Me.TextBox71.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox71.Location = New System.Drawing.Point(342, 192)
        Me.TextBox71.MaxLength = 2
        Me.TextBox71.Multiline = True
        Me.TextBox71.Name = "TextBox71"
        Me.TextBox71.ReadOnly = True
        Me.TextBox71.Size = New System.Drawing.Size(71, 25)
        Me.TextBox71.TabIndex = 490
        Me.TextBox71.Visible = False
        '
        'Label288
        '
        Me.Label288.AutoSize = True
        Me.Label288.BackColor = System.Drawing.Color.Yellow
        Me.Label288.Enabled = False
        Me.Label288.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label288.Location = New System.Drawing.Point(17, 134)
        Me.Label288.Name = "Label288"
        Me.Label288.Size = New System.Drawing.Size(138, 16)
        Me.Label288.TabIndex = 489
        Me.Label288.Text = "PAGE PLUS READ"
        Me.Label288.Visible = False
        '
        'Label280
        '
        Me.Label280.AutoSize = True
        Me.Label280.BackColor = System.Drawing.Color.Yellow
        Me.Label280.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label280.Location = New System.Drawing.Point(17, 28)
        Me.Label280.Name = "Label280"
        Me.Label280.Size = New System.Drawing.Size(145, 16)
        Me.Label280.TabIndex = 488
        Me.Label280.Text = "PAGE PLUS WRITE"
        '
        'Label242
        '
        Me.Label242.AutoSize = True
        Me.Label242.Enabled = False
        Me.Label242.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label242.Location = New System.Drawing.Point(185, 169)
        Me.Label242.Name = "Label242"
        Me.Label242.Size = New System.Drawing.Size(65, 12)
        Me.Label242.TabIndex = 487
        Me.Label242.Text = "CMD CODE"
        Me.Label242.Visible = False
        '
        'Label243
        '
        Me.Label243.AutoSize = True
        Me.Label243.Enabled = False
        Me.Label243.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label243.Location = New System.Drawing.Point(106, 169)
        Me.Label243.Name = "Label243"
        Me.Label243.Size = New System.Drawing.Size(54, 12)
        Me.Label243.TabIndex = 486
        Me.Label243.Text = "PAGE NO"
        Me.Label243.Visible = False
        '
        'Label244
        '
        Me.Label244.AutoSize = True
        Me.Label244.Enabled = False
        Me.Label244.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label244.Location = New System.Drawing.Point(12, 169)
        Me.Label244.Name = "Label244"
        Me.Label244.Size = New System.Drawing.Size(72, 12)
        Me.Label244.TabIndex = 485
        Me.Label244.Text = "BYTE COUNT"
        Me.Label244.Visible = False
        '
        'TextBox68
        '
        Me.TextBox68.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.TextBox68.Enabled = False
        Me.TextBox68.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox68.Location = New System.Drawing.Point(195, 192)
        Me.TextBox68.MaxLength = 2
        Me.TextBox68.Multiline = True
        Me.TextBox68.Name = "TextBox68"
        Me.TextBox68.Size = New System.Drawing.Size(51, 25)
        Me.TextBox68.TabIndex = 484
        Me.TextBox68.Visible = False
        '
        'TextBox69
        '
        Me.TextBox69.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.TextBox69.Enabled = False
        Me.TextBox69.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox69.Location = New System.Drawing.Point(20, 192)
        Me.TextBox69.MaxLength = 2
        Me.TextBox69.Multiline = True
        Me.TextBox69.Name = "TextBox69"
        Me.TextBox69.ReadOnly = True
        Me.TextBox69.Size = New System.Drawing.Size(47, 25)
        Me.TextBox69.TabIndex = 483
        Me.TextBox69.Text = "2"
        Me.TextBox69.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.TextBox69.Visible = False
        '
        'NumericUpDown17
        '
        Me.NumericUpDown17.Enabled = False
        Me.NumericUpDown17.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericUpDown17.Location = New System.Drawing.Point(96, 194)
        Me.NumericUpDown17.Maximum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown17.Name = "NumericUpDown17"
        Me.NumericUpDown17.Size = New System.Drawing.Size(70, 23)
        Me.NumericUpDown17.TabIndex = 482
        Me.NumericUpDown17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown17.Visible = False
        '
        'Label240
        '
        Me.Label240.AutoSize = True
        Me.Label240.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label240.Location = New System.Drawing.Point(343, 53)
        Me.Label240.Name = "Label240"
        Me.Label240.Size = New System.Drawing.Size(35, 12)
        Me.Label240.TabIndex = 481
        Me.Label240.Text = "DATA"
        '
        'Label239
        '
        Me.Label239.AutoSize = True
        Me.Label239.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label239.Location = New System.Drawing.Point(229, 53)
        Me.Label239.Name = "Label239"
        Me.Label239.Size = New System.Drawing.Size(65, 12)
        Me.Label239.TabIndex = 480
        Me.Label239.Text = "CMD CODE"
        '
        'Label237
        '
        Me.Label237.AutoSize = True
        Me.Label237.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label237.Location = New System.Drawing.Point(138, 53)
        Me.Label237.Name = "Label237"
        Me.Label237.Size = New System.Drawing.Size(54, 12)
        Me.Label237.TabIndex = 479
        Me.Label237.Text = "PAGE NO"
        '
        'Label234
        '
        Me.Label234.AutoSize = True
        Me.Label234.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label234.Location = New System.Drawing.Point(20, 53)
        Me.Label234.Name = "Label234"
        Me.Label234.Size = New System.Drawing.Size(72, 12)
        Me.Label234.TabIndex = 478
        Me.Label234.Text = "BYTE COUNT"
        '
        'TextBox32
        '
        Me.TextBox32.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.TextBox32.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox32.Location = New System.Drawing.Point(22, 76)
        Me.TextBox32.MaxLength = 2
        Me.TextBox32.Multiline = True
        Me.TextBox32.Name = "TextBox32"
        Me.TextBox32.ReadOnly = True
        Me.TextBox32.Size = New System.Drawing.Size(70, 25)
        Me.TextBox32.TabIndex = 476
        Me.TextBox32.Text = "4"
        Me.TextBox32.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericUpDown15
        '
        Me.NumericUpDown15.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericUpDown15.Location = New System.Drawing.Point(129, 78)
        Me.NumericUpDown15.Maximum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown15.Name = "NumericUpDown15"
        Me.NumericUpDown15.Size = New System.Drawing.Size(70, 23)
        Me.NumericUpDown15.TabIndex = 474
        Me.NumericUpDown15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Button105
        '
        Me.Button105.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button105.Location = New System.Drawing.Point(431, 71)
        Me.Button105.Name = "Button105"
        Me.Button105.Size = New System.Drawing.Size(150, 32)
        Me.Button105.TabIndex = 281
        Me.Button105.Text = "PAGE PLUS Write"
        Me.Button105.UseVisualStyleBackColor = True
        '
        'Button106
        '
        Me.Button106.Enabled = False
        Me.Button106.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button106.Location = New System.Drawing.Point(431, 186)
        Me.Button106.Name = "Button106"
        Me.Button106.Size = New System.Drawing.Size(150, 36)
        Me.Button106.TabIndex = 282
        Me.Button106.Text = "PAGE PLUS Read"
        Me.Button106.UseVisualStyleBackColor = True
        Me.Button106.Visible = False
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AllowUserToResizeColumns = False
        Me.DataGridView1.AllowUserToResizeRows = False
        Me.DataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Cmd, Me.DataGridViewTextBoxColumn18, Me.DataGridViewTextBoxColumn19, Me.DataGridViewTextBoxColumn21})
        Me.DataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.DataGridView1.GridColor = System.Drawing.SystemColors.Control
        Me.DataGridView1.Location = New System.Drawing.Point(5, 4)
        Me.DataGridView1.MultiSelect = False
        Me.DataGridView1.Name = "DataGridView1"
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.ControlDark
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle4.NullValue = "0"
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.RowHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.DataGridView1.RowHeadersVisible = False
        Me.DataGridView1.RowHeadersWidth = 195
        Me.DataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.DataGridView1.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.DataGridView1.RowTemplate.DefaultCellStyle.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DataGridView1.RowTemplate.Height = 19
        Me.DataGridView1.RowTemplate.ReadOnly = True
        Me.DataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.DataGridView1.Size = New System.Drawing.Size(426, 510)
        Me.DataGridView1.TabIndex = 46
        '
        'Column1
        '
        Me.Column1.HeaderText = "Cmd"
        Me.Column1.Name = "Column1"
        Me.Column1.Width = 35
        '
        'Cmd
        '
        Me.Cmd.HeaderText = "Command Name"
        Me.Cmd.Name = "Cmd"
        Me.Cmd.Width = 135
        '
        'DataGridViewTextBoxColumn18
        '
        Me.DataGridViewTextBoxColumn18.HeaderText = "With PEC"
        Me.DataGridViewTextBoxColumn18.Name = "DataGridViewTextBoxColumn18"
        Me.DataGridViewTextBoxColumn18.Width = 88
        '
        'DataGridViewTextBoxColumn19
        '
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DataGridViewTextBoxColumn19.DefaultCellStyle = DataGridViewCellStyle3
        Me.DataGridViewTextBoxColumn19.HeaderText = "Hex Data"
        Me.DataGridViewTextBoxColumn19.Name = "DataGridViewTextBoxColumn19"
        Me.DataGridViewTextBoxColumn19.Width = 80
        '
        'DataGridViewTextBoxColumn21
        '
        Me.DataGridViewTextBoxColumn21.HeaderText = "Actual"
        Me.DataGridViewTextBoxColumn21.Name = "DataGridViewTextBoxColumn21"
        Me.DataGridViewTextBoxColumn21.Width = 90
        '
        'TabControl1
        '
        Me.TabControl1.Appearance = System.Windows.Forms.TabAppearance.Buttons
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.ItemSize = New System.Drawing.Size(200, 28)
        Me.TabControl1.Location = New System.Drawing.Point(4, 91)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1053, 560)
        Me.TabControl1.TabIndex = 547
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Window
        Me.ClientSize = New System.Drawing.Size(1058, 676)
        Me.Controls.Add(Me.RichTextBox1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label29)
        Me.Controls.Add(Me.CheckBox2)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.RadioButton17)
        Me.Controls.Add(Me.RadioButton16)
        Me.Controls.Add(Me.NumericUpDown1)
        Me.Controls.Add(Me.RadioButton9)
        Me.Controls.Add(Me.RadioButton10)
        Me.Controls.Add(Me.Button14)
        Me.Controls.Add(Me.CheckBox1)
        Me.Controls.Add(Me.NumericUpDown7)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.RadioButton11)
        Me.Controls.Add(Me.TabControl1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "PMBus_GUI"
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown7, System.ComponentModel.ISupportInitialize).EndInit()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.TabPage9.ResumeLayout(False)
        Me.TabPage9.PerformLayout()
        CType(Me.DataGridView4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        CType(Me.NumericUpDown2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown16, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        CType(Me.NumericUpDown21, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage11.ResumeLayout(False)
        CType(Me.PictureBox39, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox43, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox47, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox51, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox55, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox59, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox63, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox64, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage1.ResumeLayout(False)
        Me.TabControl2.ResumeLayout(False)
        Me.TabPage6.ResumeLayout(False)
        Me.TabPage6.PerformLayout()
        CType(Me.PictureBox169, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox170, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox171, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox172, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox173, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox174, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox175, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox176, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox32, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox168, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox62, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox31, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox167, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox61, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox24, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox60, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox23, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox16, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox58, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox30, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox166, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox57, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox56, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox22, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox54, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox29, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox165, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox53, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox52, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox21, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox50, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox28, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox164, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox49, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox48, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox20, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox46, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox27, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox163, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox45, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox44, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox19, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox42, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox26, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox162, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox41, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox40, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox18, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox38, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox25, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox161, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox37, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox36, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox17, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox35, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox34, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox33, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage7.ResumeLayout(False)
        Me.TabPage7.PerformLayout()
        Me.TabPage19.ResumeLayout(False)
        Me.GroupBox11.ResumeLayout(False)
        Me.GroupBox11.PerformLayout()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        CType(Me.NumericUpDown17, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControl1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout

End Sub
    Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents CheckBox2 As System.Windows.Forms.CheckBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents RadioButton17 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton16 As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents RadioButton9 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton10 As System.Windows.Forms.RadioButton
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Button14 As System.Windows.Forms.Button
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents NumericUpDown7 As System.Windows.Forms.NumericUpDown
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripProgressBar1 As System.Windows.Forms.ToolStripProgressBar
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents RadioButton11 As System.Windows.Forms.RadioButton
    Friend WithEvents TabPage9 As System.Windows.Forms.TabPage
    Friend WithEvents Button48 As System.Windows.Forms.Button
    Friend WithEvents DataGridView4 As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn9 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn11 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn12 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn13 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label78 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Label206 As System.Windows.Forms.Label
    Friend WithEvents TextBox51 As System.Windows.Forms.TextBox
    Friend WithEvents NumericUpDown12 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Button49 As System.Windows.Forms.Button
    Friend WithEvents NumericUpDown16 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Button50 As System.Windows.Forms.Button
    Friend WithEvents Button56 As System.Windows.Forms.Button
    Friend WithEvents Label201 As System.Windows.Forms.Label
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Label275 As System.Windows.Forms.Label
    Friend WithEvents Label327 As System.Windows.Forms.Label
    Friend WithEvents Label272 As System.Windows.Forms.Label
    Friend WithEvents Label269 As System.Windows.Forms.Label
    Friend WithEvents Button103 As System.Windows.Forms.Button
    Friend WithEvents Label268 As System.Windows.Forms.Label
    Friend WithEvents Button104 As System.Windows.Forms.Button
    Friend WithEvents Label264 As System.Windows.Forms.Label
    Friend WithEvents CheckBox6 As System.Windows.Forms.CheckBox
    Friend WithEvents Label252 As System.Windows.Forms.Label
    Friend WithEvents CheckBox7 As System.Windows.Forms.CheckBox
    Friend WithEvents Label246 As System.Windows.Forms.Label
    Friend WithEvents CheckBox8 As System.Windows.Forms.CheckBox
    Friend WithEvents TextBox89 As System.Windows.Forms.TextBox
    Friend WithEvents CheckBox9 As System.Windows.Forms.CheckBox
    Friend WithEvents TextBox27 As System.Windows.Forms.TextBox
    Friend WithEvents CheckBox10 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox20 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox11 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox19 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox12 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox18 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox69 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox17 As System.Windows.Forms.CheckBox
    Friend WithEvents TextBox31 As System.Windows.Forms.TextBox
    Friend WithEvents CheckBox16 As System.Windows.Forms.CheckBox
    Friend WithEvents TextBox84 As System.Windows.Forms.TextBox
    Friend WithEvents CheckBox15 As System.Windows.Forms.CheckBox
    Friend WithEvents Label347 As System.Windows.Forms.Label
    Friend WithEvents CheckBox14 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox13 As System.Windows.Forms.CheckBox
    Friend WithEvents TextBox26 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox23 As System.Windows.Forms.TextBox
    Friend WithEvents Label131 As System.Windows.Forms.Label
    Friend WithEvents CheckBox28 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox27 As System.Windows.Forms.CheckBox
    Friend WithEvents Label277 As System.Windows.Forms.Label
    Friend WithEvents CheckBox26 As System.Windows.Forms.CheckBox
    Friend WithEvents Label276 As System.Windows.Forms.Label
    Friend WithEvents CheckBox25 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox24 As System.Windows.Forms.CheckBox
    Friend WithEvents Button101 As System.Windows.Forms.Button
    Friend WithEvents CheckBox23 As System.Windows.Forms.CheckBox
    Friend WithEvents Button102 As System.Windows.Forms.Button
    Friend WithEvents CheckBox22 As System.Windows.Forms.CheckBox
    Friend WithEvents Button99 As System.Windows.Forms.Button
    Friend WithEvents CheckBox21 As System.Windows.Forms.CheckBox
    Friend WithEvents Button100 As System.Windows.Forms.Button
    Friend WithEvents TextBox22 As System.Windows.Forms.TextBox
    Friend WithEvents Button97 As System.Windows.Forms.Button
    Friend WithEvents TextBox21 As System.Windows.Forms.TextBox
    Friend WithEvents Button98 As System.Windows.Forms.Button
    Friend WithEvents CheckBox36 As System.Windows.Forms.CheckBox
    Friend WithEvents Button95 As System.Windows.Forms.Button
    Friend WithEvents CheckBox35 As System.Windows.Forms.CheckBox
    Friend WithEvents Button96 As System.Windows.Forms.Button
    Friend WithEvents CheckBox34 As System.Windows.Forms.CheckBox
    Friend WithEvents Button91 As System.Windows.Forms.Button
    Friend WithEvents CheckBox33 As System.Windows.Forms.CheckBox
    Friend WithEvents Button92 As System.Windows.Forms.Button
    Friend WithEvents CheckBox32 As System.Windows.Forms.CheckBox
    Friend WithEvents Button89 As System.Windows.Forms.Button
    Friend WithEvents CheckBox31 As System.Windows.Forms.CheckBox
    Friend WithEvents Button90 As System.Windows.Forms.Button
    Friend WithEvents CheckBox30 As System.Windows.Forms.CheckBox
    Friend WithEvents Label76 As System.Windows.Forms.Label
    Friend WithEvents CheckBox29 As System.Windows.Forms.CheckBox
    Friend WithEvents Label77 As System.Windows.Forms.Label
    Friend WithEvents TextBox20 As System.Windows.Forms.TextBox
    Friend WithEvents Label79 As System.Windows.Forms.Label
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents Label80 As System.Windows.Forms.Label
    Friend WithEvents CheckBox44 As System.Windows.Forms.CheckBox
    Friend WithEvents Label89 As System.Windows.Forms.Label
    Friend WithEvents CheckBox43 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox42 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox41 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox40 As System.Windows.Forms.CheckBox
    Friend WithEvents Label95 As System.Windows.Forms.Label
    Friend WithEvents CheckBox39 As System.Windows.Forms.CheckBox
    Friend WithEvents Label125 As System.Windows.Forms.Label
    Friend WithEvents CheckBox38 As System.Windows.Forms.CheckBox
    Friend WithEvents Label127 As System.Windows.Forms.Label
    Friend WithEvents CheckBox37 As System.Windows.Forms.CheckBox
    Friend WithEvents Label134 As System.Windows.Forms.Label
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents Label135 As System.Windows.Forms.Label
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents CheckBox61 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox52 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox62 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox51 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox63 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox50 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox64 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox49 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox65 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox48 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox66 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox47 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox67 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox46 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox68 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox45 As System.Windows.Forms.CheckBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents CheckBox53 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox60 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox54 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox59 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox55 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox58 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox56 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox57 As System.Windows.Forms.CheckBox
    Friend WithEvents TabPage11 As System.Windows.Forms.TabPage
    Friend WithEvents Label236 As System.Windows.Forms.Label
    Friend WithEvents Label238 As System.Windows.Forms.Label
    Friend WithEvents Button17 As System.Windows.Forms.Button
    Friend WithEvents Button16 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Label203 As System.Windows.Forms.Label
    Friend WithEvents PictureBox39 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox43 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox47 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox51 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox55 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox59 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox63 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox64 As System.Windows.Forms.PictureBox
    Friend WithEvents Label98 As System.Windows.Forms.Label
    Friend WithEvents Label70 As System.Windows.Forms.Label
    Friend WithEvents Label182 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label167 As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label93 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabControl2 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents Label177 As System.Windows.Forms.Label
    Friend WithEvents PictureBox32 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox168 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox62 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox31 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox167 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox61 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox24 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox60 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox23 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox16 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox58 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox30 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox166 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox57 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox15 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox56 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox22 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox8 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox54 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox29 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox165 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox53 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox14 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox52 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox21 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox50 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox28 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox164 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox49 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox13 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox48 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox20 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox7 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox46 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox27 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox163 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox45 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox12 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox44 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox19 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox42 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox26 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox162 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox41 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox11 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox40 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox18 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox6 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox38 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox25 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox161 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox37 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox10 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox36 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox17 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox35 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox34 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox9 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox33 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox5 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents TabPage7 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage19 As System.Windows.Forms.TabPage
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Cmd As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn18 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn19 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn21 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents Label85 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label198 As System.Windows.Forms.Label
    Friend WithEvents PictureBox169 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox170 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox171 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox172 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox173 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox174 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox175 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox176 As System.Windows.Forms.PictureBox
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents Label417 As System.Windows.Forms.Label
    Friend WithEvents Label419 As System.Windows.Forms.Label
    Friend WithEvents Label418 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents Label87 As System.Windows.Forms.Label
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button15 As System.Windows.Forms.Button
    Friend WithEvents Label222 As System.Windows.Forms.Label
    Friend WithEvents Label220 As System.Windows.Forms.Label
    Friend WithEvents Label348 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown21 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label279 As System.Windows.Forms.Label
    Friend WithEvents Label90 As System.Windows.Forms.Label
    Friend WithEvents Label83 As System.Windows.Forms.Label
    Friend WithEvents Label81 As System.Windows.Forms.Label
    Friend WithEvents Label232 As System.Windows.Forms.Label
    Friend WithEvents Label230 As System.Windows.Forms.Label
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents Button20 As System.Windows.Forms.Button
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents Button19 As System.Windows.Forms.Button
    Friend WithEvents TextBox14 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox13 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox12 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox11 As System.Windows.Forms.TextBox
    Friend WithEvents Label67 As System.Windows.Forms.Label
    Friend WithEvents Label66 As System.Windows.Forms.Label
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents TextBox15 As System.Windows.Forms.TextBox
    Friend WithEvents Button22 As System.Windows.Forms.Button
    Friend WithEvents Label68 As System.Windows.Forms.Label
    Friend WithEvents TextBox16 As System.Windows.Forms.TextBox
    Friend WithEvents CheckBox3 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox72 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox73 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox74 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox4 As System.Windows.Forms.CheckBox
    Friend WithEvents Button23 As System.Windows.Forms.Button
    Friend WithEvents Button24 As System.Windows.Forms.Button
    Friend WithEvents TextBox17 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox18 As System.Windows.Forms.TextBox
    Friend WithEvents Button25 As System.Windows.Forms.Button
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents Label398 As System.Windows.Forms.Label
    Friend WithEvents Label397 As System.Windows.Forms.Label
    Friend WithEvents TextBox121 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox56 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox63 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox64 As System.Windows.Forms.TextBox
    Friend WithEvents Label214 As System.Windows.Forms.Label
    Friend WithEvents Button63 As System.Windows.Forms.Button
    Friend WithEvents Label216 As System.Windows.Forms.Label
    Friend WithEvents ComboBox3 As System.Windows.Forms.ComboBox
    Friend WithEvents Label217 As System.Windows.Forms.Label
    Friend WithEvents Label219 As System.Windows.Forms.Label
    Friend WithEvents Label69 As System.Windows.Forms.Label
    Friend WithEvents GroupBox11 As System.Windows.Forms.GroupBox
    Friend WithEvents Label343 As System.Windows.Forms.Label
    Friend WithEvents Label301 As System.Windows.Forms.Label
    Friend WithEvents TextBox75 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox71 As System.Windows.Forms.TextBox
    Friend WithEvents Label288 As System.Windows.Forms.Label
    Friend WithEvents Label280 As System.Windows.Forms.Label
    Friend WithEvents Label242 As System.Windows.Forms.Label
    Friend WithEvents Label243 As System.Windows.Forms.Label
    Friend WithEvents Label244 As System.Windows.Forms.Label
    Friend WithEvents TextBox68 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox69 As System.Windows.Forms.TextBox
    Friend WithEvents NumericUpDown17 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label240 As System.Windows.Forms.Label
    Friend WithEvents Label239 As System.Windows.Forms.Label
    Friend WithEvents Label237 As System.Windows.Forms.Label
    Friend WithEvents Label234 As System.Windows.Forms.Label
    Friend WithEvents TextBox32 As System.Windows.Forms.TextBox
    Friend WithEvents NumericUpDown15 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Button105 As System.Windows.Forms.Button
    Friend WithEvents Button106 As System.Windows.Forms.Button
    Friend WithEvents TextBox19 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox10 As System.Windows.Forms.TextBox
    Friend WithEvents NumericUpDown2 As NumericUpDown
    Friend WithEvents TextBox28 As TextBox
    Friend WithEvents Button29 As Button
    Friend WithEvents Button26 As Button
    Friend WithEvents Label151 As Label
End Class
