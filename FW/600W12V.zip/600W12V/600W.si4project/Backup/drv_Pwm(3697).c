/*******************************************************************************
 * \file    McuPwm.c
 * \brief   init PWM
 *
 * \section AUTHOR
 *    1. CIPS
 *
 * \section SVN
 *  $Date$
 *  $Author$
 *  $Revision$
 *
 * \section LICENSE
 * Copyright (c) 
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * Included header
 ******************************************************************************/
#include <p33EP64GS504.h>
#include "DataFormat.h"

/* Module header */
#include "McuPwm.h"
#include "drv_Clock.h"
#include "Rtv.h"
/*******************************************************************************
 * Local data types (private DataFormats / structs / enums)
 ******************************************************************************/

/*******************************************************************************
 * Local data (private to module)
 ******************************************************************************/

/*******************************************************************************
 * DataFormat data (public to other modules)
 ******************************************************************************/

/*******************************************************************************
 * Local function prototypes (private to module)
 ******************************************************************************/
#define PIN_PWM 1
#define PIN_GPIO 0

void Mcu_PwmHwInit(void);
/*******************************************************************************
 * Function:        Init_PWM
 *
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     Initialize the PWM modules
 *
 ******************************************************************************/
void Mcu_PwmHwInit(void)
{

  PTCON = 0x0000;
  PTCON2 = 0x0000;
  PTPER = 0; // MIN_PERIOD;
#if 1
  pwm1_fan_ishare_init();
  pwm5_fbllc_init();


#else
  /***********************************************
   * PWM 1 Configuration  -- generate I local voltage
   **********************************************/
  /* PWM module controls PWMxH pin */
  IOCON1bits.PENH = PIN_PWM;
  /* PWM module controls PWMxL pin */
  IOCON1bits.PENL = PIN_PWM;
  /* PWM I/O pin pair is in the True Independent PWM Output mode */
  IOCON1bits.PMOD = 3;
  /* PWMxH and PWMxL pins are mapped to their respective pins */
  IOCON1bits.SWAP = 0;
  /* Dead time is disabled added into duty cycle */
  PWMCON1bits.DTC = 2;
  /* Disable Immediate duty cycle updates */
  PWMCON1bits.IUE = 0;
  /* PHASEx/SPHASEx registers provide time base period for this PWM generator */
  PWMCON1bits.ITB = 1;

  FCLCON1bits.CLMOD = 0;
  FCLCON1bits.FLTMOD = 3;

  PHASE1 = ISHARE_PWM_PERIOD;
  PDC1 = (ISHARE_PWM_PERIOD>>1);
  
  SPHASE1 = PWM_FAN_PERIOD;
  SDC1 = (PWM_FAN_PERIOD >> 2);

  /***********************************************
   * PWM 3 Configuration -- LLC SR MASTER driver
   **********************************************/
#if DEBUG_DISABLE_SR
  IOCON3bits.PENH = 0;
  IOCON3bits.PENL = 0;
#else
  /* PWM module controls PWMxH pin */
  IOCON3bits.PENH = 0;
  /* PWM module controls PWMxL pin */
  IOCON3bits.PENL = 0;
#endif
  /* Push-Pull Mode the period = PTPER * 2  , duty = PTPER - LLCDEADTIME */
  IOCON3bits.PMOD = 2;
  /* PWMxH and PWMxL pins are mapped to their respective pins */
  IOCON3bits.SWAP = 0;
  /* State(2) for PWMxH and PWMxL Pins if CLMOD is Enabled bits */
  IOCON3bits.CLDAT = 0;

  /* Dead time disabled added into duty cycle */
  PWMCON3bits.DTC = 0;
  /* Select Independent Time base mode */
  PWMCON3bits.ITB = 0;
  /* Updates to the active MDC/PDCx/SDCx registers are immediate */
  PWMCON3bits.IUE = 1;
  /* Normal Fault mode */
  FCLCON3bits.IFLTMOD = 0;
  /* Current-Limit mode is disabled */
  FCLCON3bits.CLMOD = 0;
  /*Fault input is disabled */
  FCLCON3bits.FLTMOD = 3;

  PHASE3 = 0;
  PDC3 = 0;

  /***********************************************
   * PWM 4 Configuration -- LLC SR MASTER driver
   **********************************************/
#if DEBUG_DISABLE_SR
  IOCON4bits.PENH = 0;
  IOCON4bits.PENL = 0;
#else
  /* PWM module controls PWMxH pin */
  IOCON4bits.PENH = 0;
  /* PWM module controls PWMxL pin */
  IOCON4bits.PENL = 0;
#endif
  /* Push-Pull Mode the period = PTPER * 2  , duty = PTPER - LLCDEADTIME */
  IOCON4bits.PMOD = 2;
  /* PWMxH and PWMxL pins are mapped to their respective pins */
  IOCON4bits.SWAP = 0;
  /* State(2) for PWMxH and PWMxL Pins if CLMOD is Enabled bits */
  IOCON4bits.CLDAT = 0;

  /* Dead time disabled added into duty cycle */
  PWMCON4bits.DTC = 0;
  /* Select Independent Time base mode */
  PWMCON4bits.ITB = 0;
  /* Updates to the active MDC/PDCx/SDCx registers are immediate */
  PWMCON4bits.IUE = 1;
  /* Normal Fault mode */
  FCLCON4bits.IFLTMOD = 0;
  /* Current-Limit mode is disabled */
  FCLCON4bits.CLMOD = 0;
  /*Fault input is disabled */
  FCLCON4bits.FLTMOD = 3;

  PHASE4 = 0;
  PDC4 = 0;

  
  /***********************************************
   * PWM 5 Configuration -- LLC Full bridge driver
   **********************************************/
  /* PWM module controls PWMxH pin */
  IOCON5bits.PENH = 1;
  /* PWM module controls PWMxL pin */
  IOCON5bits.PENL = 1;
  /* Push-Pull Mode ? the period = PTPER * 2  , duty = PTPER - LLCDEADTIME */
  IOCON5bits.PMOD = 2;
  /* State(2) for PWMxH and PWMxL Pins if CLMOD is Enabled bits */
  IOCON5bits.CLDAT = 0;
  /* Dead time is disabled added into duty cycle */
  PWMCON5bits.DTC = 2;
  /* Select Primary Time base mode */
  PWMCON5bits.ITB = 0;
  /* Updates to the active MDC/PDCx/SDCx registers are immediate */
  PWMCON5bits.IUE = 1;
  /* Normal Fault mode*/
  FCLCON5bits.IFLTMOD = 0;
  /* Analog Comparator 2 */
  //FCLCON5bits.CLSRC = 1;
  /* Current-Limit mode is disabled */
  FCLCON5bits.CLMOD = 0;
  /* Fault input is disabled */
  FCLCON5bits.FLTMOD = 3;
  /* Latched Fault Mode */
  //	FCLCON5bits.FLTMOD = 0;
  /* Analog Comparator 2 */
  FCLCON5bits.FLTSRC = 1;
  /* Active High */
  FCLCON5bits.FLTPOL = 0;
  /* Rising edge of PWMxH will trigger Leading-Edge Blanking counter */
  LEBCON5bits.PHR = 1;
  /* Rising edge of PWMxL will trigger Leading-Edge Blanking counter */
  LEBCON5bits.PLR = 1;
  /* Current-Limit Leading-Edge Blanking Enable */
  LEBCON5bits.CLLEBEN = 1;

  PHASE5 = 0;
  SPHASE5 = 0;
  PDC5 = 0;
  
  
   /***********************************************
   * PWM 6 Configuration -- LLC SR SLAVE driver
   **********************************************/
#if DEBUG_DISABLE_SR
  IOCON6bits.PENH = 0;
  IOCON6bits.PENL = 0;
#else
  /* PWM module controls PWMxH pin */
  IOCON6bits.PENH = 0;
  /* PWM module controls PWMxL pin */
  IOCON6bits.PENL = 0;
#endif
  /* Push-Pull Mode the period = PTPER * 2  , duty = PTPER - LLCDEADTIME */
  IOCON6bits.PMOD = 2;
  /* PWMxH and PWMxL pins are mapped to their respective pins */
  IOCON6bits.SWAP = 0;
  /* State(2) for PWMxH and PWMxL Pins if CLMOD is Enabled bits */
  IOCON6bits.CLDAT = 0;

  /* Dead time disabled added into duty cycle */
  PWMCON6bits.DTC = 0;
  /* Select Independent Time base mode */
  PWMCON6bits.ITB = 0;
  /* Updates to the active MDC/PDCx/SDCx registers are immediate */
  PWMCON6bits.IUE = 1;
  /* Normal Fault mode */
  FCLCON6bits.IFLTMOD = 0;
  /* Current-Limit mode is disabled */
  FCLCON6bits.CLMOD = 0;
  /*Fault input is disabled */
  FCLCON6bits.FLTMOD = 3;

  PHASE6 = 0;
  PDC6 = 0;

  /***********************************************
   * PWM 7 Configuration -- LLC SR SLAVE driver
   **********************************************/
#if DEBUG_DISABLE_SR
  IOCON7bits.PENH = 0;
  IOCON7bits.PENL = 0;
#else
  /* PWM module controls PWMxH pin */
  IOCON7bits.PENH = 0;
  /* PWM module controls PWMxL pin */
  IOCON7bits.PENL = 0;
#endif
  /* Push-Pull Mode the period = PTPER * 2  , duty = PTPER - LLCDEADTIME */
  IOCON7bits.PMOD = 2;
  /* PWMxH and PWMxL pins are mapped to their respective pins */
  IOCON7bits.SWAP = 0;
  /* State(2) for PWMxH and PWMxL Pins if CLMOD is Enabled bits */
  IOCON7bits.CLDAT = 0;

  /* Dead time disabled added into duty cycle */
  PWMCON7bits.DTC = 0;
  /* Select Independent Time base mode */
  PWMCON7bits.ITB = 0;
  /* Updates to the active MDC/PDCx/SDCx registers are immediate */
  PWMCON7bits.IUE = 1;
  /* Normal Fault mode */
  FCLCON7bits.IFLTMOD = 0;
  /* Current-Limit mode is disabled */
  FCLCON7bits.CLMOD = 0;
  /*Fault input is disabled */
  FCLCON7bits.FLTMOD = 3;

  PHASE7 = 0;
  PDC7 = 0;
  
  
  /* Active Period register is updated immediately */
  PTCONbits.EIPU = 1;
  /* PWM Special Event Match Interrupt Priority bits */
  IPC14bits.PSEMIP = PSEMIP_INT_PRIO;
  /* PWM Special Event Compare Value */
  SEVTCMP = 0;
  /* PWM Special Event Match Interrupt Enable */
  _PSEMIE = 1;

  /***********************************************
   * turn on PWM module
   **********************************************/
  /* 1 = Enable the PWM Module */
  PTCONbits.PTEN = 1;
  #endif
}


static void pwm_general_init( void)
{
  /* Active Period register is updated immediately */
  PTCONbits.EIPU = 1;
  /* PWM Special Event Match Interrupt Priority bits */
  IPC14bits.PSEMIP = PSEMIP_INT_PRIO;
  /* PWM Special Event Compare Value */
  SEVTCMP = 0;
  /* PWM Special Event Match Interrupt Enable */
  _PSEMIE = 1;

  /***********************************************
   * turn on PWM module
   **********************************************/
  /* 1 = Enable the PWM Module */
  PTCONbits.PTEN = 1;

}


/*******************************************************************************
 * Function:        pwm1_fan_init
 * auther:          edwin 
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     PWM FAN init
 * history:
 ******************************************************************************/

static void pwm1_fan_ishare_init( void)
{

	/***********************************************
	  * PWM 1 Configuration  -- generate I local voltage
	  **********************************************/
	 /* PWM module controls PWMxH pin */
	 IOCON1bits.PENH = PIN_PWM;
	 /* PWM module controls PWMxL pin */
	 IOCON1bits.PENL = PIN_PWM;
	 /* PWM I/O pin pair is in the True Independent PWM Output mode */
	 IOCON1bits.PMOD = 3;
	 /* PWMxH and PWMxL pins are mapped to their respective pins */
	 IOCON1bits.SWAP = 0;
	 /* Dead time is disabled added into duty cycle */
	 PWMCON1bits.DTC = 2;
	 /* Disable Immediate duty cycle updates */
	 PWMCON1bits.IUE = 0;
	 /* PHASEx/SPHASEx registers provide time base period for this PWM generator */
	 PWMCON1bits.ITB = 1;
	
	 FCLCON1bits.CLMOD = 0;
	 FCLCON1bits.FLTMOD = 3;
	
//	 SPHASE1 = ISHARE_PWM_PERIOD;
//	 SDC1 = (ISHARE_PWM_PERIOD>>1);
	 
	 PHASE1 = PWM_FAN_PERIOD;
	 PDC1 = (PWM_FAN_PERIOD >> 2);

}

/*******************************************************************************
 * Function:        pwm2_12v_software_trimming_init
 * auther:          edwin 
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     12V software trimming init
 * history:
 ******************************************************************************/

static void pwm2_12v_software_trimming_init( void)
{

	/***********************************************
	  * PWM 2 Configuration  -- generate I local voltage
	  **********************************************/
	 /* PWM module controls PWMxH pin */
	 IOCON2bits.PENH = PIN_PWM;
	 /* PWM module controls PWMxL pin */
	 IOCON2bits.PENL = PIN_PWM;
	 /* PWM I/O pin pair is in the True Independent PWM Output mode */
	 IOCON2bits.PMOD = 3;
	 /* PWMxH and PWMxL pins are mapped to their respective pins */
	 IOCON2bits.SWAP = 0;
	 /* Dead time is disabled added into duty cycle */
	 PWMCON2bits.DTC = 2;
	 /* Disable Immediate duty cycle updates */
	 PWMCON2bits.IUE = 0;
	 /* PHASEx/SPHASEx registers provide time base period for this PWM generator */
	 PWMCON2bits.ITB = 1;
	
	 FCLCON2bits.CLMOD = 0;
	 FCLCON2bits.FLTMOD = 3;
	
	 //SPHASE1 = PWM_12V_DROOP_PERIOD;
	 //SDC1 = (PWM_12V_DROOP_PERIOD>>2);
	 
	 PHASE2 = PWM_12V_SOFT_TRIM_PERIOD;
	 PDC2 = (PWM_12V_SOFT_TRIM_PERIOD >> 2);


	 

}

static void pwm3_sr_master_init( void)
{
   /***********************************************
   * PWM 3 Configuration -- LLC SR MASTER driver
   **********************************************/
#if DEBUG_DISABLE_SR
  IOCON3bits.PENH = 0;
  IOCON3bits.PENL = 0;
#else
  /* PWM module controls PWMxH pin */
  IOCON3bits.PENH = 0;
  /* PWM module controls PWMxL pin */
  IOCON3bits.PENL = 0;
#endif
  /* Push-Pull Mode the period = PTPER * 2  , duty = PTPER - LLCDEADTIME */
  IOCON3bits.PMOD = 2;
  /* PWMxH and PWMxL pins are mapped to their respective pins */
  IOCON3bits.SWAP = 0;
  /* State(2) for PWMxH and PWMxL Pins if CLMOD is Enabled bits */
  IOCON3bits.CLDAT = 0;

  /* Dead time disabled added into duty cycle */
  PWMCON3bits.DTC = 0;
  /* Select Independent Time base mode */
  PWMCON3bits.ITB = 0;
  /* Updates to the active MDC/PDCx/SDCx registers are immediate */
  PWMCON3bits.IUE = 1;
  /* Normal Fault mode */
  FCLCON3bits.IFLTMOD = 0;
  /* Current-Limit mode is disabled */
  FCLCON3bits.CLMOD = 0;
  /*Fault input is disabled */
  FCLCON3bits.FLTMOD = 3;

  PHASE3 = 0;
  PDC3 = 0;
}

static void   pwm4_1()
{

#if 0
 //PWM 4 configuration				  //True Independent Mode
   /*
   PWM4H : 12V_REF
   PWM4L : FAN_PWMA (Please refer the settings in Fan.c)
	*/
   IOCON4bits.PENH = 1; 		 //PWM module controls PWMxH pin
   IOCON4bits.PENL = 1; 		 //PWM module controls PWMxL pin
   IOCON4bits.PMOD = 3; 		 //PWM I/O pin pair is in the True Independent Output mode
   PWMCON4bits.MDCS = 0;
   PWMCON4bits.DTC = 2; 		 //Dead time function is disabled
   PWMCON4bits.ITB = 1; 		 //PHASEx/SPHASEx registers provide time base period for this PWM generator
   FCLCON4bits.FLTMOD = 3;
   PHASE4 = 33000;
   PDC4 = 0;
   gVoutCmd = UserData.Page2.region.VoutCommand.Val;
   Vref.SetVoltage = gVoutCmd;
   Vref.SoftstartVoltage = 0;
#endif
}

static void pwm5_fbllc_init()
{

	/***********************************************
	   * PWM 5 Configuration -- LLC Full bridge driver
	   **********************************************/
	  /* PWM module controls PWMxH pin */
	  IOCON5bits.PENH = PIN_PWM;
	  /* PWM module controls PWMxL pin */
	  IOCON5bits.PENL = PIN_PWM;
	  /* Push-Pull Mode ? the period = PTPER * 2  , duty = PTPER - LLCDEADTIME */
	  IOCON5bits.PMOD = 2;
	  /* State(2) for PWMxH and PWMxL Pins if CLMOD is Enabled bits */
	  IOCON5bits.CLDAT = 0;
	  /* Dead time is disabled added into duty cycle */
	  PWMCON5bits.DTC = 2;
	  /* Select Primary Time base mode */
	  PWMCON5bits.ITB = 0;
	  /* Updates to the active MDC/PDCx/SDCx registers are immediate */
	  PWMCON5bits.IUE = 1;
	  /* Normal Fault mode*/
	  FCLCON5bits.IFLTMOD = 0;
	  /* Analog Comparator 2 */
	  //FCLCON5bits.CLSRC = 1;
	  /* Current-Limit mode is disabled */
	  FCLCON5bits.CLMOD = 0;
	  /* Fault input is disabled */
	  FCLCON5bits.FLTMOD = 3;
	  /* Latched Fault Mode */
	  //	FCLCON5bits.FLTMOD = 0;
	  /* Analog Comparator 2 */
	  FCLCON5bits.FLTSRC = 1;
	  /* Active High */
	  FCLCON5bits.FLTPOL = 0;
	  /* Rising edge of PWMxH will trigger Leading-Edge Blanking counter */
	  LEBCON5bits.PHR = 1;
	  /* Rising edge of PWMxL will trigger Leading-Edge Blanking counter */
	  LEBCON5bits.PLR = 1;
	  /* Current-Limit Leading-Edge Blanking Enable */
	  LEBCON5bits.CLLEBEN = 1;
	
	  PHASE5 = 0;
	  SPHASE5 = 0;
	  PDC5 = 0;
	  


}

static void pwm6_sr_slave_init(void)
{

/***********************************************
   * PWM 6 Configuration -- LLC SR SLAVE driver
   **********************************************/
#if DEBUG_DISABLE_SR
  IOCON6bits.PENH = 0;
  IOCON6bits.PENL = 0;
#else
  /* PWM module controls PWMxH pin */
  IOCON6bits.PENH = 0;
  /* PWM module controls PWMxL pin */
  IOCON6bits.PENL = 0;
#endif
  /* Push-Pull Mode the period = PTPER * 2  , duty = PTPER - LLCDEADTIME */
  IOCON6bits.PMOD = 2;
  /* PWMxH and PWMxL pins are mapped to their respective pins */
  IOCON6bits.SWAP = 0;
  /* State(2) for PWMxH and PWMxL Pins if CLMOD is Enabled bits */
  IOCON6bits.CLDAT = 0;

  /* Dead time disabled added into duty cycle */
  PWMCON6bits.DTC = 0;
  /* Select Independent Time base mode */
  PWMCON6bits.ITB = 0;
  /* Updates to the active MDC/PDCx/SDCx registers are immediate */
  PWMCON6bits.IUE = 1;
  /* Normal Fault mode */
  FCLCON6bits.IFLTMOD = 0;
  /* Current-Limit mode is disabled */
  FCLCON6bits.CLMOD = 0;
  /*Fault input is disabled */
  FCLCON6bits.FLTMOD = 3;

  PHASE6 = 0;
  PDC6 = 0;

   /***********************************************
   * PWM 7 Configuration -- LLC SR SLAVE driver
   **********************************************/
#if DEBUG_DISABLE_SR
  IOCON7bits.PENH = 0;
  IOCON7bits.PENL = 0;
#else
  /* PWM module controls PWMxH pin */
  IOCON7bits.PENH = 0;
  /* PWM module controls PWMxL pin */
  IOCON7bits.PENL = 0;
#endif
  /* Push-Pull Mode the period = PTPER * 2  , duty = PTPER - LLCDEADTIME */
  IOCON7bits.PMOD = 2;
  /* PWMxH and PWMxL pins are mapped to their respective pins */
  IOCON7bits.SWAP = 0;
  /* State(2) for PWMxH and PWMxL Pins if CLMOD is Enabled bits */
  IOCON7bits.CLDAT = 0;

  /* Dead time disabled added into duty cycle */
  PWMCON7bits.DTC = 0;
  /* Select Independent Time base mode */
  PWMCON7bits.ITB = 0;
  /* Updates to the active MDC/PDCx/SDCx registers are immediate */
  PWMCON7bits.IUE = 1;
  /* Normal Fault mode */
  FCLCON7bits.IFLTMOD = 0;
  /* Current-Limit mode is disabled */
  FCLCON7bits.CLMOD = 0;
  /*Fault input is disabled */
  FCLCON7bits.FLTMOD = 3;

  PHASE7 = 0;
  PDC7 = 0;
}


