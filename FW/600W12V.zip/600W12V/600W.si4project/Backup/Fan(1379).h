#ifndef __FAN_H__
#define __FAN_H__

#include "Define.h"

#define FAN_PWM_PERIOD			19230	//max duty
#define FAN_PWM_DEFAULT_DUTY	9615	//, modify for customer request	//3846	//mapping to 20.66% duty --> 3000rpm Nidec V60E 12BS6C3
#define FAN_MAX_RPM				14000	//max rpm

#define FAN_ADJ_PRI_TEMP_H			75		//75 degree
#define FAN_ADJ_PRI_TEMP_L			65		//65 degree
#define FAN_ADJ_SEC_TEMP_H			87		//82 degree
#define FAN_ADJ_SEC_TEMP_L			67		//65 degree

typedef struct _FAN_CNTL
{
  WORD TargetDuty ;
  WORD TargetRpm ;
  WORD CurrentDuty ;
  WORD CurrentRpm ;
  BYTE Detected ;
  WORD OverridedDuty ;
  WORD minDuty ;
  DWORD PwmH_Cnt ;
  DWORD PwmL_Cnt ;
} tFAN_CNTL ;

extern tFAN_CNTL gFan1 ;
extern tFAN_CNTL gFan2 ;

/*Exported function*/
void init_Fan ( ) ;
void UpdateFanDuty ( ) ;
void DisableFan ( ) ;
void EnableFan ( ) ;
BYTE    LoadHysteresis();//20170707 Added Fan Issue modify
BYTE    TempHysteresis();//20170707 Added Fan Issue modify

WORD GetFanMinDuty ( ) ;
void CheckICAOV ( ) ;
void CalcFanTargetSpeed ( BYTE ratio ) ;




#endif //

