
#include "Led.h"
#include "Timer.h"
#include "Pmbus.h"
#include "Process.h"
#include "Sci.h"

static BYTE gSysCntl;
tLED_STATUS gLedStatus;
// tLED_WARNING_STATUS gLedWarningStatus;
tINPUT_LED_STATUS gInputLedStatus;

extern tPS_FLAG PS;

void init_Led ( )
{
  gSysCntl = FALSE;
  gLedStatus.Val = 0;
}

static void SetLedBlinkGreen ( )
{
  static BYTE onoff = ON;
  if ( onoff )
  {
	  drv_o_LED_ON;
  }
  else
  {
	  drv_o_LED_DIS;
  }
  onoff = ! onoff;
}




#if 0
static void LedControl ( BYTE status )
{
  static BYTE ghLedTimer = 0;
  static BYTE previous_status = 0;

  if ( status != previous_status )
  {
      if ( ghLedTimer )
      {
          KillTimer ( &ghLedTimer );
      }

      switch ( status )
      {
          case SOLID_GREEN:
              SetLedGreen ( );
              break;
          case SOLID_YELLOW:
              SetLedYellow ( );
              break;
          case ALTERNATED:
              ghLedTimer = SetTimer ( LED_BLINK_FREQ, SetLedAlternated );
              break;
          case BLINK:
              ghLedTimer = SetTimer ( LED_BLINK_FREQ, SetLedBlink );
              break;
          case BLINK_GREEN:
              ghLedTimer = SetTimer ( LED_BLINK_FREQ, SetLedBlinkGreen );	// 1 Hz
              break;
          case BLINK_YELLOW:
              ghLedTimer = SetTimer ( LED_BLINK_FREQ, SetLedBlinkYellow );	// 1 Hz
              break;
          case LED_OFF:
              SetLedOff ( );
              break;
          case BLINK_GREEN_TYPE2:
              ghLedTimer = SetTimer ( LED_BLINK_FREQ_TYPE2, SetLedBlinkGreen );	// 0.5 Hz
              break;
          case BLINK_YELLOW_TYPE2:
              ghLedTimer = SetTimer ( LED_BLINK_FREQ_TYPE2, SetLedBlinkYellow );	// 0.5 Hz
              break;
          case BLINK_YELLOW_TYPE3:
              ghLedTimer = SetTimer ( LED_BLINK_FREQ_TYPE3, SetLedBlinkYellow ); // 0.2 Hz
              break;

          default:
              break;
      }
  }

  previous_status = status;
}
#endif

static void InputLedControl ( BYTE status )
{
  static BYTE ghLedTimer = 0;
  static BYTE previous_status = 0;

  if ( status != previous_status )
  {
      if ( ghLedTimer )
      {
          KillTimer ( &ghLedTimer );
      }

      switch ( status )
      {
          case SOLID_GREEN:
              oLED_INPUT_CNTL = LED_INPUT_ON;
              break;
          case BLINK_GREEN:
              ghLedTimer = SetTimer ( LED_BLINK_FREQ, SetInputLedBlinkGreen );	// 1 Hz
              break;
          case LED_OFF:
              oLED_INPUT_CNTL = LED_INPUT_OFF;
              break;

          default:
              break;
      }
  }

  previous_status = status;
}



void Led_PSU_Control (BYTE status  )
{

  static BYTE ghLedTimer = 0;
  static BYTE previous_status = 0;
  
   if ( status != previous_status )
   {
	   if ( ghLedTimer )
	   {
		   KillTimer ( &ghLedTimer );
	   }

  if ( gLedStatus.bits.ac_lost )
  {
      drv_o_LED_DIS;
  }
  else if ( gLedStatus.bits.Power_ok )
  {
     drv_o_LED_ON;
  }
  else if ( gLedStatus.bits.stb_blinking )
  {
      ghLedTimer = SetTimer ( LED_BLINK_FREQ, SetLedBlinkGreen );	// 1 Hz
  }

  previous_status = status;
 }

 
}


