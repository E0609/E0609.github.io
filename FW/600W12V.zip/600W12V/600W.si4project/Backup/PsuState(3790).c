/******************************************************************************
 * \file    PsuState.c
 * \brief   State machine control of PSU
 *
 * \section AUTHOR
 *    1. CIPS
 *
 * \section SVN
 *  $Date$
 *  $Author$
 *  $Revision$
 *
 * \section LICENSE
 * Copyright (c) 
 * All rights reserved.
 *******************************************************************************/

/*******************************************************************************
 * Included header
 ******************************************************************************/

#include "DataFormat.h"

/* Module header */
#include "Rtv.h"
#include "Protection.h"
#include "McuAdc.h"
#include "McuPwm.h"
#include "PsuState.h"
#include "Rtv_Uart.h"
#include "McuGPIO.h"
#include "llc_ctrl.h"
#include "Crc.h"
/*******************************************************************************
 * Local constants and macros (private to module)
 ******************************************************************************/

#define PSU_PW_TURNON_DLY  21000
#define MG_V1_TURN_OFF_DLY   5  


/*******************************************************************************
 * Local data (private to module)
 ******************************************************************************/
static MG_V1_CTRL_STA PSU_mg_V1_state_ctrl = PSU_CTRL_V1_OFF;
static uint16 psu_mg_u16V1TurnOnDly = 0;
/*******************************************************************************
 * Local function prototypes (private to module)
 ******************************************************************************/

/*******************************************************************************
 * DataFormat data
 ******************************************************************************/

/*******************************************************************************
 * DataFormat data types (public typedefs / structs / enums)
 ******************************************************************************/

/*******************************************************************************
 * DataFormat functions (public to other modules)
 ******************************************************************************/
void PSUstate_DataInit(void);
void PSUstate_V1OnOffJudge(void);

/*******************************************************************************
 * \brief         Initialize PSU State control data
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PSUstate_DataInit(void)
{
  PSU_mg_V1_state_ctrl = PSU_CTRL_V1_OFF;
  psu_mg_u16V1TurnOnDly = PSU_PW_TURNON_DLY;
}/* PSUstate_DataInit */

/*******************************************************************************
 * \brief         control V1 status
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PSUstate_V1StatusControl(void)
{
  static uint16 u16V1_PwrUpDly = 0;
  static uint16 u16V1_OutputOKDly = 0;

  PSUstate_V1OnOffJudge();

  switch (PSU_mg_V1_state_ctrl) {
  case PSU_CTRL_V1_OFF:
  {
    PSU_mg_V1PwrOff();

    if (psu_mg_u16V1TurnOnDly > 0)
    {
      psu_mg_u16V1TurnOnDly--;
    }
    else
    {
      if ((FALSE != FLG_V1_PRISYS_CONDITION)
      && (FALSE == FLG_V1_FAULT_CONDITION))
      {
        PSU_mg_V1PwrOn();
        u16V1_PwrUpDly = 0;
        PSU_mg_V1_state_ctrl = PSU_CTRL_V1_RUN;
      }
    }
    u16StartMonV1UvpCnt = 0;
    PROTECT_V1Volt();
    break;
  }
  case PSU_CTRL_V1_RUN:
  {
    PROTECT_V1Volt();
    u16StartMonV1UvpCnt = 0;
    
    if ((FALSE == FLG_V1_PRISYS_CONDITION)
      || (FALSE != FLG_V1_FAULT_CONDITION))
    {
      PSU_mg_V1PwrOff();
      u16V1_PwrUpDly = 0;
      u16V1_OutputOKDly = 0;
      PSU_mg_V1_state_ctrl = PSU_CTRL_V1_OFF;
      psu_mg_u16V1TurnOnDly = PSU_PW_TURNON_DLY;
    }
    break;
  }

  default:
  {
    PSU_mg_V1_state_ctrl = PSU_CTRL_V1_OFF;
    break;
  }
  }
  
}

/*******************************************************************************
 * \brief         control psu on
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PSU_mg_V1PwrOn(void)
{
  FLG_B_V1_STATE = ON;
  PORT_OUT_V1_OUTPUT_EN;
  PORT_OUT_V1_ORING_EN;
  PWM_V1_FB_ENABLE_H_REG = 1;
  PWM_V1_FB_ENABLE_L_REG = 1;
  PWM_SR_M12_ENABLE_H_REG = 1;
  PWM_SR_M12_ENABLE_L_REG = 1;
}

/*******************************************************************************
 * \brief         control psu off
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PSU_mg_V1PwrOff(void)
{
  FLG_B_V1_STATE = OFF;
  PORT_OUT_V1_OUTPUT_DIS;
  PORT_OUT_V1_ORING_DIS;
}


/*******************************************************************************
 * \brief         control psu V1 start judge
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PSUstate_V1OnOffJudge(void)
{
  static uint16 mg_u16V1FaultTurnOffDly = 0;
  static uint16 mg_u16V1TurnOffDly = 0;
  


  if ((FALSE == FLG_B_V1_FAULT_LATCH) &&
      (FALSE == FLG_B_LLC_V1_FW_OVP) &&
      (FALSE == FLG_B_LLC_V1_OCP)
      )     
  {
    FLG_V1_FAULT_CONDITION = 0; 
    mg_u16V1FaultTurnOffDly = 0;
  }
  else
  {
    if (FALSE != FLG_B_LLC_V1_FW_OVP) 
    {
      mg_u16V1FaultTurnOffDly = 0;
      FLG_B_V1_PWOK_GOOD = FALSE;
      FLG_B_V1_FAULT_LATCH = 1;
      FLG_V1_FAULT_CONDITION = 1;
    }
    else
    {
      if (mg_u16V1FaultTurnOffDly > MG_V1_TURN_OFF_DLY)
      {
        FLG_V1_FAULT_CONDITION = 1;
      }
      else
      {
        mg_u16V1FaultTurnOffDly++;
        FLG_B_V1_PWOK_GOOD = FALSE;
      }
    }
  }
  
  
  if (FALSE != FLG_B_PSON_ENABLE)
  {
    mg_u16V1TurnOffDly = 0;
    FLG_V1_PRISYS_CONDITION = 1;
  }
  else
  {
    if (mg_u16V1TurnOffDly > MG_V1_TURN_OFF_DLY)
    {
      FLG_V1_PRISYS_CONDITION = 0;
    }
    else
    {
      mg_u16V1TurnOffDly++;
      FLG_B_V1_PWOK_GOOD = FALSE;
    }
  }
}



