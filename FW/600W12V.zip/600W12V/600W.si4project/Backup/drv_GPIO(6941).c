/** *****************************************************************************
 * \file    McuGPIO.c
 * \brief   MCU IO port configurations
 *
 * \section AUTHOR
 *    1. CIPS
 *
 * \section SVN
 *  $Date$
 *  $Author$
 *  $Revision$
 *
 * \section LICENSE
 * Copyright (c) Lite-On Singapore Pte Ltd
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * Included header
 ******************************************************************************/

/* Module header */
#include "McuGPIO.h"

/*******************************************************************************
 * Local constants and macros (private to module)
 ******************************************************************************/

/*******************************************************************************
 * Local data types (private DataFormats / structs / enums)
 ******************************************************************************/

/*******************************************************************************
 * Local data (private to module)
 ******************************************************************************/

/*******************************************************************************
 * DataFormat data (public to other modules)
 ******************************************************************************/

/*******************************************************************************
 * Local function prototypes (private to module)
 ******************************************************************************/

/*******************************************************************************
 * DataFormat functions (public to other modules)
 ******************************************************************************/

/*******************************************************************************
 * Local functions (private to module)
 ******************************************************************************/
static void port_A_config(void);
static void port_B_config(void);
static void port_C_config(void);



/*******************************************************************************
 * Name:         Mcu_GPIOHwInit
 * Description:  gpio direction/analogue configuration
 * param[in]     -
 * param[in,out] -
 * param[out]  
 * return value:
 * Author:
 * Version:
 * Date:
 * History:
 *******************************************************************************/

void Mcu_GPIOHwInit(void)
{
  /* Set PORT as input or output    * 1 = input (default)   * 0 = output */

    port_A_config();
    port_B_config();
	port_C_config();
}
/*******************************************************************************
 * Name:         
 * Description:  
 * param[in]:     
 * param[in,out]: 
 * param[out]:  
 * return value:
 * Author:
 * Version:
 * Date:
 * History:
 *******************************************************************************/

static void port_A_config()
{
   LATA = 0x0000;
   TRISA = 0xffff;   
   ANSELA = 0x0000; 
   
  /* PIN13 for  PSON*/
   _TRISA3 = MG_PIN_INPUT_DIRECTION;
  /* PIN21 for  12V_ORING_MCU*/
   _TRISA0 = MG_PIN_INPUT_DIRECTION;
   _ANSA0 = MG_PIN_ANALOG;
  /* PIN22 for  I_OUT_MCU*/
   _TRISA1 = MG_PIN_INPUT_DIRECTION;
   _ANSA1 = MG_PIN_ANALOG;
  /* PIN23 for  12V_OUT_MCU*/
   _TRISA2 = MG_PIN_INPUT_DIRECTION;
   _ANSA2 = MG_PIN_ANALOG;

} 
/*******************************************************************************
 * Name:         Mcu_GPIOHwInit
 * Description:  gpio direction/analogue configuration
 * param[in]     -
 * param[in,out] -
 * param[out]  
 * return value:
 * Author:
 * Version:
 * Date:
 * History:
 *******************************************************************************/

static void port_B_config()
{
   LATB = 0x0000;
   TRISB = 0xffff;   
   ANSELB = 0x0000;
   
   /* PIN24 for  ISHARE_IN*/
   _TRISB0 = MG_PIN_INPUT_DIRECTION;
   _ANSB0 = MG_PIN_ANALOG;

   
   /* PIN33 for  T_SR_MCU*/
   _TRISB2 = MG_PIN_INPUT_DIRECTION;
   _ANSB2 = MG_PIN_ANALOG;

   /* Reserved DACOUT  Pin 34*/
   _TRISB3 = MG_PIN_INPUT_DIRECTION;
   _ANSB3 = MG_PIN_ANALOG;

   /* PIN35 for  ISHARE_DIS*/
   _TRISB4 = MG_PIN_INPUT_DIRECTION;
   /* PIN43 for  LED1*/
   _TRISB5 = MG_PIN_OUTPUT_DIRECTION;
   /* SDA_INTERNAL Pin39*/
   _TRISB8 = MG_PIN_INPUT_DIRECTION; 
   /* PIN25 for  STB_5V_OUT_MCU*/
   _TRISB9 = MG_PIN_INPUT_DIRECTION;
   _ANSB9 = MG_PIN_ANALOG;
   /* PIN26 for  STB_I_OUT_MCU*/
   _TRISB10 = MG_PIN_INPUT_DIRECTION;
   _ANSB10 = MG_PIN_ANALOG;
 
  /* PIN8 for  ORING_EN_MCU*/
   _TRISB11 = MG_PIN_OUTPUT_DIRECTION;
  /* PIN9 for  POK*/
   _TRISB12 = MG_PIN_OUTPUT_DIRECTION;
  /* PIN11 for  FAN SPEED*/
   _TRISB14 = MG_PIN_INPUT_DIRECTION;
}
/*******************************************************************************
 * Name:         Mcu_GPIOHwInit
 * Description:  gpio direction/analogue configuration
 * param[in]     -
 * param[in,out] -
 * param[out]  
 * return value:
 * Author:
 * Version:
 * Date:
 * History:
 *******************************************************************************/

static void port_C_config()
{
    LATC = 0x0000;
	TRISC = 0xffff;   
	ANSELC = 0x0000;
  /* PIN 14 for  AC_OK_SEC*/
   _TRISC0 = MG_PIN_INPUT_DIRECTION;
  /* PIN 5,2,3 for I2C Address selection*/
   _TRISC3 = MG_PIN_INPUT_DIRECTION;
   _TRISC4 = MG_PIN_INPUT_DIRECTION;
   _TRISC5 = MG_PIN_INPUT_DIRECTION;
  /* PIN 4 for PFC_OK_SEC*/
   _TRISC6 = MG_PIN_INPUT_DIRECTION;

  /* PMBUS_SDA Pin37 */
  _TRISC7 = MG_PIN_INPUT_DIRECTION;
  /* PMBUS_SCL Pin38 */
  _TRISC8 = MG_PIN_INPUT_DIRECTION;
  
  /* UART_RX Pin27 */
	_TRISC9 = MG_PIN_INPUT_DIRECTION;
  /* UART_TX Pin28 */
	_TRISC10 = MG_PIN_OUTPUT_DIRECTION;
   
  /* PIN 19 for STB_ORING_EN_MCU*/
   _TRISC11 = MG_PIN_OUTPUT_DIRECTION;
  /* PIN 20 for SR_EN_MCU*/
   _TRISC12 = MG_PIN_OUTPUT_DIRECTION;
  /* PIN 15 for LLC_DIS*/
   _TRISC13 = MG_PIN_OUTPUT_DIRECTION;

   /*
   * Set PORTx as open-drain or push-pull
   * 1 = open-drain (5V)
   * 0 = push-pull  (default)
   */
   #if 0
  ODCCbits.ODCC8 = 1; // uC_SCL
  ODCCbits.ODCC7 = 1; // uC_SDA
  ODCCbits.ODCC15 = 1; //uC_SDA_Internal
  ODCBbits.ODCB3 = 1; //uC_SCL_Internal
  #endif
  _ODCC8 = 1;  // uC_SCL
  _ODCC7 = 1;  // uC_SDA
  _ODCB8= 1;   //uC_SDA_Internal
  _ODCB15 = 1; //uC_SCL_Internal
  
}


#if Config_Input_CN       //20160427 added Input Change Notification
//---------------------------------- init_Input_CN ----------------------------------------------
void init_Input_CN ( void )     
{
    CNENCbits.CNIEC6 = 1; // pfc
    CNENCbits.CNIEC0 = 1; // ac
    CNENAbits.CNIEA3 = 1; //PSON
	
    IEC1bits.CNIE = 1; // Enable CN interrupts
    IFS1bits.CNIF = 0; // Reset CN interrupt
}
#endif


