/* 
 * File:   McuAdc.h
 * Author: CIPS
 *
 * Created on 29 September, 2020, 10:50 AM
 */

#ifndef MCUADC_H
#define	MCUADC_H

#ifdef	__cplusplus
extern "C" {
#endif


    /*******************************************************************************
     * Global data types (globals / structs / enums)
     ******************************************************************************/
    /* V1 sample for loop calculation */
#define ADC_V1_VOLT_EXT      ADCBUF4    /* V1 feedback voltage after oring */
#define ADC_V1_VOLT_VEA      ADCBUF1    /* V1 feedback voltage before oring for control loop */
#define ADC_I1_CURR          ADCBUF3    /* V1 output current */
#define ADC_REF_2V5          ADCBUF17
    
    /* Ilocal and Ishare sample for current share */
#define ADC_I1_VOLT_LOCAL    ADCBUF2    /* iLocal sample for current share */
#define ADC_I1_VOLT_SHARE    ADCBUF0    /* iLocal sample for current share */

    /* NTC and others sample */
#define ADC_NTC_LLC          ADCBUF9     /* LLC PRI temperature sample*/
#define ADC_NTC_XFMR         ADCBUF10    /* XFMR temperature sample*/ 
#define ADC_NTC_SR           ADCBUF11    /* SR temperature sample*/
#define ADC_NTC_CONN         ADCBUF14    /* Connector temperature sample*/
    /*******************************************************************************
     * Global function prototypes
     ******************************************************************************/

    extern void Mcu_ADCHwInit(void);
    extern void Mcu_CMPHwInit(void);


#ifdef	__cplusplus
}
#endif

#endif	/* MCUADC_H */

