/** *****************************************************************************
 * \file    McuClock.c
 * \brief   MCU clock configuration
 *
 * \section AUTHOR
 *    1. CIPS
 *
 * \section SVN
 *  $Date$
 *  $Author$
 *  $Revision$
 *
 * \section LICENSE
 * Copyright (c) Lite-On Singapore Pte Ltd
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * Included header
 ******************************************************************************/
#include <p33EP128GS708.h>

/* Module header */
#include "drv_Clock.h"
#include "Rtv.h"
/*******************************************************************************
 * Local constants and macros (private to module)
 ******************************************************************************/

/* CONFIGURATION REGISTERS SETTINGS */
//_FBS(BWRP_WRPROTECT_ON & BSS_LARGE_FLASH_STD)   

#if defined(FRC_OSC)
/* Fast RC internal oscillator (FRC) w/PLL, start with FRC and then switch */
// FOSCSEL
#pragma config FNOSC = FRCPLL           // Oscillator Source Selection (Fast RC Oscillator with divide-by-N with PLL module (FRCPLL) )
#pragma config IESO = ON                // Two-speed Oscillator Start-up Enable bit (Start up device with FRC, then switch to user-selected oscillator source)
 
#elif defined(PRIM_OSC)
/* Primary oscillator (XT, HS, EC) w/PLL, start with FRC and then switch */
// FOSCSEL
#pragma config FNOSC = PRIPLL           // Oscillator Source Selection (Fast RC Oscillator with divide-by-N with PLL module (FRCPLL) )
#pragma config IESO = ON                // Two-speed Oscillator Start-up Enable bit (Start up device with FRC, then switch to user-selected oscillator source)
#else
#error No oscillator type selected!
#endif
        
/* POR timer value (128ms) */
//_FPOR(FPWRT_PWR128)

/* Oscillator switch enable monitor disable, oscillator pin used as IO */
// FOSC
#pragma config OSCIOFNC = ON            // OSC2 Pin Function bit (OSC2 is general purpose digital I/O pin)
#pragma config FCKSM = CSECMD           // Clock Switching Mode bits (Clock switching is enabled,Fail-safe Clock Monitor is disabled)
/* Watchdog disable */
// FWDT
#pragma config WDTPOST = PS1            // Watchdog Timer Postscaler bits (1:1)
#pragma config WDTPRE = PR128           // Watchdog Timer Prescaler bit (1:128)
#pragma config WDTEN = SWDTEN           // Watchdog Timer Enable bits (WDT Enabled) //  128 * 1 / 32kHz = 4ms
//#pragma config FWDTEN = ON
// FICD
#pragma config ICS = PGD1               // ICD Communication Channel Select bits (Communicate on PGEC1 and PGED1)
#pragma config JTAGEN = OFF             // JTAG Enable bit (JTAG is disabled)

// FDEVOPT
#pragma config PWMLOCK = OFF            // PWMx Lock Enable bit (PWM registers may be written without key sequence)
#pragma config ALTI2C1 = ON             // Alternate I2C1 Pin bit (I2C1 mapped to ASDA1/ASCL1 pins)
#pragma config ALTI2C2 = ON             // Alternate I2C2 Pin bit (I2C2 mapped to ASDA2/ASCL2 pins)


// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.
/*******************************************************************************
 * Global function definition
 ******************************************************************************/
void Mcu_SysClkHwInit(void);

/*******************************************************************************
 * \brief         Initialize the System and the MCU Clock
 *                Called by startup in main
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 ******************************************************************************/
void Mcu_SysClkHwInit(void)
{
  /* Initialize Fosc */
#if defined(FRC_OSC)
  /* Oscillator configuration
   *  Configure Oscillator to operate the device at 60Mhz
   *  Fosc= Fin * M / (N1 * N2), Fcy = Fosc / 2
   *  Fosc= 7.37MHz * 65 / (2 * 2) = 119.7625Mhz for Fosc, Fcy = 59.88125Mhz
   */

  /* Configure PLL prescaler, PLL postscaler, PLL divisor */
  PLLFBD = 63; /* M = PLLDIV + 2 = 65 */
  CLKDIVbits.PLLPOST = 0; /* N2 = 2 * (PLLPOST + 1) = 2 */
  CLKDIVbits.PLLPRE = 0; /* N1 = PLLPRE + 2 = 2 */
  __builtin_write_OSCCONH(0x01); /* New Oscillator FRC w/ PLL */
  __builtin_write_OSCCONL(0x01); /* Enable Switch */

  /* Wait for new Oscillator to become FRC w/ PLL */
  while (OSCCONbits.COSC != 0b001);
  /* Wait for Pll to Lock */
  while (OSCCONbits.LOCK != 1);
#endif
  // Setup the ADC and PWM clock for 120MHz
  // ((FRC * 16) / APSTSCLR ) = (7.37MHz * 16) / 1 = 117.92MHz

  ACLKCONbits.FRCSEL = 1; // FRC provides input for Auxiliary PLL (x16)
  ACLKCONbits.SELACLK = 1; // Aux Osc. provides clock source for PWM & ADC
  ACLKCONbits.APSTSCLR = 7; // Divide Auxiliary clock by 1
  ACLKCONbits.ENAPLL = 1; // Enable Auxiliary PLL

  while (ACLKCONbits.APLLCK != 1); // Wait for Auxiliary PLL to Lock
}


//===========================================================================
// End of file.
//===========================================================================







