/* 
 * File:   McuGPIO.h
 * Author: edwin 
 * Description : Interface for GPIO
 * 
 * Created on 29 September, 2020, 1:59 PM
 * 
 * \section LICENSE
 * Copyright (c) 
 * All rights reserved.
 */

#ifndef MCUGPIO_H
#define	MCUGPIO_H

#ifdef	__cplusplus
extern "C" {
#endif

#include <p33EP64GS504.h>
#include "DataFormat.h"
#include "Rtv.h"

    /*******************************************************************************
     * Local constants and macros (private to module)
     ******************************************************************************/
#define MG_PIN_INPUT_DIRECTION    1         //Microchip Pin Input Direction
#define MG_PIN_OUTPUT_DIRECTION   0

#define MG_PIN_ANALOG             1         //Microchip Pin Analog Select
#define MG_PIN_DIGITAL            0

#define MG_PIN_OUTPUT_HIGH        1
#define MG_PIN_OUTPUT_LOW         0

    /*********************** Digital output pin register ***********************************/
//#define DIO_PFC_OFF                       _LATC6 // pfc_ok   
#define pin_o_ISHARE_DIS                    _LATB4
#define pin_o_ORING_EN_MCU                  _LATB11  
#define pin_o_LLC_EN_MCU                    _LATC13  
#define pin_o_STB_EN_MCU                     _LATC11 



    /**************** set digital output pin High/Low status  ******************************/
#define drv_o_ISHARE_EN           { pin_o_ISHARE_DIS = 0;\
                                          FLG_DO_V1_ISHARE_ON = 1; }
#define drv_o_ISHARE_DIS           { pin_o_ISHARE_DIS = 1;\
                                          FLG_DO_V1_ISHARE_ON = 0; }
#define drv_o_ORING_EN            { pin_o_ORING_EN_MCU = 1;\
                                          FLG_DO_V1_ORING_CTRL_EN = 1; }
#define drv_o_ORING_DIS           { pin_o_ORING_EN_MCU = 0;\
                                          FLG_DO_V1_ORING_CTRL_EN = 0; }
#define drv_o_LLC_EN               { pin_o_LLC_EN_MCU = 1;\
										FLG_DO_V1_ORING_CTRL_EN = 1; }
#define drv_o_LLC_DIS              { pin_o_LLC_EN_MCU = 0;\
											  FLG_DO_V1_ORING_CTRL_EN = 0; }
#define drv_o_STB_EN               { pin_o_STB_EN_MCU  = 1;\
											FLG_DO_V1_ORING_CTRL_EN = 1; }
#define drv_o_STB_DIS              { pin_o_STB_EN_MCU  = 0;\
												  FLG_DO_V1_ORING_CTRL_EN = 0; }

#define drv_o_LED_ON               { pin_o_LED_ON  = 0;\
											     FLG_DO_V1_LED_EN = 0; }
#define drv_o_LED_DIS              { pin_o_LED_ON  = 1;\
													 FLG_DO_V1_LED_EN = 1; }


    /******************** Digital input pin register ********************************/
#define DIO_VIN_OK_FRO_PRI_HIP            _RC0 //AC OK  
#define DIO_BULK_OK_FRO_PRI_HIP           _RC6 // PFC OK    
#define DIO_V1_PSON_ACTIVE_HIP            _RA3   
    /**************** set digital input pin High/Low status  *******************************/
#define PORT_IN_VIN_FRO_PRI_IS_OK        ( FALSE == DIO_VIN_OK_FRO_PRI_HIP )
#define PORT_IN_VIN_FRO_PRI_IS_NO_OK     ( FALSE != DIO_VIN_OK_FRO_PRI_HIP )
#define PORT_IN_VBULK_FRO_PRI_IS_OK      ( FALSE == DIO_BULK_OK_FRO_PRI_HIP )
#define PORT_IN_VBULK_FRO_PRI_IS_NO_OK   ( FALSE != DIO_BULK_OK_FRO_PRI_HIP )
#define PORT_IN_PSON_IS_ACTIVE           ( FALSE == DIO_V1_PSON_ACTIVE_HIP )
#define PORT_IN_PSON_IS_INACTIVE         ( FALSE != DIO_V1_PSON_ACTIVE_HIP )
    /*******************************************************************************
     * DataFormat data types (DataFormats / structs / enums)
     ******************************************************************************/

    /*******************************************************************************
     * DataFormat data types (typedefs / structs / enums)
     ******************************************************************************/

    /*******************************************************************************
     * DataFormat function prototypes (public to other modules)
     ******************************************************************************/
    extern void Mcu_GPIOHwInit(void);


#ifdef	__cplusplus
}
#endif

#endif	/* MCUGPIO_H */

