#ifndef __LED_H__
#define __LED_H__

#include "Define.h"




#if 1
#define LED_BLINK_FREQ			500 //ms
#define LED_BLINK_FREQ_TYPE2	250	//ms
#define LED_BLINK_FREQ_TYPE3	100	//ms

// 20101013 updated for X04-00
typedef union _LED_STATUS
{
  BYTE Val ;

  struct
  {
    unsigned ac_lost : 1 ;
    unsigned Power_ok : 1 ;
    unsigned stb_blinking : 1 ;
    unsigned b3 : 1 ;
    unsigned b4 : 1 ;
    unsigned b5 : 1 ;       //20160503 added primary and secondary side communication error
    unsigned b6: 1 ;               //20160503 added primary and secondary side communication error
    unsigned b7 : 1 ;
  } bits ;
} tLED_STATUS ;

extern tLED_STATUS gLedStatus ;


/*Exported function*/
void init_Led ( ) ;
void tsk_Led_PSU_Control ( ) ;




#endif


#endif //

