/* 
 * File:   PsuState.h
 * Author: CIPS
 *
 * Created on 8 October, 2020, 4:56 PM
 */

#ifndef PSUSTATE_H
#define	PSUSTATE_H

#
ifdef	__cplusplus
extern "C" {
#endif


    /*******************************************************************************
     * Included header
     ******************************************************************************/
#include "DataFormat.h"
#include "McuGPIO.h"
    /*******************************************************************************
     * Local constants and macros (private to module)
     ******************************************************************************/

    
  

    /*******************************************************************************
     * DataFormat data types (DataFormats / structs / enums)
     ******************************************************************************/

    typedef enum MG_V1_CTRL_STA_ {
        PSU_CTRL_V1_OFF = 0,
        PSU_CTRL_V1_UP,
        PSU_CTRL_V1_RUN,
    } MG_V1_CTRL_STA;


 
    /*******************************************************************************
     * DataFormat data
     ******************************************************************************/


    /*******************************************************************************
     * DataFormat function prototypes
     ******************************************************************************/
    extern void PSU_mg_V1PwrOn(void);
    extern void PSU_mg_V1PwrOff(void);
    extern void PSUstate_V1StatusControl(void);
    extern void PSUstate_DataInit();

#ifdef	__cplusplus
}
#endif

#endif	/* PSUSTATE_H */

