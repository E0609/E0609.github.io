/* 
 * File:   Timer_ISR.h
 * Author: CIPS
 *
 * Created on 2 October, 2020, 3:49 PM
 */

#ifndef TIMER_ISR_H
#define	TIMER_ISR_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "DataFormat.h"      
    /*******************************************************************************
     * DataFormat constants and macros (public to other modules)
     ******************************************************************************/
    extern uint8 u8CTOCCnt;


    /*******************************************************************************
     * DataFormat function prototypes (public to other modules)
     ******************************************************************************/
    extern void TIMER_SchDataInit(void);
    

#ifdef	__cplusplus
}
#endif

#endif	/* TIMER_ISR_H */



