/* 
 * File:   McuAdc.h
 * Author: CIPS
 *
 * Created on 29 September, 2020, 10:50 AM
 */

#ifndef MCUADC_H
#define	MCUADC_H

#ifdef	__cplusplus
extern "C" {
#endif


    /*******************************************************************************
     * Global data types (globals / structs / enums)
     ******************************************************************************/
  #if 0
    /* V1 sample for loop calculation */
#define ADC_V1_VOLT_EXT      ADCBUF4    /* V1 feedback voltage after oring */
#define ADC_V1_VOLT_VEA      ADCBUF1    /* V1 feedback voltage before oring for control loop */
#define ADC_I1_CURR          ADCBUF3    /* V1 output current */
#define ADC_REF_2V5          ADCBUF17
    
    /* Ilocal and Ishare sample for current share */
#define ADC_I1_VOLT_LOCAL    ADCBUF2    /* iLocal sample for current share */
#define ADC_I1_VOLT_SHARE    ADCBUF0    /* iLocal sample for current share */

    /* NTC and others sample */
#define ADC_NTC_LLC          ADCBUF9     /* LLC PRI temperature sample*/
#define ADC_NTC_XFMR         ADCBUF10    /* XFMR temperature sample*/ 
#define ADC_NTC_SR           ADCBUF11    /* SR temperature sample*/
#define ADC_NTC_CONN         ADCBUF14    /* Connector temperature sample*/
#else
/*
21           AN0            12V_ORING_MCU      0V/0Vdc ~ 16.23V/3.3Vdc 
22           AN1                 I_OUT_MCU           0A/0V    ~    ? 60A/3.3V 
23           AN2               12V_OUT_MCU         0V/0Vdc ~ 16.23V/3.3Vdc 
24           AN3                  ISHARE_IN            0A/0V ~ ? 10.584V/3.3V 
25           AN4           STB_5V_OUT_MCU     0A/0V ~ 6V/3.3V 
26           AN5             STB_I_OUT_MCU       0A/0V ~ 0.5A/3.3V 
32           AN6               CS_OUT_READ         0A/0V ~ ? A/3.3V 
33           AN7                   T_SR_MCU            10K NTC 

*/
/* Ilocal and Ishare sample for current share */
#define ADC_12V_ORING    ADCBUF0    
#define ADC_I_OUT        ADCBUF1    
#define ADC_12V_OUT      ADCBUF2    
#define ADC_ISHARE_IN    ADCBUF3 
#define ADC_STB_5V_OUT   ADCBUF4    
#define ADC_STB_I_OUT    ADCBUF5 
#define ADC_CS_OUT_READ  ADCBUF6 
#define ADC_T_SR_MCU     ADCBUF7



#endif
    /*******************************************************************************
     * Global function prototypes
     ******************************************************************************/

    extern void Mcu_ADCHwInit(void);
    extern void Mcu_CMPHwInit(void);


#ifdef	__cplusplus
}
#endif

#endif	/* MCUADC_H */

