/** *****************************************************************************
 * \file    Rtv.c
 * \brief  
 *
 * \section AUTHOR
 *    1. CIPS
 *
 * \section SVN
 *  $Date$
 *  $Author$
 *  $Revision$
 *
 * \section LICENSE
 * Copyright (c) 
 * All rights reserved.
 ***************************************************************************** */

/*******************************************************************************
 * Included header
 ******************************************************************************/

#include "global.h"

/* Module header */
#define RTV_EXPORT_H
#include "Rtv.h"
#include "McuClock.h"
#include "McuAdc.h"
#include "McuGPIO.h"
#include "McuPwm.h"
#include "llc_ctrl.h"
/*******************************************************************************
 * Global data
 ******************************************************************************/

/*******************************************************************************
 * Local data types (private typedefs / structs / enums)
 ******************************************************************************/

/*******************************************************************************
 * Local constants and macros (private to module)
 ******************************************************************************/

/*******************************************************************************
 * Local data (private to module)
 ******************************************************************************/
uint16 u16q12VinAdcAvgPri;
uint16 u16q12IinAdcAvgPri;
uint16 u16q12PinAdcAvgPri;
uint16 u16q12VbulkAdcAvgPri;
ST_INTCOM1_DATA stIntcom1_PriA;

GLOBAL_U_U16BIT uComStatus00;
GLOBAL_U_U16BIT uComStatus01;
GLOBAL_U_U16BIT uComStatus02;

GLOBAL_U_U16BIT uDioInStatus;
GLOBAL_U_U16BIT uDioOutStatus;
GLOBAL_U_U16BIT uPsuCtrlTrimStatus;
/*******************************************************************************
 * Global functions (public to other modules)
 ******************************************************************************/
void RTV_vV1AnalogFilter(void);

/*******************************************************************************
 * \brief         Initialize modules for 100us system time slice
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 ******************************************************************************/
void RTV_vDataInit(void)
{
  u16_CclHhrLow = 0;
  u16_CclHhrHigh = 0;
  u16q12VinAdcAvgPri = 0;
  u16q12IinAdcAvgPri = 0;
  u16q12PinAdcAvgPri = 0;
  u16q12VbulkAdcAvgPri= 0;
  uComStatus00.ALL = 0;
  uComStatus01.ALL = 0;
  uComStatus02.ALL = 0;
} /* RTV_vDataInit() */

/*******************************************************************************
 * \brief         filter
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 ******************************************************************************/
void RTV_vV1AnalogFilter(void)
{
  static uint8 u8V1Filter_Counter = 0;

  aAdcAverage[MG_U8_ADC_INDEX_V1_CURR].u32Sum += stAdcBufResult.u16AdcBufV1Curr;

  aAdcAverage[MG_U8_ADC_INDEX_V1_VOLT_VEA].u32Sum += stAdcBufResult.u16_AdcBuf_V1Volt_VEA;

  aAdcAverage[MG_U8_ADC_INDEX_V1_VOLT_EXT].u32Sum += stAdcBufResult.u16AdcBufV1VoltExt;

  aAdcAverage[MG_U8_ADC_INDEX_V1_ISHARE].u32Sum += stAdcBufResult.u16_AdcBuf_V1IShare_Volt;

  aAdcAverage[MG_U8_ADC_INDEX_V1_ILOCAL].u32Sum += stAdcBufResult.u16_AdcBuf_V1ILocal_Volt;
  
  aAdcAverage[MG_U8_ADC_INDEX_ORING_STA].u32Sum += stAdcBufResult.u16AdcBufOring;

  u8V1Filter_Counter ++;
  if (u8V1Filter_Counter >= 16)
  {
    /********I1 filter********/
    aAdcAverage[MG_U8_ADC_INDEX_V1_CURR].u16q12Avg = (aAdcAverage[MG_U8_ADC_INDEX_V1_CURR].u32Sum + 8) >> 4;
    aAdcAverage[MG_U8_ADC_INDEX_V1_CURR].u32Sum = 0;

    /********V1 Int filter********/
    aAdcAverage[MG_U8_ADC_INDEX_V1_VOLT_VEA].u16q12Avg = (aAdcAverage[MG_U8_ADC_INDEX_V1_VOLT_VEA].u32Sum + 8) >> 4;
    aAdcAverage[MG_U8_ADC_INDEX_V1_VOLT_VEA].u32Sum = 0;

    /********V1 Ext filter********/
    aAdcAverage[MG_U8_ADC_INDEX_V1_VOLT_EXT].u16q12Avg = (aAdcAverage[MG_U8_ADC_INDEX_V1_VOLT_EXT].u32Sum + 8) >> 4;
    aAdcAverage[MG_U8_ADC_INDEX_V1_VOLT_EXT].u32Sum = 0;

    /********I1 share filter********/
    aAdcAverage[MG_U8_ADC_INDEX_V1_ISHARE].u16q12Avg = (aAdcAverage[MG_U8_ADC_INDEX_V1_ISHARE].u32Sum + 8) >> 4;
    aAdcAverage[MG_U8_ADC_INDEX_V1_ISHARE].u32Sum = 0;

    /********I1 local filter********/
    aAdcAverage[MG_U8_ADC_INDEX_V1_ILOCAL].u16q12Avg = (aAdcAverage[MG_U8_ADC_INDEX_V1_ILOCAL].u32Sum + 8) >> 4;
    aAdcAverage[MG_U8_ADC_INDEX_V1_ILOCAL].u32Sum = 0;
    
    /********V1 ORING STATUS local filter********/
    aAdcAverage[MG_U8_ADC_INDEX_ORING_STA].u16q12Avg = (aAdcAverage[MG_U8_ADC_INDEX_ORING_STA].u32Sum + 8) >> 4;
    aAdcAverage[MG_U8_ADC_INDEX_ORING_STA].u32Sum = 0;
    
    u8V1Filter_Counter = 0;
  }
}

/*
 * End of file
 */



