/* 
 * File:   Rtv.h
 * Author: 
 *
 * Created on 1 October, 2020, 2:21 PM
 */

#ifndef RTV_H
#define	RTV_H

#ifdef	__cplusplus
extern "C" {
#endif

    /*******************************************************************************
     * Included header
     ******************************************************************************/
#include "global.h"
    /*******************************************************************************
     * Global constants and macros
     ******************************************************************************/

#define TOTAL_ADC_CH_NBR    ((uint8)13U)
#define ADC_FILTER_CH_NBR   ((uint8)3U)

#define DEBUG_PHASE         0

#define U16Q12_V1_MAX_INT       (71.28F)  
#define U16Q12_V1_MAX_SENSE     (72.28F)  
#define U16Q12_I1_MAX           (112.615F) 
#define U16Q12_POUT_MAX         (U16Q12_V1_MAX_INT * U16Q12_I1_MAX)

//#define U16Q12_ILOCAL_MAX       (9.222F) 
#define U16Q12_I1_HL_FULL_LOAD  (60.0F)  
#define U16Q12_I1_LL_FULL_LOAD  (60.0F)  

    /*CCL trigger point setting*/
#if 1
#define LLCCTRL_I1OUT_CC_HI_HL_ST  Q12(U16Q12_I1_HL_FULL_LOAD * 1.50 / U16Q12_I1_MAX)//reserved
#define LLCCTRL_I1OUT_CC_HI_HL     Q12(U16Q12_I1_HL_FULL_LOAD * 1.35 / U16Q12_I1_MAX)  /*1.35 125% load*/
#define LLCCTRL_I1OUT_CT_CC_HI_HL  Q12(U16Q12_I1_HL_FULL_LOAD * 1.20 / U16Q12_I1_MAX)   //reserved
#define LLCCTRL_I1OUT_CC_LO_HL     Q12(U16Q12_I1_HL_FULL_LOAD * 1.1 / U16Q12_I1_MAX) //1.1
#else    
#define LLCCTRL_I1OUT_CC_HI_HL  Q12(U16Q12_I1_HL_FULL_LOAD * 1.28 / U16Q12_I1_MAX)  /* 125% load*/
#define LLCCTRL_I1OUT_CC_LO_HL  Q12(U16Q12_I1_HL_FULL_LOAD * 1.22 / U16Q12_I1_MAX)
#endif


    /*CT trigger point setting*/
#define V1_CT_MAX_CURRENT           (33.0F)
#define V1_CT_HL_START_CMP_SET      Q12(18.0 / V1_CT_MAX_CURRENT)//Q12(24.0 / V1_CT_MAX_CURRENT)    
#define V1_CT_HL_NORMAL_CMP_SET     Q12(8.0 / V1_CT_MAX_CURRENT)

#define VBULK_MAX                  497.971  
#define VIN_MAX                    498.299   

#define T1_INT_PRIO                 5
#define T3_INT_PRIO                 2
#define ADCP2_INT_PRIO              5
#define PSEMIP_INT_PRIO             6
#define V1_OCP_PRIO                 7
#define IC1_INT_PRIO                1
#define IC2_INT_PRIO                1
#define I2C_INT_PRIO                4

#define MG_PWM_FAN_FREQ             25E3
#define	MG_PWM_12V_SOFT_TRIM_FREQ   (25E3 <<2) //TMP
#define	MG_PWM_12V_DROOP_FREQ       (25E3 ) //TMP

#define PWM_FAN_PERIOD              (unsigned int)(PWMCLOCKFREQ / MG_PWM_FAN_FREQ)
#define PWM_12V_SOFT_TRIM_PERIOD    (unsigned int)(PWMCLOCKFREQ / MG_PWM_12V_SOFT_TRIM_FREQ)
#define	PWM_12V_DROOP_PERIOD        (unsigned int)(PWMCLOCKFREQ / MG_PWM_12V_DROOP_FREQ)

#define MG_ISHARE_PWM_FREQ          800E3   
#define ISHARE_PWM_PERIOD           (unsigned int)(PWMCLOCKFREQ / MG_ISHARE_PWM_FREQ)
#define MG_ORING_PWM_FREQ           15E3
#define ORING_PWM_PERIOD            (unsigned int)(PWMCLOCKFREQ / MG_ORING_PWM_FREQ)
#define ORING_PWM_DUTY              (float32)(0.93)    
    /***********************************************
     * Uart
     **********************************************/

    /* Define UART architecture */

    /* 0: only TX to PRI1, 1: TX to PRI1 and PRI2, 2: TX to PRI1 and PRI2 and broadcast*/
#define UART1_TX_PRI_SEQUENCE         0U

#define UART1_TX_PRI_1                0U


    /* TRUE: calculate crc for one byte once,  FALSE: calculate crc for all data once */
#define UART_CAL_CRC_DISTRIBUTED      TRUE

#define UART1_TX_BUF_SIZE             ((uint16)50U)  /* COM TX to PRI */
#define UART1_RX_BUF_SIZE             ((uint16)50U)  /* COM RX from PRI */

#define UART_MIN_FRAME_LEN	          ((uint16)6U)   /* STX,ADDR,LEN,DATA0,CRC16 */
#define UART_FRAME_AUX_LEN            ((uint16)5U)   /* STX,ADDR,LEN,CRC16 */

    /* Define frame format */
#define UART_FRAME_STX                0xAA           /* Start of a UART frame */
#define UART_ADDR_PRI_1               0x51           /* MCU address */


    /* Define supported baudrate */
#define UART_BAUDRATE_4800            4800U          /* 1ms   RX polling */
#define UART_BAUDRATE_9600            9600U          /* 500us RX polling */
#define UART_BAUDRATE_19200           19200U         /* 200us RX polling */
#define UART_BAUDRATE_38400           38400U         /* 100us RX polling */
#define UART_BAUDRATE_57600           57600U         /* 100us RX polling */
#define UART_BAUDRATE_115200          115200UL       /* 50us  RX polling */

#define UART1_BAUDRATE                UART_BAUDRATE_9600   /* set baudrate */
//#define UART2_BAUDRATE                UART_BAUDRATE_38400  /* set baudrate */

#define UART_RX_BYTE_TIMEOUT_4800     5U             /* Value * 1ms = time */
#define UART_RX_BYTE_TIMEOUT_9600     3U             /* Value * 1ms = time */
#define UART_RX_BYTE_TIMEOUT_19200    2U             /* Value * 1ms = time */
#define UART_RX_BYTE_TIMEOUT_38400    1U             /* Value * 1ms = time */
#define UART_RX_BYTE_TIMEOUT_57600    1U             /* Value * 1ms = time */
#define UART_RX_BYTE_TIMEOUT_115200   1U             /* Value * 1ms = time */

#define UART_RX_FRAME_TIMEOUT_4800    8U             /* Value * 1ms = time */
#define UART_RX_FRAME_TIMEOUT_9600    6U             /* Value * 1ms = time */
#define UART_RX_FRAME_TIMEOUT_19200   5U             /* Value * 1ms = time */
#define UART_RX_FRAME_TIMEOUT_38400   4U             /* Value * 1ms = time */
#define UART_RX_FRAME_TIMEOUT_57600   4U             /* Value * 1ms = time */
#define UART_RX_FRAME_TIMEOUT_115200  4U             /* Value * 1ms = time */

#define UART_TX_TIMEOUT_4800          7U             /* Value * 1ms = time */
#define UART_TX_TIMEOUT_9600          5U             /* Value * 1ms = time */
#define UART_TX_TIMEOUT_19200         4U             /* Value * 1ms = time */
#define UART_TX_TIMEOUT_38400         3U             /* Value * 1ms = time */
#define UART_TX_TIMEOUT_57600         3U             /* Value * 1ms = time */
#define UART_TX_TIMEOUT_115200        3U             /* Value * 1ms = time */

    /* UART1 timeout config*/
#if (UART_BAUDRATE_4800 == UART1_BAUDRATE)
#define UART1_RX_BYTE_TIMEOUT         UART_RX_BYTE_TIMEOUT_4800
#define UART1_RX_FRAME_TIMEOUT        UART_RX_FRAME_TIMEOUT_4800
#define UART1_TX_TIMEOUT              UART_TX_TIMEOUT_4800
#endif
#if (UART_BAUDRATE_9600 == UART1_BAUDRATE)
#define UART1_RX_BYTE_TIMEOUT         UART_RX_BYTE_TIMEOUT_9600
#define UART1_RX_FRAME_TIMEOUT        UART_RX_FRAME_TIMEOUT_9600
#define UART1_TX_TIMEOUT              UART_TX_TIMEOUT_9600
#endif
#if (UART_BAUDRATE_19200 == UART1_BAUDRATE)
#define UART1_RX_BYTE_TIMEOUT         UART_RX_BYTE_TIMEOUT_19200
#define UART1_RX_FRAME_TIMEOUT        UART_RX_FRAME_TIMEOUT_19200
#define UART1_TX_TIMEOUT              UART_TX_TIMEOUT_19200
#endif
#if (UART_BAUDRATE_38400 == UART1_BAUDRATE)
#define UART1_RX_BYTE_TIMEOUT         UART_RX_BYTE_TIMEOUT_38400
#define UART1_RX_FRAME_TIMEOUT        UART_RX_FRAME_TIMEOUT_38400
#define UART1_TX_TIMEOUT              UART_TX_TIMEOUT_38400
#endif
#if (UART_BAUDRATE_57600 == UART1_BAUDRATE)
#define UART1_RX_BYTE_TIMEOUT         UART_RX_BYTE_TIMEOUT_57600
#define UART1_RX_FRAME_TIMEOUT        UART_RX_FRAME_TIMEOUT_57600
#define UART1_TX_TIMEOUT              UART_TX_TIMEOUT_57600
#endif
#if (UART_BAUDRATE_115200 == UART1_BAUDRATE)
#define UART1_RX_BYTE_TIMEOUT         UART_RX_BYTE_TIMEOUT_115200
#define UART1_RX_FRAME_TIMEOUT        UART_RX_FRAME_TIMEOUT_115200
#define UART1_TX_TIMEOUT              UART_TX_TIMEOUT_115200
#endif

#define UART1_FAIL_CNT                ((uint16)1000U)   /* Total 2s for each CH, Value * 1ms = time */
#define UART2_FAIL_CNT                ((uint16)1000U)   /* Total 2s for each CH, Value * 1ms = time */

    /***********************************************
     * PMBus
     **********************************************/
#define I2C_DEB_BUF_SIZE             ((uint16)64U)
//#define EEP_99_9E_MFR_CMD_EN         (FALSE)


    /***********************************************
     * PSU Ctrl
     **********************************************/
#define	INPUT_RAIL_NUM		1U

    /***********************************************
     * Intcom1 status bit
     **********************************************/
#define INTCOM1_PRI1_UART_FAIL     uIntcom1Status.Bits.f0
#define INTCOM1_PRI2_UART_FAIL     uIntcom1Status.Bits.f1
#define INTCOM1_PRI1_REV_UPDATE    uIntcom1Status.Bits.f2
#define INTCOM1_PRI2_REV_UPDATE    uIntcom1Status.Bits.f3
#define INTCOM1_PRI1_NO_RX_PKG     uIntcom1Status.Bits.f4
#define INTCOM1_PRI2_NO_RX_PKG     uIntcom1Status.Bits.f5
#define INTCOM1_PRI1_METER_IC_CALI uIntcom1Status.Bits.f6
#define INTCOM1_PRI2_METER_IC_CALI uIntcom1Status.Bits.f7
#define INTCOM1_VIN_OK_FOR_UART    uIntcom1Status.Bits.f8

    /***********************************************
     * DIO status bit
     **********************************************/
    /* Input */
#define FLG_DI_V1_OVP                 uDioInStatus.Bits.f0
#define FLG_DI_VIN_FRO_PRI_OK         uDioInStatus.Bits.f1
#define FLG_DI_BULK_FRO_PRI_OK        uDioInStatus.Bits.f2
#define FLG_DI_PSKILL_V1_ON           uDioInStatus.Bits.f3
#define FLG_DI_PSON_ACTIVE            uDioInStatus.Bits.f4
#define FLG_DI_I2C_RESET_ACTIVE       uDioInStatus.Bits.f5
#define FLG_DI_I2C_ADDR_A0_HIGH       uDioInStatus.Bits.f6
#define FLG_DI_I2C_ADDR_A1_HIGH       uDioInStatus.Bits.f7
#define FLG_DI_I2C_ADDR_A2_HIGH       uDioInStatus.Bits.f8

    /* Output */
#define FLG_DO_V1_ISHARE_ON           uDioOutStatus.Bits.f0
//#define DO_SR_CLAMP_EN                uDioOutStatus.Bits.f1
#define FLG_DO_V1_OUTPUT_EN           uDioOutStatus.Bits.f2
//#define DO_VSB_OUTPUT_EN              uDioOutStatus.Bits.f3
#define FLG_DO_PWOK_TO_SYS_OK         uDioOutStatus.Bits.f4
#define FLG_DO_OUTPUT_LED_ON          uDioOutStatus.Bits.f5
#define FLG_DO_FAULT_LED_ON           uDioOutStatus.Bits.f6
#define FLG_DO_SMBALT_ALARM           uDioOutStatus.Bits.f7
#define FLG_DO_EEP_WR_EN              uDioOutStatus.Bits.f8
#define FLG_DO_V1_ORING_CTRL_EN       uDioOutStatus.Bits.f9
#define FLG_DO_RESERVED               uDioOutStatus.Bits.fa
#define FLG_DO_INOK_TO_SYS_OK         uDioOutStatus.Bits.fb
#define FLG_DO_V1_OVP_CLAER           uDioOutStatus.Bits.fc
//#define FLG_DO_BEACON_LED_ON          uDioOutStatus.Bits.fd
    /***********************************************
     * Primary status bit
     **********************************************/
    /* Status bits */
#define FLG_PRI_VDC_IN             stIntcom1_PriA.u16PriStatus00.Bits.f0  /* 1 = input valtage is DC */
#define FLG_PRI_VIN_OK             stIntcom1_PriA.u16PriStatus00.Bits.f1  /* 1 = input voltage is OK */
#define FLG_PRI_BULK_OK            stIntcom1_PriA.u16PriStatus00.Bits.f2  /* 1 = bulk voltage is OK */
#define FLG_PRI_VIN_LINE           stIntcom1_PriA.u16PriStatus00.Bits.f3  /* 1 = low line */
#define FLG_PRI_VIN_ALERT          stIntcom1_PriA.u16PriStatus00.Bits.f4  /* 1 = input voltage alert to inform sec. */
#define FLG_PRI_BULK_OV            stIntcom1_PriA.u16PriStatus00.Bits.f5  /* 1 = bulk is over voltage */
#define FLG_PRI_PFC_OT             stIntcom1_PriA.u16PriStatus00.Bits.f6  /* 1 = PSU is over temperature */
#define FLG_PRI_PFC_OTW            stIntcom1_PriA.u16PriStatus00.Bits.f7  /* 1 = PFC stage over temperature */
    /* Control bits */
#define FLG_PRI_PFC_GO             stIntcom1_PriA.u16PriStatus00.Bits.f8  /* 1 = PFC GO */
#define FLG_PRI_RELAY_ON           stIntcom1_PriA.u16PriStatus00.Bits.f9  /* 1 = relat is closed */
#define FLG_PRI_PFC_EN             stIntcom1_PriA.u16PriStatus00.Bits.fa  /* 1 = PFC is turn on */
#define FLG_PRI_EXT_EN             stIntcom1_PriA.u16PriStatus00.Bits.fb  /* 1 = extender is turn on */
#define FLG_PRI_PFC_OT_DIS         stIntcom1_PriA.u16PriStatus00.Bits.fc  /* 1 = PSU disable OT judgement */
#define FLG_PRI_BL_MODE            stIntcom1_PriA.u16PriStatus00.Bits.fd  /* 1 = Boot loader mode */
#define FLG_PRI_BL_EXIST           stIntcom1_PriA.u16PriStatus00.Bits.fe  /* 1 = Boot loader is existing */
#define FLG_PRI_PFC_OPP            stIntcom1_PriA.u16PriStatus00.Bits.ff  /* 1 = PFC stage over power */
    /* Primary Control bits */
#define FLG_PRI_VIN_OV             stIntcom1_PriA.u16PriStatus01.Bits.f0  /* 1 = input over voltage */
#define FLG_PRI_VIN_OVW            stIntcom1_PriA.u16PriStatus01.Bits.f1  /* 1 = over voltage warning */
#define FLG_PRI_VIN_UVW            stIntcom1_PriA.u16PriStatus01.Bits.f2  /* 1 = under voltage warning */
#define FLG_PRI_VIN_SAG            stIntcom1_PriA.u16PriStatus01.Bits.f3  /* 1 = input voltage is sag */
#define FLG_PRI_VIN_UV             stIntcom1_PriA.u16PriStatus01.Bits.f4  /* 1 = input is under voltage */
#define FLG_PRI_VIN_DROPOUT        stIntcom1_PriA.u16PriStatus01.Bits.f5  /* 1 = input voltage drops to 0V */

    /*******************************************************************************
     * Global constants and macros
     ******************************************************************************/

    /***********************************************
     * ADC
     **********************************************/
    typedef enum E_VIP_ADC_AVE_INDEX_ {
        MG_U8_ADC_INDEX_V1_VOLT_EXT = 0,   /* 0 */
        MG_U8_ADC_INDEX_V1_VOLT_VEA,       /* 1 */
        MG_U8_ADC_INDEX_V1_CURR,           /* 2 */
        MG_U8_ADC_INDEX_V1_ISHARE,         /* 3 */
        MG_U8_ADC_INDEX_V1_ILOCAL,         /* 4 */
        MG_U8_ADC_INDEX_VSB_VOLT_EXT,      /* 5 */
        MG_U8_ADC_INDEX_VSB_VOLT_INT,      /* 6 */
        MG_U8_ADC_INDEX_VSB_CURR,          /* 7 */
        MG_U8_ADC_INDEX_ORING_STA,         /* 8 */
        MG_U8_ADC_INDEX_NUM,               /* 9 */
    } E_VIP_ADC_AVE_INDEX;

    typedef struct ST_ADC_ANALOG_ {
        uint16 u16q12Max;
        uint16 u16q12Min;
        uint16 u16q12Avg;
        uint32 u32Sum;
    } ST_ADC_ANALOG;

    /***********************************************
     * UART
     **********************************************/
    typedef union U_UARTSTATUS_ {

        struct {
            uint8 u8BootMode : 1; /* bit0 */
            uint8 u8CrcErr : 1; /* bit1 */
            uint8 u8McuAddrErr : 1; /* bit2 */
            uint8 u8LenErr : 1; /* bit3 */
            uint8 u8ByteTmout : 1; /* bit4 */
            uint8 u8FrameTmout : 1; /* bit5 */
            uint8 u8InvalidData : 1; /* bit6 */
            uint8 u8UartRegErr : 1; /* bit7 */
        } Bit;
        uint8 Byte;
    } U_UARTSTATUS;

    typedef struct ST_UART_DATA_ {
        uint16 u16TxDataCnt;
        uint16 u16RxDataCnt;
        uint16 u16RxByteTmOutEna;
        uint16 u16RxByteTmOutCnt;
        uint16 u16RxFrameTmOutEna;
        uint16 u16RxFrameTmOutCnt;
        uint16 u16TxTmOutEna;
        uint16 u16TxTmOutCnt;
    } ST_UART_DATA;

    typedef struct ST_INTCOM1_DATA_ {
        WORD_VAL u16q12VinAdc;
        WORD_VAL u16q12IinAdc;
        WORD_VAL u16q12PinAdc;
        WORD_VAL u16q12VbulkAdc;
        uint8 u8VoltInFreq;
        WORD_VAL u16q12PowerFactor;
        GLOBAL_U_U16BIT u16PriStatus00;
        GLOBAL_U_U16BIT u16PriStatus01;
        WORD_VAL u16PriDebug1;
        WORD_VAL u16PriDebug2;
        WORD_VAL u16q12PfcNtc;
        WORD_VAL u16q12AmbExhaust;
        WORD_VAL u16VoltInRms;
    } ST_INTCOM1_DATA;

    typedef struct ST_INTCOM2_DATA_ {
        WORD_VAL u16q12IoutAdc;
        GLOBAL_U_U16BIT u16SecStatus00;
        GLOBAL_U_U16BIT u16SecStatus01;
        WORD_VAL u16SecDebug1;
        WORD_VAL u16SecDebug2;
        WORD_VAL u16SecDebug3;
        WORD_VAL u16SecDebug4;
    } ST_INTCOM2_DATA;

    typedef struct ST_ADC_Result_ {
        uint16 u16AdcBufV1VoltExt;
        uint16 u16_AdcBuf_V1Volt_VEA;
        uint16 u16AdcBufV1Curr;
        uint16 u16_AdcBuf_V1ILocal_Volt;
        uint16 u16_AdcBuf_V1IShare_Volt;
        uint16 u16AdcBufVsbVoltExt;
        uint16 u16AdcBufVsbVoltInt;
        uint16 u16AdcBufVsbCurr;
        uint16 u16AdcBufNtcSr;
        uint16 u16AdcBufNtcAmb;
        uint16 u16AdcBufV1CurrCali;
        uint16 u16_AdcBuf_V1IShare_VoltCali;
        uint16 u16AdcBufRef2V5;
        uint16 u16AdcBufOring;
    } ST_ADC_Result;

    typedef union U_FW_VERSION_ {
        uint64 u64Val;

        struct {
            uint16 u16ApdsVersion;
            uint16 u16BLVersion;
            uint16 u16APPVersion;
            uint16 u16APPDebugVersion;
        } u16Val;

        struct {
            uint8 u8MajorVersion;
            uint8 u8MinorVersion;
            uint8 u8BLMajorVersion;
            uint8 u8BLMinorVersion;
            uint8 u8APPMajorVersion;
            uint8 u8APPMinorVersion;
            uint8 u8APPBuildVersion;
            uint8 u8Reserved;
        } Bytes;
    } U_FW_VERSION;


    /*******************************************************************************
     * Global data types (typedefs / structs / enums)
     ******************************************************************************/
#if defined(RTV_EXPORT_H)
#define EXTERN
#else
#define EXTERN extern
#endif

    EXTERN uint16 u16_CclHhrLow;
    EXTERN uint16 u16_CclHhrHigh;
    EXTERN sint16 PSU_s16VrefControl;
    /***********************************************
     * Uart
     **********************************************/
    EXTERN uint8 au8Uart1TxBuf[UART1_TX_BUF_SIZE];
    EXTERN uint8 au8Uart1RxBuf[UART1_RX_BUF_SIZE];
    EXTERN uint16 u16Uart1TxDataNbr;
    EXTERN uint16 u16Uart1RxDataNbr;
    EXTERN uint8 u8Uart1TxBufUpdated;
    EXTERN uint8 u8Uart1RxNewFrame;
    EXTERN uint8 u8Uart1FrameTmoutFlg;
    EXTERN uint8 u8Uart1ByteTmoutFlg;
    EXTERN uint8 u8Uart1TxTmoutFlg;
    EXTERN uint8 u8Uart1BroadcastFlg;
    EXTERN uint16 u16Uart1RxCrc;
    EXTERN U_UARTSTATUS uUart1Status;
    EXTERN GLOBAL_U_U16BIT uIntcom1Status;

    

    
    EXTERN ST_INTCOM1_DATA stIntcom1_PriA;
    EXTERN GLOBAL_U_U16BIT uComStatus00;
    EXTERN GLOBAL_U_U16BIT uComStatus01;
    EXTERN GLOBAL_U_U16BIT uComStatus02;

    EXTERN GLOBAL_U_U16BIT uDioInStatus;
    EXTERN GLOBAL_U_U16BIT uDioOutStatus;
    EXTERN GLOBAL_U_U16BIT uPsuCtrlTrimStatus;


    EXTERN ST_ADC_Result stAdcBufResult;
    EXTERN ST_ADC_ANALOG aAdcAverage[TOTAL_ADC_CH_NBR];


    EXTERN uint16 u16q12VinAdcAvgPri;
    EXTERN uint16 u16q12IinAdcAvgPri;
    EXTERN uint16 u16q12PinAdcAvgPri;
    EXTERN uint16 u16q12VbulkAdcAvgPri;
    /***********************************************
     * Output Trim and OVP test
     **********************************************/


    /***********************************************
     * FM Revision
     **********************************************/
    EXTERN U_FW_VERSION u64PmbusFwRevPri1;
    EXTERN DWORD_VAL u64PmbusFwRevSec1;
    EXTERN U_FW_VERSION u64PmbusFwRevPri1Old;
    EXTERN DWORD_VAL u64PmbusFwRevSec1Old;


    /***********************************************
     * Input Line Status
     **********************************************/
    EXTERN uint8 u8LineStatus;

    
    
#undef EXTERN

    /*******************************************************************************
     * Global function prototypes (public to other modules)
     ******************************************************************************/
    extern void RTV_vDataInit(void);
    extern void RTV_vV1AnalogFilter(void);
    extern void DIO_ReadAllDigitalInputs(void);
    extern void DIO_WriteAllDigitalOutputs(void);


#ifdef	__cplusplus
}
#endif

#endif	/* RTV_H */

