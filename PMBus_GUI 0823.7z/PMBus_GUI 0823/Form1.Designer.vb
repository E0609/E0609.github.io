﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim ChartArea1 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend1 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series1 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim Series2 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim Title1 As System.Windows.Forms.DataVisualization.Charting.Title = New System.Windows.Forms.DataVisualization.Charting.Title()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.SaveFileDialog2 = New System.Windows.Forms.SaveFileDialog()
        Me.RadioButton9 = New System.Windows.Forms.RadioButton()
        Me.RadioButton10 = New System.Windows.Forms.RadioButton()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripProgressBar1 = New System.Windows.Forms.ToolStripProgressBar()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.RadioButton11 = New System.Windows.Forms.RadioButton()
        Me.Tab_Read = New System.Windows.Forms.TabPage()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Cmd = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn18 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn19 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn21 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Label232 = New System.Windows.Forms.Label()
        Me.Label230 = New System.Windows.Forms.Label()
        Me.Label90 = New System.Windows.Forms.Label()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.Label222 = New System.Windows.Forms.Label()
        Me.Label220 = New System.Windows.Forms.Label()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.Label348 = New System.Windows.Forms.Label()
        Me.Button_Status_VOUT = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.NumericUpDown21 = New System.Windows.Forms.NumericUpDown()
        Me.Label275 = New System.Windows.Forms.Label()
        Me.Label327 = New System.Windows.Forms.Label()
        Me.Label272 = New System.Windows.Forms.Label()
        Me.Label269 = New System.Windows.Forms.Label()
        Me.Button103 = New System.Windows.Forms.Button()
        Me.Label268 = New System.Windows.Forms.Label()
        Me.Button104 = New System.Windows.Forms.Button()
        Me.Label264 = New System.Windows.Forms.Label()
        Me.CheckBox6 = New System.Windows.Forms.CheckBox()
        Me.Label252 = New System.Windows.Forms.Label()
        Me.CheckBox7 = New System.Windows.Forms.CheckBox()
        Me.Label246 = New System.Windows.Forms.Label()
        Me.CheckBox8 = New System.Windows.Forms.CheckBox()
        Me.TextBox89 = New System.Windows.Forms.TextBox()
        Me.CheckBox9 = New System.Windows.Forms.CheckBox()
        Me.TextBox27 = New System.Windows.Forms.TextBox()
        Me.CheckBox10 = New System.Windows.Forms.CheckBox()
        Me.CheckBox20 = New System.Windows.Forms.CheckBox()
        Me.CheckBox11 = New System.Windows.Forms.CheckBox()
        Me.CheckBox19 = New System.Windows.Forms.CheckBox()
        Me.CheckBox12 = New System.Windows.Forms.CheckBox()
        Me.CheckBox18 = New System.Windows.Forms.CheckBox()
        Me.CheckBox69 = New System.Windows.Forms.CheckBox()
        Me.CheckBox17 = New System.Windows.Forms.CheckBox()
        Me.TextBox31 = New System.Windows.Forms.TextBox()
        Me.CheckBox16 = New System.Windows.Forms.CheckBox()
        Me.TextBox84 = New System.Windows.Forms.TextBox()
        Me.CheckBox15 = New System.Windows.Forms.CheckBox()
        Me.Label347 = New System.Windows.Forms.Label()
        Me.CheckBox14 = New System.Windows.Forms.CheckBox()
        Me.CheckBox13 = New System.Windows.Forms.CheckBox()
        Me.TextBox26 = New System.Windows.Forms.TextBox()
        Me.TextBox23 = New System.Windows.Forms.TextBox()
        Me.Label131 = New System.Windows.Forms.Label()
        Me.CheckBox28 = New System.Windows.Forms.CheckBox()
        Me.Label279 = New System.Windows.Forms.Label()
        Me.CheckBox27 = New System.Windows.Forms.CheckBox()
        Me.Label277 = New System.Windows.Forms.Label()
        Me.CheckBox26 = New System.Windows.Forms.CheckBox()
        Me.Label276 = New System.Windows.Forms.Label()
        Me.CheckBox25 = New System.Windows.Forms.CheckBox()
        Me.CheckBox24 = New System.Windows.Forms.CheckBox()
        Me.Button101 = New System.Windows.Forms.Button()
        Me.CheckBox23 = New System.Windows.Forms.CheckBox()
        Me.Button102 = New System.Windows.Forms.Button()
        Me.CheckBox22 = New System.Windows.Forms.CheckBox()
        Me.Button99 = New System.Windows.Forms.Button()
        Me.CheckBox21 = New System.Windows.Forms.CheckBox()
        Me.Button100 = New System.Windows.Forms.Button()
        Me.TextBox22 = New System.Windows.Forms.TextBox()
        Me.Button97 = New System.Windows.Forms.Button()
        Me.TextBox21 = New System.Windows.Forms.TextBox()
        Me.Button98 = New System.Windows.Forms.Button()
        Me.CheckBox36 = New System.Windows.Forms.CheckBox()
        Me.Button95 = New System.Windows.Forms.Button()
        Me.CheckBox35 = New System.Windows.Forms.CheckBox()
        Me.Button96 = New System.Windows.Forms.Button()
        Me.CheckBox34 = New System.Windows.Forms.CheckBox()
        Me.Button91 = New System.Windows.Forms.Button()
        Me.CheckBox33 = New System.Windows.Forms.CheckBox()
        Me.Button92 = New System.Windows.Forms.Button()
        Me.CheckBox32 = New System.Windows.Forms.CheckBox()
        Me.Button89 = New System.Windows.Forms.Button()
        Me.CheckBox31 = New System.Windows.Forms.CheckBox()
        Me.Button90 = New System.Windows.Forms.Button()
        Me.CheckBox30 = New System.Windows.Forms.CheckBox()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.CheckBox29 = New System.Windows.Forms.CheckBox()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.TextBox20 = New System.Windows.Forms.TextBox()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.CheckBox44 = New System.Windows.Forms.CheckBox()
        Me.Label89 = New System.Windows.Forms.Label()
        Me.CheckBox43 = New System.Windows.Forms.CheckBox()
        Me.CheckBox42 = New System.Windows.Forms.CheckBox()
        Me.CheckBox41 = New System.Windows.Forms.CheckBox()
        Me.CheckBox40 = New System.Windows.Forms.CheckBox()
        Me.Label95 = New System.Windows.Forms.Label()
        Me.CheckBox39 = New System.Windows.Forms.CheckBox()
        Me.Label125 = New System.Windows.Forms.Label()
        Me.CheckBox38 = New System.Windows.Forms.CheckBox()
        Me.Label127 = New System.Windows.Forms.Label()
        Me.CheckBox37 = New System.Windows.Forms.CheckBox()
        Me.Label134 = New System.Windows.Forms.Label()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.Label135 = New System.Windows.Forms.Label()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.CheckBox61 = New System.Windows.Forms.CheckBox()
        Me.CheckBox52 = New System.Windows.Forms.CheckBox()
        Me.CheckBox62 = New System.Windows.Forms.CheckBox()
        Me.CheckBox51 = New System.Windows.Forms.CheckBox()
        Me.CheckBox63 = New System.Windows.Forms.CheckBox()
        Me.CheckBox50 = New System.Windows.Forms.CheckBox()
        Me.CheckBox64 = New System.Windows.Forms.CheckBox()
        Me.CheckBox49 = New System.Windows.Forms.CheckBox()
        Me.CheckBox65 = New System.Windows.Forms.CheckBox()
        Me.CheckBox48 = New System.Windows.Forms.CheckBox()
        Me.CheckBox66 = New System.Windows.Forms.CheckBox()
        Me.CheckBox47 = New System.Windows.Forms.CheckBox()
        Me.CheckBox67 = New System.Windows.Forms.CheckBox()
        Me.CheckBox46 = New System.Windows.Forms.CheckBox()
        Me.CheckBox68 = New System.Windows.Forms.CheckBox()
        Me.CheckBox45 = New System.Windows.Forms.CheckBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.CheckBox53 = New System.Windows.Forms.CheckBox()
        Me.CheckBox60 = New System.Windows.Forms.CheckBox()
        Me.CheckBox54 = New System.Windows.Forms.CheckBox()
        Me.CheckBox59 = New System.Windows.Forms.CheckBox()
        Me.CheckBox55 = New System.Windows.Forms.CheckBox()
        Me.CheckBox58 = New System.Windows.Forms.CheckBox()
        Me.CheckBox56 = New System.Windows.Forms.CheckBox()
        Me.CheckBox57 = New System.Windows.Forms.CheckBox()
        Me.Poll = New System.Windows.Forms.Button()
        Me.ReadOnce = New System.Windows.Forms.Button()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.Tab_MFR = New System.Windows.Forms.TabPage()
        Me.DataGridView_MFR = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Button_MFR_Read = New System.Windows.Forms.Button()
        Me.Tab_Constant = New System.Windows.Forms.TabPage()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Tab_Status = New System.Windows.Forms.TabPage()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.ListBox_Cmd = New System.Windows.Forms.ListBox()
        Me.Button_Clear_Faults = New System.Windows.Forms.Button()
        Me.TextBox_Status_Data_r = New System.Windows.Forms.TextBox()
        Me.NumericUpDown_cmd_r = New System.Windows.Forms.NumericUpDown()
        Me.Button_status_read = New System.Windows.Forms.Button()
        Me.Label468 = New System.Windows.Forms.Label()
        Me.Label467 = New System.Windows.Forms.Label()
        Me.TextBox_status_Data = New System.Windows.Forms.TextBox()
        Me.NumericUpDown_page = New System.Windows.Forms.NumericUpDown()
        Me.Button_status_write = New System.Windows.Forms.Button()
        Me.Label405 = New System.Windows.Forms.Label()
        Me.Label406 = New System.Windows.Forms.Label()
        Me.Label407 = New System.Windows.Forms.Label()
        Me.Label408 = New System.Windows.Forms.Label()
        Me.Label409 = New System.Windows.Forms.Label()
        Me.Label410 = New System.Windows.Forms.Label()
        Me.Label411 = New System.Windows.Forms.Label()
        Me.Label412 = New System.Windows.Forms.Label()
        Me.Label413 = New System.Windows.Forms.Label()
        Me.Label414 = New System.Windows.Forms.Label()
        Me.Label415 = New System.Windows.Forms.Label()
        Me.PictureBox65 = New System.Windows.Forms.PictureBox()
        Me.PictureBox66 = New System.Windows.Forms.PictureBox()
        Me.PictureBox67 = New System.Windows.Forms.PictureBox()
        Me.PictureBox68 = New System.Windows.Forms.PictureBox()
        Me.PictureBox69 = New System.Windows.Forms.PictureBox()
        Me.PictureBox70 = New System.Windows.Forms.PictureBox()
        Me.PictureBox71 = New System.Windows.Forms.PictureBox()
        Me.PictureBox72 = New System.Windows.Forms.PictureBox()
        Me.Label416 = New System.Windows.Forms.Label()
        Me.PictureBox73 = New System.Windows.Forms.PictureBox()
        Me.PictureBox74 = New System.Windows.Forms.PictureBox()
        Me.PictureBox75 = New System.Windows.Forms.PictureBox()
        Me.PictureBox76 = New System.Windows.Forms.PictureBox()
        Me.PictureBox77 = New System.Windows.Forms.PictureBox()
        Me.PictureBox78 = New System.Windows.Forms.PictureBox()
        Me.PictureBox79 = New System.Windows.Forms.PictureBox()
        Me.PictureBox80 = New System.Windows.Forms.PictureBox()
        Me.Label420 = New System.Windows.Forms.Label()
        Me.Label421 = New System.Windows.Forms.Label()
        Me.Label422 = New System.Windows.Forms.Label()
        Me.Label423 = New System.Windows.Forms.Label()
        Me.Label424 = New System.Windows.Forms.Label()
        Me.Label425 = New System.Windows.Forms.Label()
        Me.Label426 = New System.Windows.Forms.Label()
        Me.Label427 = New System.Windows.Forms.Label()
        Me.Label428 = New System.Windows.Forms.Label()
        Me.Label429 = New System.Windows.Forms.Label()
        Me.Label430 = New System.Windows.Forms.Label()
        Me.Label431 = New System.Windows.Forms.Label()
        Me.Label432 = New System.Windows.Forms.Label()
        Me.Label433 = New System.Windows.Forms.Label()
        Me.Label434 = New System.Windows.Forms.Label()
        Me.Label435 = New System.Windows.Forms.Label()
        Me.Label436 = New System.Windows.Forms.Label()
        Me.Label437 = New System.Windows.Forms.Label()
        Me.Label438 = New System.Windows.Forms.Label()
        Me.Label439 = New System.Windows.Forms.Label()
        Me.Label440 = New System.Windows.Forms.Label()
        Me.Label441 = New System.Windows.Forms.Label()
        Me.Label442 = New System.Windows.Forms.Label()
        Me.Label443 = New System.Windows.Forms.Label()
        Me.Label444 = New System.Windows.Forms.Label()
        Me.Label445 = New System.Windows.Forms.Label()
        Me.Label446 = New System.Windows.Forms.Label()
        Me.Label447 = New System.Windows.Forms.Label()
        Me.Label448 = New System.Windows.Forms.Label()
        Me.Label449 = New System.Windows.Forms.Label()
        Me.Label450 = New System.Windows.Forms.Label()
        Me.Label451 = New System.Windows.Forms.Label()
        Me.Label452 = New System.Windows.Forms.Label()
        Me.Label453 = New System.Windows.Forms.Label()
        Me.Label454 = New System.Windows.Forms.Label()
        Me.Label455 = New System.Windows.Forms.Label()
        Me.Label456 = New System.Windows.Forms.Label()
        Me.PictureBox81 = New System.Windows.Forms.PictureBox()
        Me.PictureBox82 = New System.Windows.Forms.PictureBox()
        Me.PictureBox83 = New System.Windows.Forms.PictureBox()
        Me.PictureBox84 = New System.Windows.Forms.PictureBox()
        Me.PictureBox85 = New System.Windows.Forms.PictureBox()
        Me.PictureBox86 = New System.Windows.Forms.PictureBox()
        Me.PictureBox87 = New System.Windows.Forms.PictureBox()
        Me.PictureBox88 = New System.Windows.Forms.PictureBox()
        Me.PictureBox89 = New System.Windows.Forms.PictureBox()
        Me.PictureBox90 = New System.Windows.Forms.PictureBox()
        Me.PictureBox91 = New System.Windows.Forms.PictureBox()
        Me.PictureBox92 = New System.Windows.Forms.PictureBox()
        Me.PictureBox93 = New System.Windows.Forms.PictureBox()
        Me.PictureBox94 = New System.Windows.Forms.PictureBox()
        Me.PictureBox95 = New System.Windows.Forms.PictureBox()
        Me.PictureBox96 = New System.Windows.Forms.PictureBox()
        Me.PictureBox97 = New System.Windows.Forms.PictureBox()
        Me.PictureBox_Busy = New System.Windows.Forms.PictureBox()
        Me.PictureBox99 = New System.Windows.Forms.PictureBox()
        Me.PictureBox100 = New System.Windows.Forms.PictureBox()
        Me.PictureBox101 = New System.Windows.Forms.PictureBox()
        Me.PictureBox102 = New System.Windows.Forms.PictureBox()
        Me.PictureBox103 = New System.Windows.Forms.PictureBox()
        Me.PictureBox104 = New System.Windows.Forms.PictureBox()
        Me.PictureBox105 = New System.Windows.Forms.PictureBox()
        Me.PictureBox106 = New System.Windows.Forms.PictureBox()
        Me.PictureBox107 = New System.Windows.Forms.PictureBox()
        Me.PictureBox108 = New System.Windows.Forms.PictureBox()
        Me.PictureBox109 = New System.Windows.Forms.PictureBox()
        Me.PictureBox110 = New System.Windows.Forms.PictureBox()
        Me.PictureBox111 = New System.Windows.Forms.PictureBox()
        Me.PictureBox112 = New System.Windows.Forms.PictureBox()
        Me.PictureBox113 = New System.Windows.Forms.PictureBox()
        Me.PictureBox_OFF = New System.Windows.Forms.PictureBox()
        Me.PictureBox115 = New System.Windows.Forms.PictureBox()
        Me.PictureBox116 = New System.Windows.Forms.PictureBox()
        Me.PictureBox117 = New System.Windows.Forms.PictureBox()
        Me.PictureBox118 = New System.Windows.Forms.PictureBox()
        Me.PictureBox119 = New System.Windows.Forms.PictureBox()
        Me.PictureBox120 = New System.Windows.Forms.PictureBox()
        Me.PictureBox121 = New System.Windows.Forms.PictureBox()
        Me.PictureBox122 = New System.Windows.Forms.PictureBox()
        Me.PictureBox123 = New System.Windows.Forms.PictureBox()
        Me.PictureBox124 = New System.Windows.Forms.PictureBox()
        Me.PictureBox125 = New System.Windows.Forms.PictureBox()
        Me.PictureBox126 = New System.Windows.Forms.PictureBox()
        Me.PictureBox127 = New System.Windows.Forms.PictureBox()
        Me.PictureBox128 = New System.Windows.Forms.PictureBox()
        Me.PictureBox129 = New System.Windows.Forms.PictureBox()
        Me.PictureBox_VOUT_OV = New System.Windows.Forms.PictureBox()
        Me.PictureBox131 = New System.Windows.Forms.PictureBox()
        Me.PictureBox132 = New System.Windows.Forms.PictureBox()
        Me.PictureBox133 = New System.Windows.Forms.PictureBox()
        Me.PictureBox134 = New System.Windows.Forms.PictureBox()
        Me.PictureBox135 = New System.Windows.Forms.PictureBox()
        Me.PictureBox136 = New System.Windows.Forms.PictureBox()
        Me.PictureBox137 = New System.Windows.Forms.PictureBox()
        Me.PictureBox138 = New System.Windows.Forms.PictureBox()
        Me.PictureBox139 = New System.Windows.Forms.PictureBox()
        Me.PictureBox140 = New System.Windows.Forms.PictureBox()
        Me.PictureBox141 = New System.Windows.Forms.PictureBox()
        Me.PictureBox142 = New System.Windows.Forms.PictureBox()
        Me.PictureBox_IOUT_OC = New System.Windows.Forms.PictureBox()
        Me.PictureBox144 = New System.Windows.Forms.PictureBox()
        Me.Tab_Control = New System.Windows.Forms.TabPage()
        Me.GroupBox18 = New System.Windows.Forms.GroupBox()
        Me.Button_PSUOff = New System.Windows.Forms.Button()
        Me.Button_PSUOn = New System.Windows.Forms.Button()
        Me.GroupBox14 = New System.Windows.Forms.GroupBox()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Button_IOUT_OC_Warn = New System.Windows.Forms.Button()
        Me.TextBox_Set_Warn = New System.Windows.Forms.TextBox()
        Me.Button_SET_IOUT_OC_WARN = New System.Windows.Forms.Button()
        Me.NumericUpDown_Set_Warn = New System.Windows.Forms.NumericUpDown()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Button_GET_IOUT_OC_Fault_Limit = New System.Windows.Forms.Button()
        Me.TextBox_GET_OC_Fault_Limit = New System.Windows.Forms.TextBox()
        Me.Button_SET_IOUT_OC_Fault = New System.Windows.Forms.Button()
        Me.NumericUpDown_SET_IOUT_F = New System.Windows.Forms.NumericUpDown()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label457 = New System.Windows.Forms.Label()
        Me.NumericUpDown_SET_Vbulk = New System.Windows.Forms.NumericUpDown()
        Me.TextBox_GET_Vbulk = New System.Windows.Forms.TextBox()
        Me.Button_GET_Vbulk = New System.Windows.Forms.Button()
        Me.Button_SET_Vbulk = New System.Windows.Forms.Button()
        Me.Label458 = New System.Windows.Forms.Label()
        Me.TextBox_GET_Duty = New System.Windows.Forms.TextBox()
        Me.NumericUpDown_SET_Duty = New System.Windows.Forms.NumericUpDown()
        Me.Button_GET_Duty = New System.Windows.Forms.Button()
        Me.Button_SET_Duty = New System.Windows.Forms.Button()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.Label465 = New System.Windows.Forms.Label()
        Me.Label466 = New System.Windows.Forms.Label()
        Me.Button32 = New System.Windows.Forms.Button()
        Me.NumericUpDown23 = New System.Windows.Forms.NumericUpDown()
        Me.TextBox47 = New System.Windows.Forms.TextBox()
        Me.TextBox48 = New System.Windows.Forms.TextBox()
        Me.Button33 = New System.Windows.Forms.Button()
        Me.NumericUpDown24 = New System.Windows.Forms.NumericUpDown()
        Me.Tab_Calibration = New System.Windows.Forms.TabPage()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TextBox_offset1 = New System.Windows.Forms.TextBox()
        Me.TextBox_G1 = New System.Windows.Forms.TextBox()
        Me.Button_calculate = New System.Windows.Forms.Button()
        Me.TextBox_G0 = New System.Windows.Forms.TextBox()
        Me.TextBox_offset0 = New System.Windows.Forms.TextBox()
        Me.Label464 = New System.Windows.Forms.Label()
        Me.GroupBox20 = New System.Windows.Forms.GroupBox()
        Me.GroupBox_1 = New System.Windows.Forms.GroupBox()
        Me.Label461 = New System.Windows.Forms.Label()
        Me.TextBox_input_1 = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TextBox_Raw_ADC = New System.Windows.Forms.TextBox()
        Me.GroupBox_2 = New System.Windows.Forms.GroupBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TextBox_input_2 = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TextBox_RAW_ADC_2 = New System.Windows.Forms.TextBox()
        Me.Button_Read_Adc = New System.Windows.Forms.Button()
        Me.ListBox_adc = New System.Windows.Forms.ListBox()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.Button_Disable_Factory_Mode = New System.Windows.Forms.Button()
        Me.MFR_EN = New System.Windows.Forms.Button()
        Me.GroupBox15 = New System.Windows.Forms.GroupBox()
        Me.Button_S_Disable = New System.Windows.Forms.Button()
        Me.Button_S_Enable = New System.Windows.Forms.Button()
        Me.CheckBox5 = New System.Windows.Forms.CheckBox()
        Me.RadioButton_Disable = New System.Windows.Forms.RadioButton()
        Me.RadioButton_Enable = New System.Windows.Forms.RadioButton()
        Me.GroupBox13 = New System.Windows.Forms.GroupBox()
        Me.RadioButton_s = New System.Windows.Forms.RadioButton()
        Me.RadioButton_p = New System.Windows.Forms.RadioButton()
        Me.Button_Cab_Read = New System.Windows.Forms.Button()
        Me.Button27 = New System.Windows.Forms.Button()
        Me.ListBox_index = New System.Windows.Forms.ListBox()
        Me.Label462 = New System.Windows.Forms.Label()
        Me.Button_Execute = New System.Windows.Forms.Button()
        Me.Tab_Log = New System.Windows.Forms.TabPage()
        Me.Button_LogRead = New System.Windows.Forms.Button()
        Me.DataGridView_LOG = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn16 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn17 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn20 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn22 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn23 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Tab_FRU = New System.Windows.Forms.TabPage()
        Me.GroupBox19 = New System.Windows.Forms.GroupBox()
        Me.Button_Write_Page = New System.Windows.Forms.Button()
        Me.Button_Read_All = New System.Windows.Forms.Button()
        Me.Button_Write_ee = New System.Windows.Forms.Button()
        Me.Button_Clear_FRU = New System.Windows.Forms.Button()
        Me.Button_FRU_File = New System.Windows.Forms.Button()
        Me.BTN_FRU_Read = New System.Windows.Forms.Button()
        Me.GroupBox16 = New System.Windows.Forms.GroupBox()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.TextBox_Read_EE_Byte_Count = New System.Windows.Forms.TextBox()
        Me.TextBox_Write_EE_Byte2 = New System.Windows.Forms.TextBox()
        Me.TextBox_Write_EE_Byte1 = New System.Windows.Forms.TextBox()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.TextBox_Write_EE_Word_Addr = New System.Windows.Forms.TextBox()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.DataGridView_ee = New System.Windows.Forms.DataGridView()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column16 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column17 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Tab_Statistics = New System.Windows.Forms.TabPage()
        Me.Chart1 = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.Tab_About = New System.Windows.Forms.TabPage()
        Me.RichTextBox2 = New System.Windows.Forms.RichTextBox()
        Me.Tag_Help = New System.Windows.Forms.TabPage()
        Me.RichTextBox3 = New System.Windows.Forms.RichTextBox()
        Me.GroupBox12 = New System.Windows.Forms.GroupBox()
        Me.TextBox40 = New System.Windows.Forms.TextBox()
        Me.TextBox41 = New System.Windows.Forms.TextBox()
        Me.TextBox42 = New System.Windows.Forms.TextBox()
        Me.TextBox43 = New System.Windows.Forms.TextBox()
        Me.NumericUpDown14 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown18 = New System.Windows.Forms.NumericUpDown()
        Me.Label459 = New System.Windows.Forms.Label()
        Me.Label460 = New System.Windows.Forms.Label()
        Me.Button28 = New System.Windows.Forms.Button()
        Me.NumericUpDown_r_b = New System.Windows.Forms.NumericUpDown()
        Me.Button30 = New System.Windows.Forms.Button()
        Me.NumericUpDown_w_index = New System.Windows.Forms.NumericUpDown()
        Me.Test = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_EEPROM_Addr = New System.Windows.Forms.NumericUpDown()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.NumericUpDown7 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_S_Addr = New System.Windows.Forms.NumericUpDown()
        Me.PICkitConnect = New System.Windows.Forms.Button()
        Me.RadioButton16 = New System.Windows.Forms.RadioButton()
        Me.RadioButton17 = New System.Windows.Forms.RadioButton()
        Me.GroupBox17 = New System.Windows.Forms.GroupBox()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.StatusStrip1.SuspendLayout()
        Me.Tab_Read.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        CType(Me.NumericUpDown21, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControl1.SuspendLayout()
        Me.Tab_MFR.SuspendLayout()
        CType(Me.DataGridView_MFR, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Tab_Constant.SuspendLayout()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Tab_Status.SuspendLayout()
        Me.GroupBox10.SuspendLayout()
        CType(Me.NumericUpDown_cmd_r, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_page, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox65, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox66, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox67, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox68, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox69, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox70, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox71, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox72, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox73, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox74, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox75, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox76, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox77, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox78, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox79, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox80, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox81, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox82, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox83, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox84, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox85, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox86, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox87, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox88, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox89, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox90, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox91, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox92, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox93, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox94, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox95, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox96, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox97, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox_Busy, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox99, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox100, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox101, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox102, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox103, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox104, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox105, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox106, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox107, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox108, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox109, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox110, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox111, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox112, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox113, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox_OFF, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox115, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox116, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox117, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox118, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox119, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox120, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox121, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox122, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox123, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox124, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox125, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox126, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox127, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox128, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox129, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox_VOUT_OV, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox131, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox132, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox133, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox134, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox135, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox136, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox137, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox138, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox139, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox140, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox141, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox142, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox_IOUT_OC, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox144, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Tab_Control.SuspendLayout()
        Me.GroupBox18.SuspendLayout()
        Me.GroupBox14.SuspendLayout()
        CType(Me.NumericUpDown_Set_Warn, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_SET_IOUT_F, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_SET_Vbulk, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_SET_Duty, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox7.SuspendLayout()
        CType(Me.NumericUpDown23, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown24, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Tab_Calibration.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox20.SuspendLayout()
        Me.GroupBox_1.SuspendLayout()
        Me.GroupBox_2.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.GroupBox15.SuspendLayout()
        Me.GroupBox13.SuspendLayout()
        Me.Tab_Log.SuspendLayout()
        CType(Me.DataGridView_LOG, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Tab_FRU.SuspendLayout()
        Me.GroupBox19.SuspendLayout()
        Me.GroupBox16.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        CType(Me.DataGridView_ee, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Tab_Statistics.SuspendLayout()
        CType(Me.Chart1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Tab_About.SuspendLayout()
        Me.Tag_Help.SuspendLayout()
        Me.GroupBox12.SuspendLayout()
        CType(Me.NumericUpDown14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown18, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_r_b, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_w_index, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.NumericUpDown_EEPROM_Addr, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_S_Addr, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox17.SuspendLayout()
        Me.SuspendLayout()
        '
        'SaveFileDialog1
        '
        Me.SaveFileDialog1.FileName = "Pico_AC_Pri_Rev_xxxx.hex"
        Me.SaveFileDialog1.Filter = "Binary File|*.bin|All Files|*.*"
        Me.SaveFileDialog1.InitialDirectory = "C:\Users\Meravanagikiran\DocumentsPicoAC_Sec.X"
        '
        'SaveFileDialog2
        '
        Me.SaveFileDialog2.FileName = "Pico_AC_Pri_Rev_xxxxx.hex"
        Me.SaveFileDialog2.Filter = "Binary File|*.bin|All Files|*.*"
        Me.SaveFileDialog2.InitialDirectory = "C:\Users\Meravanagikiran\DocumentsPicoAC_Sec.X"
        '
        'RadioButton9
        '
        Me.RadioButton9.AutoCheck = False
        Me.RadioButton9.AutoSize = True
        Me.RadioButton9.BackColor = System.Drawing.Color.Transparent
        Me.RadioButton9.Enabled = False
        Me.RadioButton9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton9.Location = New System.Drawing.Point(1247, 128)
        Me.RadioButton9.Name = "RadioButton9"
        Me.RadioButton9.Size = New System.Drawing.Size(61, 19)
        Me.RadioButton9.TabIndex = 548
        Me.RadioButton9.Text = "PSU1"
        Me.RadioButton9.UseVisualStyleBackColor = False
        Me.RadioButton9.Visible = False
        '
        'RadioButton10
        '
        Me.RadioButton10.AutoCheck = False
        Me.RadioButton10.AutoSize = True
        Me.RadioButton10.BackColor = System.Drawing.Color.Transparent
        Me.RadioButton10.Enabled = False
        Me.RadioButton10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton10.Location = New System.Drawing.Point(1247, 148)
        Me.RadioButton10.Name = "RadioButton10"
        Me.RadioButton10.Size = New System.Drawing.Size(61, 19)
        Me.RadioButton10.TabIndex = 549
        Me.RadioButton10.Text = "PSU2"
        Me.RadioButton10.UseVisualStyleBackColor = False
        Me.RadioButton10.Visible = False
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 10
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.StatusStrip1.AutoSize = False
        Me.StatusStrip1.Dock = System.Windows.Forms.DockStyle.None
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripProgressBar1, Me.ToolStripStatusLabel2, Me.ToolStripStatusLabel1})
        Me.StatusStrip1.Location = New System.Drawing.Point(-371, 642)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(1282, 25)
        Me.StatusStrip1.TabIndex = 552
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripProgressBar1
        '
        Me.ToolStripProgressBar1.ForeColor = System.Drawing.Color.Lime
        Me.ToolStripProgressBar1.Name = "ToolStripProgressBar1"
        Me.ToolStripProgressBar1.Size = New System.Drawing.Size(300, 19)
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.AutoSize = False
        Me.ToolStripStatusLabel2.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold)
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(480, 20)
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.AutoSize = False
        Me.ToolStripStatusLabel1.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.ToolStripStatusLabel1.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me.ToolStripStatusLabel1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ToolStripStatusLabel1.Font = New System.Drawing.Font("Times New Roman", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(250, 20)
        '
        'Timer2
        '
        Me.Timer2.Enabled = True
        Me.Timer2.Interval = 1000
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        Me.OpenFileDialog1.Filter = "Primary MCU Setting Files|*.pri|All Files|*.*"
        Me.OpenFileDialog1.InitialDirectory = "C:\Users\Meravanagikiran\Documents"
        Me.OpenFileDialog1.RestoreDirectory = True
        '
        'RadioButton11
        '
        Me.RadioButton11.AutoCheck = False
        Me.RadioButton11.AutoSize = True
        Me.RadioButton11.BackColor = System.Drawing.Color.Transparent
        Me.RadioButton11.Enabled = False
        Me.RadioButton11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton11.Location = New System.Drawing.Point(1247, 168)
        Me.RadioButton11.Name = "RadioButton11"
        Me.RadioButton11.Size = New System.Drawing.Size(61, 19)
        Me.RadioButton11.TabIndex = 550
        Me.RadioButton11.Text = "PSU3"
        Me.RadioButton11.UseVisualStyleBackColor = False
        Me.RadioButton11.Visible = False
        '
        'Tab_Read
        '
        Me.Tab_Read.AllowDrop = True
        Me.Tab_Read.BackColor = System.Drawing.Color.FloralWhite
        Me.Tab_Read.Controls.Add(Me.DataGridView1)
        Me.Tab_Read.Controls.Add(Me.GroupBox5)
        Me.Tab_Read.Controls.Add(Me.Poll)
        Me.Tab_Read.Controls.Add(Me.ReadOnce)
        Me.Tab_Read.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tab_Read.Location = New System.Drawing.Point(4, 32)
        Me.Tab_Read.Name = "Tab_Read"
        Me.Tab_Read.Padding = New System.Windows.Forms.Padding(3)
        Me.Tab_Read.Size = New System.Drawing.Size(1193, 421)
        Me.Tab_Read.TabIndex = 0
        Me.Tab_Read.Text = "Read"
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AllowUserToResizeColumns = False
        Me.DataGridView1.AllowUserToResizeRows = False
        Me.DataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Cmd, Me.DataGridViewTextBoxColumn18, Me.DataGridViewTextBoxColumn19, Me.DataGridViewTextBoxColumn21})
        Me.DataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.DataGridView1.GridColor = System.Drawing.SystemColors.Control
        Me.DataGridView1.Location = New System.Drawing.Point(0, 0)
        Me.DataGridView1.MultiSelect = False
        Me.DataGridView1.Name = "DataGridView1"
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.ControlDark
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.NullValue = "0"
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.RowHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.DataGridView1.RowHeadersVisible = False
        Me.DataGridView1.RowHeadersWidth = 195
        Me.DataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.DataGridView1.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.DataGridView1.RowTemplate.DefaultCellStyle.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DataGridView1.RowTemplate.Height = 19
        Me.DataGridView1.RowTemplate.ReadOnly = True
        Me.DataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.DataGridView1.Size = New System.Drawing.Size(584, 395)
        Me.DataGridView1.TabIndex = 46
        '
        'Column1
        '
        Me.Column1.HeaderText = "Cmd"
        Me.Column1.Name = "Column1"
        Me.Column1.Width = 35
        '
        'Cmd
        '
        Me.Cmd.HeaderText = "Command Name"
        Me.Cmd.Name = "Cmd"
        Me.Cmd.Width = 135
        '
        'DataGridViewTextBoxColumn18
        '
        Me.DataGridViewTextBoxColumn18.HeaderText = "With PEC"
        Me.DataGridViewTextBoxColumn18.Name = "DataGridViewTextBoxColumn18"
        Me.DataGridViewTextBoxColumn18.Width = 88
        '
        'DataGridViewTextBoxColumn19
        '
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DataGridViewTextBoxColumn19.DefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridViewTextBoxColumn19.HeaderText = "Hex Data"
        Me.DataGridViewTextBoxColumn19.Name = "DataGridViewTextBoxColumn19"
        Me.DataGridViewTextBoxColumn19.Width = 80
        '
        'DataGridViewTextBoxColumn21
        '
        Me.DataGridViewTextBoxColumn21.HeaderText = "Actual"
        Me.DataGridViewTextBoxColumn21.Name = "DataGridViewTextBoxColumn21"
        Me.DataGridViewTextBoxColumn21.Width = 90
        '
        'GroupBox5
        '
        Me.GroupBox5.BackColor = System.Drawing.Color.AliceBlue
        Me.GroupBox5.Controls.Add(Me.Label232)
        Me.GroupBox5.Controls.Add(Me.Label230)
        Me.GroupBox5.Controls.Add(Me.Label90)
        Me.GroupBox5.Controls.Add(Me.Label83)
        Me.GroupBox5.Controls.Add(Me.Label81)
        Me.GroupBox5.Controls.Add(Me.Label222)
        Me.GroupBox5.Controls.Add(Me.Label220)
        Me.GroupBox5.Controls.Add(Me.TextBox3)
        Me.GroupBox5.Controls.Add(Me.Label348)
        Me.GroupBox5.Controls.Add(Me.Button_Status_VOUT)
        Me.GroupBox5.Controls.Add(Me.Button4)
        Me.GroupBox5.Controls.Add(Me.NumericUpDown21)
        Me.GroupBox5.Controls.Add(Me.Label275)
        Me.GroupBox5.Controls.Add(Me.Label327)
        Me.GroupBox5.Controls.Add(Me.Label272)
        Me.GroupBox5.Controls.Add(Me.Label269)
        Me.GroupBox5.Controls.Add(Me.Button103)
        Me.GroupBox5.Controls.Add(Me.Label268)
        Me.GroupBox5.Controls.Add(Me.Button104)
        Me.GroupBox5.Controls.Add(Me.Label264)
        Me.GroupBox5.Controls.Add(Me.CheckBox6)
        Me.GroupBox5.Controls.Add(Me.Label252)
        Me.GroupBox5.Controls.Add(Me.CheckBox7)
        Me.GroupBox5.Controls.Add(Me.Label246)
        Me.GroupBox5.Controls.Add(Me.CheckBox8)
        Me.GroupBox5.Controls.Add(Me.TextBox89)
        Me.GroupBox5.Controls.Add(Me.CheckBox9)
        Me.GroupBox5.Controls.Add(Me.TextBox27)
        Me.GroupBox5.Controls.Add(Me.CheckBox10)
        Me.GroupBox5.Controls.Add(Me.CheckBox20)
        Me.GroupBox5.Controls.Add(Me.CheckBox11)
        Me.GroupBox5.Controls.Add(Me.CheckBox19)
        Me.GroupBox5.Controls.Add(Me.CheckBox12)
        Me.GroupBox5.Controls.Add(Me.CheckBox18)
        Me.GroupBox5.Controls.Add(Me.CheckBox69)
        Me.GroupBox5.Controls.Add(Me.CheckBox17)
        Me.GroupBox5.Controls.Add(Me.TextBox31)
        Me.GroupBox5.Controls.Add(Me.CheckBox16)
        Me.GroupBox5.Controls.Add(Me.TextBox84)
        Me.GroupBox5.Controls.Add(Me.CheckBox15)
        Me.GroupBox5.Controls.Add(Me.Label347)
        Me.GroupBox5.Controls.Add(Me.CheckBox14)
        Me.GroupBox5.Controls.Add(Me.CheckBox13)
        Me.GroupBox5.Controls.Add(Me.TextBox26)
        Me.GroupBox5.Controls.Add(Me.TextBox23)
        Me.GroupBox5.Controls.Add(Me.Label131)
        Me.GroupBox5.Controls.Add(Me.CheckBox28)
        Me.GroupBox5.Controls.Add(Me.Label279)
        Me.GroupBox5.Controls.Add(Me.CheckBox27)
        Me.GroupBox5.Controls.Add(Me.Label277)
        Me.GroupBox5.Controls.Add(Me.CheckBox26)
        Me.GroupBox5.Controls.Add(Me.Label276)
        Me.GroupBox5.Controls.Add(Me.CheckBox25)
        Me.GroupBox5.Controls.Add(Me.CheckBox24)
        Me.GroupBox5.Controls.Add(Me.Button101)
        Me.GroupBox5.Controls.Add(Me.CheckBox23)
        Me.GroupBox5.Controls.Add(Me.Button102)
        Me.GroupBox5.Controls.Add(Me.CheckBox22)
        Me.GroupBox5.Controls.Add(Me.Button99)
        Me.GroupBox5.Controls.Add(Me.CheckBox21)
        Me.GroupBox5.Controls.Add(Me.Button100)
        Me.GroupBox5.Controls.Add(Me.TextBox22)
        Me.GroupBox5.Controls.Add(Me.Button97)
        Me.GroupBox5.Controls.Add(Me.TextBox21)
        Me.GroupBox5.Controls.Add(Me.Button98)
        Me.GroupBox5.Controls.Add(Me.CheckBox36)
        Me.GroupBox5.Controls.Add(Me.Button95)
        Me.GroupBox5.Controls.Add(Me.CheckBox35)
        Me.GroupBox5.Controls.Add(Me.Button96)
        Me.GroupBox5.Controls.Add(Me.CheckBox34)
        Me.GroupBox5.Controls.Add(Me.Button91)
        Me.GroupBox5.Controls.Add(Me.CheckBox33)
        Me.GroupBox5.Controls.Add(Me.Button92)
        Me.GroupBox5.Controls.Add(Me.CheckBox32)
        Me.GroupBox5.Controls.Add(Me.Button89)
        Me.GroupBox5.Controls.Add(Me.CheckBox31)
        Me.GroupBox5.Controls.Add(Me.Button90)
        Me.GroupBox5.Controls.Add(Me.CheckBox30)
        Me.GroupBox5.Controls.Add(Me.Label76)
        Me.GroupBox5.Controls.Add(Me.CheckBox29)
        Me.GroupBox5.Controls.Add(Me.Label77)
        Me.GroupBox5.Controls.Add(Me.TextBox20)
        Me.GroupBox5.Controls.Add(Me.Label79)
        Me.GroupBox5.Controls.Add(Me.TextBox7)
        Me.GroupBox5.Controls.Add(Me.Label80)
        Me.GroupBox5.Controls.Add(Me.CheckBox44)
        Me.GroupBox5.Controls.Add(Me.Label89)
        Me.GroupBox5.Controls.Add(Me.CheckBox43)
        Me.GroupBox5.Controls.Add(Me.CheckBox42)
        Me.GroupBox5.Controls.Add(Me.CheckBox41)
        Me.GroupBox5.Controls.Add(Me.CheckBox40)
        Me.GroupBox5.Controls.Add(Me.Label95)
        Me.GroupBox5.Controls.Add(Me.CheckBox39)
        Me.GroupBox5.Controls.Add(Me.Label125)
        Me.GroupBox5.Controls.Add(Me.CheckBox38)
        Me.GroupBox5.Controls.Add(Me.Label127)
        Me.GroupBox5.Controls.Add(Me.CheckBox37)
        Me.GroupBox5.Controls.Add(Me.Label134)
        Me.GroupBox5.Controls.Add(Me.TextBox6)
        Me.GroupBox5.Controls.Add(Me.Label135)
        Me.GroupBox5.Controls.Add(Me.TextBox5)
        Me.GroupBox5.Controls.Add(Me.CheckBox61)
        Me.GroupBox5.Controls.Add(Me.CheckBox52)
        Me.GroupBox5.Controls.Add(Me.CheckBox62)
        Me.GroupBox5.Controls.Add(Me.CheckBox51)
        Me.GroupBox5.Controls.Add(Me.CheckBox63)
        Me.GroupBox5.Controls.Add(Me.CheckBox50)
        Me.GroupBox5.Controls.Add(Me.CheckBox64)
        Me.GroupBox5.Controls.Add(Me.CheckBox49)
        Me.GroupBox5.Controls.Add(Me.CheckBox65)
        Me.GroupBox5.Controls.Add(Me.CheckBox48)
        Me.GroupBox5.Controls.Add(Me.CheckBox66)
        Me.GroupBox5.Controls.Add(Me.CheckBox47)
        Me.GroupBox5.Controls.Add(Me.CheckBox67)
        Me.GroupBox5.Controls.Add(Me.CheckBox46)
        Me.GroupBox5.Controls.Add(Me.CheckBox68)
        Me.GroupBox5.Controls.Add(Me.CheckBox45)
        Me.GroupBox5.Controls.Add(Me.TextBox1)
        Me.GroupBox5.Controls.Add(Me.TextBox4)
        Me.GroupBox5.Controls.Add(Me.TextBox2)
        Me.GroupBox5.Controls.Add(Me.CheckBox53)
        Me.GroupBox5.Controls.Add(Me.CheckBox60)
        Me.GroupBox5.Controls.Add(Me.CheckBox54)
        Me.GroupBox5.Controls.Add(Me.CheckBox59)
        Me.GroupBox5.Controls.Add(Me.CheckBox55)
        Me.GroupBox5.Controls.Add(Me.CheckBox58)
        Me.GroupBox5.Controls.Add(Me.CheckBox56)
        Me.GroupBox5.Controls.Add(Me.CheckBox57)
        Me.GroupBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox5.Location = New System.Drawing.Point(590, 198)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(556, 174)
        Me.GroupBox5.TabIndex = 476
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "SMB_Alert Making Conjunction  With Page Plus Write"
        Me.GroupBox5.Visible = False
        '
        'Label232
        '
        Me.Label232.AutoSize = True
        Me.Label232.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label232.Location = New System.Drawing.Point(378, 262)
        Me.Label232.Name = "Label232"
        Me.Label232.Size = New System.Drawing.Size(37, 9)
        Me.Label232.TabIndex = 482
        Me.Label232.Text = "Oring_Flt"
        '
        'Label230
        '
        Me.Label230.AutoSize = True
        Me.Label230.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label230.Location = New System.Drawing.Point(414, 262)
        Me.Label230.Name = "Label230"
        Me.Label230.Size = New System.Drawing.Size(27, 9)
        Me.Label230.TabIndex = 481
        Me.Label230.Text = "Invalid"
        '
        'Label90
        '
        Me.Label90.AutoSize = True
        Me.Label90.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label90.Location = New System.Drawing.Point(416, 176)
        Me.Label90.Name = "Label90"
        Me.Label90.Size = New System.Drawing.Size(24, 9)
        Me.Label90.TabIndex = 480
        Me.Label90.Text = "MEM"
        '
        'Label83
        '
        Me.Label83.AutoSize = True
        Me.Label83.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label83.Location = New System.Drawing.Point(382, 177)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(31, 9)
        Me.Label83.TabIndex = 479
        Me.Label83.Text = "COMM"
        '
        'Label81
        '
        Me.Label81.AutoSize = True
        Me.Label81.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label81.Location = New System.Drawing.Point(323, 177)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(33, 9)
        Me.Label81.TabIndex = 478
        Me.Label81.Text = "PRCSR"
        '
        'Label222
        '
        Me.Label222.AutoSize = True
        Me.Label222.Enabled = False
        Me.Label222.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label222.Location = New System.Drawing.Point(518, 46)
        Me.Label222.Name = "Label222"
        Me.Label222.Size = New System.Drawing.Size(58, 12)
        Me.Label222.TabIndex = 477
        Me.Label222.Text = "BW_BRPC"
        Me.Label222.Visible = False
        '
        'Label220
        '
        Me.Label220.AutoSize = True
        Me.Label220.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label220.Location = New System.Drawing.Point(440, 45)
        Me.Label220.Name = "Label220"
        Me.Label220.Size = New System.Drawing.Size(63, 12)
        Me.Label220.TabIndex = 476
        Me.Label220.Text = "Write Block"
        '
        'TextBox3
        '
        Me.TextBox3.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.TextBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox3.Location = New System.Drawing.Point(171, 182)
        Me.TextBox3.MaxLength = 2
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.ReadOnly = True
        Me.TextBox3.Size = New System.Drawing.Size(27, 23)
        Me.TextBox3.TabIndex = 475
        '
        'Label348
        '
        Me.Label348.AutoSize = True
        Me.Label348.BackColor = System.Drawing.Color.Yellow
        Me.Label348.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label348.Location = New System.Drawing.Point(80, 40)
        Me.Label348.Name = "Label348"
        Me.Label348.Size = New System.Drawing.Size(45, 17)
        Me.Label348.TabIndex = 474
        Me.Label348.Text = "Page"
        '
        'Button_Status_VOUT
        '
        Me.Button_Status_VOUT.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Status_VOUT.Location = New System.Drawing.Point(442, 65)
        Me.Button_Status_VOUT.Name = "Button_Status_VOUT"
        Me.Button_Status_VOUT.Size = New System.Drawing.Size(62, 23)
        Me.Button_Status_VOUT.TabIndex = 281
        Me.Button_Status_VOUT.Text = "Write"
        Me.Button_Status_VOUT.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Enabled = False
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Location = New System.Drawing.Point(517, 65)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(62, 23)
        Me.Button4.TabIndex = 282
        Me.Button4.Text = "Read"
        Me.Button4.UseVisualStyleBackColor = True
        Me.Button4.Visible = False
        '
        'NumericUpDown21
        '
        Me.NumericUpDown21.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericUpDown21.Location = New System.Drawing.Point(133, 37)
        Me.NumericUpDown21.Maximum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown21.Name = "NumericUpDown21"
        Me.NumericUpDown21.Size = New System.Drawing.Size(65, 23)
        Me.NumericUpDown21.TabIndex = 473
        Me.NumericUpDown21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label275
        '
        Me.Label275.AutoSize = True
        Me.Label275.BackColor = System.Drawing.Color.Yellow
        Me.Label275.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label275.Location = New System.Drawing.Point(25, 69)
        Me.Label275.Name = "Label275"
        Me.Label275.Size = New System.Drawing.Size(102, 17)
        Me.Label275.TabIndex = 283
        Me.Label275.Text = "Status VOUT"
        '
        'Label327
        '
        Me.Label327.AutoSize = True
        Me.Label327.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label327.Location = New System.Drawing.Point(409, 234)
        Me.Label327.Name = "Label327"
        Me.Label327.Size = New System.Drawing.Size(38, 9)
        Me.Label327.TabIndex = 419
        Me.Label327.Text = "VSB_FLT"
        '
        'Label272
        '
        Me.Label272.AutoSize = True
        Me.Label272.BackColor = System.Drawing.Color.Yellow
        Me.Label272.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label272.Location = New System.Drawing.Point(38, 97)
        Me.Label272.Name = "Label272"
        Me.Label272.Size = New System.Drawing.Size(96, 17)
        Me.Label272.TabIndex = 284
        Me.Label272.Text = "Status IOUT"
        '
        'Label269
        '
        Me.Label269.AutoSize = True
        Me.Label269.BackColor = System.Drawing.Color.Yellow
        Me.Label269.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label269.Location = New System.Drawing.Point(28, 152)
        Me.Label269.Name = "Label269"
        Me.Label269.Size = New System.Drawing.Size(99, 17)
        Me.Label269.TabIndex = 285
        Me.Label269.Text = "Status Temp"
        '
        'Button103
        '
        Me.Button103.Enabled = False
        Me.Button103.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button103.Location = New System.Drawing.Point(517, 268)
        Me.Button103.Name = "Button103"
        Me.Button103.Size = New System.Drawing.Size(62, 23)
        Me.Button103.TabIndex = 417
        Me.Button103.Text = "Read"
        Me.Button103.UseVisualStyleBackColor = True
        Me.Button103.Visible = False
        '
        'Label268
        '
        Me.Label268.AutoSize = True
        Me.Label268.BackColor = System.Drawing.Color.Yellow
        Me.Label268.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label268.Location = New System.Drawing.Point(22, 124)
        Me.Label268.Name = "Label268"
        Me.Label268.Size = New System.Drawing.Size(105, 17)
        Me.Label268.TabIndex = 286
        Me.Label268.Text = "Status INPUT"
        '
        'Button104
        '
        Me.Button104.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button104.Location = New System.Drawing.Point(442, 268)
        Me.Button104.Name = "Button104"
        Me.Button104.Size = New System.Drawing.Size(62, 23)
        Me.Button104.TabIndex = 416
        Me.Button104.Text = "Write"
        Me.Button104.UseVisualStyleBackColor = True
        '
        'Label264
        '
        Me.Label264.AutoSize = True
        Me.Label264.BackColor = System.Drawing.Color.Yellow
        Me.Label264.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label264.Location = New System.Drawing.Point(11, 218)
        Me.Label264.Name = "Label264"
        Me.Label264.Size = New System.Drawing.Size(116, 17)
        Me.Label264.TabIndex = 287
        Me.Label264.Text = "Status FAN_12"
        '
        'CheckBox6
        '
        Me.CheckBox6.AutoSize = True
        Me.CheckBox6.Location = New System.Drawing.Point(391, 274)
        Me.CheckBox6.Name = "CheckBox6"
        Me.CheckBox6.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox6.TabIndex = 415
        Me.CheckBox6.UseVisualStyleBackColor = True
        '
        'Label252
        '
        Me.Label252.AutoSize = True
        Me.Label252.BackColor = System.Drawing.Color.Yellow
        Me.Label252.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label252.Location = New System.Drawing.Point(38, 186)
        Me.Label252.Name = "Label252"
        Me.Label252.Size = New System.Drawing.Size(90, 17)
        Me.Label252.TabIndex = 288
        Me.Label252.Text = "Status CML"
        '
        'CheckBox7
        '
        Me.CheckBox7.AutoSize = True
        Me.CheckBox7.Location = New System.Drawing.Point(361, 274)
        Me.CheckBox7.Name = "CheckBox7"
        Me.CheckBox7.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox7.TabIndex = 414
        Me.CheckBox7.UseVisualStyleBackColor = True
        '
        'Label246
        '
        Me.Label246.AutoSize = True
        Me.Label246.BackColor = System.Drawing.Color.Yellow
        Me.Label246.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label246.Location = New System.Drawing.Point(38, 244)
        Me.Label246.Name = "Label246"
        Me.Label246.Size = New System.Drawing.Size(91, 17)
        Me.Label246.TabIndex = 289
        Me.Label246.Text = "Status MFR"
        '
        'CheckBox8
        '
        Me.CheckBox8.AutoSize = True
        Me.CheckBox8.Location = New System.Drawing.Point(331, 274)
        Me.CheckBox8.Name = "CheckBox8"
        Me.CheckBox8.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox8.TabIndex = 413
        Me.CheckBox8.UseVisualStyleBackColor = True
        '
        'TextBox89
        '
        Me.TextBox89.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox89.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox89.Location = New System.Drawing.Point(133, 66)
        Me.TextBox89.MaxLength = 2
        Me.TextBox89.Name = "TextBox89"
        Me.TextBox89.ReadOnly = True
        Me.TextBox89.Size = New System.Drawing.Size(27, 23)
        Me.TextBox89.TabIndex = 300
        '
        'CheckBox9
        '
        Me.CheckBox9.AutoSize = True
        Me.CheckBox9.Location = New System.Drawing.Point(301, 274)
        Me.CheckBox9.Name = "CheckBox9"
        Me.CheckBox9.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox9.TabIndex = 412
        Me.CheckBox9.UseVisualStyleBackColor = True
        '
        'TextBox27
        '
        Me.TextBox27.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.TextBox27.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox27.Location = New System.Drawing.Point(171, 66)
        Me.TextBox27.MaxLength = 2
        Me.TextBox27.Name = "TextBox27"
        Me.TextBox27.ReadOnly = True
        Me.TextBox27.Size = New System.Drawing.Size(27, 23)
        Me.TextBox27.TabIndex = 301
        '
        'CheckBox10
        '
        Me.CheckBox10.AutoSize = True
        Me.CheckBox10.Location = New System.Drawing.Point(271, 274)
        Me.CheckBox10.Name = "CheckBox10"
        Me.CheckBox10.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox10.TabIndex = 411
        Me.CheckBox10.UseVisualStyleBackColor = True
        '
        'CheckBox20
        '
        Me.CheckBox20.AutoSize = True
        Me.CheckBox20.Location = New System.Drawing.Point(421, 70)
        Me.CheckBox20.Name = "CheckBox20"
        Me.CheckBox20.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox20.TabIndex = 302
        Me.CheckBox20.UseVisualStyleBackColor = True
        '
        'CheckBox11
        '
        Me.CheckBox11.AutoSize = True
        Me.CheckBox11.Location = New System.Drawing.Point(241, 274)
        Me.CheckBox11.Name = "CheckBox11"
        Me.CheckBox11.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox11.TabIndex = 410
        Me.CheckBox11.UseVisualStyleBackColor = True
        '
        'CheckBox19
        '
        Me.CheckBox19.AutoSize = True
        Me.CheckBox19.Location = New System.Drawing.Point(211, 71)
        Me.CheckBox19.Name = "CheckBox19"
        Me.CheckBox19.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox19.TabIndex = 303
        Me.CheckBox19.UseVisualStyleBackColor = True
        '
        'CheckBox12
        '
        Me.CheckBox12.AutoSize = True
        Me.CheckBox12.Location = New System.Drawing.Point(211, 274)
        Me.CheckBox12.Name = "CheckBox12"
        Me.CheckBox12.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox12.TabIndex = 409
        Me.CheckBox12.UseVisualStyleBackColor = True
        '
        'CheckBox18
        '
        Me.CheckBox18.AutoSize = True
        Me.CheckBox18.Location = New System.Drawing.Point(241, 71)
        Me.CheckBox18.Name = "CheckBox18"
        Me.CheckBox18.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox18.TabIndex = 304
        Me.CheckBox18.UseVisualStyleBackColor = True
        '
        'CheckBox69
        '
        Me.CheckBox69.AutoSize = True
        Me.CheckBox69.Location = New System.Drawing.Point(421, 273)
        Me.CheckBox69.Name = "CheckBox69"
        Me.CheckBox69.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox69.TabIndex = 408
        Me.CheckBox69.UseVisualStyleBackColor = True
        '
        'CheckBox17
        '
        Me.CheckBox17.AutoSize = True
        Me.CheckBox17.Location = New System.Drawing.Point(271, 71)
        Me.CheckBox17.Name = "CheckBox17"
        Me.CheckBox17.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox17.TabIndex = 305
        Me.CheckBox17.UseVisualStyleBackColor = True
        '
        'TextBox31
        '
        Me.TextBox31.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.TextBox31.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox31.Location = New System.Drawing.Point(171, 269)
        Me.TextBox31.MaxLength = 2
        Me.TextBox31.Name = "TextBox31"
        Me.TextBox31.ReadOnly = True
        Me.TextBox31.Size = New System.Drawing.Size(27, 23)
        Me.TextBox31.TabIndex = 407
        '
        'CheckBox16
        '
        Me.CheckBox16.AutoSize = True
        Me.CheckBox16.Location = New System.Drawing.Point(301, 71)
        Me.CheckBox16.Name = "CheckBox16"
        Me.CheckBox16.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox16.TabIndex = 306
        Me.CheckBox16.UseVisualStyleBackColor = True
        '
        'TextBox84
        '
        Me.TextBox84.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox84.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox84.Location = New System.Drawing.Point(133, 269)
        Me.TextBox84.MaxLength = 2
        Me.TextBox84.Name = "TextBox84"
        Me.TextBox84.ReadOnly = True
        Me.TextBox84.Size = New System.Drawing.Size(27, 23)
        Me.TextBox84.TabIndex = 406
        '
        'CheckBox15
        '
        Me.CheckBox15.AutoSize = True
        Me.CheckBox15.Location = New System.Drawing.Point(331, 71)
        Me.CheckBox15.Name = "CheckBox15"
        Me.CheckBox15.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox15.TabIndex = 307
        Me.CheckBox15.UseVisualStyleBackColor = True
        '
        'Label347
        '
        Me.Label347.AutoSize = True
        Me.Label347.BackColor = System.Drawing.Color.Yellow
        Me.Label347.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label347.Location = New System.Drawing.Point(15, 273)
        Me.Label347.Name = "Label347"
        Me.Label347.Size = New System.Drawing.Size(113, 17)
        Me.Label347.TabIndex = 405
        Me.Label347.Text = "Status OTHER"
        '
        'CheckBox14
        '
        Me.CheckBox14.AutoSize = True
        Me.CheckBox14.Location = New System.Drawing.Point(361, 71)
        Me.CheckBox14.Name = "CheckBox14"
        Me.CheckBox14.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox14.TabIndex = 308
        Me.CheckBox14.UseVisualStyleBackColor = True
        '
        'CheckBox13
        '
        Me.CheckBox13.AutoSize = True
        Me.CheckBox13.Location = New System.Drawing.Point(391, 71)
        Me.CheckBox13.Name = "CheckBox13"
        Me.CheckBox13.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox13.TabIndex = 309
        Me.CheckBox13.UseVisualStyleBackColor = True
        '
        'TextBox26
        '
        Me.TextBox26.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox26.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox26.Location = New System.Drawing.Point(133, 95)
        Me.TextBox26.MaxLength = 2
        Me.TextBox26.Name = "TextBox26"
        Me.TextBox26.ReadOnly = True
        Me.TextBox26.Size = New System.Drawing.Size(27, 23)
        Me.TextBox26.TabIndex = 310
        '
        'TextBox23
        '
        Me.TextBox23.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.TextBox23.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox23.Location = New System.Drawing.Point(171, 95)
        Me.TextBox23.MaxLength = 2
        Me.TextBox23.Name = "TextBox23"
        Me.TextBox23.ReadOnly = True
        Me.TextBox23.Size = New System.Drawing.Size(27, 23)
        Me.TextBox23.TabIndex = 311
        '
        'Label131
        '
        Me.Label131.AutoSize = True
        Me.Label131.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label131.Location = New System.Drawing.Point(300, 119)
        Me.Label131.Name = "Label131"
        Me.Label131.Size = New System.Drawing.Size(16, 9)
        Me.Label131.TabIndex = 401
        Me.Label131.Text = "UV"
        '
        'CheckBox28
        '
        Me.CheckBox28.AutoSize = True
        Me.CheckBox28.Location = New System.Drawing.Point(421, 99)
        Me.CheckBox28.Name = "CheckBox28"
        Me.CheckBox28.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox28.TabIndex = 312
        Me.CheckBox28.UseVisualStyleBackColor = True
        '
        'Label279
        '
        Me.Label279.AutoSize = True
        Me.Label279.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label279.Location = New System.Drawing.Point(237, 119)
        Me.Label279.Name = "Label279"
        Me.Label279.Size = New System.Drawing.Size(24, 9)
        Me.Label279.TabIndex = 400
        Me.Label279.Text = "OVW"
        '
        'CheckBox27
        '
        Me.CheckBox27.AutoSize = True
        Me.CheckBox27.Location = New System.Drawing.Point(211, 100)
        Me.CheckBox27.Name = "CheckBox27"
        Me.CheckBox27.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox27.TabIndex = 313
        Me.CheckBox27.UseVisualStyleBackColor = True
        '
        'Label277
        '
        Me.Label277.AutoSize = True
        Me.Label277.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label277.Location = New System.Drawing.Point(210, 119)
        Me.Label277.Name = "Label277"
        Me.Label277.Size = New System.Drawing.Size(16, 9)
        Me.Label277.TabIndex = 399
        Me.Label277.Text = "OV"
        '
        'CheckBox26
        '
        Me.CheckBox26.AutoSize = True
        Me.CheckBox26.Location = New System.Drawing.Point(241, 100)
        Me.CheckBox26.Name = "CheckBox26"
        Me.CheckBox26.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox26.TabIndex = 314
        Me.CheckBox26.UseVisualStyleBackColor = True
        '
        'Label276
        '
        Me.Label276.AutoSize = True
        Me.Label276.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label276.Location = New System.Drawing.Point(266, 89)
        Me.Label276.Name = "Label276"
        Me.Label276.Size = New System.Drawing.Size(25, 9)
        Me.Label276.TabIndex = 398
        Me.Label276.Text = "OCW"
        '
        'CheckBox25
        '
        Me.CheckBox25.AutoSize = True
        Me.CheckBox25.Location = New System.Drawing.Point(271, 100)
        Me.CheckBox25.Name = "CheckBox25"
        Me.CheckBox25.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox25.TabIndex = 315
        Me.CheckBox25.UseVisualStyleBackColor = True
        '
        'CheckBox24
        '
        Me.CheckBox24.AutoSize = True
        Me.CheckBox24.Location = New System.Drawing.Point(301, 100)
        Me.CheckBox24.Name = "CheckBox24"
        Me.CheckBox24.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox24.TabIndex = 316
        Me.CheckBox24.UseVisualStyleBackColor = True
        '
        'Button101
        '
        Me.Button101.Enabled = False
        Me.Button101.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button101.Location = New System.Drawing.Point(517, 239)
        Me.Button101.Name = "Button101"
        Me.Button101.Size = New System.Drawing.Size(62, 23)
        Me.Button101.TabIndex = 396
        Me.Button101.Text = "Read"
        Me.Button101.UseVisualStyleBackColor = True
        Me.Button101.Visible = False
        '
        'CheckBox23
        '
        Me.CheckBox23.AutoSize = True
        Me.CheckBox23.Location = New System.Drawing.Point(331, 100)
        Me.CheckBox23.Name = "CheckBox23"
        Me.CheckBox23.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox23.TabIndex = 317
        Me.CheckBox23.UseVisualStyleBackColor = True
        '
        'Button102
        '
        Me.Button102.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button102.Location = New System.Drawing.Point(442, 239)
        Me.Button102.Name = "Button102"
        Me.Button102.Size = New System.Drawing.Size(62, 23)
        Me.Button102.TabIndex = 395
        Me.Button102.Text = "Write"
        Me.Button102.UseVisualStyleBackColor = True
        '
        'CheckBox22
        '
        Me.CheckBox22.AutoSize = True
        Me.CheckBox22.Location = New System.Drawing.Point(361, 100)
        Me.CheckBox22.Name = "CheckBox22"
        Me.CheckBox22.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox22.TabIndex = 318
        Me.CheckBox22.UseVisualStyleBackColor = True
        '
        'Button99
        '
        Me.Button99.Enabled = False
        Me.Button99.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button99.Location = New System.Drawing.Point(517, 181)
        Me.Button99.Name = "Button99"
        Me.Button99.Size = New System.Drawing.Size(62, 23)
        Me.Button99.TabIndex = 394
        Me.Button99.Text = "Read"
        Me.Button99.UseVisualStyleBackColor = True
        Me.Button99.Visible = False
        '
        'CheckBox21
        '
        Me.CheckBox21.AutoSize = True
        Me.CheckBox21.Location = New System.Drawing.Point(391, 100)
        Me.CheckBox21.Name = "CheckBox21"
        Me.CheckBox21.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox21.TabIndex = 319
        Me.CheckBox21.UseVisualStyleBackColor = True
        '
        'Button100
        '
        Me.Button100.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button100.Location = New System.Drawing.Point(442, 181)
        Me.Button100.Name = "Button100"
        Me.Button100.Size = New System.Drawing.Size(62, 23)
        Me.Button100.TabIndex = 393
        Me.Button100.Text = "Write"
        Me.Button100.UseVisualStyleBackColor = True
        '
        'TextBox22
        '
        Me.TextBox22.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox22.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox22.Location = New System.Drawing.Point(133, 153)
        Me.TextBox22.MaxLength = 2
        Me.TextBox22.Name = "TextBox22"
        Me.TextBox22.ReadOnly = True
        Me.TextBox22.Size = New System.Drawing.Size(27, 23)
        Me.TextBox22.TabIndex = 320
        '
        'Button97
        '
        Me.Button97.Enabled = False
        Me.Button97.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button97.Location = New System.Drawing.Point(517, 210)
        Me.Button97.Name = "Button97"
        Me.Button97.Size = New System.Drawing.Size(62, 23)
        Me.Button97.TabIndex = 392
        Me.Button97.Text = "Read"
        Me.Button97.UseVisualStyleBackColor = True
        Me.Button97.Visible = False
        '
        'TextBox21
        '
        Me.TextBox21.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.TextBox21.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox21.Location = New System.Drawing.Point(171, 153)
        Me.TextBox21.MaxLength = 2
        Me.TextBox21.Name = "TextBox21"
        Me.TextBox21.ReadOnly = True
        Me.TextBox21.Size = New System.Drawing.Size(27, 23)
        Me.TextBox21.TabIndex = 321
        '
        'Button98
        '
        Me.Button98.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button98.Location = New System.Drawing.Point(442, 210)
        Me.Button98.Name = "Button98"
        Me.Button98.Size = New System.Drawing.Size(62, 23)
        Me.Button98.TabIndex = 391
        Me.Button98.Text = "Write"
        Me.Button98.UseVisualStyleBackColor = True
        '
        'CheckBox36
        '
        Me.CheckBox36.AutoSize = True
        Me.CheckBox36.Location = New System.Drawing.Point(421, 157)
        Me.CheckBox36.Name = "CheckBox36"
        Me.CheckBox36.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox36.TabIndex = 322
        Me.CheckBox36.UseVisualStyleBackColor = True
        '
        'Button95
        '
        Me.Button95.Enabled = False
        Me.Button95.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button95.Location = New System.Drawing.Point(517, 123)
        Me.Button95.Name = "Button95"
        Me.Button95.Size = New System.Drawing.Size(62, 23)
        Me.Button95.TabIndex = 390
        Me.Button95.Text = "Read"
        Me.Button95.UseVisualStyleBackColor = True
        Me.Button95.Visible = False
        '
        'CheckBox35
        '
        Me.CheckBox35.AutoSize = True
        Me.CheckBox35.Location = New System.Drawing.Point(211, 158)
        Me.CheckBox35.Name = "CheckBox35"
        Me.CheckBox35.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox35.TabIndex = 323
        Me.CheckBox35.UseVisualStyleBackColor = True
        '
        'Button96
        '
        Me.Button96.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button96.Location = New System.Drawing.Point(442, 123)
        Me.Button96.Name = "Button96"
        Me.Button96.Size = New System.Drawing.Size(62, 23)
        Me.Button96.TabIndex = 389
        Me.Button96.Text = "Write"
        Me.Button96.UseVisualStyleBackColor = True
        '
        'CheckBox34
        '
        Me.CheckBox34.AutoSize = True
        Me.CheckBox34.Location = New System.Drawing.Point(241, 158)
        Me.CheckBox34.Name = "CheckBox34"
        Me.CheckBox34.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox34.TabIndex = 324
        Me.CheckBox34.UseVisualStyleBackColor = True
        '
        'Button91
        '
        Me.Button91.Enabled = False
        Me.Button91.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button91.Location = New System.Drawing.Point(517, 152)
        Me.Button91.Name = "Button91"
        Me.Button91.Size = New System.Drawing.Size(62, 23)
        Me.Button91.TabIndex = 388
        Me.Button91.Text = "Read"
        Me.Button91.UseVisualStyleBackColor = True
        Me.Button91.Visible = False
        '
        'CheckBox33
        '
        Me.CheckBox33.AutoSize = True
        Me.CheckBox33.Location = New System.Drawing.Point(271, 158)
        Me.CheckBox33.Name = "CheckBox33"
        Me.CheckBox33.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox33.TabIndex = 325
        Me.CheckBox33.UseVisualStyleBackColor = True
        '
        'Button92
        '
        Me.Button92.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button92.Location = New System.Drawing.Point(442, 152)
        Me.Button92.Name = "Button92"
        Me.Button92.Size = New System.Drawing.Size(62, 23)
        Me.Button92.TabIndex = 387
        Me.Button92.Text = "Write"
        Me.Button92.UseVisualStyleBackColor = True
        '
        'CheckBox32
        '
        Me.CheckBox32.AutoSize = True
        Me.CheckBox32.Location = New System.Drawing.Point(301, 158)
        Me.CheckBox32.Name = "CheckBox32"
        Me.CheckBox32.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox32.TabIndex = 326
        Me.CheckBox32.UseVisualStyleBackColor = True
        '
        'Button89
        '
        Me.Button89.Enabled = False
        Me.Button89.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button89.Location = New System.Drawing.Point(517, 94)
        Me.Button89.Name = "Button89"
        Me.Button89.Size = New System.Drawing.Size(62, 23)
        Me.Button89.TabIndex = 386
        Me.Button89.Text = "Read"
        Me.Button89.UseVisualStyleBackColor = True
        Me.Button89.Visible = False
        '
        'CheckBox31
        '
        Me.CheckBox31.AutoSize = True
        Me.CheckBox31.Location = New System.Drawing.Point(331, 158)
        Me.CheckBox31.Name = "CheckBox31"
        Me.CheckBox31.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox31.TabIndex = 327
        Me.CheckBox31.UseVisualStyleBackColor = True
        '
        'Button90
        '
        Me.Button90.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button90.Location = New System.Drawing.Point(442, 94)
        Me.Button90.Name = "Button90"
        Me.Button90.Size = New System.Drawing.Size(62, 23)
        Me.Button90.TabIndex = 385
        Me.Button90.Text = "Write"
        Me.Button90.UseVisualStyleBackColor = True
        '
        'CheckBox30
        '
        Me.CheckBox30.AutoSize = True
        Me.CheckBox30.Location = New System.Drawing.Point(361, 158)
        Me.CheckBox30.Name = "CheckBox30"
        Me.CheckBox30.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox30.TabIndex = 328
        Me.CheckBox30.UseVisualStyleBackColor = True
        '
        'Label76
        '
        Me.Label76.AutoSize = True
        Me.Label76.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label76.Location = New System.Drawing.Point(265, 176)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(31, 9)
        Me.Label76.TabIndex = 384
        Me.Label76.Text = "PEC Er"
        '
        'CheckBox29
        '
        Me.CheckBox29.AutoSize = True
        Me.CheckBox29.Location = New System.Drawing.Point(391, 158)
        Me.CheckBox29.Name = "CheckBox29"
        Me.CheckBox29.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox29.TabIndex = 329
        Me.CheckBox29.UseVisualStyleBackColor = True
        '
        'Label77
        '
        Me.Label77.AutoSize = True
        Me.Label77.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label77.Location = New System.Drawing.Point(230, 175)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(36, 9)
        Me.Label77.TabIndex = 383
        Me.Label77.Text = "US_Data"
        '
        'TextBox20
        '
        Me.TextBox20.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox20.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox20.Location = New System.Drawing.Point(133, 124)
        Me.TextBox20.MaxLength = 2
        Me.TextBox20.Name = "TextBox20"
        Me.TextBox20.ReadOnly = True
        Me.TextBox20.Size = New System.Drawing.Size(27, 23)
        Me.TextBox20.TabIndex = 330
        '
        'Label79
        '
        Me.Label79.AutoSize = True
        Me.Label79.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label79.Location = New System.Drawing.Point(197, 175)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(35, 9)
        Me.Label79.TabIndex = 382
        Me.Label79.Text = "US Cmd"
        '
        'TextBox7
        '
        Me.TextBox7.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.TextBox7.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox7.Location = New System.Drawing.Point(171, 124)
        Me.TextBox7.MaxLength = 2
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.ReadOnly = True
        Me.TextBox7.Size = New System.Drawing.Size(27, 23)
        Me.TextBox7.TabIndex = 331
        '
        'Label80
        '
        Me.Label80.AutoSize = True
        Me.Label80.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label80.Location = New System.Drawing.Point(323, 205)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(35, 9)
        Me.Label80.TabIndex = 381
        Me.Label80.Text = "F1_OVR"
        '
        'CheckBox44
        '
        Me.CheckBox44.AutoSize = True
        Me.CheckBox44.Location = New System.Drawing.Point(421, 128)
        Me.CheckBox44.Name = "CheckBox44"
        Me.CheckBox44.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox44.TabIndex = 332
        Me.CheckBox44.UseVisualStyleBackColor = True
        '
        'Label89
        '
        Me.Label89.AutoSize = True
        Me.Label89.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label89.Location = New System.Drawing.Point(204, 205)
        Me.Label89.Name = "Label89"
        Me.Label89.Size = New System.Drawing.Size(31, 9)
        Me.Label89.TabIndex = 380
        Me.Label89.Text = "F1_Fail"
        '
        'CheckBox43
        '
        Me.CheckBox43.AutoSize = True
        Me.CheckBox43.Location = New System.Drawing.Point(211, 129)
        Me.CheckBox43.Name = "CheckBox43"
        Me.CheckBox43.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox43.TabIndex = 333
        Me.CheckBox43.UseVisualStyleBackColor = True
        '
        'CheckBox42
        '
        Me.CheckBox42.AutoSize = True
        Me.CheckBox42.Checked = True
        Me.CheckBox42.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox42.Location = New System.Drawing.Point(241, 129)
        Me.CheckBox42.Name = "CheckBox42"
        Me.CheckBox42.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox42.TabIndex = 334
        Me.CheckBox42.UseVisualStyleBackColor = True
        '
        'CheckBox41
        '
        Me.CheckBox41.AutoSize = True
        Me.CheckBox41.Location = New System.Drawing.Point(271, 129)
        Me.CheckBox41.Name = "CheckBox41"
        Me.CheckBox41.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox41.TabIndex = 335
        Me.CheckBox41.UseVisualStyleBackColor = True
        '
        'CheckBox40
        '
        Me.CheckBox40.AutoSize = True
        Me.CheckBox40.Location = New System.Drawing.Point(301, 129)
        Me.CheckBox40.Name = "CheckBox40"
        Me.CheckBox40.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox40.TabIndex = 336
        Me.CheckBox40.UseVisualStyleBackColor = True
        '
        'Label95
        '
        Me.Label95.AutoSize = True
        Me.Label95.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label95.Location = New System.Drawing.Point(235, 148)
        Me.Label95.Name = "Label95"
        Me.Label95.Size = New System.Drawing.Size(24, 9)
        Me.Label95.TabIndex = 376
        Me.Label95.Text = "OTW"
        '
        'CheckBox39
        '
        Me.CheckBox39.AutoSize = True
        Me.CheckBox39.Location = New System.Drawing.Point(331, 129)
        Me.CheckBox39.Name = "CheckBox39"
        Me.CheckBox39.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox39.TabIndex = 337
        Me.CheckBox39.UseVisualStyleBackColor = True
        '
        'Label125
        '
        Me.Label125.AutoSize = True
        Me.Label125.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label125.Location = New System.Drawing.Point(207, 148)
        Me.Label125.Name = "Label125"
        Me.Label125.Size = New System.Drawing.Size(21, 9)
        Me.Label125.TabIndex = 375
        Me.Label125.Text = "OTF"
        '
        'CheckBox38
        '
        Me.CheckBox38.AutoSize = True
        Me.CheckBox38.Location = New System.Drawing.Point(361, 129)
        Me.CheckBox38.Name = "CheckBox38"
        Me.CheckBox38.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox38.TabIndex = 338
        Me.CheckBox38.UseVisualStyleBackColor = True
        '
        'Label127
        '
        Me.Label127.AutoSize = True
        Me.Label127.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label127.Location = New System.Drawing.Point(210, 89)
        Me.Label127.Name = "Label127"
        Me.Label127.Size = New System.Drawing.Size(17, 9)
        Me.Label127.TabIndex = 374
        Me.Label127.Text = "OC"
        '
        'CheckBox37
        '
        Me.CheckBox37.AutoSize = True
        Me.CheckBox37.Location = New System.Drawing.Point(391, 129)
        Me.CheckBox37.Name = "CheckBox37"
        Me.CheckBox37.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox37.TabIndex = 339
        Me.CheckBox37.UseVisualStyleBackColor = True
        '
        'Label134
        '
        Me.Label134.AutoSize = True
        Me.Label134.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label134.Location = New System.Drawing.Point(300, 61)
        Me.Label134.Name = "Label134"
        Me.Label134.Size = New System.Drawing.Size(16, 9)
        Me.Label134.TabIndex = 372
        Me.Label134.Text = "UV"
        '
        'TextBox6
        '
        Me.TextBox6.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox6.Location = New System.Drawing.Point(133, 211)
        Me.TextBox6.MaxLength = 2
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.ReadOnly = True
        Me.TextBox6.Size = New System.Drawing.Size(27, 23)
        Me.TextBox6.TabIndex = 340
        '
        'Label135
        '
        Me.Label135.AutoSize = True
        Me.Label135.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label135.Location = New System.Drawing.Point(209, 61)
        Me.Label135.Name = "Label135"
        Me.Label135.Size = New System.Drawing.Size(16, 9)
        Me.Label135.TabIndex = 371
        Me.Label135.Text = "OV"
        '
        'TextBox5
        '
        Me.TextBox5.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.TextBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox5.Location = New System.Drawing.Point(171, 211)
        Me.TextBox5.MaxLength = 2
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.ReadOnly = True
        Me.TextBox5.Size = New System.Drawing.Size(27, 23)
        Me.TextBox5.TabIndex = 341
        '
        'CheckBox61
        '
        Me.CheckBox61.AutoSize = True
        Me.CheckBox61.Location = New System.Drawing.Point(391, 245)
        Me.CheckBox61.Name = "CheckBox61"
        Me.CheckBox61.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox61.TabIndex = 369
        Me.CheckBox61.UseVisualStyleBackColor = True
        '
        'CheckBox52
        '
        Me.CheckBox52.AutoSize = True
        Me.CheckBox52.Location = New System.Drawing.Point(421, 215)
        Me.CheckBox52.Name = "CheckBox52"
        Me.CheckBox52.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox52.TabIndex = 342
        Me.CheckBox52.UseVisualStyleBackColor = True
        '
        'CheckBox62
        '
        Me.CheckBox62.AutoSize = True
        Me.CheckBox62.Location = New System.Drawing.Point(361, 245)
        Me.CheckBox62.Name = "CheckBox62"
        Me.CheckBox62.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox62.TabIndex = 368
        Me.CheckBox62.UseVisualStyleBackColor = True
        '
        'CheckBox51
        '
        Me.CheckBox51.AutoSize = True
        Me.CheckBox51.Location = New System.Drawing.Point(211, 216)
        Me.CheckBox51.Name = "CheckBox51"
        Me.CheckBox51.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox51.TabIndex = 343
        Me.CheckBox51.UseVisualStyleBackColor = True
        '
        'CheckBox63
        '
        Me.CheckBox63.AutoSize = True
        Me.CheckBox63.Location = New System.Drawing.Point(331, 245)
        Me.CheckBox63.Name = "CheckBox63"
        Me.CheckBox63.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox63.TabIndex = 367
        Me.CheckBox63.UseVisualStyleBackColor = True
        '
        'CheckBox50
        '
        Me.CheckBox50.AutoSize = True
        Me.CheckBox50.Location = New System.Drawing.Point(241, 216)
        Me.CheckBox50.Name = "CheckBox50"
        Me.CheckBox50.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox50.TabIndex = 344
        Me.CheckBox50.UseVisualStyleBackColor = True
        '
        'CheckBox64
        '
        Me.CheckBox64.AutoSize = True
        Me.CheckBox64.Location = New System.Drawing.Point(301, 245)
        Me.CheckBox64.Name = "CheckBox64"
        Me.CheckBox64.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox64.TabIndex = 366
        Me.CheckBox64.UseVisualStyleBackColor = True
        '
        'CheckBox49
        '
        Me.CheckBox49.AutoSize = True
        Me.CheckBox49.Location = New System.Drawing.Point(271, 216)
        Me.CheckBox49.Name = "CheckBox49"
        Me.CheckBox49.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox49.TabIndex = 345
        Me.CheckBox49.UseVisualStyleBackColor = True
        '
        'CheckBox65
        '
        Me.CheckBox65.AutoSize = True
        Me.CheckBox65.Location = New System.Drawing.Point(271, 245)
        Me.CheckBox65.Name = "CheckBox65"
        Me.CheckBox65.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox65.TabIndex = 365
        Me.CheckBox65.UseVisualStyleBackColor = True
        '
        'CheckBox48
        '
        Me.CheckBox48.AutoSize = True
        Me.CheckBox48.Location = New System.Drawing.Point(301, 216)
        Me.CheckBox48.Name = "CheckBox48"
        Me.CheckBox48.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox48.TabIndex = 346
        Me.CheckBox48.UseVisualStyleBackColor = True
        '
        'CheckBox66
        '
        Me.CheckBox66.AutoSize = True
        Me.CheckBox66.Location = New System.Drawing.Point(241, 245)
        Me.CheckBox66.Name = "CheckBox66"
        Me.CheckBox66.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox66.TabIndex = 364
        Me.CheckBox66.UseVisualStyleBackColor = True
        '
        'CheckBox47
        '
        Me.CheckBox47.AutoSize = True
        Me.CheckBox47.Checked = True
        Me.CheckBox47.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox47.Location = New System.Drawing.Point(331, 216)
        Me.CheckBox47.Name = "CheckBox47"
        Me.CheckBox47.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox47.TabIndex = 347
        Me.CheckBox47.UseVisualStyleBackColor = True
        '
        'CheckBox67
        '
        Me.CheckBox67.AutoSize = True
        Me.CheckBox67.Location = New System.Drawing.Point(211, 245)
        Me.CheckBox67.Name = "CheckBox67"
        Me.CheckBox67.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox67.TabIndex = 363
        Me.CheckBox67.UseVisualStyleBackColor = True
        '
        'CheckBox46
        '
        Me.CheckBox46.AutoSize = True
        Me.CheckBox46.Location = New System.Drawing.Point(361, 216)
        Me.CheckBox46.Name = "CheckBox46"
        Me.CheckBox46.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox46.TabIndex = 348
        Me.CheckBox46.UseVisualStyleBackColor = True
        '
        'CheckBox68
        '
        Me.CheckBox68.AutoSize = True
        Me.CheckBox68.Location = New System.Drawing.Point(421, 244)
        Me.CheckBox68.Name = "CheckBox68"
        Me.CheckBox68.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox68.TabIndex = 362
        Me.CheckBox68.UseVisualStyleBackColor = True
        '
        'CheckBox45
        '
        Me.CheckBox45.AutoSize = True
        Me.CheckBox45.Location = New System.Drawing.Point(391, 216)
        Me.CheckBox45.Name = "CheckBox45"
        Me.CheckBox45.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox45.TabIndex = 349
        Me.CheckBox45.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(171, 240)
        Me.TextBox1.MaxLength = 2
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.Size = New System.Drawing.Size(27, 23)
        Me.TextBox1.TabIndex = 361
        '
        'TextBox4
        '
        Me.TextBox4.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox4.Location = New System.Drawing.Point(133, 182)
        Me.TextBox4.MaxLength = 2
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.ReadOnly = True
        Me.TextBox4.Size = New System.Drawing.Size(27, 23)
        Me.TextBox4.TabIndex = 350
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.Location = New System.Drawing.Point(133, 240)
        Me.TextBox2.MaxLength = 2
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ReadOnly = True
        Me.TextBox2.Size = New System.Drawing.Size(27, 23)
        Me.TextBox2.TabIndex = 360
        '
        'CheckBox53
        '
        Me.CheckBox53.AutoSize = True
        Me.CheckBox53.Location = New System.Drawing.Point(391, 187)
        Me.CheckBox53.Name = "CheckBox53"
        Me.CheckBox53.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox53.TabIndex = 359
        Me.CheckBox53.UseVisualStyleBackColor = True
        '
        'CheckBox60
        '
        Me.CheckBox60.AutoSize = True
        Me.CheckBox60.Location = New System.Drawing.Point(421, 186)
        Me.CheckBox60.Name = "CheckBox60"
        Me.CheckBox60.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox60.TabIndex = 352
        Me.CheckBox60.UseVisualStyleBackColor = True
        '
        'CheckBox54
        '
        Me.CheckBox54.AutoSize = True
        Me.CheckBox54.Location = New System.Drawing.Point(361, 187)
        Me.CheckBox54.Name = "CheckBox54"
        Me.CheckBox54.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox54.TabIndex = 358
        Me.CheckBox54.UseVisualStyleBackColor = True
        '
        'CheckBox59
        '
        Me.CheckBox59.AutoSize = True
        Me.CheckBox59.Checked = True
        Me.CheckBox59.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox59.Location = New System.Drawing.Point(211, 187)
        Me.CheckBox59.Name = "CheckBox59"
        Me.CheckBox59.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox59.TabIndex = 353
        Me.CheckBox59.UseVisualStyleBackColor = True
        '
        'CheckBox55
        '
        Me.CheckBox55.AutoSize = True
        Me.CheckBox55.Location = New System.Drawing.Point(331, 187)
        Me.CheckBox55.Name = "CheckBox55"
        Me.CheckBox55.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox55.TabIndex = 357
        Me.CheckBox55.UseVisualStyleBackColor = True
        '
        'CheckBox58
        '
        Me.CheckBox58.AutoSize = True
        Me.CheckBox58.Checked = True
        Me.CheckBox58.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox58.Location = New System.Drawing.Point(241, 187)
        Me.CheckBox58.Name = "CheckBox58"
        Me.CheckBox58.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox58.TabIndex = 354
        Me.CheckBox58.UseVisualStyleBackColor = True
        '
        'CheckBox56
        '
        Me.CheckBox56.AutoSize = True
        Me.CheckBox56.Location = New System.Drawing.Point(301, 187)
        Me.CheckBox56.Name = "CheckBox56"
        Me.CheckBox56.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox56.TabIndex = 356
        Me.CheckBox56.UseVisualStyleBackColor = True
        '
        'CheckBox57
        '
        Me.CheckBox57.AutoSize = True
        Me.CheckBox57.Location = New System.Drawing.Point(271, 187)
        Me.CheckBox57.Name = "CheckBox57"
        Me.CheckBox57.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox57.TabIndex = 355
        Me.CheckBox57.UseVisualStyleBackColor = True
        '
        'Poll
        '
        Me.Poll.BackColor = System.Drawing.Color.Transparent
        Me.Poll.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Poll.Location = New System.Drawing.Point(619, 144)
        Me.Poll.Name = "Poll"
        Me.Poll.Size = New System.Drawing.Size(113, 31)
        Me.Poll.TabIndex = 538
        Me.Poll.Text = "Poll"
        Me.Poll.UseVisualStyleBackColor = False
        '
        'ReadOnce
        '
        Me.ReadOnce.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ReadOnce.Location = New System.Drawing.Point(619, 101)
        Me.ReadOnce.Name = "ReadOnce"
        Me.ReadOnce.Size = New System.Drawing.Size(113, 37)
        Me.ReadOnce.TabIndex = 537
        Me.ReadOnce.Text = "Read Once"
        Me.ReadOnce.UseVisualStyleBackColor = True
        '
        'TabControl1
        '
        Me.TabControl1.AccessibleRole = System.Windows.Forms.AccessibleRole.MenuItem
        Me.TabControl1.AllowDrop = True
        Me.TabControl1.Appearance = System.Windows.Forms.TabAppearance.Buttons
        Me.TabControl1.Controls.Add(Me.Tab_Read)
        Me.TabControl1.Controls.Add(Me.Tab_MFR)
        Me.TabControl1.Controls.Add(Me.Tab_Constant)
        Me.TabControl1.Controls.Add(Me.Tab_Status)
        Me.TabControl1.Controls.Add(Me.Tab_Control)
        Me.TabControl1.Controls.Add(Me.Tab_Calibration)
        Me.TabControl1.Controls.Add(Me.Tab_Log)
        Me.TabControl1.Controls.Add(Me.Tab_FRU)
        Me.TabControl1.Controls.Add(Me.Tab_Statistics)
        Me.TabControl1.Controls.Add(Me.Tab_About)
        Me.TabControl1.Controls.Add(Me.Tag_Help)
        Me.TabControl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.HotTrack = True
        Me.TabControl1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.TabControl1.ItemSize = New System.Drawing.Size(200, 28)
        Me.TabControl1.Location = New System.Drawing.Point(12, 55)
        Me.TabControl1.Multiline = True
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1201, 457)
        Me.TabControl1.TabIndex = 547
        '
        'Tab_MFR
        '
        Me.Tab_MFR.Controls.Add(Me.DataGridView_MFR)
        Me.Tab_MFR.Controls.Add(Me.Button_MFR_Read)
        Me.Tab_MFR.Location = New System.Drawing.Point(4, 32)
        Me.Tab_MFR.Name = "Tab_MFR"
        Me.Tab_MFR.Padding = New System.Windows.Forms.Padding(3)
        Me.Tab_MFR.Size = New System.Drawing.Size(1193, 421)
        Me.Tab_MFR.TabIndex = 1
        Me.Tab_MFR.Text = "MFR"
        Me.Tab_MFR.UseVisualStyleBackColor = True
        '
        'DataGridView_MFR
        '
        Me.DataGridView_MFR.AllowUserToDeleteRows = False
        Me.DataGridView_MFR.AllowUserToResizeColumns = False
        Me.DataGridView_MFR.AllowUserToResizeRows = False
        Me.DataGridView_MFR.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        Me.DataGridView_MFR.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.DataGridView_MFR.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5})
        Me.DataGridView_MFR.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.DataGridView_MFR.GridColor = System.Drawing.SystemColors.Control
        Me.DataGridView_MFR.Location = New System.Drawing.Point(6, 3)
        Me.DataGridView_MFR.MultiSelect = False
        Me.DataGridView_MFR.Name = "DataGridView_MFR"
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.ControlDark
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle4.NullValue = "0"
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView_MFR.RowHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.DataGridView_MFR.RowHeadersVisible = False
        Me.DataGridView_MFR.RowHeadersWidth = 195
        Me.DataGridView_MFR.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.DataGridView_MFR.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.DataGridView_MFR.RowTemplate.DefaultCellStyle.Font = New System.Drawing.Font("Arial Narrow", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DataGridView_MFR.RowTemplate.Height = 19
        Me.DataGridView_MFR.RowTemplate.ReadOnly = True
        Me.DataGridView_MFR.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.DataGridView_MFR.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.DataGridView_MFR.Size = New System.Drawing.Size(644, 376)
        Me.DataGridView_MFR.TabIndex = 425
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.HeaderText = "Cmd"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.Width = 35
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.HeaderText = "Command Name"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Width = 130
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.HeaderText = "With PEC"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.Width = 88
        '
        'DataGridViewTextBoxColumn4
        '
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DataGridViewTextBoxColumn4.DefaultCellStyle = DataGridViewCellStyle3
        Me.DataGridViewTextBoxColumn4.HeaderText = "Hex Data"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.Width = 84
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.HeaderText = "Actual"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.Width = 90
        '
        'Button_MFR_Read
        '
        Me.Button_MFR_Read.BackColor = System.Drawing.Color.Transparent
        Me.Button_MFR_Read.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_MFR_Read.Location = New System.Drawing.Point(669, 130)
        Me.Button_MFR_Read.Name = "Button_MFR_Read"
        Me.Button_MFR_Read.Size = New System.Drawing.Size(117, 32)
        Me.Button_MFR_Read.TabIndex = 424
        Me.Button_MFR_Read.Text = "Read MFR Data"
        Me.Button_MFR_Read.UseVisualStyleBackColor = False
        '
        'Tab_Constant
        '
        Me.Tab_Constant.Controls.Add(Me.Button13)
        Me.Tab_Constant.Controls.Add(Me.DataGridView2)
        Me.Tab_Constant.Location = New System.Drawing.Point(4, 32)
        Me.Tab_Constant.Name = "Tab_Constant"
        Me.Tab_Constant.Padding = New System.Windows.Forms.Padding(3)
        Me.Tab_Constant.Size = New System.Drawing.Size(1193, 421)
        Me.Tab_Constant.TabIndex = 3
        Me.Tab_Constant.Text = "Constant Data"
        Me.Tab_Constant.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.BackColor = System.Drawing.Color.Transparent
        Me.Button13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button13.Location = New System.Drawing.Point(574, 117)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(117, 43)
        Me.Button13.TabIndex = 424
        Me.Button13.Text = "Read All Constant Data"
        Me.Button13.UseVisualStyleBackColor = False
        '
        'DataGridView2
        '
        Me.DataGridView2.AllowUserToDeleteRows = False
        Me.DataGridView2.AllowUserToResizeColumns = False
        Me.DataGridView2.AllowUserToResizeRows = False
        Me.DataGridView2.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.DataGridView2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn6, Me.DataGridViewTextBoxColumn7, Me.DataGridViewTextBoxColumn8, Me.DataGridViewTextBoxColumn14, Me.DataGridViewTextBoxColumn15})
        Me.DataGridView2.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.DataGridView2.GridColor = System.Drawing.SystemColors.Control
        Me.DataGridView2.Location = New System.Drawing.Point(0, 0)
        Me.DataGridView2.MultiSelect = False
        Me.DataGridView2.Name = "DataGridView2"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.ControlDark
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle6.NullValue = "0"
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView2.RowHeadersDefaultCellStyle = DataGridViewCellStyle6
        Me.DataGridView2.RowHeadersVisible = False
        Me.DataGridView2.RowHeadersWidth = 195
        Me.DataGridView2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.DataGridView2.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.DataGridView2.RowTemplate.DefaultCellStyle.Font = New System.Drawing.Font("Arial Narrow", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DataGridView2.RowTemplate.Height = 19
        Me.DataGridView2.RowTemplate.ReadOnly = True
        Me.DataGridView2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.DataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.DataGridView2.Size = New System.Drawing.Size(561, 389)
        Me.DataGridView2.TabIndex = 423
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.HeaderText = "Cmd"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.Width = 35
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.HeaderText = "Command Name"
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.Width = 130
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.HeaderText = "With PEC"
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        Me.DataGridViewTextBoxColumn8.Width = 88
        '
        'DataGridViewTextBoxColumn14
        '
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DataGridViewTextBoxColumn14.DefaultCellStyle = DataGridViewCellStyle5
        Me.DataGridViewTextBoxColumn14.HeaderText = "Hex Data"
        Me.DataGridViewTextBoxColumn14.Name = "DataGridViewTextBoxColumn14"
        Me.DataGridViewTextBoxColumn14.Width = 84
        '
        'DataGridViewTextBoxColumn15
        '
        Me.DataGridViewTextBoxColumn15.HeaderText = "Actual"
        Me.DataGridViewTextBoxColumn15.Name = "DataGridViewTextBoxColumn15"
        Me.DataGridViewTextBoxColumn15.Width = 90
        '
        'Tab_Status
        '
        Me.Tab_Status.AutoScroll = True
        Me.Tab_Status.Controls.Add(Me.GroupBox10)
        Me.Tab_Status.Controls.Add(Me.Label405)
        Me.Tab_Status.Controls.Add(Me.Label406)
        Me.Tab_Status.Controls.Add(Me.Label407)
        Me.Tab_Status.Controls.Add(Me.Label408)
        Me.Tab_Status.Controls.Add(Me.Label409)
        Me.Tab_Status.Controls.Add(Me.Label410)
        Me.Tab_Status.Controls.Add(Me.Label411)
        Me.Tab_Status.Controls.Add(Me.Label412)
        Me.Tab_Status.Controls.Add(Me.Label413)
        Me.Tab_Status.Controls.Add(Me.Label414)
        Me.Tab_Status.Controls.Add(Me.Label415)
        Me.Tab_Status.Controls.Add(Me.PictureBox65)
        Me.Tab_Status.Controls.Add(Me.PictureBox66)
        Me.Tab_Status.Controls.Add(Me.PictureBox67)
        Me.Tab_Status.Controls.Add(Me.PictureBox68)
        Me.Tab_Status.Controls.Add(Me.PictureBox69)
        Me.Tab_Status.Controls.Add(Me.PictureBox70)
        Me.Tab_Status.Controls.Add(Me.PictureBox71)
        Me.Tab_Status.Controls.Add(Me.PictureBox72)
        Me.Tab_Status.Controls.Add(Me.Label416)
        Me.Tab_Status.Controls.Add(Me.PictureBox73)
        Me.Tab_Status.Controls.Add(Me.PictureBox74)
        Me.Tab_Status.Controls.Add(Me.PictureBox75)
        Me.Tab_Status.Controls.Add(Me.PictureBox76)
        Me.Tab_Status.Controls.Add(Me.PictureBox77)
        Me.Tab_Status.Controls.Add(Me.PictureBox78)
        Me.Tab_Status.Controls.Add(Me.PictureBox79)
        Me.Tab_Status.Controls.Add(Me.PictureBox80)
        Me.Tab_Status.Controls.Add(Me.Label420)
        Me.Tab_Status.Controls.Add(Me.Label421)
        Me.Tab_Status.Controls.Add(Me.Label422)
        Me.Tab_Status.Controls.Add(Me.Label423)
        Me.Tab_Status.Controls.Add(Me.Label424)
        Me.Tab_Status.Controls.Add(Me.Label425)
        Me.Tab_Status.Controls.Add(Me.Label426)
        Me.Tab_Status.Controls.Add(Me.Label427)
        Me.Tab_Status.Controls.Add(Me.Label428)
        Me.Tab_Status.Controls.Add(Me.Label429)
        Me.Tab_Status.Controls.Add(Me.Label430)
        Me.Tab_Status.Controls.Add(Me.Label431)
        Me.Tab_Status.Controls.Add(Me.Label432)
        Me.Tab_Status.Controls.Add(Me.Label433)
        Me.Tab_Status.Controls.Add(Me.Label434)
        Me.Tab_Status.Controls.Add(Me.Label435)
        Me.Tab_Status.Controls.Add(Me.Label436)
        Me.Tab_Status.Controls.Add(Me.Label437)
        Me.Tab_Status.Controls.Add(Me.Label438)
        Me.Tab_Status.Controls.Add(Me.Label439)
        Me.Tab_Status.Controls.Add(Me.Label440)
        Me.Tab_Status.Controls.Add(Me.Label441)
        Me.Tab_Status.Controls.Add(Me.Label442)
        Me.Tab_Status.Controls.Add(Me.Label443)
        Me.Tab_Status.Controls.Add(Me.Label444)
        Me.Tab_Status.Controls.Add(Me.Label445)
        Me.Tab_Status.Controls.Add(Me.Label446)
        Me.Tab_Status.Controls.Add(Me.Label447)
        Me.Tab_Status.Controls.Add(Me.Label448)
        Me.Tab_Status.Controls.Add(Me.Label449)
        Me.Tab_Status.Controls.Add(Me.Label450)
        Me.Tab_Status.Controls.Add(Me.Label451)
        Me.Tab_Status.Controls.Add(Me.Label452)
        Me.Tab_Status.Controls.Add(Me.Label453)
        Me.Tab_Status.Controls.Add(Me.Label454)
        Me.Tab_Status.Controls.Add(Me.Label455)
        Me.Tab_Status.Controls.Add(Me.Label456)
        Me.Tab_Status.Controls.Add(Me.PictureBox81)
        Me.Tab_Status.Controls.Add(Me.PictureBox82)
        Me.Tab_Status.Controls.Add(Me.PictureBox83)
        Me.Tab_Status.Controls.Add(Me.PictureBox84)
        Me.Tab_Status.Controls.Add(Me.PictureBox85)
        Me.Tab_Status.Controls.Add(Me.PictureBox86)
        Me.Tab_Status.Controls.Add(Me.PictureBox87)
        Me.Tab_Status.Controls.Add(Me.PictureBox88)
        Me.Tab_Status.Controls.Add(Me.PictureBox89)
        Me.Tab_Status.Controls.Add(Me.PictureBox90)
        Me.Tab_Status.Controls.Add(Me.PictureBox91)
        Me.Tab_Status.Controls.Add(Me.PictureBox92)
        Me.Tab_Status.Controls.Add(Me.PictureBox93)
        Me.Tab_Status.Controls.Add(Me.PictureBox94)
        Me.Tab_Status.Controls.Add(Me.PictureBox95)
        Me.Tab_Status.Controls.Add(Me.PictureBox96)
        Me.Tab_Status.Controls.Add(Me.PictureBox97)
        Me.Tab_Status.Controls.Add(Me.PictureBox_Busy)
        Me.Tab_Status.Controls.Add(Me.PictureBox99)
        Me.Tab_Status.Controls.Add(Me.PictureBox100)
        Me.Tab_Status.Controls.Add(Me.PictureBox101)
        Me.Tab_Status.Controls.Add(Me.PictureBox102)
        Me.Tab_Status.Controls.Add(Me.PictureBox103)
        Me.Tab_Status.Controls.Add(Me.PictureBox104)
        Me.Tab_Status.Controls.Add(Me.PictureBox105)
        Me.Tab_Status.Controls.Add(Me.PictureBox106)
        Me.Tab_Status.Controls.Add(Me.PictureBox107)
        Me.Tab_Status.Controls.Add(Me.PictureBox108)
        Me.Tab_Status.Controls.Add(Me.PictureBox109)
        Me.Tab_Status.Controls.Add(Me.PictureBox110)
        Me.Tab_Status.Controls.Add(Me.PictureBox111)
        Me.Tab_Status.Controls.Add(Me.PictureBox112)
        Me.Tab_Status.Controls.Add(Me.PictureBox113)
        Me.Tab_Status.Controls.Add(Me.PictureBox_OFF)
        Me.Tab_Status.Controls.Add(Me.PictureBox115)
        Me.Tab_Status.Controls.Add(Me.PictureBox116)
        Me.Tab_Status.Controls.Add(Me.PictureBox117)
        Me.Tab_Status.Controls.Add(Me.PictureBox118)
        Me.Tab_Status.Controls.Add(Me.PictureBox119)
        Me.Tab_Status.Controls.Add(Me.PictureBox120)
        Me.Tab_Status.Controls.Add(Me.PictureBox121)
        Me.Tab_Status.Controls.Add(Me.PictureBox122)
        Me.Tab_Status.Controls.Add(Me.PictureBox123)
        Me.Tab_Status.Controls.Add(Me.PictureBox124)
        Me.Tab_Status.Controls.Add(Me.PictureBox125)
        Me.Tab_Status.Controls.Add(Me.PictureBox126)
        Me.Tab_Status.Controls.Add(Me.PictureBox127)
        Me.Tab_Status.Controls.Add(Me.PictureBox128)
        Me.Tab_Status.Controls.Add(Me.PictureBox129)
        Me.Tab_Status.Controls.Add(Me.PictureBox_VOUT_OV)
        Me.Tab_Status.Controls.Add(Me.PictureBox131)
        Me.Tab_Status.Controls.Add(Me.PictureBox132)
        Me.Tab_Status.Controls.Add(Me.PictureBox133)
        Me.Tab_Status.Controls.Add(Me.PictureBox134)
        Me.Tab_Status.Controls.Add(Me.PictureBox135)
        Me.Tab_Status.Controls.Add(Me.PictureBox136)
        Me.Tab_Status.Controls.Add(Me.PictureBox137)
        Me.Tab_Status.Controls.Add(Me.PictureBox138)
        Me.Tab_Status.Controls.Add(Me.PictureBox139)
        Me.Tab_Status.Controls.Add(Me.PictureBox140)
        Me.Tab_Status.Controls.Add(Me.PictureBox141)
        Me.Tab_Status.Controls.Add(Me.PictureBox142)
        Me.Tab_Status.Controls.Add(Me.PictureBox_IOUT_OC)
        Me.Tab_Status.Controls.Add(Me.PictureBox144)
        Me.Tab_Status.Location = New System.Drawing.Point(4, 32)
        Me.Tab_Status.Name = "Tab_Status"
        Me.Tab_Status.Padding = New System.Windows.Forms.Padding(3)
        Me.Tab_Status.Size = New System.Drawing.Size(1193, 421)
        Me.Tab_Status.TabIndex = 4
        Me.Tab_Status.Text = "Status"
        Me.Tab_Status.UseVisualStyleBackColor = True
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.Label35)
        Me.GroupBox10.Controls.Add(Me.ListBox_Cmd)
        Me.GroupBox10.Controls.Add(Me.Button_Clear_Faults)
        Me.GroupBox10.Controls.Add(Me.TextBox_Status_Data_r)
        Me.GroupBox10.Controls.Add(Me.NumericUpDown_cmd_r)
        Me.GroupBox10.Controls.Add(Me.Button_status_read)
        Me.GroupBox10.Controls.Add(Me.Label468)
        Me.GroupBox10.Controls.Add(Me.Label467)
        Me.GroupBox10.Controls.Add(Me.TextBox_status_Data)
        Me.GroupBox10.Controls.Add(Me.NumericUpDown_page)
        Me.GroupBox10.Controls.Add(Me.Button_status_write)
        Me.GroupBox10.Location = New System.Drawing.Point(630, 30)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(392, 225)
        Me.GroupBox10.TabIndex = 624
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "Status Operation"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(7, 50)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(72, 15)
        Me.Label35.TabIndex = 636
        Me.Label35.Text = "Command"
        '
        'ListBox_Cmd
        '
        Me.ListBox_Cmd.FormattingEnabled = True
        Me.ListBox_Cmd.ItemHeight = 15
        Me.ListBox_Cmd.Items.AddRange(New Object() {"0x78 - STATUS_BYTE", "0x79 - STATUS_WORD", "0x7A - STATUS_VOUT", "0x7B - STATUS_IOUT", "0x7C - STATUS_INPUT", "0x7D - STATUS_TEMPERATURE", "0x7E - STATUS_CML", "0x7F - STATUS_OTHER", "0x80 - STATUS_MFR_SPECIFIC", "", "", ""})
        Me.ListBox_Cmd.Location = New System.Drawing.Point(10, 70)
        Me.ListBox_Cmd.Name = "ListBox_Cmd"
        Me.ListBox_Cmd.Size = New System.Drawing.Size(179, 124)
        Me.ListBox_Cmd.TabIndex = 635
        '
        'Button_Clear_Faults
        '
        Me.Button_Clear_Faults.BackColor = System.Drawing.Color.Transparent
        Me.Button_Clear_Faults.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Clear_Faults.Location = New System.Drawing.Point(245, 189)
        Me.Button_Clear_Faults.Name = "Button_Clear_Faults"
        Me.Button_Clear_Faults.Size = New System.Drawing.Size(107, 31)
        Me.Button_Clear_Faults.TabIndex = 632
        Me.Button_Clear_Faults.Text = "Clear Faults"
        Me.Button_Clear_Faults.UseVisualStyleBackColor = False
        '
        'TextBox_Status_Data_r
        '
        Me.TextBox_Status_Data_r.Location = New System.Drawing.Point(114, 97)
        Me.TextBox_Status_Data_r.Name = "TextBox_Status_Data_r"
        Me.TextBox_Status_Data_r.Size = New System.Drawing.Size(100, 21)
        Me.TextBox_Status_Data_r.TabIndex = 631
        Me.TextBox_Status_Data_r.Visible = False
        '
        'NumericUpDown_cmd_r
        '
        Me.NumericUpDown_cmd_r.Hexadecimal = True
        Me.NumericUpDown_cmd_r.Location = New System.Drawing.Point(8, 98)
        Me.NumericUpDown_cmd_r.Maximum = New Decimal(New Integer() {127, 0, 0, 0})
        Me.NumericUpDown_cmd_r.Minimum = New Decimal(New Integer() {122, 0, 0, 0})
        Me.NumericUpDown_cmd_r.Name = "NumericUpDown_cmd_r"
        Me.NumericUpDown_cmd_r.Size = New System.Drawing.Size(80, 21)
        Me.NumericUpDown_cmd_r.TabIndex = 630
        Me.NumericUpDown_cmd_r.Value = New Decimal(New Integer() {122, 0, 0, 0})
        Me.NumericUpDown_cmd_r.Visible = False
        '
        'Button_status_read
        '
        Me.Button_status_read.Location = New System.Drawing.Point(245, 155)
        Me.Button_status_read.Name = "Button_status_read"
        Me.Button_status_read.Size = New System.Drawing.Size(107, 31)
        Me.Button_status_read.TabIndex = 629
        Me.Button_status_read.Text = "Read"
        Me.Button_status_read.UseVisualStyleBackColor = True
        '
        'Label468
        '
        Me.Label468.AutoSize = True
        Me.Label468.Location = New System.Drawing.Point(242, 50)
        Me.Label468.Name = "Label468"
        Me.Label468.Size = New System.Drawing.Size(37, 15)
        Me.Label468.TabIndex = 628
        Me.Label468.Text = "Data"
        '
        'Label467
        '
        Me.Label467.AutoSize = True
        Me.Label467.Location = New System.Drawing.Point(5, 26)
        Me.Label467.Name = "Label467"
        Me.Label467.Size = New System.Drawing.Size(44, 15)
        Me.Label467.TabIndex = 627
        Me.Label467.Text = " Page"
        '
        'TextBox_status_Data
        '
        Me.TextBox_status_Data.Location = New System.Drawing.Point(245, 70)
        Me.TextBox_status_Data.Name = "TextBox_status_Data"
        Me.TextBox_status_Data.Size = New System.Drawing.Size(81, 21)
        Me.TextBox_status_Data.TabIndex = 626
        '
        'NumericUpDown_page
        '
        Me.NumericUpDown_page.Location = New System.Drawing.Point(65, 26)
        Me.NumericUpDown_page.Maximum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_page.Name = "NumericUpDown_page"
        Me.NumericUpDown_page.Size = New System.Drawing.Size(63, 21)
        Me.NumericUpDown_page.TabIndex = 625
        '
        'Button_status_write
        '
        Me.Button_status_write.Location = New System.Drawing.Point(246, 121)
        Me.Button_status_write.Name = "Button_status_write"
        Me.Button_status_write.Size = New System.Drawing.Size(106, 30)
        Me.Button_status_write.TabIndex = 624
        Me.Button_status_write.Text = "Write"
        Me.Button_status_write.UseVisualStyleBackColor = True
        '
        'Label405
        '
        Me.Label405.AutoSize = True
        Me.Label405.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label405.Location = New System.Drawing.Point(538, 391)
        Me.Label405.Name = "Label405"
        Me.Label405.Size = New System.Drawing.Size(52, 12)
        Me.Label405.TabIndex = 619
        Me.Label405.Text = "VSB_FLT"
        '
        'Label406
        '
        Me.Label406.AutoSize = True
        Me.Label406.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label406.Location = New System.Drawing.Point(452, 352)
        Me.Label406.Name = "Label406"
        Me.Label406.Size = New System.Drawing.Size(79, 12)
        Me.Label406.TabIndex = 618
        Me.Label406.Text = "ORING FAULT"
        '
        'Label407
        '
        Me.Label407.AutoSize = True
        Me.Label407.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label407.Location = New System.Drawing.Point(542, 310)
        Me.Label407.Name = "Label407"
        Me.Label407.Size = New System.Drawing.Size(32, 12)
        Me.Label407.TabIndex = 617
        Me.Label407.Text = "MEM"
        '
        'Label408
        '
        Me.Label408.AutoSize = True
        Me.Label408.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label408.Location = New System.Drawing.Point(306, 310)
        Me.Label408.Name = "Label408"
        Me.Label408.Size = New System.Drawing.Size(81, 12)
        Me.Label408.TabIndex = 616
        Me.Label408.Text = "PRCSR FAULT"
        '
        'Label409
        '
        Me.Label409.AutoSize = True
        Me.Label409.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label409.Location = New System.Drawing.Point(312, 143)
        Me.Label409.Name = "Label409"
        Me.Label409.Size = New System.Drawing.Size(76, 12)
        Me.Label409.TabIndex = 615
        Me.Label409.Text = "ISHARE Fault"
        '
        'Label410
        '
        Me.Label410.AutoSize = True
        Me.Label410.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label410.Location = New System.Drawing.Point(533, 58)
        Me.Label410.Name = "Label410"
        Me.Label410.Size = New System.Drawing.Size(54, 12)
        Me.Label410.TabIndex = 614
        Me.Label410.Text = "UNKOWN"
        '
        'Label411
        '
        Me.Label411.AutoSize = True
        Me.Label411.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label411.Location = New System.Drawing.Point(400, 58)
        Me.Label411.Name = "Label411"
        Me.Label411.Size = New System.Drawing.Size(28, 12)
        Me.Label411.TabIndex = 613
        Me.Label411.Text = "FAN"
        '
        'Label412
        '
        Me.Label412.AutoSize = True
        Me.Label412.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label412.Location = New System.Drawing.Point(255, 58)
        Me.Label412.Name = "Label412"
        Me.Label412.Size = New System.Drawing.Size(30, 12)
        Me.Label412.TabIndex = 612
        Me.Label412.Text = "MFR"
        '
        'Label413
        '
        Me.Label413.AutoSize = True
        Me.Label413.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label413.Location = New System.Drawing.Point(540, 352)
        Me.Label413.Name = "Label413"
        Me.Label413.Size = New System.Drawing.Size(40, 12)
        Me.Label413.TabIndex = 611
        Me.Label413.Text = "Invalid"
        '
        'Label414
        '
        Me.Label414.AutoSize = True
        Me.Label414.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label414.Location = New System.Drawing.Point(317, 271)
        Me.Label414.Name = "Label414"
        Me.Label414.Size = New System.Drawing.Size(45, 12)
        Me.Label414.TabIndex = 610
        Me.Label414.Text = "F1 OVR"
        '
        'Label415
        '
        Me.Label415.AutoSize = True
        Me.Label415.BackColor = System.Drawing.Color.Transparent
        Me.Label415.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.Label415.Location = New System.Drawing.Point(19, 379)
        Me.Label415.Name = "Label415"
        Me.Label415.Size = New System.Drawing.Size(86, 13)
        Me.Label415.TabIndex = 609
        Me.Label415.Text = "STATUS MFR"
        '
        'PictureBox65
        '
        Me.PictureBox65.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox65.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox65.Location = New System.Drawing.Point(49, 406)
        Me.PictureBox65.Name = "PictureBox65"
        Me.PictureBox65.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox65.TabIndex = 608
        Me.PictureBox65.TabStop = False
        '
        'PictureBox66
        '
        Me.PictureBox66.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox66.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox66.Location = New System.Drawing.Point(337, 406)
        Me.PictureBox66.Name = "PictureBox66"
        Me.PictureBox66.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox66.TabIndex = 607
        Me.PictureBox66.TabStop = False
        '
        'PictureBox67
        '
        Me.PictureBox67.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox67.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox67.Location = New System.Drawing.Point(121, 406)
        Me.PictureBox67.Name = "PictureBox67"
        Me.PictureBox67.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox67.TabIndex = 602
        Me.PictureBox67.TabStop = False
        '
        'PictureBox68
        '
        Me.PictureBox68.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox68.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox68.Location = New System.Drawing.Point(481, 406)
        Me.PictureBox68.Name = "PictureBox68"
        Me.PictureBox68.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox68.TabIndex = 601
        Me.PictureBox68.TabStop = False
        '
        'PictureBox69
        '
        Me.PictureBox69.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox69.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox69.Location = New System.Drawing.Point(193, 406)
        Me.PictureBox69.Name = "PictureBox69"
        Me.PictureBox69.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox69.TabIndex = 606
        Me.PictureBox69.TabStop = False
        '
        'PictureBox70
        '
        Me.PictureBox70.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox70.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox70.Location = New System.Drawing.Point(409, 406)
        Me.PictureBox70.Name = "PictureBox70"
        Me.PictureBox70.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox70.TabIndex = 605
        Me.PictureBox70.TabStop = False
        '
        'PictureBox71
        '
        Me.PictureBox71.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox71.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox71.Location = New System.Drawing.Point(265, 406)
        Me.PictureBox71.Name = "PictureBox71"
        Me.PictureBox71.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox71.TabIndex = 604
        Me.PictureBox71.TabStop = False
        '
        'PictureBox72
        '
        Me.PictureBox72.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox72.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox72.Location = New System.Drawing.Point(553, 406)
        Me.PictureBox72.Name = "PictureBox72"
        Me.PictureBox72.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox72.TabIndex = 603
        Me.PictureBox72.TabStop = False
        '
        'Label416
        '
        Me.Label416.AutoSize = True
        Me.Label416.BackColor = System.Drawing.Color.Transparent
        Me.Label416.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.Label416.Location = New System.Drawing.Point(19, 339)
        Me.Label416.Name = "Label416"
        Me.Label416.Size = New System.Drawing.Size(103, 13)
        Me.Label416.TabIndex = 600
        Me.Label416.Text = "STATUS OTHER"
        '
        'PictureBox73
        '
        Me.PictureBox73.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox73.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox73.Location = New System.Drawing.Point(48, 367)
        Me.PictureBox73.Name = "PictureBox73"
        Me.PictureBox73.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox73.TabIndex = 599
        Me.PictureBox73.TabStop = False
        '
        'PictureBox74
        '
        Me.PictureBox74.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox74.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox74.Location = New System.Drawing.Point(336, 367)
        Me.PictureBox74.Name = "PictureBox74"
        Me.PictureBox74.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox74.TabIndex = 598
        Me.PictureBox74.TabStop = False
        '
        'PictureBox75
        '
        Me.PictureBox75.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox75.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox75.Location = New System.Drawing.Point(120, 367)
        Me.PictureBox75.Name = "PictureBox75"
        Me.PictureBox75.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox75.TabIndex = 593
        Me.PictureBox75.TabStop = False
        '
        'PictureBox76
        '
        Me.PictureBox76.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox76.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox76.Location = New System.Drawing.Point(480, 367)
        Me.PictureBox76.Name = "PictureBox76"
        Me.PictureBox76.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox76.TabIndex = 592
        Me.PictureBox76.TabStop = False
        '
        'PictureBox77
        '
        Me.PictureBox77.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox77.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox77.Location = New System.Drawing.Point(192, 367)
        Me.PictureBox77.Name = "PictureBox77"
        Me.PictureBox77.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox77.TabIndex = 597
        Me.PictureBox77.TabStop = False
        '
        'PictureBox78
        '
        Me.PictureBox78.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox78.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox78.Location = New System.Drawing.Point(408, 367)
        Me.PictureBox78.Name = "PictureBox78"
        Me.PictureBox78.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox78.TabIndex = 596
        Me.PictureBox78.TabStop = False
        '
        'PictureBox79
        '
        Me.PictureBox79.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox79.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox79.Location = New System.Drawing.Point(264, 367)
        Me.PictureBox79.Name = "PictureBox79"
        Me.PictureBox79.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox79.TabIndex = 595
        Me.PictureBox79.TabStop = False
        '
        'PictureBox80
        '
        Me.PictureBox80.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox80.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox80.Location = New System.Drawing.Point(552, 367)
        Me.PictureBox80.Name = "PictureBox80"
        Me.PictureBox80.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox80.TabIndex = 594
        Me.PictureBox80.TabStop = False
        '
        'Label420
        '
        Me.Label420.AutoSize = True
        Me.Label420.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label420.Location = New System.Drawing.Point(33, 271)
        Me.Label420.Name = "Label420"
        Me.Label420.Size = New System.Drawing.Size(46, 12)
        Me.Label420.TabIndex = 563
        Me.Label420.Text = "F1 FAIL"
        '
        'Label421
        '
        Me.Label421.AutoSize = True
        Me.Label421.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold)
        Me.Label421.Location = New System.Drawing.Point(180, 402)
        Me.Label421.Name = "Label421"
        Me.Label421.Size = New System.Drawing.Size(0, 13)
        Me.Label421.TabIndex = 564
        Me.Label421.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label422
        '
        Me.Label422.AutoSize = True
        Me.Label422.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label422.Location = New System.Drawing.Point(471, 310)
        Me.Label422.Name = "Label422"
        Me.Label422.Size = New System.Drawing.Size(31, 12)
        Me.Label422.TabIndex = 565
        Me.Label422.Text = "COM"
        '
        'Label423
        '
        Me.Label423.AutoSize = True
        Me.Label423.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label423.Location = New System.Drawing.Point(542, 16)
        Me.Label423.Name = "Label423"
        Me.Label423.Size = New System.Drawing.Size(36, 12)
        Me.Label423.TabIndex = 576
        Me.Label423.Text = "NONE"
        '
        'Label424
        '
        Me.Label424.AutoSize = True
        Me.Label424.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label424.Location = New System.Drawing.Point(473, 15)
        Me.Label424.Name = "Label424"
        Me.Label424.Size = New System.Drawing.Size(29, 12)
        Me.Label424.TabIndex = 567
        Me.Label424.Text = "CML"
        '
        'Label425
        '
        Me.Label425.AutoSize = True
        Me.Label425.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label425.Location = New System.Drawing.Point(396, 15)
        Me.Label425.Name = "Label425"
        Me.Label425.Size = New System.Drawing.Size(35, 12)
        Me.Label425.TabIndex = 568
        Me.Label425.Text = "TEMP"
        '
        'Label426
        '
        Me.Label426.AutoSize = True
        Me.Label426.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label426.Location = New System.Drawing.Point(466, 59)
        Me.Label426.Name = "Label426"
        Me.Label426.Size = New System.Drawing.Size(42, 12)
        Me.Label426.TabIndex = 569
        Me.Label426.Text = "OTHER"
        '
        'Label427
        '
        Me.Label427.AutoSize = True
        Me.Label427.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label427.Location = New System.Drawing.Point(331, 58)
        Me.Label427.Name = "Label427"
        Me.Label427.Size = New System.Drawing.Size(26, 12)
        Me.Label427.TabIndex = 570
        Me.Label427.Text = "#PG"
        '
        'Label428
        '
        Me.Label428.AutoSize = True
        Me.Label428.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label428.Location = New System.Drawing.Point(322, 15)
        Me.Label428.Name = "Label428"
        Me.Label428.Size = New System.Drawing.Size(47, 12)
        Me.Label428.TabIndex = 571
        Me.Label428.Text = "VIN_UV"
        '
        'Label429
        '
        Me.Label429.AutoSize = True
        Me.Label429.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label429.Location = New System.Drawing.Point(172, 310)
        Me.Label429.Name = "Label429"
        Me.Label429.Size = New System.Drawing.Size(53, 12)
        Me.Label429.TabIndex = 572
        Me.Label429.Text = "INV_PEC"
        '
        'Label430
        '
        Me.Label430.AutoSize = True
        Me.Label430.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label430.Location = New System.Drawing.Point(244, 186)
        Me.Label430.Name = "Label430"
        Me.Label430.Size = New System.Drawing.Size(51, 12)
        Me.Label430.TabIndex = 573
        Me.Label430.Text = "VIN UVF"
        '
        'Label431
        '
        Me.Label431.AutoSize = True
        Me.Label431.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label431.Location = New System.Drawing.Point(244, 15)
        Me.Label431.Name = "Label431"
        Me.Label431.Size = New System.Drawing.Size(53, 12)
        Me.Label431.TabIndex = 574
        Me.Label431.Text = "IOUT_OC"
        '
        'Label432
        '
        Me.Label432.AutoSize = True
        Me.Label432.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label432.Location = New System.Drawing.Point(184, 143)
        Me.Label432.Name = "Label432"
        Me.Label432.Size = New System.Drawing.Size(31, 12)
        Me.Label432.TabIndex = 566
        Me.Label432.Text = "OCW"
        '
        'Label433
        '
        Me.Label433.AutoSize = True
        Me.Label433.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label433.Location = New System.Drawing.Point(259, 102)
        Me.Label433.Name = "Label433"
        Me.Label433.Size = New System.Drawing.Size(28, 12)
        Me.Label433.TabIndex = 575
        Me.Label433.Text = "UVP"
        '
        'Label434
        '
        Me.Label434.AutoSize = True
        Me.Label434.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label434.Location = New System.Drawing.Point(179, 58)
        Me.Label434.Name = "Label434"
        Me.Label434.Size = New System.Drawing.Size(38, 12)
        Me.Label434.TabIndex = 591
        Me.Label434.Text = "INPUT"
        '
        'Label435
        '
        Me.Label435.AutoSize = True
        Me.Label435.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label435.Location = New System.Drawing.Point(172, 15)
        Me.Label435.Name = "Label435"
        Me.Label435.Size = New System.Drawing.Size(57, 12)
        Me.Label435.TabIndex = 577
        Me.Label435.Text = "VOUT_OV"
        '
        'Label436
        '
        Me.Label436.AutoSize = True
        Me.Label436.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label436.Location = New System.Drawing.Point(102, 143)
        Me.Label436.Name = "Label436"
        Me.Label436.Size = New System.Drawing.Size(48, 12)
        Me.Label436.TabIndex = 589
        Me.Label436.Text = "OCP_LV"
        '
        'Label437
        '
        Me.Label437.AutoSize = True
        Me.Label437.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label437.Location = New System.Drawing.Point(100, 310)
        Me.Label437.Name = "Label437"
        Me.Label437.Size = New System.Drawing.Size(61, 12)
        Me.Label437.TabIndex = 588
        Me.Label437.Text = "INV_DATA"
        '
        'Label438
        '
        Me.Label438.AutoSize = True
        Me.Label438.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label438.Location = New System.Drawing.Point(113, 230)
        Me.Label438.Name = "Label438"
        Me.Label438.Size = New System.Drawing.Size(29, 12)
        Me.Label438.TabIndex = 587
        Me.Label438.Text = "OTW"
        '
        'Label439
        '
        Me.Label439.AutoSize = True
        Me.Label439.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label439.Location = New System.Drawing.Point(100, 58)
        Me.Label439.Name = "Label439"
        Me.Label439.Size = New System.Drawing.Size(64, 12)
        Me.Label439.TabIndex = 586
        Me.Label439.Text = "IOUT/POUT"
        '
        'Label440
        '
        Me.Label440.AutoSize = True
        Me.Label440.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label440.Location = New System.Drawing.Point(28, 186)
        Me.Label440.Name = "Label440"
        Me.Label440.Size = New System.Drawing.Size(51, 12)
        Me.Label440.TabIndex = 585
        Me.Label440.Text = "VIN OVF"
        '
        'Label441
        '
        Me.Label441.AutoSize = True
        Me.Label441.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label441.Location = New System.Drawing.Point(100, 186)
        Me.Label441.Name = "Label441"
        Me.Label441.Size = New System.Drawing.Size(54, 12)
        Me.Label441.TabIndex = 590
        Me.Label441.Text = "VIN OVW"
        '
        'Label442
        '
        Me.Label442.AutoSize = True
        Me.Label442.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label442.Location = New System.Drawing.Point(113, 15)
        Me.Label442.Name = "Label442"
        Me.Label442.Size = New System.Drawing.Size(27, 12)
        Me.Label442.TabIndex = 583
        Me.Label442.Text = "OFF"
        '
        'Label443
        '
        Me.Label443.AutoSize = True
        Me.Label443.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label443.Location = New System.Drawing.Point(43, 143)
        Me.Label443.Name = "Label443"
        Me.Label443.Size = New System.Drawing.Size(28, 12)
        Me.Label443.TabIndex = 582
        Me.Label443.Text = "OCP"
        '
        'Label444
        '
        Me.Label444.AutoSize = True
        Me.Label444.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label444.Location = New System.Drawing.Point(31, 310)
        Me.Label444.Name = "Label444"
        Me.Label444.Size = New System.Drawing.Size(57, 12)
        Me.Label444.TabIndex = 581
        Me.Label444.Text = "INV_CMD"
        '
        'Label445
        '
        Me.Label445.AutoSize = True
        Me.Label445.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label445.Location = New System.Drawing.Point(43, 102)
        Me.Label445.Name = "Label445"
        Me.Label445.Size = New System.Drawing.Size(28, 12)
        Me.Label445.TabIndex = 584
        Me.Label445.Text = "OVP"
        '
        'Label446
        '
        Me.Label446.AutoSize = True
        Me.Label446.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label446.Location = New System.Drawing.Point(43, 230)
        Me.Label446.Name = "Label446"
        Me.Label446.Size = New System.Drawing.Size(26, 12)
        Me.Label446.TabIndex = 580
        Me.Label446.Text = "OTP"
        '
        'Label447
        '
        Me.Label447.AutoSize = True
        Me.Label447.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label447.Location = New System.Drawing.Point(38, 58)
        Me.Label447.Name = "Label447"
        Me.Label447.Size = New System.Drawing.Size(35, 12)
        Me.Label447.TabIndex = 579
        Me.Label447.Text = "VOUT"
        '
        'Label448
        '
        Me.Label448.AutoSize = True
        Me.Label448.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label448.Location = New System.Drawing.Point(38, 15)
        Me.Label448.Name = "Label448"
        Me.Label448.Size = New System.Drawing.Size(33, 12)
        Me.Label448.TabIndex = 578
        Me.Label448.Text = "BUSY"
        '
        'Label449
        '
        Me.Label449.AutoSize = True
        Me.Label449.BackColor = System.Drawing.Color.Transparent
        Me.Label449.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.Label449.Location = New System.Drawing.Point(16, 129)
        Me.Label449.Name = "Label449"
        Me.Label449.Size = New System.Drawing.Size(90, 13)
        Me.Label449.TabIndex = 557
        Me.Label449.Text = "STATUS IOUT"
        '
        'Label450
        '
        Me.Label450.AutoSize = True
        Me.Label450.BackColor = System.Drawing.Color.Transparent
        Me.Label450.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.Label450.Location = New System.Drawing.Point(16, 255)
        Me.Label450.Name = "Label450"
        Me.Label450.Size = New System.Drawing.Size(115, 13)
        Me.Label450.TabIndex = 558
        Me.Label450.Text = "STATUS Fans_1_2"
        '
        'Label451
        '
        Me.Label451.AutoSize = True
        Me.Label451.BackColor = System.Drawing.Color.Transparent
        Me.Label451.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.Label451.Location = New System.Drawing.Point(16, 297)
        Me.Label451.Name = "Label451"
        Me.Label451.Size = New System.Drawing.Size(85, 13)
        Me.Label451.TabIndex = 562
        Me.Label451.Text = "STATUS CML"
        '
        'Label452
        '
        Me.Label452.AutoSize = True
        Me.Label452.BackColor = System.Drawing.Color.Transparent
        Me.Label452.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.Label452.Location = New System.Drawing.Point(16, 87)
        Me.Label452.Name = "Label452"
        Me.Label452.Size = New System.Drawing.Size(94, 13)
        Me.Label452.TabIndex = 560
        Me.Label452.Text = "STATUS VOUT"
        '
        'Label453
        '
        Me.Label453.AutoSize = True
        Me.Label453.BackColor = System.Drawing.Color.Transparent
        Me.Label453.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.Label453.Location = New System.Drawing.Point(16, 215)
        Me.Label453.Name = "Label453"
        Me.Label453.Size = New System.Drawing.Size(153, 13)
        Me.Label453.TabIndex = 561
        Me.Label453.Text = "STATUS TEMPERATURE"
        '
        'Label454
        '
        Me.Label454.AutoSize = True
        Me.Label454.BackColor = System.Drawing.Color.Transparent
        Me.Label454.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.Label454.Location = New System.Drawing.Point(16, 43)
        Me.Label454.Name = "Label454"
        Me.Label454.Size = New System.Drawing.Size(137, 13)
        Me.Label454.TabIndex = 556
        Me.Label454.Text = "STATUS WORD (MSB)"
        '
        'Label455
        '
        Me.Label455.AutoSize = True
        Me.Label455.BackColor = System.Drawing.Color.Transparent
        Me.Label455.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.Label455.Location = New System.Drawing.Point(16, 171)
        Me.Label455.Name = "Label455"
        Me.Label455.Size = New System.Drawing.Size(98, 13)
        Me.Label455.TabIndex = 559
        Me.Label455.Text = "STATUS INPUT"
        '
        'Label456
        '
        Me.Label456.AutoSize = True
        Me.Label456.BackColor = System.Drawing.Color.Transparent
        Me.Label456.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.Label456.Location = New System.Drawing.Point(16, 0)
        Me.Label456.Name = "Label456"
        Me.Label456.Size = New System.Drawing.Size(92, 13)
        Me.Label456.TabIndex = 555
        Me.Label456.Text = "STATUS BYTE"
        '
        'PictureBox81
        '
        Me.PictureBox81.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox81.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox81.Location = New System.Drawing.Point(45, 158)
        Me.PictureBox81.Name = "PictureBox81"
        Me.PictureBox81.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox81.TabIndex = 553
        Me.PictureBox81.TabStop = False
        '
        'PictureBox82
        '
        Me.PictureBox82.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox82.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox82.Location = New System.Drawing.Point(45, 284)
        Me.PictureBox82.Name = "PictureBox82"
        Me.PictureBox82.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox82.TabIndex = 519
        Me.PictureBox82.TabStop = False
        '
        'PictureBox83
        '
        Me.PictureBox83.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox83.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox83.Location = New System.Drawing.Point(45, 325)
        Me.PictureBox83.Name = "PictureBox83"
        Me.PictureBox83.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox83.TabIndex = 518
        Me.PictureBox83.TabStop = False
        '
        'PictureBox84
        '
        Me.PictureBox84.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox84.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox84.Location = New System.Drawing.Point(333, 158)
        Me.PictureBox84.Name = "PictureBox84"
        Me.PictureBox84.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox84.TabIndex = 517
        Me.PictureBox84.TabStop = False
        '
        'PictureBox85
        '
        Me.PictureBox85.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox85.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox85.Location = New System.Drawing.Point(333, 284)
        Me.PictureBox85.Name = "PictureBox85"
        Me.PictureBox85.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox85.TabIndex = 516
        Me.PictureBox85.TabStop = False
        '
        'PictureBox86
        '
        Me.PictureBox86.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox86.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox86.Location = New System.Drawing.Point(333, 325)
        Me.PictureBox86.Name = "PictureBox86"
        Me.PictureBox86.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox86.TabIndex = 515
        Me.PictureBox86.TabStop = False
        '
        'PictureBox87
        '
        Me.PictureBox87.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox87.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox87.Location = New System.Drawing.Point(45, 117)
        Me.PictureBox87.Name = "PictureBox87"
        Me.PictureBox87.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox87.TabIndex = 514
        Me.PictureBox87.TabStop = False
        '
        'PictureBox88
        '
        Me.PictureBox88.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox88.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox88.Location = New System.Drawing.Point(45, 245)
        Me.PictureBox88.Name = "PictureBox88"
        Me.PictureBox88.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox88.TabIndex = 513
        Me.PictureBox88.TabStop = False
        '
        'PictureBox89
        '
        Me.PictureBox89.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox89.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox89.Location = New System.Drawing.Point(333, 117)
        Me.PictureBox89.Name = "PictureBox89"
        Me.PictureBox89.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox89.TabIndex = 512
        Me.PictureBox89.TabStop = False
        '
        'PictureBox90
        '
        Me.PictureBox90.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox90.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox90.Location = New System.Drawing.Point(45, 73)
        Me.PictureBox90.Name = "PictureBox90"
        Me.PictureBox90.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox90.TabIndex = 511
        Me.PictureBox90.TabStop = False
        '
        'PictureBox91
        '
        Me.PictureBox91.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox91.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox91.Location = New System.Drawing.Point(333, 245)
        Me.PictureBox91.Name = "PictureBox91"
        Me.PictureBox91.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox91.TabIndex = 510
        Me.PictureBox91.TabStop = False
        '
        'PictureBox92
        '
        Me.PictureBox92.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox92.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox92.Location = New System.Drawing.Point(117, 158)
        Me.PictureBox92.Name = "PictureBox92"
        Me.PictureBox92.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox92.TabIndex = 509
        Me.PictureBox92.TabStop = False
        '
        'PictureBox93
        '
        Me.PictureBox93.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox93.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox93.Location = New System.Drawing.Point(117, 284)
        Me.PictureBox93.Name = "PictureBox93"
        Me.PictureBox93.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox93.TabIndex = 508
        Me.PictureBox93.TabStop = False
        '
        'PictureBox94
        '
        Me.PictureBox94.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox94.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox94.Location = New System.Drawing.Point(117, 325)
        Me.PictureBox94.Name = "PictureBox94"
        Me.PictureBox94.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox94.TabIndex = 507
        Me.PictureBox94.TabStop = False
        '
        'PictureBox95
        '
        Me.PictureBox95.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox95.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox95.Location = New System.Drawing.Point(333, 73)
        Me.PictureBox95.Name = "PictureBox95"
        Me.PictureBox95.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox95.TabIndex = 520
        Me.PictureBox95.TabStop = False
        '
        'PictureBox96
        '
        Me.PictureBox96.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox96.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox96.Location = New System.Drawing.Point(45, 201)
        Me.PictureBox96.Name = "PictureBox96"
        Me.PictureBox96.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox96.TabIndex = 506
        Me.PictureBox96.TabStop = False
        '
        'PictureBox97
        '
        Me.PictureBox97.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox97.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox97.Location = New System.Drawing.Point(117, 117)
        Me.PictureBox97.Name = "PictureBox97"
        Me.PictureBox97.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox97.TabIndex = 504
        Me.PictureBox97.TabStop = False
        '
        'PictureBox_Busy
        '
        Me.PictureBox_Busy.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox_Busy.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox_Busy.Location = New System.Drawing.Point(45, 30)
        Me.PictureBox_Busy.Name = "PictureBox_Busy"
        Me.PictureBox_Busy.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox_Busy.TabIndex = 503
        Me.PictureBox_Busy.TabStop = False
        '
        'PictureBox99
        '
        Me.PictureBox99.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox99.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox99.Location = New System.Drawing.Point(117, 245)
        Me.PictureBox99.Name = "PictureBox99"
        Me.PictureBox99.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox99.TabIndex = 502
        Me.PictureBox99.TabStop = False
        '
        'PictureBox100
        '
        Me.PictureBox100.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox100.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox100.Location = New System.Drawing.Point(477, 158)
        Me.PictureBox100.Name = "PictureBox100"
        Me.PictureBox100.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox100.TabIndex = 501
        Me.PictureBox100.TabStop = False
        '
        'PictureBox101
        '
        Me.PictureBox101.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox101.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox101.Location = New System.Drawing.Point(477, 284)
        Me.PictureBox101.Name = "PictureBox101"
        Me.PictureBox101.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox101.TabIndex = 500
        Me.PictureBox101.TabStop = False
        '
        'PictureBox102
        '
        Me.PictureBox102.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox102.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox102.Location = New System.Drawing.Point(477, 325)
        Me.PictureBox102.Name = "PictureBox102"
        Me.PictureBox102.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox102.TabIndex = 499
        Me.PictureBox102.TabStop = False
        '
        'PictureBox103
        '
        Me.PictureBox103.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox103.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox103.Location = New System.Drawing.Point(117, 73)
        Me.PictureBox103.Name = "PictureBox103"
        Me.PictureBox103.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox103.TabIndex = 498
        Me.PictureBox103.TabStop = False
        '
        'PictureBox104
        '
        Me.PictureBox104.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox104.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox104.Location = New System.Drawing.Point(333, 201)
        Me.PictureBox104.Name = "PictureBox104"
        Me.PictureBox104.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox104.TabIndex = 497
        Me.PictureBox104.TabStop = False
        '
        'PictureBox105
        '
        Me.PictureBox105.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox105.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox105.Location = New System.Drawing.Point(477, 117)
        Me.PictureBox105.Name = "PictureBox105"
        Me.PictureBox105.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox105.TabIndex = 496
        Me.PictureBox105.TabStop = False
        '
        'PictureBox106
        '
        Me.PictureBox106.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox106.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox106.Location = New System.Drawing.Point(333, 30)
        Me.PictureBox106.Name = "PictureBox106"
        Me.PictureBox106.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox106.TabIndex = 495
        Me.PictureBox106.TabStop = False
        '
        'PictureBox107
        '
        Me.PictureBox107.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox107.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox107.Location = New System.Drawing.Point(477, 245)
        Me.PictureBox107.Name = "PictureBox107"
        Me.PictureBox107.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox107.TabIndex = 494
        Me.PictureBox107.TabStop = False
        '
        'PictureBox108
        '
        Me.PictureBox108.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox108.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox108.Location = New System.Drawing.Point(189, 158)
        Me.PictureBox108.Name = "PictureBox108"
        Me.PictureBox108.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox108.TabIndex = 493
        Me.PictureBox108.TabStop = False
        '
        'PictureBox109
        '
        Me.PictureBox109.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox109.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox109.Location = New System.Drawing.Point(189, 284)
        Me.PictureBox109.Name = "PictureBox109"
        Me.PictureBox109.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox109.TabIndex = 492
        Me.PictureBox109.TabStop = False
        '
        'PictureBox110
        '
        Me.PictureBox110.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox110.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox110.Location = New System.Drawing.Point(189, 325)
        Me.PictureBox110.Name = "PictureBox110"
        Me.PictureBox110.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox110.TabIndex = 505
        Me.PictureBox110.TabStop = False
        '
        'PictureBox111
        '
        Me.PictureBox111.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox111.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox111.Location = New System.Drawing.Point(477, 73)
        Me.PictureBox111.Name = "PictureBox111"
        Me.PictureBox111.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox111.TabIndex = 521
        Me.PictureBox111.TabStop = False
        '
        'PictureBox112
        '
        Me.PictureBox112.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox112.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox112.Location = New System.Drawing.Point(117, 201)
        Me.PictureBox112.Name = "PictureBox112"
        Me.PictureBox112.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox112.TabIndex = 522
        Me.PictureBox112.TabStop = False
        '
        'PictureBox113
        '
        Me.PictureBox113.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox113.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox113.Location = New System.Drawing.Point(189, 117)
        Me.PictureBox113.Name = "PictureBox113"
        Me.PictureBox113.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox113.TabIndex = 523
        Me.PictureBox113.TabStop = False
        '
        'PictureBox_OFF
        '
        Me.PictureBox_OFF.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox_OFF.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox_OFF.Location = New System.Drawing.Point(117, 30)
        Me.PictureBox_OFF.Name = "PictureBox_OFF"
        Me.PictureBox_OFF.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox_OFF.TabIndex = 552
        Me.PictureBox_OFF.TabStop = False
        '
        'PictureBox115
        '
        Me.PictureBox115.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox115.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox115.Location = New System.Drawing.Point(189, 245)
        Me.PictureBox115.Name = "PictureBox115"
        Me.PictureBox115.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox115.TabIndex = 551
        Me.PictureBox115.TabStop = False
        '
        'PictureBox116
        '
        Me.PictureBox116.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox116.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox116.Location = New System.Drawing.Point(405, 158)
        Me.PictureBox116.Name = "PictureBox116"
        Me.PictureBox116.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox116.TabIndex = 550
        Me.PictureBox116.TabStop = False
        '
        'PictureBox117
        '
        Me.PictureBox117.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox117.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox117.Location = New System.Drawing.Point(405, 284)
        Me.PictureBox117.Name = "PictureBox117"
        Me.PictureBox117.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox117.TabIndex = 549
        Me.PictureBox117.TabStop = False
        '
        'PictureBox118
        '
        Me.PictureBox118.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox118.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox118.Location = New System.Drawing.Point(405, 325)
        Me.PictureBox118.Name = "PictureBox118"
        Me.PictureBox118.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox118.TabIndex = 548
        Me.PictureBox118.TabStop = False
        '
        'PictureBox119
        '
        Me.PictureBox119.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox119.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox119.Location = New System.Drawing.Point(189, 73)
        Me.PictureBox119.Name = "PictureBox119"
        Me.PictureBox119.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox119.TabIndex = 547
        Me.PictureBox119.TabStop = False
        '
        'PictureBox120
        '
        Me.PictureBox120.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox120.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox120.Location = New System.Drawing.Point(477, 201)
        Me.PictureBox120.Name = "PictureBox120"
        Me.PictureBox120.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox120.TabIndex = 546
        Me.PictureBox120.TabStop = False
        '
        'PictureBox121
        '
        Me.PictureBox121.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox121.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox121.Location = New System.Drawing.Point(405, 117)
        Me.PictureBox121.Name = "PictureBox121"
        Me.PictureBox121.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox121.TabIndex = 545
        Me.PictureBox121.TabStop = False
        '
        'PictureBox122
        '
        Me.PictureBox122.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox122.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox122.Location = New System.Drawing.Point(477, 30)
        Me.PictureBox122.Name = "PictureBox122"
        Me.PictureBox122.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox122.TabIndex = 544
        Me.PictureBox122.TabStop = False
        '
        'PictureBox123
        '
        Me.PictureBox123.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox123.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox123.Location = New System.Drawing.Point(405, 245)
        Me.PictureBox123.Name = "PictureBox123"
        Me.PictureBox123.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox123.TabIndex = 543
        Me.PictureBox123.TabStop = False
        '
        'PictureBox124
        '
        Me.PictureBox124.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox124.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox124.Location = New System.Drawing.Point(261, 158)
        Me.PictureBox124.Name = "PictureBox124"
        Me.PictureBox124.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox124.TabIndex = 542
        Me.PictureBox124.TabStop = False
        '
        'PictureBox125
        '
        Me.PictureBox125.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox125.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox125.Location = New System.Drawing.Point(261, 284)
        Me.PictureBox125.Name = "PictureBox125"
        Me.PictureBox125.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox125.TabIndex = 541
        Me.PictureBox125.TabStop = False
        '
        'PictureBox126
        '
        Me.PictureBox126.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox126.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox126.Location = New System.Drawing.Point(261, 325)
        Me.PictureBox126.Name = "PictureBox126"
        Me.PictureBox126.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox126.TabIndex = 540
        Me.PictureBox126.TabStop = False
        '
        'PictureBox127
        '
        Me.PictureBox127.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox127.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox127.Location = New System.Drawing.Point(405, 73)
        Me.PictureBox127.Name = "PictureBox127"
        Me.PictureBox127.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox127.TabIndex = 539
        Me.PictureBox127.TabStop = False
        '
        'PictureBox128
        '
        Me.PictureBox128.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox128.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox128.Location = New System.Drawing.Point(189, 201)
        Me.PictureBox128.Name = "PictureBox128"
        Me.PictureBox128.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox128.TabIndex = 538
        Me.PictureBox128.TabStop = False
        '
        'PictureBox129
        '
        Me.PictureBox129.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox129.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox129.Location = New System.Drawing.Point(261, 117)
        Me.PictureBox129.Name = "PictureBox129"
        Me.PictureBox129.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox129.TabIndex = 537
        Me.PictureBox129.TabStop = False
        '
        'PictureBox_VOUT_OV
        '
        Me.PictureBox_VOUT_OV.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox_VOUT_OV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox_VOUT_OV.Location = New System.Drawing.Point(189, 30)
        Me.PictureBox_VOUT_OV.Name = "PictureBox_VOUT_OV"
        Me.PictureBox_VOUT_OV.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox_VOUT_OV.TabIndex = 536
        Me.PictureBox_VOUT_OV.TabStop = False
        '
        'PictureBox131
        '
        Me.PictureBox131.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox131.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox131.Location = New System.Drawing.Point(261, 245)
        Me.PictureBox131.Name = "PictureBox131"
        Me.PictureBox131.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox131.TabIndex = 535
        Me.PictureBox131.TabStop = False
        '
        'PictureBox132
        '
        Me.PictureBox132.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox132.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox132.Location = New System.Drawing.Point(549, 158)
        Me.PictureBox132.Name = "PictureBox132"
        Me.PictureBox132.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox132.TabIndex = 534
        Me.PictureBox132.TabStop = False
        '
        'PictureBox133
        '
        Me.PictureBox133.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox133.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox133.Location = New System.Drawing.Point(549, 284)
        Me.PictureBox133.Name = "PictureBox133"
        Me.PictureBox133.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox133.TabIndex = 533
        Me.PictureBox133.TabStop = False
        '
        'PictureBox134
        '
        Me.PictureBox134.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox134.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox134.Location = New System.Drawing.Point(549, 325)
        Me.PictureBox134.Name = "PictureBox134"
        Me.PictureBox134.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox134.TabIndex = 532
        Me.PictureBox134.TabStop = False
        '
        'PictureBox135
        '
        Me.PictureBox135.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox135.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox135.Location = New System.Drawing.Point(261, 73)
        Me.PictureBox135.Name = "PictureBox135"
        Me.PictureBox135.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox135.TabIndex = 531
        Me.PictureBox135.TabStop = False
        '
        'PictureBox136
        '
        Me.PictureBox136.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox136.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox136.Location = New System.Drawing.Point(405, 201)
        Me.PictureBox136.Name = "PictureBox136"
        Me.PictureBox136.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox136.TabIndex = 530
        Me.PictureBox136.TabStop = False
        '
        'PictureBox137
        '
        Me.PictureBox137.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox137.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox137.Location = New System.Drawing.Point(549, 117)
        Me.PictureBox137.Name = "PictureBox137"
        Me.PictureBox137.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox137.TabIndex = 529
        Me.PictureBox137.TabStop = False
        '
        'PictureBox138
        '
        Me.PictureBox138.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox138.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox138.Location = New System.Drawing.Point(549, 245)
        Me.PictureBox138.Name = "PictureBox138"
        Me.PictureBox138.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox138.TabIndex = 528
        Me.PictureBox138.TabStop = False
        '
        'PictureBox139
        '
        Me.PictureBox139.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox139.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox139.Location = New System.Drawing.Point(405, 30)
        Me.PictureBox139.Name = "PictureBox139"
        Me.PictureBox139.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox139.TabIndex = 527
        Me.PictureBox139.TabStop = False
        '
        'PictureBox140
        '
        Me.PictureBox140.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox140.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox140.Location = New System.Drawing.Point(261, 201)
        Me.PictureBox140.Name = "PictureBox140"
        Me.PictureBox140.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox140.TabIndex = 526
        Me.PictureBox140.TabStop = False
        '
        'PictureBox141
        '
        Me.PictureBox141.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox141.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox141.Location = New System.Drawing.Point(549, 73)
        Me.PictureBox141.Name = "PictureBox141"
        Me.PictureBox141.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox141.TabIndex = 525
        Me.PictureBox141.TabStop = False
        '
        'PictureBox142
        '
        Me.PictureBox142.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox142.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox142.Location = New System.Drawing.Point(549, 201)
        Me.PictureBox142.Name = "PictureBox142"
        Me.PictureBox142.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox142.TabIndex = 524
        Me.PictureBox142.TabStop = False
        '
        'PictureBox_IOUT_OC
        '
        Me.PictureBox_IOUT_OC.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox_IOUT_OC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox_IOUT_OC.Location = New System.Drawing.Point(261, 30)
        Me.PictureBox_IOUT_OC.Name = "PictureBox_IOUT_OC"
        Me.PictureBox_IOUT_OC.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox_IOUT_OC.TabIndex = 554
        Me.PictureBox_IOUT_OC.TabStop = False
        '
        'PictureBox144
        '
        Me.PictureBox144.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox144.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox144.Location = New System.Drawing.Point(549, 30)
        Me.PictureBox144.Name = "PictureBox144"
        Me.PictureBox144.Size = New System.Drawing.Size(20, 10)
        Me.PictureBox144.TabIndex = 491
        Me.PictureBox144.TabStop = False
        '
        'Tab_Control
        '
        Me.Tab_Control.Controls.Add(Me.GroupBox18)
        Me.Tab_Control.Controls.Add(Me.GroupBox14)
        Me.Tab_Control.Controls.Add(Me.GroupBox7)
        Me.Tab_Control.Location = New System.Drawing.Point(4, 32)
        Me.Tab_Control.Name = "Tab_Control"
        Me.Tab_Control.Padding = New System.Windows.Forms.Padding(3)
        Me.Tab_Control.Size = New System.Drawing.Size(1193, 421)
        Me.Tab_Control.TabIndex = 5
        Me.Tab_Control.Text = "Control"
        Me.Tab_Control.UseVisualStyleBackColor = True
        '
        'GroupBox18
        '
        Me.GroupBox18.Controls.Add(Me.Button_PSUOff)
        Me.GroupBox18.Controls.Add(Me.Button_PSUOn)
        Me.GroupBox18.Location = New System.Drawing.Point(681, 32)
        Me.GroupBox18.Name = "GroupBox18"
        Me.GroupBox18.Size = New System.Drawing.Size(202, 115)
        Me.GroupBox18.TabIndex = 510
        Me.GroupBox18.TabStop = False
        Me.GroupBox18.Text = "PSU Remote Control"
        '
        'Button_PSUOff
        '
        Me.Button_PSUOff.BackColor = System.Drawing.Color.Transparent
        Me.Button_PSUOff.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_PSUOff.Location = New System.Drawing.Point(77, 69)
        Me.Button_PSUOff.Name = "Button_PSUOff"
        Me.Button_PSUOff.Size = New System.Drawing.Size(105, 26)
        Me.Button_PSUOff.TabIndex = 510
        Me.Button_PSUOff.Text = "PSU OFF"
        Me.Button_PSUOff.UseVisualStyleBackColor = False
        '
        'Button_PSUOn
        '
        Me.Button_PSUOn.BackColor = System.Drawing.Color.Transparent
        Me.Button_PSUOn.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_PSUOn.Location = New System.Drawing.Point(77, 37)
        Me.Button_PSUOn.Name = "Button_PSUOn"
        Me.Button_PSUOn.Size = New System.Drawing.Size(105, 26)
        Me.Button_PSUOn.TabIndex = 509
        Me.Button_PSUOn.Text = "PSU ON"
        Me.Button_PSUOn.UseVisualStyleBackColor = False
        '
        'GroupBox14
        '
        Me.GroupBox14.Controls.Add(Me.Label62)
        Me.GroupBox14.Controls.Add(Me.Label71)
        Me.GroupBox14.Controls.Add(Me.Label65)
        Me.GroupBox14.Controls.Add(Me.Label64)
        Me.GroupBox14.Controls.Add(Me.Label63)
        Me.GroupBox14.Controls.Add(Me.Label59)
        Me.GroupBox14.Controls.Add(Me.Label57)
        Me.GroupBox14.Controls.Add(Me.Label54)
        Me.GroupBox14.Controls.Add(Me.Button_IOUT_OC_Warn)
        Me.GroupBox14.Controls.Add(Me.TextBox_Set_Warn)
        Me.GroupBox14.Controls.Add(Me.Button_SET_IOUT_OC_WARN)
        Me.GroupBox14.Controls.Add(Me.NumericUpDown_Set_Warn)
        Me.GroupBox14.Controls.Add(Me.Label30)
        Me.GroupBox14.Controls.Add(Me.Button_GET_IOUT_OC_Fault_Limit)
        Me.GroupBox14.Controls.Add(Me.TextBox_GET_OC_Fault_Limit)
        Me.GroupBox14.Controls.Add(Me.Button_SET_IOUT_OC_Fault)
        Me.GroupBox14.Controls.Add(Me.NumericUpDown_SET_IOUT_F)
        Me.GroupBox14.Controls.Add(Me.Label27)
        Me.GroupBox14.Controls.Add(Me.Label457)
        Me.GroupBox14.Controls.Add(Me.NumericUpDown_SET_Vbulk)
        Me.GroupBox14.Controls.Add(Me.TextBox_GET_Vbulk)
        Me.GroupBox14.Controls.Add(Me.Button_GET_Vbulk)
        Me.GroupBox14.Controls.Add(Me.Button_SET_Vbulk)
        Me.GroupBox14.Controls.Add(Me.Label458)
        Me.GroupBox14.Controls.Add(Me.TextBox_GET_Duty)
        Me.GroupBox14.Controls.Add(Me.NumericUpDown_SET_Duty)
        Me.GroupBox14.Controls.Add(Me.Button_GET_Duty)
        Me.GroupBox14.Controls.Add(Me.Button_SET_Duty)
        Me.GroupBox14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox14.Location = New System.Drawing.Point(72, 25)
        Me.GroupBox14.Name = "GroupBox14"
        Me.GroupBox14.Size = New System.Drawing.Size(586, 242)
        Me.GroupBox14.TabIndex = 507
        Me.GroupBox14.TabStop = False
        Me.GroupBox14.Text = "Special Commands"
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.Location = New System.Drawing.Point(424, 192)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(21, 16)
        Me.Label62.TabIndex = 536
        Me.Label62.Text = "%"
        '
        'Label71
        '
        Me.Label71.AutoSize = True
        Me.Label71.Location = New System.Drawing.Point(424, 160)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(21, 16)
        Me.Label71.TabIndex = 535
        Me.Label71.Text = "%"
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Location = New System.Drawing.Point(98, 197)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(28, 16)
        Me.Label65.TabIndex = 534
        Me.Label65.Text = "(A)"
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.Location = New System.Drawing.Point(98, 166)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(28, 16)
        Me.Label64.TabIndex = 533
        Me.Label64.Text = "(A)"
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Location = New System.Drawing.Point(424, 91)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(28, 16)
        Me.Label63.TabIndex = 532
        Me.Label63.Text = "(V)"
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Location = New System.Drawing.Point(98, 95)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(28, 16)
        Me.Label59.TabIndex = 530
        Me.Label59.Text = "(A)"
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Location = New System.Drawing.Point(98, 61)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(28, 16)
        Me.Label57.TabIndex = 529
        Me.Label57.Text = "(A)"
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Location = New System.Drawing.Point(424, 59)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(28, 16)
        Me.Label54.TabIndex = 528
        Me.Label54.Text = "(V)"
        '
        'Button_IOUT_OC_Warn
        '
        Me.Button_IOUT_OC_Warn.BackColor = System.Drawing.Color.Transparent
        Me.Button_IOUT_OC_Warn.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_IOUT_OC_Warn.Location = New System.Drawing.Point(130, 189)
        Me.Button_IOUT_OC_Warn.Name = "Button_IOUT_OC_Warn"
        Me.Button_IOUT_OC_Warn.Size = New System.Drawing.Size(130, 29)
        Me.Button_IOUT_OC_Warn.TabIndex = 525
        Me.Button_IOUT_OC_Warn.Text = "GET Iout OC Warn Limit"
        Me.Button_IOUT_OC_Warn.UseVisualStyleBackColor = False
        '
        'TextBox_Set_Warn
        '
        Me.TextBox_Set_Warn.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox_Set_Warn.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_Set_Warn.Location = New System.Drawing.Point(30, 189)
        Me.TextBox_Set_Warn.Name = "TextBox_Set_Warn"
        Me.TextBox_Set_Warn.ReadOnly = True
        Me.TextBox_Set_Warn.Size = New System.Drawing.Size(60, 23)
        Me.TextBox_Set_Warn.TabIndex = 524
        Me.TextBox_Set_Warn.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Button_SET_IOUT_OC_WARN
        '
        Me.Button_SET_IOUT_OC_WARN.BackColor = System.Drawing.Color.Transparent
        Me.Button_SET_IOUT_OC_WARN.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_SET_IOUT_OC_WARN.Location = New System.Drawing.Point(130, 160)
        Me.Button_SET_IOUT_OC_WARN.Name = "Button_SET_IOUT_OC_WARN"
        Me.Button_SET_IOUT_OC_WARN.Size = New System.Drawing.Size(130, 27)
        Me.Button_SET_IOUT_OC_WARN.TabIndex = 523
        Me.Button_SET_IOUT_OC_WARN.Text = "SET Iout OC Warn"
        Me.Button_SET_IOUT_OC_WARN.UseVisualStyleBackColor = False
        '
        'NumericUpDown_Set_Warn
        '
        Me.NumericUpDown_Set_Warn.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericUpDown_Set_Warn.Location = New System.Drawing.Point(30, 160)
        Me.NumericUpDown_Set_Warn.Maximum = New Decimal(New Integer() {55, 0, 0, 0})
        Me.NumericUpDown_Set_Warn.Name = "NumericUpDown_Set_Warn"
        Me.NumericUpDown_Set_Warn.Size = New System.Drawing.Size(62, 23)
        Me.NumericUpDown_Set_Warn.TabIndex = 522
        Me.NumericUpDown_Set_Warn.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown_Set_Warn.Value = New Decimal(New Integer() {52, 0, 0, 0})
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.BackColor = System.Drawing.Color.LightYellow
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(27, 134)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(122, 13)
        Me.Label30.TabIndex = 521
        Me.Label30.Text = "IOUT OC Warn Limit"
        '
        'Button_GET_IOUT_OC_Fault_Limit
        '
        Me.Button_GET_IOUT_OC_Fault_Limit.BackColor = System.Drawing.Color.Transparent
        Me.Button_GET_IOUT_OC_Fault_Limit.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_GET_IOUT_OC_Fault_Limit.Location = New System.Drawing.Point(130, 88)
        Me.Button_GET_IOUT_OC_Fault_Limit.Name = "Button_GET_IOUT_OC_Fault_Limit"
        Me.Button_GET_IOUT_OC_Fault_Limit.Size = New System.Drawing.Size(130, 29)
        Me.Button_GET_IOUT_OC_Fault_Limit.TabIndex = 520
        Me.Button_GET_IOUT_OC_Fault_Limit.Text = "GET Iout OC Fault"
        Me.Button_GET_IOUT_OC_Fault_Limit.UseVisualStyleBackColor = False
        '
        'TextBox_GET_OC_Fault_Limit
        '
        Me.TextBox_GET_OC_Fault_Limit.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox_GET_OC_Fault_Limit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_GET_OC_Fault_Limit.Location = New System.Drawing.Point(30, 88)
        Me.TextBox_GET_OC_Fault_Limit.Multiline = True
        Me.TextBox_GET_OC_Fault_Limit.Name = "TextBox_GET_OC_Fault_Limit"
        Me.TextBox_GET_OC_Fault_Limit.ReadOnly = True
        Me.TextBox_GET_OC_Fault_Limit.Size = New System.Drawing.Size(60, 28)
        Me.TextBox_GET_OC_Fault_Limit.TabIndex = 519
        Me.TextBox_GET_OC_Fault_Limit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Button_SET_IOUT_OC_Fault
        '
        Me.Button_SET_IOUT_OC_Fault.BackColor = System.Drawing.Color.Transparent
        Me.Button_SET_IOUT_OC_Fault.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_SET_IOUT_OC_Fault.Location = New System.Drawing.Point(130, 59)
        Me.Button_SET_IOUT_OC_Fault.Name = "Button_SET_IOUT_OC_Fault"
        Me.Button_SET_IOUT_OC_Fault.Size = New System.Drawing.Size(130, 27)
        Me.Button_SET_IOUT_OC_Fault.TabIndex = 518
        Me.Button_SET_IOUT_OC_Fault.Text = "SET Iout OC Fault"
        Me.Button_SET_IOUT_OC_Fault.UseVisualStyleBackColor = False
        '
        'NumericUpDown_SET_IOUT_F
        '
        Me.NumericUpDown_SET_IOUT_F.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericUpDown_SET_IOUT_F.Location = New System.Drawing.Point(30, 59)
        Me.NumericUpDown_SET_IOUT_F.Maximum = New Decimal(New Integer() {60, 0, 0, 0})
        Me.NumericUpDown_SET_IOUT_F.Name = "NumericUpDown_SET_IOUT_F"
        Me.NumericUpDown_SET_IOUT_F.Size = New System.Drawing.Size(62, 23)
        Me.NumericUpDown_SET_IOUT_F.TabIndex = 517
        Me.NumericUpDown_SET_IOUT_F.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown_SET_IOUT_F.Value = New Decimal(New Integer() {55, 0, 0, 0})
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.BackColor = System.Drawing.Color.LightYellow
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(27, 33)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(120, 13)
        Me.Label27.TabIndex = 516
        Me.Label27.Text = "IOUT OC Fault Limit"
        '
        'Label457
        '
        Me.Label457.AutoSize = True
        Me.Label457.BackColor = System.Drawing.Color.LightYellow
        Me.Label457.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label457.Location = New System.Drawing.Point(350, 31)
        Me.Label457.Name = "Label457"
        Me.Label457.Size = New System.Drawing.Size(102, 13)
        Me.Label457.TabIndex = 515
        Me.Label457.Text = "Vbulk 400+(D0h)"
        '
        'NumericUpDown_SET_Vbulk
        '
        Me.NumericUpDown_SET_Vbulk.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericUpDown_SET_Vbulk.Location = New System.Drawing.Point(353, 55)
        Me.NumericUpDown_SET_Vbulk.Maximum = New Decimal(New Integer() {80, 0, 0, 0})
        Me.NumericUpDown_SET_Vbulk.Name = "NumericUpDown_SET_Vbulk"
        Me.NumericUpDown_SET_Vbulk.Size = New System.Drawing.Size(62, 23)
        Me.NumericUpDown_SET_Vbulk.TabIndex = 514
        Me.NumericUpDown_SET_Vbulk.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox_GET_Vbulk
        '
        Me.TextBox_GET_Vbulk.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox_GET_Vbulk.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_GET_Vbulk.Location = New System.Drawing.Point(353, 88)
        Me.TextBox_GET_Vbulk.Multiline = True
        Me.TextBox_GET_Vbulk.Name = "TextBox_GET_Vbulk"
        Me.TextBox_GET_Vbulk.ReadOnly = True
        Me.TextBox_GET_Vbulk.Size = New System.Drawing.Size(60, 28)
        Me.TextBox_GET_Vbulk.TabIndex = 513
        Me.TextBox_GET_Vbulk.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Button_GET_Vbulk
        '
        Me.Button_GET_Vbulk.BackColor = System.Drawing.Color.Transparent
        Me.Button_GET_Vbulk.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_GET_Vbulk.Location = New System.Drawing.Point(453, 88)
        Me.Button_GET_Vbulk.Name = "Button_GET_Vbulk"
        Me.Button_GET_Vbulk.Size = New System.Drawing.Size(100, 29)
        Me.Button_GET_Vbulk.TabIndex = 512
        Me.Button_GET_Vbulk.Text = "GET Vbulk"
        Me.Button_GET_Vbulk.UseVisualStyleBackColor = False
        '
        'Button_SET_Vbulk
        '
        Me.Button_SET_Vbulk.BackColor = System.Drawing.Color.Transparent
        Me.Button_SET_Vbulk.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_SET_Vbulk.Location = New System.Drawing.Point(453, 55)
        Me.Button_SET_Vbulk.Name = "Button_SET_Vbulk"
        Me.Button_SET_Vbulk.Size = New System.Drawing.Size(100, 27)
        Me.Button_SET_Vbulk.TabIndex = 511
        Me.Button_SET_Vbulk.Text = "SET Vbulk"
        Me.Button_SET_Vbulk.UseVisualStyleBackColor = False
        '
        'Label458
        '
        Me.Label458.AutoSize = True
        Me.Label458.BackColor = System.Drawing.Color.LightYellow
        Me.Label458.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label458.Location = New System.Drawing.Point(355, 134)
        Me.Label458.Name = "Label458"
        Me.Label458.Size = New System.Drawing.Size(58, 13)
        Me.Label458.TabIndex = 510
        Me.Label458.Text = "Fan(3Bh)"
        '
        'TextBox_GET_Duty
        '
        Me.TextBox_GET_Duty.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox_GET_Duty.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_GET_Duty.Location = New System.Drawing.Point(353, 189)
        Me.TextBox_GET_Duty.Multiline = True
        Me.TextBox_GET_Duty.Name = "TextBox_GET_Duty"
        Me.TextBox_GET_Duty.ReadOnly = True
        Me.TextBox_GET_Duty.Size = New System.Drawing.Size(60, 23)
        Me.TextBox_GET_Duty.TabIndex = 508
        Me.TextBox_GET_Duty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericUpDown_SET_Duty
        '
        Me.NumericUpDown_SET_Duty.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericUpDown_SET_Duty.Location = New System.Drawing.Point(353, 158)
        Me.NumericUpDown_SET_Duty.Minimum = New Decimal(New Integer() {20, 0, 0, 0})
        Me.NumericUpDown_SET_Duty.Name = "NumericUpDown_SET_Duty"
        Me.NumericUpDown_SET_Duty.Size = New System.Drawing.Size(62, 23)
        Me.NumericUpDown_SET_Duty.TabIndex = 509
        Me.NumericUpDown_SET_Duty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown_SET_Duty.Value = New Decimal(New Integer() {20, 0, 0, 0})
        '
        'Button_GET_Duty
        '
        Me.Button_GET_Duty.BackColor = System.Drawing.Color.Transparent
        Me.Button_GET_Duty.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_GET_Duty.Location = New System.Drawing.Point(453, 188)
        Me.Button_GET_Duty.Name = "Button_GET_Duty"
        Me.Button_GET_Duty.Size = New System.Drawing.Size(100, 25)
        Me.Button_GET_Duty.TabIndex = 506
        Me.Button_GET_Duty.Text = "GET Duty"
        Me.Button_GET_Duty.UseVisualStyleBackColor = False
        '
        'Button_SET_Duty
        '
        Me.Button_SET_Duty.BackColor = System.Drawing.Color.Transparent
        Me.Button_SET_Duty.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_SET_Duty.Location = New System.Drawing.Point(453, 159)
        Me.Button_SET_Duty.Name = "Button_SET_Duty"
        Me.Button_SET_Duty.Size = New System.Drawing.Size(100, 23)
        Me.Button_SET_Duty.TabIndex = 507
        Me.Button_SET_Duty.Text = "SET Duty"
        Me.Button_SET_Duty.UseVisualStyleBackColor = False
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.Label465)
        Me.GroupBox7.Controls.Add(Me.Label466)
        Me.GroupBox7.Controls.Add(Me.Button32)
        Me.GroupBox7.Controls.Add(Me.NumericUpDown23)
        Me.GroupBox7.Controls.Add(Me.TextBox47)
        Me.GroupBox7.Controls.Add(Me.TextBox48)
        Me.GroupBox7.Controls.Add(Me.Button33)
        Me.GroupBox7.Controls.Add(Me.NumericUpDown24)
        Me.GroupBox7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox7.Location = New System.Drawing.Point(681, 159)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(448, 139)
        Me.GroupBox7.TabIndex = 506
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "General Commands"
        '
        'Label465
        '
        Me.Label465.AutoSize = True
        Me.Label465.BackColor = System.Drawing.Color.LightYellow
        Me.Label465.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label465.Location = New System.Drawing.Point(109, 18)
        Me.Label465.Name = "Label465"
        Me.Label465.Size = New System.Drawing.Size(34, 13)
        Me.Label465.TabIndex = 491
        Me.Label465.Text = "Data"
        '
        'Label466
        '
        Me.Label466.AutoSize = True
        Me.Label466.BackColor = System.Drawing.Color.LightYellow
        Me.Label466.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label466.Location = New System.Drawing.Point(6, 18)
        Me.Label466.Name = "Label466"
        Me.Label466.Size = New System.Drawing.Size(38, 13)
        Me.Label466.TabIndex = 490
        Me.Label466.Text = "Index"
        '
        'Button32
        '
        Me.Button32.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button32.Location = New System.Drawing.Point(326, 91)
        Me.Button32.Name = "Button32"
        Me.Button32.Size = New System.Drawing.Size(64, 23)
        Me.Button32.TabIndex = 489
        Me.Button32.Text = "Read"
        Me.Button32.UseVisualStyleBackColor = True
        '
        'NumericUpDown23
        '
        Me.NumericUpDown23.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericUpDown23.Location = New System.Drawing.Point(4, 91)
        Me.NumericUpDown23.Maximum = New Decimal(New Integer() {101, 0, 0, 0})
        Me.NumericUpDown23.Name = "NumericUpDown23"
        Me.NumericUpDown23.Size = New System.Drawing.Size(54, 23)
        Me.NumericUpDown23.TabIndex = 487
        Me.NumericUpDown23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown23.Value = New Decimal(New Integer() {20, 0, 0, 0})
        '
        'TextBox47
        '
        Me.TextBox47.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox47.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox47.Location = New System.Drawing.Point(93, 90)
        Me.TextBox47.Multiline = True
        Me.TextBox47.Name = "TextBox47"
        Me.TextBox47.ReadOnly = True
        Me.TextBox47.Size = New System.Drawing.Size(227, 23)
        Me.TextBox47.TabIndex = 486
        Me.TextBox47.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox48
        '
        Me.TextBox48.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox48.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox48.Location = New System.Drawing.Point(93, 47)
        Me.TextBox48.Multiline = True
        Me.TextBox48.Name = "TextBox48"
        Me.TextBox48.ReadOnly = True
        Me.TextBox48.Size = New System.Drawing.Size(227, 23)
        Me.TextBox48.TabIndex = 485
        Me.TextBox48.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Button33
        '
        Me.Button33.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button33.Location = New System.Drawing.Point(326, 46)
        Me.Button33.Name = "Button33"
        Me.Button33.Size = New System.Drawing.Size(64, 23)
        Me.Button33.TabIndex = 484
        Me.Button33.Text = "Write"
        Me.Button33.UseVisualStyleBackColor = True
        '
        'NumericUpDown24
        '
        Me.NumericUpDown24.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericUpDown24.Location = New System.Drawing.Point(4, 47)
        Me.NumericUpDown24.Maximum = New Decimal(New Integer() {101, 0, 0, 0})
        Me.NumericUpDown24.Name = "NumericUpDown24"
        Me.NumericUpDown24.Size = New System.Drawing.Size(54, 23)
        Me.NumericUpDown24.TabIndex = 421
        Me.NumericUpDown24.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown24.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Tab_Calibration
        '
        Me.Tab_Calibration.Controls.Add(Me.GroupBox1)
        Me.Tab_Calibration.Controls.Add(Me.GroupBox20)
        Me.Tab_Calibration.Controls.Add(Me.GroupBox9)
        Me.Tab_Calibration.Controls.Add(Me.GroupBox15)
        Me.Tab_Calibration.Controls.Add(Me.GroupBox13)
        Me.Tab_Calibration.Location = New System.Drawing.Point(4, 32)
        Me.Tab_Calibration.Name = "Tab_Calibration"
        Me.Tab_Calibration.Padding = New System.Windows.Forms.Padding(3)
        Me.Tab_Calibration.Size = New System.Drawing.Size(1193, 421)
        Me.Tab_Calibration.TabIndex = 2
        Me.Tab_Calibration.Text = "Calibration"
        Me.Tab_Calibration.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.TextBox_offset1)
        Me.GroupBox1.Controls.Add(Me.TextBox_G1)
        Me.GroupBox1.Controls.Add(Me.Button_calculate)
        Me.GroupBox1.Controls.Add(Me.TextBox_G0)
        Me.GroupBox1.Controls.Add(Me.TextBox_offset0)
        Me.GroupBox1.Controls.Add(Me.Label464)
        Me.GroupBox1.Location = New System.Drawing.Point(9, 180)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(443, 118)
        Me.GroupBox1.TabIndex = 563
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Calculation"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label5.Location = New System.Drawing.Point(158, 57)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(43, 12)
        Me.Label5.TabIndex = 575
        Me.Label5.Text = "Offset1"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label4.Location = New System.Drawing.Point(158, 27)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(43, 12)
        Me.Label4.TabIndex = 574
        Me.Label4.Text = "Offset0"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(0, 52)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(57, 16)
        Me.Label3.TabIndex = 573
        Me.Label3.Text = "Slope1"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(0, 23)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(57, 16)
        Me.Label1.TabIndex = 572
        Me.Label1.Text = "Slope0"
        '
        'TextBox_offset1
        '
        Me.TextBox_offset1.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.TextBox_offset1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_offset1.Location = New System.Drawing.Point(213, 51)
        Me.TextBox_offset1.MaxLength = 2
        Me.TextBox_offset1.Name = "TextBox_offset1"
        Me.TextBox_offset1.Size = New System.Drawing.Size(68, 23)
        Me.TextBox_offset1.TabIndex = 571
        Me.TextBox_offset1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox_G1
        '
        Me.TextBox_G1.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.TextBox_G1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_G1.Location = New System.Drawing.Point(66, 48)
        Me.TextBox_G1.MaxLength = 2
        Me.TextBox_G1.Name = "TextBox_G1"
        Me.TextBox_G1.Size = New System.Drawing.Size(58, 23)
        Me.TextBox_G1.TabIndex = 570
        Me.TextBox_G1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Button_calculate
        '
        Me.Button_calculate.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_calculate.Location = New System.Drawing.Point(20, 80)
        Me.Button_calculate.Name = "Button_calculate"
        Me.Button_calculate.Size = New System.Drawing.Size(131, 26)
        Me.Button_calculate.TabIndex = 569
        Me.Button_calculate.Text = "Calculate"
        Me.Button_calculate.UseVisualStyleBackColor = True
        '
        'TextBox_G0
        '
        Me.TextBox_G0.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.TextBox_G0.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_G0.Location = New System.Drawing.Point(66, 22)
        Me.TextBox_G0.MaxLength = 2
        Me.TextBox_G0.Name = "TextBox_G0"
        Me.TextBox_G0.Size = New System.Drawing.Size(58, 23)
        Me.TextBox_G0.TabIndex = 568
        Me.TextBox_G0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox_offset0
        '
        Me.TextBox_offset0.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.TextBox_offset0.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_offset0.Location = New System.Drawing.Point(213, 20)
        Me.TextBox_offset0.MaxLength = 2
        Me.TextBox_offset0.Multiline = True
        Me.TextBox_offset0.Name = "TextBox_offset0"
        Me.TextBox_offset0.ReadOnly = True
        Me.TextBox_offset0.Size = New System.Drawing.Size(68, 25)
        Me.TextBox_offset0.TabIndex = 566
        Me.TextBox_offset0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label464
        '
        Me.Label464.AutoSize = True
        Me.Label464.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.25!, System.Drawing.FontStyle.Bold)
        Me.Label464.Location = New System.Drawing.Point(18, -10)
        Me.Label464.Name = "Label464"
        Me.Label464.Size = New System.Drawing.Size(72, 12)
        Me.Label464.TabIndex = 567
        Me.Label464.Text = "BYTE COUNT"
        Me.Label464.Visible = False
        '
        'GroupBox20
        '
        Me.GroupBox20.Controls.Add(Me.GroupBox_1)
        Me.GroupBox20.Controls.Add(Me.GroupBox_2)
        Me.GroupBox20.Controls.Add(Me.Button_Read_Adc)
        Me.GroupBox20.Controls.Add(Me.ListBox_adc)
        Me.GroupBox20.Location = New System.Drawing.Point(470, 21)
        Me.GroupBox20.Name = "GroupBox20"
        Me.GroupBox20.Size = New System.Drawing.Size(669, 233)
        Me.GroupBox20.TabIndex = 559
        Me.GroupBox20.TabStop = False
        Me.GroupBox20.Text = "ADC"
        '
        'GroupBox_1
        '
        Me.GroupBox_1.Controls.Add(Me.Label461)
        Me.GroupBox_1.Controls.Add(Me.TextBox_input_1)
        Me.GroupBox_1.Controls.Add(Me.Label6)
        Me.GroupBox_1.Controls.Add(Me.TextBox_Raw_ADC)
        Me.GroupBox_1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_1.Location = New System.Drawing.Point(260, 20)
        Me.GroupBox_1.Name = "GroupBox_1"
        Me.GroupBox_1.Size = New System.Drawing.Size(172, 121)
        Me.GroupBox_1.TabIndex = 567
        Me.GroupBox_1.TabStop = False
        Me.GroupBox_1.Text = "10%"
        '
        'Label461
        '
        Me.Label461.AutoSize = True
        Me.Label461.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label461.Location = New System.Drawing.Point(15, 22)
        Me.Label461.Name = "Label461"
        Me.Label461.Size = New System.Drawing.Size(114, 16)
        Me.Label461.TabIndex = 569
        Me.Label461.Text = "Data measured"
        '
        'TextBox_input_1
        '
        Me.TextBox_input_1.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.TextBox_input_1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_input_1.Location = New System.Drawing.Point(17, 38)
        Me.TextBox_input_1.MaxLength = 2
        Me.TextBox_input_1.Name = "TextBox_input_1"
        Me.TextBox_input_1.Size = New System.Drawing.Size(137, 23)
        Me.TextBox_input_1.TabIndex = 568
        Me.TextBox_input_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(18, 64)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(98, 16)
        Me.Label6.TabIndex = 567
        Me.Label6.Text = "Raw ADC Data"
        '
        'TextBox_Raw_ADC
        '
        Me.TextBox_Raw_ADC.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.TextBox_Raw_ADC.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_Raw_ADC.Location = New System.Drawing.Point(17, 83)
        Me.TextBox_Raw_ADC.MaxLength = 2
        Me.TextBox_Raw_ADC.Name = "TextBox_Raw_ADC"
        Me.TextBox_Raw_ADC.Size = New System.Drawing.Size(137, 23)
        Me.TextBox_Raw_ADC.TabIndex = 566
        Me.TextBox_Raw_ADC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox_2
        '
        Me.GroupBox_2.Controls.Add(Me.Label7)
        Me.GroupBox_2.Controls.Add(Me.TextBox_input_2)
        Me.GroupBox_2.Controls.Add(Me.Label8)
        Me.GroupBox_2.Controls.Add(Me.TextBox_RAW_ADC_2)
        Me.GroupBox_2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_2.Location = New System.Drawing.Point(438, 20)
        Me.GroupBox_2.Name = "GroupBox_2"
        Me.GroupBox_2.Size = New System.Drawing.Size(178, 121)
        Me.GroupBox_2.TabIndex = 566
        Me.GroupBox_2.TabStop = False
        Me.GroupBox_2.Text = "20%"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(15, 23)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(114, 16)
        Me.Label7.TabIndex = 569
        Me.Label7.Text = "Data measured"
        '
        'TextBox_input_2
        '
        Me.TextBox_input_2.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.TextBox_input_2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_input_2.Location = New System.Drawing.Point(17, 39)
        Me.TextBox_input_2.MaxLength = 2
        Me.TextBox_input_2.Name = "TextBox_input_2"
        Me.TextBox_input_2.Size = New System.Drawing.Size(137, 23)
        Me.TextBox_input_2.TabIndex = 568
        Me.TextBox_input_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(18, 65)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(98, 16)
        Me.Label8.TabIndex = 567
        Me.Label8.Text = "Raw ADC Data"
        '
        'TextBox_RAW_ADC_2
        '
        Me.TextBox_RAW_ADC_2.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.TextBox_RAW_ADC_2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_RAW_ADC_2.Location = New System.Drawing.Point(17, 84)
        Me.TextBox_RAW_ADC_2.MaxLength = 2
        Me.TextBox_RAW_ADC_2.Name = "TextBox_RAW_ADC_2"
        Me.TextBox_RAW_ADC_2.Size = New System.Drawing.Size(137, 23)
        Me.TextBox_RAW_ADC_2.TabIndex = 566
        Me.TextBox_RAW_ADC_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Button_Read_Adc
        '
        Me.Button_Read_Adc.BackColor = System.Drawing.SystemColors.Control
        Me.Button_Read_Adc.Location = New System.Drawing.Point(260, 159)
        Me.Button_Read_Adc.Name = "Button_Read_Adc"
        Me.Button_Read_Adc.Size = New System.Drawing.Size(137, 34)
        Me.Button_Read_Adc.TabIndex = 561
        Me.Button_Read_Adc.Text = "Read ADC"
        Me.Button_Read_Adc.UseVisualStyleBackColor = False
        '
        'ListBox_adc
        '
        Me.ListBox_adc.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListBox_adc.FormattingEnabled = True
        Me.ListBox_adc.ItemHeight = 16
        Me.ListBox_adc.Location = New System.Drawing.Point(6, 19)
        Me.ListBox_adc.Name = "ListBox_adc"
        Me.ListBox_adc.Size = New System.Drawing.Size(241, 132)
        Me.ListBox_adc.Sorted = True
        Me.ListBox_adc.TabIndex = 559
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.Button_Disable_Factory_Mode)
        Me.GroupBox9.Controls.Add(Me.MFR_EN)
        Me.GroupBox9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox9.Location = New System.Drawing.Point(211, 317)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(209, 98)
        Me.GroupBox9.TabIndex = 557
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "Factory Mode Control"
        Me.GroupBox9.Visible = False
        '
        'Button_Disable_Factory_Mode
        '
        Me.Button_Disable_Factory_Mode.BackColor = System.Drawing.Color.Transparent
        Me.Button_Disable_Factory_Mode.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Disable_Factory_Mode.Location = New System.Drawing.Point(12, 59)
        Me.Button_Disable_Factory_Mode.Name = "Button_Disable_Factory_Mode"
        Me.Button_Disable_Factory_Mode.Size = New System.Drawing.Size(176, 31)
        Me.Button_Disable_Factory_Mode.TabIndex = 430
        Me.Button_Disable_Factory_Mode.Text = "Disable Factory Mode"
        Me.Button_Disable_Factory_Mode.UseVisualStyleBackColor = False
        '
        'MFR_EN
        '
        Me.MFR_EN.BackColor = System.Drawing.Color.Transparent
        Me.MFR_EN.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MFR_EN.Location = New System.Drawing.Point(12, 21)
        Me.MFR_EN.Name = "MFR_EN"
        Me.MFR_EN.Size = New System.Drawing.Size(176, 31)
        Me.MFR_EN.TabIndex = 429
        Me.MFR_EN.Text = "Enable Factory Mode"
        Me.MFR_EN.UseVisualStyleBackColor = False
        '
        'GroupBox15
        '
        Me.GroupBox15.Controls.Add(Me.Button_S_Disable)
        Me.GroupBox15.Controls.Add(Me.Button_S_Enable)
        Me.GroupBox15.Controls.Add(Me.CheckBox5)
        Me.GroupBox15.Controls.Add(Me.RadioButton_Disable)
        Me.GroupBox15.Controls.Add(Me.RadioButton_Enable)
        Me.GroupBox15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox15.Location = New System.Drawing.Point(10, 316)
        Me.GroupBox15.Name = "GroupBox15"
        Me.GroupBox15.Size = New System.Drawing.Size(161, 99)
        Me.GroupBox15.TabIndex = 556
        Me.GroupBox15.TabStop = False
        Me.GroupBox15.Text = " Calibration Mode"
        '
        'Button_S_Disable
        '
        Me.Button_S_Disable.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_S_Disable.Location = New System.Drawing.Point(29, 59)
        Me.Button_S_Disable.Name = "Button_S_Disable"
        Me.Button_S_Disable.Size = New System.Drawing.Size(116, 32)
        Me.Button_S_Disable.TabIndex = 558
        Me.Button_S_Disable.Text = "Disable"
        Me.Button_S_Disable.UseVisualStyleBackColor = True
        '
        'Button_S_Enable
        '
        Me.Button_S_Enable.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_S_Enable.Location = New System.Drawing.Point(29, 21)
        Me.Button_S_Enable.Name = "Button_S_Enable"
        Me.Button_S_Enable.Size = New System.Drawing.Size(116, 32)
        Me.Button_S_Enable.TabIndex = 557
        Me.Button_S_Enable.Text = "Enable"
        Me.Button_S_Enable.UseVisualStyleBackColor = True
        '
        'CheckBox5
        '
        Me.CheckBox5.AutoSize = True
        Me.CheckBox5.Checked = True
        Me.CheckBox5.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox5.Enabled = False
        Me.CheckBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox5.Location = New System.Drawing.Point(151, 48)
        Me.CheckBox5.Name = "CheckBox5"
        Me.CheckBox5.Size = New System.Drawing.Size(51, 17)
        Me.CheckBox5.TabIndex = 552
        Me.CheckBox5.Text = "Test"
        Me.CheckBox5.UseVisualStyleBackColor = True
        Me.CheckBox5.Visible = False
        '
        'RadioButton_Disable
        '
        Me.RadioButton_Disable.AutoSize = True
        Me.RadioButton_Disable.BackColor = System.Drawing.Color.Transparent
        Me.RadioButton_Disable.Enabled = False
        Me.RadioButton_Disable.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton_Disable.Location = New System.Drawing.Point(151, 22)
        Me.RadioButton_Disable.Name = "RadioButton_Disable"
        Me.RadioButton_Disable.Size = New System.Drawing.Size(80, 20)
        Me.RadioButton_Disable.TabIndex = 548
        Me.RadioButton_Disable.Text = "Disable"
        Me.RadioButton_Disable.UseVisualStyleBackColor = False
        Me.RadioButton_Disable.Visible = False
        '
        'RadioButton_Enable
        '
        Me.RadioButton_Enable.AllowDrop = True
        Me.RadioButton_Enable.AutoCheck = False
        Me.RadioButton_Enable.AutoSize = True
        Me.RadioButton_Enable.BackColor = System.Drawing.Color.Transparent
        Me.RadioButton_Enable.Checked = True
        Me.RadioButton_Enable.Enabled = False
        Me.RadioButton_Enable.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton_Enable.Location = New System.Drawing.Point(151, 74)
        Me.RadioButton_Enable.Name = "RadioButton_Enable"
        Me.RadioButton_Enable.Size = New System.Drawing.Size(75, 20)
        Me.RadioButton_Enable.TabIndex = 547
        Me.RadioButton_Enable.TabStop = True
        Me.RadioButton_Enable.Text = "Enable"
        Me.RadioButton_Enable.UseVisualStyleBackColor = False
        Me.RadioButton_Enable.Visible = False
        '
        'GroupBox13
        '
        Me.GroupBox13.Controls.Add(Me.RadioButton_s)
        Me.GroupBox13.Controls.Add(Me.RadioButton_p)
        Me.GroupBox13.Controls.Add(Me.Button_Cab_Read)
        Me.GroupBox13.Controls.Add(Me.Button27)
        Me.GroupBox13.Controls.Add(Me.ListBox_index)
        Me.GroupBox13.Controls.Add(Me.Label462)
        Me.GroupBox13.Controls.Add(Me.Button_Execute)
        Me.GroupBox13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox13.Location = New System.Drawing.Point(9, 11)
        Me.GroupBox13.Name = "GroupBox13"
        Me.GroupBox13.Size = New System.Drawing.Size(443, 163)
        Me.GroupBox13.TabIndex = 542
        Me.GroupBox13.TabStop = False
        Me.GroupBox13.Text = "Calibration Event"
        '
        'RadioButton_s
        '
        Me.RadioButton_s.AllowDrop = True
        Me.RadioButton_s.AutoSize = True
        Me.RadioButton_s.BackColor = System.Drawing.Color.Transparent
        Me.RadioButton_s.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton_s.Location = New System.Drawing.Point(319, 10)
        Me.RadioButton_s.Name = "RadioButton_s"
        Me.RadioButton_s.Size = New System.Drawing.Size(92, 19)
        Me.RadioButton_s.TabIndex = 564
        Me.RadioButton_s.Text = "Secondary"
        Me.RadioButton_s.UseVisualStyleBackColor = False
        '
        'RadioButton_p
        '
        Me.RadioButton_p.AutoSize = True
        Me.RadioButton_p.BackColor = System.Drawing.Color.Transparent
        Me.RadioButton_p.Checked = True
        Me.RadioButton_p.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton_p.Location = New System.Drawing.Point(239, 10)
        Me.RadioButton_p.Name = "RadioButton_p"
        Me.RadioButton_p.Size = New System.Drawing.Size(74, 19)
        Me.RadioButton_p.TabIndex = 563
        Me.RadioButton_p.TabStop = True
        Me.RadioButton_p.Text = "Primary"
        Me.RadioButton_p.UseVisualStyleBackColor = False
        '
        'Button_Cab_Read
        '
        Me.Button_Cab_Read.Location = New System.Drawing.Point(262, 81)
        Me.Button_Cab_Read.Name = "Button_Cab_Read"
        Me.Button_Cab_Read.Size = New System.Drawing.Size(137, 23)
        Me.Button_Cab_Read.TabIndex = 562
        Me.Button_Cab_Read.Text = "Calibration Read"
        Me.Button_Cab_Read.UseVisualStyleBackColor = True
        '
        'Button27
        '
        Me.Button27.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button27.Location = New System.Drawing.Point(262, 116)
        Me.Button27.Name = "Button27"
        Me.Button27.Size = New System.Drawing.Size(137, 26)
        Me.Button27.TabIndex = 557
        Me.Button27.Text = "Clear "
        Me.Button27.UseVisualStyleBackColor = True
        Me.Button27.Visible = False
        '
        'ListBox_index
        '
        Me.ListBox_index.FormattingEnabled = True
        Me.ListBox_index.ItemHeight = 16
        Me.ListBox_index.Location = New System.Drawing.Point(7, 35)
        Me.ListBox_index.Name = "ListBox_index"
        Me.ListBox_index.Size = New System.Drawing.Size(226, 116)
        Me.ListBox_index.Sorted = True
        Me.ListBox_index.TabIndex = 556
        '
        'Label462
        '
        Me.Label462.AutoSize = True
        Me.Label462.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label462.Location = New System.Drawing.Point(5, 20)
        Me.Label462.Name = "Label462"
        Me.Label462.Size = New System.Drawing.Size(73, 16)
        Me.Label462.TabIndex = 533
        Me.Label462.Text = "Index No."
        '
        'Button_Execute
        '
        Me.Button_Execute.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Execute.Location = New System.Drawing.Point(262, 43)
        Me.Button_Execute.Name = "Button_Execute"
        Me.Button_Execute.Size = New System.Drawing.Size(140, 26)
        Me.Button_Execute.TabIndex = 528
        Me.Button_Execute.Text = "Calibration Write"
        Me.Button_Execute.UseVisualStyleBackColor = True
        '
        'Tab_Log
        '
        Me.Tab_Log.Controls.Add(Me.Button_LogRead)
        Me.Tab_Log.Controls.Add(Me.DataGridView_LOG)
        Me.Tab_Log.Location = New System.Drawing.Point(4, 32)
        Me.Tab_Log.Name = "Tab_Log"
        Me.Tab_Log.Padding = New System.Windows.Forms.Padding(3)
        Me.Tab_Log.Size = New System.Drawing.Size(1193, 421)
        Me.Tab_Log.TabIndex = 6
        Me.Tab_Log.Text = "Event Log"
        Me.Tab_Log.UseVisualStyleBackColor = True
        '
        'Button_LogRead
        '
        Me.Button_LogRead.BackColor = System.Drawing.Color.Transparent
        Me.Button_LogRead.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_LogRead.Location = New System.Drawing.Point(690, 125)
        Me.Button_LogRead.Name = "Button_LogRead"
        Me.Button_LogRead.Size = New System.Drawing.Size(145, 37)
        Me.Button_LogRead.TabIndex = 425
        Me.Button_LogRead.Text = "Read Log Once"
        Me.Button_LogRead.UseVisualStyleBackColor = False
        '
        'DataGridView_LOG
        '
        Me.DataGridView_LOG.AllowUserToDeleteRows = False
        Me.DataGridView_LOG.AllowUserToResizeColumns = False
        Me.DataGridView_LOG.AllowUserToResizeRows = False
        Me.DataGridView_LOG.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        Me.DataGridView_LOG.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.DataGridView_LOG.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn16, Me.DataGridViewTextBoxColumn17, Me.DataGridViewTextBoxColumn20, Me.DataGridViewTextBoxColumn22, Me.DataGridViewTextBoxColumn23})
        Me.DataGridView_LOG.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.DataGridView_LOG.GridColor = System.Drawing.SystemColors.Control
        Me.DataGridView_LOG.Location = New System.Drawing.Point(3, 3)
        Me.DataGridView_LOG.MultiSelect = False
        Me.DataGridView_LOG.Name = "DataGridView_LOG"
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.ControlDark
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle8.NullValue = "0"
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView_LOG.RowHeadersDefaultCellStyle = DataGridViewCellStyle8
        Me.DataGridView_LOG.RowHeadersVisible = False
        Me.DataGridView_LOG.RowHeadersWidth = 195
        Me.DataGridView_LOG.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.DataGridView_LOG.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.DataGridView_LOG.RowTemplate.DefaultCellStyle.Font = New System.Drawing.Font("Arial Narrow", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DataGridView_LOG.RowTemplate.Height = 19
        Me.DataGridView_LOG.RowTemplate.ReadOnly = True
        Me.DataGridView_LOG.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.DataGridView_LOG.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.DataGridView_LOG.Size = New System.Drawing.Size(558, 328)
        Me.DataGridView_LOG.TabIndex = 423
        '
        'DataGridViewTextBoxColumn16
        '
        Me.DataGridViewTextBoxColumn16.HeaderText = "Cmd"
        Me.DataGridViewTextBoxColumn16.Name = "DataGridViewTextBoxColumn16"
        Me.DataGridViewTextBoxColumn16.Width = 35
        '
        'DataGridViewTextBoxColumn17
        '
        Me.DataGridViewTextBoxColumn17.HeaderText = "Command Name"
        Me.DataGridViewTextBoxColumn17.Name = "DataGridViewTextBoxColumn17"
        Me.DataGridViewTextBoxColumn17.Width = 130
        '
        'DataGridViewTextBoxColumn20
        '
        Me.DataGridViewTextBoxColumn20.HeaderText = "With PEC"
        Me.DataGridViewTextBoxColumn20.Name = "DataGridViewTextBoxColumn20"
        Me.DataGridViewTextBoxColumn20.Width = 88
        '
        'DataGridViewTextBoxColumn22
        '
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DataGridViewTextBoxColumn22.DefaultCellStyle = DataGridViewCellStyle7
        Me.DataGridViewTextBoxColumn22.HeaderText = "Hex Data"
        Me.DataGridViewTextBoxColumn22.Name = "DataGridViewTextBoxColumn22"
        Me.DataGridViewTextBoxColumn22.Width = 84
        '
        'DataGridViewTextBoxColumn23
        '
        Me.DataGridViewTextBoxColumn23.HeaderText = "Actual"
        Me.DataGridViewTextBoxColumn23.Name = "DataGridViewTextBoxColumn23"
        Me.DataGridViewTextBoxColumn23.Width = 90
        '
        'Tab_FRU
        '
        Me.Tab_FRU.Controls.Add(Me.GroupBox19)
        Me.Tab_FRU.Controls.Add(Me.GroupBox16)
        Me.Tab_FRU.Controls.Add(Me.GroupBox6)
        Me.Tab_FRU.Location = New System.Drawing.Point(4, 32)
        Me.Tab_FRU.Name = "Tab_FRU"
        Me.Tab_FRU.Padding = New System.Windows.Forms.Padding(3)
        Me.Tab_FRU.Size = New System.Drawing.Size(1193, 421)
        Me.Tab_FRU.TabIndex = 7
        Me.Tab_FRU.Text = "FRU_EEPROM"
        Me.Tab_FRU.UseVisualStyleBackColor = True
        '
        'GroupBox19
        '
        Me.GroupBox19.Controls.Add(Me.Button_Write_Page)
        Me.GroupBox19.Controls.Add(Me.Button_Read_All)
        Me.GroupBox19.Controls.Add(Me.Button_Write_ee)
        Me.GroupBox19.Controls.Add(Me.Button_Clear_FRU)
        Me.GroupBox19.Controls.Add(Me.Button_FRU_File)
        Me.GroupBox19.Controls.Add(Me.BTN_FRU_Read)
        Me.GroupBox19.Location = New System.Drawing.Point(696, 215)
        Me.GroupBox19.Name = "GroupBox19"
        Me.GroupBox19.Size = New System.Drawing.Size(370, 119)
        Me.GroupBox19.TabIndex = 559
        Me.GroupBox19.TabStop = False
        Me.GroupBox19.Text = "Operation"
        '
        'Button_Write_Page
        '
        Me.Button_Write_Page.Location = New System.Drawing.Point(102, 82)
        Me.Button_Write_Page.Name = "Button_Write_Page"
        Me.Button_Write_Page.Size = New System.Drawing.Size(89, 23)
        Me.Button_Write_Page.TabIndex = 563
        Me.Button_Write_Page.Text = "Write Page"
        Me.Button_Write_Page.UseVisualStyleBackColor = True
        '
        'Button_Read_All
        '
        Me.Button_Read_All.Location = New System.Drawing.Point(99, 28)
        Me.Button_Read_All.Name = "Button_Read_All"
        Me.Button_Read_All.Size = New System.Drawing.Size(89, 24)
        Me.Button_Read_All.TabIndex = 561
        Me.Button_Read_All.Text = "Read All"
        Me.Button_Read_All.UseVisualStyleBackColor = True
        '
        'Button_Write_ee
        '
        Me.Button_Write_ee.Location = New System.Drawing.Point(6, 82)
        Me.Button_Write_ee.Name = "Button_Write_ee"
        Me.Button_Write_ee.Size = New System.Drawing.Size(89, 23)
        Me.Button_Write_ee.TabIndex = 562
        Me.Button_Write_ee.Text = "Write Byte"
        Me.Button_Write_ee.UseVisualStyleBackColor = True
        '
        'Button_Clear_FRU
        '
        Me.Button_Clear_FRU.Location = New System.Drawing.Point(194, 82)
        Me.Button_Clear_FRU.Name = "Button_Clear_FRU"
        Me.Button_Clear_FRU.Size = New System.Drawing.Size(127, 23)
        Me.Button_Clear_FRU.TabIndex = 561
        Me.Button_Clear_FRU.Text = "Clear All"
        Me.Button_Clear_FRU.UseVisualStyleBackColor = True
        '
        'Button_FRU_File
        '
        Me.Button_FRU_File.Location = New System.Drawing.Point(194, 28)
        Me.Button_FRU_File.Name = "Button_FRU_File"
        Me.Button_FRU_File.Size = New System.Drawing.Size(127, 24)
        Me.Button_FRU_File.TabIndex = 560
        Me.Button_FRU_File.Text = "Report to File"
        Me.Button_FRU_File.UseVisualStyleBackColor = True
        '
        'BTN_FRU_Read
        '
        Me.BTN_FRU_Read.Location = New System.Drawing.Point(6, 28)
        Me.BTN_FRU_Read.Name = "BTN_FRU_Read"
        Me.BTN_FRU_Read.Size = New System.Drawing.Size(89, 24)
        Me.BTN_FRU_Read.TabIndex = 559
        Me.BTN_FRU_Read.Text = "Read FRU"
        Me.BTN_FRU_Read.UseVisualStyleBackColor = True
        '
        'GroupBox16
        '
        Me.GroupBox16.Controls.Add(Me.Label47)
        Me.GroupBox16.Controls.Add(Me.Label36)
        Me.GroupBox16.Controls.Add(Me.TextBox_Read_EE_Byte_Count)
        Me.GroupBox16.Controls.Add(Me.TextBox_Write_EE_Byte2)
        Me.GroupBox16.Controls.Add(Me.TextBox_Write_EE_Byte1)
        Me.GroupBox16.Controls.Add(Me.Label44)
        Me.GroupBox16.Controls.Add(Me.Label39)
        Me.GroupBox16.Controls.Add(Me.Label38)
        Me.GroupBox16.Controls.Add(Me.TextBox_Write_EE_Word_Addr)
        Me.GroupBox16.Location = New System.Drawing.Point(696, 11)
        Me.GroupBox16.Name = "GroupBox16"
        Me.GroupBox16.Size = New System.Drawing.Size(370, 198)
        Me.GroupBox16.TabIndex = 557
        Me.GroupBox16.TabStop = False
        Me.GroupBox16.Text = "EEPROM "
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.Location = New System.Drawing.Point(198, 157)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(56, 16)
        Me.Label47.TabIndex = 18
        Me.Label47.Text = "Max:16"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(8, 156)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(67, 16)
        Me.Label36.TabIndex = 17
        Me.Label36.Text = "Byte No."
        '
        'TextBox_Read_EE_Byte_Count
        '
        Me.TextBox_Read_EE_Byte_Count.Location = New System.Drawing.Point(93, 156)
        Me.TextBox_Read_EE_Byte_Count.Name = "TextBox_Read_EE_Byte_Count"
        Me.TextBox_Read_EE_Byte_Count.Size = New System.Drawing.Size(99, 21)
        Me.TextBox_Read_EE_Byte_Count.TabIndex = 15
        Me.TextBox_Read_EE_Byte_Count.Text = "4"
        '
        'TextBox_Write_EE_Byte2
        '
        Me.TextBox_Write_EE_Byte2.AllowDrop = True
        Me.TextBox_Write_EE_Byte2.Location = New System.Drawing.Point(93, 115)
        Me.TextBox_Write_EE_Byte2.MaxLength = 32
        Me.TextBox_Write_EE_Byte2.Multiline = True
        Me.TextBox_Write_EE_Byte2.Name = "TextBox_Write_EE_Byte2"
        Me.TextBox_Write_EE_Byte2.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.TextBox_Write_EE_Byte2.Size = New System.Drawing.Size(99, 35)
        Me.TextBox_Write_EE_Byte2.TabIndex = 14
        Me.TextBox_Write_EE_Byte2.Text = "45"
        '
        'TextBox_Write_EE_Byte1
        '
        Me.TextBox_Write_EE_Byte1.Location = New System.Drawing.Point(93, 85)
        Me.TextBox_Write_EE_Byte1.Name = "TextBox_Write_EE_Byte1"
        Me.TextBox_Write_EE_Byte1.Size = New System.Drawing.Size(99, 21)
        Me.TextBox_Write_EE_Byte1.TabIndex = 13
        Me.TextBox_Write_EE_Byte1.Text = "12"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.Location = New System.Drawing.Point(6, 115)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(45, 16)
        Me.Label44.TabIndex = 12
        Me.Label44.Text = "Page"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(6, 89)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(43, 16)
        Me.Label39.TabIndex = 11
        Me.Label39.Text = "Byte "
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(6, 58)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(82, 16)
        Me.Label38.TabIndex = 10
        Me.Label38.Text = "Word Addr"
        '
        'TextBox_Write_EE_Word_Addr
        '
        Me.TextBox_Write_EE_Word_Addr.Location = New System.Drawing.Point(93, 58)
        Me.TextBox_Write_EE_Word_Addr.Name = "TextBox_Write_EE_Word_Addr"
        Me.TextBox_Write_EE_Word_Addr.Size = New System.Drawing.Size(99, 21)
        Me.TextBox_Write_EE_Word_Addr.TabIndex = 8
        Me.TextBox_Write_EE_Word_Addr.Text = "0"
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.DataGridView_ee)
        Me.GroupBox6.Location = New System.Drawing.Point(3, 3)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(677, 386)
        Me.GroupBox6.TabIndex = 3
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "FUR Data"
        '
        'DataGridView_ee
        '
        Me.DataGridView_ee.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.DataGridView_ee.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView_ee.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column2, Me.Column3, Me.Column4, Me.Column5, Me.Column6, Me.Column7, Me.Column8, Me.Column9, Me.Column10, Me.Column11, Me.Column12, Me.Column13, Me.Column14, Me.Column15, Me.Column16, Me.Column17})
        Me.DataGridView_ee.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.DataGridView_ee.Location = New System.Drawing.Point(6, 21)
        Me.DataGridView_ee.Name = "DataGridView_ee"
        Me.DataGridView_ee.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        Me.DataGridView_ee.RowHeadersWidth = 60
        Me.DataGridView_ee.Size = New System.Drawing.Size(648, 359)
        Me.DataGridView_ee.TabIndex = 560
        '
        'Column2
        '
        Me.Column2.HeaderText = "h0"
        Me.Column2.Name = "Column2"
        Me.Column2.Width = 35
        '
        'Column3
        '
        Me.Column3.HeaderText = "h1"
        Me.Column3.Name = "Column3"
        Me.Column3.Width = 35
        '
        'Column4
        '
        Me.Column4.HeaderText = "02h"
        Me.Column4.Name = "Column4"
        Me.Column4.Width = 35
        '
        'Column5
        '
        Me.Column5.HeaderText = "03h"
        Me.Column5.Name = "Column5"
        Me.Column5.Width = 35
        '
        'Column6
        '
        Me.Column6.HeaderText = "04h"
        Me.Column6.Name = "Column6"
        Me.Column6.Width = 35
        '
        'Column7
        '
        Me.Column7.HeaderText = "05h"
        Me.Column7.Name = "Column7"
        Me.Column7.Width = 35
        '
        'Column8
        '
        Me.Column8.HeaderText = "06h"
        Me.Column8.Name = "Column8"
        Me.Column8.Width = 35
        '
        'Column9
        '
        Me.Column9.HeaderText = "07h"
        Me.Column9.Name = "Column9"
        Me.Column9.Width = 35
        '
        'Column10
        '
        Me.Column10.HeaderText = "08h"
        Me.Column10.Name = "Column10"
        Me.Column10.Width = 35
        '
        'Column11
        '
        Me.Column11.HeaderText = "09h"
        Me.Column11.Name = "Column11"
        Me.Column11.Width = 35
        '
        'Column12
        '
        Me.Column12.HeaderText = "0Ah"
        Me.Column12.Name = "Column12"
        Me.Column12.Width = 35
        '
        'Column13
        '
        Me.Column13.HeaderText = "0Bh"
        Me.Column13.Name = "Column13"
        Me.Column13.Width = 35
        '
        'Column14
        '
        Me.Column14.HeaderText = "0Ch"
        Me.Column14.Name = "Column14"
        Me.Column14.Width = 35
        '
        'Column15
        '
        Me.Column15.HeaderText = "0Dh"
        Me.Column15.Name = "Column15"
        Me.Column15.Width = 35
        '
        'Column16
        '
        Me.Column16.HeaderText = "0Eh"
        Me.Column16.Name = "Column16"
        Me.Column16.Width = 35
        '
        'Column17
        '
        Me.Column17.HeaderText = "0Fh"
        Me.Column17.Name = "Column17"
        Me.Column17.Width = 35
        '
        'Tab_Statistics
        '
        Me.Tab_Statistics.Controls.Add(Me.Chart1)
        Me.Tab_Statistics.Location = New System.Drawing.Point(4, 32)
        Me.Tab_Statistics.Name = "Tab_Statistics"
        Me.Tab_Statistics.Size = New System.Drawing.Size(1193, 421)
        Me.Tab_Statistics.TabIndex = 8
        Me.Tab_Statistics.Text = "Statistics"
        Me.Tab_Statistics.UseVisualStyleBackColor = True
        '
        'Chart1
        '
        Me.Chart1.BackColor = System.Drawing.Color.Gray
        Me.Chart1.BackHatchStyle = System.Windows.Forms.DataVisualization.Charting.ChartHatchStyle.BackwardDiagonal
        Me.Chart1.BorderlineColor = System.Drawing.Color.Black
        ChartArea1.AlignmentOrientation = CType((System.Windows.Forms.DataVisualization.Charting.AreaAlignmentOrientations.Vertical Or System.Windows.Forms.DataVisualization.Charting.AreaAlignmentOrientations.Horizontal), System.Windows.Forms.DataVisualization.Charting.AreaAlignmentOrientations)
        ChartArea1.Name = "ChartArea1"
        Me.Chart1.ChartAreas.Add(ChartArea1)
        Legend1.BackSecondaryColor = System.Drawing.Color.Red
        Legend1.BorderColor = System.Drawing.Color.Red
        Legend1.Name = "Legend1"
        Me.Chart1.Legends.Add(Legend1)
        Me.Chart1.Location = New System.Drawing.Point(100, 36)
        Me.Chart1.Name = "Chart1"
        Me.Chart1.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Fire
        Me.Chart1.PaletteCustomColors = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))}
        Me.Chart1.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Series1.ChartArea = "ChartArea1"
        Series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
        Series1.IsValueShownAsLabel = True
        Series1.IsXValueIndexed = True
        Series1.LabelBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Series1.LabelBorderColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Series1.Legend = "Legend1"
        Series1.LegendText = "here"
        Series1.MarkerColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Series1.Name = "Series1"
        Series1.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Berry
        Series2.ChartArea = "ChartArea1"
        Series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline
        Series2.IsXValueIndexed = True
        Series2.Legend = "Legend1"
        Series2.Name = "Series2"
        Me.Chart1.Series.Add(Series1)
        Me.Chart1.Series.Add(Series2)
        Me.Chart1.Size = New System.Drawing.Size(624, 266)
        Me.Chart1.TabIndex = 2
        Me.Chart1.Text = "Chart1"
        Title1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Title1.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.LeftRight
        Title1.BackImageTransparentColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Title1.Name = "Title1"
        Title1.Text = "Vout- Iout Curve"
        Me.Chart1.Titles.Add(Title1)
        '
        'Tab_About
        '
        Me.Tab_About.AccessibleDescription = "Here"
        Me.Tab_About.AccessibleRole = System.Windows.Forms.AccessibleRole.MenuBar
        Me.Tab_About.AllowDrop = True
        Me.Tab_About.AutoScroll = True
        Me.Tab_About.Controls.Add(Me.RichTextBox2)
        Me.Tab_About.ImeMode = System.Windows.Forms.ImeMode.[On]
        Me.Tab_About.Location = New System.Drawing.Point(4, 32)
        Me.Tab_About.Name = "Tab_About"
        Me.Tab_About.Size = New System.Drawing.Size(1193, 421)
        Me.Tab_About.TabIndex = 9
        Me.Tab_About.Text = "About"
        Me.Tab_About.UseVisualStyleBackColor = True
        '
        'RichTextBox2
        '
        Me.RichTextBox2.Location = New System.Drawing.Point(4, 5)
        Me.RichTextBox2.Name = "RichTextBox2"
        Me.RichTextBox2.Size = New System.Drawing.Size(1145, 344)
        Me.RichTextBox2.TabIndex = 0
        Me.RichTextBox2.Text = "Released By:" & Global.Microsoft.VisualBasic.ChrW(10) & "   WUHENG.CHEN@LITEON.COM" & Global.Microsoft.VisualBasic.ChrW(10) & "   65-63491486    " & Global.Microsoft.VisualBasic.ChrW(10) & "  " & Global.Microsoft.VisualBasic.ChrW(10) & "PRODUCT NAME:" & Global.Microsoft.VisualBasic.ChrW(10) & "   PMB" &
    "US GRAPHIC USER INTERFACE" & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(10) & "CopyRight:" & Global.Microsoft.VisualBasic.ChrW(10) & "   LITEON SINGAPORE PTE LTD" & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(10) & "Version: 1.0." &
    "0.0" & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Tag_Help
        '
        Me.Tag_Help.AccessibleRole = System.Windows.Forms.AccessibleRole.MenuBar
        Me.Tag_Help.AllowDrop = True
        Me.Tag_Help.Controls.Add(Me.RichTextBox3)
        Me.Tag_Help.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.LiteOn_Pmbus.My.MySettings.Default, "here", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Tag_Help.Location = New System.Drawing.Point(4, 32)
        Me.Tag_Help.Name = "Tag_Help"
        Me.Tag_Help.Size = New System.Drawing.Size(1193, 421)
        Me.Tag_Help.TabIndex = 10
        Me.Tag_Help.UseVisualStyleBackColor = True
        '
        'RichTextBox3
        '
        Me.RichTextBox3.Location = New System.Drawing.Point(3, 3)
        Me.RichTextBox3.Name = "RichTextBox3"
        Me.RichTextBox3.Size = New System.Drawing.Size(1154, 379)
        Me.RichTextBox3.TabIndex = 0
        Me.RichTextBox3.Text = resources.GetString("RichTextBox3.Text")
        '
        'GroupBox12
        '
        Me.GroupBox12.Controls.Add(Me.TextBox40)
        Me.GroupBox12.Controls.Add(Me.TextBox41)
        Me.GroupBox12.Controls.Add(Me.TextBox42)
        Me.GroupBox12.Controls.Add(Me.TextBox43)
        Me.GroupBox12.Controls.Add(Me.NumericUpDown14)
        Me.GroupBox12.Controls.Add(Me.NumericUpDown18)
        Me.GroupBox12.Controls.Add(Me.Label459)
        Me.GroupBox12.Controls.Add(Me.Label460)
        Me.GroupBox12.Controls.Add(Me.Button28)
        Me.GroupBox12.Controls.Add(Me.NumericUpDown_r_b)
        Me.GroupBox12.Controls.Add(Me.Button30)
        Me.GroupBox12.Controls.Add(Me.NumericUpDown_w_index)
        Me.GroupBox12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox12.Location = New System.Drawing.Point(1247, 319)
        Me.GroupBox12.Name = "GroupBox12"
        Me.GroupBox12.Size = New System.Drawing.Size(438, 144)
        Me.GroupBox12.TabIndex = 541
        Me.GroupBox12.TabStop = False
        Me.GroupBox12.Text = "Block Operation"
        Me.GroupBox12.Visible = False
        '
        'TextBox40
        '
        Me.TextBox40.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.TextBox40.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox40.Location = New System.Drawing.Point(12, 68)
        Me.TextBox40.MaxLength = 2
        Me.TextBox40.Multiline = True
        Me.TextBox40.Name = "TextBox40"
        Me.TextBox40.ReadOnly = True
        Me.TextBox40.Size = New System.Drawing.Size(44, 25)
        Me.TextBox40.TabIndex = 553
        Me.TextBox40.Text = "4"
        Me.TextBox40.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.TextBox40.Visible = False
        '
        'TextBox41
        '
        Me.TextBox41.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.TextBox41.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox41.Location = New System.Drawing.Point(12, 37)
        Me.TextBox41.MaxLength = 2
        Me.TextBox41.Multiline = True
        Me.TextBox41.Name = "TextBox41"
        Me.TextBox41.ReadOnly = True
        Me.TextBox41.Size = New System.Drawing.Size(44, 25)
        Me.TextBox41.TabIndex = 551
        Me.TextBox41.Text = "4"
        Me.TextBox41.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox42
        '
        Me.TextBox42.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox42.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox42.Location = New System.Drawing.Point(238, 70)
        Me.TextBox42.Multiline = True
        Me.TextBox42.Name = "TextBox42"
        Me.TextBox42.ReadOnly = True
        Me.TextBox42.Size = New System.Drawing.Size(83, 23)
        Me.TextBox42.TabIndex = 544
        Me.TextBox42.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.TextBox42.Visible = False
        '
        'TextBox43
        '
        Me.TextBox43.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TextBox43.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox43.Location = New System.Drawing.Point(333, 67)
        Me.TextBox43.Multiline = True
        Me.TextBox43.Name = "TextBox43"
        Me.TextBox43.ReadOnly = True
        Me.TextBox43.Size = New System.Drawing.Size(88, 23)
        Me.TextBox43.TabIndex = 543
        Me.TextBox43.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericUpDown14
        '
        Me.NumericUpDown14.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericUpDown14.Location = New System.Drawing.Point(79, 70)
        Me.NumericUpDown14.Maximum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown14.Name = "NumericUpDown14"
        Me.NumericUpDown14.Size = New System.Drawing.Size(54, 23)
        Me.NumericUpDown14.TabIndex = 552
        Me.NumericUpDown14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown14.Visible = False
        '
        'NumericUpDown18
        '
        Me.NumericUpDown18.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericUpDown18.Location = New System.Drawing.Point(79, 40)
        Me.NumericUpDown18.Maximum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown18.Name = "NumericUpDown18"
        Me.NumericUpDown18.Size = New System.Drawing.Size(55, 23)
        Me.NumericUpDown18.TabIndex = 550
        Me.NumericUpDown18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label459
        '
        Me.Label459.AutoSize = True
        Me.Label459.BackColor = System.Drawing.Color.LightYellow
        Me.Label459.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label459.Location = New System.Drawing.Point(330, 18)
        Me.Label459.Name = "Label459"
        Me.Label459.Size = New System.Drawing.Size(34, 13)
        Me.Label459.TabIndex = 548
        Me.Label459.Text = "Data"
        '
        'Label460
        '
        Me.Label460.AutoSize = True
        Me.Label460.BackColor = System.Drawing.Color.LightYellow
        Me.Label460.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label460.Location = New System.Drawing.Point(238, 18)
        Me.Label460.Name = "Label460"
        Me.Label460.Size = New System.Drawing.Size(38, 13)
        Me.Label460.TabIndex = 547
        Me.Label460.Text = "Index"
        '
        'Button28
        '
        Me.Button28.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button28.Location = New System.Drawing.Point(104, 111)
        Me.Button28.Name = "Button28"
        Me.Button28.Size = New System.Drawing.Size(86, 26)
        Me.Button28.TabIndex = 546
        Me.Button28.Text = "Read"
        Me.Button28.UseVisualStyleBackColor = True
        '
        'NumericUpDown_r_b
        '
        Me.NumericUpDown_r_b.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericUpDown_r_b.Location = New System.Drawing.Point(149, 71)
        Me.NumericUpDown_r_b.Maximum = New Decimal(New Integer() {25, 0, 0, 0})
        Me.NumericUpDown_r_b.Name = "NumericUpDown_r_b"
        Me.NumericUpDown_r_b.Size = New System.Drawing.Size(70, 23)
        Me.NumericUpDown_r_b.TabIndex = 545
        Me.NumericUpDown_r_b.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown_r_b.Value = New Decimal(New Integer() {20, 0, 0, 0})
        Me.NumericUpDown_r_b.Visible = False
        '
        'Button30
        '
        Me.Button30.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button30.Location = New System.Drawing.Point(12, 111)
        Me.Button30.Name = "Button30"
        Me.Button30.Size = New System.Drawing.Size(86, 25)
        Me.Button30.TabIndex = 542
        Me.Button30.Text = "Write"
        Me.Button30.UseVisualStyleBackColor = True
        '
        'NumericUpDown_w_index
        '
        Me.NumericUpDown_w_index.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericUpDown_w_index.Location = New System.Drawing.Point(149, 39)
        Me.NumericUpDown_w_index.Maximum = New Decimal(New Integer() {25, 0, 0, 0})
        Me.NumericUpDown_w_index.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_w_index.Name = "NumericUpDown_w_index"
        Me.NumericUpDown_w_index.Size = New System.Drawing.Size(70, 23)
        Me.NumericUpDown_w_index.TabIndex = 541
        Me.NumericUpDown_w_index.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown_w_index.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Test
        '
        Me.Test.BackColor = System.Drawing.Color.Transparent
        Me.Test.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Test.Location = New System.Drawing.Point(1255, 594)
        Me.Test.Name = "Test"
        Me.Test.Size = New System.Drawing.Size(72, 45)
        Me.Test.TabIndex = 553
        Me.Test.Text = "Clear Log"
        Me.Test.UseVisualStyleBackColor = False
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.NumericUpDown_EEPROM_Addr)
        Me.GroupBox2.Controls.Add(Me.Label37)
        Me.GroupBox2.Controls.Add(Me.CheckBox2)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.CheckBox1)
        Me.GroupBox2.Controls.Add(Me.Label29)
        Me.GroupBox2.Controls.Add(Me.NumericUpDown7)
        Me.GroupBox2.Controls.Add(Me.NumericUpDown_S_Addr)
        Me.GroupBox2.Controls.Add(Me.PICkitConnect)
        Me.GroupBox2.Controls.Add(Me.RadioButton16)
        Me.GroupBox2.Controls.Add(Me.RadioButton17)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(15, 3)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(1198, 46)
        Me.GroupBox2.TabIndex = 555
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Device Setting"
        '
        'NumericUpDown_EEPROM_Addr
        '
        Me.NumericUpDown_EEPROM_Addr.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericUpDown_EEPROM_Addr.Hexadecimal = True
        Me.NumericUpDown_EEPROM_Addr.Increment = New Decimal(New Integer() {100, 0, 0, 0})
        Me.NumericUpDown_EEPROM_Addr.Location = New System.Drawing.Point(949, 14)
        Me.NumericUpDown_EEPROM_Addr.Maximum = New Decimal(New Integer() {188, 0, 0, 0})
        Me.NumericUpDown_EEPROM_Addr.Minimum = New Decimal(New Integer() {100, 0, 0, 0})
        Me.NumericUpDown_EEPROM_Addr.Name = "NumericUpDown_EEPROM_Addr"
        Me.NumericUpDown_EEPROM_Addr.Size = New System.Drawing.Size(62, 21)
        Me.NumericUpDown_EEPROM_Addr.TabIndex = 564
        Me.NumericUpDown_EEPROM_Addr.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown_EEPROM_Addr.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left
        Me.NumericUpDown_EEPROM_Addr.Value = New Decimal(New Integer() {164, 0, 0, 0})
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(834, 15)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(109, 16)
        Me.Label37.TabIndex = 563
        Me.Label37.Text = "EEPROM Addr"
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Enabled = False
        Me.CheckBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox2.Location = New System.Drawing.Point(732, 16)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(96, 17)
        Me.CheckBox2.TabIndex = 561
        Me.CheckBox2.Text = "Enable MUX"
        Me.CheckBox2.UseVisualStyleBackColor = True
        Me.CheckBox2.Visible = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(300, 17)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(73, 13)
        Me.Label2.TabIndex = 559
        Me.Label2.Text = "Slave Addr."
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Checked = True
        Me.CheckBox1.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox1.Location = New System.Drawing.Point(638, 17)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(93, 17)
        Me.CheckBox1.TabIndex = 558
        Me.CheckBox1.Text = "Enable PEC"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(447, 16)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(87, 15)
        Me.Label29.TabIndex = 557
        Me.Label29.Text = "Interval (ms)"
        '
        'NumericUpDown7
        '
        Me.NumericUpDown7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericUpDown7.Increment = New Decimal(New Integer() {100, 0, 0, 0})
        Me.NumericUpDown7.Location = New System.Drawing.Point(540, 14)
        Me.NumericUpDown7.Maximum = New Decimal(New Integer() {5000, 0, 0, 0})
        Me.NumericUpDown7.Minimum = New Decimal(New Integer() {500, 0, 0, 0})
        Me.NumericUpDown7.Name = "NumericUpDown7"
        Me.NumericUpDown7.Size = New System.Drawing.Size(78, 21)
        Me.NumericUpDown7.TabIndex = 556
        Me.NumericUpDown7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown7.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left
        Me.NumericUpDown7.Value = New Decimal(New Integer() {500, 0, 0, 0})
        '
        'NumericUpDown_S_Addr
        '
        Me.NumericUpDown_S_Addr.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericUpDown_S_Addr.Hexadecimal = True
        Me.NumericUpDown_S_Addr.Increment = New Decimal(New Integer() {100, 0, 0, 0})
        Me.NumericUpDown_S_Addr.Location = New System.Drawing.Point(379, 14)
        Me.NumericUpDown_S_Addr.Maximum = New Decimal(New Integer() {188, 0, 0, 0})
        Me.NumericUpDown_S_Addr.Minimum = New Decimal(New Integer() {100, 0, 0, 0})
        Me.NumericUpDown_S_Addr.Name = "NumericUpDown_S_Addr"
        Me.NumericUpDown_S_Addr.Size = New System.Drawing.Size(62, 21)
        Me.NumericUpDown_S_Addr.TabIndex = 555
        Me.NumericUpDown_S_Addr.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown_S_Addr.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left
        Me.NumericUpDown_S_Addr.Value = New Decimal(New Integer() {182, 0, 0, 0})
        '
        'PICkitConnect
        '
        Me.PICkitConnect.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PICkitConnect.Location = New System.Drawing.Point(178, 14)
        Me.PICkitConnect.Name = "PICkitConnect"
        Me.PICkitConnect.Size = New System.Drawing.Size(113, 26)
        Me.PICkitConnect.TabIndex = 549
        Me.PICkitConnect.Text = "PICkit Connect"
        Me.PICkitConnect.UseVisualStyleBackColor = True
        '
        'RadioButton16
        '
        Me.RadioButton16.AutoCheck = False
        Me.RadioButton16.AutoSize = True
        Me.RadioButton16.BackColor = System.Drawing.Color.Transparent
        Me.RadioButton16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton16.Location = New System.Drawing.Point(93, 21)
        Me.RadioButton16.Name = "RadioButton16"
        Me.RadioButton16.Size = New System.Drawing.Size(79, 19)
        Me.RadioButton16.TabIndex = 548
        Me.RadioButton16.Text = "400 KHz"
        Me.RadioButton16.UseVisualStyleBackColor = False
        '
        'RadioButton17
        '
        Me.RadioButton17.AutoCheck = False
        Me.RadioButton17.AutoSize = True
        Me.RadioButton17.BackColor = System.Drawing.Color.Transparent
        Me.RadioButton17.Checked = True
        Me.RadioButton17.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton17.Location = New System.Drawing.Point(8, 21)
        Me.RadioButton17.Name = "RadioButton17"
        Me.RadioButton17.Size = New System.Drawing.Size(79, 19)
        Me.RadioButton17.TabIndex = 547
        Me.RadioButton17.TabStop = True
        Me.RadioButton17.Text = "100 KHz"
        Me.RadioButton17.UseVisualStyleBackColor = False
        '
        'GroupBox17
        '
        Me.GroupBox17.Controls.Add(Me.RichTextBox1)
        Me.GroupBox17.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox17.Location = New System.Drawing.Point(12, 518)
        Me.GroupBox17.Name = "GroupBox17"
        Me.GroupBox17.Size = New System.Drawing.Size(1197, 117)
        Me.GroupBox17.TabIndex = 560
        Me.GroupBox17.TabStop = False
        Me.GroupBox17.Text = "Application Log"
        '
        'RichTextBox1
        '
        Me.RichTextBox1.AcceptsTab = True
        Me.RichTextBox1.AutoWordSelection = True
        Me.RichTextBox1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.RichTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.RichTextBox1.EnableAutoDragDrop = True
        Me.RichTextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox1.HideSelection = False
        Me.RichTextBox1.Location = New System.Drawing.Point(3, 15)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.ReadOnly = True
        Me.RichTextBox1.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical
        Me.RichTextBox1.Size = New System.Drawing.Size(1188, 93)
        Me.RichTextBox1.TabIndex = 537
        Me.RichTextBox1.Text = "Here"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Window
        Me.ClientSize = New System.Drawing.Size(1370, 684)
        Me.Controls.Add(Me.GroupBox17)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.Test)
        Me.Controls.Add(Me.RadioButton9)
        Me.Controls.Add(Me.RadioButton10)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.GroupBox12)
        Me.Controls.Add(Me.RadioButton11)
        Me.Controls.Add(Me.TabControl1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "PMBUS - CIPS LiteOn V0.0"
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.Tab_Read.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        CType(Me.NumericUpDown21, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControl1.ResumeLayout(False)
        Me.Tab_MFR.ResumeLayout(False)
        CType(Me.DataGridView_MFR, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Tab_Constant.ResumeLayout(False)
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Tab_Status.ResumeLayout(False)
        Me.Tab_Status.PerformLayout()
        Me.GroupBox10.ResumeLayout(False)
        Me.GroupBox10.PerformLayout()
        CType(Me.NumericUpDown_cmd_r, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_page, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox65, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox66, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox67, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox68, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox69, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox70, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox71, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox72, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox73, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox74, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox75, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox76, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox77, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox78, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox79, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox80, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox81, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox82, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox83, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox84, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox85, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox86, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox87, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox88, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox89, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox90, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox91, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox92, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox93, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox94, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox95, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox96, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox97, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox_Busy, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox99, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox100, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox101, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox102, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox103, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox104, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox105, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox106, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox107, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox108, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox109, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox110, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox111, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox112, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox113, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox_OFF, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox115, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox116, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox117, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox118, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox119, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox120, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox121, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox122, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox123, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox124, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox125, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox126, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox127, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox128, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox129, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox_VOUT_OV, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox131, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox132, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox133, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox134, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox135, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox136, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox137, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox138, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox139, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox140, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox141, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox142, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox_IOUT_OC, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox144, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Tab_Control.ResumeLayout(False)
        Me.GroupBox18.ResumeLayout(False)
        Me.GroupBox14.ResumeLayout(False)
        Me.GroupBox14.PerformLayout()
        CType(Me.NumericUpDown_Set_Warn, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_SET_IOUT_F, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_SET_Vbulk, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_SET_Duty, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        CType(Me.NumericUpDown23, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown24, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Tab_Calibration.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox20.ResumeLayout(False)
        Me.GroupBox_1.ResumeLayout(False)
        Me.GroupBox_1.PerformLayout()
        Me.GroupBox_2.ResumeLayout(False)
        Me.GroupBox_2.PerformLayout()
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox15.ResumeLayout(False)
        Me.GroupBox15.PerformLayout()
        Me.GroupBox13.ResumeLayout(False)
        Me.GroupBox13.PerformLayout()
        Me.Tab_Log.ResumeLayout(False)
        CType(Me.DataGridView_LOG, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Tab_FRU.ResumeLayout(False)
        Me.GroupBox19.ResumeLayout(False)
        Me.GroupBox16.ResumeLayout(False)
        Me.GroupBox16.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        CType(Me.DataGridView_ee, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Tab_Statistics.ResumeLayout(False)
        CType(Me.Chart1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Tab_About.ResumeLayout(False)
        Me.Tag_Help.ResumeLayout(False)
        Me.GroupBox12.ResumeLayout(False)
        Me.GroupBox12.PerformLayout()
        CType(Me.NumericUpDown14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown18, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_r_b, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_w_index, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.NumericUpDown_EEPROM_Addr, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_S_Addr, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox17.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents SaveFileDialog2 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents RadioButton9 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton10 As System.Windows.Forms.RadioButton
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripProgressBar1 As System.Windows.Forms.ToolStripProgressBar
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents RadioButton11 As System.Windows.Forms.RadioButton
    Friend WithEvents Tab_Read As System.Windows.Forms.TabPage
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Cmd As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn18 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn19 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn21 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents Test As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Poll As Button
    Friend WithEvents ReadOnce As Button
    Friend WithEvents Tab_MFR As TabPage
    Friend WithEvents Tab_Calibration As TabPage
    Friend WithEvents Tab_Constant As TabPage
    Friend WithEvents Tab_Status As TabPage
    Friend WithEvents Tab_Control As TabPage
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents Label232 As Label
    Friend WithEvents Label230 As Label
    Friend WithEvents Label90 As Label
    Friend WithEvents Label83 As Label
    Friend WithEvents Label81 As Label
    Friend WithEvents Label222 As Label
    Friend WithEvents Label220 As Label
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents Label348 As Label
    Friend WithEvents Button_Status_VOUT As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents NumericUpDown21 As NumericUpDown
    Friend WithEvents Label275 As Label
    Friend WithEvents Label327 As Label
    Friend WithEvents Label272 As Label
    Friend WithEvents Label269 As Label
    Friend WithEvents Button103 As Button
    Friend WithEvents Label268 As Label
    Friend WithEvents Button104 As Button
    Friend WithEvents Label264 As Label
    Friend WithEvents CheckBox6 As CheckBox
    Friend WithEvents Label252 As Label
    Friend WithEvents CheckBox7 As CheckBox
    Friend WithEvents Label246 As Label
    Friend WithEvents CheckBox8 As CheckBox
    Friend WithEvents TextBox89 As TextBox
    Friend WithEvents CheckBox9 As CheckBox
    Friend WithEvents TextBox27 As TextBox
    Friend WithEvents CheckBox10 As CheckBox
    Friend WithEvents CheckBox20 As CheckBox
    Friend WithEvents CheckBox11 As CheckBox
    Friend WithEvents CheckBox19 As CheckBox
    Friend WithEvents CheckBox12 As CheckBox
    Friend WithEvents CheckBox18 As CheckBox
    Friend WithEvents CheckBox69 As CheckBox
    Friend WithEvents CheckBox17 As CheckBox
    Friend WithEvents TextBox31 As TextBox
    Friend WithEvents CheckBox16 As CheckBox
    Friend WithEvents TextBox84 As TextBox
    Friend WithEvents CheckBox15 As CheckBox
    Friend WithEvents Label347 As Label
    Friend WithEvents CheckBox14 As CheckBox
    Friend WithEvents CheckBox13 As CheckBox
    Friend WithEvents TextBox26 As TextBox
    Friend WithEvents TextBox23 As TextBox
    Friend WithEvents Label131 As Label
    Friend WithEvents CheckBox28 As CheckBox
    Friend WithEvents Label279 As Label
    Friend WithEvents CheckBox27 As CheckBox
    Friend WithEvents Label277 As Label
    Friend WithEvents CheckBox26 As CheckBox
    Friend WithEvents Label276 As Label
    Friend WithEvents CheckBox25 As CheckBox
    Friend WithEvents CheckBox24 As CheckBox
    Friend WithEvents Button101 As Button
    Friend WithEvents CheckBox23 As CheckBox
    Friend WithEvents Button102 As Button
    Friend WithEvents CheckBox22 As CheckBox
    Friend WithEvents Button99 As Button
    Friend WithEvents CheckBox21 As CheckBox
    Friend WithEvents Button100 As Button
    Friend WithEvents TextBox22 As TextBox
    Friend WithEvents Button97 As Button
    Friend WithEvents TextBox21 As TextBox
    Friend WithEvents Button98 As Button
    Friend WithEvents CheckBox36 As CheckBox
    Friend WithEvents Button95 As Button
    Friend WithEvents CheckBox35 As CheckBox
    Friend WithEvents Button96 As Button
    Friend WithEvents CheckBox34 As CheckBox
    Friend WithEvents Button91 As Button
    Friend WithEvents CheckBox33 As CheckBox
    Friend WithEvents Button92 As Button
    Friend WithEvents CheckBox32 As CheckBox
    Friend WithEvents Button89 As Button
    Friend WithEvents CheckBox31 As CheckBox
    Friend WithEvents Button90 As Button
    Friend WithEvents CheckBox30 As CheckBox
    Friend WithEvents Label76 As Label
    Friend WithEvents CheckBox29 As CheckBox
    Friend WithEvents Label77 As Label
    Friend WithEvents TextBox20 As TextBox
    Friend WithEvents Label79 As Label
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents Label80 As Label
    Friend WithEvents CheckBox44 As CheckBox
    Friend WithEvents Label89 As Label
    Friend WithEvents CheckBox43 As CheckBox
    Friend WithEvents CheckBox42 As CheckBox
    Friend WithEvents CheckBox41 As CheckBox
    Friend WithEvents CheckBox40 As CheckBox
    Friend WithEvents Label95 As Label
    Friend WithEvents CheckBox39 As CheckBox
    Friend WithEvents Label125 As Label
    Friend WithEvents CheckBox38 As CheckBox
    Friend WithEvents Label127 As Label
    Friend WithEvents CheckBox37 As CheckBox
    Friend WithEvents Label134 As Label
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents Label135 As Label
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents CheckBox61 As CheckBox
    Friend WithEvents CheckBox52 As CheckBox
    Friend WithEvents CheckBox62 As CheckBox
    Friend WithEvents CheckBox51 As CheckBox
    Friend WithEvents CheckBox63 As CheckBox
    Friend WithEvents CheckBox50 As CheckBox
    Friend WithEvents CheckBox64 As CheckBox
    Friend WithEvents CheckBox49 As CheckBox
    Friend WithEvents CheckBox65 As CheckBox
    Friend WithEvents CheckBox48 As CheckBox
    Friend WithEvents CheckBox66 As CheckBox
    Friend WithEvents CheckBox47 As CheckBox
    Friend WithEvents CheckBox67 As CheckBox
    Friend WithEvents CheckBox46 As CheckBox
    Friend WithEvents CheckBox68 As CheckBox
    Friend WithEvents CheckBox45 As CheckBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents CheckBox53 As CheckBox
    Friend WithEvents CheckBox60 As CheckBox
    Friend WithEvents CheckBox54 As CheckBox
    Friend WithEvents CheckBox59 As CheckBox
    Friend WithEvents CheckBox55 As CheckBox
    Friend WithEvents CheckBox58 As CheckBox
    Friend WithEvents CheckBox56 As CheckBox
    Friend WithEvents CheckBox57 As CheckBox
    Friend WithEvents Button_MFR_Read As Button
    Friend WithEvents DataGridView_MFR As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents Tab_Log As TabPage
    Friend WithEvents Tab_FRU As TabPage
    Friend WithEvents DataGridView2 As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn14 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn15 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridView_LOG As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn16 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn17 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn20 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn22 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn23 As DataGridViewTextBoxColumn
    Friend WithEvents Button13 As Button
    Friend WithEvents Button_LogRead As Button
    Friend WithEvents GroupBox6 As GroupBox
    Friend WithEvents Label405 As Label
    Friend WithEvents Label406 As Label
    Friend WithEvents Label407 As Label
    Friend WithEvents Label408 As Label
    Friend WithEvents Label409 As Label
    Friend WithEvents Label410 As Label
    Friend WithEvents Label411 As Label
    Friend WithEvents Label412 As Label
    Friend WithEvents Label413 As Label
    Friend WithEvents Label414 As Label
    Friend WithEvents Label415 As Label
    Friend WithEvents PictureBox65 As PictureBox
    Friend WithEvents PictureBox66 As PictureBox
    Friend WithEvents PictureBox67 As PictureBox
    Friend WithEvents PictureBox68 As PictureBox
    Friend WithEvents PictureBox69 As PictureBox
    Friend WithEvents PictureBox70 As PictureBox
    Friend WithEvents PictureBox71 As PictureBox
    Friend WithEvents PictureBox72 As PictureBox
    Friend WithEvents Label416 As Label
    Friend WithEvents PictureBox73 As PictureBox
    Friend WithEvents PictureBox74 As PictureBox
    Friend WithEvents PictureBox75 As PictureBox
    Friend WithEvents PictureBox76 As PictureBox
    Friend WithEvents PictureBox77 As PictureBox
    Friend WithEvents PictureBox78 As PictureBox
    Friend WithEvents PictureBox79 As PictureBox
    Friend WithEvents PictureBox80 As PictureBox
    Friend WithEvents Label420 As Label
    Friend WithEvents Label421 As Label
    Friend WithEvents Label422 As Label
    Friend WithEvents Label423 As Label
    Friend WithEvents Label424 As Label
    Friend WithEvents Label425 As Label
    Friend WithEvents Label426 As Label
    Friend WithEvents Label427 As Label
    Friend WithEvents Label428 As Label
    Friend WithEvents Label429 As Label
    Friend WithEvents Label430 As Label
    Friend WithEvents Label431 As Label
    Friend WithEvents Label432 As Label
    Friend WithEvents Label433 As Label
    Friend WithEvents Label434 As Label
    Friend WithEvents Label435 As Label
    Friend WithEvents Label436 As Label
    Friend WithEvents Label437 As Label
    Friend WithEvents Label438 As Label
    Friend WithEvents Label439 As Label
    Friend WithEvents Label440 As Label
    Friend WithEvents Label441 As Label
    Friend WithEvents Label442 As Label
    Friend WithEvents Label443 As Label
    Friend WithEvents Label444 As Label
    Friend WithEvents Label445 As Label
    Friend WithEvents Label446 As Label
    Friend WithEvents Label447 As Label
    Friend WithEvents Label448 As Label
    Friend WithEvents Label449 As Label
    Friend WithEvents Label450 As Label
    Friend WithEvents Label451 As Label
    Friend WithEvents Label452 As Label
    Friend WithEvents Label453 As Label
    Friend WithEvents Label454 As Label
    Friend WithEvents Label455 As Label
    Friend WithEvents Label456 As Label
    Friend WithEvents PictureBox81 As PictureBox
    Friend WithEvents PictureBox82 As PictureBox
    Friend WithEvents PictureBox83 As PictureBox
    Friend WithEvents PictureBox84 As PictureBox
    Friend WithEvents PictureBox85 As PictureBox
    Friend WithEvents PictureBox86 As PictureBox
    Friend WithEvents PictureBox87 As PictureBox
    Friend WithEvents PictureBox88 As PictureBox
    Friend WithEvents PictureBox89 As PictureBox
    Friend WithEvents PictureBox90 As PictureBox
    Friend WithEvents PictureBox91 As PictureBox
    Friend WithEvents PictureBox92 As PictureBox
    Friend WithEvents PictureBox93 As PictureBox
    Friend WithEvents PictureBox94 As PictureBox
    Friend WithEvents PictureBox95 As PictureBox
    Friend WithEvents PictureBox96 As PictureBox
    Friend WithEvents PictureBox97 As PictureBox
    Friend WithEvents PictureBox_Busy As PictureBox
    Friend WithEvents PictureBox99 As PictureBox
    Friend WithEvents PictureBox100 As PictureBox
    Friend WithEvents PictureBox101 As PictureBox
    Friend WithEvents PictureBox102 As PictureBox
    Friend WithEvents PictureBox103 As PictureBox
    Friend WithEvents PictureBox104 As PictureBox
    Friend WithEvents PictureBox105 As PictureBox
    Friend WithEvents PictureBox106 As PictureBox
    Friend WithEvents PictureBox107 As PictureBox
    Friend WithEvents PictureBox108 As PictureBox
    Friend WithEvents PictureBox109 As PictureBox
    Friend WithEvents PictureBox110 As PictureBox
    Friend WithEvents PictureBox111 As PictureBox
    Friend WithEvents PictureBox112 As PictureBox
    Friend WithEvents PictureBox113 As PictureBox
    Friend WithEvents PictureBox_OFF As PictureBox
    Friend WithEvents PictureBox115 As PictureBox
    Friend WithEvents PictureBox116 As PictureBox
    Friend WithEvents PictureBox117 As PictureBox
    Friend WithEvents PictureBox118 As PictureBox
    Friend WithEvents PictureBox119 As PictureBox
    Friend WithEvents PictureBox120 As PictureBox
    Friend WithEvents PictureBox121 As PictureBox
    Friend WithEvents PictureBox122 As PictureBox
    Friend WithEvents PictureBox123 As PictureBox
    Friend WithEvents PictureBox124 As PictureBox
    Friend WithEvents PictureBox125 As PictureBox
    Friend WithEvents PictureBox126 As PictureBox
    Friend WithEvents PictureBox127 As PictureBox
    Friend WithEvents PictureBox128 As PictureBox
    Friend WithEvents PictureBox129 As PictureBox
    Friend WithEvents PictureBox_VOUT_OV As PictureBox
    Friend WithEvents PictureBox131 As PictureBox
    Friend WithEvents PictureBox132 As PictureBox
    Friend WithEvents PictureBox133 As PictureBox
    Friend WithEvents PictureBox134 As PictureBox
    Friend WithEvents PictureBox135 As PictureBox
    Friend WithEvents PictureBox136 As PictureBox
    Friend WithEvents PictureBox137 As PictureBox
    Friend WithEvents PictureBox138 As PictureBox
    Friend WithEvents PictureBox139 As PictureBox
    Friend WithEvents PictureBox140 As PictureBox
    Friend WithEvents PictureBox141 As PictureBox
    Friend WithEvents PictureBox142 As PictureBox
    Friend WithEvents PictureBox_IOUT_OC As PictureBox
    Friend WithEvents PictureBox144 As PictureBox
    Friend WithEvents GroupBox7 As GroupBox
    Friend WithEvents Label465 As Label
    Friend WithEvents Label466 As Label
    Friend WithEvents Button32 As Button
    Friend WithEvents NumericUpDown23 As NumericUpDown
    Friend WithEvents TextBox47 As TextBox
    Friend WithEvents TextBox48 As TextBox
    Friend WithEvents Button33 As Button
    Friend WithEvents NumericUpDown24 As NumericUpDown
    Friend WithEvents GroupBox10 As GroupBox
    Friend WithEvents Label468 As Label
    Friend WithEvents Label467 As Label
    Friend WithEvents TextBox_status_Data As TextBox
    Friend WithEvents NumericUpDown_page As NumericUpDown
    Friend WithEvents Button_status_write As Button
    Friend WithEvents Button_Clear_Faults As Button
    Friend WithEvents TextBox_Status_Data_r As TextBox
    Friend WithEvents NumericUpDown_cmd_r As NumericUpDown
    Friend WithEvents Button_status_read As Button
    Friend WithEvents GroupBox13 As GroupBox
    Friend WithEvents Label462 As Label
    Friend WithEvents Button_Execute As Button
    Friend WithEvents GroupBox12 As GroupBox
    Friend WithEvents TextBox40 As TextBox
    Friend WithEvents TextBox41 As TextBox
    Friend WithEvents TextBox42 As TextBox
    Friend WithEvents TextBox43 As TextBox
    Friend WithEvents NumericUpDown14 As NumericUpDown
    Friend WithEvents NumericUpDown18 As NumericUpDown
    Friend WithEvents Label459 As Label
    Friend WithEvents Label460 As Label
    Friend WithEvents Button28 As Button
    Friend WithEvents NumericUpDown_r_b As NumericUpDown
    Friend WithEvents Button30 As Button
    Friend WithEvents NumericUpDown_w_index As NumericUpDown
    Friend WithEvents GroupBox14 As GroupBox
    Friend WithEvents Label457 As Label
    Friend WithEvents NumericUpDown_SET_Vbulk As NumericUpDown
    Friend WithEvents TextBox_GET_Vbulk As TextBox
    Friend WithEvents Button_GET_Vbulk As Button
    Friend WithEvents Button_SET_Vbulk As Button
    Friend WithEvents Label458 As Label
    Friend WithEvents TextBox_GET_Duty As TextBox
    Friend WithEvents NumericUpDown_SET_Duty As NumericUpDown
    Friend WithEvents Button_GET_Duty As Button
    Friend WithEvents Button_SET_Duty As Button
    Friend WithEvents Button_GET_IOUT_OC_Fault_Limit As Button
    Friend WithEvents TextBox_GET_OC_Fault_Limit As TextBox
    Friend WithEvents Button_SET_IOUT_OC_Fault As Button
    Friend WithEvents NumericUpDown_SET_IOUT_F As NumericUpDown
    Friend WithEvents Label27 As Label
    Friend WithEvents Button_IOUT_OC_Warn As Button
    Friend WithEvents TextBox_Set_Warn As TextBox
    Friend WithEvents Button_SET_IOUT_OC_WARN As Button
    Friend WithEvents NumericUpDown_Set_Warn As NumericUpDown
    Friend WithEvents Label30 As Label
    Friend WithEvents ListBox_Cmd As ListBox
    Friend WithEvents Label35 As Label
    Friend WithEvents ListBox_index As ListBox
    Friend WithEvents Button27 As Button
    Friend WithEvents GroupBox15 As GroupBox
    Friend WithEvents Button_S_Disable As Button
    Friend WithEvents Button_S_Enable As Button
    Friend WithEvents CheckBox5 As CheckBox
    Friend WithEvents RadioButton_Disable As RadioButton
    Friend WithEvents RadioButton_Enable As RadioButton
    Friend WithEvents GroupBox16 As GroupBox
    Friend WithEvents GroupBox18 As GroupBox
    Friend WithEvents Button_PSUOff As Button
    Friend WithEvents Button_PSUOn As Button
    Friend WithEvents Label38 As Label
    Friend WithEvents TextBox_Write_EE_Word_Addr As TextBox
    Friend WithEvents TextBox_Write_EE_Byte1 As TextBox
    Friend WithEvents Label44 As Label
    Friend WithEvents Label39 As Label
    Friend WithEvents TextBox_Write_EE_Byte2 As TextBox
    Friend WithEvents Tab_Statistics As TabPage
    Friend WithEvents GroupBox19 As GroupBox
    Friend WithEvents Button_Write_ee As Button
    Friend WithEvents Button_Clear_FRU As Button
    Friend WithEvents Button_FRU_File As Button
    Friend WithEvents BTN_FRU_Read As Button
    Friend WithEvents Label59 As Label
    Friend WithEvents Label57 As Label
    Friend WithEvents Label54 As Label
    Friend WithEvents Label62 As Label
    Friend WithEvents Label71 As Label
    Friend WithEvents Label65 As Label
    Friend WithEvents Label64 As Label
    Friend WithEvents Label63 As Label
    Friend WithEvents DataGridView_ee As DataGridView
    Friend WithEvents Button_Read_All As Button
    Friend WithEvents TextBox_Read_EE_Byte_Count As TextBox
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents Column5 As DataGridViewTextBoxColumn
    Friend WithEvents Column6 As DataGridViewTextBoxColumn
    Friend WithEvents Column7 As DataGridViewTextBoxColumn
    Friend WithEvents Column8 As DataGridViewTextBoxColumn
    Friend WithEvents Column9 As DataGridViewTextBoxColumn
    Friend WithEvents Column10 As DataGridViewTextBoxColumn
    Friend WithEvents Column11 As DataGridViewTextBoxColumn
    Friend WithEvents Column12 As DataGridViewTextBoxColumn
    Friend WithEvents Column13 As DataGridViewTextBoxColumn
    Friend WithEvents Column14 As DataGridViewTextBoxColumn
    Friend WithEvents Column15 As DataGridViewTextBoxColumn
    Friend WithEvents Column16 As DataGridViewTextBoxColumn
    Friend WithEvents Column17 As DataGridViewTextBoxColumn
    Friend WithEvents Button_Write_Page As Button
    Friend WithEvents Label47 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents GroupBox20 As GroupBox
    Friend WithEvents Button_Read_Adc As Button
    Friend WithEvents ListBox_adc As ListBox
    Friend WithEvents Button_Cab_Read As Button
    Friend WithEvents Tab_About As TabPage
    Friend WithEvents Tag_Help As TabPage
    Friend WithEvents GroupBox17 As GroupBox
    Friend WithEvents RichTextBox1 As RichTextBox
    Friend WithEvents RichTextBox2 As RichTextBox
    Friend WithEvents Chart1 As DataVisualization.Charting.Chart
    Friend WithEvents RichTextBox3 As RichTextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents Label29 As Label
    Friend WithEvents NumericUpDown7 As NumericUpDown
    Friend WithEvents NumericUpDown_S_Addr As NumericUpDown
    Friend WithEvents PICkitConnect As Button
    Friend WithEvents RadioButton16 As RadioButton
    Friend WithEvents RadioButton17 As RadioButton
    Friend WithEvents CheckBox2 As CheckBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents TextBox_offset1 As TextBox
    Friend WithEvents TextBox_G1 As TextBox
    Friend WithEvents Button_calculate As Button
    Friend WithEvents TextBox_G0 As TextBox
    Friend WithEvents TextBox_offset0 As TextBox
    Friend WithEvents Label464 As Label
    Friend WithEvents GroupBox9 As GroupBox
    Friend WithEvents Button_Disable_Factory_Mode As Button
    Friend WithEvents MFR_EN As Button
    Friend WithEvents RadioButton_s As RadioButton
    Friend WithEvents RadioButton_p As RadioButton
    Friend WithEvents GroupBox_1 As GroupBox
    Friend WithEvents Label461 As Label
    Friend WithEvents TextBox_input_1 As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents TextBox_Raw_ADC As TextBox
    Friend WithEvents GroupBox_2 As GroupBox
    Friend WithEvents Label7 As Label
    Friend WithEvents TextBox_input_2 As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents TextBox_RAW_ADC_2 As TextBox
    Friend WithEvents Label37 As Label
    Friend WithEvents NumericUpDown_EEPROM_Addr As NumericUpDown
End Class
