﻿
Option Strict Off
Option Explicit On
Module Win_I2C_Module
    Declare Function Enable3VOutputPower Lib "WinI2CUSBpro.dll" (ByVal State As Boolean) As Boolean
    Declare Function Enable5VOutputPower Lib "WinI2CUSBpro.dll" (ByVal State As Boolean) As Boolean
    Declare Function GetFirmwareRevision Lib "WinI2CUSBpro.dll" () As Byte
    Declare Function GetHardwareInfo Lib "WinI2CUSBpro.dll" (ByRef Data As Byte) As Integer
    Declare Function GetNumberOfDevices Lib "WinI2CUSBpro.dll" () As Integer
    Declare Function GetSerialNumbers Lib "WinI2CUSBpro.dll" (ByRef SerialNumbers As Integer) As Integer
    Declare Function SelectBySerialNumber Lib "WinI2CUSBpro.dll" (ByVal dwDeviceNum As Integer) As Integer
    Declare Sub ShutdownProcedure Lib "WinI2CUSBpro.dll" ()
    Declare Function Read_IO Lib "WinI2CUSBpro.dll" () As Integer
    Declare Function Write_IO Lib "WinI2CUSBpro.dll" (ByVal OutputState As Integer) As Integer
    ' Declare Function Disable_SPI Lib "WinI2CUSBpro.dll" () As Integer
    Declare Function Enable_SPI Lib "WinI2CUSBpro.dll" () As Integer
    Declare Function Configure_SPI_GPIO Lib "WinI2CUSBpro.dll" (ByVal GPIODirection As Byte) As Byte
    Declare Function GPIO_SPI_Write Lib "WinI2CUSBpro.dll" (ByVal GPIO_Data As Byte) As Integer
    Declare Function GPIO_SPI_Read Lib "WinI2CUSBpro.dll" () As Byte
    Declare Function Enable_I2C Lib "WinI2CUSBpro.dll" () As Integer
    Declare Function Disable_I2C Lib "WinI2CUSBpro.dll" () As Integer
    Declare Function GPIO_I2C_Write Lib "WinI2CUSBpro.dll" (ByVal GPIO_Data As Byte) As Integer
    Declare Function GPIO_I2C_Read Lib "WinI2CUSBpro.dll" () As Byte
    Declare Function Get_DLL_Version Lib "WinI2CUSBpro.dll" () As Long

    Declare Function GetI2CFrequency Lib "WinI2CUSBpro.dll" () As Integer
    Declare Function I2CRead Lib "WinI2CUSBpro.dll" (ByVal address As Byte, ByVal nBytes As Short, ByRef ReadData As Byte, ByVal SendStop As Boolean) As Byte
    Declare Function I2C10ReadArray Lib "WinI2CUSBpro.dll" (ByVal address As Short, ByVal Subaddress As Byte, ByVal nBytes As Short, ByRef ReadData As Byte) As Byte
    Declare Function I2C10WriteArray Lib "WinI2CUSBpro.dll" (ByVal address As Short, ByVal Subaddress As Byte, ByVal nBytes As Short, ByRef WriteData As Byte) As Byte
    Declare Function I2CReadArray Lib "WinI2CUSBpro.dll" (ByVal address As Byte, ByVal Subaddress As Byte, ByVal nBytes As Short, ByRef ReadData As Byte) As Byte
    Declare Function I2CReadByte Lib "WinI2CUSBpro.dll" (ByVal address As Byte, ByVal Subaddress As Byte, ByRef ReadData As Byte) As Byte
    Declare Function I2CReceiveByte Lib "WinI2CUSBpro.dll" (ByVal address As Byte, ByRef ReadByte As Byte) As Byte
    Declare Function I2CSendByte Lib "WinI2CUSBpro.dll" (ByVal address As Byte, ByVal DataByte As Byte) As Byte
    Declare Function I2CWrite Lib "WinI2CUSBpro.dll" (ByVal address As Byte, ByVal nBytes As Short, ByRef WriteData As Byte, ByVal SendStop As Boolean) As Byte
    Declare Function I2CWriteArray Lib "WinI2CUSBpro.dll" (ByVal address As Byte, ByVal Subaddress As Byte, ByVal nBytes As Short, ByRef WriteData As Byte) As Byte
    Declare Function I2CWriteByte Lib "WinI2CUSBpro.dll" (ByVal address As Byte, ByVal Subaddress As Byte, ByVal Data As Byte) As Byte
    Declare Function I2CWriteRepWrite Lib "WinI2CUSBpro.dll" (ByVal address0 As Byte, ByVal nBytes0 As Short, ByRef WriteData0 As Byte, ByVal address1 As Byte, ByVal nBytes1 As Short, ByRef WriteData1 As Byte) As Byte
    Declare Function SetI2CFrequency Lib "WinI2CUSBpro.dll" (ByVal frequency As Integer) As Integer

    ' Declare Function SPI_Configure Lib "WinI2CUSBpro.dll" (ByVal SPI_Mode As Byte) As Byte
    ' Declare Function SPI_Generic Lib "WinI2CUSBpro.dll" (ByVal nBytes As Short, ByRef WriteData As Byte, ByRef ReadData As Byte) As Byte
    ' Declare Function SPI_SetFrequency Lib "WinI2CUSBpro.dll" (ByVal frequency As Integer) As Integer
    ' Declare Function SPI_Write Lib "WinI2CUSBpro.dll" (ByVal nBytes As Short, ByRef SPI_Data As Byte) As Byte
    ' Declare Function SPI_WriteRead Lib "WinI2CUSBpro.dll" (ByVal nBytesWrite As Short, ByVal nBytesRead As Short, ByRef WriteData As Byte, ByRef ReadData As Byte) As Byte
    ' Declare Function SPI_WriteWithOC Lib "WinI2CUSBpro.dll" (ByVal nBytes As Short, ByRef WriteData As Byte) As Byte
End Module
