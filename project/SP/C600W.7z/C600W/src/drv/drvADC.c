/*****************************************************************************************
 *
 *Copyright (C) 2021 CIPS Singapore

 *                   LITE-ON TECHNOLOGY Corp.
 *
 *All Rights Reserved
 *
 *File Name : Init.c
 *
 *Date : 2021.01.20
 *
 *Author :              Edwin
 *
 *Description :
 *
 *******************************************************************************************/

#include  "xc.h"
#include  "../Lib/p33Exxxx.h"
#include   "../Lib/p33EP64GS506.h"
#include "../h/drv/drvADC.h"
#include "../h/App/UserData.h"
#include "../h/Middle/Isr.h"
#include "../h/Middle/Sci.h"

#define PIN_PWM 1
extern tPS_FLAG PS;
extern SHORT gVoutCmd;

static void  adc_clk_Setup();
static void calibrateADC();
static void adc_resolution_Setup(void);
static void adc_triggle_Setup();
static void  adc_triggle_Setup();
 static void  adc_isr_Setup();
//------------------------------------ SetupClock ------------------------------------------------
/*
PLLFBD: PLL FEEDBACK DIVISOR REGISTER
PLLDIV<8:0>: PLL Feedback Divisor bits (also denoted as �??M�??, PLL multiplier)

bit 2-0               PCLKDIV<2:0>: PWM Input Clock Prescaler (Divider) Select bits
bit 7-6               PLLPOST<1:0>: PLL VCO Output Divider Select bits (also denoted as �??N2�??, PLL postscaler)

*/
 
 #ifdef notes
#define PERIOD_CONTROL_LOOP    898     /* Counter value for 15uS timer at 59.88125MHz fcl */  // 15uS
#define PERIOD_FAN_CAPTURE     14970   /* Setting of maximum capture time */            // 250uS  
#define PERIOD_MAIN_LOOP       5988    /* Counter value for 100uS timer at 59.88125MHz fcl */ // 100uS 5988
#endif

 

/*******************************************************************************
 * Function:        pwm1_fan_init
 * auther:          Edwin 
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     PWM FAN init
 * history:
 ******************************************************************************/

static void adc_averagingmode_Setup(void)
{
  /********************************************/
  /* Configure averaging mode for FB AD */
  ADFL0CONbits.OVRSAM = 0b010;  //15-bit result (12.3 format)
  ADCON4Lbits.SAMC1EN = 1;      //Core 1 delay enable
  ADCORE1Lbits.SAMC = 6;        //8 t_ADCORE
  ADFL0CONbits.FLCHSEL = 1;     //AN1
  ADFL0CONbits.MODE = 0b11;     //Averaging mode
  ADFL0CONbits.FLEN = 1;        //Enable filter

}


/*******************************************************************************
 * Name:                    Mcu_GPIOHwInit
 * Description:        
 * param[in]     -
 * param[in,out] -
 * param[out]  
 * return value:
 * author:                     Edwin                Edwin
 * Version:
 * Date:
 * History:
 *******************************************************************************/
void init_Timer ( void )
{  // clock :40Mhz
  //------ Timer1:1ms  ------
  PR1 = 40000; /* Period Register 1 40000/1000us=40/us */
  IEC0bits.T1IE = 1;
  T1CONbits.TON = 1;

  //------ Timer1:  20us for ADC  sample and conversion------
  PR2 = 800;
  T2CONbits.TON = 1;

  //------ Timer3: for Fan RPM   40Mhz  =25ns ------
  T3CONbits.TCKPS = 3;
  T3CONbits.TON = 1;

  //------ Timer4:8us for I2C write cmd------//8us = (8MHz*64*1)//16us = (8MHz*64*2)
  PR4 = 1;
  T4CON = 0;
  T4CONbits.TCKPS = 2;
  IPC6bits.T4IP = 4;
  IFS1bits.T4IF = 0;
  IEC1bits.T4IE = 1;
  T4CONbits.TON = 1;

  //------ Timer5:  100ms for I2C buffer cache issue 600khz?------
  PR5 = 15625;
  T5CONbits.TCKPS = 3;
  IPC7bits.T5IP = 3;
  IEC1bits.T5IE = 1;
  T5CONbits.TON = 1;
}
/*******************************************************************************
 * Function:        adc_resolution_Setup
 * auther:          Edwin 
 * Parameters:      -
 * Returned value:  -
 *
 * Description:    
 * history:
 ******************************************************************************/

static void adc_resolution_Setup(void)
{ 
  ADCON1Hbits.SHRRES = 3;        /* Shared ADC Core in 12-bit resolution mode */
  ADCORE0Hbits.RES = 3;             /* Core 0 ADC Core in 12-bit resolution mode */                                                          
  ADCORE1Hbits.RES = 3;              /* Core 1 ADC Core in 12-bit resolution mode */
  ADCORE2Hbits.RES = 3;              /* Core 2 ADC Core in 12-bit resolution mode */ 
  ADCORE3Hbits.RES = 3;              /* Core 3 ADC Core in 12-bit resolution mode */
  
  /* SHRSAMC= Shared ADC core sampling time selection bit 
    Specify the shared ADC core clock period within the shared ADC core sampling time*/
  ADCON2Hbits.SHRSAMC = 2;    /* Shared ADC Core sample time 4Tad */
}

/*******************************************************************************
 * Function:        pwm1_fan_init
 * auther:          Edwin 
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     PWM FAN init
 * history:
 ******************************************************************************/
static void adc_triggle_Setup()
{
    #define triggered_by_TIMER2 31
    #define triggered_by_TIMER1 12
           _TRGSRC0 = triggered_by_TIMER2;
           _TRGSRC1 = triggered_by_TIMER2;
           _TRGSRC2 = triggered_by_TIMER2;     
           _TRGSRC3 = triggered_by_TIMER2;
           _TRGSRC4 = triggered_by_TIMER2;
           _TRGSRC5 = triggered_by_TIMER2;
           _TRGSRC7 = triggered_by_TIMER2;
           _TRGSRC7 = triggered_by_TIMER2;
       /* ADC AN4 50V_OUT (after Oring)*/
	  _TRGSRC18 = triggered_by_TIMER2;
	 
}
/*******************************************************************************
 * Function:        pwm1_fan_init
 * auther:          Edwin 
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     PWM FAN init
 * history:
 ******************************************************************************/
static void adc_isr_Setup()
{
   IFS6bits.ADCAN0IF = 0;
  IPC27bits.ADCAN0IP= 5;
  IEC6bits.ADCAN0IE = 1;

  IFS6bits.ADCAN1IF = 0;
  IPC27bits.ADCAN1IP = 5;
  IEC6bits.ADCAN1IE = 1;
  IFS7bits.ADCAN2IF = 0;

  IPC28bits.ADCAN2IP = 3;
  IEC7bits.ADCAN2IE = 1;

  IFS7bits.ADCAN4IF = 0;
  IPC28bits.ADCAN4IP = 3;
  IEC7bits.ADCAN4IE = 1;

  IFS7bits.ADCAN5IF = 0;
  IPC28bits.ADCAN5IP = 5;
  IEC7bits.ADCAN5IE = 1;

  IFS7bits.ADCAN6IF = 0;
  IPC29bits.ADCAN6IP = 5;
  IEC7bits.ADCAN6IE = 1;

  IFS7bits.ADCAN7IF = 0;
  IPC29bits.ADCAN7IP = 5;
  IEC7bits.ADCAN7IE = 1;   
  
  _ADCAN10IF = 0;
  _ADCAN10IP = 5;
  _ADCAN10IE = 1;   
  
   _ADCAN11IF = 0;
  _ADCAN11IP = 5;
  _ADCAN11IE = 1;   
  
   _ADCAN13IF = 0;
  _ADCAN13IP = 5;
  _ADCAN13IE = 1;   
  
   _ADCAN14IF = 0;
  _ADCAN14IP = 5;
  _ADCAN14IE = 1;   
  
   _ADCAN19IF = 0;
  _ADCAN19IP = 5;
  _ADCAN19IE = 1;   


    
  /* Enable ADC Common Interrupt   and separate interrupt for each channel*/
   _IE0 = 1;
   _IE1 = 1;
   _IE2 = 1;
   _IE3 = 1;
   _IE4 = 1;
   _IE5 = 1;
   _IE6 = 1;
   _IE7 = 1;
   _IE10 = 1;
   _IE11 = 1;
   _IE13 = 1;
   _IE14 = 1;
   _IE19 = 1;
  
}

void init_ADC ( void )
{
   adc_clk_Setup();
   adc_resolution_Setup();
   adc_averagingmode_Setup();
   ADMOD0L = 0x0000;
   calibrateADC();
   adc_triggle_Setup();
   adc_isr_Setup();
  _ADON=1;   //ON
}

/*******************************************************************************
 * Function:     ADC Clock setup
 * auther:          Edwin 
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     ADC Clock setup
 * history:
 ******************************************************************************/
static void adc_clk_Setup(void )
{
#ifdef notes
    if ADRC==0; 
             ADC_Clock Cycle(TAD)= Tcy*(ADCS+1)
        if ADRC==1; 
             ADC_Clock Cycle(TAD)= T_ADRC
  ADRC=CLKSEL in 33EP506chipset                   
#endif                
 /* Setup ADC Clock Input Max speed of 60 MHz --> Fosc = 120 MHz */
  ADCON3Hbits.CLKSEL = 1;         /* 0-Fsys, 1-Fosc(system_clock * 2), 2-FRC, 3-APLL */
  ADCON3Hbits.CLKDIV = 0;        /* Global Clock divider (1:1) */
  ADCORE0Hbits.ADCS = 0;          /* Core 0 clock divider (1:2) */
  ADCORE1Hbits.ADCS = 0;            /* Core 1 clock divider (1:2) */
  ADCORE2Hbits.ADCS = 0;           /* Core 2 clock divider (1:2) */
  ADCORE3Hbits.ADCS = 0;            /* Core 3 clock divider (1:2) */
  ADCON2Lbits.SHRADCS = 0;      /* 1/2 clock divider */
  /* Integer format */
  ADCON1Hbits.FORM = 0;
  /* AVdd as voltage reference */
  ADCON3Lbits.REFSEL = 0;
}

/*******************************************************************************
 * \brief         configure the ADC's
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
static void calibrateADC()
{
  /*
   * Power Up delay: 2048 Core Clock Source Periods (TCORESRC) for all ADC cores
   * (~14.6 us)
   */
  _WARMTIME = 11;

  /* Turn on ADC module */
  ADCON1Lbits.ADON = 1;
  /* power-on delay time */
  ADCON5Hbits.WARMTIME = 11; 
  /* Turn on analog power for dedicated core 0 */
  ADCON5Lbits.C0PWR = 1;
  while (ADCON5Lbits.C0RDY == 0);
  /* Enable ADC core 0 */
  ADCON3Hbits.C0EN = 1;

  /* Turn on analog power for dedicated core 1 */
  ADCON5Lbits.C1PWR = 1;
  while (ADCON5Lbits.C1RDY == 0);
  /* Enable ADC core 1 */
  ADCON3Hbits.C1EN = 1;

  /* Turn on analog power for dedicated core 2 */
  ADCON5Lbits.C2PWR = 1;
  while (ADCON5Lbits.C2RDY == 0);
  /* Enable ADC core 2 */
  ADCON3Hbits.C2EN = 1;

  /* Turn on analog power for dedicated core 3 */
  ADCON5Lbits.C3PWR = 1;
  while (ADCON5Lbits.C3RDY == 0);
  /* Enable ADC core 3 */
  ADCON3Hbits.C3EN = 1;

  /* Turn on analog power for shared core */
  ADCON5Lbits.SHRPWR = 1;
  while (ADCON5Lbits.SHRRDY == 0);
  /* Enable shared ADC core */
  ADCON3Hbits.SHREN = 1;

  /* Enable calibration for the dedicated core 0 */
  ADCAL0Lbits.CAL0EN = 1;
  /* Single-ended input calibration */
  ADCAL0Lbits.CAL0DIFF = 0;
  /* Start Cal */
  ADCAL0Lbits.CAL0RUN = 1;
  while (ADCAL0Lbits.CAL0RDY == 0);
  /* Cal complete */
  ADCAL0Lbits.CAL0EN = 0;

  /* Enable calibration for the dedicated core 1 */
  ADCAL0Lbits.CAL1EN = 1;
  /* Single-ended input calibration */
  ADCAL0Lbits.CAL1DIFF = 0;
  /* Start Cal */
  ADCAL0Lbits.CAL1RUN = 1;
  while (ADCAL0Lbits.CAL1RDY == 0);
  /* Cal complete */
  ADCAL0Lbits.CAL1EN = 0;

  /* Enable calibration for the dedicated core 2 */
  ADCAL0Hbits.CAL2EN = 1;
  /* Single-ended input calibration */
  ADCAL0Hbits.CAL2DIFF = 0;
  /* Start Cal */
  ADCAL0Hbits.CAL2RUN = 1;
  while (ADCAL0Hbits.CAL2RDY == 0);
  /* Cal complete */
  ADCAL0Hbits.CAL2EN = 0;

  /* Enable calibration for the dedicated core 3 */
  ADCAL0Hbits.CAL3EN = 1;
  /* Single-ended input calibration */
  ADCAL0Hbits.CAL3DIFF = 0;
  /* Start Cal */
  ADCAL0Hbits.CAL3RUN = 1;
  while (ADCAL0Hbits.CAL3RDY == 0);
  /* Cal complete */
  ADCAL0Hbits.CAL3EN = 0;

  /* Enable calibration for the shared core */
  ADCAL1Hbits.CSHREN = 1;
  /* Single-ended input calibration */
  ADCAL1Hbits.CSHRDIFF = 0;
  /* Start calibration cycle */
  ADCAL1Hbits.CSHRRUN = 1;
  /* while calibration is still in progress */
  while (ADCAL1Hbits.CSHRRDY == 0);
  /* Calibration is complete */
  ADCAL1Hbits.CSHREN = 0;
}

