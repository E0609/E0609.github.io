/*****************************************************************************************
 *
 *Copyright (C) 2021 CIPS Singapore

 *                   LITE-ON TECHNOLOGY Corp.
 *
 *All Rights Reserved
 *
 *File Name : Init.c
 *
 *Date : 2021.01.20
 *
 *Author :              Edwin
 *
 *Description :
 *
 *******************************************************************************************/

#include  "xc.h"
#include  "p33Exxxx.h"
#include   "p33EP64GS506.h"
#include "define.h"
#include "Init.h"
#include "Userdata.h"
#include "Isr.h"
#include "Process.h"

#define PIN_PWM 1
extern tPS_FLAG PS;
extern SHORT gVoutCmd;

static void  adc_clk_Setup();
static void calibrateADC();
static void adc_resolution_Setup(void);
static void adc_triggle_Setup();
static void  adc_triggle_Setup();
 static void  adc_isr_Setup();
//------------------------------------ SetupClock ------------------------------------------------
/*
PLLFBD: PLL FEEDBACK DIVISOR REGISTER
PLLDIV<8:0>: PLL Feedback Divisor bits (also denoted as �??M�??, PLL multiplier)

bit 2-0               PCLKDIV<2:0>: PWM Input Clock Prescaler (Divider) Select bits
bit 7-6               PLLPOST<1:0>: PLL VCO Output Divider Select bits (also denoted as �??N2�??, PLL postscaler)

*/
 
 #ifdef notes
#define PERIOD_CONTROL_LOOP    898     /* Counter value for 15uS timer at 59.88125MHz fcl */  // 15uS
#define PERIOD_FAN_CAPTURE     14970   /* Setting of maximum capture time */            // 250uS  
#define PERIOD_MAIN_LOOP       5988    /* Counter value for 100uS timer at 59.88125MHz fcl */ // 100uS 5988
#endif

 
void init_SetupClock ( void )
{
#define FRC_OSC                                                       // if use internal FRC  osc
//#define FCY                    59881250                           /* FCY = FOSC/2 - freq in Hz*/ 
#define PWMCLOCKFREQ           943360000      //130426 117.92*8*1000000
    

#if defined(FRC_OSC)
/* Fast RC internal oscillator (FRC) w/PLL, start with FRC and then switch */
// FOSCSEL
#pragma config FNOSC = FRCPLL           // Oscillator Source Selection (Fast RC Oscillator with divide-by-N with PLL module (FRCPLL) )
#pragma config IESO = ON                        // Two-speed Oscillator Start-up Enable bit (Start up device with FRC, then switch to user-selected oscillator source)
 
#elif defined(PRIM_OSC)
/* Primary oscillator (XT, HS, EC) w/PLL, start with FRC and then switch */
// FOSCSEL
#pragma config FNOSC = PRIPLL           // Oscillator Source Selection (Fast RC Oscillator with divide-by-N with PLL module (FRCPLL) )
#pragma config IESO = ON                // Two-speed Oscillator Start-up Enable bit (Start up device with FRC, then switch to user-selected oscillator source)
#else
#error No oscillator type selected!
#endif
        
/* POR timer value (128ms) */
//_FPOR(FPWRT_PWR128)

/* Oscillator switch enable monitor disable, oscillator pin used as IO */
// FOSC
#pragma config OSCIOFNC = ON            // OSC2 Pin Function bit (OSC2 is general purpose digital I/O pin)
#pragma config FCKSM = CSECMD           /* Clock Switching Mode bits (Clock switching is enabled,
                                                                                                                                      Fail-safe Clock Monitor is disabled)*/

/* Watchdog disable */
// FWDT
#pragma config WDTPOST = PS1            // Watchdog Timer Postscaler bits (1:1)
#pragma config WDTPRE = PR128           // Watchdog Timer Prescaler bit (1:128)
#pragma config WDTEN = 0//SWDTEN           // Watchdog Timer Enable bits (WDT Enabled) //  128 * 1 / 32kHz = 4ms

#pragma config ICS = PGD1               // ICD Communication Channel Select bits (Communicate on PGEC1 and PGED1)
#pragma config JTAGEN = OFF             // JTAG Enable bit (JTAG is disabled)

// FDEVOPT
#pragma config PWMLOCK = OFF            // PWMx Lock Enable bit (PWM registers may be written without key sequence)
#pragma config ALTI2C1 = ON             // Alternate I2C1 Pin bit (I2C1 mapped to ASDA1/ASCL1 pins)
#pragma config ALTI2C2 = ON             // Alternate I2C2 Pin bit (I2C2 mapped to ASDA2/ASCL2 pins)

  PLLFBD = 41;    
  CLKDIVbits.PLLPOST = 0;        // PLLPOST (N1) 0=/2
  
  /*  __builtin_write_OSCCONH(0x01); >> now the PLL is configured.
  set the value for {COSC, NOSC} with this function to switch to FRC with PLL*/
  
  __builtin_write_OSCCONH ( 0x01 );
  
/*__builtin_write_OSCCONL(0x01);   >>  // Tell the CPU to perform the clock switch.*/
  
  __builtin_write_OSCCONL ( 0x01 );
  while ( OSCCONbits.COSC != 0b001 );
  while ( OSCCONbits.LOCK != 1 );
  ACLKCON = 0xA740;		  //     devided by 32              
  while ( ACLKCONbits.APLLCK != 1 );  // waiting for lock status
}


/*******************************************************************************
 * Function:        pwm1_fan_init
 * auther:          Edwin 
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     PWM FAN init
 * history:
 ******************************************************************************/

static void adc_averagingmode_Setup(void)
{
  /********************************************/
  /* Configure averaging mode for FB AD */
  ADFL0CONbits.OVRSAM = 0b010;  //15-bit result (12.3 format)
  ADCON4Lbits.SAMC1EN = 1;      //Core 1 delay enable
  ADCORE1Lbits.SAMC = 6;        //8 t_ADCORE
  ADFL0CONbits.FLCHSEL = 1;     //AN1
  ADFL0CONbits.MODE = 0b11;     //Averaging mode
  ADFL0CONbits.FLEN = 1;        //Enable filter

}

/*******************************************************************************
 * Name:                    Mcu_GPIOHwInit
 * Description:        
 * param[in]     -
 * param[in,out] -
 * param[out]  
 * return value:
 * author:                     Edwin                Edwin
 * Version:
 * Date:
 * History:
 *******************************************************************************/
static void port_IO_config()
{  // ODCx=Open-drain control register;1=5V open-drain ; 0=default 3v3 push-pull
    LATB = 0x0000;
    TRISB= 0xffff;   
    ANSELB = 0x0000;
    LATC = 0x0000;
    TRISC = 0xffff;   
    ANSELC = 0x0000;
      LATD = 0x0000;
    TRISD = 0xffff;   
    ANSELD = 0x0000;
 // INPUT
  /* PIN 35,34,33 for I2C Address selection*/
   _TRISC2 = MG_PIN_INPUT_DIRECTION;
   _TRISC14 = MG_PIN_INPUT_DIRECTION;
  _TRISB4 = MG_PIN_INPUT_DIRECTION;
   _TRISC4 = MG_PIN_INPUT_DIRECTION;     /* PIN 4 for PFC_OK_SEC*/
     _TRISC5 = MG_PIN_INPUT_DIRECTION;   /* PIN 51 for  AC_OK_SEC*/
  _TRISD0 = MG_PIN_INPUT_DIRECTION;     /* PIN 50 for  PS_ON_SEC*/
  // BUS
  _TRISC7 = MG_PIN_INPUT_DIRECTION;     /* PMBUS_SDA Pin36 */
  _TRISC8 = MG_PIN_INPUT_DIRECTION;     /* PMBUS_SCL Pin37 */
  _ODCC8 = 1;     // ODCx=Open-drain control register;1=5V open-drain ; 0=default 3v3 push-pull
  _ODCC7 = 1; 
 _TRISB8 = MG_PIN_INPUT_DIRECTION;          /* UART_RX Pin27 */
_TRISB15 = MG_PIN_OUTPUT_DIRECTION;     /* UART_TX Pin28 */
  _ODCB8= 1;   
  _ODCB15 = 1; 
  
// OUTOUT
   _TRISC0 = MG_PIN_OUTPUT_DIRECTION;    /* PIN 4  LED1*/
   _TRISC13 = MG_PIN_OUTPUT_DIRECTION;   /* PIN 5 for SR_DIS*/
   _TRISD12 = MG_PIN_OUTPUT_DIRECTION;   /* PIN 8 for ishare_DIS*/
   _TRISD7 = MG_PIN_OUTPUT_DIRECTION;    /* PIN 21 for oring _en*/
   _TRISD2 = MG_PIN_OUTPUT_DIRECTION;   /* PIN 30 for POK*/
   _TRISD9= MG_PIN_OUTPUT_DIRECTION;    /* PIN 40 for STB_EN*/
   _TRISD5 = MG_PIN_OUTPUT_DIRECTION;   /* PIN 53 for PFC*/
   _TRISD4 = MG_PIN_OUTPUT_DIRECTION;   /* PIN 58 for FAN*/
   _TRISD1 = MG_PIN_OUTPUT_DIRECTION;    /* PIN 64 for LLC_DIS*/
}
/*******************************************************************************
 * Name:                    uart Remap Pin
 * Description:        
 * param[in]     -
 * param[in,out] -
 * param[out]  
 * return value:
 * author:                     Edwin                
 * Version:
 * Date:
 * History:
 *******************************************************************************/
//static
void Mcu_uart_RemapPinInit(void)
{
  __builtin_write_OSCCONL(OSCCON & 0xbf);     /* Unlock register for remap pin configuration */
  _U1RXR = 40;                                                                /* Assign U1Rx to pin RP40/pin 43 */ 
  _RP47R= 1;                                                                    /* Assign U1Tx to pin RP47/ pin 44 */
  __builtin_write_OSCCONL(OSCCON | 0x40);      /* Lock register */
}

static void init_CMP()
{
#if cips // no comparater
    /* ~~~~~~~~~~~~~~~~~~~~~~~~ CMP1C Configuration ~~~~~~~~~~~~~~~~~~~~~~~~~~ */
    CMP1CONbits.INSEL = 2;               /* Select CMP1C input  PIN23, 12_OUT_MCU*/
    CMP1CONbits.EXTREF = 0;              /* Choose internal reference AVDD */
    CMP1CONbits.RANGE = 1;               /* Max DAC voltage = AVdd */
    
    CMP1DAC = 0x03FF;                    /* Choose comparator reference voltage 0x01FF = AVdd/4 ,AVdd/2 =0x03FF */
    
    // Select comparator hysteresis
   CMP1CONbits.HYSSEL = 3;   // 45 mV hysteresis selected
   CMP1CONbits.HYSPOL = 0;   // Hysteresis is applied to rising edge of the
// comparator output
    CMP1CONbits.CMPON = 1;               /* CMP1 enabled */
#endif
}
/*******************************************************************************
 * Name:                    init GPIO
 * Description:        
 * param[in]     -
 * param[in,out] -
 * param[out]  
 * return value:
 * author:                     Edwin                
 * Version:
 * Date:
 * History:
 *******************************************************************************/
void init_GPIO ( void )
{
     port_IO_config();
     Mcu_uart_RemapPinInit();    
     pin_o_LED_ON = LED_OFF;
     init_CMP();
#if PSON_ENABLE
#else
     _SD_Flag.PS_ON_OFF = TRUE;
#endif

#if RS_ENABLE   
      pin_o_ORING_EN_MCU  = RS_OFF;
#endif
}

/*******************************************************************************
 * Name:                    Mcu_GPIOHwInit
 * Description:        
 * param[in]     -
 * param[in,out] -
 * param[out]  
 * return value:
 * author:                     Edwin                Edwin
 * Version:
 * Date:
 * History:
 *******************************************************************************/
void init_Timer ( void )
{  // clock :40Mhz
  //------ Timer1:1ms  ------
  PR1 = 40000; /* Period Register 1 40000/1000us=40/us */
  IEC0bits.T1IE = 1;
  T1CONbits.TON = 1;

  //------ Timer1:  20us for ADC  sample and conversion------
  PR2 = 800;
  T2CONbits.TON = 1;

  //------ Timer3: for Fan RPM   40Mhz  =25ns ------
  T3CONbits.TCKPS = 3;
  T3CONbits.TON = 1;

  //------ Timer4:8us for I2C write cmd------//8us = (8MHz*64*1)//16us = (8MHz*64*2)
  PR4 = 1;
  T4CON = 0;
  T4CONbits.TCKPS = 2;
  IPC6bits.T4IP = 4;
  IFS1bits.T4IF = 0;
  IEC1bits.T4IE = 1;
  T4CONbits.TON = 1;

  //------ Timer5:  100ms for I2C buffer cache issue 600khz?------
  PR5 = 15625;
  T5CONbits.TCKPS = 3;
  IPC7bits.T5IP = 3;
  IEC1bits.T5IE = 1;
  T5CONbits.TON = 1;
}
/*******************************************************************************
 * Function:        adc_resolution_Setup
 * auther:          Edwin 
 * Parameters:      -
 * Returned value:  -
 *
 * Description:    
 * history:
 ******************************************************************************/

static void adc_resolution_Setup(void)
{ 
  ADCON1Hbits.SHRRES = 3;        /* Shared ADC Core in 12-bit resolution mode */
  ADCORE0Hbits.RES = 3;             /* Core 0 ADC Core in 12-bit resolution mode */                                                          
  ADCORE1Hbits.RES = 3;              /* Core 1 ADC Core in 12-bit resolution mode */
  ADCORE2Hbits.RES = 3;              /* Core 2 ADC Core in 12-bit resolution mode */ 
  ADCORE3Hbits.RES = 3;              /* Core 3 ADC Core in 12-bit resolution mode */
  
  /* SHRSAMC= Shared ADC core sampling time selection bit 
    Specify the shared ADC core clock period within the shared ADC core sampling time*/
  ADCON2Hbits.SHRSAMC = 2;    /* Shared ADC Core sample time 4Tad */
}

/*******************************************************************************
 * Function:        pwm1_fan_init
 * auther:          Edwin 
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     PWM FAN init
 * history:
 ******************************************************************************/
static void adc_triggle_Setup()
{
    #define triggered_by_TIMER2 31
    #define triggered_by_TIMER1 12
           _TRGSRC0 = triggered_by_TIMER2;
           _TRGSRC1 = triggered_by_TIMER2;
           _TRGSRC2 = triggered_by_TIMER2;     
           _TRGSRC3 = triggered_by_TIMER2;
           _TRGSRC4 = triggered_by_TIMER2;
           _TRGSRC5 = triggered_by_TIMER2;
           _TRGSRC7 = triggered_by_TIMER2;
           _TRGSRC7 = triggered_by_TIMER2;
       /* ADC AN4 50V_OUT (after Oring)*/
	  _TRGSRC18 = triggered_by_TIMER2;
	 
}
/*******************************************************************************
 * Function:        pwm1_fan_init
 * auther:          Edwin 
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     PWM FAN init
 * history:
 ******************************************************************************/
static void adc_isr_Setup()
{
   IFS6bits.ADCAN0IF = 0;
  IPC27bits.ADCAN0IP= 5;
  IEC6bits.ADCAN0IE = 1;

  IFS6bits.ADCAN1IF = 0;
  IPC27bits.ADCAN1IP = 5;
  IEC6bits.ADCAN1IE = 1;
  IFS7bits.ADCAN2IF = 0;

  IPC28bits.ADCAN2IP = 3;
  IEC7bits.ADCAN2IE = 1;

  IFS7bits.ADCAN4IF = 0;
  IPC28bits.ADCAN4IP = 3;
  IEC7bits.ADCAN4IE = 1;

  IFS7bits.ADCAN5IF = 0;
  IPC28bits.ADCAN5IP = 5;
  IEC7bits.ADCAN5IE = 1;

  IFS7bits.ADCAN6IF = 0;
  IPC29bits.ADCAN6IP = 5;
  IEC7bits.ADCAN6IE = 1;

  IFS7bits.ADCAN7IF = 0;
  IPC29bits.ADCAN7IP = 5;
  IEC7bits.ADCAN7IE = 1;   
  
  _ADCAN10IF = 0;
  _ADCAN10IP = 5;
  _ADCAN10IE = 1;   
  
   _ADCAN11IF = 0;
  _ADCAN11IP = 5;
  _ADCAN11IE = 1;   
  
   _ADCAN13IF = 0;
  _ADCAN13IP = 5;
  _ADCAN13IE = 1;   
  
   _ADCAN14IF = 0;
  _ADCAN14IP = 5;
  _ADCAN14IE = 1;   
  
   _ADCAN19IF = 0;
  _ADCAN19IP = 5;
  _ADCAN19IE = 1;   


    
  /* Enable ADC Common Interrupt   and separate interrupt for each channel*/
   _IE0 = 1;
   _IE1 = 1;
   _IE2 = 1;
   _IE3 = 1;
   
   _IE4 = 1;
   _IE5 = 1;
   _IE6 = 1;
   _IE7 = 1;
   
   _IE10 = 1;
   _IE11 = 1;
   _IE13 = 1;
   _IE14 = 1;
   _IE19 = 1;
  
}

void init_ADC ( void )
{
   adc_clk_Setup();
   adc_resolution_Setup();
   adc_averagingmode_Setup();
   ADMOD0L = 0x0000;
   calibrateADC();
   adc_triggle_Setup();
   adc_isr_Setup();
  _ADON=1;   //ON
}

/*******************************************************************************
 * Function:     ADC Clock setup
 * auther:          Edwin 
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     ADC Clock setup
 * history:
 ******************************************************************************/
static void adc_clk_Setup(void )
{
#ifdef notes
    if ADRC==0; 
             ADC_Clock Cycle(TAD)= Tcy*(ADCS+1)
        if ADRC==1; 
             ADC_Clock Cycle(TAD)= T_ADRC
  ADRC=CLKSEL in 33EP506chipset                   
#endif                
 /* Setup ADC Clock Input Max speed of 60 MHz --> Fosc = 120 MHz */
  ADCON3Hbits.CLKSEL = 1;         /* 0-Fsys, 1-Fosc(system_clock * 2), 2-FRC, 3-APLL */
  ADCON3Hbits.CLKDIV = 0;        /* Global Clock divider (1:1) */
  ADCORE0Hbits.ADCS = 0;          /* Core 0 clock divider (1:2) */
  ADCORE1Hbits.ADCS = 0;            /* Core 1 clock divider (1:2) */
  ADCORE2Hbits.ADCS = 0;           /* Core 2 clock divider (1:2) */
  ADCORE3Hbits.ADCS = 0;            /* Core 3 clock divider (1:2) */
  ADCON2Lbits.SHRADCS = 0;      /* 1/2 clock divider */
  /* Integer format */
  ADCON1Hbits.FORM = 0;
  /* AVdd as voltage reference */
  ADCON3Lbits.REFSEL = 0;
}

/*******************************************************************************
 * \brief         configure the ADC's
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
static void calibrateADC()
{
  /*
   * Power Up delay: 2048 Core Clock Source Periods (TCORESRC) for all ADC cores
   * (~14.6 us)
   */
  _WARMTIME = 11;

  /* Turn on ADC module */
  ADCON1Lbits.ADON = 1;
  /* power-on delay time */
  ADCON5Hbits.WARMTIME = 11; 
  /* Turn on analog power for dedicated core 0 */
  ADCON5Lbits.C0PWR = 1;
  while (ADCON5Lbits.C0RDY == 0);
  /* Enable ADC core 0 */
  ADCON3Hbits.C0EN = 1;

  /* Turn on analog power for dedicated core 1 */
  ADCON5Lbits.C1PWR = 1;
  while (ADCON5Lbits.C1RDY == 0);
  /* Enable ADC core 1 */
  ADCON3Hbits.C1EN = 1;

  /* Turn on analog power for dedicated core 2 */
  ADCON5Lbits.C2PWR = 1;
  while (ADCON5Lbits.C2RDY == 0);
  /* Enable ADC core 2 */
  ADCON3Hbits.C2EN = 1;

  /* Turn on analog power for dedicated core 3 */
  ADCON5Lbits.C3PWR = 1;
  while (ADCON5Lbits.C3RDY == 0);
  /* Enable ADC core 3 */
  ADCON3Hbits.C3EN = 1;

  /* Turn on analog power for shared core */
  ADCON5Lbits.SHRPWR = 1;
  while (ADCON5Lbits.SHRRDY == 0);
  /* Enable shared ADC core */
  ADCON3Hbits.SHREN = 1;

  /* Enable calibration for the dedicated core 0 */
  ADCAL0Lbits.CAL0EN = 1;
  /* Single-ended input calibration */
  ADCAL0Lbits.CAL0DIFF = 0;
  /* Start Cal */
  ADCAL0Lbits.CAL0RUN = 1;
  while (ADCAL0Lbits.CAL0RDY == 0);
  /* Cal complete */
  ADCAL0Lbits.CAL0EN = 0;

  /* Enable calibration for the dedicated core 1 */
  ADCAL0Lbits.CAL1EN = 1;
  /* Single-ended input calibration */
  ADCAL0Lbits.CAL1DIFF = 0;
  /* Start Cal */
  ADCAL0Lbits.CAL1RUN = 1;
  while (ADCAL0Lbits.CAL1RDY == 0);
  /* Cal complete */
  ADCAL0Lbits.CAL1EN = 0;

  /* Enable calibration for the dedicated core 2 */
  ADCAL0Hbits.CAL2EN = 1;
  /* Single-ended input calibration */
  ADCAL0Hbits.CAL2DIFF = 0;
  /* Start Cal */
  ADCAL0Hbits.CAL2RUN = 1;
  while (ADCAL0Hbits.CAL2RDY == 0);
  /* Cal complete */
  ADCAL0Hbits.CAL2EN = 0;

  /* Enable calibration for the dedicated core 3 */
  ADCAL0Hbits.CAL3EN = 1;
  /* Single-ended input calibration */
  ADCAL0Hbits.CAL3DIFF = 0;
  /* Start Cal */
  ADCAL0Hbits.CAL3RUN = 1;
  while (ADCAL0Hbits.CAL3RDY == 0);
  /* Cal complete */
  ADCAL0Hbits.CAL3EN = 0;

  /* Enable calibration for the shared core */
  ADCAL1Hbits.CSHREN = 1;
  /* Single-ended input calibration */
  ADCAL1Hbits.CSHRDIFF = 0;
  /* Start calibration cycle */
  ADCAL1Hbits.CSHRRUN = 1;
  /* while calibration is still in progress */
  while (ADCAL1Hbits.CSHRRDY == 0);
  /* Calibration is complete */
  ADCAL1Hbits.CSHREN = 0;
}


//------------------------------------ init_PWM ------------------------------------------------
/*******************************************************************************
 * Function:      init_PWM   
 * auther:          Edwin 
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     
 * history:
 ******************************************************************************/
/**
 *PWM1H	ISHARE_REF
PWM2L	FAN_PWM
PWM5H	LLC_G1
PWM5L	LLC_G2
PWM3H	SR_G1
PWM3L	SR_G2
 */

/*******************************************************************************
 * Function:      init_PWM   
 * auther:          Edwin 
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     
 * history:
 ******************************************************************************/
#ifdef notes // Independent time base = ITB
  if (CAM==1&& ITB==1) {
      PETER!= Cycle;
      CYCLE== PHASEx, SPHASEx:
               PHASEx, SPHASEx  = FOSC/(F_PWM* (PWM Input Clock Prescaler)*2)
               e.g  PHASEx, SPHASEx = (120 MHz)/ (20 kHz * 1 * 2)  = 3000
#endif
      
static void init_PWM_ISHARE_REF()
{
  IOCON1bits.PENH = PIN_PWM;						
  IOCON1bits.PMOD = 3;    /*  pin pair is in the True Independent PWM Output mode */		
  PWMCON1bits.MDCS = 0; /*0= PDCx/SDCx provides duty cycle value;1=MDC provide */
  PWMCON1bits.DTC = 2;   /* Dead time is disabled added into duty cycle */
  PWMCON1bits.IUE = 0;    /* Disable Immediate duty cycle updates */
  IOCON1bits.SWAP = 0;       /* PWMxH and PWMxL pins are mapped to their respective pins */
                                                      /* PHASEx/SPHASEx registers provide time base period*/  
  PWMCON1bits.ITB = 1;		// Time Base Period Control;CYCLE = PHASEx	
  FCLCON1bits.FLTMOD = 3;  /*3=disable fault input;0 =FLADAT locked*/
  PHASE1 = 300;  //?
  /*  PDCx: PWM GENERATOR DUTY CYCLE x REGISTER*/
  PDC1 = 0;
}

static void init_PWM_FAN()
{
  IOCON2bits.PENL = PIN_PWM;						
  IOCON2bits.PMOD = 3;			
  PWMCON2bits.MDCS = 0;
  PWMCON2bits.DTC = 2;			
  PWMCON2bits.ITB = 1;			
  FCLCON2bits.FLTMOD = 3;
  IOCON1bits.SWAP = 0;       /* PWMxH and PWMxL pins are mapped to their respective pins */
   PTCON2bits.PCLKDIV = 1;     /*1= pre-scaler 1:2*/
  SPHASE2 = 33000; 
  /*  PDCx: PWM GENERATOR DUTY CYCLE x REGISTER*/
 SDC2 = 0;
}
#ifdef  no_used
/*******************************************************************************
 * Function:        
 * auther:          Edwin 
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     
 * history:
 ******************************************************************************/

static void init_PWM_V36V_TRIM()
{


     //PWM 2 configuration				 //True Independent Mode
  /*
  PWM2H : V36V_REF
   */
  IOCON2bits.PENH = PIN_PWM;					
  IOCON2bits.PMOD = 3;			//PWMin the True Independent Output mode
  IOCON1bits.FLTDAT = 0;                              /* Turn OFF both PWM1 outputs in case of a fault condition */

  PWMCON1bits.DTC = 2;                                /* Dead time function disabled */
  
  
  PWMCON2bits.MDCS = 0;
  PWMCON2bits.DTC = 2;			 //Dead time function is disabled
  PWMCON2bits.ITB = 1;			 //PHASEx/SPHASEx registers provide time base period for this PWM generator
  FCLCON2bits.FLTMOD = 3;
  
 PHASE2 = 33000;
  /*  PDCx: PWM GENERATOR DUTY CYCLE x REGISTER*/
  PDC2 = 0;
  
  ///
  FCLCON2bits.FLTSRC = 2;             /* Comparator #3 is Fault source */
  FCLCON2bits.FLTPOL = 1;             /* Fault source is active high */
  FCLCON2bits.FLTMOD = 1;             /* FLTDAT from IOCONx register
                                           provides data to PWM output
                                           when in fault state */
  
  ///

  gVoutCmd = UserData.Page2.region.VoutCommand.Val;
  Vref.SetVoltage = gVoutCmd;
  Vref.SoftstartVoltage = 0;

}
#endif

/*******************************************************************************
 * Function:        
 * auther:          Edwin 
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     
 * history:
 ******************************************************************************/
static void pwm_general_init( void)
{
  /* Active Period register is updated immediately */
  PTCONbits.EIPU = 1;
  /* PWM Special Event Match Interrupt Priority bits */
  IPC14bits.PSEMIP = PSEMIP_INT_PRIO;
  /* PWM Special Event Compare Value */
  SEVTCMP = 0;
  /* PWM Special Event Match Interrupt Enable */
  _PSEMIE = 1;

  /***********************************************
   * turn on PWM module
   **********************************************/
  /* 1 = Enable the PWM Module */
  PTCONbits.PTEN = 1;

}
/*******************************************************************************
 * Function:        
 * auther:          Edwin 
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     
 * history:
 ******************************************************************************/
static void pwm3_sr_init( void)
{
   /***********************************************
   * PWM 3 Configuration -- LLC SR MASTER driver
   **********************************************/
#if DEBUG_DISABLE_SR
  IOCON3bits.PENH = 0;
  IOCON3bits.PENL = 0;
#else
  /* PWM module controls PWMxH pin */
  IOCON3bits.PENH = PIN_PWM;
  /* PWM module controls PWMxL pin */
  IOCON3bits.PENL = PIN_PWM;
#endif
  IOCON3bits.PMOD = 2;              /* Push-Pull Mode the period = PTPER * 2  , duty = PTPER - LLCDEADTIME */
  IOCON3bits.SWAP = 0;             /* PWMxH and PWMxL pins are mapped to their respective pins */
  IOCON3bits.CLDAT = 0;            /* State(2) for PWMxH and PWMxL Pins if CLMOD is Enabled bits */ 
  PWMCON3bits.DTC = 0;           /* positive Dead time  added into duty cycle */
  PWMCON3bits.ITB = 0;             /* Select Independent Time base mode */
  PWMCON3bits.IUE = 1;             /* Updates to the active MDC/PDCx/SDCx registers are immediate */
  FCLCON3bits.IFLTMOD = 0;     /* Normal Fault mode */
  FCLCON3bits.CLMOD = 0;        /* Current-Limit mode is disabled */
  FCLCON3bits.FLTMOD = 3;      /*Fault input is disabled */
  PHASE3 = 0;
  PDC3 = 0;
  
  SPHASE3 = 0;
  SDC3 = 0;
}
/*******************************************************************************
 * Function:        
 * auther:          Edwin 
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     
 * history:
 ******************************************************************************/

static void pwm5_fbllc_init()
{

	/***********************************************
	   * PWM 5 Configuration -- LLC Half bridge driver
	   **********************************************/
/* PWM module controls PWMxH pin */
            IOCON5bits.PENH = PIN_PWM;
/* PWM module controls PWMxL pin */
	  IOCON5bits.PENL = PIN_PWM;
/* Push-Pull Mode ? the period = PTPER * 2  , duty = PTPER - LLCDEADTIME */
	  IOCON5bits.PMOD = 2;
/* State(2) for PWMxH and PWMxL Pins if CLMOD is Enabled bits */
	  IOCON5bits.CLDAT = 0;
/* Dead time is disabled added into duty cycle */
	  PWMCON5bits.DTC = 2;
/* Select Primary Time base mode */
	  PWMCON5bits.ITB = 0;
/* Updates to the active MDC/PDCx/SDCx registers are immediate */
	  PWMCON5bits.IUE = 1;
/* Normal Fault mode*/
	  FCLCON5bits.IFLTMOD = 0;
/* Analog Comparator 2 */
	  //FCLCON5bits.CLSRC = 1;
/* Current-Limit mode is disabled */
	  FCLCON5bits.CLMOD = 0;
/* Fault input is disabled */
	  FCLCON5bits.FLTMOD = 3;
	  /* Latched Fault Mode */
	  //	FCLCON5bits.FLTMOD = 0;
	  /* Analog Comparator 2 */
	  FCLCON5bits.FLTSRC = 1;
	  /* Active High */
	  FCLCON5bits.FLTPOL = 0;
	  /* Rising edge of PWMxH will trigger Leading-Edge Blanking counter */
	  LEBCON5bits.PHR = 1;
	  /* Rising edge of PWMxL will trigger Leading-Edge Blanking counter */
	  LEBCON5bits.PLR = 1;
	  /* Current-Limit Leading-Edge Blanking Enable */
	  LEBCON5bits.CLLEBEN = 1;
	
	  PHASE5 = 0;
	  SPHASE5 = 0;
	  PDC5 = 0;
	 SDC5 = 0;
}

/*******************************************************************************
 * Function:        
 * auther:          Edwin 
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     
 * history:
 ******************************************************************************/
void init_PWM ( )
{
init_PWM_ISHARE_REF();
 init_PWM_FAN();		
  pwm3_sr_init( );
  pwm5_fbllc_init();
  
  PTPER = PWM_PERIOD;                                       // Old PWM_PERIOD=3846;125K  // from ASIC
  MDC = ( PWM_PERIOD >> 1 );                             // 50%
  pwm_general_init();
   /***********************************************
   * turn on PWM module
   **********************************************/
  /* 1 = Enable the PWM Module */
  PTCONbits.PTEN = 1;
}







