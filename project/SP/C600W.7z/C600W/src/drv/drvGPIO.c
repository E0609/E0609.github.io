/*****************************************************************************************
 *
 *Copyright (C) 2021 CIPS Singapore

 *                   LITE-ON TECHNOLOGY Corp.
 *
 *All Rights Reserved
 *
 *File Name : Init.c
 *
 *Date : 2021.01.20
 *
 *Author :              Edwin
 *
 *Description :
 *
 *******************************************************************************************/

#include  "xc.h"
#include  "p33Exxxx.h"
#include   "p33EP64GS506.h"
#include "define.h"
#include "Init.h"
#include "Userdata.h"
#include "Isr.h"
#include "Process.h"


extern tPS_FLAG PS;
extern SHORT gVoutCmd;



/*******************************************************************************
 * Name:                    Mcu_GPIOHwInit
 * Description:        
 * param[in]     -
 * param[in,out] -
 * param[out]  
 * return value:
 * author:                     Edwin                Edwin
 * Version:
 * Date:
 * History:
 *******************************************************************************/
static void port_IO_config()
{  // ODCx=Open-drain control register;1=5V open-drain ; 0=default 3v3 push-pull
    LATB = 0x0000;
    TRISB= 0xffff;   
    ANSELB = 0x0000;
    LATC = 0x0000;
    TRISC = 0xffff;   
    ANSELC = 0x0000;
      LATD = 0x0000;
    TRISD = 0xffff;   
    ANSELD = 0x0000;
 // INPUT
  /* PIN 35,34,33 for I2C Address selection*/
   _TRISC2 = MG_PIN_INPUT_DIRECTION;
   _TRISC14 = MG_PIN_INPUT_DIRECTION;
  _TRISB4 = MG_PIN_INPUT_DIRECTION;
   _TRISC4 = MG_PIN_INPUT_DIRECTION;     /* PIN 4 for PFC_OK_SEC*/
     _TRISC5 = MG_PIN_INPUT_DIRECTION;   /* PIN 51 for  AC_OK_SEC*/
  _TRISD0 = MG_PIN_INPUT_DIRECTION;     /* PIN 50 for  PS_ON_SEC*/
  // BUS
  _TRISC7 = MG_PIN_INPUT_DIRECTION;     /* PMBUS_SDA Pin36 */
  _TRISC8 = MG_PIN_INPUT_DIRECTION;     /* PMBUS_SCL Pin37 */
  _ODCC8 = 1;     // ODCx=Open-drain control register;1=5V open-drain ; 0=default 3v3 push-pull
  _ODCC7 = 1; 
 _TRISB8 = MG_PIN_INPUT_DIRECTION;          /* UART_RX Pin27 */
_TRISB15 = MG_PIN_OUTPUT_DIRECTION;     /* UART_TX Pin28 */
  _ODCB8= 1;   
  _ODCB15 = 1; 
  
// OUTOUT
   _TRISC0 = MG_PIN_OUTPUT_DIRECTION;    /* PIN 4  LED1*/
   _TRISC13 = MG_PIN_OUTPUT_DIRECTION;   /* PIN 5 for SR_DIS*/
   _TRISD12 = MG_PIN_OUTPUT_DIRECTION;   /* PIN 8 for ishare_DIS*/
   _TRISD7 = MG_PIN_OUTPUT_DIRECTION;    /* PIN 21 for oring _en*/
   _TRISD2 = MG_PIN_OUTPUT_DIRECTION;   /* PIN 30 for POK*/
   _TRISD9= MG_PIN_OUTPUT_DIRECTION;    /* PIN 40 for STB_EN*/
   _TRISD5 = MG_PIN_OUTPUT_DIRECTION;   /* PIN 53 for PFC*/
   _TRISD4 = MG_PIN_OUTPUT_DIRECTION;   /* PIN 58 for FAN*/
   _TRISD1 = MG_PIN_OUTPUT_DIRECTION;    /* PIN 64 for LLC_DIS*/
}
/*******************************************************************************
 * Name:                    uart Remap Pin
 * Description:        
 * param[in]     -
 * param[in,out] -
 * param[out]  
 * return value:
 * author:                     Edwin                
 * Version:
 * Date:
 * History:
 *******************************************************************************/
//static
void Mcu_uart_RemapPinInit(void)
{
  __builtin_write_OSCCONL(OSCCON & 0xbf);     /* Unlock register for remap pin configuration */
  _U1RXR = 40;                                                                /* Assign U1Rx to pin RP40/pin 43 */ 
  _RP47R= 1;                                                                    /* Assign U1Tx to pin RP47/ pin 44 */
  __builtin_write_OSCCONL(OSCCON | 0x40);      /* Lock register */
}

static void init_CMP()
{
#if cips // no comparater
    /* ~~~~~~~~~~~~~~~~~~~~~~~~ CMP1C Configuration ~~~~~~~~~~~~~~~~~~~~~~~~~~ */
    CMP1CONbits.INSEL = 2;               /* Select CMP1C input  PIN23, 12_OUT_MCU*/
    CMP1CONbits.EXTREF = 0;              /* Choose internal reference AVDD */
    CMP1CONbits.RANGE = 0;               /* Max DAC voltage = AVdd */
    
    CMP1DAC = 0x03FF;                    /* Choose comparator reference voltage 0x01FF = AVdd/4 ,AVdd/2 =0x03FF */
    
    // Select comparator hysteresis
   CMP1CONbits.HYSSEL = 3;   // 45 mV hysteresis selected
   CMP1CONbits.HYSPOL = 0;   // Hysteresis is applied to rising edge of the
// comparator output
    CMP1CONbits.CMPON = 1;               /* CMP1 enabled */
#endif
}
/*******************************************************************************
 * Name:                    init GPIO
 * Description:        
 * param[in]     -
 * param[in,out] -
 * param[out]  
 * return value:
 * author:                     Edwin                
 * Version:
 * Date:
 * History:
 *******************************************************************************/
void init_GPIO ( void )
{
     port_IO_config();
     Mcu_uart_RemapPinInit();    
     pin_o_LED_ON = LED_OFF;
     init_CMP();
#if PSON_ENABLE
#else
     _SD_Flag.PS_ON_OFF = TRUE;
#endif

#if RS_ENABLE   
      pin_o_ORING_EN_MCU  = RS_OFF;
#endif
}
