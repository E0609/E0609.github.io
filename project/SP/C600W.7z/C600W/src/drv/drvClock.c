/*****************************************************************************************
 *
 *Copyright (C) 2021 CIPS Singapore

 *                   LITE-ON TECHNOLOGY Corp.
 *
 *All Rights Reserved
 *
 *File Name : Init.c
 *
 *Date : 2021.01.20
 *
 *Author :              Edwin
 *
 *Description :
 *
 *******************************************************************************************/

#include  "xc.h"
#include  "p33Exxxx.h"
#include   "p33EP64GS506.h"
#include "define.h"
#include "drvClock.h"
#include "Userdata.h"
#include "Isr.h"
#include "Process.h"


extern tPS_FLAG PS;
//------------------------------------ SetupClock ------------------------------------------------
/*
PLLFBD: PLL FEEDBACK DIVISOR REGISTER
PLLDIV<8:0>: PLL Feedback Divisor bits (also denoted as �??M�??, PLL multiplier)

bit 2-0               PCLKDIV<2:0>: PWM Input Clock Prescaler (Divider) Select bits
bit 7-6               PLLPOST<1:0>: PLL VCO Output Divider Select bits (also denoted as �??N2�??, PLL postscaler)

*/
 
 #ifdef notes
#define PERIOD_CONTROL_LOOP    898     /* Counter value for 15uS timer at 59.88125MHz fcl */  // 15uS
#define PERIOD_FAN_CAPTURE     14970   /* Setting of maximum capture time */            // 250uS  
#define PERIOD_MAIN_LOOP       5988    /* Counter value for 100uS timer at 59.88125MHz fcl */ // 100uS 5988
#endif

 
void init_SetupClock ( void )
{
#define FRC_OSC                                                       // if use internal FRC  osc
//#define FCY                    59881250                           /* FCY = FOSC/2 - freq in Hz; 120Mhz/2   -freq 118750*/ 
#define PWMCLOCKFREQ           943360000      //130426 117.92*8*1000000
    

#if defined(FRC_OSC)
/* Fast RC internal oscillator (FRC) w/PLL, start with FRC and then switch */
// FOSCSEL
#pragma config FNOSC = FRCPLL                       // Oscillator Source Selection (Fast RC Oscillator with divide-by-N with PLL module (FRCPLL) )
#pragma config IESO = ON                                    // Two-speed Oscillator Start-up Enable bit (Start up device with FRC, then switch to user-selected oscillator source)
 
#elif defined(PRIM_OSC)
/* Primary oscillator (XT, HS, EC) w/PLL, start with FRC and then switch */
// FOSCSEL
#pragma config FNOSC = PRIPLL                      // Oscillator Source Selection (Fast RC Oscillator with divide-by-N with PLL module (FRCPLL) )
#pragma config IESO = ON                                  // Two-speed Oscillator Start-up Enable bit (Start up device with FRC, then switch to user-selected oscillator source)
#else
#error No oscillator type selected!
#endif
        
/* POR timer value (128ms) */
//_FPOR(FPWRT_PWR128)

/* Oscillator switch enable monitor disable, oscillator pin used as IO */
// FOSC
#pragma config OSCIOFNC = ON               // OSC2 Pin Function bit   (OSC2 is general purpose digital I/O pin)
#pragma config FCKSM = CSECMD           // Clock Switching Mode bits (Clock switching is enabled,Fail-safe Clock Monitor is disabled)

/* Watchdog disable */
// FWDT
#pragma config WDTPOST = PS1              // Watchdog Timer Postscaler bits (1:1)
#pragma config WDTPRE = PR128           // Watchdog Timer Prescaler bit (1:128)
#pragma config WDTEN = SWDTEN     // Watchdog Timer Enable bits (WDT Enabled) 
                                                                          //  128 * 1 / 32kHz = 4ms

#pragma config ICS = PGD1                       // ICD Communication Channel Select bits (Communicate on PGEC1 and PGED1)
#pragma config JTAGEN = OFF                 // JTAG Enable bit (JTAG is disabled)

// FDEVOPT
#pragma config PWMLOCK = OFF            // PWMx Lock Enable bit (PWM registers may be written without key sequence)
#pragma config ALTI2C1 = ON                  // Alternate I2C1 Pin bit (I2C1 mapped to ASDA1/ASCL1 pins)
#pragma config ALTI2C2 = ON                  // Alternate I2C2 Pin bit (I2C2 mapped to ASDA2/ASCL2 pins)

  PLLFBD = 41;                                             // M
  CLKDIVbits.PLLPOST = 0;                          // PLLPOST (N1) 0=/2
  
  
  /*  __builtin_write_OSCCONH(0x01); >> now the PLL is configured.
  set the value for {COSC, NOSC} with this function to switch to FRC with PLL*/
  __builtin_write_OSCCONH ( 0x01 );    /*1=FRCPLL in  NOSC*/
  
/*__builtin_write_OSCCONL(0x01);   >>  /* 1= NOSC;  Tell the CPU to perform the clock switch.*/
  __builtin_write_OSCCONL ( 0x01 );
  
  
  while ( OSCCONbits.COSC != 0b001 );
  while ( OSCCONbits.LOCK != 1 );
  ACLKCON = 0xA740;		  //     devided by 32              
  while ( ACLKCONbits.APLLCK != 1 );  // waiting for lock status
}







