/*****************************************************************************************
 *
 *Copyright (C) 2021 CIPS Singapore

 *                   LITE-ON TECHNOLOGY Corp.
 *
 *All Rights Reserved
 *
 *File Name : Init.c
 *
 *Date : 2021.01.20
 *
 *Author :              Edwin
 *
 *Description :
 *
 *******************************************************************************************/

#include  "xc.h"
#include  "../Lib/p33Exxxx.h"
#include   "../Lib/p33EP64GS506.h"
#include "define.h"
#include "../h/drv/drvPWM.h"


#define PIN_PWM 1


//------------------------------------ init_PWM ------------------------------------------------
/*******************************************************************************
 * Function:      init_PWM   
 * auther:          Edwin 
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     
 * history:
 ******************************************************************************/
/**
 *PWM1H	ISHARE_REF
PWM2L	FAN_PWM
PWM5H	LLC_G1
PWM5L	LLC_G2
PWM3H	SR_G1
PWM3L	SR_G2
 */

/*******************************************************************************
 * Function:      init_PWM   
 * auther:          Edwin 
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     
 * history:
 ******************************************************************************/
#ifdef notes // Independent time base = ITB
  if (CAM==1&& ITB==1) {
      PETER!= Cycle;
      CYCLE== PHASEx, SPHASEx:
               PHASEx, SPHASEx  = FOSC/(F_PWM* (PWM Input Clock Prescaler)*2)
               e.g  PHASEx, SPHASEx = (120 MHz)/ (20 kHz * 1 * 2)  = 3000
#endif
      
static void init_PWM_ISHARE_REF()
{
  IOCON1bits.PENH = PIN_PWM;						
  IOCON1bits.PMOD = 3;    /*  pin pair is in the True Independent PWM Output mode */		
  PWMCON1bits.MDCS = 0; /*0= PDCx/SDCx provides duty cycle value;1=MDC provide */
  PWMCON1bits.DTC = 2;   /* Dead time is disabled added into duty cycle */
  PWMCON1bits.IUE = 0;    /* Disable Immediate duty cycle updates */
  IOCON1bits.SWAP = 0;       /* PWMxH and PWMxL pins are mapped to their respective pins */
                                                      /* PHASEx/SPHASEx registers provide time base period*/  
  PWMCON1bits.ITB = 1;		// Time Base Period Control;CYCLE = PHASEx	
  FCLCON1bits.FLTMOD = 3;  /*3=disable fault input;0 =FLADAT locked*/
  PHASE1 = 300;  //?
  /*  PDCx: PWM GENERATOR DUTY CYCLE x REGISTER*/
  PDC1 = 0;
}

static void init_PWM_FAN()
{
  IOCON2bits.PENL = PIN_PWM;						
  IOCON2bits.PMOD = 3;			
  PWMCON2bits.MDCS = 0;
  PWMCON2bits.DTC = 2;			
  PWMCON2bits.ITB = 1;			
  FCLCON2bits.FLTMOD = 3;
  IOCON1bits.SWAP = 0;       /* PWMxH and PWMxL pins are mapped to their respective pins */
   PTCON2bits.PCLKDIV = 1;     /*1= pre-scaler 1:2*/
  SPHASE2 = 33000; 
  /*  PDCx: PWM GENERATOR DUTY CYCLE x REGISTER*/
 SDC2 = 0;
}
#ifdef  no_used
/*******************************************************************************
 * Function:        
 * auther:          Edwin 
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     
 * history:
 ******************************************************************************/

static void init_PWM_V36V_TRIM()
{


     //PWM 2 configuration				 //True Independent Mode
  /*
  PWM2H : V36V_REF
   */
  IOCON2bits.PENH = PIN_PWM;					
  IOCON2bits.PMOD = 3;			//PWMin the True Independent Output mode
  IOCON1bits.FLTDAT = 0;                              /* Turn OFF both PWM1 outputs in case of a fault condition */

  PWMCON1bits.DTC = 2;                                /* Dead time function disabled */
  
  
  PWMCON2bits.MDCS = 0;
  PWMCON2bits.DTC = 2;			 //Dead time function is disabled
  PWMCON2bits.ITB = 1;			 //PHASEx/SPHASEx registers provide time base period for this PWM generator
  FCLCON2bits.FLTMOD = 3;
  
 PHASE2 = 33000;
  /*  PDCx: PWM GENERATOR DUTY CYCLE x REGISTER*/
  PDC2 = 0;
  
  ///
  FCLCON2bits.FLTSRC = 2;             /* Comparator #3 is Fault source */
  FCLCON2bits.FLTPOL = 1;             /* Fault source is active high */
  FCLCON2bits.FLTMOD = 1;             /* FLTDAT from IOCONx register
                                           provides data to PWM output
                                           when in fault state */

  gVoutCmd = UserData.Page2.region.VoutCommand.Val;
  Vref.SetVoltage = gVoutCmd;
  Vref.SoftstartVoltage = 0;

}
#endif

/*******************************************************************************
 * Function:        
 * auther:          Edwin 
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     
 * history:
 ******************************************************************************/
static void pwm_general_init( void)
{
  /* Active Period register is updated immediately */
  PTCONbits.EIPU = 1;
  /* PWM Special Event Match Interrupt Priority bits */
  IPC14bits.PSEMIP = PSEMIP_INT_PRIO;
  /* PWM Special Event Compare Value */
  SEVTCMP = 0;
  /* PWM Special Event Match Interrupt Enable */
  _PSEMIE = 1;

  /***********************************************
   * turn on PWM module
   **********************************************/
  /* 1 = Enable the PWM Module */
  PTCONbits.PTEN = 1;

}
/*******************************************************************************
 * Function:        
 * auther:          Edwin 
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     
 * history:
 ******************************************************************************/
static void pwm3_sr_init( void)
{
   /***********************************************
   * PWM 3 Configuration -- LLC SR MASTER driver
   **********************************************/
#if DEBUG_DISABLE_SR
  IOCON3bits.PENH = 0;
  IOCON3bits.PENL = 0;
#else
  /* PWM module controls PWMxH pin */
  IOCON3bits.PENH = PIN_PWM;
  /* PWM module controls PWMxL pin */
  IOCON3bits.PENL = PIN_PWM;
#endif
  IOCON3bits.PMOD = 2;              /* Push-Pull Mode the period = PTPER * 2  , duty = PTPER - LLCDEADTIME */
  IOCON3bits.SWAP = 0;             /* PWMxH and PWMxL pins are mapped to their respective pins */
  IOCON3bits.CLDAT = 0;            /* State(2) for PWMxH and PWMxL Pins if CLMOD is Enabled bits */ 
  PWMCON3bits.DTC = 0;           /* positive Dead time  added into duty cycle */
  PWMCON3bits.ITB = 0;             /* Select Independent Time base mode */
  PWMCON3bits.IUE = 1;             /* Updates to the active MDC/PDCx/SDCx registers are immediate */
  FCLCON3bits.IFLTMOD = 0;     /* Normal Fault mode */
  FCLCON3bits.CLMOD = 0;        /* Current-Limit mode is disabled */
  FCLCON3bits.FLTMOD = 3;      /*Fault input is disabled */
  PHASE3 = 0;
  PDC3 = 0;
  
  SPHASE3 = 0;
  SDC3 = 0;
}
/*******************************************************************************
 * Function:        
 * auther:          Edwin 
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     
 * history:
 ******************************************************************************/

static void pwm5_fbllc_init()
{

	/***********************************************
	   * PWM 5 Configuration -- LLC Half bridge driver
	   **********************************************/
/* PWM module controls PWMxH pin */
            IOCON5bits.PENH = PIN_PWM;
/* PWM module controls PWMxL pin */
	  IOCON5bits.PENL = PIN_PWM;
/* Push-Pull Mode ? the period = PTPER * 2  , duty = PTPER - LLCDEADTIME */
	  IOCON5bits.PMOD = 2;
/* State(2) for PWMxH and PWMxL Pins if CLMOD is Enabled bits */
	  IOCON5bits.CLDAT = 0;
/* Dead time is disabled added into duty cycle */
	  PWMCON5bits.DTC = 2;
/* Select Primary Time base mode */
	  PWMCON5bits.ITB = 0;
/* Updates to the active MDC/PDCx/SDCx registers are immediate */
	  PWMCON5bits.IUE = 1;
/* Normal Fault mode*/
	  FCLCON5bits.IFLTMOD = 0;
/* Analog Comparator 2 */
	  //FCLCON5bits.CLSRC = 1;
/* Current-Limit mode is disabled */
	  FCLCON5bits.CLMOD = 0;
/* Fault input is disabled */
	  FCLCON5bits.FLTMOD = 3;
	  /* Latched Fault Mode */
	  //	FCLCON5bits.FLTMOD = 0;
	  /* Analog Comparator 2 */
	  FCLCON5bits.FLTSRC = 1;
	  /* Active High */
	  FCLCON5bits.FLTPOL = 0;
	  /* Rising edge of PWMxH will trigger Leading-Edge Blanking counter */
	  LEBCON5bits.PHR = 1;
	  /* Rising edge of PWMxL will trigger Leading-Edge Blanking counter */
	  LEBCON5bits.PLR = 1;
	  /* Current-Limit Leading-Edge Blanking Enable */
	  LEBCON5bits.CLLEBEN = 1;
	
	  PHASE5 = 0;
	  SPHASE5 = 0;
	  PDC5 = 0;
	 SDC5 = 0;
}

/*******************************************************************************
 * Function:        
 * auther:          Edwin 
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     
 * history:
 ******************************************************************************/
void init_PWM ( )
{
  init_PWM_ISHARE_REF();
  init_PWM_FAN();		
  pwm3_sr_init( );
  pwm5_fbllc_init();
  
  PTPER = PWM_PERIOD;                                       // Old PWM_PERIOD=3846;125K  // from ASIC
  MDC = ( PWM_PERIOD >> 1 );                             // 50%
  pwm_general_init();
   /***********************************************
   * turn on PWM module
   **********************************************/
  /* 1 = Enable the PWM Module */
  PTCONbits.PTEN = 1;
}







