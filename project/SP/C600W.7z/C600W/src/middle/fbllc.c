
#include "p33Exxxx.h"
#include "define.h"
#include "Parameter.h"
#include "dsp.h"
#include "Process.h"
#include "Util.h"
#include "fbllc.h"
#include "UserData.h"
#include "Protection.h"
#include "Pmbus.h"
#include "PowerOnOff.h"
#include "Fan.h"
#include "Isr.h"
#include "Timer.h"
#include <string.h>

#include "init.h"


//-------------Definition ------------------------------------------------------------

#define DUMMY_LOAD_ON_LIMIT (((WORD)1 * IOUT_TO_ADC) >> IOUT_TO_ADC_GAIN)
#define DUMMY_LOAD_OFF_LIMIT (((WORD)3 * IOUT_TO_ADC) >> IOUT_TO_ADC_GAIN)

//-------------Global variable---------------------------------------------------------
volatile unsigned long CaliCSIoutOffset = 0;
volatile unsigned long CaliCShareOffset = 0;

WORD CurrentShareError = 0;
SHORT Iout_Real = 0;
SHORT CSHARE_AVG = 0;

LONG CSIntegralOutput = 0;
LONG CSPropOutput = 0;
LONG CSDerivativeOutput = 0;

signed int cs_kp = 2293;	// 0.07 x 32767
signed int cs_ki = 2293;    	// 0.07 x 32767
signed int cs_kd = 0;		// 0.25 x 32767

//< --------------------------------  new current share method
MyPID CurrentSharePID;
SHORT CurrentShareABC[3];
SHORT CurrentShareHistory[3];
SHORT CurrentShareABC_SS[3];

//--------------------------------->

SHORT gVoutCshareOffset = 0;
SHORT i16CSStableCnt = 0;           //  Current Sharing Issue modified

#if RS_ENABLE   
SHORT gVoutRSenseOffset = 0;
#endif


//-------------Extern variable---------------------------------------------------------
extern tPS_FLAG PS;
extern tLLC HBLLC;
/************************************************************************
 * author:                     Edwin
 * description: 
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

//----------------------------------------------------------------------------------
void SRControl ( )
{
  if ( ADC.Iout_FF >= cSR_ON_IOUT_REFH_IM )
  {
      //oSR1 = SR_ON;
      pin_o_SR_EN   = SR_ON;
      PS.SR_Enable = 1;
  }
  else if ( HBLLC.Counter_InRegulation >= cSR_ON_DELAY && HBLLC.SR_ON_Delay >= 100 && ADC.Iout_FF >= cSR_ON_IOUT_REFH )
  {
      //oSR1 = SR_ON;
       pin_o_SR_EN   = SR_ON;
      PS.SR_Enable = 1;
  }
  else if ( ADC.V36V_OUT_FF< cSR_OFF_VOUT_REF || ADC.Iout_FF < cSR_ON_IOUT_REFL )
  {
      //oSR1 = SR_OFF;
      pin_o_SR_EN   = SR_OFF;
      PS.SR_Enable = 0;
      HBLLC.SR_ON_Delay = 0;
  }

}
/************************************************************************
 * author:                     Edwin
 * description: 
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
/**
 * 
 * SDCx: PWM Secondary Duty Cycle x Register(1,2,3)
?  SPHASEx: PWM Secondary Phase-Shift x Register(1,2)
 */
void CS_Control ( void )
{
    #ifdef c600
  static unsigned int cs_pwm_duty = 0;
  static LONG current_cs_pwm_duty = 0;
  static DWORD tcs_pwm = 0;
  static WORD cs_temp = 0;
  WORD Iout_AD_Buf;

  if ( HBLLC.CurrentShare == TRUE )
  {
      Iout_AD_Buf = ADC.Iout;
      
      cs_temp = ( Iout_AD_Buf << 3 ) - Iout_AD_Buf;  // ? cips
      tcs_pwm = __builtin_mulss ( cs_temp, CS_Slope_Temp );
      tcs_pwm = tcs_pwm >> 10;
      current_cs_pwm_duty = ( LONG ) tcs_pwm + ( CS_Offset_Temp >> 1 );

      if ( current_cs_pwm_duty <= 0 || Iout_AD_Buf == 0 )   
      {
            current_cs_pwm_duty = 0;
            cs_pwm_duty = 0;
      }
      else
      {
            cs_pwm_duty = current_cs_pwm_duty;
      }

      if ( cs_pwm_duty >= PWM_V36V_FB_Period )
      {
            PWM_ISHARE_INT_duty = PWM_V36V_FB_Period;
      }

      else
      {
            PWM_ISHARE_INT_duty = cs_pwm_duty;
      }
  }
  else
  {
      PWM_ISHARE_INT_duty = 0;
  }
  #endif
}
/************************************************************************
 * author:                     Edwin
 * description: 
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void ResetPID ( )
{
  memset ( CurrentShareHistory, 0, sizeof (CurrentShareHistory ) );

  CurrentSharePID.controlReference = 0;
  CurrentSharePID.measuredOutput = 0;
  CurrentSharePID.controlOutput = 0;
  CurrentSharePID.historyCount = 0;
}

/************************************************************************
 * author:                     Edwin
 * description: STABDBy
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void PIDApp ( MyPID *controller )
{

#if 1
  SHORT Error = 0;
  LONG Sum = 0;
  CHAR N1 = 0;
  CHAR N2 = 0;

  Error = controller->controlReference - controller->measuredOutput;

#if CS_OPTIMIZTION_EN                                     //  Current Sharing optimization Enable
    if ((Error >192) && (i16CSStableCnt == 500))          
      Error = 192;                                       
#endif
                                       
  controller->controlHistory[controller->historyCount] = Error;

  N1 = controller->historyCount - 1;
  N2 = controller->historyCount - 2;

  if ( N1 < 0 ) N1 += 3;
  if ( N2 < 0 ) N2 += 3;
      
      Sum = ( ( ( LONG ) controller->controlHistory[controller->historyCount] * controller->abcCoefficients[P_ENUM] ) >> 15 )
          + ( ( ( LONG ) controller->controlHistory[N1] * controller->abcCoefficients[I_ENUM] ) >> 15 )
          + ( ( ( LONG ) controller->controlHistory[N2] * controller->abcCoefficients[D_ENUM] ) >> 15 )
          + ( controller->controlOutput );

  controller->historyCount = ( controller->historyCount < 2 ) ? ( controller->historyCount + 1 ) : ( 0 );


  if ( Sum > Q15_UNSIGN_MAX )
      controller->controlOutput = Q15_UNSIGN_MAX;
  else if ( Sum < Q15_UNSIGN_MIN )
      controller->controlOutput = Q15_UNSIGN_MIN;
  else
      controller->controlOutput = Sum;
#endif	

}
/************************************************************************
 * author:                     Edwin
 * description: 
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void init_CurrentShareLoop ( void )
{
#if 1//cips 
  memset ( CurrentShareABC, 0, sizeof (CurrentShareABC ) );
  memset ( CurrentShareABC_SS, 0, sizeof (CurrentShareABC_SS ) );
  memset ( CurrentShareHistory, 0, sizeof (CurrentShareHistory ) );

  CurrentSharePID.abcCoefficients = & CurrentShareABC_SS[0];
  CurrentSharePID.controlHistory = & CurrentShareHistory[0];

  PIDApp ( &CurrentSharePID );

#if 0
  CurrentSharePID.abcCoefficients[0] = PID_CURRENTSHARE_A;
  CurrentSharePID.abcCoefficients[1] = PID_CURRENTSHARE_B;
  CurrentSharePID.abcCoefficients[2] = PID_CURRENTSHARE_C;
#endif

  CurrentShareABC_SS[0] = PID_CURRENTSHARE_A_SS;
  CurrentShareABC_SS[1] = PID_CURRENTSHARE_B_SS;
  CurrentShareABC_SS[2] = PID_CURRENTSHARE_C_SS;

  CurrentSharePID.controlReference = 0;
  CurrentSharePID.measuredOutput = 0;
  #endif
}
/************************************************************************
 * author:                     Edwin
 * description: 
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void CurrentShareOffsetInit ( )	//  added
{
#if 1//cips
  static BYTE tflag = FALSE;

  if ( PS.CS_CALIBTATED == TRUE )	//  modified
  {
      if ( tflag == FALSE )
      {
            tflag = TRUE;
           CaliCSIoutOffset = ( ( LONG ) ( ( ( LONGLONG ) UserData.Page1.region.Iout[OUTPUT_V36V].Offset * IOUT_TO_ADC ) >> 10 ) );
           CaliCShareOffset = ( ( LONG ) ( ( ( LONGLONG ) UserData.Page1.region.Iout[OUTPUT_V36V].CS_Offset * IOUT_TO_ADC ) >> 10 ) );
      }
  }
  else
  {
      tflag = FALSE;
      CaliCSIoutOffset = ( ( LONG ) ( ( ( LONGLONG ) UserData.Page1.region.Iout[OUTPUT_V36V].Offset * IOUT_TO_ADC ) >> 10 ) );
      CaliCShareOffset = ( ( LONG ) ( ( ( LONGLONG ) UserData.Page1.region.Iout[OUTPUT_V36V].CS_Offset * IOUT_TO_ADC ) >> 10 ) );
  }
  #endif
}
/************************************************************************
 * author:                     Edwin
 * description: 
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static void UpdatePIDBuffer ( BYTE* data, BYTE size )
{
  static BYTE count = 0;

  memcpy ( &gPmbusCmd.PID_LOG[count], data, size );

  count += size;
  if ( count >= ( sizeof (gPmbusCmd.PID_LOG ) ) )
  {
      count = 0;
  }
}
/************************************************************************
 * author:                     Edwin
 * description: 
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void Current_Share ( void )
{
#if 1//cips
  static SHORT cshare_error = 0;
  static LONG CurrentRef = 0;

  static unsigned int preIoAD = 0;                              //  Current Sharing Issue modified

  Iout_Real = ADC.CS_PWM_FB_FF;
  CSHARE_AVG = ( ( ( LONG ) ADC.ISHARE_IN_FF * gVCS_Slope ) + gVCS_Offset ) >> 10;

  if ( CSHARE_AVG <= 0 )   {   CSHARE_AVG = 0;   }
  if ( ! PS.I2C_Processing )
  {
      memcpy ( gPmbusCmd.CS_PWM_FB, ( BYTE* ) & ADC.CS_PWM_FB_FF, 2 );
      memcpy ( gPmbusCmd.CS_IN, ( BYTE* ) & ADC.ISHARE_IN_FF, 2 );
  }

  if ( PS.CS_CALIBTATED == TRUE && HBLLC.CurrentShare == TRUE )
  {
      CurrentSharePID.controlReference = ( SHORT ) ( CSHARE_AVG << 5 );
      CurrentSharePID.measuredOutput = ( SHORT ) ( Iout_Real << 5 );
      cshare_error = CurrentSharePID.controlReference  - CurrentSharePID.measuredOutput;

#if CS_OPTIMIZTION_EN   //  Current Sharing optimization Enable
//***************** //  Current Sharing Issue modified   ***********************************
      if(abs(ADC.Iout - preIoAD) <  10)
      {
          if (++i16CSStableCnt > 500)
              i16CSStableCnt = 500;
      }
      else
          i16CSStableCnt = 0;

      if ( cshare_error <= 192 )        // 6*32 = 192, 4*32 = 128, 
      {
              preIoAD = ADC.Iout;

              if(i16CSStableCnt == 500)
              {
                  if(ADC.Iout > I_Error_ADD_H)
                  {
                    CurrentSharePID.controlReference = CurrentSharePID.controlReference - 192;
                  }
              }
              else
              {
                  CurrentSharePID.controlReference = CurrentSharePID.controlReference - 192;
              }
       }

          PIDApp ( &CurrentSharePID );

          CurrentRef = ( __builtin_mulss ( CurrentSharePID.controlOutput, 200 ) >> 15 );

           if ( CurrentRef < 0 )
                CurrentRef = 0;

          gVoutCshareOffset = CurrentRef;
#else                                                                     //  Current Sharing optimization Disable
     if ( cshare_error <= 192 ) // 6*32 = 192
      {
          CurrentSharePID.controlReference = CurrentSharePID.controlReference - 192;
      }

      PIDApp ( &CurrentSharePID );

      if ( CurrentSharePID.controlOutput > 32767 )
            CurrentSharePID.controlOutput = 32767;
      else if ( CurrentSharePID.controlOutput < 0 )
            CurrentSharePID.controlOutput = 0;

      CurrentRef = ( __builtin_muluu ( CurrentSharePID.controlOutput, 800 ) >> 15 );

      if ( CurrentRef > 800 )
            CurrentRef = 800;
      else if ( CurrentRef < - 800 )
            CurrentRef = - 800;

      gVoutCshareOffset = CurrentRef;

      if ( gVoutCshareOffset <= 0 )
      {
          gVoutCshareOffset = 0;
      }
      if ( gVoutCshareOffset >= 200 )
      {
          gVoutCshareOffset = 200;
      }
#endif
      UpdatePIDBuffer ( ( BYTE* ) & CSHARE_AVG, 2 );
      UpdatePIDBuffer ( ( BYTE* ) & Iout_Real, 2 );
      UpdatePIDBuffer ( ( BYTE* ) & CurrentSharePID.controlOutput, 2 );
      UpdatePIDBuffer ( ( BYTE* ) & gVoutCshareOffset, 2 );
  }
  else
  {
      ResetPID ( );
      gVoutCshareOffset = 0;
      CurrentRef = 0;
  }
#endif
}
/************************************************************************
 * author:                     Edwin
 * description: 
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void IoutCali ( )
{

  if ( PS.IOUT1_CALIBRATED )
  {
      LONG temp;
  #if 1
      //20150924 Added no Load, dispaly zero.
      if (ADC.Iout_report_FF == 0)
      {
        temp = 0;
      }
      else
      {
            if ( PS.SR_Enable == 1 )    //20160713 Added two step Iout Calibration.
            {
                temp = ( ( ( LONG ) ADC.Iout_report_FF * UserData.Page1.region.Iout[OUTPUT_V36V].slope + ( ( LONG ) ( ( ( LONGLONG ) UserData.Page1.region.Iout[OUTPUT_V36V].Offset * IOUT_TO_ADC ) >> IOUT_TO_ADC_GAIN ) ) ) >> 10 );    //20160713 Added two step Iout Calibration.
            }
            else if ( PS.SR_Enable == 0 ) //20160713 Added two step Iout Calibration.
            {
                temp = ( ( ( LONG ) ADC.Iout_report_FF * UserData.Page1.region.Iout[OUTPUT_V36V].slope2 + ( ( LONG ) ( ( ( LONGLONG ) UserData.Page1.region.Iout[OUTPUT_V36V].Offset2 * IOUT_TO_ADC ) >> IOUT_TO_ADC_GAIN ) ) ) >> 10 );  //20160713 Added two step Iout Calibration.
            }
      }


      if ( temp <= 0 )
      {
          ADC.Iout_report_Cal = 0;
      }
      else
      {
          ADC.Iout_report_Cal = temp;
      }

      //20150924 Added no Load, dispaly zero.
      if (ADC.Iout_FF == 0)
      {
          temp = 0;
      }
      else
      {
          if ( PS.SR_Enable == 1 )    //20160713 Added two step Iout Calibration.
          {
                temp = ( ( ( LONG ) ADC.Iout_FF * UserData.Page1.region.Iout[OUTPUT_V36V].slope + ( ( LONG ) ( ( ( LONGLONG ) UserData.Page1.region.Iout[OUTPUT_V36V].Offset * IOUT_TO_ADC ) >> IOUT_TO_ADC_GAIN ) ) ) >> 10 );   //20160713 Added two step Iout Calibration.
          }
          else if ( PS.SR_Enable == 0 ) //20160713 Added two step Iout Calibration.
          {
                temp = ( ( ( LONG ) ADC.Iout_FF * UserData.Page1.region.Iout[OUTPUT_V36V].slope2 + ( ( LONG ) ( ( ( LONGLONG ) UserData.Page1.region.Iout[OUTPUT_V36V].Offset2 * IOUT_TO_ADC ) >> IOUT_TO_ADC_GAIN ) ) ) >> 10 ); //20160713 Added two step Iout Calibration.
          }
      }
      
      if ( temp <= 0 )
      {
          ADC.Iout_Cal = 0;
      }
      else
      {
          ADC.Iout_Cal = temp;
      }

#endif
  }
  else
  {
      ADC.Iout_Cal = ADC.Iout_FF;
#if 1
      ADC.Iout_report_Cal = ADC.Iout_report_FF;
#endif
  }
}
/************************************************************************
 * author:                     Edwin
 * description: 
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void DummyLoad_Control ( )
{
  if ( ADC.Iout_Cal <=  DUMMY_LOAD_ON_LIMIT )
  {
   
  }
  else if ( ADC.Iout_Cal >= DUMMY_LOAD_OFF_LIMIT )	//20150122 modified
  {

  }
}

/************************************************************************
 * author:                     Edwin
 * description: 
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void OutputControl ( )
{
  //Check Output is in regulation
  if ( ADC.V36V_OUT_FF>= cVOUT_REG_REFH && PS.Softstart == FALSE && HBLLC.MainEnabled )
  {
      HBLLC.InRegulation = TRUE;
  }
  else if ( ADC.V36V_OUT_FF<= cVOUT_REG_REFL )
  {
      HBLLC.InRegulation = FALSE;
  }
  SRControl ( );
#if 0//no_needed // single  psu
  CurrentShareOffsetInit ( );
#endif
  IoutCali ( );
  DummyLoad_Control ( );
}
/************************************************************************
 * author:                     Edwin
 * description: 
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void Disable_CurrentShare ( )
{
  pin_o_ISHARE_DIS = TRUE;
  HBLLC.CurrentShare = FALSE;
  gVoutCshareOffset = 0;
}
/************************************************************************
 * author:                     Edwin
 * description: 
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void Enable_CurrentShare ( )
{
  if ( ( HBLLC.MainEnabled == TRUE ) && ( PS.SoftstartFinished == TRUE ) )
  {
      pin_o_ISHARE_DIS = FALSE;

      HBLLC.CurrentShare = TRUE;
      //Protect.CS_CATCH.Flag = 1;    // 20150108 removed
  }
}
#if 0

#define OUTPUT_MIN 0
#define OUTPUT_MAX 255
#define KP 0.12
#define KI 0.8
#define KD 0.003

// Variables
double analogReadValue, setPoint, outputVal;

// Input/output variables passed by reference, so they are updated automatically
AutoPID myPID(&analogReadValue, &setPoint, &outputVal, OUTPUT_MIN, OUTPUT_MAX, KP, KI, KD);

// Setup timeStep
void setup() {
  myPID.setTimeStep(500);
}


void loop() {
  setPoint = analogRead(A3);          // Set our desired point (read the POT)
  analogReadValue = analogRead(A1);   // Read our output voltage
  myPID.run();                        // Run the PID 
  analogWrite(6, outputVal); // Write the PID result to the output
}


#endif

