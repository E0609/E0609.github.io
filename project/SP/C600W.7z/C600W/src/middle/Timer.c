/*****************************************************************************************
 *
 *Copyright (C) 2021 CIPS Singapore

 *                   LITE-ON TECHNOLOGY Corp.
 *
 *All Rights Reserved
 *
 *File Name : Timer.c
 *
 *Date : 2021.01.20
 *
 *Author :              Edwin
 *
 *Description :This Program used for HP 2400W Timer Program.
 *
 *******************************************************************************************/
#include "Timer.h"
#include "Standby.h"
#include "Pmbus.h"
#include "Isr.h"
#include "Process.h"
#include "fbllc.h"
#include "Sci.h"

#define MAX_SYS_TIMER 8 //15    // 20150108 modified

//------------------Global Variable-----------------------------------------------------
SYS_TIMER SysTimer[MAX_SYS_TIMER];
QWORD SysTimerCount = 0;
static WORD UnitOffBlankingTime = 0;	//20110812 added for unit off not show issue
WORD AcOffBlankingTime = 0;
WORD AcOnBlankingTime = 0;
//WORD VrefCompDelay = 0;   //20160408 removed, the Function no used
WORD Tsb_off_delay = 0;
BYTE isInputDetected = FALSE;

BYTE Tsb_off_delay_Flag = 0;



//------------------Exported Variable-----------------------------------------------------
extern tPS_FLAG PS;
extern tLLC HBLLC;
//-------------------------------- T1Interrupt 1ms --------------------------------------

void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _T1Interrupt ( void )
{
  BYTE i;
  QWORD DiffTime;

  SysTimerCount ++;

  for ( i = 0; i < MAX_SYS_TIMER; i ++ )
  {
      if ( SysTimer[i].Active )
      {
          DiffTime = SysTimerCount - SysTimer[i].StartTime;
          if ( DiffTime == SysTimer[i].Elapse )
          {
              if ( SysTimer[i].pTimerFunc ) SysTimer[i].pTimerFunc ( );
              SysTimer[i].StartTime = SysTimerCount;
          }
      }
  }


  //For Main SCP
  {
      static BYTE count = 0;

      if ( PS.Softstart )
      {
          if ( count >= 3 )
          {
              PS.SC_CheckStart = 1;
          }
          else
          {
              count ++;
          }
      }
      else
      {
          PS.SC_CheckStart = 0;
      }
  }

  //20110503 added, should be the same priority with the uart data updating
 Count_4AC_Cycle ( );

  if ( ADC.StbVout_FF > cSTB_OK_REFH && STB.Enabled )
  {
      if ( STB.Counter_InRegulation < 0xFFFE ) STB.Counter_InRegulation ++;
  }


  if ( UnitOffBlankingTime < 5000 )
  {
      UnitOffBlankingTime ++;
  }
  else
  {
      
      if ( iAC_OK == AC_N_GOOD && ( ( _SD_Flag.STB_OCP == 0 ) && ( _SD_Flag.STB_OVP == 0 ) && ( _SD_Flag.STB_UVP == 0 ) ) /*&& (AcOffBlankingTime >= 5)*/ )    
      {
#if 0// Edwin
          if ( iPS_OK == P_N_OK )	// fbllc 20111014 added
          {
              if ( PS.isDCInput == FALSE )
              {
                  gPagePlusStatus.PAGE[PAGE0].STATUS_INPUT.bits.UNIT_OFF = 1;
                  if ( Real_Vac < Parameter.VIN_UV_WARN_LIMIT[0] )
                  {
                      gPagePlusStatus.PAGE[PAGE0].STATUS_INPUT.bits.VIN_UV_WARNING = 1;
                  }
                  if ( Real_Vac < Parameter.VIN_UV_FAULT_LIMIT[0] )
                  {
                      gPagePlusStatus.PAGE[PAGE0].STATUS_INPUT.bits.VIN_UV_FAULT = 1;
                  }

              }
              else
              {
                  gPagePlusStatus.PAGE[PAGE1].STATUS_INPUT.bits.UNIT_OFF = 1;
                  if ( Real_Vac < Parameter.VIN_UV_WARN_LIMIT[1] )
                  {
                      gPagePlusStatus.PAGE[PAGE1].STATUS_INPUT.bits.VIN_UV_WARNING = 1;
                  }
                  if ( Real_Vac < Parameter.VIN_UV_FAULT_LIMIT[1] )
                  {
                      gPagePlusStatus.PAGE[PAGE1].STATUS_INPUT.bits.VIN_UV_FAULT = 1;
                  }
              }
          }
#endif
      }
  }

#if cips // no_needed
#else
  if ( iAC_OK == AC_N_GOOD )
  {
      AcOnBlankingTime = 0;
      if ( AcOffBlankingTime >= 60 )
      {	//60ms
          PS.AC_OFF_ClearFault = TRUE;
      }
      else
      {
          AcOffBlankingTime ++;
      }
  }
  else
  {
      AcOffBlankingTime = 0;
      if ( AcOnBlankingTime >= 5000 )
      {	//5000ms
          PS.AC_ON_CheckLineStatus = TRUE;
      }
      else
      {
          AcOnBlankingTime ++;
      }
  }
#endif 
  /*SR control*/
  if ( HBLLC.InRegulation == TRUE )
  {
      if ( HBLLC.Counter_InRegulation < 0xFFFE )
      {
          HBLLC.Counter_InRegulation ++;
      }
  }
  else
  {
      HBLLC.Counter_InRegulation = 0;
  }

  if ( ADC.Iout_FF > cSR_ON_IOUT_REFH )
  {
      if ( HBLLC.SR_ON_Delay < 0xFFFE ) HBLLC.SR_ON_Delay ++;
  }


#if 1//cips


  /*Stb output control*/
//  if ( iPS_OK == P_N_OK && iAC_OK == AC_N_GOOD )   //iPS_ON   
   if ( iPS_ON  == P_N_OK && iAC_OK == AC_N_GOOD )     
  {
      if ( Tsb_off_delay < 0xFFFE ) 
      {
          Tsb_off_delay ++;
      }
  }
  else
  {
      Tsb_off_delay = 0;
      Tsb_off_delay_Flag = 0;
  }
  #else
    if ( Tsb_off_delay < 0xFFFE ) 
      {
          Tsb_off_delay ++;
      }

  #endif

  IFS0bits.T1IF = 0;
}
//-------------------------------- SetTimer ms--------------------------------------

BYTE SetTimer ( WORD Elapse, _Pfn pTimerFunc )
{
  BYTE i;

  if ( Elapse == 0 )
  {
      if ( pTimerFunc != NULL_cips )
      {
          pTimerFunc ( );
      }
  }
  else
  {
      for ( i = 0; i < MAX_SYS_TIMER; i ++ )
      {
          if ( SysTimer[i].Active == 0 )
          {
              SysTimer[i].Active = 1;
              SysTimer[i].pTimerFunc = pTimerFunc;
              SysTimer[i].Elapse = Elapse;
              SysTimer[i].StartTime = SysTimerCount;
              return i + 1;
          }
      }
  }
  return 0;
}
//-------------------------------- RestartTimer --------------------------------------

void RestartTimer ( BYTE *pTimerID )
{
  if ( *pTimerID <= 0 || * pTimerID > MAX_SYS_TIMER ) return;

  if ( SysTimer[*pTimerID - 1].Active == 0 ) return;

  SysTimer[*pTimerID - 1].StartTime = SysTimerCount;
}

//-------------------------------- KillTimer ms --------------------------------------

void KillTimer ( BYTE *pTimerID )
{
  if ( *pTimerID <= 0 || * pTimerID > MAX_SYS_TIMER ) return;

  SysTimer[*pTimerID - 1].Active = 0;

  *pTimerID = 0;
}





