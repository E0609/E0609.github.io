/*****************************************************************************************
 *
 *Copyright (C) 2021 CIPS Singapore

 *                   LITE-ON TECHNOLOGY Corp.
 *
 *All Rights Reserved
 *
 *File Name : Process.c
 *
 *Date : 2021.01.20
 *
 *Author :              Edwin
 *
 *Description :This Program used for HP 2400W Process Program.
 *
 *******************************************************************************************/
#include "p33EP64GS506.h"
#include "Process.h"
#include "Protection.h"
#include "Parameter.h"
#include "I2c.h"
#include "Fan.h"
#include "Util.h"
#include "Pmbus.h"
#include "Sci.h"
#include "Isr.h"
#include "UserData.h"
#include "fbllc.h"
#include "Temp_table.h"
#include "Led.h"



//---------Global variable----------------------------------------------------------------
tSD_FlagBITS _SD_Flag;
tMFR_STATUS MFR_Status;
DWORD gVout;
DWORD gIout;
DWORD gPout;
DWORD gVin;
DWORD gIin;	//
DWORD gPin;
WORD T_Pri;
WORD T_Sec;
WORD T_Inlet;

extern tSTB STB;    //add


signed char N; // cips added
//---------Extern variable----------------------------------------------------------------
extern tPS_FLAG PS;
extern tLLC HBLLC;
extern tPSU_STATE gPS_State;
//------------------------------ GetN ------------ --------------------------------------

char GetN ( BYTE type, WORD input )  // no such sensor in 600W
{

  /*Refer to dEll 11G spec. 6.5.2   IPMM Sensor Formatting Tables*/
  switch ( type )
  {
      case N_VOUT:
          return - 9;
          break;
      case N_FAN_CMD:
          return 0;
          break;
      case N_FAN_SPEED:
          return 4;
          break;
      case N_TEMPERATURE:
          return - 2;
          break;
      case N_IIN:
          if ( input < 2 )
          {
              return - 9;
          }
          else if ( input < 4 )
          {
              return - 8;
          }
      case N_IOUT:
          if ( input < 8 )
          {
              return - 7;
          }
          else if ( input < 16 )
          {
              return - 6;
          }
          else if ( input < 32 )
          {
              return - 5;
          }
      case N_VIN:
          if ( input < 64 )
          {
              return - 4;
          }
      case N_POUT:
          if ( input < 128 )
          {
              return - 3;
          }
      case N_PIN:
          if ( input < 256 )
          {
              return - 2;
          }
          else if ( input < 512 )
          {
              return - 1;
          }
          else if ( input < 1024 )
          {
              return 0;
          }
          else if ( input < 2048 )
          {
              return 1;
          }
          else
          {
              return 2;
          }
          break;
      default:
          return 0;
          break;
  }
  

}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void VinProcess ( )
{
  

#if  cips//_sg//WithTeridian
    DWORD result;
 
  if ( PS.Uart1Error == FALSE )          
  {
      if ( iAC_OK == AC_GOOD || Real_Vac >= 60 )
      {
          result = ( Uart.U1.Rx.VacMsb << 8 ) | Uart.U1.Rx.VacLsb;
          result = LinearFmt_YtoX ( result, 5 );		// VIN_MODE -> N = -5

          if(! PS.I2C_Processing)   // 
          {
            gPmbusCmd.READ_VIN[0] = result & 0xFF;
            gPmbusCmd.READ_VIN[1] = ( result >> 8 ) & 0xFF;
          }
      }
      else
      {
          gPmbusCmd.READ_VIN[0] = 0;
          gPmbusCmd.READ_VIN[1] = 0;
      }
  }
  else
  {
      gPmbusCmd.READ_VIN[0] = 0;
      gPmbusCmd.READ_VIN[1] = 0;
  }
#endif
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
void IinProcess ( )
{

   WORD Iin = 0;
  if ( PS.Uart1Error == FALSE )          
  {
      if ( iAC_OK == AC_GOOD || Real_Vac >= 60 )
      {
          Iin = Uart.U1.Rx.IinAvg;  	//0202 2021
          if(! PS.I2C_Processing)   // 
          {
            gPmbusCmd.READ_IIN[0] = Iin & 0xFF;
            gPmbusCmd.READ_IIN[1] = ( Iin >> 8 ) & 0xFF;
          }
      }
      else
      {
          gPmbusCmd.READ_IIN[0] = 0;
          gPmbusCmd.READ_IIN[1] = 0;
      }
  }
  else
  {
      gPmbusCmd.READ_IIN[0] = 0;
      gPmbusCmd.READ_IIN[1] = 0;
  }
	

}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
void PinProcess ( )
{
WORD Pin = 0;
  if ( PS.Uart1Error == FALSE )          
  {
      Pin = LinearFmt_XtoY(Uart.U1.Rx.PinAvg, GetN(N_PIN, (Uart.U1.Rx.PinAvg >> PIN_GAIN)), PIN_GAIN);	//translate to Linear Format
      if ( iAC_OK == AC_GOOD || Real_Vac >= 60 )
      {
          Pin = Uart.U1.Rx.PinAvg >> PIN_GAIN;

          if(! PS.I2C_Processing)    
          {
            gPmbusCmd.READ_PIN[0] = Pin & 0xFF;
            gPmbusCmd.READ_PIN[1] = ( Pin >> 8 ) & 0xFF;
          }
      }
      else
      {
          gPmbusCmd.READ_PIN[0] = 0;
          gPmbusCmd.READ_PIN[1] = 0;
      }
  }
#if 0//cips 
  else
  {
      gPmbusCmd.READ_PIN[0] = 0;
      gPmbusCmd.READ_PIN[1] = 0;
  }
  
#endif

}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static LONG check_vou_result()
{
	LONG result = 0;
	
	  if ( ( gIsFactoryMode) && ( iAC_OK == AC_GOOD ) ) 		  
	 { //
		  result = ( ( SHORT ) ADC.V36V_OUT_FF+ ( SHORT ) gVoutReadOffsetAdc );
		  if ( result < 0 )
		  {
			  result = 0;
		  }
		  ADC.V36V_OUT_Cal = result;
		  result = gVout = result * ADC_TO_VOUT;
	}
		        //N of Vout is fixed -8, Y = (X << 8) >> VOUT_GAIN => Y = X >> 3
      result = result >> 3;
      return result;
}
 /************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/   
 static void set_vou_reading_value(LONG i)
{
  if(! PS.I2C_Processing)   // 
	{
	    gPmbusCmd.READ_VOUT[0] = i & 0xFF;
	    gPmbusCmd.READ_VOUT[1] = ( i >> 8 ) & 0xFF;
	}

} 
 /************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
 static void set_iou_reading_value(DWORD i)
{
  if(! PS.I2C_Processing)   // 
	{
	    gPmbusCmd.READ_IOUT[0] = i & 0xFF;
	    gPmbusCmd.READ_IOUT[1] = ( i >> 8 ) & 0xFF;
	}

} 
 /************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
 static void set_Pou_reading_value(DWORD i)
{
  if(! PS.I2C_Processing)   // 
	{
	    gPmbusCmd.READ_POUT[0] = i & 0xFF;
	    gPmbusCmd.READ_POUT[1] = ( i >> 8 ) & 0xFF;
	}

} 
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
 static void clear_vou_reading_value()
{
	gPmbusCmd.READ_VOUT[0] = 0;
	gPmbusCmd.READ_VOUT[1] = 0;

}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
 static void clear_Iou_reading_value()
{
	gPmbusCmd.READ_IOUT[0] = 0;
	gPmbusCmd.READ_IOUT[1] = 0;

}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
 static void clear_Pou_reading_value()
{
	gPmbusCmd.READ_POUT[0] = 0;
	gPmbusCmd.READ_POUT[1] = 0;

}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void VoutProcess ( )
{
  LONG result = 0;

  if ( ( gIsFactoryMode) && ( iAC_OK == AC_GOOD ) )        
  {	//
	  result= check_vou_result();  
      if ( gPmbusCmd.PAGE[0] == 0 )
      {
          if ( HBLLC.MainEnabled == TRUE )
          {
              set_vou_reading_value(result);
          }
          else
          {
	  clear_vou_reading_value();
          }
      }  
      else
      {	//PAGE == 1
          result = ADC.StbVout_FF * ADC_TO_VOUT;
          result = result >> 3;
          set_vou_reading_value(result);
      }
  }
  else
  {
	  clear_vou_reading_value();
  }
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
 DWORD Check_IOUT_Calibration()
{
     DWORD result;
    if ( PS.IOUT1_CALIBRATED )
      {
          static DWORD temp_LPF = 0;
          static DWORD temp_FF = 0;
          result = ( ( DWORD ) ADC.Iout_report_Cal * ADC_TO_IOUT );
          temp_LPF = temp_LPF + result - temp_FF;
          gIout = temp_FF = temp_LPF >> 1;	//>> 4;	
      }
      else
      {
          gIout = result = ( DWORD ) ADC.Iout_FF * ADC_TO_IOUT;
      }
	  
       result = result >> 6;
	   return result;
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
 void Icurrent_share_reporting()
{
	//For Icurrent_share reporting		 
			  DWORD result = 0;
			  result = ( DWORD ) ADC.ISHARE_IN_FF * ADC_TO_IOUT;
			  N = GetN ( N_IOUT, ( WORD ) ( result >> ADC_TO_IOUT_GAIN ) );
			  result = LinearFmt_XtoY ( result, N, ADC_TO_IOUT_GAIN );			  
			  gPmbusCmd.READ_IOUT_CS[0] = result & 0xFF;
			  gPmbusCmd.READ_IOUT_CS[1] = ( result >> 8 ) & 0xFF;
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void IoutProcess ( )
{
  DWORD result = 0;
  //signed char N;

  if ( ( gIsFactoryMode)&& ( iAC_OK == AC_GOOD ) )           
  {	
       result = Check_IOUT_Calibration();
      if ( HBLLC.MainEnabled == TRUE )
      {
		  set_iou_reading_value(result);
      }
      else
      {
		  clear_Iou_reading_value();
      }
      gPmbusCmd.READ_IOUT_LS[0] = result & 0xFF;              //20160408 removed
      gPmbusCmd.READ_IOUT_LS[1] = ( result >> 8 ) & 0xFF;     //20160408 removed
	  Icurrent_share_reporting();
  }
  else
  {
	  clear_Iou_reading_value();
  }
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void PoutProcess ( )
{
  DWORD result = 0;
  BYTE totalIoutGain = 0;
  
  if ( ( gIsFactoryMode )&& ( iAC_OK == AC_GOOD ) )           
 
  {	//
      totalIoutGain = ADC_TO_IOUT_GAIN;                                                                   	//total gain for gIout
      result = ( DWORD ) ( ( ( QWORD ) gVout * gIout ) >> totalIoutGain );                	//divide total gain for gIout first to prevent DWORD overflow
      gPout = ( WORD ) ( result >> VOUT_GAIN );
	  set_Pou_reading_value(result);
  }
  else
  {
	  clear_Pou_reading_value();
  }

}

//-------------------------------- TpriProcess ---------------------------------------
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

 void Fan1Monitor ( )
{
  //DWORD result = 0;

  //Detect if fan is availble
  //20110124 modified begin =>
  if ( gFan1.Detected == FALSE )
  {
      Protect.Fan1Disappear.Flag = 1;
  }
  else
  {
      Protect.Fan1Disappear.Flag = 0;
      Protect.Fan1Disappear.delay = 0;
      PS.Fan1Disappear = 0;
  }
  // end <=


  //Check Fan Lock
#if 0 // no locked define
  if ( iAC_OK == AC_GOOD )
  {
      if ( ! PS.FanLock_Disable && _SD_Flag.FAN_LOCK == FALSE )
      {
          //20101220 modified for fan warning condition --->
#if 0
          if ( gFan1.CurrentRpm < 500 || gFan1.Detected == FALSE )
          {
              Protect.Fan1Warning.Flag = 1;
          }
          else
          {
              Protect.Fan1Warning.Flag = 0;
              Protect.Fan1Warning.delay = 0;
              gPmbusCmd.STATUS_FAN_1_2.bits.FAN1_WARNING = 0;
          }
#endif
          //20101220 modified for fan warning condition <---

          if ( gFan1.CurrentRpm < 500 || gFan1.Detected == FALSE )
          {
              Protect.Fan1Fault.Flag = 1;
              Protect.Fan1Lock.Flag = 1;
          }
          else
          {
              Protect.Fan1Lock.Flag = 0;
              Protect.Fan1Lock.delay = 0;
              Protect.Fan1Fault.Flag = 0;
              Protect.Fan1Fault.delay = 0;
          }
      }
      else
      {
          Protect.Fan1Warning.Flag = 0;
          Protect.Fan1Warning.delay = 0;
          Protect.Fan1Lock.Flag = 0;
          Protect.Fan1Lock.delay = 0;
          Protect.Fan1Fault.Flag = 0;
          Protect.Fan1Fault.delay = 0;
      }
  }
  else
  {
      //20100917 added for AC_NOK situation
      Protect.Fan1Warning.Flag = 0;
      Protect.Fan1Warning.delay = 0;
      Protect.Fan1Lock.Flag = 0;
      Protect.Fan1Lock.delay = 0;
      Protect.Fan1Fault.Flag = 0;
      Protect.Fan1Fault.delay = 0;
  }
#endif
#if 0
  if ( PS.Uart2Error == FALSE && PS.Fan1Disappear == FALSE )         
  {

      if ( iFAN_CNTL == Fan_Enable )
      {
          result = LinearFmt_XtoY ( gFan1.CurrentRpm, 5, 0 );	//original N = 4, but it will get overflow
          if(! PS.I2C_Processing)   // 
          {
            gPmbusCmd.READ_FAN_SPEED_1[0] = result & 0xFF;
            gPmbusCmd.READ_FAN_SPEED_1[1] = ( result >> 8 ) & 0xFF;
          }
      }
      else
      {
          gPmbusCmd.READ_FAN_SPEED_1[0] = 0;
          gPmbusCmd.READ_FAN_SPEED_1[1] = 0;
      }

  }
  else
  {
      gPmbusCmd.READ_FAN_SPEED_1[0] = 0;
      gPmbusCmd.READ_FAN_SPEED_1[1] = 0;
  }
#endif
    gPmbusCmd.READ_FAN_SPEED_1[0] = 0;
      gPmbusCmd.READ_FAN_SPEED_1[1] = 0;
  gFan1.Detected = FALSE;

}


//------------------------- CalculateNTSE0103FZD73Temp -----------------------------
/************************************************************************
 * author:                     Edwin
 * description: Temperature detection
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

 WORD CalculateNTSE0103FZD73Temp ( WORD TempAD )
{
  //Tambient

  WORD ReportTemp = 0;

  if ( TempAD >= 901 )	// 0C
  {
      ReportTemp = 0;
  }
  else if ( TempAD >= 865 )	// 20C
  {
      ReportTemp = ( SHORT ) ( ( ( ( LONG ) TempAD * ( - 568 ) ) + ( 512568 ) ) >> 10 );
  }
  else if ( TempAD >= 784 )	//45C
  {
      ReportTemp = ( SHORT ) ( ( ( ( LONG ) TempAD * ( - 316 ) ) + ( 293862 ) ) >> 10 );
  }
  else if ( TempAD >= 602 )	//80C
  {
      ReportTemp = ( SHORT ) ( ( ( ( LONG ) TempAD * ( - 196 ) ) + ( 200467 ) ) >> 10 );
  }
  else
  {
      ReportTemp = 80;
  }

  //Calibration
#if 1
  if ( ReportTemp <= 39 )
  {
      ReportTemp = ReportTemp + 1;
  }
#endif

  return ReportTemp;
}

//------------------------- CalculateNCP18XH103F03RBTemp -----------------------------
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

 WORD CalculateNCP18XH103F03RBTemp ( WORD TempAD )
{
  //Tpri & Tsec

  WORD ReportTemp = 0;

  if ( TempAD >= 900 )	// 0C
  {
      ReportTemp = 0;
  }
  else if ( TempAD >= 839 )	// 30C
  {
      ReportTemp = ( SHORT ) ( ( ( ( LONG ) TempAD * ( - 503 ) ) + ( 453245 ) ) >> 10 );
  }
  else if ( TempAD >= 715 )	//60C
  {
      ReportTemp = ( SHORT ) ( ( ( ( LONG ) TempAD * ( - 247 ) ) + ( 238575 ) ) >> 10 );
  }
  else if ( TempAD >= 368 )	//120C
  {
      ReportTemp = ( SHORT ) ( ( ( ( LONG ) TempAD * ( - 177 ) ) + ( 188038 ) ) >> 10 );
  }
  else
  {
      ReportTemp = 120;
  }

  return ReportTemp;
}

//-------------------------------- TpriProcess ---------------------------------------
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

 void TpriProcess ( )
{

#if cips
#else
  //Temperature of Primary side
  DWORD result = 0;
  WORD temp;
  static WORD T_PriCnt = 0;            //

  temp = Uart.U1.Rx.Pri_Temperature.Val;

#if 0
  if ( temp > Temp_AD_PARAMETER )
  {
      if ( ( temp - Temp_AD_PARAMETER ) >= Temp_Table_Total_Number )
      {
          T_Pri = 0;
      }
      else
      {
          T_Pri = temp_table[temp - Temp_AD_PARAMETER];
      }
  }
  else
  {
      T_Pri = 120;
  }
#else

  //if (T_PriCnt++ >= 20)                                                                                   //
  if ( ( PS.Uart1Error == FALSE ) && (T_PriCnt++ >= 20) )                       //20170216 
  {
    T_PriCnt = 25;                                                                                                //
    T_Pri = CalculateNCP18XH103F03RBTemp ( temp );                              //
  }
  else
  {
    T_Pri = 25;                                                                                                         //
  }



#endif

  if ( T_Pri >= Parameter.OTP_Tpri_FAULT_LIMIT )
  {
      if ( _SD_Flag.OTP_SD == 0 )
      {
          Protect.OTP_Tpri.Flag = 1;
      }
  }
  else
  {
      Protect.OTP_Tpri.Flag = 0;
      Protect.OTP_Tpri.delay = 0;
  }

  if ( T_Pri >= Parameter.OTP_Tpri_WARN_LIMIT )
  {	//
      Protect.OTW_Tpri.Flag = 1;
  }
  else
  {
      Protect.OTW_Tpri.Flag = 0;
      Protect.OTW_Tpri.delay = 0;
      //gLedWarningStatus.bits.ot2_warning = 0;
  }

  if ( _SD_Flag.OTP_SD || _SD_Flag.STB_OTP )
 // if ( _SD_Flag.OTP_SD )    
  {
      if ( T_Pri < Parameter.OTP_Tpri_Recovery_LIMIT )
      {
          Protect.OT_Recover_Tpri.Flag = 1;
      }
      else
      {
          Protect.OT_Recover_Tpri.Flag = 0;
          Protect.OT_Recover_Tpri.delay = 0;
      }
  }

  //if ( gIsFactoryMode || ( PS.Uart1Error == FALSE && PS.Uart2Error == FALSE ) )
  if ( gIsFactoryMode || ( PS.Uart1Error == FALSE ) )         
  {
      result = LinearFmt_XtoY ( T_Pri, 0, 0 );	//N is fixed 0
      if(! PS.I2C_Processing)   // 
      {
        gPmbusCmd.READ_TEMPERATURE_2[0] = result & 0xFF;
        gPmbusCmd.READ_TEMPERATURE_2[1] = ( result >> 8 ) & 0xFF;
      }
  }
  else
  {
      gPmbusCmd.READ_TEMPERATURE_2[0] = 0;
      gPmbusCmd.READ_TEMPERATURE_2[1] = 0;
  }


#endif
}
//-------------------------------- TsecProcess ---------------------------------------
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

 void TsecProcess ( )
{
  //Temperature of Sec
  DWORD result = 0;
  WORD temp;
  temp = ADC.Tsec_FF;

  if ( temp > Temp_AD_PARAMETER )
  {
      if ( ( temp - Temp_AD_PARAMETER ) >= Temp_Table_Total_Number )
      {
          T_Sec = 0;
      }
      else
      {
          T_Sec = temp_table[temp - Temp_AD_PARAMETER];
      }
  }
  else
  {
      T_Sec = 120;
  }


  //Check Sec OTP
  if ( T_Sec >= Parameter.OTP_Tsec_FAULT_LIMIT )
  {
      if ( _SD_Flag.OTP_SD == 0 )
      {
          Protect.OTP_Tsec.Flag = 1;
      }
  }
  else
  {
      Protect.OTP_Tsec.Flag = 0;
      Protect.OTP_Tsec.delay = 0;
  }

  if ( T_Sec >= Parameter.OTP_Tsec_WARN_LIMIT )
  {
      Protect.OTW_Tsec.Flag = 1;
  }
  else
  {
      Protect.OTW_Tsec.Flag = 0;
      Protect.OTW_Tsec.delay = 0;
 //     //gLedWarningStatus.bits.ot3_warning = 0;
  }

  if ( _SD_Flag.OTP_SD || _SD_Flag.STB_OTP )
  //if ( _SD_Flag.OTP_SD )    
  {
      if ( T_Sec < Parameter.OTP_Tsec_Recovery_LIMIT )
      {
          Protect.OT_Recover_Tsec.Flag = 1;
      }
      else
      {
          Protect.OT_Recover_Tsec.Flag = 0;
          Protect.OT_Recover_Tsec.delay = 0;
      }
  }

  //if ( gIsFactoryMode || ( PS.Uart1Error == FALSE && PS.Uart2Error == FALSE ) )
  if ( gIsFactoryMode || ( PS.Uart1Error == FALSE ) )         
  {
      result = LinearFmt_XtoY ( T_Sec, 0, 0 );	//N is fixed 0
      if(! PS.I2C_Processing)   // 
      {
        gPmbusCmd.READ_TEMPERATURE_3[0] = result & 0xFF;
        gPmbusCmd.READ_TEMPERATURE_3[1] = ( result >> 8 ) & 0xFF;
      }
  }
  else
  {
      gPmbusCmd.READ_TEMPERATURE_3[0] = 0;
      gPmbusCmd.READ_TEMPERATURE_3[1] = 0;
  }
}

//-------------------------------- TinletProcess ---------------------------------------
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

 void TinletProcess ( )
{
  //Temperature of Ambient
  DWORD result = 0;
  WORD temp;

  temp = ADC.Tinlet_FF;


#if 0
  if ( temp > Temp_AD_PARAMETER )
  {
      if ( ( temp - Temp_AD_PARAMETER ) >= Temp_Table_Total_Number )
      {
          T_Inlet = 0;
      }
      else
      {
          T_Inlet = temp_table[temp - Temp_AD_PARAMETER];
      }
  }
  else
  {
      T_Inlet = 120;
  }
#else

  T_Inlet = CalculateNTSE0103FZD73Temp ( temp );

#endif

  //Check Ambient OTP
  if ( T_Inlet >= Parameter.OTP_Tinlet_FAULT_LIMIT )
  {
      if ( _SD_Flag.OTP_SD == 0 )
      {
          Protect.OTP_Tinlet.Flag = 1;
      }
  }
  else
  {
      Protect.OTP_Tinlet.Flag = 0;
      Protect.OTP_Tinlet.delay = 0;
  }

  if ( T_Inlet >= Parameter.OTP_Tinlet_WARN_LIMIT )
  {
      Protect.OTW_Tinlet.Flag = 1;
  }
  else
  {
      Protect.OTW_Tinlet.Flag = 0;
      Protect.OTW_Tinlet.delay = 0;

  }


  if ( _SD_Flag.OTP_SD )    
  {
      if ( T_Inlet < Parameter.OTP_Tinlet_Recovery_LIMIT )
      {
          Protect.OT_Recover_Tinlet.Flag = 1;
      }
      else
      {
          Protect.OT_Recover_Tinlet.Flag = 0;
          Protect.OT_Recover_Tinlet.delay = 0;
      }
  }

  //if ( gIsFactoryMode || ( PS.Uart1Error == FALSE && PS.Uart2Error == FALSE ) )
  if ( gIsFactoryMode || ( PS.Uart1Error == FALSE ) )         
  {
      result = LinearFmt_XtoY ( T_Inlet, 0, 0 ); //N is fixed 0
      if(! PS.I2C_Processing)   // 
      {
        gPmbusCmd.READ_TEMPERATURE_1[0] = result & 0xFF;
        gPmbusCmd.READ_TEMPERATURE_1[1] = ( result >> 8 ) & 0xFF;
      }
  }
  else
  {
      gPmbusCmd.READ_TEMPERATURE_1[0] = 0;
      gPmbusCmd.READ_TEMPERATURE_1[1] = 0;
  }

}

//-------------------------------- ResetSD_Flag ---------------------------------------
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void ResetSD_Flag ( )
{
  _SD_Flag.FAN_LOCK = 0;
  _SD_Flag.OVP_SD = 0;
  _SD_Flag.OTP_SD = 0;
  _SD_Flag.OCP_SD = 0;
  _SD_Flag.UV_SD = 0;
  //_SD_Flag.OPP_SD = 0;      // removed _SD_Flag.OPP_SD not use
  _SD_Flag.SCP_SD = 0;
  _SD_Flag.LATCH_SD = 0;
  _SD_Flag.STB_OCP = 0;
  _SD_Flag.STB_OTP = 0;   
  _SD_Flag.STB_UVP = 0;
  _SD_Flag.STB_OVP = 0;
  _SD_Flag.ISP_MODE = 0;
}

//-------------------------------- ResetSD_Flag ---------------------------------------
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void PSOnOff_ResetSD_Flag ( )		//  added
{
  _SD_Flag.FAN_LOCK = 0;
  _SD_Flag.OVP_SD = 0;
  _SD_Flag.OTP_SD = 0;
  _SD_Flag.OCP_SD = 0;
  _SD_Flag.UV_SD = 0;
 
  _SD_Flag.SCP_SD = 0;
  _SD_Flag.LATCH_SD = 0;
#if 0
  _SD_Flag.STB_OCP = 0;
  _SD_Flag.STB_OTP = 0;
  _SD_Flag.STB_UVP = 0;
  _SD_Flag.STB_OVP = 0;
#endif
  _SD_Flag.ISP_MODE = 0;
}

//-------------------------------- IsReportCmd ---------------------------------------
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
 BYTE IsReportCmd ( BYTE cmd )
{
  if ( cmd == 0x88 ||	//READ_VIN
       cmd == 0x89 ||	//READ_IIN
       cmd == 0x97 ||	//READ_PIN
       cmd == 0x8B ||	//READ_VOUT
       cmd == 0x8C ||	//READ_IOUT
       cmd == 0x96 ||	//READ_POUT
       cmd == 0x8D ||	//T1
       cmd == 0x8E ||	//T2
       cmd == 0x8F ||	//T3
       cmd == 0x90 )
  {	//FAN_SPEED_1
      return TRUE;
  }
  else
  {
      return FALSE;
  }
}

//-------------------------------- UpdateDebugInfo ---------------------------------------
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

 void UpdateDebugInfo ( )
{
  //For Command 0x77
  gPmbusCmd.DEBUG_INFO[0] = _SD_Flag.Val & 0xFF;
  gPmbusCmd.DEBUG_INFO[1] = ( _SD_Flag.Val >> 8 ) & 0xFF;
  gPmbusCmd.DEBUG_INFO[2] = STB.Enabled; //0; add
  gPmbusCmd.DEBUG_INFO[3] = MFR_Status.Val;        
  gPmbusCmd.DEBUG_INFO[4] = gPS_State.mainState;
  gPmbusCmd.DEBUG_INFO[5] = gPS_State.subState;

}

//-------------------------------- ---- ---------------------------------------
/************************************************************************
 * author:                     Edwin
 * description:            UpdateCSCali
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static void UpdateCSCali ( )
{
  gPmbusCmd.CALI_INFO[0] = UserData.Page2.region.Calibration_Flag.Val & 0xFF;
  gPmbusCmd.CALI_INFO[1] = ( UserData.Page2.region.Calibration_Flag.Val >> 8 ) & 0xFF;
}

//-------------------------------- ScanProcess ---------------------------------------
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void ScanProcess ( )
{
#ifdef debug
  gPmbusCmd.IIN_OC_WARN_LIMIT[0] = gPmbusCmd.CS_PWM_FB[0] & 0xFF;
  gPmbusCmd.IIN_OC_WARN_LIMIT[1] = gPmbusCmd.CS_PWM_FB[1] & 0xFF;
  gPmbusCmd.PIN_OP_WARN_LIMIT[0] = gPmbusCmd.CS_IN[0] & 0xFF; //ADC.ISHARE_IN & 0xFF;
  gPmbusCmd.PIN_OP_WARN_LIMIT[1] = gPmbusCmd.CS_IN[1] & 0xFF;	//(ADC.ISHARE_IN>>8) & 0xFF;
#endif

  //Input Information
#if WithTeridian
  
  //PS.U2RX_Updated = FALSE;
  VinProcess ( );            // pfc
  IinProcess ( );            // pfc
  PinProcess ( );            // pfc
  //}
#endif
  VoutProcess();
  IoutProcess ( );
  PoutProcess ( );
  TpriProcess ( );       //Temperature
  TsecProcess ( );
  TinletProcess ( );
  Fan1Monitor ( );   //Fan
  //Debug
  UpdateDebugInfo ( );
  UpdateCSCali ( );
  UpdateLog ( gPmbusCmd.LOG_INDEX[0] );
}
//---------------- T5Interrupt ---> ScanProcess ---------------------------------------

void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _T5Interrupt ( void )
{
  if ( PS.SaveBlackBox == FALSE )
  {
      ScanProcess ( );
  }
 
  IFS1bits.T5IF = 0;
}



