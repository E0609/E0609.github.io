/*****************************************************************************************
 *
 *Copyright (C) 2021 CIPS Singapore

 *                   LITE-ON TECHNOLOGY Corp.
 *
 *All Rights Reserved
 *
 *File Name : ISR.c
 *
 *Date : 2021.01.20
 *
 *Author :              Edwin
 *
 *Description :This Program used for HP 2400W ISR Program.
 *
 *******************************************************************************************/
#include "p33Exxxx.h"
#include "p33EP64GS506.h"     // cips
#include "Isr.h"
#include "Protection.h"
#include "Process.h"
#include "parameter.h"
#include "define.h"
#include "PowerOnOff.h"
#include "Init.h"
#include "I2c.h"
#include "Standby.h"
#include "PowerOnOff.h"
#include "Pmbus.h"
#include "Standby.h"
#include "Userdata.h"
#include "fbllc.h"
#include "Fan.h"
#include "Led.h"

#include "init.h"
// -------------Global Variable --------------------------------------------
tADC ADC;
tVref Vref;

// -------------Extern Variable --------------------------------------------
extern BYTE gPSU_ONOFF_Status;
extern tPSU_STATE gPS_State;
extern tTimerHandle hTimer;
extern tPS_FLAG PS;
extern tLLC HBLLC;
extern WORD Tsb_off_delay;
extern BYTE Tsb_off_delay_Flag;
// -----------------------------------------------------------------------

extern void ControlVref ( );
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _ADCAN0Interrupt ( )
{
    /*
   ADC_ISHARE_EXT  
     */
  ADC.ISHARE_EXT =  ADC_ISHARE_EXT ;
  ADC.ISHARE_EXT_LPF = ADC.ISHARE_EXT_LPF + ADC_ISHARE_EXT  - ADC.ISHARE_EXT_FF;
  ADC.ISHARE_EXT_FF = ADC.ISHARE_EXT_LPF >> 9;
  
  _ADCAN0IF = 0;

}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _ADCAN1Interrupt ( )
{
    /* ADC_V36V_DET      ADCBUF1
     */  
    
   SHORT result;
  ADC.V36V_DET = ADC_V36V_DET ;
  ADC.V36V_DET_LPF +=  ( ADC.V36V_DET- ADC.V36V_DET_FF);
  ADC.V36V_DET_FF= ADC.V36V_DET_LPF >> 9;  //9? GAIN 2e9?
  
  
  _ADCAN1IF = 0;
  
}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/


void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _ADCAN2Interrupt ( )
{
    /*   
     * AN2	ADC_ISHARE_IN
   */
  ADC.ISHARE_IN = ADC_ISHARE_IN;
  ADC.ISHARE_IN_LPF +=  (ADC.ISHARE_IN - ADC.ISHARE_IN_FF);
  ADC.ISHARE_IN_FF = ADC.ISHARE_IN_LPF >> 7;	// 2
 

#if 1//linker error
  {	//New Current Share Scheme
      static BYTE count = 0;
      if ( count >= 10 )
      {	// 200us         

        ControlVref ( );
          count = 0;
      }
      else
      {
          count ++;
      }
  }
#endif
  

    _ADCAN2IF = 0;
}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _ADCAN3Interrupt ( )
{
  /*
     ADC_I_OUT
   */
  //SHORT result;
  ADC.Iout = ADC_I_OUT;
  ADC.Iout_LPF = ADC.Iout_LPF + (ADC.Iout - ADC.Iout_FF);
  ADC.Iout_FF = ADC.Iout_LPF >> 7;	// 7?
  ADC.Iout_report_LPF = ADC.Iout_report_LPF + ADC.Iout - ADC.Iout_report_FF;
  ADC.Iout_report_FF = ADC.Iout_report_LPF >> 13; //13?

   //SCP
#if SC_PROTECT
    SC_protect_handler();
#endif
    
current_limit_handler();

  _ADCAN3IF= 0;

}

/************************************************************************
 * author:                     Edwin
 * description: 
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _ADCAN4Interrupt ( )
{
  /*
V36V_OUT
   */
#define softstart_level_1 16581 	   //8.V36V = 12.5x16581/25506
#define softstart_level_2 22108 	   //10.83v = 12.5x22108/25506

  SHORT result;
  ADC.V36V_OUT = ADC_V36V_OUT ;
  ADC.V36V_OUT_LPF +=  (ADC_V36V_OUT- ADC.V36V_OUT_FF);
  ADC.V36V_OUT_FF= ADC.V36V_OUT_LPF >> 9;  //9? GAIN 2e9?
    
  //OVP
  result = ( SHORT ) ADC_V36V_OUT+ ( SHORT ) gVoutReadOffsetAdc;
  if ( result < 0 )
  {
      result = 0;
  }
  if ( result > Parameter.OVP_VOUT_OV_WARN_LIMIT )
  {
      gPagePlusStatus.PAGE[PAGE0].STATUS_VOUT.bits.VOUT_OV_WARNING = 1;
  }


  if ( HBLLC.MainEnabled == TRUE )
  {
      if ( result > Parameter.OVP_VOUT_OV_FAULT_LIMIT )
      {
           App_Capture_Fault ( );  // cips
         App_Emergency_PowerOff( );
          _SD_Flag.OVP_SD = 1;
          _SD_Flag.LATCH_SD = 1;
          gPagePlusStatus.PAGE[PAGE0].STATUS_VOUT.bits.VOUT_OV_FAULT = 1;
      }
  }

    
  //------------------------- Main output Softstart--------------------------
  {
      static WORD cnt = 0;
	  //  #define DUTY_12V5_REF	            25506	// 12.5V
      if ( cnt >= SOFTSTART_SLOPE_ADJUSTMENT )
      {
          cnt = 0;
          if ( PS.Softstart )
          {  
              if ( Vref.SoftstartVoltage < softstart_level_1 )  // cips scaler with 1023 11 1111 1111       
              {
                  Vref.SoftstartVoltage += 256;
              }
              else
              {
                  if ( Vref.SoftstartVoltage < softstart_level_2 )     // 10.83V
                  {
                      Vref.SoftstartVoltage += 128;
                  }
                  else if ( Vref.SoftstartVoltage < Vref.SetVoltage )
                  {
                      Vref.SoftstartVoltage += 40;
                      if ( Vref.SoftstartVoltage >= Vref.SetVoltage )
                      {
                          Vref.SoftstartVoltage = Vref.SetVoltage;
                      }
                  }
              }
          }
          else
          {
              Vref.SoftstartVoltage = 0;
          }
      }
      else
      {
          cnt ++;
      }
  }
  // -----------------------------------------------------------------------

  _ADCAN4IF = 0;
}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _ADCAN5Interrupt ( )
{
    /*
     AN5	I_LLC_PRI
     */

  ADC.I_LLC_PRI_LPF=ADC.I_LLC_PRI_LPF + ADC_I_LLC_PRI - ADC.I_LLC_PRI_FF;
  ADC.I_LLC_PRI_FF = ADC.I_LLC_PRI_LPF >> 7;
  
#ifdef cips
  // protection for  ADC_I_LLC_PRI
  
#endif
  
 _ADCAN5IF = 0;
}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _ADCAN6Interrupt ( )
{
    // ADC_REMOTE_V_DET1  ADCBUF6 
    ADC.REMOTE_V_DET1 = ADC_REMOTE_V_DET1;
    ADC.REMOTE_V_DET1_LPF = ADC.REMOTE_V_DET1_LPF + (ADC_REMOTE_V_DET1 - ADC.REMOTE_V_DET1_FF);
    ADC.REMOTE_V_DET1_FF = ADC.REMOTE_V_DET1_LPF >> 5;
      
      
      _ADCAN6IF = 0;

}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _ADCAN7Interrupt ( )
{
  /*  REMOTE_V_DET2
   */
    ADC.REMOTE_V_DET2 = ADC_REMOTE_V_DET2;
    ADC.REMOTE_V_DET2_LPF = ADC.REMOTE_V_DET2_LPF + (ADC_REMOTE_V_DET2 - ADC.REMOTE_V_DET2_FF);
    ADC.REMOTE_V_DET2_FF = ADC.REMOTE_V_DET2_LPF >> 5;
    
#if DITHER_ENABLED
  {
      static BYTE cnt =  0;
      static WORD period = PWM_PERIOD_LOW;

      //Dither with 500Hz, 50/100
      //Dither with 2000Hz, 14/28
      if ( cnt >= 14 )
      {
          if ( cnt >= 28 )
          {
              cnt = 0;
          }
          else
          {
              cnt ++;

              if ( period < PWM_PERIOD_LOW )
              {
                 // period = period + DIFF_COUNT;
               period += DIFF_COUNT;  
              }
              PTPER = period;
              MDC = ( period >> 1 );
          }
      }
      else
      {
          cnt ++;

          if ( period > PWM_PERIOD_HIGH )
          {
              period = period - DIFF_COUNT;
          }
          PTPER = period;
          MDC = ( period >> 1 );
      }

  }
#endif
_ADCAN7IF = 0;
  IFS7 = IFS7 & 0b1111111111011111;
}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:    ADC_T_XFORM
 * history:
 * ***********************************************************************/
void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _ADCAN10Interrupt ( )
{
   ADC.T_XForm = ADCBUF10;
  ADC.T_XForm_LPF = ADC.T_XForm_LPF + ADC.T_XForm  - ADC.T_XForm_FF;
  ADC.T_XForm_FF = ADC.T_XForm_LPF >> 5;
  
  _ADCAN14IF = 0;

}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:                   T_SR
 * history:
 * ***********************************************************************/
void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _ADCAN11Interrupt ( )
{  
  ADC.Tsec = ADCBUF11;
  ADC.Tsec_LPF = ADC.Tsec_LPF + ADC.Tsec - ADC.Tsec_FF;
  ADC.Tsec_FF = ADC.Tsec_LPF >> 5;
  
_ADCAN11IF = 0;
}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/


void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _ADCAN13Interrupt ( )
{
  /*
  13: STB_5V_OUT_MCU
   */
  ADC.StbVout = ADC_5Vsb_DET;
  ADC.StbVout_LPF = ADC.StbVout_LPF + ADC.StbVout - ADC.StbVout_FF;
  ADC.StbVout_FF = ADC.StbVout_LPF >> 2;
   
#if 0 //? difference  
   ADC.StbVbus = ADC_STB_5V_OUT ;
  ADC.StbVbus_LPF = ADC.StbVbus_LPF + ADC.StbVbus - ADC.StbVbus_FF;
  ADC.StbVbus_FF = ADC.StbVbus_LPF >> 2;
#endif  
  
  if (  Tsb_off_delay > 200 ) 
  {
      //PFC voltage is under 260V, disable standby
      if (Tsb_off_delay_Flag == 0 )
      {
        drv_DisableSTBoutput ( );
        Tsb_off_delay_Flag = 1;
      }   
  }
  #if STB_OV_PROTECT
  Check_STBOVP ( );
#endif
 _ADCAN13IF = 0;

}


/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _ADCAN14Interrupt ( )
{
    //#define ADC_T_AMBIENT    ADCBUF14  
   ADC.Tinlet = ADCBUF14;
  ADC.Tinlet_LPF = ADC.Tinlet_LPF + ADC.Tinlet - ADC.Tinlet_FF;
  ADC.Tinlet_FF = ADC.Tinlet_LPF >> 5;
  
  _ADCAN14IF = 0;
}
#ifndef no_used
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
 void current_limit_handler()
{  
    

#if 1    //ConfigDD_SlaveSW  // special IC in V36V solution 
      if (ADC.Iout >= Parameter.CCM_IOUT_FAULT_HLIMIT)  // Iout>= 30A
      {    
            //oSD1 = SLAVE_SW_EN;   
      }
      else if (ADC.Iout < Parameter.CCM_IOUT_FAULT_LLIMIT)  // Iout < 10A
      {
           Protect.DD_SlaveSW_OFF.Flag = 1;

      }
#endif


 #if ConfigVout_CompSW
      if (ADC.Iout >= Parameter.CCM_VOUT_COMP_HLIMIT )  // Iout>= 60A
      {
          #if ConfigVout_CompSW
          Protect.MainVoutComp.Flag = 1;
          #endif

      }
      else if (ADC.Iout < Parameter.CCM_VOUT_COMP_LLIMIT)  // Iout < 10A
      {
          pin_o_ORING_EN_MCU  = 0;                      
          Protect.MainVoutComp.Flag = 0;    
          Protect.MainVoutComp.delay = 0;   
      }
      #endif
}
#endif
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

 void SC_protect_handler()
{
 #if cips
#else
  if ( ( ADC.V36V_OUT < VOUT_1V && PS.Softstart == TRUE && HBLLC.MainEnabled && PS.SC_CheckStart && ADC.Iout > Parameter.SCP_FAULT_LIMIT ) ||
       ( ADC.Iout > Parameter.SCP_FAULT_LIMIT && ADC.V36V_OUT< VOUT_2V && PS.Softstart == FALSE && HBLLC.MainEnabled )
       )
  {
      if ( ! _SD_Flag.Val )
      {
         App_Emergency_PowerOff( );
          _SD_Flag.SCP_SD = 1;
          _SD_Flag.LATCH_SD = 1;
          //20101209 added
          gPagePlusStatus.PAGE[PAGE0].STATUS_IOUT.bits.IOUT_OC_WARNING = 1;
          gPagePlusStatus.PAGE[PAGE1].STATUS_IOUT.bits.IOUT_OC_WARNING = 1;
          gPagePlusStatus.PAGE[PAGE0].STATUS_IOUT.bits.IOUT_OC_FAULT = 1;
          gPagePlusStatus.PAGE[PAGE1].STATUS_IOUT.bits.IOUT_OC_FAULT = 1;
          SaveToBlackBox ( );
          PS.SC_CheckStart = 0;
      }
  }
#endif

}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:                  ADC_I_DET_5Vsb   ADCBUF19
 * history:
 * ***********************************************************************/
void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _ADCAN19Interrupt ( )
{

  ADC.StbIout = ADC_I_DET_5Vsb;
  ADC.StbIout_LPF = ADC.StbIout_LPF + ADC.StbIout - ADC.StbIout_FF;
  ADC.StbIout_FF = ADC.StbIout_LPF >> 2;

    
 #if STB_SC_PROTECT
  Check_STBSCP ( );
#endif

  _ADCAN19IF = 0;

}








void __attribute__((__interrupt__,no_auto_psv)) _CNInterrupt(void)
{
/* Insert ISR Code Here*/
/* Clear Timer2 interrupt */
//IFS0bits.T2IF = 0;
}



void __attribute__((__interrupt__,no_auto_psv)) _OC1Interrupt(void)
{
/* Insert ISR Code Here*/
/* Clear Timer2 interrupt */
//IFS0bits.T2IF = 0;
}