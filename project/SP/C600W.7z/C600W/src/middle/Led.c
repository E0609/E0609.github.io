
#include "Led.h"
#include "Timer.h"
#include "Pmbus.h"
#include "Process.h"
#include "Sci.h"

static BYTE gSysCntl;
tLED_STATUS gLedStatus;


extern tPS_FLAG PS;

void init_Led ( )
{
  gSysCntl = FALSE;
  //gLedStatus.Val = 0;
}

static void SetLedBlinkGreen ( )
{
  static BYTE onoff = ON;
  if ( onoff )
  {
//	  drv_o_LED_ON;
            pin_o_LED_ON =LED_ON ;
  }
  else
  {
//	  drv_o_LED_DIS;
             pin_o_LED_ON=LED_OFF ;
  }
  onoff = ! onoff;
}





#if 0
static void  InputLedControl  ( BYTE status )
{
  static BYTE ghLedTimer = 0;
  static BYTE previous_status = 0;

  if ( status != previous_status )
  {
      if ( ghLedTimer )
      {
          KillTimer ( &ghLedTimer );
      }

      switch ( status )
      {
          case SOLID_GREEN:
              pin_o_LED_ON  = LED_ON;
              break;
          case BLINK_GREEN:
              ghLedTimer = SetTimer ( LED_BLINK_FREQ, SetLedBlinkGreen );	// 1 Hz
              break;
          case LED_OFF_STATUS:
              pin_o_LED_ON  = LED_OFF;
              break;

          default:
              break;
      }
  }

  previous_status = status;
}

#endif

void tsk_Led_PSU_Control (BYTE status  )
{

  static BYTE ghLedTimer = 0;
  static BYTE previous_status = 0;
  
   if ( status != previous_status )
   {
	   if ( ghLedTimer )
	   {
		   KillTimer ( &ghLedTimer );
	   }

  if ( gLedStatus.bits.ac_lost )
  {
//      drv_o_LED_DIS;
        pin_o_LED_ON = LED_OFF;
  }
  else if ( gLedStatus.bits.Power_ok )
  {
    // drv_o_LED_ON;
      pin_o_LED_ON = LED_ON;
  }
  else if ( gLedStatus.bits.stb_blinking )
  {
      ghLedTimer = SetTimer ( LED_BLINK_FREQ, SetLedBlinkGreen );	// 1 Hz
  }

  previous_status = status;
 }
}
 



