/*****************************************************************************************
 *
 *Copyright (C) 2021 CIPS Singapore

 *                   LITE-ON TECHNOLOGY Corp.
 *
 *All Rights Reserved
 *
 *File Name : Protection.c
 *
 *Date : 2021.01.20
 *
 *Author :              Edwin
 *
 *Description :This Program used for HP 2400W Protection Program.
 *
 *******************************************************************************************/
#include <string.h>
#include "Protection.h"
#include "Process.h"
#include "Isr.h"
#include "Parameter.h"
#include "I2c.h"
#include "Standby.h"
#include "PowerOnOff.h"
#include "Fan.h"
#include "Pmbus.h"
#include "UserData.h"
#include "Led.h"
#include "fbllc.h"
#include "Sci.h"


 WORD timeDifference;
extern QWORD SysTimerCount;
static QWORD LastTimerCount = 0;
extern tPSU_STATE gPS_State;
extern tPS_FLAG PS;
extern tLLC HBLLC;
extern unsigned int T_Pri;
extern unsigned int T_Sec;
extern unsigned int T_Inlet;
tProtectDelay Protect;
BYTE ConverterChangeInd = 0;
//extern void GetRapidOnStatus ( );	//for softstart

//------------------------ CheckDebounce ---------------------------------------------------------
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static void CheckDebounce ( BYTE* Flag, WORD* delay, WORD timeLimit, WORD timeDifference, _Pfn handler )
{
  if ( *Flag )
  {
      if ( *delay >= timeLimit )
      {
          *delay = 0;
          *Flag = 0;
          handler ( );
      }
      else
      {
          *delay += timeDifference;
      }
  }
  else
  {
      *delay = 0;
  }
}

//------------------------------ OCP_Handler -------------------------------------------------
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static void OCP_Handler ( )
{
  if ( HBLLC.MainEnabled == TRUE )
  {
      _SD_Flag.OCP_SD = 1;
      _SD_Flag.LATCH_SD = 1;
      gPagePlusStatus.PAGE[PAGE0].STATUS_IOUT.bits.IOUT_OC_FAULT = 1;

      App_Capture_Fault ( );
     App_Emergency_PowerOff( );
  }
}
//------------------------------ OCW_Handler -------------------------------------------------
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static void OCW_Handler ( )
{
  gPagePlusStatus.PAGE[PAGE0].STATUS_IOUT.bits.IOUT_OC_WARNING = 1;
  //gPagePlusStatus.PAGE[PAGE1].STATUS_IOUT.bits.IOUT_OC_WARNING = 1;   //

  MFR_Status.bits.V12_OCW = 1;
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static void CheckOCP ( )
{
  WORD result;

  if ( HBLLC.MainEnabled == TRUE )
  {
      if ( PS.IOUT1_CALIBRATED )
      {
          result = ADC.Iout_Cal;
      }
      else
      {
          result = ADC.Iout;
      }

      if ( result > Parameter.OCP_IOUT_OC_FAULT_LIMIT )
      {
          Protect.OCP.Flag = 1;
      }
      else
      {
          Protect.OCP.Flag = 0;
          Protect.OCP.delay = 0;
      }

      if ( result > Parameter.OCP_IOUT_OC_WARN_LIMIT )
      {
          Protect.OCW.Flag = 1;
      }
      else
      {
          Protect.OCW.Flag = 0;
          Protect.OCW.delay = 0;
          //gLedWarningStatus.bits.iout_oc_warning = 0;
      }
  }
  else
  {
      Protect.OCP.Flag = 0;
      Protect.OCP.delay = 0;
      Protect.OCW.Flag = 0;
      Protect.OCW.delay = 0;
  }

}

//------------------------------ SW_SLAVE_Handler -------------------------------------------------

#if 0//ConfigDD_SlaveSW
static void SW_SLAVE_Handler ( )
{
//    oSD1 = SLAVE_SW_DIS;   
}
#endif


#if ConfigVout_CompSW
static void VOUTCOMP_SW_Handler ()
{
  pin_o_ORING_EN_MCU  = 1;
}
#endif


/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static void SCP_Handler ( )
{
  //FW V42 Source code
  //if ( ! _SD_Flag.Val )

  //add
  if ( HBLLC.MainEnabled == TRUE )
  {
      App_Capture_Fault ( );
     App_Emergency_PowerOff( );
      _SD_Flag.SCP_SD = 1;
      _SD_Flag.LATCH_SD = 1;
      //20101209 added
      gPagePlusStatus.PAGE[PAGE0].STATUS_IOUT.bits.IOUT_OC_WARNING = 1;
      //gPagePlusStatus.PAGE[PAGE1].STATUS_IOUT.bits.IOUT_OC_WARNING = 1;   //
      gPagePlusStatus.PAGE[PAGE0].STATUS_IOUT.bits.IOUT_OC_FAULT = 1;
      //gPagePlusStatus.PAGE[PAGE1].STATUS_IOUT.bits.IOUT_OC_FAULT = 1;     //
      PS.SC_CheckStart = 0;
  }
}

#if 0
//------------------------------ OPP_Handler -------------------------------------------------

static void OPP_Handler ( )
{
  if ( ! _SD_Flag.Val )
  {
      App_Capture_Fault ( );
      _SD_Flag.OPP_SD = 1;
      _SD_Flag.LATCH_SD = 1;
      gPagePlusStatus.PAGE[PAGE0].STATUS_IOUT.bits.POUT_OP_FAULT = 1;
      gPagePlusStatus.PAGE[PAGE1].STATUS_IOUT.bits.POUT_OP_FAULT = 1;
      gPagePlusStatus.PAGE[PAGE0].STATUS_IOUT.bits.POUT_OP_WARNING = 1;
      gPagePlusStatus.PAGE[PAGE1].STATUS_IOUT.bits.POUT_OP_WARNING = 1;
     App_Emergency_PowerOff( );
  }
}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static void OPW_Handler ( )
{
  gPagePlusStatus.PAGE[PAGE0].STATUS_IOUT.bits.POUT_OP_WARNING = 1;
  gPagePlusStatus.PAGE[PAGE1].STATUS_IOUT.bits.POUT_OP_WARNING = 1;
}
#endif

//------------------------------ CheckPinOP -------------------------------------------------
#if 0

static void CheckPinOP ( )
{
  if ( gPin >= Parameter.PIN_OP_WARN_LIMIT )
  {
      Protect.PinOPW.Flag = 1;
  }
  else
  {
      Protect.PinOPW.Flag = 0;
      Protect.PinOPW.delay = 0;
  }
}

//------------------------------ PIN_OPW_Handler --------------------------------------------

static void PIN_OPW_Handler ( )
{
  gPagePlusStatus.PAGE[PAGE0].STATUS_INPUT.bits.PIN_OP_WARNING = 1;
  gPagePlusStatus.PAGE[PAGE1].STATUS_INPUT.bits.PIN_OP_WARNING = 1;
}
#endif
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
#if 0

static void CheckIinOC ( )
{
  if ( gPmbusCmd.MFR_LINE_STATUS[0].bits.IsHighLine )
  {
      if ( gIin >= Parameter.IIN_OC_WARN_HL_LIMIT )
      {
          Protect.IinOCW.Flag = 1;
      }
      else
      {
          Protect.IinOCW.Flag = 0;
          Protect.IinOCW.delay = 0;
      }
  }
  else
  {
      if ( gIin >= Parameter.IIN_OC_WARN_LL_LIMIT )
      {
          Protect.IinOCW.Flag = 1;
      }
      else
      {
          Protect.IinOCW.Flag = 0;
          Protect.IinOCW.delay = 0;
      }
  }
}

//------------------------------ IIN_OCW_Handler --------------------------------------------

static void IIN_OCW_Handler ( )
{
  gPagePlusStatus.PAGE[PAGE0].STATUS_INPUT.bits.IIN_OC_WARNING = 1;
  gPagePlusStatus.PAGE[PAGE1].STATUS_INPUT.bits.IIN_OC_WARNING = 1;
}
#endif
#if 0
//------------------------------ CheckOPP -------------------------------------------------

static void CheckOPP ( )
{
  WORD result;

  if ( HBLLC.MainEnabled == TRUE )
  {
      if ( PS.IOUT1_CALIBRATED )
      {
          result = ADC.Iout_Cal;
      }
      else
      {
          result = ADC.Iout;
      }

      if ( gPout > OPP_H_REF )
      {
          Protect.OPP.Flag = 1;
      }
      else
      {
          Protect.OPP.Flag = 0;
          Protect.OPP.delay = 0;
      }

      if ( gPout > Parameter.OPP_POUT_OP_WARN_LIMIT )
      {
          Protect.OPW.Flag = 1;
      }
      else
      {
          Protect.OPW.Flag = 0;
          Protect.OPW.delay = 0;
      }
  }
  else
  {
      Protect.OPP.Flag = 0;
      Protect.OPP.delay = 0;
      Protect.OPW.Flag = 0;
      Protect.OPW.delay = 0;
  }
}
#endif
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static void UVP_Handler ( )
{
  //FW V42 Source code
  //if ( ! _SD_Flag.Val )

  //add
  if ( HBLLC.MainEnabled == TRUE )
  {
      _SD_Flag.UV_SD = 1;
      _SD_Flag.LATCH_SD = 1;
      gPagePlusStatus.PAGE[PAGE0].STATUS_VOUT.bits.VOUT_UV_WARNING = 1;
      gPagePlusStatus.PAGE[PAGE0].STATUS_VOUT.bits.VOUT_UV_FAULT = 1;
      App_Capture_Fault ( );
     App_Emergency_PowerOff( );
  }
}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static void CheckUVP ( )
{
  SHORT result;

  if ( HBLLC.MainEnabled )
  {
      result = ( SHORT ) ADC.V36V_OUT_FF+ ( SHORT ) gVoutReadOffsetAdc;
      if ( result < 0 )
      {
          result = 0;
      }

      if ( PS.MAIN_PROTECT_START )
      {
          if ( result < Parameter.UVP_VOUT_UV_WARN_LIMIT )
          {
              gPagePlusStatus.PAGE[PAGE0].STATUS_VOUT.bits.VOUT_UV_WARNING = 1;
              //gLedWarningStatus.bits.vout_uv_warning = 1;
              MFR_Status.bits.V12_UVW = 1;
          }
          else
          {
              //gLedWarningStatus.bits.vout_uv_warning = 0;
          }
      }

      if ( result < Parameter.UVP_VOUT_UV_FAULT_LIMIT )
      {
          Protect.UVP.Flag = 1;
      }
      else
      {
          Protect.UVP.Flag = 0;
          Protect.UVP.delay = 0;
      }
  }
  else
  {
      Protect.UVP.Flag = 0;
      Protect.UVP.delay = 0;
  }
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static void OTP_HotSpot_Handler ( )
{
#if OT_PROTECT
  //FW V42 Source code
  //if ( ! _SD_Flag.Val )

  //add
  if ( HBLLC.MainEnabled == TRUE )
  {
      _SD_Flag.OTP_SD = 1;
      gPagePlusStatus.PAGE[PAGE0].STATUS_TEMPERATURE.bits.OT_FAULT = 1;
      App_Capture_Fault ( );
     App_Emergency_PowerOff( );
  }
#endif
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static void OTP_Ambient_Handler ( )
{
#if OT_PROTECT
  //FW V42 Source code
  //if ( ! _SD_Flag.Val )

  //add
  if ( HBLLC.MainEnabled == TRUE )
  {
      _SD_Flag.OTP_SD = 1;
      gPagePlusStatus.PAGE[PAGE1].STATUS_TEMPERATURE.bits.OT_FAULT = 1;
      App_Capture_Fault ( );
     App_Emergency_PowerOff( );
  }
#endif
}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static void OTW_HotSpot_Handler ( )
{
  gPagePlusStatus.PAGE[PAGE0].STATUS_TEMPERATURE.bits.OT_WARNING = 1;
  //gLedWarningStatus.bits.ot2_warning = 1;
  //gLedWarningStatus.bits.ot3_warning = 1;
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static void OTW_Ambient_Handler ( )
{
  gPagePlusStatus.PAGE[PAGE1].STATUS_TEMPERATURE.bits.OT_WARNING = 1;
  //gLedWarningStatus.bits.ot1_warning = 1;
}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static void OT_Recover_Handler ( )
{
  //if(T_Pri < DEFAULT_OT_RECOVERY && T_Sec < DEFAULT_OT_RECOVERY && T_Inlet < DEFAULT_OT_RECOVERY)
  if ( _SD_Flag.OTP_SD )
  {
      if ( T_Pri < Parameter.OTP_Tpri_Recovery_LIMIT && T_Sec < Parameter.OTP_Tsec_Recovery_LIMIT && T_Inlet < Parameter.OTP_Tinlet_Recovery_LIMIT )	// for thermal request
      {
          _SD_Flag.OTP_SD = 0;
          PS.OT_Recover = TRUE;
      }
  }
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static void PSON_H_Handler ( )
{
#if PSON_ENABLE
  PS.PS_ON_OFF = PS_ON_H;
#endif
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static void PSON_L_Handler ( )
{
#if PSON_ENABLE
  PS.PS_ON_OFF = PS_ON_L;
  //Protect.RMC_Removed.Flag = 1; //20141226 Added, //20170216 Removed
#endif
}
//--------------------------- PRESENT_H_Handler ----------------------------------------------
#if PRESENT_ENABLE  // 20150107 not used PRESENT
static void PRESENT_H_Handler ( )
{
#if PRESENT_ENABLE
  _SD_Flag.PRESENT_OFF = TRUE;
#endif
}
//--------------------------- PRESENT_L_Handler ----------------------------------------------
static void PRESENT_L_Handler ( )
{
#if PRESENT_ENABLE
  _SD_Flag.PRESENT_OFF = FALSE;
#endif
}
#endif

#ifdef no_used
//--------------------------- FanLock_Handler ------------------------------------------------

static void Fan1Lock_Handler ( )
{
#if FAN_LOCK_PROTECT

  if ( ! _SD_Flag.Val )
  {
      _SD_Flag.FAN_LOCK = 1;
      _SD_Flag.LATCH_SD = 1;

      gPmbusCmd.STATUS_FAN_1_2.bits.FAN1_FAULT = 1;

      App_Capture_Fault ( );
     App_Emergency_PowerOff( );
  }
//#else
  //add
  if ( _SD_Flag.FAN_LOCK == 0 )
  {
      _SD_Flag.FAN_LOCK = 1;
      gPmbusCmd.STATUS_FAN_1_2.bits.FAN1_FAULT = 1;
      App_Capture_Fault ( );
     App_Emergency_PowerOff( );
  }
#endif

}
#endif
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static void Fan1Fault_Handler ( )
{
  gPmbusCmd.STATUS_FAN_1_2.bits.FAN1_FAULT = 1;	
}

#ifdef no_used

static void Fan1Warning_Handler ( )
{
#if 1
  gPmbusCmd.STATUS_FAN_1_2.bits.FAN1_WARNING = 1;	
#endif
}
#endif
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static void Fan1DisappearHandler ( )
{
  PS.Fan1Disappear = 1;
}



/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static void FanRecover_Handler ( )
{
  if ( _SD_Flag.FAN_LOCK )
  {
      if ( gFan1.CurrentRpm > 500 && gFan1.Detected == TRUE && gFan2.CurrentRpm > 500 )
      {
          _SD_Flag.FAN_LOCK = 0;
          PS.Fan_Recover = TRUE;
      }

  }
  else
  {
      Protect.FanRecovery.delay = 0;
  }
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static void FanDutyCtrl_Handler ( )
{
  PS.FanDutyCtrl = 1;
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static void T_FanControlHandler ( )
{
  PS.FanControl = 1;	//Fan control timer
  //Check FanOverride
  if ( gFan1.OverridedDuty > GetFanMinDuty ( ) )
  {
      gPmbusCmd.STATUS_FAN_1_2.bits.FAN1_OVERRIDE = 1;
  }

}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static void SoftStart_Delay_Handler ( )
{
  PS.Softstart = TRUE;
  PS.SoftstartFinished = FALSE;
}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static void STB_OCP_Handler ( )
{
#if STB_OC_PROTECT
  if ( _SD_Flag.STB_OCP == FALSE )
  {
      _SD_Flag.STB_OCP = TRUE;
      gPagePlusStatus.PAGE[PAGE1].STATUS_IOUT.bits.IOUT_OC_FAULT = 1;       

      App_Capture_Fault ( );
      drv_DisableSTBoutput ( );
      App_Emergency_PowerOff( );
      PS.SaveBlackBox = 1;
  }
#endif
}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static void STB_OCW_Handler ( )
{
    gPagePlusStatus.PAGE[PAGE1].STATUS_IOUT.bits.IOUT_OC_WARNING = 1;   
}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static void STB_UVP_Handler ( )
{
#if STB_UV_PROTECT
  gPagePlusStatus.PAGE[PAGE1].STATUS_VOUT.bits.VOUT_UV_FAULT = 1;
  if ( _SD_Flag.STB_UVP == FALSE && _SD_Flag.STB_OCP == FALSE )
  {
      _SD_Flag.STB_UVP = TRUE;
      App_Capture_Fault ( );
      drv_DisableSTBoutput ( );
     App_Emergency_PowerOff( );
      PS.SaveBlackBox = 1;

  }
#endif
}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
void STB_UVW_Handler ( )
{

    gPagePlusStatus.PAGE[PAGE1].STATUS_VOUT.bits.VOUT_UV_WARNING = 1;   //20160201 added
    MFR_Status.bits.VSB_UVW = 1;                                        //20160201 added

}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static void STB_RETRY_Handler ( )
{
  _SD_Flag.STB_OCP = FALSE;
  _SD_Flag.STB_OVP = FALSE;
  _SD_Flag.STB_UVP = FALSE;
}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static void CheckI2C ( )
{
#if 1

  //if ( ( I2C1STATbits.S == 1 && I2C1CONbits.SCLREL == 0 ) || ( I2C1STATbits.S == 1 && I2C1STATbits.TBF == 1 ) )    //20160223_I2C
  if ( I2C1STATbits.S == 1 )    //20160321 changed
  {
      Protect.I2C_SCL_Fault.Flag = 1;
  }
  else
  {
      Protect.I2C_SCL_Fault.Flag = 0;
      Protect.I2C_SCL_Fault.delay = 0;
  }
#endif
#if 0
  if ( iSDA == LOW )
  {
      Protect.I2C_SDA_Fault.Flag = 1;
  }
  else
  {
      Protect.I2C_SDA_Fault.Flag = 0;
      Protect.I2C_SDA_Fault.delay = 0;
  }
#endif
}

//------------------------ TON_MAX_FAULT_Handler-----------------------------------------------
#if 0

static void TON_MAX_FAULT_Handler ( )
{
  gPagePlusStatus.PAGE[PAGE0].STATUS_VOUT.bits.TON_MAX_FAULT = 1;
  gPagePlusStatus.PAGE[PAGE1].STATUS_VOUT.bits.TON_MAX_FAULT = 1;
}
#endif




/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static void Uart1_WDT_Timeout ( )
{
  //gLedStatus.bits.comm_err = 1;	//Chris
  MFR_Status.bits.SCI_P2S_FAIL = 1;
  PS.Uart1Error = 1;           
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static void Uart1_PriRxWDT_Timeout ( )     
{
  //gLedStatus.bits.PriRXcomm_err = 1;            
  MFR_Status.bits.SCI_PriRx_FAIL = 1;        
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static void CumulatePOS ( WORD timeDifference )
{
  static WORD timer_1s = 0;
  static WORD BMCtimer_1s = 0;  // BMC_UNIX_TIMESTAMP cmd
  static DWORD timer_24hr = 0;

  //start couting after delivering output
  if ( ( gPS_State.mainState == STATE_NORMAL ) && ( HBLLC.MainEnabled == TRUE ) )
  {
      timer_1s += timeDifference;
      if ( timer_1s >= 1000 )
      {	//count 1 sec

          if ( MFR_POS_LAST.Val < 0xFFFFFFFF )        // Black Box block read
          {
              MFR_POS_LAST.Val ++;                    // Black Box block read
          }
          else
          {
              MFR_POS_LAST.Val = 0;                   // Black Box block read
          }
          strncpy ( ( char * ) &gPmbusCmd.MFR_POS_LAST[1], ( char * ) &MFR_POS_LAST.v[0], MFR_POS_LAST_LEN ); // Black Box block read



          if ( MFR_POS_TOTAL.Val < 0xFFFFFFFF )     // Black Box block read
          {
              MFR_POS_TOTAL.Val ++;                 // Black Box block read
          }
          else
          {
              MFR_POS_TOTAL.Val = 0;                // Black Box block read
          }
          strncpy ( ( char * ) &gPmbusCmd.MFR_POS_TOTAL[1], ( char * ) &MFR_POS_TOTAL.v[0], MFR_POS_TOTAL_LEN ); // Black Box block read


          //Calculate W*H
          UserData.Page3.region.logGeneral.Total_Output_Power.Val += gPout;

          //UserData.Page2.region.POS.Val = gPmbusCmd.MFR_POS_TOTAL.Val;        //m_PowerOffSeq
          UserData.Page2.region.POS.Val = MFR_POS_TOTAL.Val;                    // Black Box block read
          PS.FlashWritePage2 = TRUE;
          PS.FlashWritePage3 = TRUE;

          timer_1s = 0;
      }
  }

//  BMCtimer_1s += timeDifference;     BMC_UNIX_TIMESTAMP cmd
  if ( BMCtimer_1s >= 1000 )       //  BMC_UNIX_TIMESTAMP cmd
  {
//        //count 1 sec
//        if ( gPmbusCmd.BMC_UNIX_TIMESTAMP.Val < 0xFFFFFFFF )    //m_PowerOffSeq
//        {
//            gPmbusCmd.BMC_UNIX_TIMESTAMP.Val ++;                //m_PowerOffSeq
//        }
//        else
//        {
//            gPmbusCmd.BMC_UNIX_TIMESTAMP.Val = 0;               //m_PowerOffSeq
//        }

        //count 1 sec
        if ( BMC_UNIX_TIMESTAMP.Val < 0xFFFFFFFF )    // Black Box block read
        {
            BMC_UNIX_TIMESTAMP.Val ++;                // Black Box block read
        }
        else
        {
            BMC_UNIX_TIMESTAMP.Val = 0;               // Black Box block read
        }

        strncpy ( ( char * ) &gPmbusCmd.BMC_UNIX_TIMESTAMP[1], ( char * ) &BMC_UNIX_TIMESTAMP.v[0], BMC_UNIX_TIMESTAMP_LEN ); // Black Box block read
        BMCtimer_1s = 0;
  }

  

  timer_24hr += timeDifference;

  if ( timer_24hr >= 86400000 )
  {
      PS.Hr24_Expiry = 1;
      timer_24hr = 0;
  }

  Protect.u1WDT.Flag = 1; // U1Rx interrupt clear flag
  Protect.u2WDT.Flag = 1;

  
}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void PriIS_Handler ( )
{
 App_Emergency_PowerOff( );
  _SD_Flag.LATCH_SD = 1;
}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void DcRapidOnLow_Handler ( )
{
  PS.DC_RAPID_ON_LOW = 1;
}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void RS_Det_Handler ( )
{

//#if 1
  #if RS_ENABLE     
  SHORT result;

  if ( UserData.Page2.region.Calibration_Flag.bits.b0 )
  {
      result = ( ( SHORT ) ADC.ISHARE_EXT_FF + ( SHORT ) gMainBusVoutOffset + ( SHORT ) gVoutReadOffsetAdc );
      if ( result < 0 )
      {
          result = 0;
      }
      ADC.ISHARE_EXT_Cal = result;

      if ( ADC.ISHARE_EXT_FF < 50 )
      {
          //Remote Sense dissappear
          gVoutRSenseOffset = 0;
          return;
      }

      if ( gIsFactoryMode == FALSE )
      {
          if ( HBLLC.MainEnabled && HBLLC.InRegulation )
          {
              if ( ADC.ISHARE_EXT_Cal < Parameter.VOUT_RSENSE_VREFL )  //20151225 Note=> ADC.ISHARE_EXT_Cal<12.50v
              {
                  gVoutRSenseOffset += 2;
                  if ( gVoutRSenseOffset >= 400 )
                  {
                      gVoutRSenseOffset = 400;
                  }
              }
              else if ( ADC.ISHARE_EXT_Cal > Parameter.VOUT_RSENSE_VREFH ) //20151225 Note=> ADC.ISHARE_EXT_Cal<12.55v
              {
                  if ( gVoutRSenseOffset >= 2 )
                  {
                      gVoutRSenseOffset -= 2;
                  }
              }
          }
          else
          {
              gVoutRSenseOffset = 0;
          }
      }
      else
      {
          gVoutRSenseOffset = 0;
      }
  }
  else
  {
      gVoutRSenseOffset = 0;
  }

#endif
}

//-----------------------------------DummyLoadOFF_Handler-------------------------------------

void DummyLoadOFF_Handler ( )
{
  PS.DummyLoadOff = 1;
}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static void SciRetryHandler ( )
{
  PS.SCI_Retry = 1;
}

//--------------------------------- RmcRemoved_Handler ---------------------------------------

//void RmcRemoved_Handler ( )
//{
//  if ( gIsFactoryMode == FALSE )
//  {
//      if ( _SD_Flag.LATCH_SD == 0 )
//      {
//          PS.op_cmdChanged = TRUE;
//          gPmbusCmd.OPERATION[0] = 0x80;
//      }
//  }
//}


/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void HotPlugAddr_Handler ( )
{
    OneTimeFlag_HotPlug = 1;    
}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void VinUVFaultHandler ( )
{
  PS.VinUVFaultDetected = 1;
}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void VinUVWarningHandler ( )
{
  PS.VinUVWarnDetected = 1;
}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static void check_protect_Fan()
{
  //*************************	FAN	********************************************************************/
  CheckDebounce ( &Protect.Fan1Fault.Flag, &Protect.Fan1Fault.delay, FAN_FAULT_TIMER, timeDifference, Fan1Fault_Handler );
#if 0
  CheckDebounce ( &Protect.Fan1Warning.Flag, &Protect.Fan1Warning.delay, FAN_WARN_TIMER, timeDifference, Fan1Warning_Handler );
#endif
  //CheckDebounce ( &Protect.Fan1Lock.Flag, &Protect.Fan1Lock.delay, FAN_LOCK_TIMER, timeDifference, Fan1Lock_Handler );
  CheckDebounce ( &Protect.Fan1Disappear.Flag, &Protect.Fan1Disappear.delay, FAN_DISAPPEAR_TIMER, timeDifference, Fan1DisappearHandler );

    CheckDebounce ( &Protect.FanDutyCtrl.Flag, &Protect.FanDutyCtrl.delay, FAN_DUTY_CNTL_TIMER, timeDifference, FanDutyCtrl_Handler );
  CheckDebounce ( &Protect.T_FanControl.Flag, &Protect.T_FanControl.delay, FAN_CONTROL_TIMER, timeDifference, T_FanControlHandler );
  Protect.FanRecovery.Flag = 1;
  CheckDebounce ( &Protect.FanRecovery.Flag, &Protect.FanRecovery.delay, FAN_RECOVER_TIMER, timeDifference, FanRecover_Handler );

}

static void check_protect_OCP()
{
      //*************************	OCP	********************************************************************/
#if OC_PROTECT
  CheckOCP ( );
  CheckDebounce ( &Protect.OCP.Flag, &Protect.OCP.delay, OCP_DEBOUNCE_TIME, timeDifference, OCP_Handler );
  CheckDebounce ( &Protect.OCW.Flag, &Protect.OCW.delay, OCW_DEBOUNCE_TIME, timeDifference, OCW_Handler );
#endif
    
}


 static void check_protect_UVP()
 {
       //*************************	UVP	********************************************************************/
  CheckUVP ( );
#if UV_PROTECT
  CheckDebounce ( &Protect.UVP.Flag, &Protect.UVP.delay, UVP_DEBOUNCE_TIME, timeDifference, UVP_Handler );
#endif
 }
  static void check_protect_SCP()
   {
      //*************************	SCP	********************************************************************/
#if SC_PROTECT
  CheckDebounce ( &Protect.SCP.Flag, &Protect.SCP.delay, SCP_DEBOUNCE_TIME, timeDifference, SCP_Handler );
#endif
 }
 static void  check_protect_OTP()
  {
       //*************************	OTP	********************************************************************/
  CheckDebounce ( &Protect.OTP_Tpri.Flag, &Protect.OTP_Tpri.delay, OTP_TIMER, timeDifference, OTP_HotSpot_Handler );
  CheckDebounce ( &Protect.OTP_Tsec.Flag, &Protect.OTP_Tsec.delay, OTP_TIMER, timeDifference, OTP_HotSpot_Handler );
  CheckDebounce ( &Protect.OTP_Tinlet.Flag, &Protect.OTP_Tinlet.delay, OTP_TIMER, timeDifference, OTP_Ambient_Handler );

  CheckDebounce ( &Protect.OTW_Tpri.Flag, &Protect.OTW_Tpri.delay, OTW_TIMER, timeDifference, OTW_HotSpot_Handler );
  CheckDebounce ( &Protect.OTW_Tsec.Flag, &Protect.OTW_Tsec.delay, OTW_TIMER, timeDifference, OTW_HotSpot_Handler );
  CheckDebounce ( &Protect.OTW_Tinlet.Flag, &Protect.OTW_Tinlet.delay, OTW_TIMER, timeDifference, OTW_Ambient_Handler );

  CheckDebounce ( &Protect.OT_Recover_Tpri.Flag, &Protect.OT_Recover_Tpri.delay, OT_RECOVER_TIMER, timeDifference, OT_Recover_Handler );
  CheckDebounce ( &Protect.OT_Recover_Tsec.Flag, &Protect.OT_Recover_Tsec.delay, OT_RECOVER_TIMER, timeDifference, OT_Recover_Handler );
  CheckDebounce ( &Protect.OT_Recover_Tinlet.Flag, &Protect.OT_Recover_Tinlet.delay, OT_RECOVER_TIMER, timeDifference, OT_Recover_Handler );
 }
  static void check_protect_STB_Retry()
   {
       //*************************	Standby Protection	********************************************************/
  CheckDebounce ( &Protect.STB_RETRY.Flag, &Protect.STB_RETRY.delay, STB_RETRY_TIMER, timeDifference, STB_RETRY_Handler );
  //*************************	STB OCP	****************************************************************/
 }
  static void  check_protect_STB_OCP()
   {
     #if STB_OC_PROTECT
  Check_STBOCP ( );
  CheckDebounce ( &Protect.STB_OCP.Flag, &Protect.STB_OCP.delay, STB_OCP_DELAY_TIME, timeDifference, STB_OCP_Handler );
  CheckDebounce ( &Protect.STB_OCW.Flag, &Protect.STB_OCW.delay, STB_OCW_DELAY_TIME, timeDifference, STB_OCW_Handler ); 
#endif
 }
 static void  check_protect_STB_UVP()
  {
       //*************************	STB UVP	****************************************************************/
#if STB_UV_PROTECT
  Check_STBUVP ( );
  CheckDebounce ( &Protect.STB_UVP.Flag, &Protect.STB_UVP.delay, STB_UVP_DELAY_TIME, timeDifference, STB_UVP_Handler );
  CheckDebounce ( &Protect.STB_UVW.Flag, &Protect.STB_UVW.delay, STB_UVW_DELAY_TIME, timeDifference, STB_UVW_Handler ); //20160201 added
#endif
 }
  static void check_protect_I2C()
   {
       //*************************	I2C	********************************************************************/
  CheckI2C ( ); //20160223_I2C
  CheckDebounce ( &Protect.I2C_SCL_Fault.Flag, &Protect.I2C_SCL_Fault.delay, I2C_RESET_TIMER, timeDifference, init_I2C ); //20160223_I2C
  //CheckDebounce ( &Protect.I2C_SDA_Fault.Flag, &Protect.I2C_SDA_Fault.delay, I2C_RESET_TIMER, timeDifference, init_I2C );   // 20150107 removed

   CheckDebounce ( &Protect.HotPlugAddr.Flag, &Protect.HotPlugAddr.delay, HOTPLUG_ADDR_TIME, timeDifference, HotPlugAddr_Handler );    
 }
 static void check_protect_UART()
  {
   //*************************	Uart ********************************************************************/
  CheckDebounce ( &Protect.u1WDT.Flag, &Protect.u1WDT.delay, UART_WDT_TIME, timeDifference, Uart1_WDT_Timeout );	// for Lenovo spec
  CheckDebounce ( &Protect. u1PriRxWDT.Flag, &Protect. u1PriRxWDT.delay, UART_WDT_TIME, timeDifference, Uart1_PriRxWDT_Timeout );   

  CheckDebounce ( &Protect.SCI_Retry.Flag, &Protect.SCI_Retry.delay, SCI_RETRY_TIME, timeDifference, SciRetryHandler );
 }
 static void check_protect_PMBUS()
  {
      //************************* PMBus*******************************************************************/
 //CheckDebounce(&Protect.TON_MAX_Fault.Flag, &Protect.TON_MAX_Fault.delay, TON_MAX_TIMER, timeDifference, TON_MAX_FAULT_Handler);
  CumulatePOS ( timeDifference );
  CheckDebounce ( &Protect.VinUVFault.Flag, &Protect.VinUVFault.delay, VIN_UV_TIME, timeDifference, VinUVFaultHandler );
  CheckDebounce ( &Protect.VinUVWarning.Flag, &Protect.VinUVWarning.delay, VIN_UV_TIME, timeDifference, VinUVWarningHandler );
 }
  static void check_protect_PSON()
   {
     //*************************	Switch Signal*************************************************************/
  CheckDebounce ( &Protect.PSON_H.Flag, &Protect.PSON_H.delay, PSON_H_DEBOUNCE_TIME, timeDifference, PSON_H_Handler );
  CheckDebounce ( &Protect.PSON_L.Flag, &Protect.PSON_L.delay, PSON_L_DEBOUNCE_TIME, timeDifference, PSON_L_Handler );
 }

void ScanFault ( )
{
     //WORD timeDifference;
      timeDifference = ( WORD ) ( SysTimerCount - LastTimerCount );
      LastTimerCount = SysTimerCount;
      check_protect_OCP();
      check_protect_UVP();
      check_protect_SCP();
      check_protect_OTP();
       check_protect_STB_Retry();
      check_protect_STB_OCP();
      check_protect_STB_UVP();
     check_protect_Fan();
     check_protect_I2C();
     check_protect_UART();
     check_protect_PSON();
     check_protect_PMBUS();
  //************************* Soft Start ****************************************************************/
  CheckDebounce ( &Protect.SoftStart.Flag, &Protect.SoftStart.delay, SOFTSTART_DELAY_TIME, timeDifference, SoftStart_Delay_Handler );
  //************************* Current Share ************************************************************/
   CheckDebounce ( &Protect.PriIS.Flag, &Protect.PriIS.delay, PRI_IS_TIMER, timeDifference, PriIS_Handler );
  //************************* Remote Sense ************************************************************/
  #if RS_ENABLE   
  Protect.RS_Detect.Flag = 1;
  CheckDebounce ( &Protect.RS_Detect.Flag, &Protect.RS_Detect.delay, RS_DETECTION_TIME, timeDifference, RS_Det_Handler );
  #endif

}



