/***********************************************************************
 *
 *Copyright (C) 2021 CIPS Singapore

 *                   LITE-ON TECHNOLOGY Corp.
 *
 *All Rights Reserved
 *
 *File Name : Main.c
 *
 *Date : 2021.01.20
 *
 *Author :              Edwin Edwin
 *
 *Description :This Program used for HP 2400W Function Control Program.
 *
 **********************************************************************/
#include "xc.h"
#include "p33Exxxx.h"
#include "p33EP64GS506.h"     // cips

#include "define.h"
#include "Init.h"

#include "Timer.h"

#include "Process.h"

#include "Protection.h"
#include "Parameter.h"
#include "PowerOnOff.h"
#include "fbllc.h"
#include "Isr.h"
#include "UserData.h"
#include "PowerOnOff.h"
#include "Memory.h"
#include "I2c.h"
#include "Fan.h"
#include "Standby.h"
#include "Pmbus.h"
#include "Status.h"


#include "Sci.h"
#include "Led.h"
#include "Pec.h"

   
//Global Variable -->
tPSU_STATE gPS_State = { STATE_INIT, STATE_SUB_NONE };
tPS_FLAG PS;
tLLC HBLLC;

BYTE hTimerMainRaise = 0;	//20100825 added
BYTE hTimerStbRaise = 0;		//20100825 added

static BYTE previousState;         // cips
BYTE pson_state_changed =FALSE ;   //cips


//Global Variable <--
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static void InitPSU ( )
{
  init_SetupClock ( );
  init_GPIO ( );
  LoadUserDataFromFlash ( );
  init_Timer ( );
  init_ADC ( );
  init_PWM ( );
  init_Parameter ( );

  init_Fan ( );
  init_Pmbus ( );
  init_I2C ( );  // can remove?

  GetI2cAddr ( );
  init_I2C ( );
  
  init_Standby ( ); //wh
  ResetSD_Flag ( ); //wh
   


  
  init_Standby ( );
  init_crc8 ( );	//added for PEC 20100506
  ClearAllStatus ( 0xFF );
  ResetSD_Flag ( );



  ADCON1Lbits.ADON = 1;		//Turn on ADC module
  PTCONbits.PTEN = 1;		//Turn on PWM module
  
  //Initial main state
  gPS_State.mainState = STATE_STANDBY;
  gPS_State.subState = STATE_SUB_STANDBY_NORMAL;

  #if Config_WATCHDOG_TIMER
  //enable software watch dog timer
  _SWDTEN = 1;         
  #endif



}
//-------------------------Chech iAC_OK and iPFC_OK ------------------------------
#ifdef  cips //no needed
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static void CheckInputOK ( )
{

  static BYTE previousStatus = AC_N_GOOD;
 
  if ( iAC_OK == AC_GOOD )
  {
      if ( PS.VinOVFault == 1 || PS.VinUVFault == 1 )
      {
  //        oVIN_GOOD = VIN_N_GOOD;
      }
      else
      {
    //      oVIN_GOOD = VIN_GOOD;
      }

      if ( previousStatus == AC_N_GOOD )
      {
          //recover from AC_NOK
          if ( gPS_State.mainState == STATE_LATCH )
          {
              //leave Latch mode
              gPS_State.mainState = STATE_STANDBY;
              gPS_State.subState = STATE_SUB_STANDBY_NORMAL;
          }
      }

      if ( PS.AC_OFF_ClearFault )
      {
            PS.AC_OFF_ClearFault = FALSE;
            ResetSD_Flag ( );
      }

      //gLedStatus.bits.ac_loss = 0;
      PS.AC_ON_TO_OFF = FALSE;
      MFR_Status.bits.AC_NOTOK = FALSE;
      previousStatus = AC_GOOD;
  }
  else
  {
//      oVIN_GOOD = VIN_N_GOOD;

      if ( previousStatus == AC_GOOD )
      {

          PS.AC_ON_TO_OFF = TRUE;
      }
      MFR_Status.bits.AC_NOTOK = TRUE;

      previousStatus = AC_N_GOOD;
  }

  //Check PFC Status
#ifdef  cips// PFC_ENABLE
  if ( iPFC_OK == PFC_OK )
  {
      _SD_Flag.PFC_NOTOK = FALSE;
  }
  else
  {
      _SD_Flag.PFC_NOTOK = TRUE;
  }

  if ( Uart.U1.Rx.Pri_Status.bits.PFCDISABLE )
  {
      gPmbusCmd.MFR_PFC_DISABLE.bits.b0 = PFC_STATUS_DISABLE;	//update PFC status
  }
  else
  {
      gPmbusCmd.MFR_PFC_DISABLE.bits.b0 = PFC_STATUS_ENABLE;	//update PFC status
  }
#endif

}


#endif

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static void CheckPowerOn ( )
{
#if 0 // PFC_ENABLE
  if ( iPFC_OK == PFC_OK && ( _SD_Flag.Val & 0xDFFF ) == 0 && iAC_OK == AC_GOOD  && PS.VinOVFault == 0 && PS.VinUVFault == 0 && PS.Compatible_code == 0 )	//  HW_FW_Compatible Code Function
#endif
#if 0//cips
	if (  ( _SD_Flag.Val & 0xDFFF ) == 0 && PS.Compatible_code == 0 )   //  HW_FW_Compatible Code Function
#else
  if ( _SD_Flag.Val == 0 )
#endif
  {	
      m_PowerOnSeq ( &hTimer._Ton_delay, Ton_delay, m_TurnOnOutput );
      gPS_State.mainState = STATE_ONING;
      gPS_State.subState = STATE_SUB_ON;
  }
}
//------------------------------------------------------------------------------------------------
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
#if cips
#else
static void enter_power_out_status()
{
    if (_SD_Flag.OVP_SD || _SD_Flag.UV_SD || _SD_Flag.OCP_SD || _SD_Flag.SCP_SD) // modified, reomoved _SD_Flag.OPP_SD not use
    {
        gPS_State.mainState = STATE_LATCH;
        gPS_State.subState = STATE_SUB_PSON_H;
    }
    else
    {
        gPS_State.mainState = STATE_STANDBY;
        gPS_State.subState = STATE_SUB_STANDBY_NORMAL;
    }
}

#endif
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
#if cips
#else
static void enter_Offing()
{
    if (_SD_Flag.STB_OCP == FALSE)
    {
        if (gPS_State.mainState != STATE_STANDBY)
        {
            m_PowerOffSeq(&hTimer._Tpwok_off, Tpwok_off, m_ISR_Tpwok_off);
            gPS_State.mainState = STATE_OFFING;
            gPS_State.subState = STATE_SUB_NONE;
        }
    }
}
#endif
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static void CheckPowerOff ( )
{
#if 0//PFC_ENABLE
  if ( ( _SD_Flag.Val & 0xDFFF ) != 0 || iPFC_OK == PFC_NOK || PS.VinOVFault == 1 || PS.VinUVFault == 1 || PS.Compatible_code == 1 )
#endif
#if 0//cips
	  if (	( _SD_Flag.Val & 0xDFFF ) != 0 && PS.Compatible_code != 0 )   //  HW_FW_Compatible Code Function


#else
  if ( _SD_Flag.Val )
#endif
  {
      enter_power_out_status();  
  }
  else
      {
      enter_Offing();    
      }
  }

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

#if cips
#else
//------------------------------------------------------------------------------------------------
static void CheckSwitch_ipresent(){
//------------------ iPRESENT ---------------------------------------
#if  0//  PRESENT_ENABLE   //cips
    if (iPRESENT == HIGH)
    {
        if (_SD_Flag.PRESENT_OFF == FALSE)
        {
            Protect.PRESENT_H.Flag = 1;
        }

        Protect.PRESENT_L.Flag = 0;
        Protect.PRESENT_L.delay = 0;
    }
    else
    {
        if (_SD_Flag.PRESENT_OFF == TRUE)
        {
            Protect.PRESENT_L.Flag = 1;
        }
        Protect.PRESENT_H.Flag = 0;
        Protect.PRESENT_H.delay = 0;
    }
#endif
}
#endif

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static void CheckNextState ( )
{
  if ( _SD_Flag.LATCH_SD == 1 )
  {
      gPS_State.mainState = STATE_LATCH;
      gPS_State.subState = STATE_SUB_PSON_H;
  }
  else
  {
      gPS_State.mainState = STATE_STANDBY;
      gPS_State.subState = STATE_SUB_STANDBY_NORMAL;
  }

}


#if cips
#else


	/************************************************************************
	 * author:                     Edwin
	 * description:
	 * input:
	 * output:
	 * version:
	 * remark:
	 * history:
	 * ***********************************************************************/

    //------------------------------------------------------------------------------------------------
static void CheckSwitch_iPS_kill()
{
    
#if cips
    //------------------ iPS_KILL ---------------------------------------
    if (iPS_KILL == HIGH)
    {
        if (_SD_Flag.PS_KILL_OFF == FALSE)
        {
            Protect.PS_KILL_H.Flag = 1;
        }

        Protect.PS_KILL_L.Flag = 0;
        Protect.PS_KILL_L.delay = 0;
    }
    else
    {
        if (_SD_Flag.PS_KILL_OFF == TRUE)
        {
            Protect.PS_KILL_L.Flag = 1;
        }

        Protect.PS_KILL_H.Flag = 0;
        Protect.PS_KILL_H.delay = 0;
    }
#endif
}
#endif

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

#if cips
#else
static void check_iPS()
{
    
#if cips
    if (iPS_ON == HIGH)
    {
        if (PS.PS_ON_OFF == PS_ON_L)
        {
            Protect.PSON_H.Flag = 1;
        }
        Protect.PSON_L.Flag = 0;
        Protect.PSON_L.delay = 0;
    }
    else
    {
        if (PS.PS_ON_OFF == PS_ON_H)
        {
            Protect.PSON_L.Flag = 1;
        }
        Protect.PSON_H.Flag = 0;
        Protect.PSON_H.delay = 0;
    }
    
#endif
}

#endif



/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static BYTE Retrive_PreOp_Stata()
{
    BYTE temp=0;

    if (gPmbusCmd.OPERATION[0] == 0x00 || gPmbusCmd.OPERATION[0] == 0x40)
    {
        temp = OP_H;
    }
    else if (gPmbusCmd.OPERATION[0] == 0x80 || gPmbusCmd.OPERATION[0] == 0x94 ||
             gPmbusCmd.OPERATION[0] == 0x98 || gPmbusCmd.OPERATION[0] == 0xA4 || gPmbusCmd.OPERATION[0] == 0xA8)
    {
        temp = OP_L;
    }
    return temp;
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

#if 1 // cips
//
static void CheckSwitch_init_status()
{
    _SD_Flag.PS_ON_OFF = TRUE;
    PS.PS_ON_OFF = PS_ON_L;
    pson_state_changed = FALSE;
    PS.Stb_PSON_L = 1;
    PS.Stb_OP_OFF = 0;
}
#endif


/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static void reset_sdb_flag()
{
    _SD_Flag.PS_ON_OFF = FALSE;
    PS.Stb_PSON_L = 0;
    PS.Stb_OP_OFF = 0;
    //ClearAllStatus(0xFF);
    PSOnOff_ResetSD_Flag();
    pson_state_changed = FALSE;
	
    PS.OT_Recover = FALSE;
    PS.Fan_Recover = FALSE;
}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static void CheckSwitch ( )
{
  static BYTE prePSONState = PS_ON_H;
  static BYTE preOPState = OP_H;
  static BYTE preOP = 0x80;
  
  BYTE pson_state_changed = FALSE;
  BYTE op_state_changed = FALSE;

  //------------------ iPS_ON ------------------------------------------


  if(PS.MFR_PSON_CONTROL == 1 )         
  {
      check_iPS();
  }
  else
  {
      CheckSwitch_init_status();  
  }

  if ( prePSONState != PS.PS_ON_OFF )
  {
      pson_state_changed = TRUE;
      prePSONState = PS.PS_ON_OFF;
  }

  if ( (PS.MFR_PSON_CONTROL == 1 ) && ( preOP != gPmbusCmd.OPERATION[0] || PS.op_cmdChanged == TRUE ) )     
  {
      op_state_changed = TRUE;
      PS.op_cmdChanged = FALSE;
#if cips
      if ( gPmbusCmd.OPERATION[0] == 0x00 || gPmbusCmd.OPERATION[0] == 0x40 )
      {
          preOPState = OP_H;
      }
      else if ( gPmbusCmd.OPERATION[0] == 0x80 || gPmbusCmd.OPERATION[0] == 0x94 ||
            gPmbusCmd.OPERATION[0] == 0x98 || gPmbusCmd.OPERATION[0] == 0xA4 || gPmbusCmd.OPERATION[0] == 0xA8 )
      {
          preOPState = OP_L;
      }
      #else
      preOPState= Retrive_PreOp_Stata();

#endif
      preOP = gPmbusCmd.OPERATION[0];
  }

  if ( _SD_Flag.PS_ON_OFF == TRUE )
  {
      /*Turn On PSU*/
      if ( pson_state_changed == TRUE && prePSONState == PS_ON_H )
      //if ( pson_state_changed == TRUE && prePSONState == PS_ON_H && PS.MFR_PSON_CONTROL == 1)
      {
          pson_state_changed = FALSE;
          reset_sdb_flag(); 
      }
      else if ( op_state_changed == TRUE && preOPState == OP_L )
      {
          op_state_changed = FALSE;
          reset_sdb_flag();
      }
  }
  else
  {
      /*Turn Off PSU*/
   
     
      if ( pson_state_changed == TRUE && prePSONState == PS_ON_L )
      {
          _SD_Flag.PS_ON_OFF = TRUE;
          pson_state_changed = FALSE;
          PS.Stb_PSON_L = 1;
          PS.Stb_OP_OFF = 0;
      }
      else if ( op_state_changed == TRUE && preOPState == OP_H )
      {

          _SD_Flag.PS_ON_OFF = TRUE;
          op_state_changed = FALSE;
          PS.Stb_PSON_L = 0;
          PS.Stb_OP_OFF = 1;
      }

  }
 CheckSwitch_ipresent();
 CheckSwitch_iPS_kill();
 // #endif
}
//#endif
//------------------------------------------------------------------------------------------------
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static void GoBLMode ( )
{
  #if Config_WATCHDOG_TIMER
  //disable watch dog timer
  _SWDTEN = 0;     
  #endif

  //disable all interrupts before jump to bootloader -->
  //disable Timer

  IEC0 = 0;
  IEC1 = 0;
  IEC2 = 0;
  IEC3 = 0;
  IEC4 = 0;
  IEC5 = 0;
  IEC6 = 0;
  IEC7 = 0;
  PTCONbits.PTEN = 0;				//Disable PWM

  //disable all interrupts before jump to bootloader <--

  RCON = 0;	//Reset control register

  asm("goto %0" : : "r"( BOOTLOADER_ADDR ) );
}

//------------------------------------------------------------------------------------------------
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static void MAIN_UV_START_Handler ( )
{
  KillTimer ( &hTimerMainRaise );
  PS.MAIN_PROTECT_START = TRUE;
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static void STB_UV_START_Handler ( )
{
  KillTimer ( &hTimerStbRaise );
  PS.STB_UV_START = TRUE;
}

//------------------------------------------------------------------------------------------------
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static void DoStateStandby ( )
{
 // StatusToPrimary.bits.isStandbyMode = 1; // needed
  if ( _SD_Flag.ISP_MODE )
  {
      GoBLMode ( );
  }
  if ( _SD_Flag.STB_OCP || _SD_Flag.STB_OVP || _SD_Flag.STB_UVP )
  {
      gPS_State.subState = STATE_SUB_STANDBY_HICCUP;
  }
  else
  {
      gPS_State.subState = STATE_SUB_STANDBY_NORMAL;
  }
  gPagePlusStatus.PAGE[PAGE0].STATUS_WORD.bits._OFF = TRUE;
  gPagePlusStatus.PAGE[PAGE1].STATUS_WORD.bits._OFF = TRUE;
  gPagePlusStatus.PAGE[PAGE0].STATUS_WORD.bits.POWER_GOOD = TRUE;
  gPagePlusStatus.PAGE[PAGE1].STATUS_WORD.bits.POWER_GOOD = TRUE;
  
  if ( hTimerMainRaise )
  {
      KillTimer ( &hTimerMainRaise );
      PS.MAIN_PROTECT_START = FALSE;
  }
  
  switch ( gPS_State.subState )
  {
      case STATE_SUB_STANDBY_HICCUP:
          //Disable Standby /
          if ( hTimerStbRaise )
          {
              KillTimer ( &hTimerStbRaise );
              PS.STB_UV_START = FALSE;
          }
          PS.MAIN_PROTECT_START = FALSE;
          PS.STB_UV_START = FALSE;
          drv_DisableSTBoutput ( );
          Protect.STB_RETRY.Flag = 1; //start retry timer 1000 ms
          break;
      case STATE_SUB_STANDBY_NORMAL:
          //Enable Standby output
#if 0//PFC_ENABLE
          if ( iPFC_OK == PFC_OK )
          {	//20100825
              if ( ! PS.STB_UV_START )
              {
                  //if ( hTimerStbRaise == 0 )
                  if ( hTimerStbRaise == 0 && _SD_Flag.PS_KILL_OFF == FALSE )       
                  {
                      hTimerStbRaise = SetTimer ( STB_RAISE_TIME, STB_UV_START_Handler );
                  }
              }
              if ( _SD_Flag.PS_KILL_OFF == FALSE )
              {
                  drv_EnableSTBoutput ( );
              }
              else
              {
                  drv_DisableSTBoutput ( );
              }
          }
#else
          drv_EnableSTBoutput ( );
#endif
          break;
      default:

          break;
  }
  CheckPowerOn ( );
  EnableFan ( );
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static void PSU_ONOFF_SUBON_Status_handler()
{
    switch (gPSU_ONOFF_Status)
    {
    case PowerGood:
        gPS_State.mainState = STATE_ONING;
        gPS_State.subState = STATE_SUB_WAIT_OUTPUT_STABLE;
        break;

    case PowerOning:
        MFR_POS_LAST.Val = 0; //Reset POS Last                // Black Box block read
        if (!PS.MAIN_PROTECT_START)
        {
            if (HBLLC.MainEnabled && (hTimerMainRaise == 0))
            {
                hTimerMainRaise = SetTimer(MAIN_RAISE_TIME, MAIN_UV_START_Handler);
            }
        }
        break;

    case PowerReady:
        break;

    case PowerOffing:
        gPS_State.mainState = STATE_OFFING;
        gPS_State.subState = STATE_SUB_NONE;
        break;

    case PowerOff:
        CheckNextState();
        break;
    }
}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static void DoStateOning ( )
{
  switch ( gPS_State.subState )
  {
      case STATE_SUB_ON:
          PSU_ONOFF_SUBON_Status_handler();
          break;

      case STATE_SUB_WAIT_OUTPUT_STABLE:
          if ( gPSU_ONOFF_Status == PowerGood )
          {
              gPS_State.mainState = STATE_NORMAL;
              gPS_State.subState = STATE_SUB_NORMAL;
          }
          break;

      default:

          break;
  }
  CheckPowerOff ( );
}


//------------------------------------------------------------------------------------------------

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static void Hicuup_mode_handler()  
{
    if (_SD_Flag.STB_OCP)
    {
        
        if (hTimerStbRaise)
        {
            KillTimer(&hTimerStbRaise);
           
        }

        PS.STB_UV_START = FALSE;
        drv_DisableSTBoutput();
        Protect.STB_RETRY.Flag = 1; //start retry timer 1000 ms
    }
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static void UV_mode_handler()
{
#if cips
    if ((iPFC_OK == PFC_OK) && (!_SD_Flag.STB_OCP))
#endif
        
    if ( (!_SD_Flag.STB_OCP))
    { 
        if (!PS.STB_UV_START)
        {
            //if ( hTimerStbRaise == 0 )
            if (hTimerStbRaise == 0 && _SD_Flag.PS_KILL_OFF == FALSE) 
            {
                hTimerStbRaise = SetTimer(STB_RAISE_TIME, STB_UV_START_Handler);
            }
        }

        if (_SD_Flag.PS_KILL_OFF == FALSE)
        {
            drv_EnableSTBoutput();
        }
        else
        {
            drv_DisableSTBoutput();
        }
    }
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static void DoStateNormal()
{
  SHORT result;

//  StatusToPrimary.bits.isStandbyMode = 0;  // cips skip pfc 
  result = ( SHORT ) ADC.V36V_OUT_FF+ ( SHORT ) gVoutReadOffsetAdc;
  if ( result < 0 )
  {
      result = 0;
  }
  Hicuup_mode_handler();
  UV_mode_handler();
                           //Check the condition to shutdown V36V main
  CheckPowerOff();
}
//------------------------------------------------------------------------------------------------
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static void DoStateOffing ( )
{
  switch ( gPSU_ONOFF_Status )
  {
      case PowerOning:
          gPS_State.mainState = STATE_ONING;
          gPS_State.subState = STATE_SUB_ON;
          break;
      case PowerReady:
          break;
      case PowerGood:
          break;
      case PowerOffing:
          break;
      case PowerOff:
          CheckNextState ( );
          break;
  }

  if ( hTimerMainRaise )
  {
      KillTimer ( &hTimerMainRaise );
      PS.MAIN_PROTECT_START = FALSE;
  }
  CheckPowerOn ( );
}
//------------------------------------------------------------------------------------------------
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static void State_SUB_Latch_Handler()
{
	switch ( gPS_State.subState )
	  {
		  case STATE_SUB_PSON_L:
			  if ( _SD_Flag.PS_ON_OFF == FALSE )
			  {
				  previousState = gPS_State.subState;
				  gPS_State.mainState = STATE_LATCH;
				  gPS_State.subState = STATE_SUB_PSON_H;
			  }
			  break;
	
		  case STATE_SUB_PSON_H:
			  if ( _SD_Flag.PS_ON_OFF == TRUE )
			  {
				  previousState = gPS_State.subState;
				  gPS_State.mainState = STATE_LATCH;
				  gPS_State.subState = STATE_SUB_PSON_L;
			  }
			  else
			  {
				  if ( previousState == STATE_SUB_PSON_L )
				  {
					  previousState = gPS_State.subState;
					  gPS_State.mainState = STATE_STANDBY;
					  gPS_State.subState = STATE_SUB_STANDBY_NORMAL;
				  }
			  }
			  break;
	  }


}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static void DoStateLatch ( )
{
 // static BYTE previousState;

//  StatusToPrimary.bits.isStandbyMode = 1;                       // skip primary side 

  gPagePlusStatus.PAGE[PAGE0].STATUS_WORD.bits._OFF = TRUE;
  gPagePlusStatus.PAGE[PAGE1].STATUS_WORD.bits._OFF = TRUE;
  
  gPagePlusStatus.PAGE[PAGE0].STATUS_WORD.bits.POWER_GOOD = TRUE;
  gPagePlusStatus.PAGE[PAGE1].STATUS_WORD.bits.POWER_GOOD = TRUE;
  
  if ( hTimerMainRaise )
  {
      KillTimer ( &hTimerMainRaise );
      PS.MAIN_PROTECT_START = FALSE;
  }
  State_SUB_Latch_Handler();
  Hicuup_mode_handler();
  UV_mode_handler();
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/


#if 1//cips
//--------------------------- SoftStart Vref.SoftstartVoltage ------------------------
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void ControlVref ( )
{
  if ( HBLLC.MainEnabled )
  {
      #if RS_ENABLE 
      Vref.SetVoltage = ( WORD ) ( gVoutCmd + gVoutCmdOffset + gVoutCshareOffset + gVoutRSenseOffset );
      #else
      Vref.SetVoltage = ( WORD ) ( gVoutCmd + gVoutCmdOffset + gVoutCshareOffset );
      #endif


      if ( PS.Softstart )
      {
          if ( Vref.SetVoltage > Vref.SoftstartVoltage )
          {
              PDC4 = Vref.SoftstartVoltage;
              Vref.OldSetVoltage = 0;
          }
          else
          {
              PS.Softstart = FALSE;
              PS.SoftstartFinished = TRUE;
			  
#ifdef cips
              Enable_CurrentShare ( );
#endif
          }
      }
      else
      {
          if ( PS.SoftstartFinished )
          {
              if ( Vref.SetVoltage != Vref.OldSetVoltage )
              {
                  PDC4 = Vref.SetVoltage;
                  Vref.OldSetVoltage = Vref.SetVoltage;
              }
          }
      }
  }
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static void FlashWrite ( )
{

 #if cips
//#else
#define Con_IOUT (( gPagePlusStatus.PAGE[PAGE0].STATUS_WORD.bits.IOUT == 1 && previous_StatusWord[PAGE0].bits.IOUT == 0 ) \
            || ( gPagePlusStatus.PAGE[PAGE1].STATUS_WORD.bits.IOUT == 1 && previous_StatusWord[PAGE1].bits.IOUT == 0 ))
         
#endif


  static BYTE OCW_Count = 0;
  static BYTE UVW_Count = 0;

  if ( PS.SaveBlackBox == TRUE )
  {
      PS.SaveBlackBox = FALSE;
      SaveToBlackBox ( );
  }

  //Update latest Log in RAM
  {
      static tSTATUS_WORD previous_StatusWord[2] = {
          {0x2848 },
          {0x2848 } };
      static WORD previous_SD_FLAG = 0x0000;
      static BYTE previous_MFR_Status = 0x00;
      static BYTE status_changed = FALSE;   

  
      //Changed in Status_Iout
      if ( ( gPagePlusStatus.PAGE[PAGE0].STATUS_WORD.bits.IOUT == 1 && previous_StatusWord[PAGE0].bits.IOUT == 0 )
           || ( gPagePlusStatus.PAGE[PAGE1].STATUS_WORD.bits.IOUT == 1 && previous_StatusWord[PAGE1].bits.IOUT == 0 ) )
      {
          if ( gPagePlusStatus.PAGE[PAGE0].STATUS_IOUT.bits.IOUT_OC_WARNING == 1 || gPagePlusStatus.PAGE[PAGE1].STATUS_IOUT.bits.IOUT_OC_WARNING == 1 )
          {
              if ( OCW_Count < 3 )
              {
                  status_changed = TRUE;
                  OCW_Count ++;
              }
          }
          else
          {
              status_changed = TRUE;
          }
      }

      //Changed in Status_Vout
      if ( ( gPagePlusStatus.PAGE[PAGE0].STATUS_WORD.bits.VOUT == 1 && previous_StatusWord[PAGE0].bits.VOUT == 0 )
           || ( gPagePlusStatus.PAGE[PAGE1].STATUS_WORD.bits.VOUT == 1 && previous_StatusWord[PAGE1].bits.VOUT == 0 ) )
      {
          if ( gPagePlusStatus.PAGE[PAGE0].STATUS_VOUT.bits.VOUT_UV_WARNING == 1 || gPagePlusStatus.PAGE[PAGE1].STATUS_VOUT.bits.VOUT_UV_WARNING == 1 )
          {
              if ( UVW_Count < 3 )
              {
                  status_changed = TRUE;
                  UVW_Count ++;
              }
          }
      }

      //Changed in Status_Temperature
      if ( ( gPagePlusStatus.PAGE[PAGE0].STATUS_WORD.bits.TEMPERATURE == 1 && previous_StatusWord[PAGE0].bits.TEMPERATURE == 0 )
           || ( gPagePlusStatus.PAGE[PAGE1].STATUS_WORD.bits.TEMPERATURE == 1 && previous_StatusWord[PAGE1].bits.TEMPERATURE == 0 ) )
      {
          status_changed = TRUE;
      }

      //Changed in PG
      if ( ( gPagePlusStatus.PAGE[PAGE0].STATUS_WORD.bits.POWER_GOOD == 1 && previous_StatusWord[PAGE0].bits.POWER_GOOD == 0 )
           || ( gPagePlusStatus.PAGE[PAGE1].STATUS_WORD.bits.POWER_GOOD == 1 && previous_StatusWord[PAGE1].bits.POWER_GOOD == 0 ) )
      {
          status_changed = TRUE;
      }

      //Changed in SD_FLAG
      if ( _SD_Flag.Val != 0 && previous_SD_FLAG != _SD_Flag.Val )
      {
          status_changed = TRUE;
      }
      previous_SD_FLAG = _SD_Flag.Val;

      //Changed in MFR_Status
      if ( MFR_Status.Val != 0 && previous_MFR_Status != MFR_Status.Val )
      {
          status_changed = TRUE;
      }
      previous_MFR_Status = MFR_Status.Val;
      if ( status_changed == TRUE )
      {
          status_changed = FALSE;
          SaveToLogContent ( );
      }

      previous_StatusWord[PAGE0].Val = gPagePlusStatus.PAGE[PAGE0].STATUS_WORD.Val;
      previous_StatusWord[PAGE1].Val = gPagePlusStatus.PAGE[PAGE1].STATUS_WORD.Val;
  }

  //Write FRU or Calibration data to Flash if needed
  if ( PS.FlashWritePage1 == TRUE )
  {
      SaveUserDataPage1ToFlash ( );
      PS.FlashWritePage1 = FALSE;
  }

  //Updating blackbox once AC loss
  if ( PS.AC_ON_TO_OFF == TRUE )
  {
      if ( ( PS.FlashWritePage2 == TRUE ) && ( HBLLC.MainEnabled == FALSE ) )
      {
          SaveUserDataPage2ToFlash ( );
          PS.FlashWritePage2 = FALSE;
      }

      if ( ( PS.FlashWritePage3 == TRUE ) && ( HBLLC.MainEnabled == FALSE ) )
      {
          SaveUserDataPage3ToFlash ( );
          PS.FlashWritePage3 = FALSE;
      }
  }

  //Updating blackbox every 24hr
  if ( PS.Hr24_Expiry == 1 )
  {
      PS.Hr24_Expiry = 0;
      OCW_Count = 0;
      UVW_Count = 0;
      if ( PS.FlashWritePage3 == TRUE )
      {
          SaveUserDataPage3ToFlash ( );
          PS.FlashWritePage3 = FALSE;
      }
  }
}

#endif

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

#if  RS_ENABLE   
static void RS_Control ( )
{
  if ((SFB.MainEnabled ) && ( HBLLC.InRegulation ))
  {
          pin_o_ORING_EN_MCU  = RS_ON;
  }   
  else
  {
      pin_o_ORING_EN_MCU  = RS_OFF;
  }
}
#endif
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/


static void statehandler()
{

    switch (gPS_State.mainState)
    {
    case STATE_STANDBY:
        DoStateStandby();
        break;
    case STATE_ONING:
       DoStateOning();
        break;
    case STATE_NORMAL:
        DoStateNormal();
        break;
    case STATE_OFFING:
       DoStateOffing();
        break;
    case STATE_LATCH:
        DoStateLatch();
        break;
    default:

        break;
    }
    
}


/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
int main ( )
{
  InitPSU ( );
  while ( 1 )
  {
           #if Config_WATCHDOG_TIMER
           ClrWdt();                                                                          // Clear WDT Counter,
           #endif 
            statehandler();	
            GetI2cAddr ( );
            CheckSwitch ( );                                                            //PS_ON Switch
            ScanFault ( );
           UpdateFanDuty ( );
            CheckInputOK ( );
            OutputControl ( );
           CheckICAOV ( );                                                                // i2c 1  // Edwin only debgug?

            StandbyVoltageControl ( );
      #if RS_ENABLE
            RS_Control ( );
      #endif

       //GetRapidOnStatus();	                                               //for softstart
            RefreshStatus ( );
           FlashWrite ( );
           VoutProcess ( );	                                                          //Move here for Inventec issue
  }

  return 0;
}
/*****************************************************************************************/
/*****************************************************************************************/
/*****************************************************************************************/








