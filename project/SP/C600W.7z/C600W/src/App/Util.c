
#include "Define.h"

//power function for direct format
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

WORD power ( BYTE x, BYTE n )
{
  if ( n == 0 )
  {
      return 1;
  }

  if ( n > 1 )
  {
      return ( WORD ) x * power ( x, n - 1 ); // n=1,return x; n=2, x*x;n=3, return x*x*x
  }
  //when n = 1
  return x;
}


//Encode as direct format
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

WORD EncodeAsDirectFmt ( WORD x, WORD m, WORD b, BYTE r )
{
  WORD result;

  if ( r & 0x80 )
  {	//r is negative
      result = ( ( m * x ) + b ) / ( power ( 10, ( 0x100 - r ) ) );
  }
  else
  {	//r is positive
      result = ( ( m * x ) + b )*( power ( 10, r ) );
  }

  return result;
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

DWORD LinearFmt_YtoX ( WORD Y, BYTE Gain )
{
  //Gain is 2's exponent

  DWORD result;
  BYTE N;

  N = ( BYTE ) ( ( Y & 0xF800 ) >> 11 );  //1111 1000 0000 0000

  if ( Y & 0x8000 ) //0x800 :  1000 0000 0000 0000
  {
      //N < 0
      result = ( ( ( ( ( DWORD ) ( Y & 0x7FF ) ) << Gain ) >> ( 32 - N ) ) );
  }
  else
  {
      //N > 0
      result = ( ( ( ( DWORD ) ( Y & 0x7FF ) ) << N ) << Gain );   // enlarge
  }

  return result;

}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

WORD LinearFmt_XtoY ( DWORD X, char N, BYTE Gain )
{

  //Gain is 2's exponent  // 0x7ff 0111 1111 1111

  WORD result;

  if ( N >= 0 )
  {
      result = ( ( ( X >> N ) >> Gain ) & 0x7FF ) | ( N << 11 );
  }
  else
  {
      result = ( ( ( X << ( - 1 * ( N ) ) ) >> Gain ) & 0x7FF ) | ( 0x8000 | ( ( 16 + ( N ) ) << 11 ) );
  }

  return result;
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

WORD GetAvg ( WORD pBuf[], WORD newData, BYTE* index, BYTE bufSize, DWORD* sum, BYTE exp )
{
  *sum = * sum - pBuf[*index] + newData;

  pBuf[*index] = newData;
  *index = ( *index ) + 1;
  *index = ( ( *index ) >= bufSize ) ? 0 : ( *index );

  return ( WORD ) ( ( *sum ) >> exp );
}


