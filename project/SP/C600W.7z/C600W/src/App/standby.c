
#include "p33Exxxx.h"
#include "define.h"
#include "dsp.h"
#include "Standby.h"
#include "Pmbus.h"
#include "Process.h"
#include "Protection.h"
#include "Timer.h"
#include "PowerOnOff.h"
#include "fbllc.h"
#include "Isr.h"


//-------------------Global Variable----------------------------------------------------------
tSTB STB;
BYTE STB_SCP_Delay;
//-------------------Extern Variable-----------------------------------------------------------

extern tPS_FLAG PS;
extern tPSU_STATE gPS_State;
extern SHORT gStbVoutOffset;


/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void drv_EnableSTBoutput ( void )
{

  //if ( ( _SD_Flag.STB_OCP | _SD_Flag.STB_OVP | _SD_Flag.STB_UVP | _SD_Flag.STB_OTP ) == FALSE )
 // if ( ( _SD_Flag.STB_OCP | _SD_Flag.STB_OVP | _SD_Flag.STB_UVP ) == FALSE )    
    if  STB_Falt_condition 
  {
      pin_o_STB_EN_MCU = STB_ON;
      STB.Enabled = TRUE;
      
  }
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void drv_DisableSTBoutput ( void )
{
  STB.Enabled = FALSE;
  pin_o_STB_EN_MCU = STB_OFF;
  PS.STB_UV_START = FALSE;
  PS.MAIN_PROTECT_START = FALSE;
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
void Check_STBOVP ( void )
{
  if ( ADC.StbVout > STB_OVW_REF )
  {
      gPagePlusStatus.PAGE[PAGE1].STATUS_VOUT.bits.VOUT_OV_WARNING = 1;
  }

  if ( ADC.StbVout > STB_OVP_REF )	// standby output volatge > 14V
  {
      gPagePlusStatus.PAGE[PAGE1].STATUS_VOUT.bits.VOUT_OV_FAULT = 1;
      if ( _SD_Flag.STB_OVP == FALSE )
      {
          _SD_Flag.STB_OVP = TRUE;
          App_Capture_Fault ( );
          drv_DisableSTBoutput ( );
         App_Emergency_PowerOff ( );
          PS.SaveBlackBox = 1;
      }
  }
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void Check_STBSCP ( void )
{
  //if ( ( ADC.StbVout < STB_SC_V_L_REF ) && ( ADC.StbIout_FF > STB_SC_REF )/* && STB_SCP_Delay >= 4*/ )	// around 1V
  if ( ADC.StbIout_FF > STB_SC_REF  )	// 20150911 modify
  {
      gPagePlusStatus.PAGE[PAGE1].STATUS_IOUT.bits.IOUT_OC_WARNING = 1;     //20170727 Added Modify can't clear_fault issue
      //gPagePlusStatus.PAGE[PAGE1].STATUS_IOUT.bits.IOUT_OC_FAULT = 1;     //20160826 removed to Modify STB STATUS_WORD can't be clear by clear fault
      gPagePlusStatus.PAGE[PAGE1].STATUS_IOUT.bits.IOUT_OC_FAULT = 1;       

      MFR_Status.bits.VSB_UVW = 1;
      if ( _SD_Flag.STB_OCP == FALSE )
      {
          _SD_Flag.STB_OCP = TRUE;
          App_Capture_Fault ( );
          drv_DisableSTBoutput ( );

          PS.SaveBlackBox = 1;
      }
  }
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void Check_STBUVP ( void )
{
  if ( PS.STB_UV_START == TRUE )
  {
      if ( ADC.StbVout_FF < STB_UVW_REF )
      {

          gPagePlusStatus.PAGE[PAGE1].STATUS_VOUT.bits.VOUT_UV_WARNING = 1;
          MFR_Status.bits.VSB_UVW = 1;
          Protect.STB_UVW.Flag = 1;         
      }
      else
      {
          Protect.STB_UVW.Flag = 0;         
          Protect.STB_UVW.delay = 0;        
      }
      if ( ADC.StbVout_FF < STB_UV_L_REF )
      {
          Protect.STB_UVP.Flag = 1;
      }
      else
      {
          Protect.STB_UVP.Flag = 0;
          Protect.STB_UVP.delay = 0;
      }
  }
  else
  {
      Protect.STB_UVP.Flag = 0;
      Protect.STB_UVP.delay = 0;
      Protect.STB_UVW.Flag = 0;         
      Protect.STB_UVW.delay = 0;        
  }
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void Check_STBOCP ( void )
{
  if ( STB.Enabled == TRUE )
  {
      //first turn on, the delay time is 25ms
      // 3V --> 610AD
      if ( ADC.StbIout_FF > STB_OCW_REF )    
      {
          Protect.STB_OCW.Flag = 1;         
      }
      else
      {
          Protect.STB_OCW.Flag = 0;         
          Protect.STB_OCW.delay = 0;        
      }
      
      if ( ADC.StbIout_FF > STB_OC_REF )
      {
          Protect.STB_OCP.Flag = 1;
      }
      else
      {
          Protect.STB_OCP.Flag = 0;
          Protect.STB_OCP.delay = 0;
      }

  }
  else
  {
      Protect.STB_OCP.Flag = 0;
      Protect.STB_OCP.delay = 0;
      Protect.STB_OCW.Flag = 0;         
      Protect.STB_OCW.delay = 0;        
  }
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void Check_STB ( void )
{
  if ( ( ADC.StbVout_FF > cSTB_OK_REFH ) && ( STB.Enabled == TRUE ) && ( STB.Counter_InRegulation >= 100 ) )
  {
      STB.InRegulation = TRUE;
  }
  else if ( ADC.StbVout_FF < cSTB_OK_REFL )
  {
      STB.InRegulation = FALSE;
      STB.Counter_InRegulation = 0;
  }
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

 void StandbyVoltageControl ( void ) // no adjustment
{
    
    #ifdef stbvref
  SHORT target;
  SHORT Vref;
  Vref = SPHASE3;

  target = ( ( SHORT ) Vref - gStbVoutOffset );
  if ( target >= SPHASE3 )
  {
      target = SPHASE3;
  }
  else if ( target <= 0 )
  {
      target = 0;
  }

  SDC3 = target;
#endif
  Check_STB ( );
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void init_Standby ( void )
{
  StandbyVoltageControl ( );
}

