
#ifndef __I2C_H__
#define __I2C_H__

typedef enum _I2C_CMD_DIR
{
  CMD_W = 0 ,
  CMD_R ,
} eI2C_CMD_DIR ;

typedef enum _I2C_STATE
{
  STATE_WAIT_FOR_ADDR = 0 ,
  STATE_WAIT_FOR_CMD ,
  STATE_WAIT_FOR_WRITE_DATA ,
  STATE_SEND_READ_DATA ,
  STATE_SEND_READ_LAST ,
  STATE_WRITE_ERROR ,
} eI2C_STATE ;

typedef struct _D_I2C_DATA
{
  BYTE* pRxBuf ;
  BYTE* pTxBuf ;
  BYTE currentCmd ;
  BYTE cmdDir ;
  BYTE isPecFail ;
  BYTE state ;
  BYTE dataIndex ;
  BYTE readBuffer[50] ;
  BYTE PEC ;
  BYTE isBlockMode ;
  BYTE accessNotAllow ;
  BYTE PermitToWrite ;
} tD_I2C_DATA ;

//Exported function
void init_I2C ( ) ;
void HoldSCL ( ) ;
void ReleaseSCL ( ) ;
void GetI2cAddr ( ) ;
void CheckI2COV ( ) ;

extern BYTE OneTimeFlag_HotPlug ;    // For PSON

#endif

