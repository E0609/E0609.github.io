#ifndef __ISR_H__
#define __ISR_H__

#include "Define.h"

#ifdef notes
// based on spec
#define ADC_T_AMBIENT    ADCBUF14    
#define ADC_ISHARE_EXT        ADCBUF0    
#define ADC_V36V_DET      ADCBUF1    
#define ADC_ISHARE_IN    ADCBUF2 
#define ADC_I_OUT   ADCBUF3   
#define ADC_V36V_OUT   ADCBUF4 
#define  ADC_I_LLC_PRI  ADCBUF5 
#define ADC_5Vsb_DET    ADCBUF13
#define ADC_T_SR   ADCBUF11    
#define ADC_T_XFMR   ADCBUF10
#define  ADC_REMOTE_V_DET1  ADCBUF6 
#define ADC_REMOTE_V_DET2    ADCBUF7
#define ADC_I_DET_5Vsb   ADCBUF19
#endif
typedef struct _ADC
{
    //3 ADC_I_OUT
  volatile unsigned int Iout ;
  volatile unsigned int Iout_Cal ;
  volatile unsigned int Iout_FF ;//FF: FEED-FORWARD
  volatile unsigned long Iout_LPF ;

  volatile unsigned int Iout_report ;
  volatile unsigned int Iout_report_Cal ;
  volatile unsigned int Iout_report_FF ;
  volatile unsigned long Iout_report_LPF ;
//ADC_ISHARE_EXT        ADCBUF0  
  volatile unsigned int ISHARE_IN ;
  volatile unsigned int ISHARE_IN_FF ;
  volatile unsigned long ISHARE_IN_LPF ;
  //1 V36V_DET
    volatile unsigned int  V36V_DET ;
  volatile unsigned int  V36V_DET_Cal ;
  volatile unsigned int V36V_DET_FF ;
  volatile unsigned long V36V_DET_LPF ;
//ADC_V36V_OUT
  volatile unsigned int  V36V_OUT ;
  volatile unsigned int  V36V_OUT_Cal ;
  volatile unsigned int V36V_OUT_FF ;
  volatile unsigned long V36V_OUT_LPF ;
//ADC_T_XFMR   ADCBUF10
  volatile unsigned int ISHARE_EXT ;
  volatile unsigned int ISHARE_EXT_Cal ;
  volatile unsigned int ISHARE_EXT_FF ;
  volatile unsigned long ISHARE_EXT_LPF ;
//ADC_ISHARE_IN    ADCBUF2 
  volatile unsigned int CS_PWM_FB ;
  volatile unsigned int CS_PWM_FB_Cal ;
  volatile unsigned int CS_PWM_FB_FF ;
  volatile unsigned long CS_PWM_FB_LPF ;
// ADC_5Vsb_DET    ADCBUF13
  volatile unsigned int StbVout ;
  volatile unsigned int StbVout_Cal ;
  volatile unsigned int StbVout_FF ;
  volatile unsigned int StbVout_LPF ;
//19 ADC_I_DET_5Vsb 19
  volatile unsigned int StbIout ;
  volatile unsigned int StbIout_Cal ;
  volatile unsigned int StbIout_FF ;
  volatile unsigned int StbIout_LPF ;

  volatile unsigned int StbVbus ;
  volatile unsigned int StbVbus_Cal ;
  volatile unsigned int StbVbus_FF ;
  volatile unsigned int StbVbus_LPF ;
//14 ADC_T_AMBIENT
  volatile unsigned int Tinlet ;
  volatile unsigned int Tinlet_FF ;
  volatile unsigned int Tinlet_LPF ;
//ADC_T_SR   ADCBUF11
  volatile unsigned int Tsec ;
  volatile unsigned int Tsec_FF ;
  volatile unsigned int Tsec_LPF ;
  //ADC_T_XForm   ADCBUF10
  volatile unsigned int T_XForm ;
  volatile unsigned int T_XForm_FF ;
  volatile unsigned int T_XForm_LPF ;
  
  
 volatile unsigned int REMOTE_V_DET1 ;
  volatile unsigned int REMOTE_V_DET1_FF ;
  volatile unsigned int REMOTE_V_DET1_LPF ;

  
   volatile unsigned int REMOTE_V_DET2 ;
  volatile unsigned int REMOTE_V_DET2_FF ;
  volatile unsigned int REMOTE_V_DET2_LPF ;
  
 volatile unsigned int I_LLC_PRI;
  volatile unsigned int I_LLC_PRI_FF ;
  volatile unsigned int I_LLC_PRI_LPF ;
  

} tADC ;

typedef struct
{
  unsigned int SetVoltage ;
  unsigned int OldSetVoltage ;
  volatile unsigned int SoftstartVoltage ;
} tVref ;


extern tADC ADC ;
extern tVref Vref ;

/*Exported function*/


#endif //__TIMER_H__

