#ifndef __TIMER_H__
#define __TIMER_H__

#include "Define.h"

typedef struct _TIMER
{
  BYTE Active ;
  _Pfn pTimerFunc ;
  WORD Elapse ;
  QWORD StartTime ;
} SYS_TIMER ;


/*Exported variable*/
extern WORD AcOffBlankingTime ;
//extern WORD VrefCompDelay ;   //20160408 removed, the Function no used

/*Exported function*/
BYTE SetTimer ( WORD Elapse , _Pfn pTimerFunc ) ;
void KillTimer ( BYTE *pTimerID ) ;
void RestartTimer ( BYTE *pTimerID ) ;


#endif //__TIMER_H__

