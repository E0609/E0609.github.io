
#ifndef __DRVADC_H__
#define __DRVADC_H__

#include "../Lib/p33EP64GS506.h"     // cips

#ifdef notes  // no  UCC28950
// Example:
// 10^9 ns /125k = 8000ns per PWM cycle 
// 8000 ns / 2.08 ns = 3846 counts (PWM Period)

#define UCC28950_SYNC_FREQ	100000
#define GET_PERIOD(FREQ)	((LONG)1000000000/FREQ)*100/208
//#define PWM_PERIOD	GET_PERIOD(UCC28950_SYNC_FREQ)  //  3846 
#endif
#define PWM_PERIOD  (3846/5) 


#if DITHER_ENABLED
#define UCC28950_SYNC_FREQ_LOW		116000
#define UCC28950_SYNC_FREQ_HIGH		130000
#define PWM_PERIOD_LOW		GET_PERIOD(UCC28950_SYNC_FREQ_LOW)
#define PWM_PERIOD_HIGH		GET_PERIOD(UCC28950_SYNC_FREQ_HIGH)
#define DIFF_PERIOD_TOTAL	(GET_PERIOD(UCC28950_SYNC_FREQ_LOW) - GET_PERIOD(UCC28950_SYNC_FREQ_HIGH))
#define DIFF_COUNT	(DIFF_PERIOD_TOTAL / 14)	// 20us * 14 = 240us
#endif



#define DUTY_V36V2_REF	                 24894	// 12.2V

#if defined(Config_V36V35_REF)                          
    //#define DUTY_V36V3_REF	            25098	// 12.3V => (12.3/12.5)*25506 = 25098, 
    #define DUTY_V36V35_REF	            25200	// 12.3V => (12.35/12.5)*25506 = 25200, 
#elif defined(Config_V36V25_REF)
    #define DUTY_V36V25_REF	            24996	// 12.25V => (12.25/12.5)*25506 = 24996,
#elif defined(Config_V36V5_REF)
    #define DUTY_V36V5_REF	            25506	

/* 12.5V   // how to get this?  12.5x1000/25505
 * 3.3V/ 0b 11 1111 1111= 3.3X1000/1023=3.226mv resolution
 * cips 0~3.3 0~1023,0b11 11111111;3.3x4=13.2*/
#endif
#define DITHER_ENABLED	0


#define DUTY_V36V_STEP_DOWN_REF      24282	    // 11.9V         
#define SOFTSTART_SLOPE_ADJUSTMENT	9 //6    

// for ADC AW600
/*
 AN14	T_AMBIENT
AN0	ISHARE_EXT
AN1	V36V_DET
AN2	ISHARE_INT
AN3	I_OUT
AN4	V36V_OUT
AN5	I_LLC_PRI
AN13	5Vsb_DET
AN11	T_SR
AN10	T_XFMR
AN6	REMOTE_V_DET1
AN7	REMOTE_V_DET2
AN19	I_DET_5Vsb

 */
#define  ADC_T_AMBIENT    ADCBUF14    
#define     ADC_ISHARE_EXT       ADCBUF0
#define ADC_V36V_DET      ADCBUF1    
#define ADC_ISHARE_IN    ADCBUF2 
#define ADC_I_OUT   ADCBUF3   
#define ADC_V36V_OUT   ADCBUF4 
#define  ADC_I_LLC_PRI  ADCBUF5 
#define ADC_5Vsb_DET    ADCBUF13
#define ADC_T_SR   ADCBUF11    
#define ADC_T_XFMR   ADCBUF10
#define  ADC_REMOTE_V_DET1  ADCBUF6 
#define ADC_REMOTE_V_DET2    ADCBUF7
#define ADC_I_DET_5Vsb   ADCBUF19


// for pwm
/**

 PWM1H	ISHARE_REF	Create Current reference
PWM2L	FAN_PWM	PWM control for FAN
PWM5H	LLC_G1	LLC primary gate signal 
PWM5L	LLC_G2	LLC primary gate signal
PWM3H	SR_G1	LLC secondary gate signal 
PWM3L	SR_G2	LLC secondary gate signal
*/

//Exported function

void init_ADC ( void ) ;


