
#ifndef __DRVGPIO_H__
#define __DRVGPIO_H__

#include "../Lib/p33EP64GS506.h"     // cips




#define MG_PIN_ANALOG             1                        //Microchip Pin Analog Select
#define MG_PIN_DIGITAL            0
#define MG_PIN_OUTPUT_HIGH        1
#define MG_PIN_OUTPUT_LOW         0
#define MG_PIN_INPUT_DIRECTION    1              //Microchip Pin Input Direction
#define MG_PIN_OUTPUT_DIRECTION   0
// spec for gpio
/** output
RC0	L	LED1
RC13	L	SR_DIS
RD12	L	ISHARE_DIS
RD7	L	ORING_EN
RD2	L	POK
RD9	L	5Vsb_EN
RD5	L	PFC_OFF_SEC
RD4	L	FAN_FAILED
RD1	L	LLC_DIS

 */
#define pin_o_LED_ON                         _LATC0
#define pin_o_SR_EN                            _LATC13 
#define pin_o_ISHARE_DIS                    _LATD12
#define pin_o_ORING_EN_MCU      _LATD7
#define pin_o_PW_GOOD                  _LATD2 
#define pin_o_STB_EN_MCU                     _LATD9
#define pin_o_PFC_OFF                   _LATD5 
//#define  pin_o_FAN_CNTL                           _LATC1  
#define pin_o_LLC_EN_MCU                    _LATD1  

/**
 * GPIO input
RD0	  PSON / REMOTE ON
RC4	PFC_NOK_SEC
RC5	AC_NOK_SEC
RB4	PS_A0
RC14	PS_A1
RC2	PS_A2


 */
#define	iPS_ON                               _RD0
#define	iPFC_OK                              _RC4
#define	iAC_OK                               _RC5
#define pin_i_i2c_addr_0  	                 _RB4
#define pin_i_i2c_addr_1  	                 _RC14
#define pin_i_i2c_addr_2  	                 _RC2

// for ADC AW600
/*
 AN14	T_AMBIENT
AN0	ISHARE_EXT
AN1	V36V_DET
AN2	ISHARE_INT
AN3	I_OUT
AN4	V36V_OUT
AN5	I_LLC_PRI
AN13	5Vsb_DET
AN11	T_SR
AN10	T_XFMR
AN6	REMOTE_V_DET1
AN7	REMOTE_V_DET2
AN19	I_DET_5Vsb

 */

//Exported function

void init_GPIO ( void ) ;

