
#ifndef __INIT_H__
#define __INIT_H__

#include "p33EP64GS506.h"     // cips

#ifdef notes  // no  UCC28950
// Example:
// 10^9 ns /125k = 8000ns per PWM cycle 
// 8000 ns / 2.08 ns = 3846 counts (PWM Period)

#define UCC28950_SYNC_FREQ	100000
#define GET_PERIOD(FREQ)	((LONG)1000000000/FREQ)*100/208
//#define PWM_PERIOD	GET_PERIOD(UCC28950_SYNC_FREQ)  //  3846 
#endif
#define PWM_PERIOD  (3846/5) 


#if DITHER_ENABLED
#define UCC28950_SYNC_FREQ_LOW		116000
#define UCC28950_SYNC_FREQ_HIGH		130000
#define PWM_PERIOD_LOW		GET_PERIOD(UCC28950_SYNC_FREQ_LOW)
#define PWM_PERIOD_HIGH		GET_PERIOD(UCC28950_SYNC_FREQ_HIGH)
#define DIFF_PERIOD_TOTAL	(GET_PERIOD(UCC28950_SYNC_FREQ_LOW) - GET_PERIOD(UCC28950_SYNC_FREQ_HIGH))
#define DIFF_COUNT	(DIFF_PERIOD_TOTAL / 14)	// 20us * 14 = 240us
#endif



#define DUTY_V36V2_REF	                 24894	// 12.2V

#if defined(Config_V36V35_REF)                          
    //#define DUTY_V36V3_REF	            25098	// 12.3V => (12.3/12.5)*25506 = 25098, 
    #define DUTY_V36V35_REF	            25200	// 12.3V => (12.35/12.5)*25506 = 25200, 
#elif defined(Config_V36V25_REF)
    #define DUTY_V36V25_REF	            24996	// 12.25V => (12.25/12.5)*25506 = 24996,
#elif defined(Config_V36V5_REF)
    #define DUTY_V36V5_REF	            25506	

/* 12.5V   // how to get this?  12.5x1000/25505
 * 3.3V/ 0b 11 1111 1111= 3.3X1000/1023=3.226mv resolution
 * cips 0~3.3 0~1023,0b11 11111111;3.3x4=13.2*/
#endif
#define DITHER_ENABLED	0


#define DUTY_V36V_STEP_DOWN_REF      24282	    // 11.9V         
#define SOFTSTART_SLOPE_ADJUSTMENT	9 //6    


#define MG_PIN_ANALOG             1                        //Microchip Pin Analog Select
#define MG_PIN_DIGITAL            0
#define MG_PIN_OUTPUT_HIGH        1
#define MG_PIN_OUTPUT_LOW         0
#define MG_PIN_INPUT_DIRECTION    1              //Microchip Pin Input Direction
#define MG_PIN_OUTPUT_DIRECTION   0
// spec for gpio
/** output
RC0	L	LED1
RC13	L	SR_DIS
RD12	L	ISHARE_DIS
RD7	L	ORING_EN
RD2	L	POK
RD9	L	5Vsb_EN
RD5	L	PFC_OFF_SEC
RD4	L	FAN_FAILED
RD1	L	LLC_DIS

 */
#define pin_o_LED_ON                         _LATC0
#define pin_o_SR_EN                            _LATC13 
#define pin_o_ISHARE_DIS                    _LATD12
#define pin_o_ORING_EN_MCU      _LATD7
#define pin_o_PW_GOOD                  _LATD2 
#define pin_o_STB_EN_MCU                     _LATD9
#define pin_o_PFC_OFF                   _LATD5 
//#define  pin_o_FAN_CNTL                           _LATC1  
#define pin_o_LLC_EN_MCU                    _LATD1  

/**
 * GPIO input
RD0	  PSON / REMOTE ON
RC4	PFC_NOK_SEC
RC5	AC_NOK_SEC
RB4	PS_A0
RC14	PS_A1
RC2	PS_A2


 */
#define	iPS_ON                               _RD0
#define	iPFC_OK                              _RC4
#define	iAC_OK                               _RC5
#define pin_i_i2c_addr_0  	                 _RB4
#define pin_i_i2c_addr_1  	                 _RC14
#define pin_i_i2c_addr_2  	                 _RC2

// for ADC AW600
/*
 AN14	T_AMBIENT
AN0	ISHARE_EXT
AN1	V36V_DET
AN2	ISHARE_INT
AN3	I_OUT
AN4	V36V_OUT
AN5	I_LLC_PRI
AN13	5Vsb_DET
AN11	T_SR
AN10	T_XFMR
AN6	REMOTE_V_DET1
AN7	REMOTE_V_DET2
AN19	I_DET_5Vsb

 */
#define  ADC_T_AMBIENT    ADCBUF14    
#define     ADC_ISHARE_EXT       ADCBUF0
#define ADC_V36V_DET      ADCBUF1    
#define ADC_ISHARE_IN    ADCBUF2 
#define ADC_I_OUT   ADCBUF3   
#define ADC_V36V_OUT   ADCBUF4 
#define  ADC_I_LLC_PRI  ADCBUF5 
#define ADC_5Vsb_DET    ADCBUF13
#define ADC_T_SR   ADCBUF11    
#define ADC_T_XFMR   ADCBUF10
#define  ADC_REMOTE_V_DET1  ADCBUF6 
#define ADC_REMOTE_V_DET2    ADCBUF7
#define ADC_I_DET_5Vsb   ADCBUF19


// for pwm
/**

 PWM1H	ISHARE_REF	Create Current reference
PWM2L	FAN_PWM	PWM control for FAN
PWM5H	LLC_G1	LLC primary gate signal 
PWM5L	LLC_G2	LLC primary gate signal
PWM3H	SR_G1	LLC secondary gate signal 
PWM3L	SR_G2	LLC secondary gate signal
*/
#define PWM_ISHARE_REF_duty    PDC1
#define PWM_ISHARE_REF_Period   PHASE1 

#define PWM_FAN_duty    SDC2
#define PWM_FAN_Period   SPHASE2 

#define PWM_LLC_G1_duty         PDC5
#define PWM_LLC_G1_Period     PHASE5 
#define PWM_LLC_G2_duty         SDC5
#define PWM_LLC_G2_Period     SPHASE5 

#define PWM_SR_G1_duty         PDC3
#define PWM_SR_G1_Period     PHASE3 
#define PWM_SR_G2_duty         SDC3
#define PWM_SR_G2_Period     SPHASE3 
//Exported function
void init_SetupClock ( void ) ;
void init_GPIO ( void ) ;
void init_Timer ( void ) ;
void init_ADC ( void ) ;
void init_PWM ( void ) ;
#ifdef Config_Input_CN                        //  Input Change Notification
void init_Input_CN ( void );                
#endif
//void init_Comparator ( void ) ;           // removed
//void init_External_Interrupt ( void ) ;   // removed

#endif

