
#ifndef __MEMORY_H__
#define __MEMORY_H__ 

#include "Define.h"

//Configuration Defines ************************************************************
//Bootloader device configuration
#define DEV_HAS_WORD_WRITE	//Device has word write capability (24FJxxx devices)

//Bootloader feature configuration
#define USE_BOOT_PROTECT	//Use BL block protection 

#define USE_VECTOR_PROTECT  //Use Reset and IVT protection



#define BOOTLOADER_ADDR		0x400
#define BL_VER_ADDR			0x100	//BL version addr

#if defined(__dsPIC33FJ32GS606__)
#define USER_DATA_ADDR		0x5000
#define FRU_ADDR			0x5000
#define MISC_ADDR			0x5400
#elif defined(__dsPIC33EP64GS506__)
#define USER_DATA_ADDR		0xA400
#define FRU_ADDR			0xA400
#define MISC_ADDR			0xA800
#define LOG_ADDR			0xA000
#endif

#define PM_INSTR_SIZE 		4		//bytes per instruction 
#define PM_ROW_SIZE 		256  	//user flash row size in bytes (64 instructions)
#define PM_PAGE_SIZE 		2048 	//user flash page size in bytes (64*8=512 instructions)


//Self-write NVMCON opcodes	
#define PM_PAGE_ERASE 		0x4042	//NVM page erase opcode
#define PM_ROW_WRITE 		0x4001	//NVM row write opcode
#define PM_WORD_WRITE		0x4003	//NVM word write opcode
#define CONFIG_WORD_WRITE	0X4004	//Config memory write opcode

#define BOOT_ADDR_LOW 		0x400	//start of BL protection area
#define BOOT_ADDR_HI  		0x13FF	//end of BL protection area  



#if defined(__dsPIC33FJ32GS606__)

#elif defined(__dsPIC33EP64GS504__)
#define CONFIG_WORD_1		0xABFEL //Flash config word locations for devices
#define CONFIG_WORD_2		0xABFCL //w/o config bits#endif
#endif


void WriteMem ( WORD cmd ) ;
void WriteLatch ( WORD page , WORD addrLo , WORD dataHi , WORD dataLo ) ;
DWORD ReadLatch ( WORD page , WORD addrLo ) ;
void ResetDevice ( WORD addr ) ;
void Erase ( WORD page , WORD addrLo , WORD cmd ) ;
void ReadPM ( BYTE *buffer , WORD bytes , DWORD_VAL sourceAddr ) ;
void WritePM ( BYTE* buffer , WORD length , DWORD_VAL sourceAddr ) ;
void ErasePM ( WORD length , DWORD_VAL sourceAddr ) ;

#endif  /*end of __MEMORY_H__*/
