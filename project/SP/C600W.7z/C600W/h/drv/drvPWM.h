
#ifndef __DRVPWM_H__
#define __DRVPWM_H__

#include "../Lib/p33EP64GS506.h"     // cips



// for pwm
/**

 PWM1H	ISHARE_REF	Create Current reference
PWM2L	FAN_PWM	PWM control for FAN
PWM5H	LLC_G1	LLC primary gate signal 
PWM5L	LLC_G2	LLC primary gate signal
PWM3H	SR_G1	LLC secondary gate signal 
PWM3L	SR_G2	LLC secondary gate signal
*/
#define PWM_ISHARE_REF_duty    PDC1
#define PWM_ISHARE_REF_Period   PHASE1 

#define PWM_FAN_duty    SDC2
#define PWM_FAN_Period   SPHASE2 

#define PWM_LLC_G1_duty         PDC5
#define PWM_LLC_G1_Period     PHASE5 
#define PWM_LLC_G2_duty         SDC5
#define PWM_LLC_G2_Period     SPHASE5 

#define PWM_SR_G1_duty         PDC3
#define PWM_SR_G1_Period     PHASE3 
#define PWM_SR_G2_duty         SDC3
#define PWM_SR_G2_Period     SPHASE3 


//Exported function
void init_PWM ( void ) ;

