
#ifndef __POWER_ONOFF_H__
#define __POWER_ONOFF_H__

#include "Define.h"

/*Power ON Timing*/
#define Tvout_rise		25		//ms
#define Tpwok_on		200		//ms
#define Tvout_in_reg	1		//ms
#define Ton_delay		0		//ms

/*Power OFF Timing*/
#define Tpwok_off		0		//ms
#define Tmain_off		3		//ms

typedef enum
{
  PowerOning = 0 ,
  PowerReady ,
  PowerGood ,
  //CheckMainRise,     //[Jonathan Liang] 20111004 added.
  PowerOffing ,
  PowerOff ,
} _POWER_ONOFF_STATUS ;

typedef struct _TimerHandle
{
  BYTE _Tvout_in_reg ;
  BYTE _Tpwok_on ;
  BYTE _Tpwok_off ;
  BYTE _Tmain_off ;
  BYTE _Ton_delay ;
} tTimerHandle ;

extern BYTE gPSU_ONOFF_Status ;
extern tTimerHandle hTimer ;

//Exported function
void PowerOnSeq ( BYTE* hTImer , WORD period , _Pfn isr ) ;
void PowerOffSeq ( BYTE* hTImer , WORD period , _Pfn isr ) ;
void EmergencyPowerOff ( ) ;
void TurnOnOutput ( ) ;
void TurnOffOutput ( ) ;
void ISR_Tpwok_off ( ) ;
void GoStandby ( ) ;
void GoLatch ( ) ;

#endif

