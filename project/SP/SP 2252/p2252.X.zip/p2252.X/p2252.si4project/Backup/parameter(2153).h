
#ifndef __PARAMETER_H__
#define __PARAMETER_H__

#include "Define.h"

#define FCY							40000000	// 40MIPS

#if defined(Config_12V35_REF)                               //[davidchchen]20160307 Added
    //#define MAINVOUT_COMMAND_REF                            (WORD)3149 //3200    // 12.3*256 = 3149, 12.5*256 = 3200, [davidchchen]20150121
    #define MAINVOUT_COMMAND_REF                            (WORD)3162 //3200     // 12.35*256 = 3162 [davidchchen]20160307 Added
#elif defined(Config_12V25_REF)
    #define MAINVOUT_COMMAND_REF                            (WORD)3136    // 12.25*256 = 3136 [davidchchen]20151223
#elif defined(Config_12V5_REF)
    #define MAINVOUT_COMMAND_REF                            (WORD)3200    // 12.5*256 = 3200 [davidchchen]20150518
#endif

#define Io_Slave_HREF					(WORD)(((DWORD)DEFAULT_IOUT_SLAVE_FAULT_H*IOUT_TO_ADC) >> IOUT_TO_ADC_GAIN)//30A, //[davidchchen]20150731 Added
#define Io_Slave_LREF					(WORD)(((DWORD)DEFAULT_IOUT_SLAVE_FAULT_L*IOUT_TO_ADC) >> IOUT_TO_ADC_GAIN)//10A, //[davidchchen]20150731 Added
#define VoutComp_HREF					(WORD)(((DWORD)DEFAULT_VOUT_COMP_H*IOUT_TO_ADC) >> IOUT_TO_ADC_GAIN)//60A, //[davidchchen]20150731 Added
#define VoutComp_LREF					(WORD)(((DWORD)DEFAULT_VOUT_COMP_L*IOUT_TO_ADC) >> IOUT_TO_ADC_GAIN)//10A, //[davidchchen]20150731 Added
#define OCP_H_REF					(WORD)(((DWORD)DEFAULT_IOUT_OC_FAULT*IOUT_TO_ADC) >> IOUT_TO_ADC_GAIN)	//235A
#define OCW_H_REF					(WORD)(((DWORD)DEFAULT_IOUT_OC_WARN*IOUT_TO_ADC) >> IOUT_TO_ADC_GAIN)	//230A
#define PEAK_CURRENT_H_REF                              (WORD)(((DWORD)230*IOUT_TO_ADC) >> IOUT_TO_ADC_GAIN)	//230A
#define CS_COMP_LIMIT                                   (WORD)(((DWORD)126*VOUT_TO_ADC)/10)		// 12.6V
#define OVP_REF						(WORD)(((DWORD)135*VOUT_TO_ADC)/10)		// 13.5V	
#define OVW_REF						(WORD)(((DWORD)132*VOUT_TO_ADC)/10)		// 13.2V
#define REG_HREF					(WORD)(((DWORD)118*VOUT_TO_ADC)/10)		// 11.8V
#define REG_LREF					(WORD)(((DWORD)114*VOUT_TO_ADC)/10)		// 11.4V
#define UVW_REF						(WORD)(((DWORD)115*VOUT_TO_ADC)/10)		// 10.7V, 20141106 david fix 11.5
#define UV_L_REF					(WORD)(((DWORD)105*VOUT_TO_ADC)/10)		// 10.5V
#define OPP_H_REF					3500
#define STB_OVP_REF					(WORD)(((DWORD)142*VOUT_TO_ADC)/10)		// 14.2V
#define STB_OVW_REF					(WORD)(((DWORD)135*VOUT_TO_ADC)/10)		// 13.5V
#define STB_UVW_REF					700		//11.2V
#define STB_UV_L_REF				668		//10.7V
#define STB_SC_V_L_REF				490		// 8V

/******************************************************************************************/

/*FW version*/
#define DELL_ISP_KEY			"Inve"
#define DELL_FACTORY_MODE_KEY	"Fmod"
#define LITEON_FACOTRY_MODE_KEY	"Lion"

//Devil 700W device code is 28350 ->hex : 6EBE
#define DEVICE_CODE			0x00006EBEL 

#define FW_VERSION 			"0-006L01"  //[davidchchen]20180801 addr pin debounce isse
#define LITEON_FW_VERSION	"20150911T0"
#define MFR_PSU		 		"PSU"
#define MFR_MODEL_INIT		"PS-2252-6L1U    "  //[davidchchen]20170921  PPT Stage
#define MFR_LOCATION_INIT	"CHINA"
#define HW_Compatible_Code      "01"            //[davidchchen]20150112 Added Compatible Code to match HW version

/******************************************************************************************/
/*Data length*/
/* with byte count */
#define MFR_ID_LEN				8 	//0x99	based on FRU spec
#define MFR_MODEL_LEN			16	//0x9A	based on FRU spec
#define MFR_REVISION_LEN		8	//0x9B	based on FRU spec
#define MFR_LOCATION_LEN		16	//0x9C	based on FRU spec
#define MFR_DATE_LEN			8	//0x9D	based on FRU spec
#define MFR_SERIAL_LEN			30
#define MFR_POS_TOTAL_LEN                   4       //[davidchchen]20170310 Modify MFR_POS_TOTAL_LEN to Block Read
#define MFR_POS_LAST_LEN                    4       //[davidchchen]20170310 Modify MFR_POS_LAST to Block Read
#define BMC_UNIX_TIMESTAMP_LEN              4       //[davidchchen]20170310 Modify BMC_UNIX_TIMESTAMP_LEN to Block Read

#define MFR_EFFICIENCY_LL_LEN	14	//0xAA
#define MFR_EFFICIENCY_HL_LEN	14	//0xAB
#define MFR_FIRMWARE_VER_LEN	10	//0xB4	based on weekly meeting, 10232008, with Dell
#define FRU_ADDR_LEN			2	//0xB0
#define FRU_READ_LEN			16	//0xB1

/* without byte count */
#define MFR_RCB_INFO_LEN		11	//0xCF	//[davidchchen]20160304 added RCB
#define MFR_DEVICE_CODE_LEN		4	//0xD0	based on IPMM spec
#define MFR_FW_VERSION_LEN		8	//0xD5	based on IPMM spec
#define MFR_BL_VERSION_LEN		1
#define MFR_PRI_VERSION_LEN		2

#define LITEON_FW_VERSION_LEN	10
#define MFR_PSU_LEN				3
#define MFR_LOCATION_INIT_LEN	5

/******************************************************************************************/

#define DEFAULT_MFR_VIN_MAX_AC			264     //270       //[davidchchen]20160113 modify
#define DEFAULT_MFR_VIN_MIN_AC			180
#define DEFAULT_MFR_VIN_MAX_DC			290     //300       //[davidchchen]20160113 modify
#define DEFAULT_MFR_VIN_MIN_DC			190
#define DEFAULT_MFR_IIN_LL_MAX_AC		1856    //1945	// 15.2A, Gain with 128 => 15.2*128 = 1945.6,
                                                        //1753, 13.7 * 128= 1753, [davidchchen]20160113 modify
#define DEFAULT_MFR_IIN_HL_MAX_AC               1856    //1945	// 15.2A, Gain with 128 => 15.2*128 = 1945.6
                                                        //1856, 14.5 * 128= 1856, [davidchchen]20160113 modify
#define DEFAULT_MFR_PIN_LL_MAX_AC		2766
#define DEFAULT_MFR_PIN_HL_MAX_AC		2766
#define DEFAULT_MFR_IIN_LL_MAX_DC		2176    //1835	// 14.34A, Gain with 128 => 14.34*128 = 1835.52, [davidchchen]20160113 modify
#define DEFAULT_MFR_IIN_HL_MAX_DC		2176    //1835	// 14.34A, Gain with 128 => 14.34*128 = 1835.52, [davidchchen]20160113 modify
#define DEFAULT_MFR_PIN_LL_MAX_DC		2742
#define DEFAULT_MFR_PIN_HL_MAX_DC		2742

#define DEFAULT_MFR_VOUT_MIN_12V		3104	//12.125V(3104), 11.875V , Gain with 256 => 11.875*256 = 3040
#define DEFAULT_MFR_VOUT_MAX_12V		3296	//12.875V(3296), 13.125V , Gain with 256 => 13.125*256 = 3360
                                                //12.6V   , Gain with 256 => 12.597*256 = 3225, [davidchchen] 20150105 modified
#define DEFAULT_MFR_IOUT_MAX_12V		25600   //25600	//200A, Gain with 128 => 200*128 = 25600, 204*128 = 26112, [davidchchen]20160425 modify
#define DEFAULT_MFR_POUT_LL_MAX_12V		2500    //2500  //[davidchchen]20160425 modify
#define DEFAULT_MFR_POUT_HL_MAX_12V		2500    //2500  //[davidchchen]20160425 modify
#define DEFAULT_MFR_TOTAL_POUT_LL_MAX           2500    //2500  //[davidchchen]20160425 modify
#define DEFAULT_MFR_TOTAL_POUT_HL_MAX           2500    //2500  //[davidchchen]20160425 modify
#define DEFAULT_MFR_TAMBIENT_MAX		45//55      //[davidchchen]20170224 change Temp Value
#define DEFAULT_MFR_TAMBIENT_MIN		0
#define DEFAULT_VIN_OV_FAULT_AC			285
#define DEFAULT_VIN_OV_RECOVER_AC		272
#define DEFAULT_VIN_OV_WARN_AC			275
#define DEFAULT_VIN_UV_WARN_AC			173 //175   //[davidchchen]20160113 modify
#define DEFAULT_VIN_UV_FAULT_AC			170
#define DEFAULT_VIN_UV_RECOVER_AC		175 //177     //[davidchchen]20160113 Added
#define DEFAULT_VIN_OV_FAULT_DC			305
#define DEFAULT_VIN_OV_RECOVER_DC		298
#define DEFAULT_VIN_OV_WARN_DC			300
#define DEFAULT_VIN_UV_WARN_DC			183 //185   //[davidchchen]20160113 modify
#define DEFAULT_VIN_UV_FAULT_DC			180
#define DEFAULT_VIN_UV_RECOVER_DC		185 //187    //[davidchchen]20160113 Added

//N of Linear format
#define N_MFR_VIN_MAX						0
#define N_MFR_VIN_MIN						0
#define N_MFR_IIN_LL_MAX					-5
#define N_MFR_IIN_HL_MAX					-5
#define N_MFR_PIN_LL_MAX					2
#define N_MFR_PIN_HL_MAX					2		
#define N_MFR_IOUT_MAX_12V					-2
#define N_MFR_POUT_LL_MAX_12V				2
#define N_MFR_POUT_HL_MAX_12V				2
#define N_MFR_TOTAL_POUT_LL_MAX				2
#define N_MFR_TOTAL_POUT_HL_MAX				2
#define N_MFR_TAMBIENT_MAX					0
#define N_MFR_TAMBIENT_MIN					0
#define N_MFR_MAX_TEMP_1					0
#define N_MFR_MAX_TEMP_2					0
#define N_MFR_EFFICIENCY_LL_INPUT_VOL		0
#define N_MFR_EFFICIENCY_LL_POWER_20_LOAD	0
#define N_MFR_EFFICIENCY_LL_EFF_20_LOAD		0
#define N_MFR_EFFICIENCY_LL_POWER_50_LOAD	0
#define N_MFR_EFFICIENCY_LL_EFF_50_LOAD		0
#define N_MFR_EFFICIENCY_LL_POWER_100_LOAD	0
#define N_MFR_EFFICIENCY_LL_EFF_100_LOAD	0
#define N_MFR_EFFICIENCY_HL_INPUT_VOL		0
#define N_MFR_EFFICIENCY_HL_POWER_20_LOAD	0
#define N_MFR_EFFICIENCY_HL_EFF_20_LOAD		0
#define N_MFR_EFFICIENCY_HL_POWER_50_LOAD	1
#define N_MFR_EFFICIENCY_HL_EFF_50_LOAD		0
#define N_MFR_EFFICIENCY_HL_POWER_100_LOAD	2
#define N_MFR_EFFICIENCY_HL_EFF_100_LOAD	0

//Low Line Efficiency
#define DEFAULT_MFR_EFFICIENCY_LL_INPUT_VOL			115
#define DEFAULT_MFR_EFFICIENCY_LL_POWER_20_LOAD		110
#define DEFAULT_MFR_EFFICIENCY_LL_EFF_20_LOAD		88
#define DEFAULT_MFR_EFFICIENCY_LL_POWER_50_LOAD		275
#define DEFAULT_MFR_EFFICIENCY_LL_EFF_50_LOAD		184		// 92 gain by 2
#define DEFAULT_MFR_EFFICIENCY_LL_POWER_100_LOAD	550
#define DEFAULT_MFR_EFFICIENCY_LL_EFF_100_LOAD		89

//High Line Efficiency
#define DEFAULT_MFR_EFFICIENCY_HL_INPUT_VOL			230
#define DEFAULT_MFR_EFFICIENCY_HL_POWER_20_LOAD		500
#define DEFAULT_MFR_EFFICIENCY_HL_EFF_20_LOAD		90
#define DEFAULT_MFR_EFFICIENCY_HL_POWER_50_LOAD		1250
#define DEFAULT_MFR_EFFICIENCY_HL_EFF_50_LOAD		94
#define DEFAULT_MFR_EFFICIENCY_HL_POWER_100_LOAD	2500
#define DEFAULT_MFR_EFFICIENCY_HL_EFF_100_LOAD		91


/******************************************************************************************/

//Vout ADC 1 is mapped to 0.01626V 
#define ADC_TO_VOUT 			33	//scaling with 2048
#define VOUT_TO_ADC				62	// 1V is mapped to Adc 61.5
#define VOUT_GAIN				11	//Gain is 2's exponent
#define VOUT_N					-9	//N of Vout
#define VOUT_1V					62
#define VOUT_2V					124
#define VOUT_8V					496

//ISB ADC 1 is mapped to 0.008316A
#define ISB_TO_ADC				59

//Iout ADC 1 is mapped to 0.32258A
#define ADC_TO_IOUT				2642//scaling with 8192
#define IOUT_TO_ADC				3174//scaling with 1024
#define ADC_TO_IOUT_GAIN		13	//Gain is 2's exponent
#define IOUT_TO_ADC_GAIN		10	//Gain is 2's exponent

//Small Scale Iout ADC 1 is mapped to 0.102585A
#define L_ADC_TO_IOUT			840	//scaling with 8192
#define L_IOUT_TO_ADC			9982//scaling with 256
#define L_ADC_TO_IOUT_GAIN		13	//Gain is 2's exponent
#define L_IOUT_TO_ADC_GAIN		10	//Gain is 2's exponent

#define FULL_LOAD_ADC			432		//88.67A, adc: 646
#define LOAD_90P_ADC			388		//79.80A, adc: 581
#define CS_50P_ADC				206

#define IOUT_SLOPE_GAIN			10	//Gain is 2's exponent

//Gain for report data
#define VIN_GAIN				10	//Gain is 2's exponent
#define IIN_GAIN				10	//Gain is 2's exponent
#define PIN_GAIN				4	//Gain is 2's exponent

//VIN ADC 1 mapped to 0.3213V
#define ADC_TO_VIN				329	//scaling with 1024

//Mainbus Vout 1mV is mapped to 0.035102 adc
#define MAINBUS_VOUT_TO_ADC		36		//Gain 1024
#define MAINBUS_GAIN			10		//Gain is 2's exponent
#define MAINBUS_12V_ADC			421		

#define FAN_SPEED_UP_TEMP		35	//degree
#define FAN_TURN_OFF_TEMP		30	//degree

#define FCY	40000000	// ???

/******************************************************************************************/
#define DEFAULT_IOUT_SLAVE_FAULT_H	30		//[davidchchen]20150731 Added
#define DEFAULT_IOUT_SLAVE_FAULT_L	10		//[davidchchen]20150731 Added
#define DEFAULT_VOUT_COMP_H             60		//[davidchchen]20150731 Added
#define DEFAULT_VOUT_COMP_L             10		//[davidchchen]20150731 Added
#define DEFAULT_IOUT_OC_FAULT		220             //[davidchchen]20160919 OCP change to 220A, //230		// 240A	//[Peter Chung] 20101118 modified due to Dell's request,
#define FACTORY_IOUT_OC_FAULT		220             //[davidchchen]20160919 OCP change to 220A, //230		// 240A	//[Peter Chung] 20101118 modified due to Dell's request,
#define DEFAULT_IOUT_OC_WARN		210 //210		// 235A, //[davidchchen]20160425 modify
#define DEFAULT_POUT_OP_WARN		3000	// 3000W
#define DEFAULT_POUT_OP_FAULT		3360	// 3360W

#define DEFAULT_SC_FAULT		270 //270		//280	//Chris, for hardware limit	// 280A, Parameter.SCP_FAULT_LIMIT, [davidchchen]20160425

#define DEFAULT_IIN_OC_WARN_LL		DEFAULT_MFR_IIN_LL_MAX_AC		// 14.5
#define DEFAULT_IIN_OC_WARN_HL		DEFAULT_MFR_IIN_HL_MAX_AC		// 7A
#define DEFAULT_IIN_OC_FAULT_LL		17
#define DEFAULT_IIN_OC_FAULT_HL		17

#define DEFAULT_IIN_OC_WARN_GAIN	7		// 2^7, Gain by 128
#define DEFAULT_PIN_OP_WARN			DEFAULT_MFR_PIN_LL_MAX_AC		//3300 W

#define DEFAULT_TPRI_FAULT			100			// degree		//Please check the primary side OTP trip point, cannot be higher than that.
#define DEFAULT_TPRI_WARN			90
#define DEFAULT_TPRI_OT_RECOVERY	80	// degree
#define DEFAULT_TSEC_FAULT			110	//100			// degree	//Chris, for thermal request
#define DEFAULT_TSEC_WARN			100	//90			// degree
#define DEFAULT_TSEC_OT_RECOVERY	80
#define DEFAULT_TINLET_FAULT		67	//60			// degree
#define DEFAULT_TINLET_WARN			55	//57			// degree	//Chris, for Lenovo spec
#define DEFAULT_TINLET_OT_RECOVERY	52  //50	//Chris, for thermal request, //[davidchchen]20160408 changed Tinlet_recovery to 52

//[davidchchen] 20150929 Added
#define DEFAULT_VIN_AC_UV_TIME          100     //1unit/20ms, 2s = 100*20ms,      //[davidchchen]20161026 Modify UNIT_OFF issue , VAC_UV_TIME to 500ms
#define DEFAULT_VIN_DC_UV_TIME          120     //1unit/20ms, 2.4s = 120*20ms,    //[davidchchen]20161026 Modify UNIT_OFF issue , VDC_UV_TIME to 500ms

/******************************************************************************************/

typedef struct _PARAMETERS_VAL
{
  //Output
  WORD OVP_VOUT_OV_FAULT_LIMIT ;
  WORD OVP_VOUT_OV_WARN_LIMIT ;
  WORD UVP_VOUT_UV_WARN_LIMIT ;
  WORD UVP_VOUT_UV_FAULT_LIMIT ;
  WORD OCP_IOUT_OC_FAULT_LIMIT ;
  WORD OCP_IOUT_OC_FAULT_H_LIMIT ;
  WORD OCP_IOUT_OC_WARN_LIMIT ;
  WORD OPP_POUT_OP_FAULT_LIMIT ;
  WORD OPP_POUT_OP_WARN_LIMIT ;
  WORD SCP_FAULT_LIMIT ;
  WORD CCM_IOUT_FAULT_HLIMIT ;
  WORD CCM_IOUT_FAULT_LLIMIT ;
  WORD CCM_VOUT_COMP_HLIMIT;
  WORD CCM_VOUT_COMP_LLIMIT;

  //Input
  WORD IIN_OC_WARN_LL_LIMIT ;
  WORD IIN_OC_WARN_HL_LIMIT ;
  WORD IIN_OC_FAULT_LL_LIMIT ;
  WORD IIN_OC_FAULT_HL_LIMIT ;
  WORD PIN_OP_WARN_LIMIT ;

  //Temperature
  WORD OTP_Tpri_FAULT_LIMIT ; //
  WORD OTP_Tpri_WARN_LIMIT ; //
  WORD OTP_Tsec_FAULT_LIMIT ; //
  WORD OTP_Tsec_WARN_LIMIT ; //
  WORD OTP_Tinlet_FAULT_LIMIT ; //
  WORD OTP_Tinlet_WARN_LIMIT ; //
  WORD OTP_Tpri_Recovery_LIMIT ;
  WORD OTP_Tsec_Recovery_LIMIT ;
  WORD OTP_Tinlet_Recovery_LIMIT ; //Chris, for thermal request

  //Remote Sense
  WORD VOUT_RSENSE_VREFL ;
  WORD VOUT_RSENSE_VREFH ;

  //MFR_VIN
  WORD MFR_VIN_MAX ;
  WORD MFR_VIN_MIN ;
  WORD VIN_OV_FAULT_LIMIT[2] ;
  WORD VIN_OV_FAULT_RECOVER_LIMIT[2] ;
  WORD VIN_OV_WARN_LIMIT[2] ;
  WORD VIN_UV_FAULT_LIMIT[2] ;
  WORD VIN_UV_FAULT_RECOVER_LIMIT[2] ;
  WORD VIN_UV_WARN_LIMIT[2] ;

  //Current Sharing
} tPARAMETERS_VAL ;

extern tPARAMETERS_VAL Parameter ;


//Exported function
void init_Parameter ( ) ;

#endif

