
#ifndef __USERDATA_H__
#define __USERDATA_H__

#include "Define.h"

#define BLACKBOX_SUPPORTED		TRUE
#define SAMPLE_SET_SUPPORTED	FALSE

//#define MFR_SERIALNUMBER_EX		"66A1U01X3G5022X "      //20170921 Debug test

//20170921 Added
//~~~~~~~~~~~~~~~ Config IPMI FRU DATA FORMAT PARAMETER (8 + 72 + 64 + 32 + 80 = 256 Bytes )~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//~~~~~~~~~~~~~~~ Config COMMON HEADER Format (0X00 ~0X08), 8 Bytes ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#define FRU_FORMAT_VERSION_NUM                  1   //Config Format Version Number = 1
#define FRU_INTERNAL_AREA_OFFSET                0   //Config Internal Use Area Offset = 0, not used
#define FRU_CHASSIS_AREA_OFFSET                 0   //Config CHASSIS Area Offset = 0, not used
#define FRU_BOARD_AREA_OFFSET                   0   //Config BOARD Area Offset = 0, not used
#define FRU_PRODUCT_AREA_OFFSET                 22  //Addr 0xB0, 8*22 = 176
#define FRU_MULTI_RECORD_AREA_OFFSET            0   //Config MULTI_RECORD Area Offset = 0, not used
#define FRU_PAD                                 0   //Config MULTI_RECORD Area Offset = 0, not used
//~~~~~~~~~~~~~~~ Config MULTI RECORD AREA Format (0X08 ~0X4F),72 Bytes ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//~~~~~~~~~~~~~~~ Config INTERNAL USE AREA Format (0X50 ~0X8F), 64 Bytes ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//~~~~~~~~~~~~~~~ Config CHASSIS INFORMATION AREA (0X90 ~0XaF), 32 Bytes ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//~~~~~~~~~~~~~~  Config Product Info Area Format (0XB0 ~0XFF), 80 Bytes ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#define FRU_PRODUCT_FORMAT_VERSION_NUM                  1           //Config Product Info Area Format Version Number = 1
#define FRU_PRODUCT_FORMAT_LENGTH                       10          //Config Product Info Area Format Length = 10*8 = 80 bytes
#define FRU_PRODUCT_FORMAT_LANGUAGE                     0x19        //Language, English = 0x19
#define FRU_PRODUCT_MFR_NAME_LENGTH                     0xC6        //ASCII, Mrf name length -> 6bytes
#define MFR_NAME                                        "LITEON"    //ASCII, Mrf name
#define FRU_PRODUCT_NAME_LENGTH                         0xD0        //ASCII, Product/Model Name length -> 16bytes
#define FRU_PRODUCT_PARTNUM_LENGTH                      0xD0        //ASCII, PartNumber length -> 16bytes
#define FRU_PRODUCT_VERSION_NUM_LENGTH                  0xC2        //ASCII,Product Version Number length  -> 2bytes
#define FRU_PRODUCT_SERIALNUM_LENGTH                    0xD0        //ASCII,Product Serial Number length  -> 16bytes
#define FRU_PRODUCT_ASSET_TAG_LENGTH                    0xC8        //ASCII,Asset TAG info length  -> 8bytes
#define FRU_PRODUCT_FILE_ID_LENGTH                      0xC4        //ASCII,FRU File length  -> 4bytes
#define FRU_PRODUCT_EFM                                 0xC1        //End of Fields Marker

//~~~~~~~~~~~~~~~ Config IPMI FRU DATA FORMAT PARAMETER END ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


//#define FRU_PN_OFFSET				0x41
//#define FRU_REVISION_OFFSET			0x47
//#define FRU_CONTRY_CODE_OFFSET		0x32
//#define FRU_MANUFACTURE_ID_OFFSET 	0x34
//#define FRU_DATE_CODE_OFFSET		0x39
//#define FRU_SEQUENCE_NUM_OFFSET		0x3C
//#define FRU_CHECKSUM_OFFSET			0x4F

//#define FRU_PN_LEN				6
//#define FRU_REVISION_LEN		3
//#define FRU_CONTRY_CODE_LEN		2
//#define FRU_MANUFACTURE_ID_LEN 	5
//#define FRU_DATE_CODE_LEN		3
//#define FRU_SEQUENCE_NUM_LEN	4

#define FRU_LENOVO_BARCODE_OFFSET	0xE0	// 22 bytes
#define FRU_PN_OFFSET				0xE3	// 7 bytes
#define FRU_REVISION_OFFSET			0xE7	// 5 bytes
#define FRU_DATE_CODE_OFFSET		0xE9	// 3 bytes

#define FRU_PN_LEN				7
#define FRU_REVISION_LEN		2
#define FRU_DATE_CODE_LEN		3


#define MAX_SAMPLE_SET		8
#define MAX_FAULT_RECORD	16 //20, //20170418 Added Black Box block read, 16* 56

#define INIT_WRITE_CYCLES	0
#define MAX_LOG_COUNT		24

typedef struct _SAMPLE_SET
{
  BYTE READ_VIN[2] ;
  BYTE READ_IIN[2] ;
  BYTE READ_VOUT[2] ;
  BYTE READ_IOUT[2] ;
  BYTE READ_TEMPERATURE1[2] ;
  BYTE READ_TEMPERATURE2[2] ;
  BYTE READ_TEMPERATURE3[2] ;
  BYTE READ_FAN_SPEED_1[2] ;
  BYTE READ_POUT[2] ;
  BYTE READ_PIN[2] ;
} tSAMPLE_SET ;

#if BLACKBOX_SUPPORTED

typedef struct _FAULT_RECORD
{
  BYTE STATUS_WORD[2] ;             //20170310     AWS Need to Black Box Added
  BYTE STATUS_VOUT[1] ;
  BYTE STATUS_IOUT[1] ;
  BYTE STATUS_INPUT[1] ;
  BYTE STATUS_TEMPERATURE[1] ;
  BYTE STATUS_CML[1] ;
  BYTE STATUS_FAN_1_2[1] ;
  //BYTE STATUS_OTHER[1] ;			//20170310     AWS Need to Black Box removed
  BYTE READ_VIN[2] ;
  BYTE READ_IIN[2] ;
  BYTE READ_VOUT[2] ;
  BYTE READ_IOUT[2] ;
  BYTE READ_TEMPERATURE_1[2] ;
  BYTE READ_TEMPERATURE_2[2] ;
  BYTE READ_TEMPERATURE_3[2] ;
  BYTE READ_FAN_SPEED_1[2] ;
  BYTE READ_FAN_SPEED_2[2] ;
  BYTE READ_POUT[2] ;
  BYTE READ_PIN[2] ;
  BYTE MFR_POS_TOTAL[5] ; // 5 bytes        //20170418 Added Black Box block read
  BYTE MFR_POS_LAST[5] ; // 5 bytes         //20170418 Added Black Box block read
  BYTE BMC_UNIX_TIMESTAMP[5];// 5 bytes     //20170418 Added Black Box block read
  BYTE MFR_FW_VERSION[9] ;                  //20170418 Added Black Box block read
  BYTE DEBUG_INFO[2] ;

#if SAMPLE_SET_SUPPORTED
  tSAMPLE_SET MFR_SAMPLE_SET[MAX_SAMPLE_SET] ;
#endif
  //BYTE DEBUG_INFO[6];	//SD_FLAG & STATES
} tFAULT_RECORD ;
#endif

// 20100521 added begin ->

typedef struct _VCaliData
{
  SHORT slope ;
  SHORT CmdOffset ;
  SHORT ReportOffset ;
  SHORT MainBusOffset ;
  LONG CS_Offset ;
  SHORT CS_Slope ;
} tVCaliData ;

typedef struct _ICaliData
{
  //Iout
  SHORT slope ;
  LONG Offset ;
  SHORT slope2 ;
  LONG Offset2 ;
  SHORT slope3 ;
  LONG Offset3 ;
  //Current Share
  SHORT CS_slope ;
  LONG CS_Offset ;
  SHORT slope4 ; // [Tommy YR Chen] 20111103 added
  LONG Offset4 ;
  SHORT LCS_slope ; // [Tommy YR Chen] 20111103 added
  LONG LCS_Offset ;
} tICaliData ;

typedef struct _LOG_GENERAL
{
  BYTE Log_Sum ;
  BYTE Latest_Log_Index ;
  DWORD_VAL Total_Output_Energy ; //WH
  DWORD_VAL Total_Operate_Time ;
  DWORD_VAL Write_Cycles ;
  QWORD_VAL Total_Output_Power ;
} tLOG_GENERAL ;

typedef struct _LOG_CONTENT
{
  BYTE Index ;
  BYTE Status_MFR_Specific ;
  WORD_VAL Status_Debug ;
  WORD_VAL Status_Word ;
  DWORD_VAL Happen_Time ;
} tLOG_CONTENT ;

// 20100521 added end <-

typedef struct _FRU_COMMON_HEADER       //20170921 added fru common header
{
	BYTE FormatVer;			/* 0x01 */
	BYTE Internal_use_off;          /* multiple of 8 bytes */
	BYTE Chassis_info_off;          /* multiple of 8 bytes */
	BYTE Board_area_off;		/* multiple of 8 bytes */
	BYTE Product_area_off;          /* multiple of 8 bytes */
	BYTE Multirecord_off;           /* multiple of 8 bytes */
	BYTE Pad;			/* must be 0 */
	BYTE Checksum;                  /* sum modulo 256 must be 0 */
}tFRU_COMMON_HEADER;

typedef union _IPMI_FruProductInfo       //20170921 added ProductInfoArea
{
  BYTE ProductInfoBuf[80] ;
  struct
  {
    BYTE ProductAreaVer;
    BYTE ProductAreaLen;
    BYTE LanguageCode;
    BYTE MfrNameTypeLen;
    BYTE MfrNameBuf[6];
    BYTE ProductNameTypeLen;
    BYTE ProductNameBuf[16];
    BYTE PartNumberTypeLen;
    BYTE PartNumberBuf[16];
    BYTE ProductVerTypeLen;
    BYTE ProductVerBuf[2];
    BYTE SerialNumberTypeLen;
    BYTE SerialNumberBuf[16];
    BYTE AssetTagTypeLen;
    BYTE AssetTagBuf[8];
    BYTE FruFileIDTypeLen;
    BYTE FruFileIDBuf[4];
    BYTE EFM;   //End of Fields Marker
    BYTE ProductCheckSum;
  } ProductInfoData ;
} tIPMI_FruProductInfo;              //20170921 added

typedef union _IPMI_FruFormat       //20170921 added
{
  BYTE frudata[256] ;
  struct
  {
    tFRU_COMMON_HEADER CommonHeader;
    BYTE MulitiRecordInfoArea[72];
    BYTE InternalUseArea[64];
    BYTE ChassisInfoArea[32];
    tIPMI_FruProductInfo ProductInfoArea;
  } area ;
} tIPMI_FruFormat;              //20170921 added

typedef union _UserDataPage1
{
  BYTE data[512] ;                      
  struct
  {
    //BYTE FRU[256] ;                     //20170921 Removed
    tIPMI_FruFormat FRU;                  //20170921 added
    tICaliData Iout[TOTAL_OUTPUT_NUM] ; //20170921 added (2+4)*6 = 36 Bytes
    tVCaliData Vout[TOTAL_OUTPUT_NUM] ; //20170921 added 14 Bytes
    SHORT StbVoutOffset ;
    SHORT VinGain ;
    SHORT IinGain ;
    SHORT PinGain ;
    SHORT IinOffset ;
    SHORT VCS_Slope ;
    LONG VCS_Offset ;
    BYTE Reserve[188] ;                 //20170921 added ( 512 - 256 -36 - 14 - ((2*6) + 4) ) - 2 = 188
    BYTE HW_CC_HB;			//20170921 added, HW_CC CODE, "01", '0'
    BYTE HW_CC_LB;                      //20170921 added, HW_CC CODE, "01", '1'
    //BYTE Reserve[214] ;
  } region ;

} tUserDataPage1 ;

typedef union _UserDataPage2
{
#if (SAMPLE_SET_SUPPORTED && BLACKBOX_SUPPORTED)
  BYTE data[1024] ;

  struct
  {

    struct
    {
      tFAULT_RECORD FaultRecord[MAX_FAULT_RECORD] ; //5*(41+(20*MAX_SAMPLE_SET)) = 1005 bytes
    } BlackBox ;
    DWORD_VAL POS ;
    BYTE BL_VER ;
    BYTE FruModified_Flag ;
    WORD_VAL Calibration_Flag ;
    WORD_VAL PriFwRev ;
    BYTE Reserve[9] ;
  } region ;
#elif BLACKBOX_SUPPORTED
  BYTE data[1024] ;

  struct
  {

    struct
    {
      tFAULT_RECORD FaultRecord[MAX_FAULT_RECORD] ; //20*47 = 940 bytes, //16*56 = 896 bytes, , //20170418 Added Black Box block read
    } BlackBox ;
    BYTE BB_Reserve[44];                            //black box Reserve: 940- 896 = 44 bytes, //20170418 Added Black Box block read,
    DWORD_VAL POS ; //Address ABAC
    BYTE BL_VER ;
    BYTE FruModified_Flag ;
    WORD_VAL Calibration_Flag ;
    WORD_VAL PriFwRev ;
    WORD_VAL VoutCommand ;
    WORD_VAL VoutCommand_LinearFmt ;
    BYTE Reserve[70] ;                  //[1024 - (20*47 + 14)] = 70
    //BYTE Reserve[70] ;                  [1024 - (20*47 + 14)] = 70 //20170418 Removed
    //BYTE Reserve[2] ;                  //20170418 Added Black Box block read     [1024 - (18*56 + 14)] = 2
  } region ;
#else
  BYTE data[1024] ;

  struct
  {
    DWORD_VAL POS ;
    BYTE BL_VER ;
    BYTE FruModified_Flag ;
    WORD_VAL Calibration_Flag ;
    WORD_VAL PriFwRev ;
    BYTE Reserve[1014] ;
  } region ;

#endif

} tUserDataPage2 ;

typedef union _UserDataPage3
{
  BYTE data[512] ;

  struct
  {
    tLOG_GENERAL logGeneral ;
    BYTE logIndex ;
    tLOG_CONTENT logContent[MAX_LOG_COUNT] ;
    //BYTE Reserve[258] ;       //20170619 removed
    BYTE Reserve[248] ;         //20170619 Modify UserDataPage3 Reserve issue
  } region ;
} tUserDataPage3 ;

typedef struct _USER_DATA_PAGE
{
  tUserDataPage1 Page1 ;
  tUserDataPage2 Page2 ;
  tUserDataPage3 Page3 ;
} tUSER_DATA_PAGE ;

typedef struct _SAMPLE_NODE
{
  tSAMPLE_SET node ;
  BYTE* pNextNode ;
} tSAMPLE_NODE ;


extern tUSER_DATA_PAGE UserData ;
extern SHORT CS_Slope_Temp ;
extern LONG CS_Offset_Temp ;

//extern BYTE HW_CompatibleCodeStr[2];   // 20150112 Added Compatible Code Fun

//Exported functions
#if BLACKBOX_SUPPORTED
void SaveToBlackBox ( ) ;
BYTE* GetDataFromBlackBox ( BYTE cmd ) ;
#endif
void CaptureFault ( ) ;
void SaveUserDataPage1ToFlash ( ) ;
void SaveUserDataPage2ToFlash ( ) ;
void SaveUserDataPage3ToFlash ( ) ;
BYTE CaluIPMIchecksum( BYTE* IpmiDataBuf, BYTE IpmiDataLen);   //20170921 Added
void LoadIpmiDataFormat();                                      //20170921 Added
void LoadUserDataFromFlash ( ) ;
#if SAMPLE_SET_SUPPORTED
void UpdateSampleSets ( ) ;
#endif
void SaveToLogContent ( ) ;



#endif

