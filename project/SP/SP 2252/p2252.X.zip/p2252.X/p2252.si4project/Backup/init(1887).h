
#ifndef __INIT_H__
#define __INIT_H__

#define DITHER_ENABLED	0

// Example:
// 10^9 ns /125k = 8000ns per PWM cycle 
// 8000 ns / 2.08 ns = 3846 counts (PWM Period)
#define UCC28950_SYNC_FREQ	100000
#define GET_PERIOD(FREQ)	((LONG)1000000000/FREQ)*100/208
#define PWM_PERIOD	GET_PERIOD(UCC28950_SYNC_FREQ)

#if DITHER_ENABLED
#define UCC28950_SYNC_FREQ_LOW		116000
#define UCC28950_SYNC_FREQ_HIGH		130000
#define PWM_PERIOD_LOW		GET_PERIOD(UCC28950_SYNC_FREQ_LOW)
#define PWM_PERIOD_HIGH		GET_PERIOD(UCC28950_SYNC_FREQ_HIGH)
#define DIFF_PERIOD_TOTAL	(GET_PERIOD(UCC28950_SYNC_FREQ_LOW) - GET_PERIOD(UCC28950_SYNC_FREQ_HIGH))
//#define DIFF_COUNT	(DIFF_PERIOD_TOTAL / 50)	// 20us * 50 = 1ms
#define DIFF_COUNT	(DIFF_PERIOD_TOTAL / 14)	// 20us * 14 = 240us

#endif



#define DUTY_12V2_REF	            24894	// 12.2V

#if defined(Config_12V35_REF)                           //[davidchchen]20160307 Added
    //#define DUTY_12V3_REF	            25098	// 12.3V => (12.3/12.5)*25506 = 25098, [davidchchen]20150105 Added
    #define DUTY_12V35_REF	            25200	// 12.3V => (12.35/12.5)*25506 = 25200, [davidchchen]20160307 Added
#elif defined(Config_12V25_REF)
    #define DUTY_12V25_REF	            24996	// 12.25V => (12.25/12.5)*25506 = 24996, [davidchchen]20151223 Added
#elif defined(Config_12V5_REF)
    #define DUTY_12V5_REF	            25506	// 12.5V
#endif

#define DUTY_12V_STEP_DOWN_REF      24282	// 11.9V         
#define SOFTSTART_SLOPE_ADJUSTMENT	9 //6       // [davidchchen]20161007 Changed

//Exported function
void init_SetupClock ( void ) ;
void init_GPIO ( void ) ;
void init_Timer ( void ) ;
void init_ADC ( void ) ;
void init_PWM ( void ) ;

#if Config_Input_CN       //[davidchchen]20160427 added Input Change Notification
void init_Input_CN ( void );                //[davidchchen]20160427 added
#endif

//void init_Comparator ( void ) ;           //[davidchchen]20160427 removed
//void init_External_Interrupt ( void ) ;   //[davidchchen]20160427 removed






#endif

