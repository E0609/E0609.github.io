#ifndef __ISR_H__
#define __ISR_H__

#include "Define.h"

typedef struct _ADC
{
  volatile unsigned int Iout ;
  volatile unsigned int Iout_Cal ;
  volatile unsigned int Iout_FF ;
  volatile unsigned long Iout_LPF ;
  
  volatile unsigned int Iout_report ;
  volatile unsigned int Iout_report_Cal ;
  volatile unsigned int Iout_report_FF ;
  volatile unsigned long Iout_report_LPF ;
  
  volatile unsigned int IoutCS ;
  volatile unsigned int IoutCS_FF ;
  volatile unsigned long IoutCS_LPF ;
  
  volatile unsigned int Vout ;
  volatile unsigned int Vout_Cal ;
  volatile unsigned int Vout_FF ;
  volatile unsigned long Vout_LPF ;
  
  volatile unsigned int VoutBus ;
  volatile unsigned int VoutBus_Cal ;
  volatile unsigned int VoutBus_FF ;
  volatile unsigned long VoutBus_LPF ;
  
  volatile unsigned int CS_PWM_FB ;
  volatile unsigned int CS_PWM_FB_Cal ;
  volatile unsigned int CS_PWM_FB_FF ;
  volatile unsigned long CS_PWM_FB_LPF ;
  
  volatile unsigned int StbVout ;
  volatile unsigned int StbVout_Cal ;
  volatile unsigned int StbVout_FF ;
  volatile unsigned int StbVout_LPF ;
  
  volatile unsigned int StbIout ;
  volatile unsigned int StbIout_Cal ;
  volatile unsigned int StbIout_FF ;
  volatile unsigned int StbIout_LPF ;
  
  volatile unsigned int StbVbus ;
  volatile unsigned int StbVbus_Cal ;
  volatile unsigned int StbVbus_FF ;
  volatile unsigned int StbVbus_LPF ;
  
  volatile unsigned int Tinlet ;
  volatile unsigned int Tinlet_FF ;
  volatile unsigned int Tinlet_LPF ;
  volatile unsigned int Tsec ;
  
  volatile unsigned int Tsec_FF ;
  volatile unsigned int Tsec_LPF ;
  volatile unsigned int MasterPriIS ;
  volatile unsigned int MasterPriIS_FF ;
  
  volatile unsigned int MasterPriIS_LPF ;
  volatile unsigned int SlavePriIS ;
  volatile unsigned int SlavePriIS_FF ;
  volatile unsigned int SlavePriIS_LPF ;
} tADC ;

typedef struct
{
  unsigned int SetVoltage ;
  unsigned int OldSetVoltage ;
  volatile unsigned int SoftstartVoltage ;
} tVref ;


extern tADC ADC ;
extern tVref Vref ;

/*Exported function*/


#endif //__TIMER_H__

