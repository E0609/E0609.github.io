
#ifndef __PROCESS_H__
#define __PROCESS_H__

#include "Define.h"

typedef struct SD_FlagBITS
{

  union //u16bits
  {

    struct
    {
      //Low Byte
      unsigned FAN_LOCK : 1 ; //LSB bit0 //fan fault, fan_rpm < 1000 last for 15 seconds
      unsigned OVP_SD : 1 ; //over voltage
      unsigned OTP_SD : 1 ; //over temperature SD (start after temperature normal)
      unsigned OCP_SD : 1 ; //over current
      unsigned UV_SD : 1 ; //under voltage
      unsigned PS_ON_OFF : 1 ; //power supply on
      unsigned PS_KILL_OFF : 1 ;
      unsigned LATCH_SD : 1 ; //MSB bit7 //12V off til to PS_ON
      //High Byte
      unsigned OPP_SD : 1 ;
      unsigned SCP_SD : 1 ;
      unsigned PFC_NOTOK : 1 ;
      unsigned STB_UVP : 1 ; // standby under voltage
      unsigned STB_OVP : 1 ; // standby over voltage
      unsigned STB_OCP : 1 ; // standby over current
      unsigned STB_OTP : 1 ; // standby over temperature
      unsigned ISP_MODE : 1 ;
    } ;

    struct
    {
      unsigned SD_Flag_LB : 8 ;
      unsigned SD_Flag_HB : 8 ;
    } ;

    WORD Val ;
  } ;
} tSD_FlagBITS ;

typedef union _MFR_STATUS
{
  BYTE Val ;

  struct
  {
    unsigned AC_NOTOK : 1 ;
    unsigned PFC_OV : 1 ;
    unsigned SCI_P2S_FAIL : 1 ;
    unsigned SCI_T2S_FAIL : 1 ;
    unsigned V12_UVW : 1 ;
    unsigned V12_OCW : 1 ;
    unsigned VSB_UVW : 1 ;
    unsigned SCI_PriRx_FAIL : 1 ;               //20160503 added primary and secondary side communication error
  } bits ;
} tMFR_STATUS ;

typedef enum
{
  N_IOUT = 0 ,
  N_VOUT ,
  N_POUT ,
  N_VIN ,
  N_IIN ,
  N_PIN ,
  N_FAN_SPEED ,
  N_FAN_CMD ,
  N_TEMPERATURE ,
} N_TYPE ;

//Exported variable
extern tSD_FlagBITS _SD_Flag ;
extern tMFR_STATUS MFR_Status ;
extern unsigned int T_Pri ;
extern unsigned int T_Sec ;
extern unsigned int T_Inlet ;
extern DWORD gVin ;
extern DWORD gIin ; //Peter
extern DWORD gPin ; //Peter
extern DWORD gVout ;
extern DWORD gIout ;
extern DWORD gPout ;

//Exported function
void ResetSD_Flag ( ) ;
void PSOnOff_ResetSD_Flag ( ) ;
BYTE IsReportCmd ( BYTE cmd ) ;
void ScanProcess ( ) ;
char GetN ( BYTE type , WORD input ) ;
void VoutProcess ( ) ;


#endif

