
#ifndef __UTIL_H__
#define __UTIL_H__



//Exported function
WORD EncodeAsDirectFmt ( WORD x , WORD m , WORD b , BYTE r ) ;
DWORD LinearFmt_YtoX ( WORD Y , BYTE Gain ) ;
WORD LinearFmt_XtoY ( DWORD X , char N , BYTE Gain ) ;
WORD GetAvg ( WORD pBuf[] , WORD newData , BYTE* index , BYTE bufSize , DWORD* sum , BYTE exp ) ;



#endif

