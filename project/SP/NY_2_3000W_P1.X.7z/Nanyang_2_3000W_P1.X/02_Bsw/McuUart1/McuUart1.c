/*******************************************************************************
 * \file    McuUart1.c
 * \brief   UART1 communication driver
 *
 * \section AUTHOR
 *    1. CIPS
 *
 * \section SVN
 *  $Date$
 *  $Author$
 *  $Revision$
 *
 * \section LICENSE
 * Copyright (c) 
 * All rights reserved.
 *******************************************************************************/

/*******************************************************************************
 * Included header
 ******************************************************************************/
#include <p33EP64GS504.h>
#include "DataFormat.h"
#include "Rtv.h"
#include "Crc.h"
#include "McuClock.h"
/* Module header */
#include "McuUart1.h"
#include "Rtv.h"

/*******************************************************************************
 * Local constants and macros (private to module)
 ******************************************************************************/
/* UART peripheral register relative definition, depends on individual MCU*/
#define MG_UART1_RX_DATA_REG        U1RXREG              /* Rx register */
#define MG_UART1_TX_DATA_REG        U1TXREG              /* Tx register */
#define MG_UART1_TX_CMPLT_FLG       U1STAbits.TRMT       /* Tx shift register empty  */
#define MG_UART1_RX_DATA_RDY_FLG    U1STAbits.URXDA      /* Rx data flag */
#define MG_UART1_BAUD_RATE_SET      (((FCY / UART1_BAUDRATE)>>4) - 1UL)
#define MG_UART1_RX_REG_FERR        U1STAbits.FERR       /* RX register frame error */
#define MG_UART1_RX_REG_OERR        U1STAbits.OERR       /* RX register overrun error */
#define MG_UART1_MODULE_ENA         U1MODEbits.UARTEN    /* UART peripheral enable */

/*******************************************************************************
 * Local data types (private typedefs / structs / enums)
 ******************************************************************************/

/*******************************************************************************
 * Local data (private to module)
 ******************************************************************************/
static ST_UART_DATA UART1_mg_sUartData;
static uint8 UART1_mg_u8DataRxDurTxFlg;

/*******************************************************************************
 * Local function prototypes (private to module)
 ******************************************************************************/

/*******************************************************************************
 * DataFormat functions (public to other modules)
 ******************************************************************************/

/** *****************************************************************************
 * \brief         Initialize the UART1 peripheral
 *
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 ***************************************************************************** */
void Mcu_Uart1HwInit(void)
{

  U1MODEbits.UARTEN = 0; /* Bit15 TX, RX DISABLED, ENABLE at end of func */
  U1MODEbits.USIDL = 0; /* Bit13 Continue in Idle */
  U1MODEbits.IREN = 0; /* Bit12 No IR translation */
  U1MODEbits.RTSMD = 0; /* Bit11 Simplex Mode */
  U1MODEbits.UEN = 0; /* Bits8, 9 TX,RX enabled, CTS,RTS not */
  U1MODEbits.WAKE = 0; /* Bit7 No wake up */
  U1MODEbits.LPBACK = 0; /* Bit6 No loop back */
  U1MODEbits.ABAUD = 0; /* Bit5 No autobaud */
  U1MODEbits.URXINV = 0; /* Bit4 IdleState = 1 */
  U1MODEbits.BRGH = 0; /* Bit3 16 clocks per bit period */
  U1MODEbits.PDSEL = 0; /* Bits1, 2 8bit, No Parity */
  U1MODEbits.STSEL = 0; /* Bit0 One Stop Bit */

  U1BRG = MG_UART1_BAUD_RATE_SET; /* Set baudrate */

  /* Load all values in for U1STA SFR */
  U1STAbits.UTXISEL1 = 0; /* Bit15 Interrupt when char is transferred */
  U1STAbits.UTXINV = 0; /* Bit14 N/A, IRDA config */
  U1STAbits.UTXISEL0 = 0; /* Bit13 Interrupt when char is transferred */
  U1STAbits.UTXBRK = 0; /* Bit11 Disabled */
  U1STAbits.UTXEN = 0; /* Bit10 TX pins controlled by io port */
  U1STAbits.URXISEL = 0; /* Bits6, 7 Interrupt on character received */
  U1STAbits.ADDEN = 0; /* Bit5 Address detect disabled */

  /* Init interrupt functions */
  //  IPC2bits.U1RXIP    = UART_RX_INT_PRIO;
  //  IPC3bits.U1TXIP    = UART_TX_INT_PRIO;
  IFS0bits.U1TXIF = 0; /* Clear transmit interrupt flag */
  IEC0bits.U1TXIE = 0; /* Enable transmit interrupt */
  IFS0bits.U1RXIF = 0; /* Clear receive interrupt flag */
  IEC0bits.U1RXIE = 0; /* Enable receive interrupt */

  U1MODEbits.UARTEN = 1; /* Enable uart */
  U1STAbits.UTXEN = 1; /* Enable tranmitter */
}

/** *****************************************************************************
 * \brief         Uart relative data init
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 ***************************************************************************** */
void UART1_DataInit(void)
{
  uint16 u16Cnt;

  UART1_mg_sUartData.u16TxDataCnt = 0U;
  UART1_mg_sUartData.u16RxDataCnt = 0U;
  UART1_mg_sUartData.u16RxByteTmOutEna = FALSE;
  UART1_mg_sUartData.u16RxByteTmOutCnt = UART1_RX_BYTE_TIMEOUT;
  UART1_mg_sUartData.u16RxFrameTmOutEna = FALSE;
  UART1_mg_sUartData.u16RxFrameTmOutCnt = UART1_RX_FRAME_TIMEOUT;
  UART1_mg_sUartData.u16TxTmOutEna = FALSE;
  UART1_mg_sUartData.u16TxTmOutCnt = UART1_TX_TIMEOUT;
  UART1_mg_u8DataRxDurTxFlg = FALSE;

  u8Uart1FrameTmoutFlg = FALSE;
  u8Uart1ByteTmoutFlg = TRUE; /* Set TRUE to start the first TX */
  u8Uart1TxTmoutFlg = TRUE; /* Set TRUE to start the first TX */

  uUart1Status.Byte = 0U;
  u8Uart1RxNewFrame = FALSE;

  /* Initialize receive buffer */
  for (u16Cnt = 0U; u16Cnt < UART1_RX_BUF_SIZE; u16Cnt++)
  {
    au8Uart1RxBuf[u16Cnt] = 0U;
  }
  u16Uart1RxDataNbr = 0U;

  u16Uart1RxCrc = CRC_INIT_00;
}

/** *****************************************************************************
 * \brief         TX data by UART1
 *
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 ***************************************************************************** */
void UART1_TxData(void)
{ /* Note: should be implemented in <= 1ms routine */
  static uint16 u16Crc = CRC_INIT_00;
  static WORD_VAL u16CrcTemp;

  if (u8Uart1TxBufUpdated) /* Txbuf array is updated */
  {
    if (MG_UART1_TX_CMPLT_FLG) /* Last data TX is complete */
    {
      if (UART1_mg_sUartData.u16TxDataCnt < u16Uart1TxDataNbr) /* Tx if Data Nbr != 0 */
      {
#if (TRUE == UART_CAL_CRC_DISTRIBUTED)
        if (UART1_mg_sUartData.u16TxDataCnt == u16Uart1TxDataNbr - 2U)
        {
          u16CrcTemp.u16Val = u16Crc;
          au8Uart1TxBuf[UART1_mg_sUartData.u16TxDataCnt] = u16CrcTemp.Bytes.LB; /* Add real crc16 into TxBuf */
        }
        else if (UART1_mg_sUartData.u16TxDataCnt == u16Uart1TxDataNbr - 1U)
        {
          au8Uart1TxBuf[UART1_mg_sUartData.u16TxDataCnt] = u16CrcTemp.Bytes.HB; /* Add real crc16 into TxBuf */
        }
        else
        {
          CRC_u16GetCrc16(&u16Crc, au8Uart1TxBuf[UART1_mg_sUartData.u16TxDataCnt]);
        }
#endif
        MG_UART1_TX_DATA_REG = au8Uart1TxBuf[UART1_mg_sUartData.u16TxDataCnt++];
      }
      else /* A frame Tx complete */
      {
        u16Crc = CRC_INIT_00; /* Reset crc for next frame */
        u8Uart1TxBufUpdated = FALSE; /* Tx array can be updated again */
        UART1_mg_sUartData.u16TxDataCnt = 0U;

        /* Begin to monitor rx frame timeout */
        if ((!u8Uart1BroadcastFlg) && /* if broadcast frame, no need to monitor */
            (!UART1_mg_u8DataRxDurTxFlg)) /* if data received during TX, no need to monitor */
        {
          UART1_mg_sUartData.u16RxFrameTmOutEna = TRUE;
          UART1_mg_sUartData.u16RxFrameTmOutCnt = UART1_RX_FRAME_TIMEOUT;
        }
        UART1_mg_u8DataRxDurTxFlg = FALSE;

        /* Begin to monitor TX timeout, the minimum duration between two TX */
        UART1_mg_sUartData.u16TxTmOutEna = TRUE;
        UART1_mg_sUartData.u16TxTmOutCnt = UART1_TX_TIMEOUT;
      }
    }
  }
}

/** *****************************************************************************
 * \brief         RX data by UART1
 *
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 ***************************************************************************** */
void UART1_RxData(void)
{
  uint8 u8Dummy;

  /* Check UART peripheral register error before read RX REG */
  if (MG_UART1_RX_REG_FERR)
  { /* For FERR, just read it */
    uUart1Status.Bit.u8UartRegErr = TRUE; /* Set status bit */
    u8Dummy = MG_UART1_RX_DATA_REG; /* Read RX REG */
    return;
  }
  if (MG_UART1_RX_REG_OERR)
  { /* For OERR, Must clear the overrun error to keep UART receiving */
    uUart1Status.Bit.u8UartRegErr = TRUE; /* Set status bit */
    MG_UART1_RX_REG_OERR = 0U; /* reset FIFO */
    return;
  }

  /* In order to be compatible with rx interrupt method, check rx reg first*/
  if (MG_UART1_RX_DATA_RDY_FLG) /* A new data is received */
  {
    u8Dummy = MG_UART1_RX_DATA_REG; /* Read RX REG */
    UART1_mg_sUartData.u16RxByteTmOutEna = FALSE; /* Stop timer */
    UART1_mg_sUartData.u16RxFrameTmOutEna = FALSE; /* Stop timer */
    if (!u8Uart1RxNewFrame) /* Last frame has been handled */
    {
      au8Uart1RxBuf[UART1_mg_sUartData.u16RxDataCnt++] = u8Dummy; /* RX data */

#if (TRUE == UART_CAL_CRC_DISTRIBUTED)
      CRC_u16GetCrc16(&u16Uart1RxCrc, u8Dummy);
#endif

#if (TRUE == UART_TX_ONCE_RX_ADDR)
      if (2U == UART1_mg_sUartData.u16RxDataCnt)
      {
        if ((UART_FRAME_STX == au8Uart1RxBuf[0]) &&
            (u8Uart1LocalMcuAddr == au8Uart1RxBuf[1]))
        {
          u8Uart1LocalMcuFlg = TRUE; /* Begin to TX once receive local address */
        }
      }
#endif

      if (UART1_mg_sUartData.u16RxDataCnt < UART1_RX_BUF_SIZE)
      {
        /* Begin to monitor rx byte timeout */
        UART1_mg_sUartData.u16RxByteTmOutEna = TRUE;
        UART1_mg_sUartData.u16RxByteTmOutCnt = UART1_RX_BYTE_TIMEOUT;
      }
      else /* Rx buffer if full, begin to handle frame */
      {
        UART1_mg_sUartData.u16RxByteTmOutEna = FALSE;
        u16Uart1RxDataNbr = UART1_mg_sUartData.u16RxDataCnt;
        UART1_mg_sUartData.u16RxDataCnt = 0U;
        u8Uart1RxNewFrame = TRUE;
      }

      /* if slaver begins to TX when receive local address */
      if (u8Uart1TxBufUpdated)
      {
        UART1_mg_u8DataRxDurTxFlg = TRUE; /* data received when Tx is ongoing */
      }
    }
    else /* Tx too fast, Rx buffer has not been handled */
    {
      uUart1Status.Bit.u8InvalidData = TRUE;
    }
  }
}

/** *****************************************************************************
 * \brief         Monitor UART1 timeout
 *
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 ***************************************************************************** */
void UART1_TmOutMon(void)
{
  static uint16 u16UartStatusRstCnt = 0;

  u16UartStatusRstCnt++;
  if (!u16UartStatusRstCnt) /* reset uart status every 65s */
  {
    /* If Boot Mode has been set, should not clear it */
    if (FALSE == uUart1Status.Bit.u8BootMode)
    {
      uUart1Status.Byte = 0;
    }
  }

  /* Byte timeout timer */
  if (TRUE == UART1_mg_sUartData.u16RxByteTmOutEna)
  {
    if (0U < UART1_mg_sUartData.u16RxByteTmOutCnt)
    {
      UART1_mg_sUartData.u16RxByteTmOutCnt--;
    }
    else
    {
      /* Timeout, stop timer */
      UART1_mg_sUartData.u16RxByteTmOutEna = FALSE;

      /* Byte timeout, new frame is received */
      uUart1Status.Bit.u8ByteTmout = TRUE; /* note: this is not a fault condition */
      u16Uart1RxDataNbr = UART1_mg_sUartData.u16RxDataCnt;
      UART1_mg_sUartData.u16RxDataCnt = 0U;
      u8Uart1RxNewFrame = TRUE; /* Begin to handle data in RX buffer */
      u8Uart1ByteTmoutFlg = TRUE; /* Flag for host */
    }
  }

  /* Frame timeout timer */
  if (TRUE == UART1_mg_sUartData.u16RxFrameTmOutEna)
  {
    if (0U < UART1_mg_sUartData.u16RxFrameTmOutCnt)
    {
      UART1_mg_sUartData.u16RxFrameTmOutCnt--;
    }
    else
    {
      /* Timeout, stop timer */
      UART1_mg_sUartData.u16RxFrameTmOutEna = FALSE;

      /* Frame timeout, no data received, if host, begin to TX again */
      uUart1Status.Bit.u8FrameTmout = TRUE;
      u8Uart1FrameTmoutFlg = TRUE; /* Flag for host */
    }
  }
  /* TX timeout timer */
  if (TRUE == UART1_mg_sUartData.u16TxTmOutEna)
  {
    if (0U < UART1_mg_sUartData.u16TxTmOutCnt)
    {
      UART1_mg_sUartData.u16TxTmOutCnt--;
    }
    else
    {
      /* Timeout, stop timer */
      UART1_mg_sUartData.u16TxTmOutEna = FALSE;

      /* Tx timeout, it's time to Tx next frame */
      u8Uart1TxTmoutFlg = TRUE;
    }
  }
}

/*******************************************************************************
 * Local functions (private to module)
 ***************************************************************************** */

/*
 * End of file
 */

