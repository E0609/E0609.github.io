/* 
 * File:   Crc.h
 * Author: CIPS
 *
 * Created on 6 October, 2020, 9:39 AM
 */

#ifndef CRC_H
#define	CRC_H

#ifdef	__cplusplus
extern "C" {
#endif

    /*******************************************************************************
     * DataFormat constants and macros
     ******************************************************************************/
#include "DataFormat.h"
    /*******************************************************************************
     * DataFormat data types (typedefs / structs / enums)
     ******************************************************************************/

    /*******************************************************************************
     * DataFormat data
     ******************************************************************************/

    /*******************************************************************************
     * DataFormat function prototypes
     ******************************************************************************/

    /** *****************************************************************************
     * \brief         Calculate crc16
     *
     * \param[in]     uint16 * pu16InCrc  uint8 u8InData
     * \param[in,out] -
     * \param[out]    -
     *
     * \return        -
     *
     *******************************************************************************/
    void CRC_u16GetCrc16(uint16 * pu16InCrc, uint8 u8InData);
    /** *****************************************************************************
     * \brief         Calculate crc8. Add data to crc calculated as 16 bit value 
     *                used the polynominal value 0x8005.
     * \param[in]     crc - pointer to crc byte
     *                data - data for crc calculation
     * \param[in,out] -
     * \param[out]    -
     *
     * \return        uint8
     *
     *******************************************************************************/
    uint8 CRC_u8GetCrc8(uint8 u8InCrc, uint8 u8InData);


#ifdef	__cplusplus
}
#endif

#endif	/* CRC_H */

