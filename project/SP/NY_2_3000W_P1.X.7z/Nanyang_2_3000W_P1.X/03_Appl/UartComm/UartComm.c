/** *****************************************************************************
 * \file    UartComm.c
 * \brief   UART1 communication handler
 *
 * \section AUTHOR
 *    1. 
 *
 * \section SVN
 *  $Date$
 *  $Author$
 *  $Revision$
 *
 * \section LICENSE
 * Copyright (c) 
 * All rights reserved.
 ***************************************************************************** */

/*******************************************************************************
 * Included header
 ******************************************************************************/
#include <p33EP64GS504.h>
#include "DataFormat.h"
#include "xc.h"
/* Module header */
#include "UartComm.h"
#include "Rtv_Uart.h"
#include "Crc.h"
#include "Protection.h"
#include "McuGPIO.h"
#include "Rtv.h"
/*******************************************************************************
 * Local constants and macros (private to module)
 ******************************************************************************/

/*******************************************************************************
 * Local data types (private typedefs / structs / enums)
 ******************************************************************************/


/*******************************************************************************
 * Local data (private to module)
 ******************************************************************************/

static uint8 UART1_mg_u8TxMcuFlg;
/*******************************************************************************
 * Local function prototypes (private to module)
 ******************************************************************************/

/*******************************************************************************
 * DataFormat data (public to other modules)
 ******************************************************************************/

/*******************************************************************************
 * DataFormat functions (public to other modules)
 ******************************************************************************/

/** *****************************************************************************
 * \brief         UART1 application data initial
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 ***************************************************************************** */
void INTCOM1_ComDataInit(void)
{
  uint16 u16Cntr;

  /* Initialize transmit buffer */
  for (u16Cntr = 0U; u16Cntr < UART1_TX_BUF_SIZE; u16Cntr++)
  {
    au8Uart1TxBuf[u16Cntr] = 0U;
  }
  u16Uart1TxDataNbr = 0U;
  u8Uart1TxBufUpdated = FALSE;
  //u8Uart1BroadcastFlg = FALSE;

  /* TX to Pri1 MCU */
  UART1_mg_u8TxMcuFlg = 1U; /* 1:Pri 1, 2:Pri 2, 3:Pri all */

  INTCOM1_PRI1_UART_FAIL = 0;
//  dataRXflg = 0;
  //PMBUS_uSysStatu0.Bits.AUX_MODE = TRUE;
  //  uUart1Pri1VinAD.ALL = 0;
  //  uUart1Pri2VinAD.ALL = 0;
}

/** *****************************************************************************
 * \brief         Load TX buffer for transmission to primary side
 *    ______________________________________________________
 *   |     |         |         |       |     |       |      |
 *   | STX | MCUADDR | DataLen | Data0 | ... | DataN | CRC16 |
 *   |_____|_________|_________|_______|_____|_______|______|
 *   |     |         |         |       |     |       |      |
 *   |  AA |10/11/1F |   N+1   |       | ... |       |      |
 *   |_____|_________|_________|_______|_____|_______|______|
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * 
 * \return        -
 *
 ***************************************************************************** */
void INTCOM1_GetTxData(void)
{
  static uint8 u8TxMcuCnt = 0U;


  /* Host begins to TX when RX buf has been handled or frame timeout */
  if (((u8Uart1ByteTmoutFlg) && (!u8Uart1RxNewFrame)) || /* RX buf was handled */
      (u8Uart1FrameTmoutFlg)) /* Braodcast frame */
  {
    if ((!u8Uart1TxBufUpdated) && (u8Uart1TxTmoutFlg)) /* Last frame has been TX and Tx timeout */
    {
      u8Uart1ByteTmoutFlg = FALSE;
      u8Uart1FrameTmoutFlg = FALSE;
      u8Uart1TxTmoutFlg = FALSE;
      //      u8Uart1BroadcastFlg    = FALSE;

      u16Uart1TxDataNbr = 0U;

      if (UART1_TX_PRI_1 == u8TxMcuCnt)/* Load TX buffer for Primay MCU 1 */ 
      {
        au8Uart1TxBuf[u16Uart1TxDataNbr++] = UART_FRAME_STX; /* STX 0xAA */
        au8Uart1TxBuf[u16Uart1TxDataNbr++] = UART_ADDR_PRI_1; /* ADDR 0x10 */
        au8Uart1TxBuf[u16Uart1TxDataNbr++] = UART_MIN_FRAME_LEN; /* LEN 6 */

        /* DATA start */
        /* DATA0 is fixed for Comm status */
        au8Uart1TxBuf[u16Uart1TxDataNbr++] = 0x11; //uUart1Status.Byte; /* DATA0 */
        au8Uart1TxBuf[u16Uart1TxDataNbr++] = 0x22; //uComToPriStatus.Bytes.LB;
        au8Uart1TxBuf[u16Uart1TxDataNbr++] = 0x33; //uComToPriStatus.Bytes.HB;

        /* User-defined data end */
        /* DATA end */
      }
      /* Fill LEN in TX buffer */
      au8Uart1TxBuf[2] = u16Uart1TxDataNbr - UART_FRAME_AUX_LEN + 2U;

#if (TRUE == UART_CAL_CRC_DISTRIBUTED)
      /* Calculate crc when TX data byte, add dummy crc here */
      au8Uart1TxBuf[u16Uart1TxDataNbr++] = CRC_INIT_00; /* CRC16 */
      au8Uart1TxBuf[u16Uart1TxDataNbr++] = CRC_INIT_00; /* CRC16 */
#else
      /* Cal CRC16 */
      for (u16Crc.u16Val = CRC_INIT_00, u16Cnt = 0U; u16Cnt < u16Uart1TxDataNbr; u16Cnt++)
      {
        CRC_u16GetCrc16(&u16Crc.u16Val, au8Uart1TxBuf[u16Cnt]);
      }
      au8Uart1TxBuf[u16Uart1TxDataNbr++] = u16Crc.Bytes.LB; /* CRC16 */
      au8Uart1TxBuf[u16Uart1TxDataNbr++] = u16Crc.Bytes.HB; /* CRC16 */
#endif
      u8Uart1TxBufUpdated = TRUE; /* Begin to TX */
    }
  }
}

/** *****************************************************************************
 * \brief         Handle data in RX buffer
 *    ______________________________________________________
 *   |     |         |         |       |     |       |      |
 *   | STX | MCUADDR | DataLen | Data0 | ... | DataN | CRC16 |
 *   |_____|_________|_________|_______|_____|_______|______|
 *   |     |         |         |       |     |       |      |
 *   |  AA |10/11/1F |   N+1   |       | ... |       |      |
 *   |_____|_________|_________|_______|_____|_______|______|
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 ***************************************************************************** */
void INTCOM1_GetRxData(void)
{
  uint16 u16Cnt;
  uint8 u8FrameCheckOk;
  WORD_VAL u16TempData;
  // DataFormat_U_U8BIT u8Tmp;
  static uint16 u16Uart1FailPri1Cnt = 0U;
  //  static uint16 u16Uart1FailPri2Cnt = 0U;
  static uint8 u8Intcom1StaClrCnt1 = 0U;
  static uint16 u16VinOkUartDly = 0U;
  //  static uint8  u8Intcom1StaClrCnt2 = 0U;

  u8FrameCheckOk = FALSE; /* In order to judge uart fail */
  if (u8Uart1RxNewFrame)/* A new frame received */
  {
    /* Check frame start */
    /* Check STX */
    if (UART_FRAME_STX != au8Uart1RxBuf[0])
    {
      uUart1Status.Bit.u8InvalidData = TRUE;
    }
      /* Check frame length */
    else if (u16Uart1RxDataNbr < UART_MIN_FRAME_LEN)
    {
      uUart1Status.Bit.u8LenErr = TRUE;
    }
      /* Check MCU address */
    else if (UART_ADDR_PRI_1 != au8Uart1RxBuf[1])
    {
      uUart1Status.Bit.u8McuAddrErr = TRUE;
    }
      /* Check length of data */
    else if ((u16Uart1RxDataNbr - UART_FRAME_AUX_LEN) != au8Uart1RxBuf[2])
    {
      uUart1Status.Bit.u8LenErr = TRUE;
      Nop();
      Nop();
    }
      /* Check frame crc8 */
    else
    {
      if (u16Uart1RxCrc)
      {
        uUart1Status.Bit.u8CrcErr = TRUE;
      }
      else
      {
        u8FrameCheckOk = TRUE;
      }
    }
    u16Uart1RxCrc = CRC_INIT_00;
    /* Data are handled, Begin to fill TX buffer */
    u8Uart1RxNewFrame = FALSE;
    /* Check frame end */
  }

  /* Judge Vin OK for UART */
  if ((FLG_B_INPUT_OK) && (FLG_B_BULK_OK))
  {
    if (500 < u16VinOkUartDly)
    {
      u16VinOkUartDly++;
    }
    else
    {
      INTCOM1_VIN_OK_FOR_UART = TRUE;
    }
  }
  else /* Vin and Bulk both are not OK */
  {
    INTCOM1_VIN_OK_FOR_UART = FALSE;
    u16VinOkUartDly = 0U;
  }

  /* Frame format is correct, Handle data */
  if(u8FrameCheckOk)
  {
    /* Handle RX from PRI1 */
    if (UART_ADDR_PRI_1 == au8Uart1RxBuf[1])
    {
      u16Uart1FailPri1Cnt = 0U;
      INTCOM1_PRI1_UART_FAIL = 0;
      INTCOM1_PRI1_NO_RX_PKG = 0;
      /* Clear UART1 status once on the first successful RX of PRI1*/
      if (!u8Intcom1StaClrCnt1)
      {
        uUart1Status.Byte = 0U;
        u8Intcom1StaClrCnt1 = 1U;
      }

      u16Cnt = 4;

      u64PmbusFwRevPri1.Bytes.u8MajorVersion = au8Uart1RxBuf[u16Cnt++]; 
      u64PmbusFwRevPri1.Bytes.u8MinorVersion = au8Uart1RxBuf[u16Cnt++]; 
      u64PmbusFwRevPri1.Bytes.u8BLMajorVersion = au8Uart1RxBuf[u16Cnt++]; 
      u64PmbusFwRevPri1.Bytes.u8BLMinorVersion = au8Uart1RxBuf[u16Cnt++]; 
      u64PmbusFwRevPri1.Bytes.u8APPMajorVersion = au8Uart1RxBuf[u16Cnt++]; 
      u64PmbusFwRevPri1.Bytes.u8APPMinorVersion = au8Uart1RxBuf[u16Cnt++]; 
      u64PmbusFwRevPri1.Bytes.u8APPBuildVersion = au8Uart1RxBuf[u16Cnt++];
      stIntcom1_PriA.u16PriStatus00.Bytes.LB = au8Uart1RxBuf[u16Cnt++]; 
      stIntcom1_PriA.u16PriStatus00.Bytes.HB = au8Uart1RxBuf[u16Cnt++];
      stIntcom1_PriA.u16PriStatus01.Bytes.LB = au8Uart1RxBuf[u16Cnt++]; 
      stIntcom1_PriA.u16PriStatus01.Bytes.HB = au8Uart1RxBuf[u16Cnt++];
      stIntcom1_PriA.u16PriDebug1.Bytes.LB = au8Uart1RxBuf[u16Cnt++]; 

      u16TempData.Bytes.LB = au8Uart1RxBuf[u16Cnt++]; 
      u16TempData.Bytes.HB = au8Uart1RxBuf[u16Cnt++];
      stIntcom1_PriA.u16q12VinAdc.u16Val = u16TempData.u16Val;
      
      u16TempData.Bytes.LB = au8Uart1RxBuf[u16Cnt++]; 
      u16TempData.Bytes.HB = au8Uart1RxBuf[u16Cnt++]; 
      stIntcom1_PriA.u16q12IinAdc.u16Val = u16TempData.u16Val;

      u16TempData.Bytes.LB = au8Uart1RxBuf[u16Cnt++]; 
      u16TempData.Bytes.HB = au8Uart1RxBuf[u16Cnt++]; 
      stIntcom1_PriA.u16q12PinAdc.u16Val = u16TempData.u16Val;

      u16TempData.Bytes.LB = au8Uart1RxBuf[u16Cnt++]; 
      u16TempData.Bytes.HB = au8Uart1RxBuf[u16Cnt++]; 
      stIntcom1_PriA.u16q12VbulkAdc.u16Val = u16TempData.u16Val;

      u16TempData.Bytes.LB = au8Uart1RxBuf[u16Cnt++]; 
      u16TempData.Bytes.HB = au8Uart1RxBuf[u16Cnt++]; 
      stIntcom1_PriA.u16q12PfcNtc.u16Val = (u16TempData.u16Val) << 2;

      u16TempData.Bytes.LB = au8Uart1RxBuf[u16Cnt++]; 
      u16TempData.Bytes.HB = au8Uart1RxBuf[u16Cnt++]; 

      stIntcom1_PriA.u16q12AmbExhaust.u16Val = (u16TempData.u16Val) << 2;

      if (u64PmbusFwRevPri1.u64Val != u64PmbusFwRevPri1Old.u64Val)
      {
        INTCOM1_PRI1_REV_UPDATE = 1;
        u64PmbusFwRevPri1Old.u64Val = u64PmbusFwRevPri1.u64Val;
      }
    }
  }
    /* Frame format is wrong or no data received, Handle UART1 fail */
  else
  {
    /* PRI1 */
    if (1U == UART1_mg_u8TxMcuFlg)
    {
      /* Handle UART1 fail of PRI1 */
      if (u16Uart1FailPri1Cnt > UART1_FAIL_CNT)
      {
        if (INTCOM1_VIN_OK_FOR_UART)
        {
          INTCOM1_PRI1_UART_FAIL = 1;
        }
        INTCOM1_PRI1_NO_RX_PKG = 1;
        if (INTCOM1_PRI1_UART_FAIL)
        {
          stIntcom1_PriA.u16PriStatus00.ALL = 0;
          stIntcom1_PriA.u16PriStatus01.ALL = 0;
        }
        else
        {
          stIntcom1_PriA.u16PriStatus00.ALL = 0x0010;
          stIntcom1_PriA.u16PriStatus01.ALL = 0x0034;
        }
        stIntcom1_PriA.u16PriDebug1.u16Val = 0;
        stIntcom1_PriA.u16PriDebug2.u16Val = 0;
        stIntcom1_PriA.u16q12VinAdc.u16Val = 0;
        stIntcom1_PriA.u16q12IinAdc.u16Val = 0;
        stIntcom1_PriA.u16q12PinAdc.u16Val = 0;
        stIntcom1_PriA.u16q12VbulkAdc.u16Val = 0;
        stIntcom1_PriA.u16q12PfcNtc.u16Val = 0; 
        stIntcom1_PriA.u16q12AmbExhaust.u16Val = 0; 
        u8LineStatus = 0b001; /* No AC input 0x00 */
      }
      else
      {
        u16Uart1FailPri1Cnt++;
      }
    }
  }
}

/*
 * End of file
 */

