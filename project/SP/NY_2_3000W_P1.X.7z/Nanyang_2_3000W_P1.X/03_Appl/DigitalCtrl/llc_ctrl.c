/*******************************************************************************
 * \file    llccontrol.c
 * \brief   
 *
 * \section AUTHOR
 *    1. CIPS
 *
 * \section SVN
 *  $Date$
 *  $Author$
 *  $Revision$
 *
 * \section LICENSE
 * Copyright (c) Lite-ON Singapore Pte Ltd
 * All rights reserved.
 *******************************************************************************/

/*******************************************************************************
 * Included header
 ******************************************************************************/
#include "DataFormat.h"
#include <p33EP64GS504.h>
#include <xc.h>
#include "McuPwm.h"
#include "McuAdc.h"
#include "McuGPIO.h"
#include "Rtv.h"
#include "llc_ctrl.h"
#include "Protection.h"
#include "Timer_ISR.h"
#include "PsuState.h"
/*******************************************************************************
 * Local constants and macros (private to module)
 ******************************************************************************/
#define MG_PSKILL_ENABLE_SET_CLEAR_TIME  2
#define LLC_MG_REF_2V5_CALI       Q12(2.5/3.3)
#define LLC_MG_V1_DROP_VAL        Q12(1.20 / Max_V1Out_LOOP)
#define LLC_MG_FULL_LOAD          Q12(60.0 / U16Q12_I1_MAX)
#define LLC_MG_DROP_RATE          Q12(LLC_MG_V1_DROP_VAL * 128 / LLC_MG_FULL_LOAD)
#define MG_MIN_PHASE_SHIFT        10
#define MG_FAST_OV_POINT          Q12(54.0F / U16Q12_V1_MAX_INT)
#define CCL_THR_SWITCH_DELAY      4000 //60ms/15us
/*******************************************************************************
 * Local data types (private typedefs / structs / enums)
 ******************************************************************************/

/*******************************************************************************
 * Local data (private to module)
 ******************************************************************************/
static sint16 s16LLC_PWM_Period;
static sint16 s16LLC_PWM_Duty_LLC;
static sint16 s16LLC_PWM_Duty_SR;
static sint16 llc_mg_s16ishare_compen;
static sint16 V1_ext;
static sint16 s16VrefIshareCompen;
static sint16 llc_mg_s16VSenseCompen;
/*******************************************************************************
 * DataFormat data (private to module)
 ******************************************************************************/
uint8 u8CTOCPWMOffCnt;
sint16 Vref;

/*******************************************************************************
 * DataFormat functions (public to other modules)
 ******************************************************************************/

/*******************************************************************************
 * Function:        InitCtrlLoop
 *
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     Initialize the control loop data
 *
 ******************************************************************************/
void InitCtrlLoop(void)
{
  PSU_s16VrefControl = V1_REF_SET_DEFAULT;
  u8CTOCPWMOffCnt = 0;
}

/*******************************************************************************
 * Function:        ADCAN2Interrupt
 *
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     Handle control loop in the AN2 interrupt routine, 15us
 * Comment:         Voltage loop operation time 5uS~8uS
 ******************************************************************************/
void __attribute__((__interrupt__, no_auto_psv)) _ADCAN2Interrupt()
{
  static sint16 e0_v = 0;
  static sint16 e1_v = 0;
  static sint16 e2_v = 0;
  static sint16 e3_v = 0;
  static sint16 e4_v = 0;

  static sint32 u0_v = 0;
  static sint16 u1_v = 0;
  static sint16 u2_v = 0;
  static sint16 u3_v = 0;

  static sint16 a0_v;
  static sint16 a1_v;
  static sint16 a2_v;
  static sint16 a3_v;
  static sint16 a4_v;

  static sint16 b1_v;
  static sint16 b2_v;
  static sint16 b3_v;

  static uint16 u16PwmStartoff = 0;
  static uint16 u16PwmStartoffDly = 0;
  static sint16 Vref_adj_cc = 0;
  static sint32 Vref_temp = 0;
  static uint16 llc_mg_loop_number = 0;
  static uint16 llc_mg_loop_change_dly0 = 0;
  static uint16 llc_mg_loop_change_dly1 = 0;
  static uint32 llc_mg_u32BurstOutDly = 0;
  static uint16 llc_mg_u16BurstDly = 0;
  static sint16 LLC_mg_u16PWMCtrlEnd = 0;
  static uint16 llc_mg_u16PWMCurrComp = 0;
  static uint16 u16LightLoadDutyComp = 0;
  static uint16 LLC_mg_u16dropVol = 0;
  static uint16 llc_mg_u16PSOff = 0;
  static uint16 llc_mg_u16FreqChangeRamp = 0;
  static uint16 llc_mg_u16SRDeadTime = 0;
  static uint16 llc_mg_u16DynamicFlag = 0;
  static uint16 llc_mg_u16DynamicFlagClrDly = 0;
  static uint16 llc_mg_u16SoftStartEndCnt = 0;
  static uint16 u16LLC_PWM_NORMAL_dly = 0;
  static uint8 u8OvpCnt = 0;
  uint16 mg_u16V1_Ss_Factor;

  V1_ext = ADC_V1_VOLT_VEA;
  stAdcBufResult.u16AdcBufV1VoltVEA = V1_ext;
  stAdcBufResult.u16AdcBufV1VoltExt = ADC_V1_VOLT_EXT;
  stAdcBufResult.u16AdcBufV1Curr = ADC_I1_CURR;
  stAdcBufResult.u16AdcBufNtcSr = ADC_NTC_SR;
  stAdcBufResult.u16AdcBufV1IShareVolt = ADC_I1_VOLT_SHARE;
  stAdcBufResult.u16AdcBufV1ILocalVolt = ADC_I1_VOLT_LOCAL;
  stAdcBufResult.u16AdcBufRef2V5 = ADC_REF_2V5;
  
  /**********************************/

  //Fast OVP detect
  if (stAdcBufResult.u16AdcBufV1VoltVEA > MG_FAST_OV_POINT)
  {
    if (u8OvpCnt < 1) //15uS * (1+1) = 30uS
    {
      u8OvpCnt++;
    }
    else
    {
      FLG_B_V1_FW_FAST_OVP = TRUE;
    }
  }
  else
  {
    u8OvpCnt = 0;
  }
  
  //detect PSON signal 
    DEBOUNCE_SET_CLR_2(FLG_B_PSON_ENABLE,
                 PORT_IN_PSON_IS_ACTIVE,
                 PORT_IN_PSON_IS_INACTIVE,
                 200,
                 4);

  if (FLG_B_V1_STATE == ON)
  {
      DIO_PFC_OFF = 1;
    if (u8CTOCPWMOffCnt > 0)
      u8CTOCPWMOffCnt--;

    if (FLG_B_V1_SOFT_START) 
    {
      if (Vref <  PSU_s16VrefControl) 
      { 
        mg_u16V1_Ss_Factor = V1_SS_FACTOR_ML + (__builtin_muluu((Q12(1.0) - stAdcBufResult.u16AdcBufV1Curr), V1_SS_FACTOR_K) >> 12);

        Vref_temp += mg_u16V1_Ss_Factor;
        Vref = (uint16) (Vref_temp >> N_SS);

        if (1 == llc_mg_u16PSOff)
        {
          if (V1_ext > Vref)
          {
            Vref_temp = ((uint32) V1_ext) << N_SS;
            Vref_temp += V1_SS_FACTOR_ZL;
          }
        }


        if (Vref > PSU_s16VrefControl)
        {
          Vref = PSU_s16VrefControl;
        }
      }
      else
      {
        PORT_OUT_V1_ISHARE_EN;
        Vref = PSU_s16VrefControl;
        Vref_temp = 0;
        FLG_B_V1_SOFT_START = 0;
      }


      a0_v = Q12(1.0);
      a1_v = Q12(-0.85);
      a2_v = Q12(0);
      a3_v = Q12(0);
      a4_v = Q12(0);

      b1_v = Q12(1.0);
      b2_v = Q12(0);
      b3_v = Q12(0);
      

      FLG_B_V1_INIT_LOOP = 0;
      llc_mg_loop_change_dly0 = 0;
      llc_mg_loop_change_dly1 = 0;
    }
    else
    {
      if (FLG_B_V1_CCL == 0)
      {
        Vref = PSU_s16VrefControl;
      }

      /*******************************************************************************
       * Initial loop data
       ******************************************************************************/
      if (!FLG_B_V1_INIT_LOOP)
      {
        FLG_B_V1_INIT_LOOP = 1;
        llc_mg_u16SRDeadTime = 0;

        if (stAdcBufResult.u16AdcBufV1Curr > Q12(24.0 / U16Q12_I1_MAX))
        {
            a0_v = Q12(0.9664406);
            a1_v = Q12(-0.7759293);
            a2_v = Q12(-0.9570519);
            a3_v = Q12(0.785318);
            a4_v = Q12(0);

          b1_v = Q12(1.5790911);
          b2_v = Q12(-0.1818016);
          b3_v = Q12(-0.3972895);
          llc_mg_loop_number = 0;
        }
        else 
        {
          a0_v = Q12(1.5205425);
          a1_v = Q12(-1.2468256);
          a2_v = Q12(-1.5082244);
          a3_v = Q12(1.2591437);
          a4_v = Q12(0);

          b1_v = Q12(1.5753913);
          b2_v = Q12(-0.1795969);
          b3_v = Q12(-0.3957944);

          llc_mg_loop_number = 1;
        }
        e3_v = 0;
        e2_v = 0;
        e1_v = 0;
        e0_v = 0;

        u0_v = s16LLC_PWM_Period;
        u1_v = u0_v;
        u2_v = u1_v;
        u3_v = u2_v;
      }
      /*******************************************************************************
       * Control Loop parameters changes
       ******************************************************************************/
      if (llc_mg_u16FreqChangeRamp < 786)
      {
        llc_mg_u16FreqChangeRamp = llc_mg_u16FreqChangeRamp + 10;
      }
      else
      {

      }
      if (llc_mg_u16SoftStartEndCnt < 6000)
      {
        llc_mg_u16SoftStartEndCnt++;
      }
      /*******************************************************************************
       * Control Loop parameters changes
       ******************************************************************************/
      if (stAdcBufResult.u16AdcBufV1Curr > Q12(24.0 / U16Q12_I1_MAX))        //40%
      {
        if (0 != llc_mg_loop_number)
        {
          if (llc_mg_loop_change_dly0 < 50)
          {
            llc_mg_loop_change_dly0++;
          }
          else
          {
            a0_v = Q12(0.9664406);
            a1_v = Q12(-0.7759293);
            a2_v = Q12(-0.9570519);
            a3_v = Q12(0.785318);
          a4_v = Q12(0);

          b1_v = Q12(1.5790911);
          b2_v = Q12(-0.1818016);
          b3_v = Q12(-0.3972895);
            llc_mg_loop_change_dly0 = 0;
            llc_mg_loop_number = 0;
          }
        }
        if (llc_mg_loop_change_dly1 > 0)
        {
          llc_mg_loop_change_dly1--;
        }
      }
      else if (stAdcBufResult.u16AdcBufV1Curr < Q12(19.2 / U16Q12_I1_MAX))       //32%
      {
        if (1 != llc_mg_loop_number)
        {
          if (llc_mg_loop_change_dly1 < 50)
          {
            llc_mg_loop_change_dly1++;
          }
          else
          {
            a0_v = Q12(1.5205425);
            a1_v = Q12(-1.2468256);
            a2_v = Q12(-1.5082244);
            a3_v = Q12(1.2591437);
            a4_v = Q12(0);

            b1_v = Q12(1.5753913);
            b2_v = Q12(-0.1795969);
            b3_v = Q12(-0.3957944);

            llc_mg_loop_change_dly1 = 0;
            llc_mg_loop_number = 1;
          }
        }
        if (llc_mg_loop_change_dly0 > 0)
        {
          llc_mg_loop_change_dly0--;
        }
      }
    } /* Control Loop parameters changes end */

    LLC_mg_u16dropVol = (__builtin_mulss(stAdcBufResult.u16AdcBufV1Curr, LLC_MG_DROP_RATE) >> 12);

    V1_ext = ADFL0DAT;
    e0_v = Vref - V1_ext + llc_mg_s16VSenseCompen + s16VrefIshareCompen - (LLC_mg_u16dropVol >> 7);
    e4_v = (e0_v + e1_v) >> 1;

    if (e0_v > MAXERROR)
    {
      e0_v = MAXERROR;
    }
    else if (e0_v < MINERROR)
    {
      e0_v = MINERROR;
    }

    u0_v = __builtin_mulss(a0_v, e0_v) + __builtin_mulss(a1_v, e1_v) + __builtin_mulss(a2_v, e2_v) + __builtin_mulss(a3_v, e3_v) + 
            __builtin_mulss(b1_v, u1_v) + __builtin_mulss(b2_v, u2_v) + __builtin_mulss(b3_v, u3_v);

    if (u0_v < ((sint32) 0))
    {
      u0_v = 0;
    }

    u0_v = (unsigned int) (u0_v >> 12);

    if (1 == FLG_B_V1_SOFT_START)
    {
      if (u0_v > MAX_u0_V_SS)
      {
        u0_v = MAX_u0_V_SS;
      }      
      else if (u0_v < MIN_u0_V_SS)
      {//270khz
        u0_v = MIN_u0_V_SS;
      }

      if (1 == llc_mg_u16PSOff)
      {
        if (u0_v < (unsigned int) (PWMCLOCKFREQ / 220E3 / 2))
        {
          u0_v = (unsigned int) (PWMCLOCKFREQ / 220E3 / 2);
        }
      } 
    }
    else if (0 == FLG_B_V1_CCL)
    {
      if (u0_v > MAX_u0_V) //minimum frequent limitation
      {
        u0_v = MAX_u0_V;
      }
      else if (u0_v < (MG_MIN_NOR_SAFE_PERI))//270khz
      {
        u0_v = MG_MIN_NOR_SAFE_PERI;
      }
    }
    else
    {
      if (u0_v > MAX_u0_V)//minimum frequent limitation 95khz
      {
        u0_v = MAX_u0_V;
      }
      else if (u0_v < MG_MIN_NOR_SAFE_PERI) //200khz
      {//MAX_PERIOD_SAFE
        u0_v = MG_MIN_NOR_SAFE_PERI;
      }
    }

    if (FLG_B_LLC_V1_FW_OVP)
    {
      FLG_B_V1_FAULT_LATCH = 1;
      s16LLC_PWM_Period = MIN_PERIOD;
      s16LLC_PWM_Duty_LLC = 0;
      s16LLC_PWM_Duty_SR = 0;
    }
    else
    {
      if (FLG_B_V1_CT)
      {
        s16LLC_PWM_Period = CT_PEAK_PERIOD;
        s16LLC_PWM_Duty_LLC = s16LLC_PWM_Period - LLC_HB_BURST_DEADTIME;
        s16LLC_PWM_Duty_SR = s16LLC_PWM_Duty_LLC;
        FLG_B_V1_CCL = 1;

        u0_v = CT_PEAK_PERIOD;
        u1_v = u0_v;
        u2_v = u1_v;
        u3_v = u2_v;

        e3_v = 0;
        e2_v = 0;
        e1_v = 0;
        e0_v = 0;
      }
      else
      {
        if ((FLG_B_V1_SOFT_START) || (!FLG_B_V1_BURST_MODE))
        {
          s16LLC_PWM_Period = (uint16) u0_v;

          if (((s16LLC_PWM_Period < MG_MIN_NOR_OPER_PERI) &&
              ((stAdcBufResult.u16AdcBufV1Curr < Q12(6.5 / U16Q12_I1_MAX)) || (e0_v < Q12(-45.5 / Max_V1Out_LOOP)))) && //
              !FLG_B_V1_SOFT_START &&
              !FLG_B_V1_CCL)
          {
            FLG_B_V1_BURST_MODE = 0;
          }

          /***** SR stress solution --- for low load add primary turn off dead time
           for high load add SR turn on dead time  *****/
          if (0 == FLG_B_V1_SOFT_START)
          {
            s16LLC_PWM_Duty_LLC = s16LLC_PWM_Period - LLC_HB_DEADTIME;
          }
          else
          {
            s16LLC_PWM_Duty_LLC = s16LLC_PWM_Period - LLC_HB_START_DEADTIME;
          }
        }
      }
    }


    if ((s16LLC_PWM_Period < (MG_MIN_NOR_OPER_PERI))
        && (0 == FLG_B_V1_SOFT_START) && (e0_v < Q12(-1.0 / Max_V1Out_LOOP))
        )
    {
      s16LLC_PWM_Duty_LLC = 0;
      s16LLC_PWM_Duty_SR = 0;
      u0_v = (unsigned long) BURST_PERIOD;
      u1_v = u0_v;
      u2_v = u1_v;
      u3_v = u2_v;
      e3_v = 0;
      e2_v = 0;
      e1_v = 0;
      e0_v = 0;
    }
    PWM_SPECIAL_EVENT_REG = 1; /* Enable Special Event Interrupt to update PWM */

    u3_v = u2_v;
    u2_v = u1_v;
    u1_v = u0_v;

    e3_v = e2_v;
    e2_v = e1_v;
    e1_v = e0_v;
  }
  else
  { 
      DIO_PFC_OFF = 0;
    llc_mg_loop_change_dly0 = 0;
    llc_mg_loop_change_dly1 = 0;
    FLG_B_V1_CCL = 0;
    u8CTOCPWMOffCnt = 0;
    FLG_B_V1_CT = 0;
    Vref = 0;
    Vref_temp = ((uint32) V1_ext) << N_SS;
    PORT_OUT_V1_ISHARE_DIS;
    Vref_adj_cc = 0;
    FLG_B_V1_SOFT_START = 1;
    llc_mg_u32BurstOutDly = 0;
    FLG_B_V1_BURST_MODE = 0;
    llc_mg_u16BurstDly = 0;
    llc_mg_s16ishare_compen = 0;
    llc_mg_loop_number = 0;
    u16PwmStartoff = 0;
    u16PwmStartoffDly = 0;
    u16LightLoadDutyComp = 0;
    llc_mg_u16SRDeadTime = 0;
    llc_mg_u16DynamicFlag = 0;
    llc_mg_u16DynamicFlagClrDly = 0;

#if PHASESHIFT_ENABLE    
    u3_v = MIN_u0_V;
    u2_v = MIN_u0_V;
    u1_v = MIN_u0_V;
    u0_v = MIN_u0_V;
    llc_mg_u16PSOff = 0;
#else
    u3_v = 0;
    u2_v = 0;
    u1_v = 0;
    u0_v = 0;
#endif    
    e3_v = 0;
    e2_v = 0;
    e1_v = 0;
    e0_v = LLC_HB_BURST_DEADTIME;
    DTR3 = MG_MIN_PHASE_SHIFT;
    ALTDTR3 = MG_MIN_PHASE_SHIFT;
    u8CTOCCnt = 0;
    u16LLC_PWM_NORMAL_dly = 0;
    s16LLC_PWM_Duty_LLC = 0;
    s16LLC_PWM_Duty_SR = 0;
    LLC_mg_u16PWMCtrlEnd = 0;
    llc_mg_u16PWMCurrComp = 0;
    llc_mg_u16FreqChangeRamp = 0;
    llc_mg_u16SoftStartEndCnt = 0;
#if PHASESHIFT_ENABLE
    s16LLC_PWM_PhaseShift = MG_SHIFT_MAX;
    s16LLC_PWM_Period = MIN_PERIOD;
    u16LLCDummy = ADC_V1_VOLT_VEA;
    u16LLCDummy = u16LLCDummy * 9;
    u16LLCDummy = u16LLCDummy >> 5;
    if ((u16LLCDummy >= MG_SHIFT_MAX) || (V1_ext > Q12(9.2 / Max_V1Out_LOOP)))
    {
      s16LLC_PWM_PhaseShift = MG_MIN_PHASE_SHIFT;
      s16LLC_PWM_PhaseShiftMax = MG_MIN_PHASE_SHIFT;
    }
    else
    {
      u16LLCDummy = MG_SHIFT_MAX - u16LLCDummy;
      s16LLC_PWM_PhaseShift = u16LLCDummy;
      s16LLC_PWM_PhaseShiftMax = s16LLC_PWM_PhaseShift;
      if (s16LLC_PWM_PhaseShift < MG_MIN_PHASE_SHIFT)
      {
        s16LLC_PWM_PhaseShift = MG_MIN_PHASE_SHIFT;
      }
    }
    s16LLC_PWM_PhaseShiftMax = s16LLC_PWM_PhaseShift;
#endif
    PWM_SPECIAL_EVENT_REG = 1;
  }
  _ADCAN2IF = 0;
  return;
}

/*******************************************************************************
 * Function:        PWMSpEventMatchInterrupt
 *
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     PWM event match interrupt routine
 *
 ******************************************************************************/
void __attribute__((__interrupt__, no_auto_psv)) _PWMSpEventMatchInterrupt(void)
{
  if (!u8CTOCPWMOffCnt)
  {
    if (((PWM_V1_FB_ENABLE_H_REG == 0) || (PWM_V1_FB_ENABLE_L_REG == 0)) && FLG_B_V1_STATE)
    {
      PWM_V1_FB_ENABLE_H_REG = 1;
      PWM_V1_FB_ENABLE_L_REG = 1;
      PWM_SR_M12_ENABLE_H_REG = 1;
      PWM_SR_M12_ENABLE_L_REG = 1;
    }
  }
  else
  {
    PWM_V1_FB_ENABLE_H_REG = 0;
    PWM_V1_FB_ENABLE_L_REG = 0;
    PWM_SR_M12_ENABLE_H_REG = 0;
    PWM_SR_M12_ENABLE_L_REG = 0;
  }

  PWM_LLC_PERIOD_REG = s16LLC_PWM_Period;
  PWM_LLC_FB_DUTY_REG = s16LLC_PWM_Duty_LLC;

  PWM_SPECIAL_EVENT_REG = 0; // Special Event Interrupt is disabled
  PWM_INTERR_FLAG_REG = 0;
}

/*******************************************************************************
 * Function:        _CMP2Interrupt
 *
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     V1 OCP interrupt - CMP2
 *
 ******************************************************************************/

void __attribute__((__interrupt__, no_auto_psv)) _CMP2Interrupt()
{
    FLG_V1_FAULT_CONDITION = 1;
    PSU_mg_V1PwrOff();
    FLG_B_LLC_V1_OCP = TRUE;

  _AC2IF = 0;
  return;
}
