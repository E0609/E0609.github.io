/* 
 * File:   Protection.h
 * Author: CIPS
 *
 * Created on 7 October, 2020, 4:34 PM
 */

#ifndef PROTECTION_H
#define	PROTECTION_H

#ifdef	__cplusplus
extern "C" {
#endif

    /*******************************************************************************
     * Local constants and macros
     ******************************************************************************/

    /*******************************************************************************
     * DataFormat data types (typedefs / structs / enums)
     ******************************************************************************/
    /***********************************************
     * Output
     **********************************************/
    /* Flags */
    /* V1 Fault */
#define FLG_B_LLC_V1_FW_OVP             stV1FaultFlag00.Bits.f0  /* 1 = V1 OVP */    
#define FLG_B_LLC_V1_OCP                stV1FaultFlag00.Bits.f1  /* 1 = V1 OCP */
#define FLG_B_LLC_V1_OCW                stV1FaultFlag00.Bits.f2  /* 1 = V1 OCW */
#define FLG_B_LLC_V1_FW_OVW             stV1FaultFlag00.Bits.f3  /* 1 = V1 OVW */
#define FLG_B_V1_SCP_TEMP               stV1FaultFlag00.Bits.f4  /* 1 = V1 SCP temp flag */
#define FLG_B_V1_FW_FAST_OVP            stV1FaultFlag00.Bits.f5  /* 1 = V1 fast OVP */



#define FLG_B_V1_FAULT_LATCH            stLatchFaultFlag00.Bits.f0 /* 1 = V1 fault latch   */

#define FLG_B_INPUT_OK                  stSysStateFlag00.Bits.f0  /* 1 = INPUT OK */
#define FLG_B_BULK_OK                   stSysStateFlag00.Bits.f1  /* 1 = BULK OK */
#define FLG_B_PSON_ENABLE               stSysStateFlag00.Bits.f2  /* 1 = SYSTEM PSON ENABLE */
#define FLG_V1_FAULT_CONDITION          stSysStateFlag00.Bits.f3  /* 1 = V1 fault state */
#define FLG_V1_PRISYS_CONDITION         stSysStateFlag00.Bits.f4  /* 1 = V1 pri sys turn onoff state */


#define FLG_B_V1_STATE                  stVoutStateFlag.Bits.f0  /* 1 = V1 ON */
#define FLG_B_V1_CCL                    stVoutStateFlag.Bits.f1  /* 1 = V1 CURRENT LIMIT */
#define FLG_B_V1_CT                     stVoutStateFlag.Bits.f2  /* 1 = V1 CT */
#define FLG_B_V1_SOFT_START             stVoutStateFlag.Bits.f3  /* 1 = V1 soft start status */
#define FLG_B_V1_INIT_LOOP              stVoutStateFlag.Bits.f4  /* 1 = V1 initial loop */
#define FLG_B_V1_BURST_MODE             stVoutStateFlag.Bits.f5  /* 1 = V1 burst mode */
#define FLG_B_V1_PWOK_GOOD              stVoutStateFlag.Bits.f6  /* 1 = V1 is OK */

    /*******************************************************************************
     * DataFormat data
     ******************************************************************************/
    extern volatile DataFormat_U_U16BIT stV1FaultFlag00, stLatchFaultFlag00;  
    extern volatile DataFormat_U_U16BIT stVoutStateFlag, stSysStateFlag00, stSysStateFlag01;
    extern uint16 u16StartMonV1UvpCnt;
    
    /*******************************************************************************
     * DataFormat function prototypes
     ******************************************************************************/
    extern void PROTECT_V1OcPointset(void);
    extern void PROTECT_DataInit(void);
    extern void PROTECT_V1Curr(void);
    extern void PROTECT_V1Volt(void);

    /********************************************************************************/



#ifdef	__cplusplus
}
#endif

#endif	/* MONITORCTRL_H */

