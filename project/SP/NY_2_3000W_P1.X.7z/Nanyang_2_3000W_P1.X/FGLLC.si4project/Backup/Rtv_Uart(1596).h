/* 
 * File:   Rtv_Uart.h
 * Author: CIPS
 *
 * Created on 6 October, 2020, 9:42 AM
 */

#ifndef RTV_UART_H
#define	RTV_UART_H

#ifdef	__cplusplus
extern "C" {
#endif
    /*******************************************************************************
     * Included header
     ******************************************************************************/

    /*******************************************************************************
     * Global constants and macros (public to other modules)
     ******************************************************************************/

    /***********************************************
     * Output
     **********************************************/
#define au8Uart1TxBuf           au8Uart1TxBuf
#define u16Uart1TxDataNbr       u16Uart1TxDataNbr
#define u8Uart1TxBufUpdated     u8Uart1TxBufUpdated
#define uUart1Status            uUart1Status
#define u8Uart1LocalMcuFlg      u8Uart1LocalMcuFlg
#define u8Uart1LocalMcuAddr     u8Uart1LocalMcuAddr
#define u8LineStatus            u8LineStatus
    
    /***********************************************
     * Input
     **********************************************/
#define au8Uart1RxBuf           au8Uart1RxBuf
#define u16Uart1RxDataNbr       u16Uart1RxDataNbr
#define u8Uart1RxNewFrame       u8Uart1RxNewFrame
#define u8Uart1FrameTmoutFlg    u8Uart1FrameTmoutFlg
#define u8Uart1ByteTmoutFlg     u8Uart1ByteTmoutFlg
#define u16Uart1RxCrc           u16Uart1RxCrc

    /*******************************************************************************
     * Global data types (typedefs / structs / enums)
     ******************************************************************************/


    /*******************************************************************************
     * Global data (public to other modules)
     ******************************************************************************/

    /*******************************************************************************
     * Global function prototypes (public to other modules)
     ******************************************************************************/

#ifdef	__cplusplus
}
#endif

#endif	/* RTV_UART_H */

