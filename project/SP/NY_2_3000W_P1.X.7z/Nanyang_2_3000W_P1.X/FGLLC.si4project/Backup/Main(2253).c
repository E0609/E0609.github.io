/*
 * File:   Main.c
 * Author: CIPS
 *
 * Created on 28 September, 2020, 1:42 PM
 */


#include "xc.h"
#include <p33EP128GS708.h>

#include "Main.h"
#include "McuClock.h"
#include "McuGPIO.h"
#include "McuAdc.h"
#include "McuTimer.h"
#include "McuPwm.h"
#include "McuUart1.h"

#include "Rtv.h"
#include "Dig_InOut.h"
#include "Timer_ISR.h"
#include "llc_ctrl.h"
#include "PsuState.h"
#include "Rtv_Uart.h"
#include "Protection.h"
#include "UartComm.h"


/*  ------------------------------------------------------------------------------
  Module               : Mcu_RemapPinInit.c
  Function             :
  Modification history :
  ------------------------------------------------------------------------------
  Description          : Main function
  ------------------------------------------------------------------------------
  Input                : -
  Output               : -
  Modified Variables   : -
  Calling              : -
------------------------------------------------------------------------------*/
void Mcu_RemapPinInit(void)
{
  __builtin_write_OSCCONL(OSCCON & 0xbf); /* Unlock register for remap pin configuration */

  /* UART pin remap */
#if 0
  RPINR18bits.U2RXR = 36; /* Assign U2Rx to pin RP36/RB4 */ 
  RPOR16bits.RP62R = 3;   /* Assign U2Tx to pin RP62/RC14 */ 
#else
  RPINR18bits.U1RXR = 40; /* Assign U1Rx to pin RP40/RB8 */ 
  RPOR9bits.RP47R = 1;    /* Assign U1Tx to pin RP47/RB15 */
#endif

  __builtin_write_OSCCONL(OSCCON | 0x40); /* Lock register */
}

/*  ------------------------------------------------------------------------------
  Module               : Main.c
  Function             :
  Modification history : 
  ------------------------------------------------------------------------------
  Description          : Main function
  ------------------------------------------------------------------------------
  Input                : -
  Output               : -
  Modified Variables   : -
  Calling              : -
------------------------------------------------------------------------------*/

int main(void) {
    
  /* System configuration */
  Mcu_SysClkHwInit();
  PROTECT_DataInit();
  Mcu_RemapPinInit();
  
  /* uC peripheral configuration */
  Mcu_GPIOHwInit();
  Mcu_ADCHwInit();
  Mcu_TMRHwInit();
  Mcu_PwmHwInit();
  Mcu_Uart1HwInit();
  Mcu_CMPHwInit();
  
  
  /* Bsw data initialization */
  RTV_vDataInit();
  TIMER_SchDataInit();
  UART1_DataInit();
  INTCOM1_ComDataInit();

  /* Appl data initialization */
  PSUstate_DataInit();
  InitCtrlLoop();

  while (1)
  {
    INTCOM1_GetTxData();
  } /* while (1) */
}
