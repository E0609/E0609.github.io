
#ifndef __INIT_H__
#define __INIT_H__

#define DITHER_ENABLED	0

// Example:
// 10^9 ns /125k = 8000ns per PWM cycle 
// 8000 ns / 2.08 ns = 3846 counts (PWM Period)
#define UCC28950_SYNC_FREQ	100000
#define GET_PERIOD(FREQ)	((LONG)1000000000/FREQ)*100/208
#define PWM_PERIOD	GET_PERIOD(UCC28950_SYNC_FREQ)

#if DITHER_ENABLED
#define UCC28950_SYNC_FREQ_LOW		116000
#define UCC28950_SYNC_FREQ_HIGH		130000
#define PWM_PERIOD_LOW		GET_PERIOD(UCC28950_SYNC_FREQ_LOW)
#define PWM_PERIOD_HIGH		GET_PERIOD(UCC28950_SYNC_FREQ_HIGH)
#define DIFF_PERIOD_TOTAL	(GET_PERIOD(UCC28950_SYNC_FREQ_LOW) - GET_PERIOD(UCC28950_SYNC_FREQ_HIGH))
//#define DIFF_COUNT	(DIFF_PERIOD_TOTAL / 50)	// 20us * 50 = 1ms
#define DIFF_COUNT	(DIFF_PERIOD_TOTAL / 14)	// 20us * 14 = 240us

#endif



#define DUTY_12V2_REF	                 24894	// 12.2V

#if defined(Config_12V35_REF)                          
    //#define DUTY_12V3_REF	            25098	// 12.3V => (12.3/12.5)*25506 = 25098, 
    #define DUTY_12V35_REF	            25200	// 12.3V => (12.35/12.5)*25506 = 25200, 
#elif defined(Config_12V25_REF)
    #define DUTY_12V25_REF	            24996	// 12.25V => (12.25/12.5)*25506 = 24996,
#elif defined(Config_12V5_REF)
    #define DUTY_12V5_REF	            25506	// 12.5V   // how to get this? cips 0~3.3 0~1023,0b11 11111111;3.3x4=13.2
#endif

#define DUTY_12V_STEP_DOWN_REF      24282	    // 11.9V         
#define SOFTSTART_SLOPE_ADJUSTMENT	9 //6      
#define MG_PIN_ANALOG             1         //Microchip Pin Analog Select
#define MG_PIN_DIGITAL            0
#define MG_PIN_OUTPUT_HIGH        1
#define MG_PIN_OUTPUT_LOW         0


#define MG_PIN_INPUT_DIRECTION    1         //Microchip Pin Input Direction
#define MG_PIN_OUTPUT_DIRECTION   0


// for AW600
#define ADC_12V_ORING    ADCBUF0    
#define ADC_I_OUT        ADCBUF1    
#define ADC_12V_OUT      ADCBUF2    
#define ADC_ISHARE_IN    ADCBUF3 
#define ADC_STB_5V_OUT   ADCBUF4    
#define ADC_STB_I_OUT    ADCBUF5 
#define ADC_CS_OUT_READ  ADCBUF6 
#define ADC_T_SR_MCU     ADCBUF7

#define PWM_FAN_duty    PDC1
#define PWM_FAN_Period   PHASE1 

#define PWM_12V_FB_duty    PDC2
#define PWM_12V_FB_Period   PHASE2 

/////microchip
#define PWM_PIN_IO 0
#define PWM_PIN_PWM 1
#define MODE_PUSHPULL 2
#define DEADTIME_DISABLE 2
#define IUE_ENABLE 1
#define IUE_DISABLE 0
#define EIPU_ENABLE 1
#define EIPU_DISABLE 0
#define PRIMARY_TIMEBASE 0
#define SWAP_ENABLE 1
#define PWM_MODULE_ENABLE 1
#define PWM_MODULE_DISABLE 0
#define PWM_PIN_OVERDAT_LOW 0
#define PWM_PIN_OVERDAT_HIGH 1
#define PWM_FAULTMODE_LATCH 0
#define PWM_FAULTMODE_CYCLE 1
#define PWM_FAULTMODE_DISABLE 2
#define PWM_FAULTSOURCE_HIGH 0
#define PWM_FAULTSOURCE_LOW 1

#define PWM_FAULTSOURCE_ACMP1 0b01101
#define PWM_FAULTSOURCE_NONE 0

#define TRIGSTART_DELAY_1PWM 1
#define TRIGOUTPUT_EVENT_2 1

#define SEVT_EVERY_COMPARE_MATCH 0
#define SEVT_1SKIP_COMPARE_MATCH 1

#define INTERRUPT_ENABLE 1
#define INTERRUPT_DISABLE 0
#define INTERRUPT_PRIORITY_3 3
#define INTERRUPT_PRIORITY_4 4
#define INTERRUPT_PRIORITY_5 5
#define INTERRUPT_PRIORITY_6 6
#define INTERRUPT_PRIORITY_7 7
#define INTERRUPT_FLAG_CLEAR 0
#define INTERRUPT_FLAG_SET 1

#define TIMER_RESET 0
#define TIMER_IDLEMODE_DISABLE 0
#define TIMER_MODULE_ENABLE 1
#define TIMER_MODULE_DISABLE 0
#define TIMER_PRESCALER_1BY1 0
#define TIMER_PRESCALER_1BY8 1
#define TIMER_PRESCALER_1BY64 2
#define TIMER_PRESCALER_1BY256 3
#define TIMER_GATEDTIME_DISABLE 0
#define TIMER_GATEDTIME_ENABLE 1
#define TIMER_INTERNAL_CLOCK 0
#define TIMER_EXTERNAL_CLOCK 1

#define IO_PIN_OUTPUT 0
#define IO_PIN_INPUT 1


#define ADC_MODULE_ENABLE 1
#define ADC_MODULE_DISABLE 0
#define ADC_TRIGGERSOURCE_PWM1 5
#define ADC_TRIGGERSOURCE_PWM2 6
#define ADC_INTGER_FORM 0
#define ADC_12BIT_RESOLUTION 3
#define ADC_EARLYINT_ENABLE 1
#define ADC_EARLYINT_DISABLE 0
#define ADC_REFVOLT_AVDD 0
#define ADC_CORECLOCK_1BY2 0
#define ADC_CLOCKSOURCE_OSCILLATOR 1
#define ADC_CLOCKSOURCE_FRC 2
#define ADC_CLOCKDIV_1BY1 0
#define ADC_ALLCHANNEL_SINGLE_UNSIGNED 0x0000

#define ADC_CALI_WARMUP 11
#define ADC_CORE_POWER_ENABLE 1
#define ADC_CORE_POWER_DISABLE 0
#define ADC_CORE_ENABLE 1
#define ADC_CORE_DISABLE 0
#define ADC_CORE_CALI_ENABLE 1
#define ADC_CORE_CALI_DISABLE 0
#define ADC_CORE_CALI_SINGLEMODE 0
#define ADC_CORE_CALI_DIFFMODE 1
#define ADC_CORE_CALI_START 1

#define ACLOCK_ASRCSEL_PRIMARY 1
#define ACLOCK_FRCSEL_PRIMARY 0
#define ACLOCK_FRCSEL_FRC 1
#define ACLOCK_DIVSOURCE_APLL 1
#define ACLOCK_DIVSOURCE_FVCO 0
#define ACLOCK_DIVIDER_BY1 7
#define APLL_ENABLE 1
#define APLL_DISABLE 0
#define NEWOSC_PRIMARY_WITHPLL 0x03
#define CURRENTOSC_PRIMARY_WITHPLL 0b011
#define NEWOSC_PRIMARY_NOPLL 0x02
#define NEWOSC_FRC_WITHPLL 0x01
#define NEWOSC_FRC_NOPLL 0x00
#define NEWOSC_SWITCH_ENABLE 0x01

#define HBLLC_ON 1
#define HBLLC_OFF 0

void InitCalibrateADC(void);
void InitAltRegContext1Setup(void);
void InitAltRegContext2Setup(void);
////
//Exported function
void init_SetupClock ( void ) ;
void init_GPIO ( void ) ;
void init_Timer ( void ) ;
void init_ADC ( void ) ;
void init_PWM ( void ) ;

#ifdef Config_Input_CN                        //  Input Change Notification
void init_Input_CN ( void );                
#endif
void init_ISR_IPL();
#endif

