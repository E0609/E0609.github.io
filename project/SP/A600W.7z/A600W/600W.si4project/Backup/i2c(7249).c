
#include "p33Fxxxx.h"
#include "define.h"
#include "dsp.h"

#include "pec.h"
#include "I2C.h"
#include "Pmbus.h"
#include "UserData.h"
#include "Query.h"
#include "Protection.h"
#include "Process.h"
#include <string.h>

//#define MajorRev_MinorRev	0x2000

//[Peter Chung] Add Begin ->
BYTE gSlaveAddrW = 0x00;
BYTE gSlaveAddrR = 0x00;

tD_I2C_DATA I2C;
static BYTE gDataLength = 0;
extern tPSU_STATE gPS_State;
extern tPS_FLAG PS;
WORD i2c_reset_cnt;

BYTE OneTimeFlag ;    //[davidchchen]20170216 added PSON Signal Enable/disable
static BYTE ADDR[16] = { 0xB0,	// Reserved     //[davidchchen]20170110 added, fix HW.
                        0xB0, 	// J1
                        0x00,	// Reserved
                        0xB2,	// J2
                        0x00,	// Reserved
                        0xB4,	// J3
                        0x00,	// Reserved
                        0xB6,	// J4
                        0x00,	// Reserved
                        0xB8,	// J5
                        0x00,	// Reserved
                        0xBA,	// J6
                        0x00,	// Reserved
                        0xBC,	// J7
                        0x00,	// Reserved
                        0xBE,	// J8
};



//[Peter Chung] Add End < -

void init_I2cStruct ( )
{
  I2C.cmdDir = CMD_R;
  I2C.dataIndex = 0;
  I2C.pRxBuf = NULL;
  I2C.pTxBuf = NULL;
  I2C.state = STATE_WAIT_FOR_CMD;
  I2C.isPecFail = FALSE;
  I2C.currentCmd = 0x00;
  I2C.isBlockMode = FALSE;
  I2C.accessNotAllow = FALSE; //[Peter Chung] 20100907 added
  I2C.PermitToWrite = FALSE;

  memset ( I2C.readBuffer, 0, sizeof (I2C.readBuffer ) );
  I2C.pRxBuf = I2C.readBuffer;
  I2C.PEC = 0;

  gDataLength = 0;
}

void init_I2C ( void )
{
  //[Peter Chung] I2C add begin->
  /*
     I2CxCON: I2Cx CONTROL REGISTER
     bit 15                I2CEN: I2Cx Enable bit 
1 = Enables the I2Cx module and configures the SDAx and SCLx pins as serial port pins
0 = Disables the I2Cx module; all I2C pins are controlled by port functions

bit 14                Unimplemented: Read as �??0�??

bit 13                I2CSIDL: I2Cx Stop in Idle Mode bit
1 = Discontinues module operation when device enters Idle mode
0 = Continues module operation in Idle mode

bit 12                SCLREL: SCLx Release Control bit (when operating as I2C slave)
1 = Releases SCLx clock
0 = Holds SCLx clock low (clock stretch)
If STREN = 1:
Bit is R/W (i.e., software can write �??0�?? to initiate stretch and write �??1�?? to release clock). Hardware is clear
at beginning of slave transmission. Hardware is clear at end of slave reception.
If STREN = 0:
Bit is R/S (i.e., software can only write �??1�?? to release clock). Hardware is clear at beginning of slave
transmission.

bit 11    IPMIEN: Intelligent Peripheral Management Interface (IPMI) Enable bit
1 = IPMI mode is enabled; all addresses are Acknowledged
0 = IPMI mode is disabled

bit 10                A10M: 10-Bit Slave Address bit
1 = I2CxADD is a 10-bit slave address
0 = I2CxADD is a 7-bit slave address

bit 9                  DISSLW: Disable Slew Rate Control bit
1 = Slew rate control is disabled
0 = Slew rate control is enabled

bit 8                  SMEN: SMBus Input Levels bit
1 = Enables I/O pin thresholds compliant with SMBus specification
0 = Disables SMBus input thresholds
bit 7                  GCEN: General Call Enable bit (when operating as I2C�?� slave)
1 =  Enables interrupt when a general call address is received in the I2CxRSR (module is enabled for
reception)
0 =  General call address is disabled
bit 6                  STREN: SCLx Clock Stretch Enable bit (when operating as I2C slave)
Used in conjunction with the SCLREL bit.
1 = Enables software or receives clock stretching
0 = Disables software or receives clock stretching


dsPIC33FJ32GS406/606/608/610 and dsPIC33FJ64GS406/606/608/610

DS70000591F-page 274                                                                                                            �?� 2009-2014 Microchip Technology Inc.

bit 5                  ACKDT: Acknowledge Data bit (when operating as I2C master, applicable during master receive)
Value that is transmitted when the software initiates an Acknowledge sequence.
1 = Sends NACK during Acknowledge
0 = Sends ACK during Acknowledge

bit 4                  ACKEN: Acknowledge Sequence Enable bit (when operating as I2C master, applicable during master 
receive)
1 =  Initiates  Acknowledge  sequence  on  SDAx  and  SCLx  pins  and  transmits  ACKDT  data  bit.
Hardware clears at the end of the master Acknowledge sequence.
0 =  Acknowledge sequence is not in progress

bit 3                  RCEN: Receive Enable bit (when operating as I2C master)
1 =  Enables Receive mode for I2C. Hardware clears at the end of the eighth bit of the master receive
data byte.
0 =  Receive sequence is not in progress

bit 2                  PEN: Stop Condition Enable bit (when operating as I2C master)
1 =  Initiates Stop condition on SDAx and SCLx pins. Hardware clears at the end of the master Stop
sequence.
0 =  Stop condition is not in progress
bit 1                  RSEN: Repeated Start Condition Enable bit (when operating as I2C master)
1 =  Initiates Repeated Start condition on SDAx and SCLx pins. Hardware clears at the end of the
master Repeated Start sequence.
0 =  Repeated Start condition is not in progress
bit 0                  SEN: Start Condition Enable bit (when operating as I2C master)
1 =  Initiates Start condition on SDAx and SCLx pins. Hardware clears at the end of the master Start
sequence.
0 =  Start condition is not in progress
  */
  I2C1CON = 0; //reset by manual

  //I2C1CON = 0x9040;
  //I2C1CON = 0xB300;
  I2C1CON = 0xB340;          //1011 0011 0100 0000

  
  IFS1bits.SI2C1IF = 0;
  IPC4bits.SI2C1IP = 4;
  IEC1bits.SI2C1IE = 1;

  i2c_reset_cnt ++;



  //[Peter Chung] 20101223 added for reset I2C structure variable
  init_I2cStruct ( );

  //[Peter Chung] 20110225 Stop Counting 25ms
 // Protect.I2C_SCL_Fault.Flag = 0;     //[davidchchen]20160223_I2C
 // Protect.I2C_SCL_Fault.delay = 0;    //[davidchchen]20160223_I2C
  
  //Protect.I2C_SDA_Fault.Flag = 0;     //[davidchchen] 20150107 removed
  //Protect.I2C_SDA_Fault.delay = 0;    //[davidchchen] 20150107 removed

  //[Peter Chung] 20110511 added
  PS.I2C_Processing = FALSE;
  
}

void GetI2cAddr ( )
{
  BYTE addr = 0x00;
  BYTE pin = 0x00;
  
  pin = ( iADDR0 << 3 ) | ( iADDR1 << 2 ) | ( iADDR2 << 1 ) | iADDR3;
  addr = ADDR[pin];
  
  /*
  I2CxADD : The I2CxADD register holds the slave address.
  */
  
  I2C1ADD = addr >> 1;
  if ( OneTimeFlag == 1 )
  {                                         
      if ( ( I2C1ADD == 0x5E ) ||  ( I2C1ADD == 0x5F ) )               //[davidchchen]20170921 added PSON Signal Enable/disable
      {
          PS.MFR_PSON_CONTROL = TRUE;                                                            
      }
      OneTimeFlag = 0;
  }

  gPmbusCmd.MFR_PSON_CONTROL[0] = PS.MFR_PSON_CONTROL;                          //[davidchchen]20180801 addr pin debounce isse. removed
  gSlaveAddrW = addr;
  gSlaveAddrR = addr + 1;
}

//[Peter Chung] Add Begin ->

static void TransmitData ( BYTE data )
{
  do
  {
      asm("clrwdt" ); //clear WDT
      //delay
      asm volatile("repeat #40" ); //Delay 10us

      I2C1STATbits.IWCOL = 0;
      I2C1TRN = data;
  }
  while ( I2C1STATbits.IWCOL );
}




void HoldSCL ( )
{
  I2C1CONbits.SCLREL = 0;
}

void ReleaseSCL ( )
{
  I2C1CONbits.SCLREL = 1;
}

void CheckI2COV ( )
{
 // BYTE Temp;
  if ( I2C1STATbits.I2COV )
  {
 //   Temp = I2C1RCV;
      I2C1STATbits.I2COV = 0;                      //[Peter Chung] 20100503 modified for buffer overflow issue.
  }
}

BYTE Get_BW_DataLen ( BYTE cmd )
{
  BYTE byte_cnt;

  switch ( cmd )
  {
      case 0x05:	//PAGE_PLUS_WRITE
          byte_cnt = 4;
          break;
      case 0x06:	//PAGE_PLUS_READ
          byte_cnt = 3;
          break;
      case 0x1A:	//QUERY
          byte_cnt = 2;
          break;
      case 0x30:	//COEFFICIENTS
          byte_cnt = 3;
          break;
//      case 0xE7:        //BMC_UNIX_TIMESTAMP        //[davidchchen]20170418 Removed
//          byte_cnt = 4;                             //[davidchchen]20170418 Removed
//          break;
      case 0xBE:	//GEN_CAL_R
          byte_cnt = 7;
          break;
      default:
          byte_cnt = 0;
          break;
  }

  return byte_cnt;

}

BYTE CheckDataContent ( BYTE cmd )
{
  switch ( cmd )
  {
      case 0x05:	//PAGE_PLUS_WRITE
          if ( I2C.readBuffer[0] != 0x03 &&
               I2C.readBuffer[0] != 0x04 )
          {
              return FALSE;
          }	//byte count
          if ( I2C.readBuffer[1] != 0x00 && I2C.readBuffer[1] != 0x01 )
          {
              return FALSE;
          }	//Page
          if ( I2C.readBuffer[0] == 0x03 )
          {
              if ( I2C.readBuffer[2] != 0x79 && 	//STATUS_WORD
                   I2C.readBuffer[2] != 0x7A && 	//STATUS_VOUT
                   I2C.readBuffer[2] != 0x7B && 	//STATUS_IOUT
                   I2C.readBuffer[2] != 0x7C && 	//STATUS_INPUT
                   I2C.readBuffer[2] != 0x7D && 	//STATUS_TEMPERATURE
                   I2C.readBuffer[2] != 0x7E )
              {		//STATUS_CML
                  return FALSE;
              }
          }
          if ( I2C.readBuffer[0] == 0x04 )
          {
              if ( I2C.readBuffer[3] != 0x79 && 	//STATUS_WORD
                   I2C.readBuffer[3] != 0x7A && 	//STATUS_VOUT
                   I2C.readBuffer[3] != 0x7B && 	//STATUS_IOUT
                   I2C.readBuffer[3] != 0x7C && 	//STATUS_INPUT
                   I2C.readBuffer[3] != 0x7D && 	//STATUS_TEMPERATURE
                   I2C.readBuffer[3] != 0x7E )
              {		//STATUS_CML
                  return FALSE;
              }
          }
          return TRUE;
          break;

      case 0x06:	//PAGE_PLUS_READ
          if ( I2C.readBuffer[0] != 0x02 && I2C.readBuffer[0] != 0x03 )
          {
              return FALSE;
          }	//byte count
          if ( I2C.readBuffer[1] != 0x00 && I2C.readBuffer[1] != 0x01 )
          {
              return FALSE;
          }	//Page
          if ( I2C.readBuffer[0] == 0x02 )
          {
              if ( I2C.readBuffer[2] != 0x79 && 	//STATUS_WORD
                   I2C.readBuffer[2] != 0x7A && 	//STATUS_VOUT
                   I2C.readBuffer[2] != 0x7B && 	//STATUS_IOUT
                   I2C.readBuffer[2] != 0x7C && 	//STATUS_INPUT
                   I2C.readBuffer[2] != 0x7D && 	//STATUS_TEMPERATURE
                   I2C.readBuffer[2] != 0x7E )
              {		//STATUS CML
                  return FALSE;
              }
          }
          if ( I2C.readBuffer[0] == 0x03 )
          {
              if ( I2C.readBuffer[3] != 0x7A && 	//STATUS_VOUT
                   I2C.readBuffer[3] != 0x7B && 	//STATUS_IOUT
                   I2C.readBuffer[3] != 0x7C &&	//STATUS_INPUT
                   I2C.readBuffer[3] != 0x7D &&	//STATUS_TEMPERATURE
                   I2C.readBuffer[3] != 0x7E )
              { 	//STATUS_CML
                  return FALSE;
              }
          }
          return TRUE;
          break;

      case 0x1A:	//QUERY
          if ( I2C.readBuffer[0] != 0x01 )
          {
              return FALSE;
          }	//byte count
          return TRUE;
          break;
      case 0x1B:	//SMBALERT_MASK
          return TRUE;
          break;

      case 0x30:	//COEFFICIENTS
          if ( I2C.readBuffer[0] != 0x02 )
          {
              return FALSE;
          }	//byte count
          if ( I2C.readBuffer[1] != 0x86 && I2C.readBuffer[1] != 0x87 )
          {
              return FALSE;
          }	//Direct format command
          if ( I2C.readBuffer[2] != 0x00 && I2C.readBuffer[2] != 0x01 )
          {
              return FALSE;
          }	//Coefficient of W cmd or R cmd
          return TRUE;  
          break;

      case 0xBE:	//GEN_CAL_R
          return TRUE;
          break;
      default:
          break;
  }

  return FALSE;
}
/************************************************************************
 * author:
 * description:
 * input:
 * oututp:
 * version:
 * remark:
 * hostory:
 * ***********************************************************************/
void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _T4Interrupt ( void )
{
  /*Execute I2C command P received*/
  if ( I2C1STATbits.P )
  {

      if ( I2C.cmdDir == CMD_W && I2C.PermitToWrite == TRUE )
      {


          if ( ! gIsFactoryMode )
          {
#if cips
              if ( gPmbusCmd.WRITE_PROTECT[0] == 0x80 )    // cips
              {
                  if ( I2C.currentCmd != 0x10 && I2C.currentCmd != 0xC9 )
                  {
                      gPagePlusStatus.PAGE[gPmbusCmd.PAGE[0]].STATUS_CML.bits.INVALID_CMD = 1;
                      goto SKIP;
                  }
              }
              else if ( gPmbusCmd.WRITE_PROTECT[0] == 0x40 )
              {
                  if ( I2C.currentCmd != 0x10 && I2C.currentCmd != 0x01 && I2C.currentCmd != 0x00 && I2C.currentCmd != 0xC9 )
                  {
                      gPagePlusStatus.PAGE[PAGE0].STATUS_CML.bits.INVALID_CMD = 1;
                      gPagePlusStatus.PAGE[PAGE1].STATUS_CML.bits.INVALID_CMD = 1;
                      goto SKIP;
                  }
              }
              else if ( gPmbusCmd.WRITE_PROTECT[0] == 0x20 )
              {
                  if ( I2C.currentCmd != 0x10 && I2C.currentCmd != 0x01 && I2C.currentCmd != 0x00 &&
                       I2C.currentCmd != 0x02 && I2C.currentCmd != 0x21 && I2C.currentCmd != 0xC9 )
                  {
                      gPagePlusStatus.PAGE[PAGE0].STATUS_CML.bits.INVALID_CMD = 1;
                      gPagePlusStatus.PAGE[PAGE1].STATUS_CML.bits.INVALID_CMD = 1;
                      goto SKIP;
                  }

              }
              else if ( gPmbusCmd.WRITE_PROTECT[0] == 0x00 )
              {
                  //Enable write commands
              }
              else
              {
                  gPagePlusStatus.PAGE[gPmbusCmd.PAGE[0]].STATUS_CML.bits.INVALID_CMD = 1;
                  goto SKIP;
              
              }
              #endif
          }

        
          if ( I2C.isBlockMode )
          {
              if ( ( I2C.dataIndex == gDataLength ) || ( I2C.dataIndex == gDataLength + 1 ) )
              {		//with PEC or without PEC byte
                  //Check data content
                  if ( CheckDataContent ( I2C.currentCmd ) )
                  {
                      //Data is correct
                  }
                  else
                  {
                      //Data is invalid
                      gPagePlusStatus.PAGE[gPmbusCmd.PAGE[0]].STATUS_CML.bits.INVALID_DATA = 1;
                      goto SKIP;
                  }
              }
              else
              {
                  gPagePlusStatus.PAGE[gPmbusCmd.PAGE[0]].STATUS_CML.bits.INVALID_DATA = 1;
                  goto SKIP;
              }
          }
          else
          {
              if ( ! gIsFactoryMode )
              {
                  if ( ( I2C.dataIndex == gDataLength ) || ( I2C.dataIndex == gDataLength + 1 ) )
                  {
                      //Do nothing
                  }
                  else
                  {
                      gPagePlusStatus.PAGE[gPmbusCmd.PAGE[0]].STATUS_CML.bits.INVALID_DATA = 1;
                      goto SKIP;
                  }
              }
          }

          if ( ( ( tQuery ) gCmd[I2C.currentCmd].type ).bits.SupportWrite == 0 )
          {
              goto SKIP;
          }

          //Check if PEC fail or access not allowed
          if ( I2C.isPecFail || I2C.accessNotAllow )
          {
              goto SKIP;
          }

          HoldSCL ( );
          WriteCmdHandler ( );	//execute write cmd here
          ReleaseSCL ( );
      }
  }
  
  
  
SKIP:
  IFS1bits.T4IF = 0;
}


/************************************************************************
 * author:
 * description:
 * input:
 * oututp:
 * version:
 * remark:
 * hostory:
 * ***********************************************************************/
 /*
bit 15              ACKSTAT: Acknowledge Status bit (when operating as I2C™ master, applicable to master transmit operation)
1 = NACK received from slave
0 = ACK received from slave
Hardware is set or clear at the end of slave Acknowledge.
bit 14              TRSTAT: Transmit Status bit (when operating as I2C master, applicable to master transmit operation)
1 = Master transmit is in progress (8 bits + ACK)
0 = Master transmit is not in progress
Hardware is set at the beginning of master transmission. Hardware is clear at the end of slave Acknowledge.
bit 13-11         Unimplemented: Read as ‘0’
bit 10              BCL: Master Bus Collision Detect bit
1 = A bus collision has been detected during a master operation
0 = No collision
Hardware set at detection of bus collision.
bit 9                GCSTAT: General Call Status bit
1 = General call address was received
0 = General call address was not received
Hardware is set when the address matches the general call address. Hardware is clear at Stop detection.
bit 8                ADD10: 10-Bit Address Status bit
1 = 10-bit address was matched
0 = 10-bit address was not matched
Hardware is set at the match of the 2nd byte of matched 10-bit address. Hardware is clear at Stop detection.
bit 7                IWCOL: Write Collision Detect bit
1 = An attempt to write to the I2CxTRN register failed because the I2C module is busy 
0 = No collision
Hardware is set at the occurrence of a write to I2CxTRN while busy (cleared by software).
bit 6                I2COV: Receive Overflow Flag bit
1 = A byte was received while the I2CxRCV register is still holding the previous byte
0 = No overflow
Hardware is set at an attempt to transfer I2CxRSR to I2CxRCV (cleared by software).
bit 5                D_A: Data/Address bit (when operating as I2C slave)
1 = Indicates that the last byte received was data
0 = Indicates that the last byte received was a device address
Hardware is clear at a device address match. Hardware is set by reception of a slave byte.
bit 4                P: Stop bit 
1 = Indicates that a Stop bit has been detected last
0 = Stop bit was not detected last
Hardware is set or clear when Start, Repeated Start or Stop is detected.


dsPIC33FJ32GS406/606/608/610 and dsPIC33FJ64GS406/606/608/610

DS70000591F-page 276                                                                                                             2009-2014 Microchip Technology Inc.

bit 3                S: Start bit 
1 = Indicates that a Start (or Repeated Start) bit has been detected last
0 = Start bit was not detected last
Hardware is set or clear when Start, Repeated Start or Stop is detected.
bit 2                R_W: Read/Write Information bit (when operating as I2C slave)
1 = Read – indicates data transfer is output from slave
0 = Write – indicates data transfer is input to slave
Hardware is set or clear after reception of an I2C device address byte.
bit 1                RBF: Receive Buffer Full Status bit 
1 = Receive is complete, I2CxRCV is full
0 = Receive is not complete, I2CxRCV is empty
Hardware is set when I2CxRCV is written with a received byte. Hardware is clear when software reads
I2CxRCV.
bit 0                TBF: Transmit Buffer Full Status bit
1 = Transmit in progress, I2CxTRN is full
0 = Transmit is complete, I2CxTRN is empty

*/

BYTE Temp;
/************************************************************************
 * author:
 * description:
 * input:
 * oututp:
 * version:
 * remark:
 * hostory:
 * ***********************************************************************/

static void Address_matched()
{
     //Initialization
      Temp = I2C1RCV;

      init_I2cStruct ( );

      CalcPEC ( &I2C.PEC, gSlaveAddrW );
}

/************************************************************************
 * author:
 * description:
 * input:
 * oututp:
 * version:
 * remark:
 * hostory:
 * ***********************************************************************/

static void  Write_check_Data()
{
   
        BYTE read_byte = I2C1RCV;

         I2C.cmdDir = CMD_W;	//[Peter Chung] 20100730 modified

         if ( I2C.state == STATE_WAIT_FOR_CMD )
        {
                 I2C.currentCmd = read_byte;
          CalcPEC ( &I2C.PEC, I2C.currentCmd );

          I2C.state = STATE_WAIT_FOR_WRITE_DATA;	//asume next will be write data

          //Check if facotry mode or not
          if ( IsFactoryCmd ( I2C.currentCmd ) )
          {
              if ( ! gIsFactoryMode )
              {
                  //treat it as invalid command
                  gPagePlusStatus.PAGE[gPmbusCmd.PAGE[0]].STATUS_CML.bits.INVALID_CMD = 1;
                  I2C.accessNotAllow = TRUE;	//[Peter Chung] 20100907 added
                  return;
              }
          }

          //Check commands can be executed in page1 or not
          if ( isPermitToReadInPage1 ( I2C.currentCmd ) == FALSE && isPermitToWriteInPage1 ( I2C.currentCmd ) == FALSE )
          {
              if ( gPmbusCmd.PAGE[0] == 1 )
              {
                  gPagePlusStatus.PAGE[gPmbusCmd.PAGE[0]].STATUS_CML.bits.INVALID_CMD = 1;
                  I2C.accessNotAllow = TRUE;	//[Peter Chung] 20100907 added
                  return;
              }
          }

          if ( ( ( tQuery ) gCmd[I2C.currentCmd].type ).bits.SupportCmd == FALSE )
          {
              gPagePlusStatus.PAGE[gPmbusCmd.PAGE[0]].STATUS_CML.bits.INVALID_CMD = 1;
              I2C.accessNotAllow = TRUE;	//[Peter Chung] 20100907 added
              return;
          }

          if ( gCmd[I2C.currentCmd].pBuf != NULL )
          {

              if ( gPmbusCmd.MFR_PAGE[0] != 0xFF )	//for Blackbox
              {
#if cips// BLACKBOX_SUPPORTED
                  I2C.pTxBuf = GetDataFromBlackBox ( I2C.currentCmd );
#endif

                  if ( I2C.pTxBuf == NULL )
                  {
                      //if the command is not support for BlackBox, point it to the specific data buffer
                      I2C.pTxBuf = gCmd[I2C.currentCmd].pBuf;	//assgin TxBuffer point to the specified Cmd buffer for reading
                  }
              }
              else
              {
                  I2C.pTxBuf = gCmd[I2C.currentCmd].pBuf;	//assgin TxBuffer point to the specified Cmd buffer for reading
              }


#if 1
              if ( ! PS.EIN_DataUpdating && PS.EIN_DataUpdated )
              {
                  PS.EIN_DataUpdated = 0;
                  memcpy ( gPmbusCmd.READ_EIN_TEMP, gPmbusCmd.READ_EIN, 7 );
              }

              if ( ! PS.EOUT_DataUpdating && PS.EOUT_DataUpdated )
              {
                  PS.EOUT_DataUpdated = 0;
                  memcpy ( gPmbusCmd.READ_EOUT_TEMP, gPmbusCmd.READ_EOUT, 7 );
              }

              if ( I2C.currentCmd == 0x86 )
              {
                  if ( PS.EIN_DataUpdating )
                  {
                      I2C.pTxBuf = gPmbusCmd.READ_EIN_TEMP;
                  }
                  else
                  {
                      I2C.pTxBuf = gPmbusCmd.READ_EIN;
                  }
              }
              if ( I2C.currentCmd == 0x87 )
              {
                  if ( PS.EOUT_DataUpdating )
                  {
                      I2C.pTxBuf = gPmbusCmd.READ_EOUT_TEMP;
                  }
                  else
                  {
                      I2C.pTxBuf = gPmbusCmd.READ_EOUT;
                  }
              }
#endif
          }
          else
          {
              if ( ! IsSendCmd ( I2C.currentCmd ) )
              {
                  gPagePlusStatus.PAGE[gPmbusCmd.PAGE[0]].STATUS_CML.bits.INVALID_DATA = 1;
                  I2C.accessNotAllow = TRUE;	//[Peter Chung] 20100907 added
                  return;
              }
              else
              {
                  I2C.PermitToWrite = TRUE;
              }
          }

      }

      else if ( I2C.state == STATE_WAIT_FOR_WRITE_DATA )
      {
          //Check if in standby mode or not to make sure the command valid to access or not...
          
          #if 0     //[davidchchen]20160429  STATUS_CML can be settign NORMAL and STANDBY mode


          #else   //[davidchchen]20160429  STATUS_CML can be settign all mode

          if ( ( ( tQuery ) gCmd[I2C.currentCmd].type ).bits.SupportWrite == 0 &&
                   ! ( CheckBlockMode ( I2C.currentCmd ) ) )
              {
                  gPagePlusStatus.PAGE[gPmbusCmd.PAGE[0]].STATUS_CML.bits.INVALID_DATA = 1;
                  I2C.accessNotAllow = TRUE;	//[Peter Chung] 20100907 added
                  return;
              }

          #endif

          //Check if this is process call command or not here.
          if ( I2C.dataIndex == 0 )
          {	                                                         //enter only first time
                                                                     //Check if Block-Write-Block-Read cmd
              I2C.isBlockMode = CheckBlockMode ( I2C.currentCmd );

              if ( I2C.isBlockMode )
              {
                  if ( I2C.currentCmd == 0x1B )
                  {
                      //Exception for 0x1B SMBALERT_MASK
                      //(support Write Word & BlockWrite-BlockRead at the same time)
                      if ( read_byte == 1 )
                      {
                          gDataLength = 2;	//BlockWrite-BlockRead mode, (block count byte + Status_x command code byte)
                      }
                      else
                      {
                          gDataLength = gCmd[I2C.currentCmd].Len;	//Write word mode
                      }
                  }
                  else if ( I2C.currentCmd == 0x05 )
                  {
                      //[Peter Chung] 20111005 add exception for PAGE_PLUS_WRITE SMBALERT_MASK
                      if ( read_byte == 3 )
                      {
                          gDataLength = 4;
                      }
                      else if ( read_byte == 4 )
                      {
                          gDataLength = 5;
                      }
                      else
                      {
                          gDataLength = gCmd[I2C.currentCmd].Len;
                      }
                  }
                  else if ( I2C.currentCmd == 0x06 )
                  {
                      //[Peter Chung] 20111005 add exception for PAGE_PLUS_READ SMBALERT_MASK
                      if ( read_byte == 2 )
                      {
                          gDataLength = 3;
                      }
                      else if ( read_byte == 3 )
                      {
                          gDataLength = 4;
                      }
                      else
                      {
                          gDataLength = gCmd[I2C.currentCmd].Len;
                      }
                  }
                  else if ( I2C.currentCmd == 0xE7 )
                  {

                      if ( read_byte == 4 )
                      {
                          gDataLength = 5;
                      }
                      else
                      {
                          gDataLength = gCmd[I2C.currentCmd].Len;
                      }
                  }
                  else
                  {
                      //gDataLength = read_byte + 1;	//get byte count here, 1 is the byte of byte count itself
                      gDataLength = Get_BW_DataLen ( I2C.currentCmd );	//[Peter Chung] 20110124 modified
                  }
              }
              else
              {

                  gDataLength = gCmd[I2C.currentCmd].Len;
              }

          }

          if ( I2C.dataIndex < gDataLength )
          {
              *I2C.pRxBuf = read_byte;
              I2C.pRxBuf ++;
              CalcPEC ( &I2C.PEC, read_byte );
              if ( ! gIsFactoryMode )
              {
                  if ( I2C.dataIndex == ( gDataLength - 1 ) )
                  {
                      I2C.PermitToWrite = TRUE;
                  }
              }
              else
              {
                  I2C.PermitToWrite = TRUE;
              }
          }
          else if ( I2C.dataIndex == gDataLength )
          {	//recognized as PEC byte
              BYTE PEC_byte;

              PEC_byte = read_byte;

              //if ( ( PEC_byte != I2C.PEC ) && ( I2C.isBlockMode == 0 ) )
              if ( ( PEC_byte != I2C.PEC ) && ( I2C.isBlockMode == 0 || I2C.isBlockMode == 1) )
              {
                  I2C.isPecFail = TRUE;
                  gPagePlusStatus.PAGE[gPmbusCmd.PAGE[0]].STATUS_CML.bits.PEC_FAILED = 1;
              }

          }
          else
          {
              Temp = read_byte;	//dummy Rx byte
          }

          I2C.dataIndex ++;
      }
}
/************************************************************************
 * author:
 * description:
 * input:
 * oututp:
 * version:
 * remark:
 * hostory:
 * ***********************************************************************/

static void Read_check_data()
{
  BYTE return_byte;

      //[Peter Chung] 20100930 added
      if ( I2C.pTxBuf == NULL || I2C.accessNotAllow )
      {
          return_byte = 0xFF;
          TransmitData ( return_byte );
          //ToDo : set status flag here
          return;
      }

      if ( I2C.dataIndex < gDataLength )
      {

          if ( I2C.dataIndex == ( gDataLength - 1 ) )
          {
              PS.I2C_Processing = FALSE;
          }

          if ( I2C.pTxBuf == NULL )
          {
              return_byte = 0xFF;
              TransmitData ( return_byte );
              //ToDo : set status flag here
              return;
          }
          else
          {
              return_byte = I2C.pTxBuf[I2C.dataIndex];
          }
          CalcPEC ( &I2C.PEC, return_byte );
      }
      else if ( I2C.dataIndex == gDataLength )
      {
          //return PEC byte
          return_byte = I2C.PEC;
      }
      else
      {
          //return dummy byte
          return_byte = 0xFF;
      }

      TransmitData ( return_byte );
      //I2C1CONbits.SCLREL = 1; 	//release clock line so MASTER can drive it
      I2C.dataIndex ++;
}

/************************************************************************
 * author:
 * description:
 * input:
 * oututp:
 * version:
 * remark:
 * hostory:
 * ***********************************************************************/

static void Read_check_Address()
{
   
      BYTE return_byte;

      ////HoldSCL(); //[Peter Chung] 20100601
      PS.I2C_Processing = TRUE;         //[davidchchen] 20170914 added
      Temp = I2C1RCV;
      I2C.cmdDir = CMD_R;
      I2C.dataIndex = 0;
      CalcPEC ( &I2C.PEC, gSlaveAddrR );

      //Check BlockWrite-BlockRead Cmd
      if ( I2C.isBlockMode )
      {
          //Handle BlockWritten data
          HandleWRBlock ( I2C.currentCmd );
       
          gDataLength = gCmd[I2C.currentCmd].pBuf[0] + 1;	//the first byte is byte count
      }
      else
      {
          gDataLength = gCmd[I2C.currentCmd].Len;
      }
	  
      if ( I2C.pTxBuf == NULL || I2C.accessNotAllow )
      {
          return_byte = 0xFF;
          TransmitData ( return_byte );
          //ToDo : set status flag here
          return;
      }
      else
      {
          return_byte = I2C.pTxBuf[I2C.dataIndex];
      }

      CalcPEC ( &I2C.PEC, return_byte );

      TransmitData ( return_byte );
      //I2C1CONbits.SCLREL = 1;
      I2C.dataIndex ++;
}


/************************************************************************
 * author:
 * description:
 * input:
 * oututp:
 * version:
 * remark:
 * hostory:
 * ***********************************************************************/
 
void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _SI2C1Interrupt ( )
{
  
  if ( ( I2C1STATbits.R_W == 0 ) && ( I2C1STATbits.D_A == 0 ) )	//Address matched
  {
     Address_matched();
  }
  else if ( ( I2C1STATbits.R_W == 0 ) && ( I2C1STATbits.D_A == 1 ) ) //Write, check for data
  {
     Write_check_Data();
	 
  }
  else if ( ( I2C1STATbits.R_W == 1 ) && ( I2C1STATbits.D_A == 1 ) )	//Read data
  {
     Read_check_data();
	
  }
  else if ( ( I2C1STATbits.R_W == 1 ) && ( I2C1STATbits.D_A == 0 ) )	//Read address
  {
     Read_check_Address();
  }
	//OUT:
	
	  if ( I2C1STATbits.RBF )             //RBF: Receive Buffer Full Status bit 1=full,0=empty
	  {
		  Temp = I2C1RCV;
		  I2C1STATbits.RBF = 0;
	  }
	  I2C1STATbits.IWCOL = 0;
	  _SI2C1IF = 0;                       //clear I2C1 Slave interrupt flag
	  ReleaseSCL ( );
}

// end of file

#if 0//cips

void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _SI2C1Interrupt ( )
{
  BYTE Temp;

  if ( ( I2C1STATbits.R_W == 0 ) && ( I2C1STATbits.D_A == 0 ) )	//Address matched
  {
      
      //Initialization
      Temp = I2C1RCV;

      init_I2cStruct ( );

      CalcPEC ( &I2C.PEC, gSlaveAddrW );
	  
  }
  else if ( ( I2C1STATbits.R_W == 0 ) && ( I2C1STATbits.D_A == 1 ) ) //Write, check for data
  {

        BYTE read_byte = I2C1RCV;

         I2C.cmdDir = CMD_W;	//[Peter Chung] 20100730 modified

         if ( I2C.state == STATE_WAIT_FOR_CMD )
        {
                 I2C.currentCmd = read_byte;
          CalcPEC ( &I2C.PEC, I2C.currentCmd );

          I2C.state = STATE_WAIT_FOR_WRITE_DATA;	//asume next will be write data

          //Check if facotry mode or not
          if ( IsFactoryCmd ( I2C.currentCmd ) )
          {
              if ( ! gIsFactoryMode )
              {
                  //treat it as invalid command
                  gPagePlusStatus.PAGE[gPmbusCmd.PAGE[0]].STATUS_CML.bits.INVALID_CMD = 1;
                  I2C.accessNotAllow = TRUE;	//[Peter Chung] 20100907 added
                  return;
              }
          }

          //Check commands can be executed in page1 or not
          if ( isPermitToReadInPage1 ( I2C.currentCmd ) == FALSE && isPermitToWriteInPage1 ( I2C.currentCmd ) == FALSE )
          {
              if ( gPmbusCmd.PAGE[0] == 1 )
              {
                  gPagePlusStatus.PAGE[gPmbusCmd.PAGE[0]].STATUS_CML.bits.INVALID_CMD = 1;
                  I2C.accessNotAllow = TRUE;	//[Peter Chung] 20100907 added
                  return;
              }
          }

          if ( ( ( tQuery ) gCmd[I2C.currentCmd].type ).bits.SupportCmd == FALSE )
          {
              gPagePlusStatus.PAGE[gPmbusCmd.PAGE[0]].STATUS_CML.bits.INVALID_CMD = 1;
              I2C.accessNotAllow = TRUE;	//[Peter Chung] 20100907 added
              return;
          }

          if ( gCmd[I2C.currentCmd].pBuf != NULL )
          {

              if ( gPmbusCmd.MFR_PAGE[0] != 0xFF )	//for Blackbox
              {
#if cips// BLACKBOX_SUPPORTED
                  I2C.pTxBuf = GetDataFromBlackBox ( I2C.currentCmd );
#endif

                  if ( I2C.pTxBuf == NULL )
                  {
                      //if the command is not support for BlackBox, point it to the specific data buffer
                      I2C.pTxBuf = gCmd[I2C.currentCmd].pBuf;	//assgin TxBuffer point to the specified Cmd buffer for reading
                  }
              }
              else
              {
                  I2C.pTxBuf = gCmd[I2C.currentCmd].pBuf;	//assgin TxBuffer point to the specified Cmd buffer for reading
              }


#if 1
              if ( ! PS.EIN_DataUpdating && PS.EIN_DataUpdated )
              {
                  PS.EIN_DataUpdated = 0;
                  memcpy ( gPmbusCmd.READ_EIN_TEMP, gPmbusCmd.READ_EIN, 7 );
              }

              if ( ! PS.EOUT_DataUpdating && PS.EOUT_DataUpdated )
              {
                  PS.EOUT_DataUpdated = 0;
                  memcpy ( gPmbusCmd.READ_EOUT_TEMP, gPmbusCmd.READ_EOUT, 7 );
              }

              if ( I2C.currentCmd == 0x86 )
              {
                  if ( PS.EIN_DataUpdating )
                  {
                      I2C.pTxBuf = gPmbusCmd.READ_EIN_TEMP;
                  }
                  else
                  {
                      I2C.pTxBuf = gPmbusCmd.READ_EIN;
                  }
              }
              if ( I2C.currentCmd == 0x87 )
              {
                  if ( PS.EOUT_DataUpdating )
                  {
                      I2C.pTxBuf = gPmbusCmd.READ_EOUT_TEMP;
                  }
                  else
                  {
                      I2C.pTxBuf = gPmbusCmd.READ_EOUT;
                  }
              }
#endif
          }
          else
          {
              if ( ! IsSendCmd ( I2C.currentCmd ) )
              {
                  gPagePlusStatus.PAGE[gPmbusCmd.PAGE[0]].STATUS_CML.bits.INVALID_DATA = 1;
                  I2C.accessNotAllow = TRUE;	//[Peter Chung] 20100907 added
                  return;
              }
              else
              {
                  I2C.PermitToWrite = TRUE;
              }
          }

      }

      else if ( I2C.state == STATE_WAIT_FOR_WRITE_DATA )
      {
          //Check if in standby mode or not to make sure the command valid to access or not...
          
          #if 0     //[davidchchen]20160429  STATUS_CML can be settign NORMAL and STANDBY mode


          #else   //[davidchchen]20160429  STATUS_CML can be settign all mode

          if ( ( ( tQuery ) gCmd[I2C.currentCmd].type ).bits.SupportWrite == 0 &&
                   ! ( CheckBlockMode ( I2C.currentCmd ) ) )
              {
                  gPagePlusStatus.PAGE[gPmbusCmd.PAGE[0]].STATUS_CML.bits.INVALID_DATA = 1;
                  I2C.accessNotAllow = TRUE;	//[Peter Chung] 20100907 added
                  return;
              }

          #endif

          //Check if this is process call command or not here.
          if ( I2C.dataIndex == 0 )
          {	//enter only first time
              //Check if Block-Write-Block-Read cmd
              I2C.isBlockMode = CheckBlockMode ( I2C.currentCmd );

              if ( I2C.isBlockMode )
              {
                  if ( I2C.currentCmd == 0x1B )
                  {
                      //Exception for 0x1B SMBALERT_MASK
                      //(support Write Word & BlockWrite-BlockRead at the same time)
                      if ( read_byte == 1 )
                      {
                          gDataLength = 2;	//BlockWrite-BlockRead mode, (block count byte + Status_x command code byte)
                      }
                      else
                      {
                          gDataLength = gCmd[I2C.currentCmd].Len;	//Write word mode
                      }
                  }
                  else if ( I2C.currentCmd == 0x05 )
                  {
                      //[Peter Chung] 20111005 add exception for PAGE_PLUS_WRITE SMBALERT_MASK
                      if ( read_byte == 3 )
                      {
                          gDataLength = 4;
                      }
                      else if ( read_byte == 4 )
                      {
                          gDataLength = 5;
                      }
                      else
                      {
                          gDataLength = gCmd[I2C.currentCmd].Len;
                      }
                  }
                  else if ( I2C.currentCmd == 0x06 )
                  {
                      //[Peter Chung] 20111005 add exception for PAGE_PLUS_READ SMBALERT_MASK
                      if ( read_byte == 2 )
                      {
                          gDataLength = 3;
                      }
                      else if ( read_byte == 3 )
                      {
                          gDataLength = 4;
                      }
                      else
                      {
                          gDataLength = gCmd[I2C.currentCmd].Len;
                      }
                  }
                  else if ( I2C.currentCmd == 0xE7 )
                  {

                      if ( read_byte == 4 )
                      {
                          gDataLength = 5;
                      }
                      else
                      {
                          gDataLength = gCmd[I2C.currentCmd].Len;
                      }
                  }
                  else
                  {
                      //gDataLength = read_byte + 1;	//get byte count here, 1 is the byte of byte count itself
                      gDataLength = Get_BW_DataLen ( I2C.currentCmd );	//[Peter Chung] 20110124 modified
                  }
              }
              else
              {

                  gDataLength = gCmd[I2C.currentCmd].Len;
              }

          }

          if ( I2C.dataIndex < gDataLength )
          {
              *I2C.pRxBuf = read_byte;
              I2C.pRxBuf ++;
              CalcPEC ( &I2C.PEC, read_byte );
              if ( ! gIsFactoryMode )
              {
                  if ( I2C.dataIndex == ( gDataLength - 1 ) )
                  {
                      I2C.PermitToWrite = TRUE;
                  }
              }
              else
              {
                  I2C.PermitToWrite = TRUE;
              }
          }
          else if ( I2C.dataIndex == gDataLength )
          {	//recognized as PEC byte
              BYTE PEC_byte;

              PEC_byte = read_byte;

              //if ( ( PEC_byte != I2C.PEC ) && ( I2C.isBlockMode == 0 ) )
              if ( ( PEC_byte != I2C.PEC ) && ( I2C.isBlockMode == 0 || I2C.isBlockMode == 1) )
              {
                  I2C.isPecFail = TRUE;
                  gPagePlusStatus.PAGE[gPmbusCmd.PAGE[0]].STATUS_CML.bits.PEC_FAILED = 1;
              }

          }
          else
          {
              Temp = read_byte;	//dummy Rx byte
          }

          I2C.dataIndex ++;
      }

  }
  else if ( ( I2C1STATbits.R_W == 1 ) && ( I2C1STATbits.D_A == 1 ) )	//Read data
  {
      BYTE return_byte;

      //[Peter Chung] 20100930 added
      if ( I2C.pTxBuf == NULL || I2C.accessNotAllow )
      {
          return_byte = 0xFF;
          TransmitData ( return_byte );
          //ToDo : set status flag here
          return;
      }

      if ( I2C.dataIndex < gDataLength )
      {

          ////HoldSCL(); //[Peter Chung] 20100601

          //[Peter Chung] 20110511 added
          if ( I2C.dataIndex == ( gDataLength - 1 ) )
          {
              PS.I2C_Processing = FALSE;
          }

          if ( I2C.pTxBuf == NULL )
          {
              return_byte = 0xFF;
              TransmitData ( return_byte );
              //ToDo : set status flag here
              return;
          }
          else
          {
              return_byte = I2C.pTxBuf[I2C.dataIndex];
          }
          CalcPEC ( &I2C.PEC, return_byte );
      }
      else if ( I2C.dataIndex == gDataLength )
      {
          //return PEC byte
          return_byte = I2C.PEC;
      }
      else
      {
          //return dummy byte
          return_byte = 0xFF;
      }

      TransmitData ( return_byte );
      //I2C1CONbits.SCLREL = 1; 	//release clock line so MASTER can drive it
      I2C.dataIndex ++;
  }
  else if ( ( I2C1STATbits.R_W == 1 ) && ( I2C1STATbits.D_A == 0 ) )	//Read address
  {
      BYTE return_byte;

      ////HoldSCL(); //[Peter Chung] 20100601
      PS.I2C_Processing = TRUE;         //[davidchchen] 20170914 added

      Temp = I2C1RCV;

      I2C.cmdDir = CMD_R;
      I2C.dataIndex = 0;
      CalcPEC ( &I2C.PEC, gSlaveAddrR );

      //Check BlockWrite-BlockRead Cmd
      if ( I2C.isBlockMode )
      {
          //Handle BlockWritten data
          HandleWRBlock ( I2C.currentCmd );
          //update data length
          gDataLength = gCmd[I2C.currentCmd].pBuf[0] + 1;	//the first byte is byte count
      }
      else
      {
          gDataLength = gCmd[I2C.currentCmd].Len;
      }


      if ( I2C.pTxBuf == NULL || I2C.accessNotAllow )
      {
          return_byte = 0xFF;
          TransmitData ( return_byte );
          //ToDo : set status flag here
          return;
      }
      else
      {
          return_byte = I2C.pTxBuf[I2C.dataIndex];
      }

      CalcPEC ( &I2C.PEC, return_byte );

      TransmitData ( return_byte );
      //I2C1CONbits.SCLREL = 1;
      I2C.dataIndex ++;
  }


OUT:



  //I2C1STATbits.RBF = 0;
  if ( I2C1STATbits.RBF )
  {
      Temp = I2C1RCV;
      I2C1STATbits.RBF = 0;
  }
  I2C1STATbits.IWCOL = 0;
  _SI2C1IF = 0;	//clear I2C1 Slave interrupt flag

  ReleaseSCL ( );
}

#endif

//[Peter Chung] Add End <-

