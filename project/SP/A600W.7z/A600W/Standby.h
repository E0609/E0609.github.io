
#ifndef __STANDBY_H__
#define __STANDBY_H__

#include "Define.h"
/*

spec
	VOUT SCP	DC: 270A	N/A
	12VSB OVP	DC: 14.2	DC: 14.7 V
	12VSB OVW	DC: 13.5	N/A
	12VSB UVP	DC: 10.7	N/A
	12VSB OCP	DC: 3.5 A	N/A
	12VSB OCW	DC: 3.0A	N/A
	12VSB SCP	DC: 5.5A	DC: 6.3A

*/
#define cSTB_OK_REFH		500		//1024/16.23(3.3) //718		// 11.4V 
#define cSTB_OK_REFL		450		//630   	//705
#define cSTB_UV_BLANK		50		//10ms


#define STB_OCW_REF	(WORD)(((DWORD)22*ISB_TO_ADC)/10)          	//2.2A  
#define STB_OC_REF	(WORD)(((DWORD)25*ISB_TO_ADC)/10)		//2.5A  
#define STB_SC_REF	(WORD)(((DWORD)30*ISB_TO_ADC)/10)	// 3.0A  modify 600W



#define STB_Falt_condition  ( ( _SD_Flag.STB_OCP | _SD_Flag.STB_OVP | _SD_Flag.STB_UVP | _SD_Flag.STB_OTP ) == FALSE )
//Exported variable
extern BYTE STB_SCP_Delay ;
extern tSTB STB ;

//Exported function
//void STBOringCntrl ( ) ;
void drv_EnableSTBoutput ( ) ;
void drv_DisableSTBoutput ( ) ;
//void m_IsSTB_InReg ( ) ;
void App_STB_OVP_hnd ( ) ;
void m_retrieve_STBUVP_Flag ( ) ;
void m_retrieve_STB_OCP_Flag ( ) ;
void App_STB_SCP_hnd ( ) ;
void App_STB_VoltageControl ( ) ;
void init_Standby ( ) ;

#endif

