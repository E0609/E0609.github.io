
#include "p33Exxxx.h"
#include "Define.h"
#include "Sci.h"
#include "Protection.h"
#include "Process.h"
#include "Fan.h"
#include <string.h>
#include "Pmbus.h"
#include "UserData.h"
#include "Util.h"
#include "Isr.h"
#include "Led.h"


#include "math.h"


extern tLLC HBLLC;
extern tPS_FLAG PS;
//UART Start ->
/*
 *	+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+
 *	| "D" | "S" | "E" | Vlsb| Vmsb| Ilsb| Imsb| Plsb| Pmsb| Tadc| Vfrq|Chksm|
 *	+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+
 */

#define TERIDIAN_CALI_RETRY		FALSE//TRUE
#define MAX_RETRY_COUNT			3
#ifdef no_used
#define FIRST_CHAR		'D'
#define SECOND_CHAR	'S'
#define THIRD_CHAR		'E'

#define LARGER_SIGN		">"
#define CHAR_I			'I'
#define CHAR_C			'C'
#define CHAR_a			'a'
#define CHAR_l			'l'
#define CHAR_SPACE		' '
#define CHAR_O			'O'
#define CHAR_K			'K'
#endif


static volatile WORD gRxFifoCount = 0;
static volatile BYTE gStartFlag = 0;
static volatile BYTE gSCI_CheckSum = 0;

BYTE gTeridanCaliType = CALI_NONE;	

BYTE recv_pntr = 0;
BYTE start_pntr = 0;

#define FIRST_HEADER_P		0
#define SECOND_HEADER_P		1
#define THIRD_HEADER_P		2

#define VIN_LSB_P			3
#define VIN_MSB_P			4
#define IIN_LSB_P			5
#define IIN_MSB_P			6
#define PIN_LSB_P			7
#define PIN_MSB_P			8
#define TEMPER_P			9
#define FREQ_P				10
#define CHKSUM_P			11

#define MAX_COMM_ERR_COUNT	100

#define IIN_BUF_SIZE	32 
#define IIN_BUF_EXP		5 

#define PIN_BUF_SIZE	8
#define PIN_BUF_EXP		3

tSCI_DATA Uart;
tSTATUS_TO_PRIMARY StatusToPrimary;

static volatile BYTE tRxData[10];   
// ------ TX  ------ 
#define HEADER	0xAA;
/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
void init_UART1 ( DWORD u32_baudRate )
{
    
#define T_C25 820   // 25 degree Celsius
  // ------ TX  ------
  U1MODEbits.UARTEN = 0;
  CONFIG_BAUDRATE_UART1 ( u32_baudRate );
  CONFIG_PDSEL_UART1 ( UXMODE_PDSEL_8DATA_NOPARITY );        // 8-bit data, no parity
  CONFIG_STOPBITS_UART1 ( 1 );            	                                                       // 1 Stop bit

  U1MODEbits.URXINV = 1;
  U1MODEbits.UARTEN = 1;
  U1STAbits.UTXEN = 1;

  // ------ RX  ------
  _U1RXIF = 0;							                                //clear the flag
  _U1RXIP = 3;							                                //choose a priority
  _U1RXIE = 1;

  //init rx buffer for preventing the primary side OTP
  Uart.U1.Rx.Pri_Temperature.Val = T_C25;	
}

/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static void UpdatePrimaryData ( UART_FROM_PRI_RECVDATA* rx_data )
{
  switch ( ( *rx_data ).Cmd )
  {
      case CMD_PRI_TEMPERATURE:
          Uart.U1.Rx.Pri_Temperature.Val = ( *rx_data ).Data.Val;
          break;
      case CMD_PRI_VIN:
          Uart.U1.Rx.Pri_Vin.Val =  ( *rx_data ).Data.Val;
          
#ifndef remove
          if (Uart.U1.Rx.Pri_Vin.Val <60)
          {
              gLedStatus.bits.ac_lost=1;
          }
#endif
          break;
      case CMD_PRI_VBUS:
          Uart.U1.Rx.Pri_VBus.Val =  ( *rx_data ).Data.Val;
          break;
      case CMD_PRI_IIN:
          Uart.U1.Rx.Pri_Iin.Val =  ( *rx_data ).Data.Val;
          break;    
      case CMD_PRI_FW_VER:
      {
          Uart.U1.Rx.Pri_FW_VER.Val = ( *rx_data ).Data.Val;
#if 1
          gPmbusCmd.MFR_FW_VERSION[3] = Uart.U1.Rx.Pri_FW_VER.byte.LB;  
          gPmbusCmd.MFR_FW_VERSION[4] = Uart.U1.Rx.Pri_FW_VER.byte.HB;  
          strncpy ( ( char * ) &UserData.Page2.region.PriFwRev.Val, ( char * ) &Uart.U1.Rx.Pri_FW_VER.Val, MFR_PRI_VERSION_LEN ); //Primary FW version
          PS.PriFwUpdated = TRUE;
#endif
      }
          break;    
      case CMD_PRI_FW_VER_INTERNAL:
          Uart.U1.Rx.Pri_FW_VER_Internal.Val = ( *rx_data ).Data.Val;
          gPmbusCmd.PRI_FW_VER_INTERNAL[0] = Uart.U1.Rx.Pri_FW_VER_Internal.byte.LB;
          gPmbusCmd.PRI_FW_VER_INTERNAL[1] = Uart.U1.Rx.Pri_FW_VER_Internal.byte.HB;
          break;

      default: break;
  }

  Uart.U1.Rx.Pri_Status.Val = ( *rx_data ).Status;
  if ( Uart.U1.Rx.Pri_Status.bits.PriCommError == 0 )   // 0=> no comm error
  {
      MFR_Status.bits.SCI_PriRx_FAIL = 0;  
      Protect. u1PriRxWDT.Flag = 0;        
      Protect. u1PriRxWDT.delay = 0;       
  }
  else
  {
      #if 0 //WH
      Protect. u1PriRxWDT.Flag = 0;  
#endif
  }
  

#ifdef cips //WH
  gPmbusCmd.PRI_STATUS[0] = Uart.U1.Rx.Pri_Status.Val;
  gPmbusCmd.PRI_STATUS[1] = Uart.U1.Rx.Pri_Temperature.byte.LB;
  gPmbusCmd.PRI_STATUS[2] = Uart.U1.Rx.Pri_Temperature.byte.HB;
  gPmbusCmd.PRI_STATUS[3] = Uart.U1.Rx.Pri_FW_VER.byte.LB;
  gPmbusCmd.PRI_STATUS[4] = Uart.U1.Rx.Pri_FW_VER.byte.HB;
  gPmbusCmd.PRI_STATUS[5] = Uart.U1.Rx.Pri_VBus.byte.LB;
  gPmbusCmd.PRI_STATUS[6] = Uart.U1.Rx.Pri_VBus.byte.HB;
  gPmbusCmd.PRI_STATUS[7] = Uart.U1.Rx.Pri_Vin.byte.LB;
  gPmbusCmd.PRI_STATUS[8] = Uart.U1.Rx.Pri_Vin.byte.HB;

  MFR_Status.bits.PFC_OV = Uart.U1.Rx.Pri_Status.bits.PFCOV;
#endif
}
/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static void UpdateTxData ( U1_TX_CMD cmd )
{
  WORD result = 0;
    WORD result2 = 0;
  switch ( cmd )
  {
      case CMD_IOUT:     //transmit Iout adc  
          if ( HBLLC.MainEnabled == TRUE )
          {
              result = ( ( ( DWORD ) ADC.Iout * ADC_TO_IOUT ) >> ADC_TO_IOUT_GAIN );
          }
          else
          {
              result = 0;
          }
          Uart.U1.Tx.cmd[cmd].byte.LB = result & 0xFF;
          Uart.U1.Tx.cmd[cmd].byte.HB = ( result >> 8 ) & 0xFF;
          break;
      // VTHD ISSUE
#ifndef Config_TERIDIAN_VinToPrimary        // 78M6610 Vin sent to Primary, add Vthd Fun,but cause AC glitch.
      case CMD_VIN:    
          result2 = Real_Vac;
          if ( PS.IsTeridianCaliMode == TRUE )
          {
              result2 = 230;
          }

          Uart.U1.Tx.cmd[cmd].byte.LB = result2 & 0xFF;
          Uart.U1.Tx.cmd[cmd].byte.HB = ( result2 >> 8 ) & 0xFF;
          break;
#endif
      default:
          break;
  }

  Uart.U1.Tx.status.Val = StatusToPrimary.Val;
}

static void drv_SendU1TxData ( BYTE data )
{
  U1TXREG = data;
}
/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
void SCI_U1_Transmit ( )
{
  static U1_RX_STATE uartState = STATE_SENDING_HEADER;
  static BYTE checksum = 0;
  static U1_TX_CMD cmdIndex = CMD_IOUT;
  BYTE data;

  if ( U1STAbits.TRMT == 1 && U1STAbits.UTXBF == 0 )
  {
      switch ( uartState )
      {
          case STATE_SENDING_HEADER:
              UpdateTxData ( cmdIndex );
              data = HEADER;
              drv_SendU1TxData ( data );
              checksum = data;
              uartState ++;
              break;
          case STATE_SENDING_STATUS:
              drv_SendU1TxData ( Uart.U1.Tx.status.Val );
              checksum += Uart.U1.Tx.status.Val;
              uartState ++;
              break;
          case STATE_SENDING_CMD:
              drv_SendU1TxData ( cmdIndex );
              checksum += cmdIndex;
              uartState ++;
              break;
          case STATE_SENDING_LB:
              drv_SendU1TxData ( Uart.U1.Tx.cmd[cmdIndex].byte.LB );
              checksum += Uart.U1.Tx.cmd[cmdIndex].byte.LB;
              uartState ++;
              break;
          case STATE_SENDING_HB:
              drv_SendU1TxData ( Uart.U1.Tx.cmd[cmdIndex].byte.HB );
              checksum += Uart.U1.Tx.cmd[cmdIndex].byte.HB;
              uartState ++;
              break;
          case STATE_SENDING_CS:  
              checksum = ~ checksum + 1;                                                  //calc 2's complement
              drv_SendU1TxData ( checksum );          
              cmdIndex ++;                                                                             //next cmd
              if ( cmdIndex >= TOTAL_TX_CMD_NUMBER )
              {
                  cmdIndex = CMD_IOUT;	                                                   //the first tx cmd
              }    
              uartState = STATE_SENDING_HEADER;                             //reset tx state
              break;
          default: 
              break;
      }
  }

}

#ifdef NOused_SCI
/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static void UpdateSCIBuffer ( BYTE data )
{
  static BYTE count = 0;

  gPmbusCmd.SCI[count] = data;

  count ++;
  if ( count >= ( sizeof (gPmbusCmd.SCI ) ) )
  {
      count = 0;
  }
}
#endif


/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
	
void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _U1RXInterrupt ( )
{
  static BYTE RXState = STATE_RX_HEADER;
  static UART_FROM_PRI_RECVDATA RecvData = { 0 };
  static BYTE CheckSum = 0;
  static BYTE header = HEADER;
  static BYTE u1err2_cnt = 0;
  volatile BYTE RecvByte;

  Protect.u1WDT.Flag = 0;		
  Protect.u1WDT.delay = 0;	
  PS.Uart1Error = 0;           

  RecvByte = U1RXREG;

  switch ( RXState )
  {
      case STATE_RX_HEADER:
      {
          if ( RecvByte == header )
          {
              RXState = STATE_RX_STATUS;
          }
          else
          {
              RXState = STATE_RX_HEADER;
          }
          /*Reset values*/
          CheckSum = 0;
      }
          break;

      case STATE_RX_STATUS:
      {
          RXState = STATE_RX_CMD;
          RecvData.Status = RecvByte;
      }
          break;
      case STATE_RX_CMD:
      {
          RXState = STATE_RX_LB;
          RecvData.Cmd = RecvByte;
      }
          break;
      case STATE_RX_LB:
      {
          RXState = STATE_RX_HB;
          RecvData.Data.byte.LB = RecvByte;
      }
          break;

      case STATE_RX_HB:
      {
          RXState = STATE_RX_CS;
          RecvData.Data.byte.HB = RecvByte;
      }
          break;

      case STATE_RX_CS:
      {
          RXState = STATE_RX_HEADER;
          CheckSum = ( ~ CheckSum ) + 1; // 2's complement
          if ( CheckSum == RecvByte )
          {
              UpdatePrimaryData ( &RecvData );
              u1err2_cnt = 0;
          }
          else
          {
              u1err2_cnt ++;
              if ( u1err2_cnt >= MAX_COMM_ERR_COUNT )
              {
                  MFR_Status.bits.SCI_P2S_FAIL = 1;    
              }
          }
      }
          break;
  }
  CheckSum += RecvByte;
  IFS0bits.U1RXIF = 0;
}

/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
 void CalcIinAvg ( )
{
 // static WORD IinBuf[IIN_BUF_SIZE];
 // static BYTE index = 0;
 // static DWORD IinSum = 0;
  WORD Iin;

#if 1	// removed for faster average

  static DWORD Iin_LPF = 0;
  static WORD Iin_AVG = 0;

  Iin = ( Uart.U1.Rx.IacMsb << 8 ) | Uart.U1.Rx.IacLsb;
  Iin = ( WORD ) ( LinearFmt_YtoX ( Iin, IIN_GAIN ) );	      //Gain by 1024, translate to real world value
  Iin_LPF = ( ( Iin_LPF + Iin ) - Iin_AVG );
  Iin_AVG = ( Iin_LPF >> 8 );
  Uart.U1.Rx.IinAvg = Iin_AVG;
#endif

}
/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
void CalcPinAvg ( )
{

  WORD Pin;
#ifdef cips

  static DWORD Pin_LPF = 0;
  static WORD Pin_AVG = 0;

  Pin = ( ( Uart.U1.Rx.PinMsb << 8 ) + Uart.U1.Rx.PinLsb );
  Pin = ( WORD ) ( LinearFmt_YtoX ( Pin, PIN_GAIN ) );
  Pin_LPF = ( ( Pin_LPF + Pin ) - Pin_AVG );
  Pin_AVG = ( Pin_LPF >> 8 );
  Uart.U1.Rx.PinAvg = Pin_AVG;
#endif

#ifdef  WithTeridian
  Pin = ( ( Uart.U1.Rx.PinMsb << 8 ) + Uart.U1.Rx.PinLsb );
  Pin = ( WORD ) ( LinearFmt_YtoX ( Pin, PIN_GAIN ) );
  Uart.U1.Rx.PinAvg = GetAvg ( PinBuf, Pin, &index, PIN_BUF_SIZE, &PinSum, PIN_BUF_EXP );
#endif

}
/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
void UpdateInputInfo ( )
{
  CalcIinAvg ( );
  CalcPinAvg ( );
}

