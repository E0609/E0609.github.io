/*****************************************************************************************
 *
 *Copyright (C) 2021 CIPS Singapore

 *                   LITE-ON TECHNOLOGY Corp.
 *
 *All Rights Reserved
 *
 *File Name : Fan.c
 *
 *Date : 2021.01.20
 *
 *Author :              WH
 *
 *Description :This Program used for 600W Fan Control Program.
 *
 *******************************************************************************************/
#include  "p33EP64GS504.h"
#include "Fan.h"
#include "Isr.h"
#include "Process.h"
#include "I2c.h"
#include "Parameter.h"
#include "Protection.h"

#include "init.h"

#define FAN_PWM_INVERSED	FALSE

#define FULL_LOAD	50   //200
#define IOUT_LOAD_PERCENT(p) (WORD)(((DWORD)p * FULL_LOAD / 100 * IOUT_TO_ADC) >> 10)

#define IOUT_7A ((WORD)7*IOUT_TO_ADC) >> 10
#define IOUT_A_min_duty_1    ((WORD)6*IOUT_TO_ADC) >> 10      // 50 * 12% load   =6A    //600/(12*1.05)=47A

#define IOUT_10A ((WORD)10*IOUT_TO_ADC) >> 10

#define GetDuty(rpm) ((DWORD)rpm * FAN_PWM_PERIOD) / FAN_MAX_RPM
#define SetDuty(percent) ((DWORD)percent * FAN_PWM_PERIOD) / 100


// the below will be changed based on real IC  testing
WORD FanDuty_Table[3][10] = {

    // when Tinlet>40, 15%,25%,35%load fan duty changed.
    #if ConfigDD_SlaveSW
    {SetDuty ( 50 ), SetDuty ( 15 ), SetDuty ( 30 ), SetDuty ( 34 ), SetDuty ( 36 ), SetDuty ( 41 ), SetDuty ( 50 ), SetDuty ( 58 ), SetDuty ( 69 ), SetDuty ( 80 ) },	// 25C
    {SetDuty ( 50 ), SetDuty ( 26 ), SetDuty ( 30 ), SetDuty ( 36 ), SetDuty ( 47 ), SetDuty ( 58 ), SetDuty ( 70 ), SetDuty ( 81 ), SetDuty ( 91 ), SetDuty ( 100 ) },	// 35C
    {SetDuty ( 75 ), SetDuty ( 25 ), SetDuty ( 30 ), SetDuty ( 38 ), SetDuty ( 58 ), SetDuty ( 68 ), SetDuty ( 78 ), SetDuty ( 92 ), SetDuty ( 100 ), SetDuty ( 100 ) },	// 55C
   
    #endif
};

WORD FanDuty_Table2[3][10] = {
    #if ConfigDD_SlaveSW
    {SetDuty ( 75 ), SetDuty ( 30 ), SetDuty ( 30 ), SetDuty ( 34 ), SetDuty ( 36 ), SetDuty ( 41 ), SetDuty ( 50 ), SetDuty ( 58 ), SetDuty ( 69 ), SetDuty ( 80 ) },	// 25C
    {SetDuty ( 75 ), SetDuty ( 30 ), SetDuty ( 30 ), SetDuty ( 36 ), SetDuty ( 47 ), SetDuty ( 58 ), SetDuty ( 70 ), SetDuty ( 81 ), SetDuty ( 91 ), SetDuty ( 100 ) },	// 35C
    {SetDuty ( 75 ), SetDuty ( 34 ), SetDuty ( 41 ), SetDuty ( 49 ), SetDuty ( 58 ), SetDuty ( 68 ), SetDuty ( 78 ), SetDuty ( 92 ), SetDuty ( 100 ), SetDuty ( 100 ) },	// 55C

    #endif
};



//--------------- Global variable -------------------------------------------------------------
unsigned int Duty_Gain = 0;
tFAN_CNTL gFan1;
tFAN_CNTL gFan2;

//--------------- Extern variable -------------------------------------------------------------
extern tPSU_STATE gPS_State;
extern tPS_FLAG PS;

//---------------Function declare--------------------------------------------------------------

void drv_SetFanDuty ( WORD duty );

//-------------------------------------------------------------------------------------------

void init_Fan ( )
{
  //Fan A Speed Monitor with input capture
  IC1CON1 = 0;
  // the fist byte 3=  each rising edge capture and enable ;2nd byte 2 = generate interrupt via 2 times capture
  // the 3rd byte 0 = timer3 as ICx clock source the 4 th byte 0=working as idle status
  IC1CON1 = 0x0023;
#if cips // explain the above
  IC1CON1bits.ICM = 3;
  IC1CON1bits.ICBNE = 0;
  IC1CON1bits.ICOV = 0;
   IC1CON1bits.ICI = 2;
  IC1CON1bits.ICTSEL= 0; 
   IC1CON1bits.ICSIDL= 0; 
#endif
   
  IFS0bits.IC1IF = 0;
  IPC0bits.IC1IP = 2;      // low priority 
  IEC0bits.IC1IE = 1;

  //Fan A Control WITH PWM1H
  IOCON1bits.PENL = 1;			
  IOCON1bits.PMOD = 3;	           // True Independent Output mode
  PWMCON1bits.DTC = 2;		//Dead time function is disabled
  PWMCON1bits.ITB = 1;			//PHASEx/SPHASEx registers provide time base period for this PWM generator
  FCLCON1bits.FLTMOD = 3;               // Disable fault input 
  
  PWM_FAN_Period = FAN_PWM_PERIOD;
  //drv_SetFanDuty(FAN_PWM_DEFAULT_DUTY);
  drv_SetFanDuty ( 0 );
}
/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void CheckICAOV ( )
{
  WORD tempbuf;
  if ( IC1CON1bits.ICOV == 1 )
  {
      tempbuf = IC1BUF;
      tempbuf = IC1BUF;
      tempbuf = IC1BUF;
      tempbuf = IC1BUF;
  }
}

/*********************************************************************************************
------- Corresponding timer 3 is 200 us
------- Input Capture module will capture the counter every 4th raising edge to ICxBuf
------- 1sec -> 5000 count of 200us, 60sec -> 300000 count of 200us
------- Since the time taken by every 4 raising edge represent the time spent of every 2 rpm
------- So that, we should divide the time of (Rpm_Capture2 - Rpm_Capture1) by 2 
------- for calculating how much time does it take every 1 rpm
 *  rpm=Revolutions per minute
 * 
 * //Fan_speed = Timer_Const/Fan_tmr_val
Fan_speed= fan's measure speed in RPM
 Fan_tmr_val =current Capture value- Previouse value
 Timer_const = (Timerx_clock/Timerx_Prescaler) * (60/Magnetic Pole Pairs)
     (40x1000000/256)*(60/2)= 4687500
 *********************************************************************************************/
/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
void UpdateFanSpeedA ( )
{
  WORD Rpm_Capture1, Rpm_Capture2, ErrCount;
  DWORD Fan_period;
  Rpm_Capture1 = IC1BUF;
  Rpm_Capture2 = IC1BUF;

  if ( Rpm_Capture2 > Rpm_Capture1 )
  {
      ErrCount = Rpm_Capture2 - Rpm_Capture1;
  }
  else
  {
      ErrCount = 65535 - Rpm_Capture1 + Rpm_Capture2; 
  }

  Fan_period = ErrCount << 1;

    gFan1.CurrentRpm= ( WORD ) ( ( QWORD ) 4687500 * 2 / Fan_period );	//Timer 3 prescaler is 1:256

  CheckICAOV ( );
}

/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _IC1Interrupt ( )
{
  gFan1.Detected = TRUE;

  UpdateFanSpeedA ( );

  IFS0bits.IC1IF = 0;
}


/************************************************************************
 * author:                     WH
 * description:             drv_SetFanDuty
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void drv_SetFanDuty ( WORD duty )
{
#if FAN_PWM_INVERSED
  PWM_FAN_duty = ( ( WORD ) FAN_PWM_PERIOD - duty );
#else
  PWM_FAN_duty  = duty;
#endif
}

//--------------------------- drv_FanSoftAdjust  -------------------------------------------------
/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static void drv_FanSoftAdjust ( )
{
  if ( PS.FanDutyCtrl )
  {
      PS.FanDutyCtrl = 0;
      if ( PWM_FAN_duty < gFan1.TargetDuty )
      {
          //SDC4 = SDC4 + 5;
          PWM_FAN_duty += 5;
      }
      else if ( PWM_FAN_duty > gFan1.TargetDuty )
      {
          PWM_FAN_duty -= 1;
      }

  }
  else
  {
      Protect.FanDutyCtrl.Flag = 1;
  }
}
/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

//----------------------------- LoadHysteresis ----- --------------------------------------
 BYTE    LoadHysteresis()
{
    WORD Adc_Io = ADC.Iout_Cal;
    static BYTE LoadCounter = 0;

    if ( Adc_Io < IOUT_LOAD_PERCENT ( 15 ) )                                                        
    {
        if ( ( Adc_Io > IOUT_LOAD_PERCENT ( 12 ) ) && ( LoadCounter == 1 ) )       //load_cnt = 0+1,  
            return  LoadCounter;
        LoadCounter = 0;
    }
    else if ( ( Adc_Io >= IOUT_LOAD_PERCENT ( 15 ) ) && ( Adc_Io < IOUT_LOAD_PERCENT ( 25 ) ) )     
    {
        if ( ( Adc_Io > IOUT_LOAD_PERCENT ( 22 ) ) && ( LoadCounter == 2 ) )       //load_cnt = 1+1,  
            return  LoadCounter;
        LoadCounter = 1;
    }
    else if ( ( Adc_Io >= IOUT_LOAD_PERCENT ( 25 ) ) && ( Adc_Io < IOUT_LOAD_PERCENT ( 35 ) ) )     
    {
        if ( ( Adc_Io > IOUT_LOAD_PERCENT ( 32 ) ) && ( LoadCounter == 3 ) )       //load_cnt = 2+1,  
            return  LoadCounter;
        LoadCounter = 2;
    }
    else if ( ( Adc_Io >= IOUT_LOAD_PERCENT ( 35 ) ) && ( Adc_Io < IOUT_LOAD_PERCENT ( 45 ) ) )     
    {
        if ( ( Adc_Io > IOUT_LOAD_PERCENT ( 42 ) ) && ( LoadCounter == 4 ) )       //load_cnt = 3+1,  
            return  LoadCounter;
        LoadCounter = 3;
    }
    else if ( ( Adc_Io >= IOUT_LOAD_PERCENT ( 45 ) ) && ( Adc_Io < IOUT_LOAD_PERCENT ( 55 ) ) )     
    {
        if ( ( Adc_Io > IOUT_LOAD_PERCENT ( 52 ) ) && ( LoadCounter == 5 ) )       //load_cnt = 4+1,  
            return  LoadCounter;
        LoadCounter = 4;
    }
    else if ( ( Adc_Io >= IOUT_LOAD_PERCENT ( 55 ) ) && ( Adc_Io < IOUT_LOAD_PERCENT ( 65 ) ) )     
    {
        if ( ( Adc_Io > IOUT_LOAD_PERCENT ( 62 ) ) && ( LoadCounter == 6 ) )       //load_cnt = 5+1,  
            return  LoadCounter;
        LoadCounter = 5;
    }
    else if ( ( Adc_Io >= IOUT_LOAD_PERCENT ( 65 ) ) && ( Adc_Io < IOUT_LOAD_PERCENT ( 75 ) ) )     
    {
        if ( ( Adc_Io > IOUT_LOAD_PERCENT ( 72 ) ) && ( LoadCounter == 7 ) )       //load_cnt = 6+1,  
            return  LoadCounter;
        LoadCounter = 6;
    }
    else if ( ( Adc_Io >= IOUT_LOAD_PERCENT ( 75 ) ) && ( Adc_Io < IOUT_LOAD_PERCENT ( 85 ) ) )     
    {
        if ( ( Adc_Io > IOUT_LOAD_PERCENT ( 82 ) ) && ( LoadCounter == 8 ) )       //load_cnt = 7+1,  
            return  LoadCounter;
        LoadCounter = 7;
    }
    else if ( ( Adc_Io >= IOUT_LOAD_PERCENT ( 85 ) ) && ( Adc_Io < IOUT_LOAD_PERCENT ( 95 ) ) )     
    {
        if ( ( Adc_Io > IOUT_LOAD_PERCENT ( 92 ) ) && ( LoadCounter == 9 ) )       //load_cnt = 8+1,  
            return  LoadCounter;
        LoadCounter = 8;
    }
    else if ( Adc_Io >= IOUT_LOAD_PERCENT ( 95 ) )
    {
      LoadCounter = 9;
    }

    return  LoadCounter;

}
/************************************************************************
 * author:                     WH
 * description:            TempHysteresis 
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

 BYTE    TempHysteresis()
{
    static BYTE TempCounter = 0;
    //Give a default temp_cnt

    if ( T_Inlet < 30 )
    {
        if ( ( T_Inlet > 27 ) && ( TempCounter == 1 ) )       //temp_cnt = 0+1,  
            return  TempCounter;
      TempCounter = 0;
    }
    else if ( T_Inlet >= 30 && T_Inlet < 40 )                                   
    {
        if ( ( T_Inlet > 37 ) && ( TempCounter == 2 ) )       //temp_cnt = 1+1,  
            return  TempCounter;
        TempCounter = 1;
    }
    else if ( T_Inlet >= 40 )
    {
        TempCounter = 2;
    }

    return  TempCounter;
}
/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

//----------------------------- GetFanMinDuty ----- --------------------------------------
WORD GetFanMinDuty ( )
{
  //WORD Adc_Io = ADC.Iout_Cal;         
  static BYTE load_cnt = 0;
  static BYTE temp_cnt = 0;
  static WORD minduty = SetDuty ( 75 );
         
    load_cnt = LoadHysteresis();
    temp_cnt = TempHysteresis();    
     
    #if ConfigDD_SlaveSW
	minduty = FanDuty_Table[temp_cnt][load_cnt];  
    #else
    if ( Adc_Io <= IOUT_7A )
    {
      minduty = SetDuty ( 75 );
    }
    else if ( Adc_Io >= IOUT_10A )
    {
      minduty = FanDuty_Table[temp_cnt][load_cnt];
    }
    #endif
   
  return minduty;

}
/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
//----------------------------- Fan_MinimumDuty_Modify ----- ------------------------------

void Fan_MinimumDuty_Modify ( void )
{
  WORD minDuty;

  
  minDuty = GetFanMinDuty ( );

  //20101101 added for Fan override behavior
  gFan1.minDuty = ( minDuty > gFan1.OverridedDuty ) ? minDuty : gFan1.OverridedDuty;
}
/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
//----------------------------- ConvertRatioToDuty  ------------------------------------

static WORD ConvertRatioToDuty ( BYTE ratio )
{
  WORD result;

  //mapping 0 - 100% to duty cycle 0 - 19000
  result = ( WORD ) ( ( DWORD ) FAN_PWM_PERIOD * ratio / 100 );

  return result;
}
/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
//----------------------------- CalcFanTargetSpeed  ------------------------------------

void CalcFanTargetSpeed ( BYTE ratio )
{
  WORD minDuty;
  WORD overrideDuty;
  WORD target;

  minDuty = GetFanMinDuty ( );
  overrideDuty = ConvertRatioToDuty ( ratio );
  target = minDuty;

  if ( overrideDuty > minDuty )
  {
      //Fan Override
      target = overrideDuty;
      drv_SetFanDuty ( overrideDuty );
      gFan1.TargetDuty = target;
  }
  else
  {
      drv_SetFanDuty ( minDuty );
      gFan1.TargetDuty = target;
  }

  gFan1.OverridedDuty = overrideDuty;	//
}

//--------------------------- Fan Duty Control By Load --------------------------------------
/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static void Check_Fan_Temperature()
{
           if ( T_Sec > FAN_ADJ_SEC_TEMP_H || T_Pri > FAN_ADJ_PRI_TEMP_H )
                      { 		 
	                      Protect.T_FanControl.Flag = 1;
		           if ( PS.FanControl )
				 {
					 gFan1.TargetDuty += 175;
	
					 if ( gFan1.TargetDuty >= FAN_PWM_PERIOD )
					 {
						 gFan1.TargetDuty = FAN_PWM_PERIOD;
					  }
					  PS.FanControl = 0;
				 }
			  }
			  else if ( T_Sec < FAN_ADJ_SEC_TEMP_L && T_Pri < FAN_ADJ_PRI_TEMP_L )
			  {  
				  Protect.T_FanControl.Flag = 1;
				  if ( PS.FanControl )
				  {
					  if ( gFan1.TargetDuty >= 100 )
					  {
						  gFan1.TargetDuty -= 100;
					  }
					  else
					  {
						  gFan1.TargetDuty = 0;
					  }
					  //min limit
					  Fan_MinimumDuty_Modify ( );
	
					  if ( gFan1.TargetDuty < gFan1.minDuty )
					  {
						  gFan1.TargetDuty = gFan1.minDuty;
					  }
	
					  PS.FanControl = 0;
				  }
			  }
			  else
			  {
				  Protect.T_FanControl.Flag = 0;
				  Protect.T_FanControl.delay = 0;
				   if ( ADC.Iout_Cal <= IOUT_7A )
				  {
					  gFan1.TargetDuty = SetDuty ( 75 );
					  if ( gFan1.OverridedDuty >= gFan1.TargetDuty )
					  {
						  gFan1.TargetDuty = gFan1.OverridedDuty;
					  }
					  drv_SetFanDuty ( gFan1.TargetDuty );
				  }
			  }

}
/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
void UpdateFanDuty ( )
{
  if ( PS.StartCalibrate )
  {
      gFan1.TargetDuty = ( ( DWORD ) FAN_PWM_PERIOD * 50 ) / 100;
      drv_SetFanDuty ( gFan1.TargetDuty );
      return;
  }
  
  {
      if ( gPS_State.mainState == STATE_NORMAL )
      {
          Check_Fan_Temperature();
      }
      else if ( ( gPS_State.mainState == STATE_STANDBY ) || ( gPS_State.mainState == STATE_LATCH ) )
      {
          gFan1.TargetDuty = ( ( DWORD ) FAN_PWM_PERIOD * 15 ) / 100;
      }
      else if ( gPS_State.mainState == STATE_ONING )
      {
          if ( T_Sec > 60 || T_Pri > 75 )
          {
              gFan1.TargetDuty = FAN_PWM_PERIOD;
              drv_SetFanDuty ( gFan1.TargetDuty );
          }
          else
          {
              gFan1.TargetDuty = FAN_PWM_DEFAULT_DUTY;
          }

       }

      drv_FanSoftAdjust ( );
  }
}


/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
//--------------------------- DisableFan ----------------------------------------------------------
void DisableFan ( )  // defined by WH
{
  PS.FanLock_Disable = TRUE;
  oFAN_CNTL = Fan_Disable;
}

/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void EnableFan ( )
{
  PS.FanLock_Disable = FALSE;
  oFAN_CNTL = Fan_Enable;
 
}



