/*****************************************************************************************
 *
 *Copyright (C) 2021 CIPS Singapore

 *                   LITE-ON TECHNOLOGY Corp.
 *
 *All Rights Reserved
 *
 *File Name : Timer.c
 *
 *Date : 2021.01.20
 *
 *Author :              WH
 *
 *Description :
 *
 *******************************************************************************************/
#include "Timer.h"
#include "Standby.h"
#include "Pmbus.h"
#include "Isr.h"
#include "Process.h"
#include "hbllc.h"
#include "Sci.h"

#define MAX_SYS_TIMER 8 //15    

//------------------Global Variable-----------------------------------------------------
SYS_TIMER SysTimer[MAX_SYS_TIMER];
QWORD SysTimerCount = 0;
WORD Tsb_off_delay = 0;
//BYTE isInputDetected = FALSE;// no used
BYTE Tsb_off_delay_Flag = 0;

//------------------Exported Variable-----------------------------------------------------
extern tPS_FLAG PS;
extern tLLC HBLLC;

/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static void sys_timer_setting()
{
      BYTE i;
  QWORD DiffTime;

  SysTimerCount ++;

  for ( i = 0; i < MAX_SYS_TIMER; i ++ )
  {
      if ( SysTimer[i].Active )
      {
          DiffTime = SysTimerCount - SysTimer[i].StartTime;
          if ( DiffTime == SysTimer[i].Elapse )
          {
              if ( SysTimer[i].pTimerFunc ) SysTimer[i].pTimerFunc ( );
              SysTimer[i].StartTime = SysTimerCount;
          }
      }
  }
}
/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static void l_unitOff_Blanking()
{
    static WORD UnitOffBlankingTime = 0;	// added for unit off not show issue
      if ( UnitOffBlankingTime < 5000 )
  {
      UnitOffBlankingTime ++;
  }
  else
  {
      if ( iAC_OK == AC_N_GOOD && ( ( _SD_Flag.STB_OCP == 0 ) && ( _SD_Flag.STB_OVP == 0 ) && ( _SD_Flag.STB_UVP == 0 ) ) /*&& (AcOffBlankingTime >= 5)*/ )    
      {
          if ( iPS_ON == P_N_OK )	// hbllc 
          {
                  gPagePlusStatus.PAGE[PS.isDCInput].STATUS_INPUT.bits.UNIT_OFF = 1;
                  if ( Real_Vac < Parameter.VIN_UV_WARN_LIMIT[PS.isDCInput] )
                  {
                      gPagePlusStatus.PAGE[PS.isDCInput].STATUS_INPUT.bits.VIN_UV_WARNING = 1;
                  }
                  if ( Real_Vac < Parameter.VIN_UV_FAULT_LIMIT[PS.isDCInput] )
                  {
                      gPagePlusStatus.PAGE[PS.isDCInput].STATUS_INPUT.bits.VIN_UV_FAULT = 1;
                  } 
          }
      }
  }
}

/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static void l_AC_onoff_Blanking()
{ 
 static WORD AcOffBlankingTime = 0;
static  WORD AcOnBlankingTime = 0;
   #if cips // no_needed
#else
  if ( iAC_OK == AC_N_GOOD )
  {
      AcOnBlankingTime = 0;
      if ( AcOffBlankingTime >= 60 )      //60ms
      {	
          PS.AC_OFF_ClearFault = TRUE;
      }
      else
      {
          AcOffBlankingTime ++;
      }
  }
  else
  {
      AcOffBlankingTime = 0;
      if ( AcOnBlankingTime >= 5000 )      //5000ms
      {	
          PS.AC_ON_CheckLineStatus = TRUE;
      }
      else
      {
          AcOnBlankingTime ++;
      }
  }
#endif 
    
}

/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static void l_SR_Control()
{
      /*SR control*/
  if ( HBLLC.InRegulation == TRUE )
  {
      if ( HBLLC.Counter_InRegulation < 0xFFFE )
      {
          HBLLC.Counter_InRegulation ++;
      }
  }
  else
  {
      HBLLC.Counter_InRegulation = 0;
  }

  if ( ADC.Iout_FF > cSR_ON_IOUT_REFH )
  {
      if ( HBLLC.SR_ON_Delay < 0xFFFE ) HBLLC.SR_ON_Delay ++;
  }
    
}
/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static
void m_STB_Output_Cnt()
{
 #if 1//cips
  /*Stb output control*/

   if ( iPFC_OK  == P_N_OK && iAC_OK == AC_N_GOOD )     
  {
      if ( Tsb_off_delay < 0xFFFE ) 
      {
          Tsb_off_delay ++;
      }
  }
  else
  {
      Tsb_off_delay = 0;
      Tsb_off_delay_Flag = 0;
  }

  #endif
}

/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static void m_Main_SCP_cnt()
{
    //For Main SCP
  {
      static BYTE count = 0;

      if ( PS.Softstart )
      {
          if ( count >= 3 )
          {
              PS.SC_CheckStart = 1;
          }
          else
          {
              count ++;
          }
      }
      else
      {
          PS.SC_CheckStart = 0;
      }
  }
    
}
/************************************************************************
 * author:                     WH
 * description:            T1Interrupt 
 * input:
 * output:
 * version:
 * remark:                  1ms
 * history:
 * ***********************************************************************/
//-------------------------------- T1Interrupt 1ms --------------------------------------
void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _T1Interrupt ( void )
{
// sys_timer_setting();
//  m_Main_SCP_cnt();
// Count_4AC_Cycle ( );                                 // should be the same priority with the uart data updating
//  if ( ADC.StbVout_FF > cSTB_OK_REFH && STB.Enabled )
//  {
//      if ( STB.Counter_InRegulation < 0xFFFE ) STB.Counter_InRegulation ++;
//  }
//l_unitOff_Blanking();
//l_AC_onoff_Blanking();
// l_SR_Control();
//m_STB_Output_Cnt();

// _TRISB14 = 0;//;
//_LATB14  ^= 1;
_LATB11  ^= 1;
  IFS0bits.T1IF = 0;
}



void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _T2Interrupt ( void )
{

// _TRISB14 = 0;//;
//_LATB14  ^= 1;
  IFS0bits.T2IF = 0;
}
/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
//-------------------------------- SetTimer ms--------------------------------------

BYTE SetTimer ( WORD Elapse, _Pfn pTimerFunc )
{
  BYTE i;

  if ( Elapse == 0 )
  {
      if ( pTimerFunc != NULL )
      {
          pTimerFunc ( );
      }
  }
  else
  {
      for ( i = 0; i < MAX_SYS_TIMER; i ++ )
      {
          if ( SysTimer[i].Active == 0 )
          {
              SysTimer[i].Active = 1;
              SysTimer[i].pTimerFunc = pTimerFunc;
              SysTimer[i].Elapse = Elapse;
              SysTimer[i].StartTime = SysTimerCount;
              return i + 1;
          }
      }
  }
  return 0;
}

/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
//-------------------------------- RestartTimer --------------------------------------

void RestartTimer ( BYTE *pTimerID )
{
  if ( *pTimerID <= 0 || * pTimerID > MAX_SYS_TIMER ) return;

  if ( SysTimer[*pTimerID - 1].Active == 0 ) return;

  SysTimer[*pTimerID - 1].StartTime = SysTimerCount;
}


/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
//-------------------------------- KillTimer ms --------------------------------------

void KillTimer ( BYTE *pTimerID )
{
  if ( *pTimerID <= 0 || * pTimerID > MAX_SYS_TIMER ) return;

  SysTimer[*pTimerID - 1].Active = 0;

  *pTimerID = 0;
}





