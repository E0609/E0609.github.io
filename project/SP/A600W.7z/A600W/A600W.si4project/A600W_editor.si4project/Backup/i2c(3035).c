
#include "p33Exxxx.h"
#include "p33EP64GS504.h"     // cips
#include "define.h"
#include "dsp.h"

#include "pec.h"
#include "I2C.h"
#include "Pmbus.h"
#include "UserData.h"
#include "Query.h"
#include "Protection.h"
#include "Process.h"
#include <string.h>

//#define MajorRev_MinorRev	0x2000

//Add Begin ->
BYTE gSlaveAddrW = 0x00;
BYTE gSlaveAddrR = 0x00;

tD_I2C_DATA I2C;
static BYTE gDataLength = 0;

extern tPSU_STATE gPS_State;
extern tPS_FLAG PS;

BYTE OneTimeFlag_HotPlug ;    


/// edwin



static BYTE ADDR[16] = {
                       0xB0,	// Reserved     // fix HW.
                        0xB0, 	// J1
                        0x00,	// Reserved
                        0xB2,	// J2
                        0x00,	// Reserved
                        0xB4,	// J3
                        0x00,	// Reserved
                        0xB6,	// J4
                        0x00,	// Reserved
                        0xB8,	// J5
                        0x00,	// Reserved
                        0xBA,	// J6
                        0x00,	// Reserved
                        0xBC,	// J7
                        0x00,	// Reserved
                        0xBE,	// J8
};


/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

//Add End < -

static void init_I2cStruct ( )
{
  I2C.cmdDir = CMD_R;
  I2C.dataIndex = 0;
  I2C.pRxBuf = NULL;
  I2C.pTxBuf = NULL;
  I2C.state = STATE_WAIT_FOR_CMD;
  I2C.isPecFail = FALSE;
  I2C.currentCmd = 0x00;
  I2C.isBlockMode = FALSE;
  I2C.accessNotAllow = FALSE; 
  I2C.PermitToWrite = FALSE;

  memset ( I2C.readBuffer, 0, sizeof (I2C.readBuffer ) );
  I2C.pRxBuf = I2C.readBuffer;
  I2C.PEC = 0;

  gDataLength = 0;
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void init_I2C ( void )
{
#if 1 //Edwin tentatively
  I2C1CONL = 0;   
 I2C1CONH = 0; 
 
 // FJ> I2C1CON    0206        I2CEN          ?         I2CSIDL    SCLREL     IPMIEN       A10M      DISSLW       SMEN         GCEN        STREN       ACKDT      ACKEN       RCEN          PEN          RSEN         SEN
 //FJ>>  I2C1CON = 0xB340;   10110011    0100 0000 
  
 /** EP
  * I2C1CONL
  * I2CEN           ?         I2CSIDL    SCLREL   STRICT      A10M      DISSLW      SMEN       GCEN       STREN       ACKDT       ACKEN        RCEN           PEN           RSEN         SEN*/
  
   I2C1CONLbits.I2CEN=1;  // enable bit
   I2C1CONLbits.DISSLW =1;
   I2C1CONLbits.SMEN=1;
   I2C1CONLbits.SCLREL=0;     //  Edwin added
   I2C1CONLbits.STREN =1;
    I2C1CONLbits.A10M =0;
    
 /**I2C1CONH 
  * ?               ?              ?              ?             ?             ?              ?              ?              ?             PCIE          SCIE          BOEN        SDAHT       SBCDE        AHEN        DHEN */
 I2C1CONHbits.AHEN=1;
I2C1CONHbits.DHEN=1;
I2C1CONHbits.SCIE=1;
I2C1CONHbits.PCIE=1;
I2C1BRG=396;                        /* Edwin:  when Fcy =40Mhz, so that Fscl = 100Khz */

#endif
_SI2C1IF = 0;
_SI2C1IP = 4;
_SI2C1IE = 1;
  init_I2cStruct ( );
  PS.I2C_Processing = FALSE;
  
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void GetI2cAddr ( )
{
  BYTE addr = 0x00;
  BYTE pin = 0x00;
  
  pin = ( iADDR0 << 3 ) | ( iADDR1<< 2 ) | ( iADDR2 << 1 ) ;
  addr = ADDR[pin];
  
  /*   I2CxADD : The I2CxADD register holds the slave address.   */
  I2C1ADD = addr >> 1; // BE>>1 =5F
  if ( OneTimeFlag_HotPlug == 1 )
  {                                         
      if ( ( I2C1ADD == 0x5E ) ||  ( I2C1ADD == 0x5F ) )          //      PSON Signal Enable/disable
      {
          PS.MFR_PSON_CONTROL = TRUE;                                                            
      }
      OneTimeFlag_HotPlug = 0;
  }

  gPmbusCmd.MFR_PSON_CONTROL[0] = PS.MFR_PSON_CONTROL;                          // addr pin debounce isse. removed
  gSlaveAddrW = addr;
  gSlaveAddrR = addr + 1;
}

//Add Begin ->
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static void drv_Transmit_byte ( BYTE data )
{
  do
  {
      asm("clrwdt" ); //clear WDT
      //delay
      asm volatile("repeat #40" ); //Delay 10us

      I2C1STATbits.IWCOL = 0;
      I2C1TRN = data;
  }
  while ( I2C1STATbits.IWCOL );
}


/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/


void HoldSCL ( )
{
  I2C1CONLbits.SCLREL = 0;
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void ReleaseSCL ( )
{
  I2C1CONLbits.SCLREL = 1;
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void CheckI2COV ( )  // I2COV overflow
{

  if ( I2C1STATbits.I2COV )
  {
      I2C1STATbits.I2COV = 0;                      // modified for buffer overflow issue.
  }
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static BYTE Get_BW_DataLen ( BYTE cmd )
{
  BYTE byte_cnt;

  switch ( cmd )
  {
      case cmd_no_PAGE_PLUS_WRITE:	
          byte_cnt = 4;
          break;
      case cmd_no_PAGE_PLUS_READ:	
          byte_cnt = 3;
          break;
      case cmd_Query:	//QUERY
          byte_cnt = 2;
          break;
      case cmd_no_COEFFICIENTS:	
          byte_cnt = 3;
          break;
      case cmd_no_GEN_CAL_R:	
          byte_cnt = 7;
          break;
      default:
          byte_cnt = 0;
          break;
  }

  return byte_cnt;

}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static BYTE Is_BlockMode_Valid(BYTE cmd)
{
    switch(cmd)
    {
        case cmd_no_PAGE_PLUS_WRITE: 
        case cmd_no_PAGE_PLUS_READ: 
        case cmd_Query: //QUERY
        case  cmd_no_SMBALERT_MASK: 
        case cmd_no_COEFFICIENTS: 
        //case 0xE7: //BMC_UNIX_TIMESTAMP    
        case cmd_no_GEN_CAL_R: 
            return TRUE;

        default:
            return FALSE;

    }
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static BYTE m_IsDataContent_Valid ( BYTE cmd )
{
#define m_StatusCmd_InValid(x)     I2C.readBuffer[x] != cmd_STATUS_WORD &&  I2C.readBuffer[x] != cmd_STATUS_VOUT &&  I2C.readBuffer[x] != cmd_STATUS_IOUT &&  I2C.readBuffer[x] != cmd_STATUS_INPUT &&  I2C.readBuffer[x] != cmd_STATUS_TEMPERATURE &&  I2C.readBuffer[x] != cmd_STATUS_CML 
#define m_StatusCmd_InValid_1(x)       I2C.readBuffer[x] != cmd_STATUS_VOUT &&  I2C.readBuffer[x] != cmd_STATUS_IOUT &&  I2C.readBuffer[x] != cmd_STATUS_INPUT &&  I2C.readBuffer[x] != cmd_STATUS_TEMPERATURE &&  I2C.readBuffer[x] != cmd_STATUS_CML 

#define write_byte_count_error   ( I2C.readBuffer[0] != 0x03 && I2C.readBuffer[0] != 0x04 )
#define read_byte_count_error   ( I2C.readBuffer[0] != 0x03 && I2C.readBuffer[0] != 0x02 )
#define page_error    ( I2C.readBuffer[1] != 0x00 && I2C.readBuffer[1] != 0x01 )
    
    switch ( cmd )
  {
      case cmd_no_PAGE_PLUS_WRITE:	
          if( write_byte_count_error  || page_error )   
          {
              return FALSE;
          }	
           if (( I2C.readBuffer[0] == 0x03 ) || ( I2C.readBuffer[0] == 0x04 ) )
           {
               if (m_StatusCmd_InValid(I2C.readBuffer[0]-1) )
               {
                   return FALSE;
               }
           }
          return TRUE;
      case cmd_no_PAGE_PLUS_READ:	         
            if( read_byte_count_error  || page_error )   
          {
              return FALSE;
          }
          if ( I2C.readBuffer[0] == 0x02 )
          {
              if (m_StatusCmd_InValid(2))
               {
                   return FALSE;
               }
          }
          if ( I2C.readBuffer[0] == 0x03 )
          {
                if (m_StatusCmd_InValid_1(3))
                {
                   return FALSE;
                }
          }
          return TRUE;
      case cmd_Query:	
          if ( I2C.readBuffer[0] != 0x01 )  //byte count
          {
              return FALSE;
          }	
          return TRUE;

      case cmd_no_SMBALERT_MASK:	
          return TRUE;        
      case cmd_no_COEFFICIENTS:	
          if ( I2C.readBuffer[0] != 0x02 )  //byte count
          {
              return FALSE;
          }	
          if ( I2C.readBuffer[1] != cmd_no_READ_EIN && I2C.readBuffer[1] != 0x87 )
          {
              return FALSE;
          }	//Direct format command
          if ( I2C.readBuffer[2] != 0x00 && I2C.readBuffer[2] != 0x01 )
          {
              return FALSE;
          }	
          return TRUE;  
      case cmd_no_GEN_CAL_R:	
          return TRUE;
  }

  return FALSE;
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static BYTE AnyErrorInBlockMode()
{
 #define DataLenError    ( I2C.dataIndex != gDataLength ) && ( I2C.dataIndex != gDataLength + 1 )
         if ( I2C.isBlockMode )
          {
              if ( DataLenError  )
              {
                  gPagePlusStatus.PAGE[gPmbusCmd.PAGE[0]].STATUS_CML.bits.INVALID_DATA = 1;
                  return TRUE;
              }
              else
              {
                   if ( !m_IsDataContent_Valid ( I2C.currentCmd ) )
                  {
                      gPagePlusStatus.PAGE[gPmbusCmd.PAGE[0]].STATUS_CML.bits.INVALID_DATA = 1;
                      return TRUE;
                  }
              }
          }
        else
          {
              if ( ! gIsFactoryMode )
              {
                  if ( DataLenError  )
                  {
                      gPagePlusStatus.PAGE[gPmbusCmd.PAGE[0]].STATUS_CML.bits.INVALID_DATA = 1;
                      return TRUE;
                  }
              }
          }
       if (( ( ( tQuery ) gCmd[I2C.currentCmd].type ).bits.SupportWrite == 0 ) ||( I2C.isPecFail || I2C.accessNotAllow )
)          {
              return TRUE;
          }

           return FALSE;
}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static BYTE IsWriteProtect()
{
  #if cips
              if ( gPmbusCmd.WRITE_PROTECT[0] == 0x80 )    // cips
              {
                  if ( I2C.currentCmd != 0x10 && I2C.currentCmd != 0xC9 )
                  {
                      gPagePlusStatus.PAGE[gPmbusCmd.PAGE[0]].STATUS_CML.bits.INVALID_CMD = 1;
                      return TRUE;
                  }
              }
              else if ( gPmbusCmd.WRITE_PROTECT[0] == 0x40 )
              {
                  if ( I2C.currentCmd != 0x10 && I2C.currentCmd != 0x01 && I2C.currentCmd != 0x00 && I2C.currentCmd != 0xC9 )
                  {
                      gPagePlusStatus.PAGE[PAGE0].STATUS_CML.bits.INVALID_CMD = 1;
                      gPagePlusStatus.PAGE[PAGE1].STATUS_CML.bits.INVALID_CMD = 1;
                      return TRUE;
                  }
              }
              else if ( gPmbusCmd.WRITE_PROTECT[0] == 0x20 )
              {
                  if ( I2C.currentCmd != 0x10 && I2C.currentCmd != 0x01 && I2C.currentCmd != 0x00 &&
                       I2C.currentCmd != 0x02 && I2C.currentCmd != 0x21 && I2C.currentCmd != 0xC9 )
                  {
                      gPagePlusStatus.PAGE[PAGE0].STATUS_CML.bits.INVALID_CMD = 1;
                      gPagePlusStatus.PAGE[PAGE1].STATUS_CML.bits.INVALID_CMD = 1;
                      return TRUE;
                  }
              }
              else if ( gPmbusCmd.WRITE_PROTECT[0] == 0x00 )
              {
                  //Enable write commands
              }
              else
              {
                  gPagePlusStatus.PAGE[gPmbusCmd.PAGE[0]].STATUS_CML.bits.INVALID_CMD = 1;
                  return TRUE;
              
              }
#else
           switch (gPmbusCmd.WRITE_PROTECT[0] )
           {

               case 0x20:
                      if ( I2C.currentCmd != 0x10 && I2C.currentCmd != 0x01 && I2C.currentCmd != 0x00 &&
                       I2C.currentCmd != 0x02 && I2C.currentCmd != 0x21 && I2C.currentCmd != 0xC9 )
                      {
                      gPagePlusStatus.PAGE[PAGE0].STATUS_CML.bits.INVALID_CMD = 1;
                      gPagePlusStatus.PAGE[PAGE1].STATUS_CML.bits.INVALID_CMD = 1;
                      return TRUE;
                      }
                      break;
               case 0x40:
                   if ( I2C.currentCmd != 0x10 && I2C.currentCmd != 0x01 && I2C.currentCmd != 0x00 && I2C.currentCmd != 0xC9 )
                     {
                      gPagePlusStatus.PAGE[PAGE0].STATUS_CML.bits.INVALID_CMD = 1;
                      gPagePlusStatus.PAGE[PAGE1].STATUS_CML.bits.INVALID_CMD = 1;
                      return TRUE;
                     }
                      break;
               case 0x80:         
                    if ( I2C.currentCmd != 0x10 && I2C.currentCmd != 0xC9 )
                      {
                      gPagePlusStatus.PAGE[gPmbusCmd.PAGE[0]].STATUS_CML.bits.INVALID_CMD = 1;
                      return TRUE;
                      }
                      break;
               case 0:
                   return FALSE;                     
               default:
                  gPagePlusStatus.PAGE[gPmbusCmd.PAGE[0]].STATUS_CML.bits.INVALID_CMD = 1;
                  return TRUE;
           }			 
   #endif
       return FALSE;
}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _T4Interrupt ( void )  //event trigger
{
  /*Execute I2C command P received*/
  if ( I2C1STATbits.P )
  {

      if ( I2C.cmdDir == CMD_W && I2C.PermitToWrite == TRUE )
      	{
          if ( ! gIsFactoryMode )
          {
            if (IsWriteProtect()) goto SKIP;
          }
          if(AnyErrorInBlockMode()) goto SKIP;

          HoldSCL ( );
          Task_WiteCmd ( );	//execute write cmd here
          ReleaseSCL ( );
      }
  }
SKIP:
  IFS1bits.T4IF = 0;
}


/************************************************************************
 * author:                     Edwin            Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
 

BYTE Temp;
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static void Address_matched()
{
     //Initialization
    //  Temp = I2C1RCV;

      init_I2cStruct ( );

      CalcPEC ( &I2C.PEC, gSlaveAddrW );
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static void Ein_Eout_handler()
{
     if ( ! PS.EIN_DataUpdating && PS.EIN_DataUpdated )
              {
                  PS.EIN_DataUpdated = 0;
                  memcpy ( gPmbusCmd.READ_EIN_TEMP, gPmbusCmd.READ_EIN, 7 );
              }

              if ( ! PS.EOUT_DataUpdating && PS.EOUT_DataUpdated )
              {
                  PS.EOUT_DataUpdated = 0;
                  memcpy ( gPmbusCmd.READ_EOUT_TEMP, gPmbusCmd.READ_EOUT, 7 );
              }

              if ( I2C.currentCmd == cmd_no_READ_EIN )
              {
                  if ( PS.EIN_DataUpdating )
                  {
                      I2C.pTxBuf = gPmbusCmd.READ_EIN_TEMP;
                  }
                  else
                  {
                      I2C.pTxBuf = gPmbusCmd.READ_EIN;
                  }
              }
              if ( I2C.currentCmd == 0x87 )
              {
                  if ( PS.EOUT_DataUpdating )
                  {
                      I2C.pTxBuf = gPmbusCmd.READ_EOUT_TEMP;
                  }
                  else
                  {
                      I2C.pTxBuf = gPmbusCmd.READ_EOUT;
                  }
              }

}

static void Retrieve_DataLen_in_BlockMode(BYTE i )
{
#ifdef otimization
     if ( I2C.currentCmd ==  cmd_no_SMBALERT_MASK )
                  {
                      //Exception for  cmd_no_SMBALERT_MASK SMBALERT_MASK
                      //(support Write Word & BlockWrite-BlockRead at the same time)
                      if ( i == 1 )
                      {
                          gDataLength = 2;	//BlockWrite-BlockRead mode, (block count byte + Status_x command code byte)
                      }
                      else
                      {
                          gDataLength = gCmd[I2C.currentCmd].Len;	//Write word mode
                      }
                  }
                  else if ( I2C.currentCmd == cmd_no_PAGE_PLUS_WRITE )
                  {
                      //20111005 add exception for PAGE_PLUS_WRITE SMBALERT_MASK
                      if (i == 3 )
                      {
                          gDataLength = 4;
                      }
                      else if ( i == 4 )
                      {
                          gDataLength = 5;
                      }
                      else
                      {
                          gDataLength = gCmd[I2C.currentCmd].Len;
                      }
                  }
                  else if ( I2C.currentCmd == cmd_no_PAGE_PLUS_READ )
                  {
                      //20111005 add exception for PAGE_PLUS_READ SMBALERT_MASK
                      if ( i == 2 )
                      {
                          gDataLength = 3;
                      }
                      else if ( i == 3 )
                      {
                          gDataLength = 4;
                      }
                      else
                      {
                          gDataLength = gCmd[I2C.currentCmd].Len;
                      }
                  }
                  else if ( I2C.currentCmd == 0xE7 )
                  {

                      if ( i == 4 )
                      {
                          gDataLength = 5;
                      }
                      else
                    
                      {
                          gDataLength = gCmd[I2C.currentCmd].Len;
                      }
                  }
     
#else
     switch (I2C.currentCmd)
     {
         case cmd_no_SMBALERT_MASK:
              if ( i == 1 )
                      {
                          gDataLength = 2;	//BlockWrite-BlockRead mode, (block count byte + Status_x command code byte)
                      }
                      else
                      {
                          gDataLength = gCmd[I2C.currentCmd].Len;	//Write word mode
                      }
             break;
             
           case cmd_no_PAGE_PLUS_WRITE:
              if ( i == 3 || i == 4)
                      {
                          gDataLength = i++;	
                      }
                      else
                      {
                          gDataLength = gCmd[I2C.currentCmd].Len;	
                      }
           case cmd_no_PAGE_PLUS_READ:
              if ( i == 2 || i == 3)
                      {
                          gDataLength = i++;	
                      }
                      else
                      {
                          gDataLength = gCmd[I2C.currentCmd].Len;	
                      }   
             break;   
           case 0xE7:
              if ( i == 4)
                      {
                          gDataLength = 5;	
                      }
                      else
                      {
                          gDataLength = gCmd[I2C.currentCmd].Len;	
                      }   
             break;    
             
         default:
             gDataLength = Get_BW_DataLen ( I2C.currentCmd );	
             break;
     }
#endif
    
}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
BYTE IsFactoryCmd(BYTE cmd)
{
    switch(cmd)
    {
        case cmd_no_PAGE_PLUS_WRITE: 
        case cmd_no_PAGE_PLUS_READ: 
        case 0x07: //DISABLE_U1_TX
        case 0x5B: //IIN_OC_FAULT_LIMIT
        case 0x5D: //IIN_OC_WARN_LIMIT
        case 0x6A: //POUT_OP_WARN_LIMIT
        case 0x6B: //PIN_OP_WARN_LIMIT
        case 0x77: //DEBUG_INFO
        case cmd_no_READ_EIN: //READ_EIN
        case 0x87: //READ_EOUT
        case 0xAB: //MFR_EFFICIENCY_HL
        //case 0xB0: //FRU_WRITE          
        //case 0xB1: //FRU_READ           
        case 0xB2: //FRU_FLASH_WRITE
        case 0xB3: //FRU_FLASH_ERASE
        case 0xB4: //MFR_FIRMWARE_VER
        case 0xB9: //UPDATE_FULL_FRU
        case 0xBA: //CAL_VOUT_OFFSET
        case 0xBB: //CAL_TERIDIAN_IC
        case 0xBC: //CAL_TERIDIAN_FINISHED_NOTIFY
        case 0xBD: //GEN_CAL_W
        case cmd_no_GEN_CAL_R: 
        case 0xBF: //CAL_TERIDIAN_GET_FW_VER
        case 0xC0: //MFR_MAX_TEMP_1
        case 0xC1: //MFR_MAX_TEMP_2
        //case 0xE5: //MFR_POS_TOTAL        
        //case 0xE6: //MFR_POS_LAST         
        //case 0xE7: //BMC_UNIX_TIMESTAMP     
        case 0xED: //PID_LOG
        case 0xEE: //PRI_DEBUG
        case 0xF1: //READ_ALL_CALI_INFO
        case 0xF2: //DISABLE_FUNC
        case 0xF3: //CS_PWM_FB
        case 0xF4: //CS_IN
        case 0xF5: //READ_IOUT_LS
        case 0xF6: //READ_IOUT_SS
        case 0xF8: //SCI
        case 0xF9: //PRI_STATUS	//20100928 added
        case 0xFA: //PRI_FW_VER_INTERNAL
        case 0xFB: //READ_IOUT_LS_2
        case 0xFC: //CALI_INFO
        case 0xFD: //READ_TEMPERATURE_4(T_Sec)
        case 0xFE: //PID_PARA

            return TRUE;
    }
      return FALSE;
}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static BYTE IsCML_InValid()
{
#define exit_condition_1  ( IsFactoryCmd ( I2C.currentCmd ) ) &&  ( ! gIsFactoryMode )
#define exit_condition_2 ( ( isPermitToReadInPage1 ( I2C.currentCmd ) == FALSE) && (isPermitToWriteInPage1 ( I2C.currentCmd ) == FALSE ) && ( gPmbusCmd.PAGE[0] == 1 ))
#define exit_condition_3   ( ( ( tQuery ) gCmd[I2C.currentCmd].type ).bits.SupportCmd == FALSE )

            if(exit_condition_1) 
                      {
                             gPagePlusStatus.PAGE[gPmbusCmd.PAGE[0]].STATUS_CML.bits.INVALID_CMD = 1;
                              I2C.accessNotAllow = TRUE;	
                               return TRUE; 
                      } 
            else  if(exit_condition_2) 
                      {
                             gPagePlusStatus.PAGE[gPmbusCmd.PAGE[0]].STATUS_CML.bits.INVALID_CMD = 1;
                              I2C.accessNotAllow = TRUE;	
                               return TRUE; 
                      } 
            else  if(exit_condition_3) 
                      {
                             gPagePlusStatus.PAGE[gPmbusCmd.PAGE[0]].STATUS_CML.bits.INVALID_CMD = 1;
                              I2C.accessNotAllow = TRUE;	
                               return TRUE; 
                      } 
            
            return FALSE; 
}


/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
BYTE IsSendCmd(BYTE cmd)
{
    switch(cmd)
    {
        case cmd_CLEAR_FAULTS: //CLEAR_FAULT
        case 0x11: //STORE_DEFAULT_ALL
        //case 0xE7: //CLEAR_HISTORY          // Removed MFR_CLEAR_HISTORY
        case cmd_VOUT_MODE:
        case cmd_CAPABILITY:

	    case cmd_STATUS_WORD:
        case cmd_STATUS_VOUT:
        case cmd_STATUS_IOUT:       
        case cmd_STATUS_INPUT:
        case cmd_STATUS_TEMPERATURE: 
        case  cmd_STATUS_CML:

       case  cmd_STATUS_FAN_1_2:
        case cmd_no_READ_EIN ://=0x86,   // no used in delta
        case cmd_no_READ_EOUT:// =0x87,   // no used in delta       
        case cmd_READ_VIN://=cmd_READ_VIN,
            
        case cmd_READ_VCAP://=cmd_READ_VCAP,
        case cmd_READ_VOUT:
        case cmd_READ_IOUT:
        case cmd_READ_TEMPERATURE_1:
        case cmd_READ_TEMPERATURE_2:
        case cmd_READ_TEMPERATURE_3:
        case cmd_READ_FAN_SPEED_1:
        case cmd_READ_POUT://=0x96,
        case cmd_PMBUS_REVISION://=0X98,
            
        case cmd_MFR_VIN_MIN://=0XA0,
        case cmd_MFR_VIN_MAX:
        case cmd_MFR_IIN_MAX:
        case cmd_MFR_PIN_MAX:  
        case cmd_MFR_VOUT_MIN:
        case cmd_MFR_VOUT_MAX:
        case cmd_MFR_IOUT_MAX: 
        case cmd_MFR_POUT_MAX:  
        case cmd_MFR_TAMBIENT_MAX:  
        case cmd_MFR_TAMBIENT_MIN:   
            cmd_no_GEN_CAL_R:
        case cmd_UNLOCK_COMMAND:                   //=0xD8,
        case cmd_REMOTE_ON_LEVEL_SELECT:
            return TRUE;
    }
	 return FALSE;
}




/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static BYTE  m_IsPermitToWrite_InValid()
{
        if ( ! IsSendCmd ( I2C.currentCmd ) )
                                 {
                                       gPagePlusStatus.PAGE[gPmbusCmd.PAGE[0]].STATUS_CML.bits.INVALID_DATA = 1;
                                        I2C.accessNotAllow = TRUE;	
                                         return TRUE;
                                 }
                          else
                                {
                                            I2C.PermitToWrite = TRUE;
                                 }   
           return FALSE;  
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static BYTE  m_Is_Data_InValid()
{
    
    if ( ( ( tQuery ) gCmd[I2C.currentCmd].type ).bits.SupportWrite == 0 &&  ! ( Is_BlockMode_Valid ( I2C.currentCmd ) ) )
                      {
                            gPagePlusStatus.PAGE[gPmbusCmd.PAGE[0]].STATUS_CML.bits.INVALID_DATA = 1;
                            I2C.accessNotAllow = TRUE;	
                            return TRUE;
                     }
    return FALSE; 
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static void  m_retrieve_DataLen(BYTE i)
{
     I2C.isBlockMode = Is_BlockMode_Valid ( I2C.currentCmd );
      if ( I2C.isBlockMode )
          {
                                       #ifndef replacement 
                                            Retrieve_DataLen_in_BlockMode(i);
                                      #endif
           }
           else
          {
                                         gDataLength = gCmd[I2C.currentCmd].Len;
           }
    
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static void m_retrieve_Data(BYTE i)
{
    #define  I2C_PermitToWrite   gIsFactoryMode ||(! gIsFactoryMode  &&  (I2C.dataIndex == ( gDataLength - 1 )))
     *I2C.pRxBuf = i;
                           I2C.pRxBuf ++;
                           CalcPEC ( &I2C.PEC, i );
                           if (I2C_PermitToWrite )  
                             {
                                 I2C.PermitToWrite = TRUE;
                             }
}
/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static void  m_IsPEC_valid(BYTE i)
{
                               BYTE PEC_byte;
                             PEC_byte = i; 
                             if ( ( PEC_byte != I2C.PEC ) && ( I2C.isBlockMode == 0 || I2C.isBlockMode == 1) )   //if ( ( PEC_byte != I2C.PEC ) && ( I2C.isBlockMode == 0 ) )
                                {
                                      I2C.isPecFail = TRUE;
                                      gPagePlusStatus.PAGE[gPmbusCmd.PAGE[0]].STATUS_CML.bits.PEC_FAILED = 1;
                                }
}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static void m_retrieve_txPuf()
{
     if ( gPmbusCmd.MFR_PAGE[0] != 0xFF )	//for Blackbox
           {
                                 #if BLACKBOX_SUPPORTED
                                         I2C.pTxBuf = GetDataFromBlackBox ( I2C.currentCmd );
                                 #endif
                                      if ( I2C.pTxBuf == NULL )
                                      {
                                          I2C.pTxBuf = gCmd[I2C.currentCmd].pBuf;	
                                      }
                                 }
                                 else
                                 {
                                      I2C.pTxBuf = gCmd[I2C.currentCmd].pBuf;	          
                                 }
    #ifdef no_delta
           Ein_Eout_handler();           
    #endif
}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static BYTE  ExtSys_Write_Data()
{
           BYTE read_byte = I2C1RCV;
           I2C.cmdDir = CMD_W;	
           
           switch ( I2C.state)
           {
               case  STATE_WAIT_FOR_CMD:
                      I2C.currentCmd = read_byte;
                      CalcPEC ( &I2C.PEC, I2C.currentCmd );
                      I2C.state = STATE_WAIT_FOR_WRITE_DATA;	//asume next will be write data      
                      #ifndef replacement 
                      if (IsCML_InValid() ==TRUE)  {return TRUE;}             
                      #endif			  
                      if ( gCmd[I2C.currentCmd].pBuf != NULL )
                      {
                              m_retrieve_txPuf();
                      }
                      else
                      {
                             if (m_IsPermitToWrite_InValid()) {return TRUE;}
                      }
               break;   
               case    STATE_WAIT_FOR_WRITE_DATA:
                      if (m_Is_Data_InValid()==TRUE){return TRUE;}
                      if ( I2C.dataIndex == 0 )
                      {	                                                         //enter only first time
                           I2C.isBlockMode = Is_BlockMode_Valid ( I2C.currentCmd );
                           m_retrieve_DataLen(read_byte);
                     }
                     else if ( I2C.dataIndex < gDataLength )
                     {
                            m_retrieve_Data(read_byte);
                      }
                      else if ( I2C.dataIndex == gDataLength )
                      {	
                           m_IsPEC_valid(read_byte);
                      }
                     else //>
                      {
                            Temp = read_byte;	//dummy Rx byte
                      }
                      I2C.dataIndex ++;
                   break;
               
               default : break;
                     
           }     
           return    FALSE;    // no err
}


/************************************************************************
 * author:                     Edwin
 * description:             Reply data to master
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static BYTE Reply_Data2Master()
{
  BYTE TX_byte;
      if ( I2C.pTxBuf == NULL || I2C.accessNotAllow )
      {
          TX_byte = 0xFF;
          drv_Transmit_byte ( TX_byte );
          return TRUE;
      }

      if ( I2C.dataIndex < gDataLength )
      {
           if ( I2C.dataIndex == ( gDataLength - 1 ) )
           {
              PS.I2C_Processing = FALSE;
           }
           if ( I2C.pTxBuf == NULL )
           {
              TX_byte = 0xFF;
              drv_Transmit_byte ( TX_byte );
              //ToDo : set status flag here
              return TRUE;
           }
          else
          {
              TX_byte = I2C.pTxBuf[I2C.dataIndex];
          }
           CalcPEC ( &I2C.PEC, TX_byte );
      }
      else if ( I2C.dataIndex == gDataLength )
      {
           TX_byte = I2C.PEC;
      }
      else
      {
          //return dummy byte
           TX_byte = 0xFF;
      }
      drv_Transmit_byte ( TX_byte );
      //I2C1CONbits.SCLREL = 1; 	//release clock line so MASTER can drive it
      I2C.dataIndex ++;
      return FALSE;
}

/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static BYTE  Reply_Addr2Master()
{
      BYTE TX_byte;

      ////HoldSCL(); 
      PS.I2C_Processing = TRUE;         // 
  //    Temp = I2C1RCV;
      
      I2C.cmdDir = CMD_R;
      I2C.dataIndex = 0;
      CalcPEC ( &I2C.PEC, gSlaveAddrR );
      
      //Check BlockWrite-BlockRead Cmd
      if ( I2C.isBlockMode )
      {
          HandleWRBlock ( I2C.currentCmd );
          gDataLength = gCmd[I2C.currentCmd].pBuf[0] + 1;	//the first byte is byte count
      }
      else
      {
          gDataLength = gCmd[I2C.currentCmd].Len;
      }
	  
      if ( I2C.pTxBuf == NULL || I2C.accessNotAllow )
      {
          TX_byte = 0xFF;
          drv_Transmit_byte ( TX_byte );
          //ToDo : set status flag here
          return  TRUE;
      }
      else
      {
          TX_byte = I2C.pTxBuf[I2C.dataIndex];
      }

      CalcPEC ( &I2C.PEC, TX_byte );
      drv_Transmit_byte ( TX_byte );
      //I2C1CONbits.SCLREL = 1;
      I2C.dataIndex ++;
      
      return  FALSE;
}


/************************************************************************
 * author:                     Edwin
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
 
#define Write_status    ( I2C1STATbits.R_W == 0 )  //1=READ
#define Read_status    ( I2C1STATbits.R_W == 1 )
#define Address_status  ( I2C1STATbits.D_A == 0 )
#define Data_status        ( I2C1STATbits.D_A == 1 )

void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _SI2C1Interrupt ( )
{
    if ( Write_status  &&  Address_status )	                             //Address matched
    { 
         Address_matched();
  }
    else if ( Write_status  && Data_status)                                //Write, check for data
  {
         if (ExtSys_Write_Data()==TRUE) { goto OUT;}	 
  }
    else if ( Read_status  && Data_status )                              	//Read data
  {
         if (Reply_Data2Master()==TRUE)  { goto OUT;}
  }
    else if ( Read_status  &&  Address_status )	                      //Read address
  {
         if (Reply_Addr2Master()==TRUE)  { goto OUT;}
  }
  

OUT:
	  if ( I2C1STATbits.RBF )             //RBF: Receive Buffer Full Status bit 1=full,0=empty
	  {
		  Temp = I2C1RCV;
		  I2C1STATbits.RBF = 0;
	  }
	  I2C1STATbits.IWCOL = 0;  // write conflict, 1=busy;0=no conflict
	  _SI2C1IF = 0;                       //clear I2C1 Slave interrupt flag
	  ReleaseSCL ( );
}

// end of file

#if 0//cips   // old code
void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _SI2C1Interrupt ( )
{
  BYTE Temp;
  if ( ( I2C1STATbits.R_W == 0 ) && ( I2C1STATbits.D_A == 0 ) )	//Address matched
  {
      //Initialization
      Temp = I2C1RCV;
      init_I2cStruct ( );
      CalcPEC ( &I2C.PEC, gSlaveAddrW );
	  
  }
  else if ( ( I2C1STATbits.R_W == 0 ) && ( I2C1STATbits.D_A == 1 ) ) //Write, check for data
  {

        BYTE read_byte = I2C1RCV;

         I2C.cmdDir = CMD_W;	//20100730 modified

         if ( I2C.state == STATE_WAIT_FOR_CMD )
        {
                 I2C.currentCmd = read_byte;
          CalcPEC ( &I2C.PEC, I2C.currentCmd );

          I2C.state = STATE_WAIT_FOR_WRITE_DATA;	//asume next will be write data

          //Check if facotry mode or not
          if ( IsFactoryCmd ( I2C.currentCmd ) )
          {
              if ( ! gIsFactoryMode )
              {
                  //treat it as invalid command
                  gPagePlusStatus.PAGE[gPmbusCmd.PAGE[0]].STATUS_CML.bits.INVALID_CMD = 1;
                  I2C.accessNotAllow = TRUE;	
                  return;
              }
          }

          //Check commands can be executed in page1 or not
          if ( isPermitToReadInPage1 ( I2C.currentCmd ) == FALSE && isPermitToWriteInPage1 ( I2C.currentCmd ) == FALSE )
          {
              if ( gPmbusCmd.PAGE[0] == 1 )
              {
                  gPagePlusStatus.PAGE[gPmbusCmd.PAGE[0]].STATUS_CML.bits.INVALID_CMD = 1;
                  I2C.accessNotAllow = TRUE;	
                  return;
              }
          }

          if ( ( ( tQuery ) gCmd[I2C.currentCmd].type ).bits.SupportCmd == FALSE )
          {
              gPagePlusStatus.PAGE[gPmbusCmd.PAGE[0]].STATUS_CML.bits.INVALID_CMD = 1;
              I2C.accessNotAllow = TRUE;	
              return;
          }

          if ( gCmd[I2C.currentCmd].pBuf != NULL )
          {

              if ( gPmbusCmd.MFR_PAGE[0] != 0xFF )	//for Blackbox
              {
// BLACKBOX_SUPPORTED
                  I2C.pTxBuf = GetDataFromBlackBox ( I2C.currentCmd );


                  if ( I2C.pTxBuf == NULL )
                  {
                      //if the command is not support for BlackBox, point it to the specific data buffer
                      I2C.pTxBuf = gCmd[I2C.currentCmd].pBuf;	//assgin TxBuffer point to the specified Cmd buffer for reading
                  }
              }
              else
              {
                  I2C.pTxBuf = gCmd[I2C.currentCmd].pBuf;	//assgin TxBuffer point to the specified Cmd buffer for reading
              }


#if 1
              if ( ! PS.EIN_DataUpdating && PS.EIN_DataUpdated )
              {
                  PS.EIN_DataUpdated = 0;
                  memcpy ( gPmbusCmd.READ_EIN_TEMP, gPmbusCmd.READ_EIN, 7 );
              }

              if ( ! PS.EOUT_DataUpdating && PS.EOUT_DataUpdated )
              {
                  PS.EOUT_DataUpdated = 0;
                  memcpy ( gPmbusCmd.READ_EOUT_TEMP, gPmbusCmd.READ_EOUT, 7 );
              }

              if ( I2C.currentCmd == cmd_no_READ_EIN )
              {
                  if ( PS.EIN_DataUpdating )
                  {
                      I2C.pTxBuf = gPmbusCmd.READ_EIN_TEMP;
                  }
                  else
                  {
                      I2C.pTxBuf = gPmbusCmd.READ_EIN;
                  }
              }
              if ( I2C.currentCmd == 0x87 )
              {
                  if ( PS.EOUT_DataUpdating )
                  {
                      I2C.pTxBuf = gPmbusCmd.READ_EOUT_TEMP;
                  }
                  else
                  {
                      I2C.pTxBuf = gPmbusCmd.READ_EOUT;
                  }
              }
#endif
          }
          else
          {
              if ( ! IsSendCmd ( I2C.currentCmd ) )
              {
                  gPagePlusStatus.PAGE[gPmbusCmd.PAGE[0]].STATUS_CML.bits.INVALID_DATA = 1;
                  I2C.accessNotAllow = TRUE;	
                  return;
              }
              else
              {
                  I2C.PermitToWrite = TRUE;
              }
          }

      }

      else if ( I2C.state == STATE_WAIT_FOR_WRITE_DATA )
      {
          //Check if in standby mode or not to make sure the command valid to access or not...
          
          #if 0     //20160429  STATUS_CML can be settign NORMAL and STANDBY mode


          #else   //20160429  STATUS_CML can be settign all mode

          if ( ( ( tQuery ) gCmd[I2C.currentCmd].type ).bits.SupportWrite == 0 &&
                   ! ( Is_BlockMode_Valid ( I2C.currentCmd ) ) )
              {
                  gPagePlusStatus.PAGE[gPmbusCmd.PAGE[0]].STATUS_CML.bits.INVALID_DATA = 1;
                  I2C.accessNotAllow = TRUE;	
                  return;
              }

          #endif

          //Check if this is process call command or not here.
          if ( I2C.dataIndex == 0 )
          {	//enter only first time
              //Check if Block-Write-Block-Read cmd
              I2C.isBlockMode = Is_BlockMode_Valid ( I2C.currentCmd );

              if ( I2C.isBlockMode )
              {
                  if ( I2C.currentCmd ==  cmd_no_SMBALERT_MASK )
                  {
                      //Exception for  cmd_no_SMBALERT_MASK SMBALERT_MASK
                      //(support Write Word & BlockWrite-BlockRead at the same time)
                      if ( read_byte == 1 )
                      {
                          gDataLength = 2;	//BlockWrite-BlockRead mode, (block count byte + Status_x command code byte)
                      }
                      else
                      {
                          gDataLength = gCmd[I2C.currentCmd].Len;	//Write word mode
                      }
                  }
                  else if ( I2C.currentCmd == cmd_no_PAGE_PLUS_WRITE )
                  {
                      //20111005 add exception for PAGE_PLUS_WRITE SMBALERT_MASK
                      if ( read_byte == 3 )
                      {
                          gDataLength = 4;
                      }
                      else if ( read_byte == 4 )
                      {
                          gDataLength = 5;
                      }
                      else
                      {
                          gDataLength = gCmd[I2C.currentCmd].Len;
                      }
                  }
                  else if ( I2C.currentCmd == cmd_no_PAGE_PLUS_READ )
                  {
                      //20111005 add exception for PAGE_PLUS_READ SMBALERT_MASK
                      if ( read_byte == 2 )
                      {
                          gDataLength = 3;
                      }
                      else if ( read_byte == 3 )
                      {
                          gDataLength = 4;
                      }
                      else
                      {
                          gDataLength = gCmd[I2C.currentCmd].Len;
                      }
                  }
                  else if ( I2C.currentCmd == 0xE7 )
                  {

                      if ( read_byte == 4 )
                      {
                          gDataLength = 5;
                      }
                      else
                      {
                          gDataLength = gCmd[I2C.currentCmd].Len;
                      }
                  }
                  else
                  {
                      //gDataLength = read_byte + 1;	//get byte count here, 1 is the byte of byte count itself
                      gDataLength = Get_BW_DataLen ( I2C.currentCmd );	//20110124 modified
                  }
              }
              else
              {

                  gDataLength = gCmd[I2C.currentCmd].Len;
              }

          }

          if ( I2C.dataIndex < gDataLength )
          {
              *I2C.pRxBuf = read_byte;
              I2C.pRxBuf ++;
              CalcPEC ( &I2C.PEC, read_byte );
              if ( ! gIsFactoryMode )
              {
                  if ( I2C.dataIndex == ( gDataLength - 1 ) )
                  {
                      I2C.PermitToWrite = TRUE;
                  }
              }
              else
              {
                  I2C.PermitToWrite = TRUE;
              }
          }
          else if ( I2C.dataIndex == gDataLength )
          {	//recognized as PEC byte
              BYTE PEC_byte;

              PEC_byte = read_byte;

              //if ( ( PEC_byte != I2C.PEC ) && ( I2C.isBlockMode == 0 ) )
              if ( ( PEC_byte != I2C.PEC ) && ( I2C.isBlockMode == 0 || I2C.isBlockMode == 1) )
              {
                  I2C.isPecFail = TRUE;
                  gPagePlusStatus.PAGE[gPmbusCmd.PAGE[0]].STATUS_CML.bits.PEC_FAILED = 1;
              }

          }
          else
          {
              Temp = read_byte;	//dummy Rx byte
          }

          I2C.dataIndex ++;
      }

  }
  else if ( ( I2C1STATbits.R_W == 1 ) && ( I2C1STATbits.D_A == 1 ) )	//Read data
  {
      BYTE return_byte;

      //
      if ( I2C.pTxBuf == NULL || I2C.accessNotAllow )
      {
          return_byte = 0xFF;
          drv_Transmit_byte ( return_byte );
          //ToDo : set status flag here
          return;
      }

      if ( I2C.dataIndex < gDataLength )
      {

          ////HoldSCL(); 

          // added
          if ( I2C.dataIndex == ( gDataLength - 1 ) )
          {
              PS.I2C_Processing = FALSE;
          }

          if ( I2C.pTxBuf == NULL )
          {
              return_byte = 0xFF;
              drv_Transmit_byte ( return_byte );
              //ToDo : set status flag here
              return;
          }
          else
          {
              return_byte = I2C.pTxBuf[I2C.dataIndex];
          }
          CalcPEC ( &I2C.PEC, return_byte );
      }
      else if ( I2C.dataIndex == gDataLength )
      {
          //return PEC byte
          return_byte = I2C.PEC;
      }
      else
      {
          //return dummy byte
          return_byte = 0xFF;
      }

      drv_Transmit_byte ( return_byte );
      //I2C1CONbits.SCLREL = 1; 	//release clock line so MASTER can drive it
      I2C.dataIndex ++;
  }
  else if ( ( I2C1STATbits.R_W == 1 ) && ( I2C1STATbits.D_A == 0 ) )	//Read address
  {
      BYTE return_byte;

      ////HoldSCL(); 
      PS.I2C_Processing = TRUE;         // 

      Temp = I2C1RCV;

      I2C.cmdDir = CMD_R;
      I2C.dataIndex = 0;
      CalcPEC ( &I2C.PEC, gSlaveAddrR );

      //Check BlockWrite-BlockRead Cmd
      if ( I2C.isBlockMode )
      {
          //Handle BlockWritten data
          HandleWRBlock ( I2C.currentCmd );
          //update data length
          gDataLength = gCmd[I2C.currentCmd].pBuf[0] + 1;	//the first byte is byte count
      }
      else
      {
          gDataLength = gCmd[I2C.currentCmd].Len;
      }


      if ( I2C.pTxBuf == NULL || I2C.accessNotAllow )
      {
          return_byte = 0xFF;
          drv_Transmit_byte ( return_byte );
          //ToDo : set status flag here
          return;
      }
      else
      {
          return_byte = I2C.pTxBuf[I2C.dataIndex];
      }

      CalcPEC ( &I2C.PEC, return_byte );

      drv_Transmit_byte ( return_byte );
      //I2C1CONbits.SCLREL = 1;
      I2C.dataIndex ++;
  }


OUT:



  //I2C1STATbits.RBF = 0;
  if ( I2C1STATbits.RBF )
  {
      Temp = I2C1RCV;
      I2C1STATbits.RBF = 0;
  }
  I2C1STATbits.IWCOL = 0;
  _SI2C1IF = 0;	//clear I2C1 Slave interrupt flag

  ReleaseSCL ( );
}

#endif



//Add End <-

