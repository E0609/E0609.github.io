
#ifndef __PMBUS_H__
#define __PMBUS_H__

#include "parameter.h"
#include "Define.h"
#include "UserData.h"



//**************************************************************/
//COEFFICIENT settings

#define DEFAULT_R_M	0x0001
#define DEFAULT_R_B   	0x0000
#define DEFAULT_R_R  	0x00

#define DEFAULT_W_M	0x0001
#define DEFAULT_W_B	0x0000
#define DEFAULT_W_R	0x00

//**************************************************************/
//OPERATION
#define OPERATION_MASK	0b11000000
#define OPERATION_OFF		0x00
#define OPERATION_ON		0x80

#define MFR_PSON_DISABLE         0X00       
#define MFR_PSON_ENABLE          0X01       

typedef enum
{
  MARGIN_NA = 0 ,
  MARGIN_OFF ,
  MARGIN_LOW_IGNORE_FAULT ,
  MARGIN_LOW_ACT_ON_FAULT ,
  MARGIN_HIGH_IGNORE_FAULT ,
  MARGIN_HIGH_ACT_ON_FAULT ,
} eOPERATION_MARGIN_STATE ;

//**************************************************************/
//FRU data
#define FRU_SLICE_BUF_SIZE	32
#define FRU_BUFFER_SIZE		256

//**************************************************************/
//QUERY
#define QUERY_REPORT_MASK	0b11111100	//mask out standby information
#define QUERY_STB_MASK		0b00000011

//**************************************************************/
//ROA Control
#define ROA_CTNL_MASK		0b00000011	//mask out except ROA control bits

typedef union _Query
{
  struct
  {
    unsigned StbSupported : 2 ; //tempary store the cmd is R or W in Standby mode.
    unsigned Format : 3 ;
    unsigned SupportRead : 1 ;
    unsigned SupportWrite : 1 ;
    unsigned SupportCmd : 1 ;
  } bits ;
  BYTE Val ;
} tQuery ;


#if remove
typedef enum
{
    cmd_STATUS_BYTE =0x78,
    cmd_STATUS_WORD,
    cmd_STATUS_VOUT,
    cmd_STATUS_IOUT,       
    cmd_STATUS_INPUT,
    cmd_STATUS_TEMPERATURE, 
    cmd_STATUS_CML,
    cmd_STATUS_OTHER,
    cmd_STATUS_SPECIFIC,
   cmd_STATUS_FAN_1_2
            
}Status_Cmd;
#endif
typedef struct _CMDS
{
  BYTE *pBuf ;
  BYTE Len ;
  BYTE type ; //for Command Query
} tCMDS ;

typedef union _STATUS_WORD
{
  WORD Val ;
  BYTE v[2] ;

  struct
  {
    BYTE LB ;
    BYTE HB ;
  } byte ;

  struct
  {
    unsigned b0 : 1 ;
    unsigned CML : 1 ;
    unsigned TEMPERATURE : 1 ;
    unsigned VIN_UV : 1 ;
    unsigned IOUT_OC : 1 ;
    unsigned VOUT_OV : 1 ;
    unsigned _OFF : 1 ;
    unsigned b7 : 1 ;
    unsigned b8 : 1 ;
    unsigned b9 : 1 ;
    unsigned FANS : 1 ;
    unsigned POWER_GOOD : 1 ;
    unsigned b12 : 1 ;
    unsigned _INPUT : 1 ;
    unsigned IOUT : 1 ;
    unsigned VOUT : 1 ;
  } bits ;

} tSTATUS_WORD ;

typedef union _STATUS_VOUT
{
  BYTE Val ;

  struct
  {
    unsigned b0 : 1 ;
    unsigned b1 : 1 ;
    unsigned b2 : 1 ;
    unsigned b3 : 1 ;
    unsigned VOUT_UV_FAULT : 1 ;
    unsigned VOUT_UV_WARNING : 1 ;
    unsigned VOUT_OV_WARNING : 1 ;
    unsigned VOUT_OV_FAULT : 1 ;
  } bits ;
} tSTATUS_VOUT ;

typedef union _STATUS_IOUT
{
  BYTE Val ;

  struct
  {
    unsigned b0 : 1 ;
    unsigned b1 : 1 ;
    unsigned b2 : 1 ;
    unsigned b3 : 1 ;
    unsigned b4 : 1 ;
    unsigned IOUT_OC_WARNING : 1 ;
    unsigned b6 : 1 ;
    unsigned IOUT_OC_FAULT : 1 ;
  } bits ;
} tSTATUS_IOUT ;

typedef union _STATUS_INPUT
{
  BYTE Val ;

  struct
  {
    unsigned b0 : 1 ;
    unsigned b1 : 1 ;
    unsigned b2 : 1 ;
    unsigned UNIT_OFF : 1 ;
    unsigned VIN_UV_FAULT : 1 ;
    unsigned VIN_UV_WARNING : 1 ;
    unsigned VIN_OV_WARNING : 1 ;
    unsigned VIN_OV_FAULT : 1 ;
  } bits ;
} tSTATUS_INPUT ;

typedef union _STATUS_TEMPERATURE
{
  BYTE Val ;

  struct
  {
    unsigned b0 : 1 ;
    unsigned b1 : 1 ;
    unsigned b2 : 1 ;
    unsigned b3 : 1 ;
    unsigned b4 : 1 ;
    unsigned b5 : 1 ;
    unsigned OT_WARNING : 1 ;
    unsigned OT_FAULT : 1 ;
  } bits ;
} tSTATUS_TEMPERATURE ;

typedef union _STATUS_CML
{
  BYTE Val ;

  struct
  {
    unsigned b0 : 1 ;
    unsigned OTHER_FAULT : 1 ;
    unsigned b2 : 1 ;
    unsigned CPU_FAULT : 1 ;
    unsigned MEM_FAULT : 1 ;
    unsigned PEC_FAILED : 1 ;
    unsigned INVALID_DATA : 1 ;
    unsigned INVALID_CMD : 1 ;
  } bits ;
} tSTATUS_CML ;

typedef union _STATUS_FAN
{
  BYTE Val ;

  struct
  {
    unsigned b0 : 1 ;
    unsigned b1 : 1 ;
    unsigned b2 : 1;//FAN2_OVERRIDE : 1 ;
    unsigned FAN1_OVERRIDE : 1 ;
    unsigned b4 : 1 ;
    unsigned b5 : 1 ;
    unsigned FAN1_WARNING : 1 ;
    unsigned FAN1_FAULT : 1 ;
  } bits ;
} tSTATUS_FAN ;

typedef union _PSU_FEATURES
{
  BYTE Val ;

  struct
  {
    unsigned b0 : 1 ;
    unsigned RapidOn : 1 ;
    unsigned PFC_Disable : 1 ;
    unsigned FaultProtectProg : 1 ;
    unsigned HighAccuracy : 1 ;
    unsigned DiamondEff : 1 ;
    unsigned b6 : 1 ;
    unsigned b7 : 1 ;
  } bits ;
} tPSU_FEATURES ;

typedef union _PSU_FACTORY_MODE
{
  BYTE Val ;

  struct
  {
    unsigned FactoryMode : 1 ;
    unsigned FruAccessControl : 2 ;
    unsigned MfrSampleSetControl : 1 ;
    unsigned BlackBoxClrControl : 1 ;
    unsigned RVSD : 2 ;
    unsigned FruModified : 1 ;
  } bits ;
} tPSU_FACTORY_MODE ;

typedef union _LINE_STATUS
{
  BYTE Val ;
  struct
  {
    unsigned NoAC : 1 ;
    unsigned IsHighLine : 1 ;
    unsigned Freq60Hz : 1 ;
    unsigned RVSD : 5 ;
  } bits ;
} tLINE_STATUS ;

typedef union _ROA_CONTROL
{
  BYTE Val ;

  struct
  {
    unsigned ROACntl : 2 ;
    unsigned IsSleep : 1 ;
    unsigned RVSD : 5 ;
  } bits ;
} tROA_CONTROL ;

typedef struct _ISP_DATA
{
  unsigned ISP_Key_Unlock : 1 ;
  unsigned RVSD : 7 ;
} tISP_DATA ;

typedef union _ISP_STATUS
{
  BYTE Val ;

  struct
  {
    unsigned bChksumOK : 1 ;
    unsigned bMemErr : 1 ;
    unsigned bAlignErr : 1 ;
    unsigned bKeyErr : 1 ;
    unsigned bStartErr : 1 ;
    unsigned RVSD : 1 ;
    unsigned bMode : 1 ;
    unsigned bPrgmBusy : 1 ;
  } bits ;
} tISP_STATUS ;

typedef struct _PMBUS_CMDS
{
  BYTE PAGE[1] ; //0X00
  BYTE OPERATION[1] ; //0X01
  BYTE ON_OFF_CONFIG[1] ; //0x02
  BYTE CLEAR_FAULTS;								//0X03	with no data
  BYTE PAGE_PLUS_WRITE[5] ; //0X05
  BYTE PAGE_PLUS_READ[4] ; //0X06

  BYTE DISABLE_U1_TX[1] ; //0X07 debug

  BYTE WRITE_PROTECT[1] ; //0x10
  BYTE CAPABILITY[1] ; //0X19
  BYTE QUERY[2] ; //0X1A
  BYTE SMBALERT_MASK[2] ; // cmd_no_SMBALERT_MASK

  BYTE VOUT_MODE[1] ; //0x20
  BYTE VOUT_COMMAND[2] ; //0X21
  BYTE COEFFICIENT[6] ; //0X30
  BYTE FAN_CONFIG_1_2[1] ; //0X3A
  BYTE FAN_COMMAND_1[2] ; //0X3B
  BYTE FAN_COMMAND_2[2] ; //0X3C
  BYTE FAN_CONFIG_3_4[1] ; //0X3D
  BYTE FAN_COMMAND_3[2] ; //0X3E
  BYTE FAN_COMMAND_4[2] ; //0X3F

  BYTE VOUT_OV_FAULT_LIMIT[2] ; //0X40
  BYTE VOUT_OV_FAULT_RESPONSE[1] ; //0x41
  BYTE VOUT_OV_WARN_LIMIT[2] ; //0x42
  BYTE VOUT_UV_WARN_LIMIT[2] ; //0X43
  BYTE VOUT_UV_FAULT_LIMIT[2] ; //0X44
  BYTE IOUT_OC_FAULT_LIMIT[2] ; //0X46
  BYTE IOUT_OC_FAULT_RESPONSE[1] ; //0x47
  BYTE IOUT_OC_WARN_LIMIT[2] ; //0X4A
  BYTE OT_FAULT_LIMIT[2] ; //0x4F

  BYTE OT_FAULT_RESPONSE[1] ; //0x50
  BYTE OT_WARN_LIMIT[2] ; //0x51
  BYTE VIN_OV_FAULT_LIMIT[2] ; //0x55
  BYTE VIN_OV_FAULT_RESPONSE[1] ; //0x56
  BYTE VIN_OV_WARN_LIMIT[2] ; //0x57
  BYTE VIN_UV_WARN_LIMIT[2] ; //0x58
  BYTE VIN_UV_FAULT_LIMIT[2] ; //0x59
  BYTE VIN_UV_FAULT_RESPONSE[1] ; //0x5A
  BYTE IIN_OC_FAULT_LIMIT[2] ; //0x5B
  BYTE IIN_OC_WARN_LIMIT[2] ; //0X5D

  BYTE POUT_OP_WARN_LIMIT[2] ; //0X6A
  BYTE PIN_OP_WARN_LIMIT[2] ; //0X6B

  BYTE MFR_FW_VER_DATE[6] ; //0x70
  BYTE DEBUG_INFO[6] ; //0x77
  
  tSTATUS_WORD* STATUS_WORD ; //0X78 0X79
  tSTATUS_VOUT* STATUS_VOUT ; //0X7A
  tSTATUS_IOUT* STATUS_IOUT ; //0X7B
  tSTATUS_INPUT* STATUS_INPUT ; //0X7C
  tSTATUS_TEMPERATURE* STATUS_TEMPERATURE ; //0X7D
  tSTATUS_CML* STATUS_CML ; //0X7E
  //tSTATUS_OTHER STATUS_OTHER;							//0X7F

  tSTATUS_FAN STATUS_FAN_1_2 ; //0X81
  //tSTATUS_FAN STATUS_FAN_3_4;						//0X82
  BYTE READ_EIN[7] ; //cmd_READ_EIN
  BYTE READ_EIN_TEMP[7] ;
  BYTE READ_EOUT[7] ; //0X87
  BYTE READ_EOUT_TEMP[7] ;
  BYTE READ_VIN[2] ; //0X88
  BYTE READ_IIN[2] ; //0X89
  BYTE READ_VOUT[2] ; //0X8B
  BYTE READ_IOUT[2] ; //0X8C
  BYTE READ_TEMPERATURE_1[2] ; //0X8D
  BYTE READ_TEMPERATURE_2[2] ; //0X8E
  BYTE READ_TEMPERATURE_3[2] ; //0X8F

  BYTE READ_FAN_SPEED_1[2] ; //0X90
  BYTE READ_FAN_SPEED_2[2] ; //0X91
  //BYTE READ_FAN_SPEED_3[2];							//0X92
  //BYTE READ_FAN_SPEED_4[2];							//0X93
  BYTE READ_FREQUENCY[2] ; //0x95
  BYTE READ_POUT[2] ; //0X96
  BYTE READ_PIN[2] ; //0X97
  BYTE READ_PIN_FOR_EIN[2] ;
  BYTE PMBUS_REVISION[1] ; //0X98
  BYTE MFR_ID[MFR_ID_LEN + 1] ; //0X99
  BYTE MFR_MODEL[MFR_MODEL_LEN + 1] ; //0X9A
  BYTE MFR_REVISION[MFR_REVISION_LEN + 1] ; //0X9B
  BYTE MFR_LOCATION[MFR_LOCATION_LEN + 1] ; //0X9C
  BYTE MFR_DATE[MFR_DATE_LEN + 1] ; //0X9D
  BYTE MFR_SERIAL[MFR_SERIAL_LEN + 1] ; //0X9E

  BYTE MFR_VIN_MIN[2] ; //0XA0
  BYTE MFR_VIN_MAX[2] ; //0XA1
  BYTE MFR_IIN_MAX[2] ; //0XA2
  BYTE MFR_PIN_MAX[2] ; //0XA3
  BYTE MFR_VOUT_MIN[2] ; //0XA4
  BYTE MFR_VOUT_MAX[2] ; //0XA5

  BYTE MFR_IOUT_MAX[2] ; //0XA6
  BYTE MFR_POUT_MAX[2] ; //0XA7
  BYTE MFR_TAMBIENT_MAX[2] ; //0XA8
  BYTE MFR_TAMBIENT_MIN[2] ; //0XA9
  BYTE MFR_EFFICIENCY_LL[MFR_EFFICIENCY_LL_LEN + 1] ; //0XAA	//add 1 for byte count
  BYTE MFR_EFFICIENCY_HL[MFR_EFFICIENCY_HL_LEN + 1] ; //0XAB
  //--for FRU command B0 and B1,
  BYTE FRU_WRITE[3] ; // 1 byte count byte + 2 address bytes         //0xB0
  BYTE FRU_READ[17] ; // 1 byte count byte + 16 data bytes            //0xB1
  //---for flash write
  //updated by daniel use block write
  //command code is "B2" the first is word address, the second is data to be write into flash
  BYTE FRU_FLASH_WRITE[30] ; //0xB2
  //---for flase erase
  BYTE FRU_FLASH_ERASE[2] ; //command 0xB3				//0xB3
  BYTE MFR_FIRMWARE_VER[MFR_FIRMWARE_VER_LEN + 1] ; //0xB4
  BYTE FRU_SLICE_BUF[FRU_SLICE_BUF_SIZE] ; //0xB9
  BYTE CAL_VOUT_OFFSET[8] ; //0xBA
  BYTE CAL_TERIDIAN_IC[50] ; //0xBB
  BYTE CAL_TERIDIAN_FINISHED_NOTIFY[3] ; //0xBC
  BYTE GEN_CAL_W[7] ; //0xBD
  BYTE GEN_CAL_R[7] ; //0xBE
  BYTE CAL_TERIDIAN_GET_FW_VER[3] ; //0xBF
  BYTE MFR_IOUT_CAL[3+1];//command 0xB5 for Iout calibration
  BYTE MFR_IIN_CAL[3+1];//command 0xB6 for Iin calibration

  BYTE MFR_MAX_TEMP_1[2] ; //0xC0
  BYTE MFR_MAX_TEMP_2[2] ; //0xC1

  //BYTE ADE_VIN[3];									//0xCA
  //BYTE ADE_IIN[3];									//0xCB
  //BYTE ADE_PIN[3];									//0xCC

  BYTE MFR_RCB_INFO[MFR_RCB_INFO_LEN + 1] ; //0xCF  //

  BYTE SMART_ON_CONFIG[1] ; //0xD0	Lenovo spec.
  BYTE MFR_DEVICE_CODE[4] ; //0XD0
  BYTE MFR_ISP_KEY[4] ; //0XD1
  BYTE MFR_ISP_STATUS_CMD[1] ; //0XD2
  BYTE MFR_ISP_MEMORY_ADDR[2] ; //0XD3
  BYTE MFR_ISP_MEMORY[16] ; //0XD4
  BYTE MFR_FW_VERSION[MFR_FW_VERSION_LEN + 1] ; //2014/12/11 modify => Baido CMD 0XD0
  BYTE MFR_SYSTEM_LED_CNTL[1] ; //0XD7
  tLINE_STATUS MFR_LINE_STATUS[1] ; //0XD8
  BYTE VIN_MODE[1] ;
  BYTE IIN_MODE[1] ;
  BYTE PIN_MODE[1] ;
  BYTE IOUT_MODE[1] ;
  BYTE POUT_MODE[1] ;
  BYTE PSU_MODEL_NUM[2] ;

  BYTE MFR_SMB_ALERT_MASKING[7] ; //0XD9
  BYTE MFR_TOT_POUT_MAX[2] ; //0xDA

  BYTE LOG_GENERAL[15] ; //0xDD
  BYTE LOG_INDEX[1] ; //0xDE
  BYTE LOG_CONTENT[11] ; //0xDF


  BYTE MFR_PSON_CONTROL[1] ;  //0xE0   

  BYTE MFR_WAKE_TRIP[2] ; //0XE2
  BYTE MFR_TRIP_LATENCY[2] ; //0XE3
  BYTE MFR_PAGE[1] ; //0XE4
  //DWORD_VAL MFR_POS_TOTAL ; //0XE5            //m_PowerOffSeq
  BYTE MFR_POS_TOTAL[5] ; //0XE5 ; //0XE5       // Black Box block read
  //DWORD_VAL MFR_POS_LAST ; //0XE6             //m_PowerOffSeq
  BYTE MFR_POS_LAST[5] ; //0XE6                 // Black Box block read
  //BYTE MFR_CLEAR_HISTORY          //0xE7	with no data, // Removed MFR_CLEAR_HISTORY
  //DWORD_VAL BMC_UNIX_TIMESTAMP;     //0XE7    //m_PowerOffSeq
  BYTE BMC_UNIX_TIMESTAMP[5];     //0XE7    // Black Box block read
  BYTE_VAL MFR_PFC_DISABLE ; //0XE8
  //BYTE MFR_VRAPID_ON_SET[2] ; //0XE9
  //BYTE MFR_VDETECT[2] ; //0XEA
  tPSU_FEATURES PSU_FEATURES[1] ; //0xEB
  BYTE PID_LOG[160] ; //0xED
  BYTE PRI_DEBUG[2] ; //0xEE
  tPSU_FACTORY_MODE PSU_FACTORY_MODE[1] ; //0xF0
  BYTE READ_ALL_CALI_INFO[79] ; //0xF1
  BYTE DISABLE_FUNC[1] ; //0xF2
  BYTE CS_PWM_FB[2] ; //0xF3
  BYTE CS_IN[2] ; //0xF4
  
  BYTE READ_IOUT_LS[2] ; //0xF5	large scale
  BYTE READ_IOUT_SS[2] ; //0xF6	small scale
  
  BYTE READ_IOUT_CS[2] ; //0xF7	current share
  
  BYTE SCI[50] ; //0xF8
  BYTE PRI_STATUS[9] ; //0xF9
  BYTE PRI_FW_VER_INTERNAL[2] ; //0xFA
  BYTE READ_IOUT_LS_2[2] ; //0xFB
  BYTE CALI_INFO[2] ; //0xFC
  BYTE READ_TEMPERATURE_4[2] ; //0XFD
  BYTE PID_P[6] ; //0xFE
} tPMBUS_CMDS ;



typedef enum
{
  PAGE0 = 0 ,
  PAGE1 ,
  TOTAL_PAGE_COUNT
} ePAGE_PLUS_NUM ;

typedef struct _PAGE_PLUS
{
  tSTATUS_WORD STATUS_WORD ;
  tSTATUS_VOUT STATUS_VOUT ;
  tSTATUS_IOUT STATUS_IOUT ;
  tSTATUS_INPUT STATUS_INPUT ;
  tSTATUS_TEMPERATURE STATUS_TEMPERATURE ;
  tSTATUS_CML STATUS_CML ;
} tPAGE_PLUS ;

typedef struct _PAGE_PLUS_STATUS
{
  tPAGE_PLUS PAGE[TOTAL_PAGE_COUNT] ;
} tPAGE_PLUS_STATUS ;


typedef union _COEFFICIENT
{

  struct
  {
    WORD_VAL m ;
    WORD_VAL b ;
    BYTE r ;
  } data ;
  BYTE val[5] ;
} tCOEFFICIENT ;

typedef struct _COEFFICIENT_TYPE
{
  tCOEFFICIENT W ;
  tCOEFFICIENT R ;
} tCOEFFICIENT_TYPE ;

typedef struct _DIRECT_FMT_CMD
{
  tCOEFFICIENT_TYPE EIN ;
  tCOEFFICIENT_TYPE EOUT ;
  tCOEFFICIENT_TYPE SMBALERT_MASK ;
} tDIRECT_FMT_CMD ;


//AnyErrorInBlockMode added for IPMM spec. X03-00

typedef struct _SMBALERT_MASK
{
  BYTE STATUS_VOUT_MASK ;
  BYTE STATUS_IOUT_MASK ;
  BYTE STATUS_TEMPERATURE_MASK ;
  BYTE STATUS_CML_MASK ;
  BYTE STATUS_INPUT_MASK ;
  //BYTE STATUS_OTHER_MASK;
  BYTE STATUS_FAN_1_2_MASK ;
  BYTE GLOBAL_MASK ;
  //BYTE STATUS_WORD_LB_MASK;	//STAUTS_BYTE
  //BYTE STATUS_WORD_HB_MASK;
} tSMBALERT_MASK ;

typedef enum
{
  GLOBAL_MASK = 0 ,
  VOUT_MASK ,
  IOUT_MASK ,
  TEMPERATURE_MASK ,
  INPUT_MASK ,
  FAN_1_2_MASK ,
  CML_MASK
} eSMBALERT_MASK ;


//SMBALERT_MASK <=


//PFC_DISABLE =>

typedef enum
{
  PFC_STATUS_ENABLE = 0 ,
  PFC_STATUS_DISABLE
} ePFC_STATUS ;

typedef enum
{
  PFC_CONTROL_ENABLE = 0 ,
  PFC_CONTROL_DISABLE
} ePFC_CONTROL ;

typedef union _PFC_DISABLE
{
  BYTE Val ;

  struct
  {
    unsigned PFC_Status : 1 ;
    unsigned PFC_Control : 2 ;
    unsigned RVSD : 5 ;
  } bits ;
} tPFC_DISABLE ;

typedef enum
{
  NORMAL = 0 ,
  ABILITY_TO_SLEEP ,
  ROA_MAIN_OFF ,
  ROA_ACTIVE
} eROA_STATUS ;


typedef enum
{
  CAL_VOUT = 0 ,
  CAL_IOUT ,
  CAL_VIN ,
  CAL_IIN ,
  CAL_CLEAR_ALL ,
  CAL_CLEAR_VOUT ,
  CAL_CLEAR_IOUT ,
  CAL_CLEAR_VIN ,
  CAL_CLEAR_IIN ,
  CAL_IOUT_1 ,
  CAL_IOUT_2 ,
  CAL_IOUT_CS ,
  CAL_VOUT_CS ,
  CAL_IOUT_3 ,
  CAL_IOUT_4 , //  added
  CAL_IOUT_LCS , //  added
  CAL_PIN = 32 ,
  CAL_CS_IN = 33 ,
} eCalibration_Info ;


extern tPMBUS_CMDS gPmbusCmd ;
extern tCMDS gCmd[256] ;
extern tSMBALERT_MASK gAlertMask[TOTAL_PAGE_COUNT] ;
extern tPAGE_PLUS_STATUS gPagePlusStatus ;
extern tISP_DATA gISP ;
extern BYTE gIsFactoryMode ;
extern WORD Real_Vac ;
extern SHORT gVoutCmd ;
extern SHORT gVoutCmdOffset ;
extern SHORT gVoutReadOffsetAdc ;
#if RS_ENABLE   
extern SHORT gMainBusVoutOffset ;
#endif
extern SHORT gVCS_Slope ;
extern LONG gVCS_Offset ;

extern DWORD_VAL  MFR_POS_TOTAL;           // Black Box block read
extern DWORD_VAL  MFR_POS_LAST;            // Black Box block read
extern DWORD_VAL  BMC_UNIX_TIMESTAMP;      // Black Box block read

//Exported function
void init_Pmbus ( ) ;
void Task_WiteCmd ( ) ;
BYTE Is_BlockMode_Valid ( BYTE cmd ) ;
void HandleWRBlock ( BYTE cmd ) ;
BYTE IsFactoryCmd ( BYTE cmd ) ;
BYTE IsSendCmd ( BYTE cmd ) ;
void CheckLineStatus ( WORD vin , BYTE freq ) ;
void UpdateEnergyCount ( ) ;
void InitEnergyCount ( ) ;
void Count_4AC_Cycle ( ) ;
//BYTE IsISPKeyMatched ( ) ;    //20170711 Removed, not used
void UpdateLog ( BYTE index ) ;
BYTE isPermitToReadInPage1 ( BYTE cmd ) ;
BYTE isPermitToWriteInPage1 ( BYTE cmd ) ;


#endif


