/*
 * File:   newmainXC16.c
 * Author: wuhengchen
 *
 * Created on May 4, 2020, 10:32 AM
 */


#include "xc.h"

int main(void) {
    return 0;
}
