
#ifndef __STATUS_H__
#define __STATUS_H__


//Exported functions
void m_Refresh_Status_Flag ( ) ;
void ClearAllStatus ( BYTE page ) ;
void mClearStatusBit ( BYTE statusCmd , BYTE bitsToClear , BYTE page ) ;
//BYTE isWarning ( ) ;
void CMD_ClearFault ( BYTE page ) ;





#endif

