
#ifndef __SCI_H__
#define __SCI_H__

#include "p33Exxxx.h"
#include "p33EP64GS504.h"
#include "Parameter.h"

/********************************************************************
 *
 * XXXX Firmware
 *
 *********************************************************************
 * FileName:		uart.h
 * Dependencies: uart.c
 * Processor:	PIC24F Family
 * Compiler:		C30 v3.00 or later
 * Company:		Liteon Technology, Inc.
 *
 * Software License Agreement:
 *
 *
 * THIS SOFTWARE IS PROVIDED IN AN ?S IS?CONDITION. NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
 * TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
 * IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
 * CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 *
 *
 * File Description:
 *
 * Flash program memory read and write functions for use with
 * PIC24F Serial Bootloader.
 *
 * Change History:
 *
 * Author      	Revision #      Date        Comment
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Borson Hsu	1.00   			1-17-2008	Initial release with AN1157
 *********************************************************************/




#define UART1_RX_INTERRUPT_PRIORITY 3

/** Default baud rate used by \ref configBasic() to
 * configure the \ref DEFAULT_UART.
 */
#ifndef DEFAULT_BAUDRATE
#define DEFAULT_U1_BAUDRATE  9600
#endif

/** Default BRGH value used by \ref CONFIG_BAUDRATE_UART1
 *  when configurating a UART. This value may be
 *  overridden on a per-UART basis by \#defineing
 *  \ref DEFAULT_BRGH1 to 4. Allowed values:
 *  - BRGH = 0 - the baud rate divisor is 16
 *  - BRGH = 1 - the baud rate divisor is 4
 */
#ifndef DEFAULT_BRGH
#define DEFAULT_BRGH  0
#endif

#if (DEFAULT_BRGH != 0) && (DEFAULT_BRGH != 1)
#error Invalid value for DEFAULT_BRGH
#endif

/** Chose a default baud rate for UART1, used by
 *  \ref configUART1 to set up UART1.
 */
#ifndef DEFAULT_BAUDRATE1
#define DEFAULT_BAUDRATE1  DEFAULT_BAUDRATE   
#endif

/** Chose a default BRGH for UART1, used by
 *  \ref CONFIG_BAUDRATE_UART1 to set up UART1.
 */
#ifndef DEFAULT_BRGH1
#define DEFAULT_BRGH1  DEFAULT_BRGH
#endif



/** Configure UART baud rate, based on \ref FCY.
 *  Note that the value computed is truncated, not
 *  rounded, since this is done using integer
 *  arithmetic. That is, BRG = truncate(FCY/16/baud - 1),
 *  giving an actual baud rate of FCY/16/(reg + 1), assuming BRGH=0.
 *
 *  NOTE: this code uses as default a value of BRGH=0 (16 clocks for each bit).
 *  Be careful about using BRGH=1 - this uses only four clock
 *  periods to sample each bit and can be very intolerant of
 *  baud rate %error - you may see framing errors.
 *
 *  \param baudRate Desired baud rate.
 */

inline static void
CONFIG_BAUDRATE_UART1 ( DWORD baudRate )
{
#if (DEFAULT_BRGH1 == 0)
  DWORD brg = ( FCY / baudRate / 16 ) - 1 ;
#else
  DWORD brg = ( FCY / baudRate / 4 ) - 1 ;
#endif
  //ASSERT(brg <= 0xFFFF);
  U1MODEbits.BRGH = DEFAULT_BRGH1 ;
  U1BRG = brg ;
}


/** \name Constants for the UxMODE.PDSEL bitfield
 *  Use with \ref CONFIG_PDSEL_UART1.
 *  @{
 */
#define UXMODE_PDSEL_8DATA_NOPARITY   0
#define UXMODE_PDSEL_8DATA_EVENPARITY 1
#define UXMODE_PDSEL_8DATA_ODDPARITY  2
#define UXMODE_PDSEL_9DATA_NOPARITY   3
///@}

#define CNTL_Z	0x1A
#define CR		0x0D
#define CNTL_Y	0x19

/** Select the parity and number of data bits for the UART.
 *  Use constants UXMODE_PDSEL_8DATA_NOPARITY and following.
 *  \param u8_pdsel Parity and number of data bits.
 */
inline static void
CONFIG_PDSEL_UART1 ( BYTE u8_pdsel )
{
  //ASSERT(u8_pdsel <= UXMODE_PDSEL_9DATA_NOPARITY);
  U1MODEbits.PDSEL = u8_pdsel ;
}

/** Select the number of stop bits for this UART. Valid values
 *  are 1 or 2.
 *  \param u8_numStopbits Number of stop bits.
 */
inline static void
CONFIG_STOPBITS_UART1 ( BYTE u8_numStopbits )
{
  //ASSERT(u8_numStopbits <= 2);
  U1MODEbits.STSEL = u8_numStopbits - 1 ;
}

/** Enable RX, TX for UART. */
inline static void
ENABLE_UART1 ( )
{
  U1MODEbits.UEN = 0b00 ; // UxTX and UxRX pins are enabled and used; no flow control pins
  U1MODEbits.UARTEN = 1 ; // enable UART RX/TX
  U1STAbits.UTXEN = 1 ; //disable the transmitter
}

/** Determine if a character is available in the UART's
 *  receive buffer.
 *  \return True (1) if character is available, 0 if not.
 */
#define IS_CHAR_READY_UART1() U1STAbits.URXDA

/** Determine if a the transmit buffer is full.
 *  \return True (1) if the transmit buffer if full,
 *          false (0) if not.
 */
#define IS_TRANSMIT_BUFFER_FULL_UART1() U1STAbits.UTXBF

/** Determines if all characters placed in the UART have been sent.
 *  Returns 1 if the last transmission has completed, or 0 if a transmission
 *  is in progress or queued in the transmit buffer.
 *  \return True (1) if the last transmission has completed, 0 if not.
 */
#define IS_TRANSMIT_COMPLETE_UART1() U1STAbits.TRMT

/** Waits until all characters placed in the UART have been sent. */
inline static void
WAIT_UNTIL_TRANSMIT_COMPLETE_UART1 ( )
{
  while ( ! IS_TRANSMIT_COMPLETE_UART1 ( ) ) ;
}

typedef union _PRIMARY_STATUS
{
  BYTE Val ;

  struct
  {
    unsigned PFCDISABLE : 1 ;
    unsigned PFCOV : 1 ;
    unsigned INPUT_OVP : 1 ;
    unsigned DC_INPUT : 1 ;
    unsigned PRI_OTP : 1 ;
    unsigned INPUT_OVW : 1 ;
    unsigned PriCommError : 1 ;          
    unsigned b7 : 1 ;
  } bits ;
} tPRIMARY_STATUS ;

typedef struct _U1_RX_DATA
{
  WORD_VAL Pri_Temperature ;
  WORD_VAL Pri_FW_VER ;
  WORD_VAL Pri_Vin ;
  WORD_VAL Pri_VBus ;
  tPRIMARY_STATUS Pri_Status ;
  WORD_VAL Pri_FW_VER_Internal ;
  WORD_VAL Pri_Iin ;
#ifdef cips
  WORD IinAvg ;   //WH
 WORD  PinAvg;
 WORD PinMsb ;
 WORD PinLsb;
 WORD Freq;
WORD  VacMsb;
WORD  VacLsb;
WORD IacMsb;
 WORD       IacLsb;
#endif
} tU1_RX_DATA ;

typedef enum
{
  CMD_IOUT = 0 ,
  CMD_VIN = 1 ,         // VTHD ISSUE
#endif
  TOTAL_TX_CMD_NUMBER ,
} U1_TX_CMD ;

typedef enum
{
  CMD_PRI_TEMPERATURE = 0 ,
  CMD_PRI_FW_VER ,
  CMD_PRI_VIN ,
  CMD_PRI_VBUS ,
  CMD_PRI_FW_VER_INTERNAL ,
  CMD_PRI_IIN ,

  TOTAL_RX_CMD_NUMBER ,
} U1_RX_CMD ;

typedef struct _U1_TX_DATA
{
  BYTE_VAL status ;
  WORD_VAL cmd[TOTAL_TX_CMD_NUMBER] ;
} tU1_TX_DATA ;


typedef struct _SCI_DATA
{

  struct
  {
    tU1_RX_DATA Rx ;
    tU1_TX_DATA Tx ;
  } U1 ;
  

} tSCI_DATA ;

typedef enum
{
  STATE_SENDING_HEADER = 0 ,
  STATE_SENDING_STATUS ,
  STATE_SENDING_CMD ,
  STATE_SENDING_LB ,
  STATE_SENDING_HB ,
  STATE_SENDING_CS ,
} U1_TX_STATE ;

typedef enum
{
  STATE_RX_HEADER = 0 ,
  STATE_RX_STATUS ,
  STATE_RX_CMD ,
  STATE_RX_LB ,
  STATE_RX_HB ,
  STATE_RX_CS ,
} U1_RX_STATE ;

typedef union _STATUS_TO_PRIMARY
{
  BYTE Val ;

  struct
  {
    unsigned isStandbyMode : 1 ;
    unsigned PFC_Disable : 1 ;
    unsigned isSleep : 1 ;
    unsigned Reserved : 5 ;
  } bits ;
} tSTATUS_TO_PRIMARY ;

typedef struct _UART_FROM_PRI_RECVDATA
{
  BYTE Status ;
  WORD_VAL Data ;
  BYTE Cmd ;
} UART_FROM_PRI_RECVDATA ;

typedef enum
{
  CALI_NONE = 0 ,
  CALI_NORMAL_LOAD ,
  CALI_LIGHT_LOAD ,
  CALI_VDC_OFFSET ,   
  CALI_IDC_OFFSET ,   
} eCaliType ;


extern tSCI_DATA Uart ;
extern tSTATUS_TO_PRIMARY StatusToPrimary ;
extern BYTE gTeridanCaliType ; 
extern BYTE PriFwUpdated ;

//Exported function
void init_UART1 ( DWORD u32_baudRate ) ;

void SCI_U1_Transmit ( ) ;

void CalcIinAvg ( ) ;
void CalcPinAvg ( ) ;
void UpdateInputInfo ( ) ;
void CheckU1OverRun ( ) ;
void CheckU2OverRun ( ) ;

BYTE TeridianSpecialCMDWrite ( BYTE cmd , BYTE byteCnt , BYTE* data ) ;








