/*****************************************************************************************
 *
 *Copyright (C) 2021 CIPS Singapore

 *                   LITE-ON TECHNOLOGY Corp.
 *
 *All Rights Reserved
 *
 *File Name : ISR.c
 *
 *Date : 2021.01.20
 *
 *Author :              WH
 *
 *Description :This Program used for HP 2400W ISR Program.
 *
 *******************************************************************************************/
#include "p33Exxxx.h"
#include "p33EP64GS504.h"     // cips
#include "Isr.h"
#include "Protection.h"
#include "Process.h"
#include "parameter.h"
#include "define.h"
#include "PowerOnOff.h"
#include "Init.h"
#include "I2c.h"
#include "Standby.h"
#include "PowerOnOff.h"
#include "Pmbus.h"
#include "Standby.h"
#include "Userdata.h"
#include "hbllc.h"
#include "Fan.h"
#include "Led.h"
// -------------Global Variable --------------------------------------------
tADC ADC;
tVref Vref;

extern tLED_STATUS gLedStatus;
// -------------Extern Variable --------------------------------------------
extern BYTE gPSU_ONOFF_Status;
extern tPSU_STATE gPS_State;
extern tTimerHandle hTimer;
extern tPS_FLAG PS;
extern tLLC HBLLC;
extern WORD Tsb_off_delay;

extern BYTE Tsb_off_delay_Flag;
// -----------------------------------------------------------------------

extern void ControlVref ( );

void __attribute__ ( ( __interrupt__ , auto_psv, weak ) ) _ADC1Interrupt ( void )
{
    uint16_t valchannel_AN4;
    //Read the ADC value from the ADCBUF
    valchannel_AN4 = ADCBUF4;

 

    //clear the channel_AN4 interrupt flag
      IFS0bits.ADCIF = 0;
}

/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _ADCAN0Interrupt ( )
{
    /*
     AN0	AN_12V_ORING_MCU,PIN21
     */
  ADC.VoutBus = ADC_12V_ORING;
  ADC.VoutBus_LPF = ADC.VoutBus_LPF + ADC.VoutBus - ADC.VoutBus_FF;
  ADC.VoutBus_FF = ADC.VoutBus_LPF >> 9;
  
  IFS6bits.ADCAN0IF = 0;
  
  //test
 _TRISB14 = 0;//;
_LATB14  ^= 1;

}
/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _ADCAN1Interrupt ( )
{
  /*
 PIN22:   AN2 : I_OUT_MCU,
   */
  //SHORT result;
  ADC.Iout = ADC_I_OUT;
  
  ADC.Iout_LPF = ADC.Iout_LPF + ADC.Iout - ADC.Iout_FF;
  ADC.Iout_FF = ADC.Iout_LPF >> 7;	// 2
  ADC.Iout_report_LPF = ADC.Iout_report_LPF + ADC.Iout - ADC.Iout_report_FF;
  ADC.Iout_report_FF = ADC.Iout_report_LPF >> 13;
  
  
#if STB_SC_PROTECT
  App_STB_SCP_hnd ( );
#endif
#if STB_OV_PROTECT
  App_STB_OVP_hnd ( );
#endif
  IFS6bits.ADCAN1IF= 0;
}

/************************************************************************
 * author:                     WH
 * description: 
 * input:                        12V_OUT_MCU
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _ADCAN4Interrupt ( )
{
  /*
AN4	12V_OUT_MCU ,PIN25
   *  12v*(2/(7.87+2))=12V*2 /9.87 =2.43V
   * 12v5 ~2v53
   * 1111 1111 1111 =4095~ 3V3
   */
#define softstart_level_1 16581 	   //8.12v = 12.5x16581/25506
#define softstart_level_2 22108 	   //10.83v = 12.5x22108/25506

SHORT result;
  ADC.Vout = ADC_12V_OUT ;
  
  ADC.Vout_LPF = ADC.Vout_LPF + ADC.Vout - ADC.Vout_FF;
  ADC.Vout_FF = ADC.Vout_LPF >> 9;
    
  //OVP
#if 1        
  result = ( SHORT ) ADC.Vout + ( SHORT ) gVoutReadOffsetAdc;
  if ( result < 0 ){result = 0;}
  if ( result > Parameter.OVP_VOUT_OV_WARN_LIMIT )
  {
      gPagePlusStatus.PAGE[PAGE0].STATUS_VOUT.bits.VOUT_OV_WARNING = 1;
  }

#endif 

  if ( HBLLC.MainEnabled == TRUE )
  {
      if ( result > Parameter.OVP_VOUT_OV_FAULT_LIMIT )
      {
           m_SetValue_InFault ( );  // cips
         m_Emergency_PowerOff( );
          _SD_Flag.OVP_SD = 1;
          _SD_Flag.LATCH_SD = 1;
          gPagePlusStatus.PAGE[PAGE0].STATUS_VOUT.bits.VOUT_OV_FAULT = 1;
      }
  }

    
    

  //------------------------- Main output Softstart--------------------------
  {
      static WORD cnt = 0;
      //  #define DutyCycle_12V5_REF	            25506	// 12.5V

      if ( cnt >= SOFTSTART_SLOPE_ADJUSTMENT )
      {
          cnt = 0;
          if ( PS.Softstart )
          {  
              if ( Vref.SoftstartVoltage < 16581 )  // cips scaler with 1023 11 1111 1111       
              {
                  Vref.SoftstartVoltage += 256;
              }
              else
              {
                  if ( Vref.SoftstartVoltage < 22108 )     // 10.83V
                  {
                      Vref.SoftstartVoltage += 128;
                  }
                  else if ( Vref.SoftstartVoltage < Vref.SetVoltage )
                  {
                      Vref.SoftstartVoltage += 40;
                      if ( Vref.SoftstartVoltage >= Vref.SetVoltage )
                      {
                          Vref.SoftstartVoltage = Vref.SetVoltage;
                      }
                  }
              }
          }
          else
          {
              Vref.SoftstartVoltage = 0;
          }
      }
      else
      {
          cnt ++;
      }
  }
  IFS7bits.ADCAN2IF = 0;
}

/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _ADCAN2Interrupt ( )
{
    /*
    PIN 23: AN2	CS_OUT_READ
     */
  ADC.CS_PWM_FB = ADCBUF2;
  ADC.CS_PWM_FB_LPF = ADC.CS_PWM_FB_LPF + ADC.CS_PWM_FB - ADC.CS_PWM_FB_FF;
  ADC.CS_PWM_FB_FF = ADC.CS_PWM_FB_LPF >> 7;
  
  
  IFS7bits.ADCAN6IF = 0;
}

/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/


void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _ADCAN3Interrupt ( )
{
    /*   AN3 : CSHARE_IN
   */
  ADC.IoutCS = ADCBUF3;
  
  ADC.IoutCS_LPF = ADC.IoutCS_LPF + ADC.IoutCS - ADC.IoutCS_FF;
  ADC.IoutCS_FF = ADC.IoutCS_LPF >> 7;	// 2
#if 1
  {	//New Current Share Scheme
      static BYTE count = 0;
      if ( count >= 10 )  // 200us 
      {	        
        ControlVref ( );
          count = 0;
      }
      else
      {
          count ++;
      }
  }
#endif
      IFS7bits.ADCAN3IF = 0;
}




/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
#ifdef NoUsed_Isr
static
void current_limit_handler()
{  
      

}
#endif
/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
static 
void App_SCP_ISR()
{

  if ( ( ADC.Vout < VOUT_1V && PS.Softstart == TRUE && HBLLC.MainEnabled && PS.SC_CheckStart && ADC.Iout > Parameter.SCP_FAULT_LIMIT ) ||
       ( ADC.Iout > Parameter.SCP_FAULT_LIMIT && ADC.Vout < VOUT_2V && PS.Softstart == FALSE && HBLLC.MainEnabled )
       )
  {
      if ( ! _SD_Flag.Val )
      {
         m_Emergency_PowerOff( );
          _SD_Flag.SCP_SD = 1;
          _SD_Flag.LATCH_SD = 1;

          gPagePlusStatus.PAGE[PAGE0].STATUS_IOUT.bits.IOUT_OC_WARNING = 1;
          gPagePlusStatus.PAGE[PAGE1].STATUS_IOUT.bits.IOUT_OC_WARNING = 1;
          gPagePlusStatus.PAGE[PAGE0].STATUS_IOUT.bits.IOUT_OC_FAULT = 1;
          gPagePlusStatus.PAGE[PAGE1].STATUS_IOUT.bits.IOUT_OC_FAULT = 1;
          SaveToBlackBox ( );
          PS.SC_CheckStart = 0;
      }
  }


}

#if remove  // redefine
/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _ADCAN4Interrupt ( )
{
  /*
PIN26:  AN5	12V_OUT_MCU
   */
  ADC.Vout = ADCBUF4;
  ADC.Vout_LPF = ADC.Vout_LPF + ADC.Vout - ADC.Vout_FF;
  ADC.Vout_FF = ADC.Vout_LPF >> 2;
 

#if SC_PROTECT
   // App_OCP_ISR();
#endif

  IFS7bits.ADCAN4IF = 0;

}
#endif
/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _ADCAN5Interrupt ( )
{
  /*
PIN26:  AN5	STB_I_OUT_MCU
   */
  ADC.StbIout = ADCBUF5;
  ADC.StbIout_LPF = ADC.StbIout_LPF + ADC.StbIout - ADC.StbIout_FF;
  ADC.StbIout_FF = ADC.StbIout_LPF >> 2;
 
 //SCP
#if SC_PROTECT
    App_SCP_ISR();
#endif

  IFS7bits.ADCAN5IF = 0;

}
/************************************************************************
 * author:                     WH
 * description:
 * input:                        
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/


void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _ADCAN7Interrupt ( )
{
  /*
   * PIN33:ADC_STB_5V_OUT
   */
  ADC.StbVout = ADCBUF7;//ADC_STB_5V_OUT ;
  
  ADC.StbVout_LPF = ADC.StbVout_LPF + ADC.StbVout - ADC.StbVout_FF;
  ADC.StbVout_FF = ADC.StbVout_LPF >> 2;
   

  
  if (  Tsb_off_delay > 200 ) 
  {
      if (Tsb_off_delay_Flag == 0 )
      {
        drv_DisableSTBoutput ( );
        Tsb_off_delay_Flag = 1;
      }   
  }

  IFS7bits.ADCAN4IF = 0;

}
/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _ADCAN12Interrupt ( )
{
  /*  PIN19:T_SR_MCU	10K NTC
   */
    ADC.Tsec = ADCBUF12;//ADC_T_SR_MCU;
    ADC.Tsec_LPF = ADC.Tsec_LPF + ADC.Tsec - ADC.Tsec_FF;
    ADC.Tsec_FF = ADC.Tsec_LPF >> 5;
    
#if DITHER_ENABLED
  {
      static BYTE cnt =  0;
      static WORD period = PWM_PERIOD_LOW;

      //Dither with 500Hz, 50/100
      //Dither with 2000Hz, 14/28
      if ( cnt >= 14 )
      {
          if ( cnt >= 28 )
          {
              cnt = 0;
          }
          else
          {
              cnt ++;

              if ( period < PWM_PERIOD_LOW )
              {
                 // period = period + DIFF_COUNT;
               period += DIFF_COUNT;  
              }
              PTPER = period;
              MDC = ( period >> 1 );
          }
      }
      else
      {
          cnt ++;

          if ( period > PWM_PERIOD_HIGH )
          {
              period = period - DIFF_COUNT;
          }
          PTPER = period;
          MDC = ( period >> 1 );
      }

  }
#endif
IFS7bits.ADCAN7IF = 0;
  IFS7 = IFS7 & 0b1111111111011111;
}

#if remove
/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _ADCAN18Interrupt ( )
{
    /* AN18	DACOUT1	DAC_OUT*/
}
#endif
/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
void __attribute__((__interrupt__,no_auto_psv)) _CNInterrupt(void)
// void __attribute__(interrupt, no_auto_psv) _CNInterrupt(void)
//void __attribute__ ((__interrupt__)) _CNInterrupt(void)
{         
 pin_o_ORING_EN_MCU  =iPS_ON;            // VDD of  MP6925GS 
 
 pin_o_AC_OK  =iAC_OK;    
 
 // Flag setup  as below
 
 
#if remove 
 if ( iAC_OK == AC_N_GOOD && ( ( _SD_Flag.STB_OCP == 0 ) && ( _SD_Flag.STB_OVP == 0 ) && ( _SD_Flag.STB_UVP == 0 ) ) /*&& (AcOffBlankingTime >= 5)*/ )    
      {
          if ( iPS_ON == P_N_OK )	// hbllc 
          {
                  gPagePlusStatus.PAGE[PS.isDCInput].STATUS_INPUT.bits.UNIT_OFF = 1;
                  if ( Real_Vac < Parameter.VIN_UV_WARN_LIMIT[PS.isDCInput] )
                  {
                      gPagePlusStatus.PAGE[PS.isDCInput].STATUS_INPUT.bits.VIN_UV_WARNING = 1;
                  }
                  if ( Real_Vac < Parameter.VIN_UV_FAULT_LIMIT[PS.isDCInput] )
                  {
                      gPagePlusStatus.PAGE[PS.isDCInput].STATUS_INPUT.bits.VIN_UV_FAULT = 1;
                  } 
          }
      }
#endif
 IFS1bits.CNIF = 0;     
}

/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void __attribute__((__interrupt__,no_auto_psv)) _OC1Interrupt(void)
{
/* Insert ISR Code Here*/
/* Clear Timer2 interrupt */
//IFS0bits.T2IF = 0;
}