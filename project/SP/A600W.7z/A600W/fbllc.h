#ifndef __HBLLC_H__
#define __HBLLC_H__

#include "Define.h"

#define KpCS 		Q15(0.04)	// 0.2 // 0.1		
#define KiCS  		Q15(0.04)	// 0.05 // 0.07
#define KdCS		Q15(0)		// 0.25

#define Q15_UNSIGN_MAX						32767  //(32767+1) /128   =256
#if CS_OPTIMIZTION_EN                                 //  Current Sharing optimization Enable
#define Q15_UNSIGN_MIN						-32767
#else                                                                     //  Current Sharing optimization Disable
#define Q15_UNSIGN_MIN						0
#endif

#define PID_CURRENTSHARE_KP 0.3        // 0.3
#define PID_CURRENTSHARE_KI 0.003	  // 0.003
#define PID_CURRENTSHARE_KD 0.25	  // 0.25

#define PID_CURRENTSHARE_A Q15(PID_CURRENTSHARE_KP + PID_CURRENTSHARE_KI + PID_CURRENTSHARE_KD)
#define PID_CURRENTSHARE_B Q15(-1 *(PID_CURRENTSHARE_KP + 2 * PID_CURRENTSHARE_KD))
#define PID_CURRENTSHARE_C Q15(PID_CURRENTSHARE_KD)

#if CS_OPTIMIZTION_EN                                              //  Current Sharing optimization Enable
#define PID_CURRENTSHARE_KP_SS  0.015           //  Current Sharing Issue modified,  //0.15      //original Parameter
#define PID_CURRENTSHARE_KI_SS	0.006    //  Current Sharing Issue modified,   //0.004     //original Parameter
#define PID_CURRENTSHARE_KD_SS	0.0          //  Current Sharing Issue modified,   //0.125     //original Parameter
#endif

#if 0 //  Current Sharing optimization Disable
#define PID_CURRENTSHARE_KP_SS  0.15     //original Parameter
#define PID_CURRENTSHARE_KI_SS	0.004    //original Parameter
#define PID_CURRENTSHARE_KD_SS	0.125    //original Parameter
#endif

#define PID_CURRENTSHARE_A_SS Q15(PID_CURRENTSHARE_KP_SS + PID_CURRENTSHARE_KI_SS + PID_CURRENTSHARE_KD_SS)
#define PID_CURRENTSHARE_B_SS Q15(-1 *(PID_CURRENTSHARE_KP_SS + 2 * PID_CURRENTSHARE_KD_SS))
#define PID_CURRENTSHARE_C_SS Q15(PID_CURRENTSHARE_KD_SS)


#define I_Error_ADD_L ( WORD ) ( ( ( DWORD ) 40 * IOUT_TO_ADC ) >> IOUT_TO_ADC_GAIN )     //  Current Sharing Issue modified
#define I_Error_ADD_H ( WORD ) ( ( ( DWORD ) 120 * IOUT_TO_ADC ) >> IOUT_TO_ADC_GAIN )    //  Current Sharing Issue modified

typedef struct _MyPID
{
  SHORT* abcCoefficients ; /* Pointer to A, B & C coefficients located in X-space */
                           /* These coefficients are derived from */
                           /* the PID gain values - Kp, Ki and Kd */
  SHORT* controlHistory ;  /* Pointer to 3 delay-line samples located in Y-space */
                           /* with the first sample being the most recent */
  SHORT controlOutput ;    /* PID Controller Output  */
  SHORT measuredOutput ;   /* Measured Output sample */
  SHORT controlReference ; /* Reference Input sample */
  BYTE  historyCount ;

} MyPID ;

typedef enum
{
  P_ENUM = 0 ,
  I_ENUM ,
  D_ENUM
} PID_ENUM ;

#define cSR_ON_DELAY		50	//ms
#define cSR_ON_IOUT_REFH_IM	(WORD)(((DWORD)60*IOUT_TO_ADC) >> IOUT_TO_ADC_GAIN)		// 60A
#define cSR_ON_IOUT_REFH	(WORD)(((DWORD)32*IOUT_TO_ADC) >> IOUT_TO_ADC_GAIN)		// 32A
#define cSR_ON_IOUT_REFL	(WORD)(((DWORD)27*IOUT_TO_ADC) >> IOUT_TO_ADC_GAIN)		// 27A

#define cSR_OFF_VOUT_REF	(((WORD)114*VOUT_TO_ADC)/10)	// 11.4V
#define cVOUT_REG_REFH		(((WORD)114*VOUT_TO_ADC)/10)	// 11.4V
#define cVOUT_REG_REFL		(((WORD)113*VOUT_TO_ADC)/10)	// 11.3V

/*Exported variable*/
extern SHORT gVoutCshareOffset ;

#if RS_ENABLE   
extern SHORT gVoutRSenseOffset ;
#endif

extern SHORT Iout_Real ;
extern SHORT CSHARE_AVG ;
extern SHORT CurrentShareABC_SS[3] ;

/*Exported function*/
void OutputControl ( ) ;
void CS_Control ( ) ;
void Disable_CurrentShare ( ) ;
void Enable_CurrentShare ( ) ;
void Current_Share ( void ) ;
void init_CurrentShareLoop ( void ) ;
#endif 

