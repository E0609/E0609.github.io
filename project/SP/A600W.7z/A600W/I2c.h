
#ifndef __I2C_H__
#define __I2C_H__


typedef enum//WH
{
    cmd_Page=0,
    cmd_Operation,
            cmd_no_ON_OFF_CONFIG,
    cmd_CLEAR_FAULTS,
            cmd_no_PHASE,
            cmd_no_PAGE_PLUS_WRITE=5,  // no used in delta
            cmd_no_PAGE_PLUS_READ,  // no used in delta
    cmd_CAPABILITY=0x19,
    cmd_Query,
            cmd_no_SMBALERT_MASK,
    cmd_VOUT_MODE=0x20,
            cmd_no_COEFFICIENTS=0x30,
     cmd_FAN_CONFIG_1_2=0x3A,
    cmd_FAN_COMMAND_1,  
    cmd_VOUT_OV_FAULT_LIMIT=0x40,
     cmd_VOUT_OC_FAULT_LIMIT=0x46,       
     cmd_VOUT_OC_WARM_LIMIT=0x4A,       
    cmd_OT_FAULT_LIMIT=0x4F, 
    cmd_OT_WARM_LIMIT=0x51,         
            
    cmd_STATUS_BYTE =0x78,
    cmd_STATUS_WORD,
    cmd_STATUS_VOUT,
    cmd_STATUS_IOUT,       
    cmd_STATUS_INPUT,
    cmd_STATUS_TEMPERATURE, 
    cmd_STATUS_CML,
    cmd_STATUS_OTHER,
    cmd_STATUS_SPECIFIC,
    cmd_STATUS_FAN_1_2 ,
         cmd_no_READ_EIN =0x86,   // no used in delta
         cmd_no_READ_EOUT =0x87,   // no used in delta       
    cmd_READ_VIN=0x88,
            
    cmd_READ_VCAP=0x8A,
    cmd_READ_VOUT,
    cmd_READ_IOUT,
    cmd_READ_TEMPERATURE_1,
    cmd_READ_TEMPERATURE_2,
    cmd_READ_TEMPERATURE_3,
    cmd_READ_FAN_SPEED_1,
    cmd_READ_POUT=0x96,
     cmd_PMBUS_REVISION=0x98,
            
    cmd_MFR_VIN_MIN=0xA0,
     cmd_MFR_VIN_MAX,
     cmd_MFR_IIN_MAX,
     cmd_MFR_PIN_MAX,  
     cmd_MFR_VOUT_MIN,
     cmd_MFR_VOUT_MAX,
     cmd_MFR_IOUT_MAX, 
     cmd_MFR_POUT_MAX,  
     cmd_MFR_TAMBIENT_MAX,  
     cmd_MFR_TAMBIENT_MIN,   
         cmd_no_GEN_CAL_R = 0xBE,   
    cmd_UNLOCK_COMMAND=0xD8,
    cmd_REMOTE_ON_LEVEL_SELECT
}Status_Cmd;
typedef enum _I2C_CMD_DIR
{
  CMD_W = 0 ,
  CMD_R ,
} eI2C_CMD_DIR ;

typedef enum _I2C_STATE
{
  STATE_WAIT_FOR_ADDR = 0 ,
  STATE_WAIT_FOR_CMD ,
  STATE_WAIT_FOR_WRITE_DATA ,
  STATE_SEND_READ_DATA ,
  STATE_SEND_READ_LAST ,
  STATE_WRITE_ERROR ,
} eI2C_STATE ;

typedef struct _D_I2C_DATA
{
  BYTE* pRxBuf ;
  BYTE* pTxBuf ;
  BYTE currentCmd ;
  BYTE cmdDir ;
  BYTE isPecFail ;
  BYTE state ;
  BYTE dataIndex ;
  BYTE readBuffer[50] ;
  BYTE PEC ;
  BYTE isBlockMode ;
  BYTE accessNotAllow ;
  BYTE PermitToWrite ;
} tD_I2C_DATA ;

//Exported function
void init_I2C ( ) ;
void HoldSCL ( ) ;
void ReleaseSCL ( ) ;
void GetI2cAddr ( ) ;
void CheckI2COV ( ) ;

extern BYTE OneTimeFlag_HotPlug ;    // For PSON

#endif

