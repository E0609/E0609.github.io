/*****************************************************************************************
 *
 *Copyright (C) 2021 CIPS Singapore

 *                   LITE-ON TECHNOLOGY Corp.
 *
 *All Rights Reserved
 *
 *File Name : Init.c
 *
 *Date : 2021.01.20
 *
 *Author :              WH
 *
 *Description :This Program used for HP 2400W Inital Status Program.
 *
 *******************************************************************************************/

#include "p33Exxxx.h"
#include "p33EP64GS504.h"
#include "define.h"
#include "Init.h"
#include "Userdata.h"
#include "Isr.h"
#include "Process.h"

#define PIN_PWM 1
extern tPS_FLAG PS;
extern SHORT gVoutCmd;

static void  adc_clk_Setup();
static void calibrateADC();
static void adc_resolution_Setup(void);
static void adc_triggle_Setup();
static void  adc_triggle_Setup();
 static void  adc_isr_Setup();

#if 0
 void Mcu_SysClkHwInit(void);

/*******************************************************************************
 * \brief         Initialize the System and the MCU Clock
 *                Called by startup in main
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 ******************************************************************************/
void Mcu_SysClkHwInit(void)
{
  /* Initialize Fosc */
#if defined(FRC_OSC)
  /* Oscillator configuration
   *  Configure Oscillator to operate the device at 60Mhz
   *  Fosc= Fin * M / (N1 * N2), Fcy = Fosc / 2
   *  Fosc= 7.37MHz * 65 / (2 * 2) = 119.7625Mhz for Fosc, Fcy = 59.88125Mhz
   */

  /* Configure PLL prescaler, PLL postscaler, PLL divisor */
  PLLFBD = 63; /* M = PLLDIV + 2 = 65 */
  CLKDIVbits.PLLPOST = 0; /* N2 = 2 * (PLLPOST + 1) = 2 */
  CLKDIVbits.PLLPRE = 0; /* N1 = PLLPRE + 2 = 2 */
  __builtin_write_OSCCONH(0x01); /* New Oscillator FRC w/ PLL */
  __builtin_write_OSCCONL(0x01); /* Enable Switch */

  /* Wait for new Oscillator to become FRC w/ PLL */
  while (OSCCONbits.COSC != 0b001);
  /* Wait for Pll to Lock */
  while (OSCCONbits.LOCK != 1);
#endif
  // Setup the ADC and PWM clock for 120MHz
  // ((FRC * 16) / APSTSCLR ) = (7.37MHz * 16) / 1 = 117.92MHz

  ACLKCONbits.FRCSEL = 1; // FRC provides input for Auxiliary PLL (x16)
  ACLKCONbits.SELACLK = 1; // Aux Osc. provides clock source for PWM & ADC
  ACLKCONbits.APSTSCLR = 7; // Divide Auxiliary clock by 1
  ACLKCONbits.ENAPLL = 1; // Enable Auxiliary PLL

  while (ACLKCONbits.APLLCK != 1); // Wait for Auxiliary PLL to Lock
}
 
#endif
void init_SetupClock ( void )
{

#if 1
    // FRCDIV FRC/1; PLLPRE 2; DOZE 1:8; PLLPOST 1:2; DOZEN disabled; ROI disabled; 
    CLKDIV = 0x3000;
    // TUN Center frequency; 
    OSCTUN = 0x00;
    // ROON disabled; ROSEL FOSC; RODIV 0; ROSSLP disabled; 
    REFOCON = 0x00;
    // PLLDIV 63; 
    PLLFBD = 0x3F;
    // ENAPLL enabled; APSTSCLR 1:1; APLLCK disabled; FRCSEL FRC; SELACLK Auxiliary Oscillators; ASRCSEL No clock input; 
    ACLKCON = 0xA740;
    // LFSR 0; 
    LFSR = 0x00;
    // ADCMD enabled; T3MD enabled; T4MD enabled; T1MD enabled; U2MD enabled; T2MD enabled; U1MD enabled; SPI2MD enabled; SPI1MD enabled; PWMMD enabled; T5MD enabled; I2C1MD enabled; 
    PMD1 = 0x00;
    // IC4MD enabled; IC3MD enabled; OC1MD enabled; IC2MD enabled; OC2MD enabled; IC1MD enabled; OC3MD enabled; OC4MD enabled; 
    PMD2 = 0x00;
    // CMPMD enabled; I2C2MD enabled; 
    PMD3 = 0x00;
    // PWM2MD enabled; PWM1MD enabled; PWM4MD enabled; PWM3MD enabled; PWM5MD enabled; 
    PMD6 = 0x00;
    // CMP3MD enabled; CMP4MD enabled; PGA1MD enabled; CMP1MD enabled; CMP2MD enabled; 
    PMD7 = 0x00;
    // CCSMD enabled; PGA2MD enabled; ABGMD enabled; 
    PMD8 = 0x00;
    // CF no clock failure; NOSC FRCPLL; CLKLOCK unlocked; OSWEN Switch is Complete; 
    __builtin_write_OSCCONH((uint8_t) (0x01));
    __builtin_write_OSCCONL((uint8_t) (0x01));
    // Wait for Clock switch to occur
    while (OSCCONbits.OSWEN != 0);
    while (OSCCONbits.LOCK != 1);
    
    
    
    
#endif
#if 0
  PLLFBD = 41;    
  CLKDIVbits.PLLPOST = 0;                          // PLLPOST (N1) 0=/2
  
  /*  __builtin_write_OSCCONH(0x01); >> now the PLL is configured.
  set the value for {COSC, NOSC} with this function to switch to FRC with PLL*/
  __builtin_write_OSCCONH ( 0x01 );
  
/*__builtin_write_OSCCONL(0x01);   >>  // Tell the CPU to perform the clock switch.*/
  __builtin_write_OSCCONL ( 0x01 );
  while ( OSCCONbits.COSC != 0b001 );
  while ( OSCCONbits.LOCK != 1 );
  ACLKCON = 0xA740;		                    //     devided by 32          1010 0111 0100 0000   
  _ENAPLL = 1;                                                // enable APLL
  _SELACLK =1;   
  
  _ASRCSEL =1;
  _FRCSEL=1;//
  
  while ( ACLKCONbits.APLLCK != 1 );       // waiting for lock status
  
  
  ]
#endif
#if 0
    #if defined(FRC_OSC)
    /* Configure PLL prescaler, PLL postscaler, PLL divisor */
  PLLFBD = 63; /* M = PLLDIV + 2 = 65 */
  CLKDIVbits.PLLPOST = 0; /* N2 = 2 * (PLLPOST + 1) = 2 */
  CLKDIVbits.PLLPRE = 0; /* N1 = PLLPRE + 2 = 2 */
  
  __builtin_write_OSCCONH(0x01); /* New Oscillator FRC w/ PLL */
  __builtin_write_OSCCONL(0x01); /* Enable Switch */

  /* Wait for new Oscillator to become FRC w/ PLL */
  while (OSCCONbits.COSC != 0b001);
  /* Wait for Pll to Lock */
  while (OSCCONbits.LOCK != 1);
#endif
  // Setup the ADC and PWM clock for 120MHz
  // ((FRC * 16) / APSTSCLR ) = (7.37MHz * 16) / 1 = 117.92MHz

  ACLKCONbits.FRCSEL = 1; // FRC provides input for Auxiliary PLL (x16)
  ACLKCONbits.SELACLK = 1; // Aux Osc. provides clock source for PWM & ADC
  ACLKCONbits.APSTSCLR = 7; // Divide Auxiliary clock by 1
  ACLKCONbits.ENAPLL = 1; // Enable Auxiliary PLL

  while (ACLKCONbits.APLLCK != 1); // Wait for Auxiliary PLL to Lock
#endif
}


/*******************************************************************************
 * Function:        pwm1_fan_init
 * author:          WH
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     PWM FAN init
 * history:
 ******************************************************************************/

static void adc_averagingmode_Setup(void)
{
  /********************************************/
  /* Configure averaging mode for FB AD */
  ADFL0CONbits.OVRSAM = 0b010;  //15-bit result (12.3 format)
  ADCON4Lbits.SAMC1EN = 1;      //Core 1 delay enable
  ADCORE1Lbits.SAMC = 6;        //8 t_ADCORE
  ADFL0CONbits.FLCHSEL = 1;     //AN1
  ADFL0CONbits.MODE = 0b11;     //Averaging mode
  ADFL0CONbits.FLEN = 1;        //Enable filter

}
//------------------------------------ GPIO ------------------------------------------------

/*******************************************************************************
 * Name:         
 * Description:  
 * param[in]:     
 * param[in,out]: 
 * param[out]:  
 * return value:
 * author:                     WH
 * Version:
 * Date:
 * History:
 *******************************************************************************/

static void port_A_config()
{
   LATA = 0x0000;
   TRISA = 0xffff;   
   ANSELA = 0x0000; 

     /* PIN21 for  AN_12V_ORING_MCU*/
   _TRISA0 = MG_PIN_INPUT_DIRECTION;
   _ANSA0 = MG_PIN_ANALOG;
   
    /* PIN22 for  I_OUT_MCU*/
   _TRISA1 = MG_PIN_INPUT_DIRECTION;
   _ANSA1 = MG_PIN_ANALOG;
  
  /* PIN23 for  CS_OUT_MCU*/
   _TRISA2 = MG_PIN_INPUT_DIRECTION;
   _ANSA2 = MG_PIN_ANALOG;
   
     /* PIN13 for  LLC_EN_MCU*/
   _TRISA3 = MG_PIN_OUTPUT_DIRECTION;
   
        /* PIN14 for  FAM_PWM*/
   _TRISA4 = MG_PIN_OUTPUT_DIRECTION;
   
} 
/*******************************************************************************
 * Name:         Mcu_GPIOHwInit
 * Description:  gpio direction/analogue configuration
 * param[in]     -
 * param[in,out] -
 * param[out]  
 * return value:
 * author:                     WH
 * Version:
 * Date:
 * History:
 *******************************************************************************/

static void port_B_config()
{
   LATB = 0x0000;
   TRISB = 0xffff;   
   ANSELB = 0x0000;
   
   /* PIN24 for  ISHARE_IN*/
   _TRISB0 = MG_PIN_INPUT_DIRECTION;
   _ANSB0 = MG_PIN_ANALOG;

     /* PIN32 for 12V_ORING_EN_MCU*/
   _TRISB1 = MG_PIN_OUTPUT_DIRECTION;
   _ANSB1 = MG_PIN_DIGITAL;
   
   /* PIN33 for  STB_5V_OUT_MCU*/
   _TRISB2 = MG_PIN_INPUT_DIRECTION;
   _ANSB2 = MG_PIN_ANALOG;

   /* Reserved DACOUT  Pin 34*/
   _TRISB3 = MG_PIN_OUTPUT_DIRECTION;
   _ANSB3 = MG_PIN_ANALOG;

   /* PIN35 for  ISHARE_DIS*/
   _TRISB4 = MG_PIN_INPUT_DIRECTION;
   
   /* PIN43 for  LED1*/
   _TRISB5 = MG_PIN_OUTPUT_DIRECTION;
      
   /* EEPROM SDA_INTERNAL Pin39*/
   _TRISB8 = MG_PIN_INPUT_DIRECTION; 
      /* PIN25 for  12V_OUT_MCU*/
   _TRISB9 = MG_PIN_INPUT_DIRECTION;
   _ANSB9 = MG_PIN_ANALOG;
   /* PIN8 for  S_BUG*/
   _TRISB11 = MG_PIN_OUTPUT_DIRECTION;
     /* PIN9 for  POK*/
   _TRISB12 = MG_PIN_OUTPUT_DIRECTION;
   /* PIN26 for  12V_SOFT_TRIM*/
   _TRISB13 = MG_PIN_OUTPUT_DIRECTION;
   //_ANSB13 = MG_PIN_ANALOG;                               //PWM2H
  /* PIN11 for  FAN SPEED*/
   _TRISB14 = MG_PIN_INPUT_DIRECTION;
      /* EEPROM SCL_INTERNAL Pin42*/
   _TRISB15 = MG_PIN_INPUT_DIRECTION; 
   
  // 1100001100010101
}
/*******************************************************************************
 * Name:                    port_C_config
 * Description:        
 * param[in]     -
 * param[in,out] -
 * param[out]  
 * return value:
 * author:                     WH               WH
 * Version:
 * Date:
 * History:
 *******************************************************************************/

static void port_C_config()
{
    LATC = 0x0000;
	TRISC = 0xffff;   
	ANSELC = 0x0000;
  /* PIN 14 for  AC_OK_SEC*/
   _TRISC0 = MG_PIN_INPUT_DIRECTION;
   /* PIN31 for  STB_EN_MCU*/
   _TRISC1 = MG_PIN_OUTPUT_DIRECTION; 
   
     /* PIN 36 for  PIN_ACOK_OUT*/
   _TRISC2 = MG_PIN_OUTPUT_DIRECTION;
   
  /* PIN 5,2,3 for I2C Address selection*/
   _TRISC3 = MG_PIN_INPUT_DIRECTION;
   _TRISC4 = MG_PIN_INPUT_DIRECTION;
   _TRISC5 = MG_PIN_INPUT_DIRECTION;
   
  /* PIN 4 for PSON_MCU*/
   _TRISC6 = MG_PIN_INPUT_DIRECTION;

  /* PMBUS_SDA Pin37 */
  _TRISC7 = MG_PIN_INPUT_DIRECTION;
  /* PMBUS_SCL Pin38 */
  _TRISC8 = MG_PIN_INPUT_DIRECTION;
  
  /* UART_RX Pin27 */
   _TRISC9 = MG_PIN_INPUT_DIRECTION;
  /* UART_TX Pin28 */
  _TRISC10 = MG_PIN_OUTPUT_DIRECTION;
   
  /* PIN 19 for T_SR_MCU*/
   _TRISC11 = MG_PIN_INPUT_DIRECTION;
    _ANSC11 = MG_PIN_ANALOG;
  /* PIN 20 for SR_EN_MCU*/
   _TRISC12 = MG_PIN_OUTPUT_DIRECTION;
   
  /* PIN 15 for PFC_OK_SEC*/
   _TRISC13 = MG_PIN_INPUT_DIRECTION;

   //0010 1011 11111001
   /*
   * Set PORTx as open-drain or push-pull
   * 1 = open-drain (5V)
   * 0 = push-pull  (default)
   */
   #if 1
  _ODCC8 = 1;  // uC_SCL
  _ODCC7 = 1;  // uC_SDA
  _ODCB8= 1;   //uC_SDA_Internal
  _ODCB15 = 1; //uC_SCL_Internal
    #endif
}
/*******************************************************************************
 * Name:                    Mcu_GPIOHwInit
 * Description:        
 * param[in]     -
 * param[in,out] -
 * param[out]  
 * return value:
 * author:                     WH               
 * Version:
 * Date:
 * History:
 *******************************************************************************/
static void Init_uart_RemapPin(void)
{
  __builtin_write_OSCCONL(OSCCON & 0xbf); /* Unlock register for remap pin configuration */
    _U1RXR = 57;                                                            /* Assign U1Rx to pin RP57/pin 27 */ 
   _RP58R= 1;                                                                 /* Assign U1Tx to pin RP58/ pin 28 */
  __builtin_write_OSCCONL(OSCCON | 0x40);     /* Lock register */
}
/*******************************************************************************
 * Name:                    init_CMP()
 * Description:        
 * param[in]     -
 * param[in,out] -
 * param[out]  
 * return value:
 * author:                 WH              
 * Version:
 * Date:
 * History:
 *******************************************************************************/
static
void init_CMP()
{
    /* ~~~~~~~~~~~~~~~~~~~~~~~~ CMP1C Configuration ~~~~~~~~~~~~~~~~~~~~~~~~~~ */
    CMP1CONbits.INSEL = 2;               /* 2=Select CMP1C input  PIN23, 12_OUT_MCU*/
                                                                 /*  1=Select CMP1B input  PIN22, I_OUT_MCU*/
    
    CMP1CONbits.EXTREF = 0;              /* Choose internal reference */
    CMP1DAC = 0x07FF;                         /* Choose comparator reference voltage 0x01FF = AVdd/4 ,AVdd/2 =0x03FF ,AVdd =7ff */
  //  CMP1DACbits.CMREF =0x07FF;  
 
   CMP1CONbits.HYSSEL = 3;   // 45 mV hysteresis selected
   CMP1CONbits.HYSPOL = 0;   // Hysteresis is applied to rising edge of the

    // reference on interveiw
   TRISBbits.TRISB3 = 1; // DAC output
   CMP1CONbits.DACOE = 1; // output the DAC voltage
   CMP1CONbits.RANGE = 1; // even though "unimplemented", MUST set to "1"    /* Max DAC voltage = AVdd */
   CMP1CONbits.CMPON = 1; // turn on the comparator
 
}
/*******************************************************************************
 * Name:                    Mcu_GPIOHwInit
 * Description:        
 * param[in]     -
 * param[in,out] -
 * param[out]  
 * return value:
 * author:                     WH               
 * Version:
 * Date:
 * History:
 *******************************************************************************/
void init_GPIO ( void )
{
     port_A_config();
     port_B_config();
     port_C_config();
     Init_uart_RemapPin();    
     pin_o_LED_ON = LED_OFF;
     init_CMP();
     
     
#if PSON_ENABLE
#else
     _SD_Flag.PS_ON_OFF = TRUE;
#endif  
#ifdef RS_ENABLE   
      pin_o_ORING_EN_MCU  =0;// iPS_ON;
#endif
pin_o_SR_EN   = SR_ON;   // always in this  solution

//init_Input_CN();

}

/*******************************************************************************
 * Name:                    Mcu_GPIOHwInit
 * Description:        
 * param[in]     -
 * param[in,out] -
 * param[out]  
 * return value:
 * author:                     WH               WH
 * Version:
 * Date:
 * History:
 *******************************************************************************/

void init_Timer ( void )
{
  //------ Timer1:1ms  ------
  PR1 = 40000; /* Period Register 1 40000/1000us=40/us */
  IEC0bits.T1IE = 1;
  T1CONbits.TON = 1;

  //------ Timer1:20us for ADC  sample and conversion------
  PR2 = 800;
  T2CONbits.TON = 1;
  IEC0bits.T2IE = 1;   //added by wh for test
  
  //------ Timer3: for Fan RPM    ------
  T3CONbits.TCKPS = 3;
  T3CONbits.TON = 1;
#if 1
  //------ Timer4:8us for I2C write cmd------//8us = (8MHz*64*1)//16us = (8MHz*64*2)
  PR4 = 1;
  T4CON = 0;
  T4CONbits.TCKPS = 2;


  IPC6bits.T4IP = 4;
  IFS1bits.T4IF = 0;
  IEC1bits.T4IE = 1;
  T4CONbits.TON = 1;
#endif
  //------ Timer5:100ms for scanprocess  ,I2C buffer cache issue------
  PR5 = 15625;
  T5CONbits.TCKPS = 3;
  IPC7bits.T5IP = 3;
  IEC1bits.T5IE = 1;
  T5CONbits.TON = 1;
}

/*******************************************************************************
 * Function:        adc_resolution_Setup
 * author:          WH
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     PWM FAN init
 * history:
 ******************************************************************************/

static void adc_resolution_Setup(void)
{
#define bit12_resolution 3
#define unsigned_int_mode 0
    
  /* Shared ADC Core*/
  ADCON1Hbits.SHRRES = bit12_resolution;
  /* Core 0 ADC Core*/
  ADCORE0Hbits.RES = bit12_resolution;
  /* Core 1 ADC Core*/
  ADCORE1Hbits.RES = bit12_resolution;
  /* Core 2 ADC Core*/
  ADCORE2Hbits.RES = bit12_resolution;
  /* Core 3 ADC Core*/
  ADCORE3Hbits.RES = bit12_resolution;
  /* Shared ADC Core sample time 4Tad */
  ADCON2Hbits.SHRSAMC = 2;
  
  ADCON1Hbits.FORM =unsigned_int_mode;

}

/*******************************************************************************
 * Function:        pwm1_fan_init
 * author:          WH
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     PWM FAN init
 * history:
 ******************************************************************************/
static void adc_triggle_Setup()
{
#if 0
    #define triggered_by_TIMER2 31
    #define triggered_by_TIMER1 12
           _TRGSRC0 = triggered_by_TIMER2;
           _TRGSRC1 = triggered_by_TIMER2;
           _TRGSRC2 = triggered_by_TIMER2;     
           _TRGSRC3 = triggered_by_TIMER2;
           _TRGSRC4 = triggered_by_TIMER2;
           _TRGSRC5 = triggered_by_TIMER2;
           _TRGSRC6 = triggered_by_TIMER2;
           _TRGSRC7 = triggered_by_TIMER2;
       /* ADC AN4 50V_OUT (after Oring)*/
	  _TRGSRC18 = triggered_by_TIMER2;
#else
       //TRGSRC0 TMR2; TRGSRC1 TMR2; 
    ADTRIG0L = 0xD0D;
    //TRGSRC3 TMR2; TRGSRC2 TMR2; 
    ADTRIG0H = 0xD0D;
    //TRGSRC4 TMR2; TRGSRC5 TMR2; 
    ADTRIG1L = 0xD0D;
    //TRGSRC6 None; TRGSRC7 TMR2; 
    ADTRIG1H = 0xD00;
    //TRGSRC8 None; TRGSRC9 None; 
    ADTRIG2L = 0x00;
    //TRGSRC11 None; TRGSRC10 None; 
    ADTRIG2H = 0x00;
    //TRGSRC12 TMR2; 
    ADTRIG3L = 0x0D;
    //TRGSRC14 None; 
    ADTRIG3H = 0x00;
    //TRGSRC17 None; 
    ADTRIG4L = 0x00;
    //TRGSRC19 None; TRGSRC18 None; 
    ADTRIG4H = 0x00;
    //TRGSRC20 None; TRGSRC21 None; 
    ADTRIG5L = 0x00;
#endif
	 
}
/*******************************************************************************
 * Function:        pwm1_fan_init
 * author:          WH
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     PWM FAN init
 * history:
 ******************************************************************************/
static void adc_isr_Setup()
{
   IFS6bits.ADCAN0IF = 0;
  IPC27bits.ADCAN0IP= 5;
  IEC6bits.ADCAN0IE = 1;

  IFS6bits.ADCAN1IF = 0;
  IPC27bits.ADCAN1IP = 5;
  IEC6bits.ADCAN1IE = 1;
  IFS7bits.ADCAN2IF = 0;

  IPC28bits.ADCAN2IP = 3;
  IEC7bits.ADCAN2IE = 1;

  IFS7bits.ADCAN4IF = 0;
  IPC28bits.ADCAN4IP = 3;
  IEC7bits.ADCAN4IE = 1;

  IFS7bits.ADCAN5IF = 0;
  IPC28bits.ADCAN5IP = 5;
  IEC7bits.ADCAN5IE = 1;

  IFS9bits.ADCAN12IF = 0;
  IPC38bits.ADCAN12IP = 5;
  IEC9bits.ADCAN12IE = 1;

  IFS7bits.ADCAN7IF = 0;
  IPC29bits.ADCAN7IP = 5;
  IEC7bits.ADCAN7IE = 1;   

    
  /* Enable ADC Common Interrupt */
 
  ADIELbits.IE2 = 1;
   _IE2 = 1;
   
   
    // Clearing channel_AN4 interrupt flag.
    IFS7bits.ADCAN4IF = 0;
    // Enabling channel_AN4 interrupt.
    IEC7bits.ADCAN4IE = 1;
    // Clearing channel_AN5 interrupt flag.
    IFS7bits.ADCAN5IF = 0;
    // Enabling channel_AN5 interrupt.
    IEC7bits.ADCAN5IE = 1;
    // Clearing channel_AN7 interrupt flag.
    IFS7bits.ADCAN7IF = 0;
    // Enabling channel_AN7 interrupt.
    IEC7bits.ADCAN7IE = 1;
    // Clearing channel_AN12 interrupt flag.
    IFS9bits.ADCAN12IF = 0;
    // Enabling channel_AN12 interrupt.
    IEC9bits.ADCAN12IE = 1;
    // Clearing channel_AN0 interrupt flag.
    IFS6bits.ADCAN0IF = 0;
    // Enabling channel_AN0 interrupt.
    IEC6bits.ADCAN0IE = 1;
    // Clearing channel_AN1 interrupt flag.
    IFS6bits.ADCAN1IF = 0;
    // Enabling channel_AN1 interrupt.
    IEC6bits.ADCAN1IE = 1;
    // Clearing channel_AN2 interrupt flag.
    IFS7bits.ADCAN2IF = 0;
    // Enabling channel_AN2 interrupt.
    IEC7bits.ADCAN2IE = 1;
    // Clearing channel_AN3 interrupt flag.
    IFS7bits.ADCAN3IF = 0;
    // Enabling channel_AN3 interrupt.
    IEC7bits.ADCAN3IE = 1;
  
}

void init_ADC ( void )
{
  /*
  AN0:	AN_12V_ORING_MCU
AN1	I_OUT_MCU
AN2	12V_OUT_MCU
AN3	ISHARE_IN
AN4	STB_5V_OUT_MCU
AN5	STB_I_OUT_MCU
AN6	CS_OUT_READ
AN7	T_SR_MCU

   */
   adc_clk_Setup();
   adc_resolution_Setup();
   adc_averagingmode_Setup();
   ADMOD0L = 0x0000;
   calibrateADC();
   adc_triggle_Setup();
   adc_isr_Setup();

  _ADON=1;   //ON
  IFS7 = IFS7 & 0b1111111111011111;
 // IPC29 = IPC29 | 0b0000000000110000;	
  IEC7 = IEC7 | 0b0000000000100000;

}

/*******************************************************************************
 * Function:        adc_clk_Setup
 * author:          WH
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     adc_clk_Setup
 * history:
 ******************************************************************************/
static void adc_clk_Setup(void )
{
   /* Setup ADC Clock Input Max speed of 60 MHz --> Fosc = 120 MHz */
  /* 0-Fsys, 1-Fosc(system_clock * 2), 2-FRC, 3-APLL */
    
  ADCON3Hbits.CLKSEL = 1;
  ADCON3Hbits.CLKDIV = 0;          /* Global Clock divider (1:1) */
  ADCORE0Hbits.ADCS = 0;            /* Core 0 clock divider (1:2) */
  ADCORE1Hbits.ADCS = 0;             /* Core 1 clock divider (1:2) */
  ADCORE2Hbits.ADCS = 0;            /* Core 2 clock divider (1:2) */
  ADCORE3Hbits.ADCS = 0;            /* Core 3 clock divider (1:2) */
  ADCON2Lbits.SHRADCS = 0;       /* 1/2 clock divider */
  ADCON1Hbits.FORM = 0;             /* Integer format */
  ADCON3Lbits.REFSEL = 0;           /* AVdd as voltage reference */

}

/*******************************************************************************
 * \brief         configure the ADC's
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
static 
void calibrateADC()
{
  /*
   * Power Up delay: 2048 Core Clock Source Periods (TCORESRC) for all ADC cores
   * (~14.6 us)
   */
  _WARMTIME = 11;

  /* Turn on ADC module */
  ADCON1Lbits.ADON = 1;
  /* power-on delay time */
  ADCON5Hbits.WARMTIME = 11; 
  /* Turn on analog power for dedicated core 0 */
  ADCON5Lbits.C0PWR = 1;
  while (ADCON5Lbits.C0RDY == 0);
  /* Enable ADC core 0 */
  ADCON3Hbits.C0EN = 1;

  /* Turn on analog power for dedicated core 1 */
  ADCON5Lbits.C1PWR = 1;
  while (ADCON5Lbits.C1RDY == 0);
  /* Enable ADC core 1 */
  ADCON3Hbits.C1EN = 1;

  /* Turn on analog power for dedicated core 2 */
  ADCON5Lbits.C2PWR = 1;
  while (ADCON5Lbits.C2RDY == 0);
  /* Enable ADC core 2 */
  ADCON3Hbits.C2EN = 1;

  /* Turn on analog power for dedicated core 3 */
  ADCON5Lbits.C3PWR = 1;
  while (ADCON5Lbits.C3RDY == 0);
  /* Enable ADC core 3 */
  ADCON3Hbits.C3EN = 1;

  /* Turn on analog power for shared core */
  ADCON5Lbits.SHRPWR = 1;
  while (ADCON5Lbits.SHRRDY == 0);
  /* Enable shared ADC core */
  ADCON3Hbits.SHREN = 1;

  /* Enable calibration for the dedicated core 0 */
  ADCAL0Lbits.CAL0EN = 1;
  /* Single-ended input calibration */
  ADCAL0Lbits.CAL0DIFF = 0;
  /* Start Cal */
  ADCAL0Lbits.CAL0RUN = 1;
  while (ADCAL0Lbits.CAL0RDY == 0);
  /* Cal complete */
  ADCAL0Lbits.CAL0EN = 0;

  /* Enable calibration for the dedicated core 1 */
  ADCAL0Lbits.CAL1EN = 1;
  /* Single-ended input calibration */
  ADCAL0Lbits.CAL1DIFF = 0;
  /* Start Cal */
  ADCAL0Lbits.CAL1RUN = 1;
  while (ADCAL0Lbits.CAL1RDY == 0);
  /* Cal complete */
  ADCAL0Lbits.CAL1EN = 0;

  /* Enable calibration for the dedicated core 2 */
  ADCAL0Hbits.CAL2EN = 1;
  /* Single-ended input calibration */
  ADCAL0Hbits.CAL2DIFF = 0;
  /* Start Cal */
  ADCAL0Hbits.CAL2RUN = 1;
  while (ADCAL0Hbits.CAL2RDY == 0);
  /* Cal complete */
  ADCAL0Hbits.CAL2EN = 0;

  /* Enable calibration for the dedicated core 3 */
  ADCAL0Hbits.CAL3EN = 1;
  /* Single-ended input calibration */
  ADCAL0Hbits.CAL3DIFF = 0;
  /* Start Cal */
  ADCAL0Hbits.CAL3RUN = 1;
  while (ADCAL0Hbits.CAL3RDY == 0);
  /* Cal complete */
  ADCAL0Hbits.CAL3EN = 0;

  /* Enable calibration for the shared core */
  ADCAL1Hbits.CSHREN = 1;
  /* Single-ended input calibration */
  ADCAL1Hbits.CSHRDIFF = 0;
  /* Start calibration cycle */
  ADCAL1Hbits.CSHRRUN = 1;
  /* while calibration is still in progress */
  while (ADCAL1Hbits.CSHRRDY == 0);
  /* Calibration is complete */
  ADCAL1Hbits.CSHREN = 0;
}





//------------------------------------ init_PWM ------------------------------------------------
/*******************************************************************************
 * Function:        
 * author:          WH
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     
 * history:
 ******************************************************************************/

/**
 * 12	PWM1H	FAN_PWM
22	PWM2H	12V_SOFT_TRIM
 */
//static 
void init_PWM_FAN()
{
   _TRISA4 = 0x0000;
   
#if 0
  IOCON1bits.PENH = PIN_PWM;						
  IOCON1bits.PMOD = 3;			
  PWMCON1bits.MDCS = 0;
  PWMCON1bits.DTC = 2;			
  PWMCON1bits.ITB = 1;			
  FCLCON1bits.FLTMOD = 3;
  PHASE1 = 33000;
  /*  PDCx: PWM GENERATOR DUTY CYCLE x REGISTER*/
  PDC1 = 0;//1000;//0;
#endif
  
  
#if  1
  /* Set PWM Period on Primary Time Base */
PTPER = 1000;
/* Set Phase Shift */
PHASE1 = 0;
SPHASE1 = 100;
PHASE2 = 200;
SPHASE2 = 300;
PHASE3 = 400;
SPHASE3 = 500;
/* Set Duty Cycles */
PDC1 = 100;
SDC1 = 200;
PDC2 = 300;
SDC2 = 400;
PDC3 = 500;
SDC3 = 600;
/* Set Dead Time Values */
DTR1 = DTR2 = DTR3 = 0;
ALTDTR1 = ALTDTR2 = ALTDTR3 = 0;
/* Set PWM Mode to Independent */
IOCON1 = IOCON2 = IOCON3 = 0xCC00;
/* Set Primary Time Base, Edge-Aligned Mode and Independent Duty Cycles */
PWMCON1 = PWMCON2 = PWMCON3 = 0x0000;
/* Configure Faults */
FCLCON1 = FCLCON2 = FCLCON3 = 0x0003;
/* 1:1 Prescaler */
PTCON2 = 0x0000;
/* Enable PWM Module */
PTCON = 0x8000;
  
#endif
}

/*******************************************************************************
 * Function:        
 * author:          WH
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     
 * history:
 ******************************************************************************/

static
void init_PWM_12V_TRIM()
{
     //PWM 2 configuration				 //True Independent Mode
  /*
  PWM2H : 12V_REF
   */
    
     _TRISB13 = 0x0000;  
 
  IOCON2bits.PENH = PIN_PWM;					
  IOCON2bits.PMOD = 3;			//PWMin the True Independent Output mode
  IOCON1bits.FLTDAT = 0;                              /* Turn OFF both PWM1 outputs in case of a fault condition */

  PWMCON1bits.DTC = 2;                                /* Dead time function disabled */
  
  
  PWMCON2bits.MDCS = 0;
  PWMCON2bits.DTC = 2;			 //Dead time function is disabled
  PWMCON2bits.ITB = 1;			 //PHASEx/SPHASEx registers provide time base period for this PWM generator
  FCLCON2bits.FLTMOD = 3;
  
 PHASE2 = 33000;
  /*  PDCx: PWM GENERATOR DUTY CYCLE x REGISTER*/
  PDC2 =  PHASE2/3;//0
  
  ///
  FCLCON2bits.FLTSRC = 2;             /* Comparator #3 is Fault source */
  FCLCON2bits.FLTPOL = 1;             /* Fault source is active high */
  FCLCON2bits.FLTMOD = 1;             /* FLTDAT from IOCONx register  provides data to PWM output when in fault state */
  
  ///

  gVoutCmd = UserData.Page2.region.VoutCommand.Val;
  Vref.SetVoltage = gVoutCmd;
  Vref.SoftstartVoltage = 0;
    
}


void pwm_f_1()
{
//#define PWM_peried   6000
//#define c  150//110// 100//200
//    /* Set PWM Period on Primary Time Base */
//PTPER = PWM_peried ;
///* Set Phase Shift */
//PHASE1 = 0;
////SPHASE1 = 100;
//
///* Set Duty Cycles */
//PDC1 = 10;//PWM_peried/c ;
////SDC1 = 200;
//
///* Set Dead Time Values */
//DTR1 = 0;
////ALTDTR1  = 0;
///* Set PWM Mode to Independent */
//IOCON1  = 0xCC00;
///* Set Primary Time Base, Edge-Aligned Mode and Independent Duty Cycles */
//PWMCON1 = 0x0000;
///* Configure Faults */
//FCLCON1 = 0x0003;
///* 1:1 Prescaler */
//PTCON2 = 0x0000;
///* Enable PWM Module */
//PTCON = 0x8000;
    
    

/***********************************************
   * PWM 1 Configuration  -- generate I local voltage
   **********************************************/
  /* PWM module controls PWMxH pin */
  IOCON1bits.PENH = 1;
  /* PWM module controls PWMxL pin */
  IOCON1bits.PENL = 0;
  /* PWM I/O pin pair is in the True Independent PWM Output mode */
  IOCON1bits.PMOD = 3;
  /* PWMxH and PWMxL pins are mapped to their respective pins */
  IOCON1bits.SWAP = 0;
  /* Dead time is disabled added into duty cycle */
  PWMCON1bits.DTC = 2;
  /* Disable Immediate duty cycle updates */
  PWMCON1bits.IUE = 0;
  /* PHASEx/SPHASEx registers provide time base period for this PWM generator */
  PWMCON1bits.ITB = 1;

  FCLCON1bits.CLMOD = 0;
  FCLCON1bits.FLTMOD = 3;

  PHASE1 = 2000;
  PDC1 =1000;
  
  SPHASE1 = 0;
  SDC1 = 0;
  
    /* 1 = Enable the PWM Module */
  PTCONbits.PTEN = 1;
    
}
/*******************************************************************************
 * Function:        
 * author:          WH
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     
 * history:
 ******************************************************************************/
//static
void init_PWM ( )
{
    
    pwm_f_1();
#if 0
 init_PWM_FAN();
  PTCON2bits.PCLKDIV = 1;			
  PTPER = PWM_PERIOD;
  MDC = ( PWM_PERIOD >> 1 );
init_PWM_12V_TRIM();


#endif
PTCONbits.PTEN = 1;
}
/*******************************************************************************
 * Function:        
 * author:          WH
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     
 * history:
 ******************************************************************************/
#ifdef Config_Input_CN     
//static
void init_Input_CN ( void )     
{
CNENCbits.CNIEC6 = 1;         // Enable RA3 pin for interrupt detection   iPS_ON
CNENCbits.CNIEC0 = 1;         // Enable RC0 pin for interrupt detection   iAC_OK
CNENCbits.CNIEC13 = 1;         // Enable RC0 pin for interrupt detection   iPFC_OK

IEC1bits.CNIE = 1;                    // Enable CN interrupts
IFS1bits.CNIF = 0;                    // Reset CN interrupt


}
#endif
/*******************************************************************************
 * Function:        
 * author:          WH
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     
 * history:
 ******************************************************************************/

//static 
void init_ISR_IPL()
{
  IPC27bits.ADCAN0IP= 5;
  IPC27bits.ADCAN1IP= 5; 
  IPC28bits.ADCAN2IP= 3;
  IPC28bits.ADCAN3IP= 3;
  IPC28bits.ADCAN4IP= 3; 
  IPC28bits.ADCAN5IP= 5; 
  IPC29bits.ADCAN7IP= 5;
   IPC38bits.ADCAN12IP= 5;   
      
  // IPC3bits.ADCIP=5;
   
    IPC0bits.T1IP = 5;
    IPC1bits.T2IP = 5;
    IPC2bits.T3IP = 4;
    IPC6bits.T4IP = 4;
    IPC7bits.T5IP = 5;
    
    IPC2bits.U1RXIP = 2;
    IPC3bits.U1TXIP = 2;
    IPC4bits.CNIP = 2;      // CN interrupt 
}


