#ifndef __PROTECTION_H__
#define __PROTECTION_H__

#include "Define.h"

#define STB_OC_PROTECT			TRUE
#define STB_OV_PROTECT			TRUE
#define STB_UV_PROTECT			TRUE
#define STB_SC_PROTECT			TRUE

#define FAN_LOCK_PROTECT		TRUE
#define OT_PROTECT				TRUE
#define SC_PROTECT				TRUE
#define UV_PROTECT				TRUE
#define OC_PROTECT				TRUE
#define OP_PROTECT				TRUE
#define OV_PROTECT				TRUE
#define PSON_ENABLE				TRUE
#define PRESENT_ENABLE			FALSE
#define PS_KILL_ENABLE			TRUE
#define PFC_ENABLE				TRUE


//Switch
#define PSON_H_DEBOUNCE_TIME		20		//ms
#define PSON_L_DEBOUNCE_TIME		10		//ms
#define PRESENT_H_DEBOUNCE_TIME		5		//ms
#define PRESENT_L_DEBOUNCE_TIME		90		//ms
#define PS_KILL_H_DEBOUNCE_TIME		20		//ms
#define PS_KILL_L_DEBOUNCE_TIME		10		//ms

//Main Protection
#define VOUT_COMP_DEBOUNCE_TIME			200	//ms, 20160108 Added
#define SW_SLAVE_DEBOUNCE_TIME			200	//ms, 20150731 Added
#define SCP_DEBOUNCE_TIME			1200	//ms
#define OCP_DEBOUNCE_TIME			1200	//ms
#define OCW_DEBOUNCE_TIME			800 //10      //800		//ms, 20141106 fix, 
#define OPP_DEBOUNCE_TIME			1200	//ms
#define OPW_DEBOUNCE_TIME			800		//ms
#define UVP_DEBOUNCE_TIME			1200	//ms
#define UVW_DEBOUNCE_TIME			1000	//ms

#define OTW_TIMER				    1000	//ms  
#define OTP_TIMER				    5000	//ms  
#define OT_RECOVER_TIMER		    3000	//ms
#define FAN_LOCK_TIMER				15000	//15000   //ms 	//for new spec
#define FAN_WARN_TIMER				9000	//10000	//ms 
#define FAN_FAULT_TIMER				15000	//15000   //ms 	//for new spec
#define FAN_RECOVER_TIMER			3000	//ms
#define FAN_DISAPPEAR_TIMER			3000	//ms 
#define FAN_DUTY_CNTL_TIMER			5		//ms
#define FAN_CONTROL_TIMER			1000	//ms

#define MAIN_RAISE_TIME				1500	//ms
#define PIN_OP_WARN_DELAY			3000	//ms	//
#define IIN_OC_WARN_DELAY			3000	//ms	//

//Standby Protection
#define STB_OCP_DELAY_TIME			120		//ms
#define STB_OCW_DELAY_TIME			30		//ms, added
#define STB_UVP_DELAY_TIME			120		//ms
#define STB_UVW_DELAY_TIME			30		//ms,20160201 added

#define STB_RETRY_TIMER			  	5000	//ms
#define STB_RAISE_TIME				  25		//ms

//Current Share
#define CS_CATCH_TIMER			  	10		//ms
#define CS_START_TIMER			  	10		//ms
#define PRI_IS_TIMER				    50		//ms
#define DC_RAPID_ON_LOW_DELAY		500		//ms

//Remote Sense
#define RS_DETECTION_TIME		  	50		//ms

//MISC
#define SOFTSTART_DELAY_TIME    250		//ms
#define I2C_RESET_TIMER	  			25		//ms
#define TON_MAX_TIMER		    		4000	//ms
#define SAMPLE_TIME			    		100		//ms
#define RMC_REMOVED_TIME	  		60000	//ms
#define HOTPLUG_ADDR_TIME		  	100	//ms        
#define VIN_UV_TIME					    1000	//ms

//UART
#define UART_WDT_TIME			    	1000	//ms
#define U2TX_DELAY_TIMER		  	500		//ms
#define SCI_RETRY_TIME			  	500		//ms


//Dummy Load
#define DUMMY_LOADOFF_DELAY_TIME	2000	//ms

//************************************************************

typedef struct _Detect
{
  BYTE Flag ;
  WORD delay ;
} tDetect ;

typedef struct _ProtectDelay
{
  //Switch
  tDetect PSON_H ;
  tDetect PSON_L ;
  tDetect PRESENT_H ;
  tDetect PRESENT_L ;
  tDetect PS_KILL_H ;
  tDetect PS_KILL_L ;
  //Debounce
  tDetect OCP ;
  tDetect OCW ;
  tDetect OPP ;
  tDetect OPW ;
  tDetect UVP ;
  tDetect SCP ;
  tDetect SR1 ;
  tDetect SR2 ;
  //tDetect SR3 ;           //20160108 removed
  tDetect SR_Enable ;
 
  tDetect PriIS ;
  tDetect DcRapidOnLowDelay ;
  tDetect PinOPW ; //
  tDetect IinOCW ; //
  tDetect DummyLoadOFF ;
  tDetect DD_SlaveSW_OFF ;  
  tDetect MainVoutComp ;  

  //Fan
  tDetect Fan1Warning ;
  tDetect Fan1Fault ;
  tDetect Fan1Lock ;
  tDetect Fan1Disappear ;
  tDetect Fan2Warning ;
  tDetect Fan2Fault ;
  tDetect Fan2Lock ;
  tDetect T_FanControl ;
  tDetect FanDutyCtrl ;
  tDetect FanRecovery ;
  //SoftStart
  tDetect SoftStart ;
  
  //Temprature
  tDetect OTP_Tpri ;
  tDetect OTW_Tpri ;
  tDetect OTP_Tsec ;
  tDetect OTW_Tsec ;
  tDetect OTP_Tinlet ;
  tDetect OTW_Tinlet ;
  tDetect OT_Recover_Tpri ;
  tDetect OT_Recover_Tsec ;
  tDetect OT_Recover_Tinlet ;

  
  //Standby
  tDetect STB_OCP ;
  tDetect STB_OCW ;     
  tDetect STB_UVP ;
  tDetect STB_UVW ;     
  
  tDetect STB_RETRY ;
  
  //I2C
  tDetect I2C_SCL_Fault ;
  tDetect I2C_SDA_Fault ;

  
  //TON
  tDetect TON_MAX_Fault ;
  
  //Current Share
  tDetect CS_CATCH ;
  tDetect CS_START ;

  
  //UART
  tDetect u2WDT ;
  tDetect u1WDT ; // for Lenovo spec
  tDetect u1PriRxWDT ;//20160503 added primary and secondary side communication error
  tDetect SCI_Retry ; // for Teridian
  tDetect U2TxDelay ; // for Teridian
  
  //Remote Sense
  tDetect RS_Detect ;
  
  //MISC
  tDetect SAMPLE ;
  tDetect RMC_Removed ;
  tDetect HotPlugAddr ; 
  tDetect VinUVFault ;
  tDetect VinUVWarning ;
  
} tProtectDelay ;

extern tProtectDelay Protect ;

/*Exported function*/
void ScanFault ( ) ;
#if cips
void CheckDebounce ( BYTE* Flag , WORD* delay , WORD timeLimit , WORD timeDifference , _Pfn handler ) ;
#endif
#endif 

