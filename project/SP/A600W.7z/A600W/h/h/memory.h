
#ifndef __MEMORY_H__
#define __MEMORY_H__ 

#include "Define.h"

//Configuration Defines ************************************************************
//Bootloader device configuration
#define DEV_HAS_WORD_WRITE	//Device has word write capability (24FJxxx devices)

//Bootloader feature configuration
#define USE_BOOT_PROTECT	//Use BL block protection 
#if 0	//[Peter Chung] 20100929 removed for write protection of the last page.
#define USE_CONFIGWORD_PROTECT	//Protect last page from writes/erases
#endif
#define USE_VECTOR_PROTECT  //Use Reset and IVT protection

//-----------------------------------
// Hardware Revision
//-----------------------------------
//#define HW_PT
//-------------------------------------------------------------------------------
// ISR addrss config -- The isr must be fixed at an program address
//-------------------------------------------------------------------------------
//#define SI2C2_ISR_ADDR   0x3000
//#define ADC1_ISR_ADDR    0x3200
//#define U1RX_ISR_ADDR    0x3300
//#define T1_ISR_ADDR      0x3500
//#define CN_ISR_ADDR      0x3580

#define BOOTLOADER_ADDR		0x400
#define BL_VER_ADDR			0x100	//BL version addr

#if defined(__dsPIC33FJ32GS606__)
#define USER_DATA_ADDR		0x5000
#define FRU_ADDR			0x5000
#define MISC_ADDR			0x5400
#elif defined(__dsPIC33FJ64GS606__)
#define USER_DATA_ADDR		0xA400
#define FRU_ADDR			0xA400
#define MISC_ADDR			0xA800
#define LOG_ADDR			0xA000
#endif

#define PM_INSTR_SIZE 		4		//bytes per instruction 
#define PM_ROW_SIZE 		256  	//user flash row size in bytes (64 instructions)
#define PM_PAGE_SIZE 		2048 	//user flash page size in bytes (64*8=512 instructions)


//Self-write NVMCON opcodes	
#define PM_PAGE_ERASE 		0x4042	//NVM page erase opcode
#define PM_ROW_WRITE 		0x4001	//NVM row write opcode
#define PM_WORD_WRITE		0x4003	//NVM word write opcode
#define CONFIG_WORD_WRITE	0X4004	//Config memory write opcode

#define BOOT_ADDR_LOW 		0x400	//start of BL protection area
#define BOOT_ADDR_HI  		0x13FF	//end of BL protection area  

/*
#if defined(__PIC24FJ16GA004__)
        #define CONFIG_WORD_1 		0x2BFEL	//Flash config word locations for devices
        #define CONFIG_WORD_2 		0x2BFCL	//w/o config bits
#elif defined(__PIC24FJ32GA004__)
    #define CONFIG_WORD_1 		0x57FEL	//Flash config word locations for devices
        #define CONFIG_WORD_2 		0x57FCL	//w/o config bits
#elif defined(__PIC24FJ64GA004__)
        #define CONFIG_WORD_1 		0xABFEL	//Flash config word locations for devices
        #define CONFIG_WORD_2 		0xABFCL	//w/o config bits#endif
#endif
 */

#if defined(__dsPIC33FJ32GS606__)
#define CONFIG_WORD_1		0x57FEL //Flash config word locations for devices
#define CONFIG_WORD_2		0x57FCL //w/o config bits#endif
#elif defined(__dsPIC33FJ64GS606__)
#define CONFIG_WORD_1		0xABFEL //Flash config word locations for devices
#define CONFIG_WORD_2		0xABFCL //w/o config bits#endif
#endif


void WriteMem ( WORD cmd ) ;
void WriteLatch ( WORD page , WORD addrLo , WORD dataHi , WORD dataLo ) ;
DWORD ReadLatch ( WORD page , WORD addrLo ) ;
void ResetDevice ( WORD addr ) ;
void Erase ( WORD page , WORD addrLo , WORD cmd ) ;
void ReadPM ( BYTE *buffer , WORD bytes , DWORD_VAL sourceAddr ) ;
void WritePM ( BYTE* buffer , WORD length , DWORD_VAL sourceAddr ) ;
void ErasePM ( WORD length , DWORD_VAL sourceAddr ) ;

#endif  /*end of __MEMORY_H__*/
