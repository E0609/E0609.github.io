
#ifndef __PEC_H__
#define __PEC_H__


//Exported function
void init_crc8 ( ) ;
//unsigned char getPEC(unsigned char cmd, unsigned char *data, unsigned char dir, unsigned char dataSize);
inline void CalcPEC ( ) ;





#endif

