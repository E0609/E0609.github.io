
#ifndef __DEFINE_H__
#define __DEFINE_H__

#include "p33Fxxxx.h"

//#define Config_12V25_REF
//#define Config_12V35_REF
#define Config_12V5_REF


#define Config_TERIDIAN_VinToPrimary            FALSE       //[davidchchen]20161212 78M6610 Vin sent to Primary, add Vthd Fun,but cause AC glitch.
#define CS_OPTIMIZTION_EN                       0//TRUE   //cips     //[davidchchen]20161026 Current Sharing optimization En/Disable,[davidchchen]20170106 enbale cs_optimiztion
#define RS_ENABLE				FALSE       //[davidchchen]20151225 Config RS_ENABLE TO Enable
#define ConfigDD_SlaveSW                        TRUE        //[davidchchen]20160225 added
#define ConfigVout_CompSW                       FALSE        //[davidchchen]20160108 added
#define Config_78M6610                          TRUE        //[davidchchen]20160114 added, TRUE = 78M6610, FALSE = 78M6613
#define Config_STATUS_ALL_READONLY              TRUE        //[davidchchen]20160303 STATUS_CML ISSUE
#define Config_WATCHDOG_TIMER                   FALSE       //[davidchchen]20160412 added watch-dog timer
#define Config_Input_CN                         TRUE       //[davidchchen]20160427 added Input Change Notification, CN8/RG6 -> iPFC_OK

#define Config_debug_IO                         FALSE       //[davidchchen]201600303 added

#define TRUE				1
#define FALSE				0
#define ON					1
#define OFF					0
#define HIGH				1
#define LOW					0
#define NULL				0

#define WithTeridian		TRUE
//*****************GPIO Define Start***************//
#define iPS_ON					PORTBbits.RB6
#define iPRESENT				PORTBbits.RB7
#define iALERT_N				PORTBbits.RB8
#define oALERT_N				LATBbits.LATB8
#define oSD_LOW					LATBbits.LATB15

#define iPS_OK					PORTCbits.RC12
#define oPS_OK					LATCbits.LATC12
#define oSR1					LATCbits.LATC13
#define oSR2					LATCbits.LATC14
#define iPS_KILL				PORTCbits.RC15

#define oG_DUMMY				LATDbits.LATD1
#define oRS_EN1					LATDbits.LATD2
#define iFan2_Rpm				PORTDbits.RD3
#define oDummy_CNTL				LATDbits.LATD4

#if Config_debug_IO    //[davidchchen]20160303 added
#define iDummy_CNTL				PORTDbits.RD4
#endif

#define iFAN_CNTL				PORTDbits.RD5
#define oFAN_CNTL				LATDbits.LATD5
#define iADDR0					PORTDbits.RD9
#define iADDR1					PORTDbits.RD10
#define iADDR2					PORTDbits.RD11
#define iADDR3					PORTDbits.RD0

#define oSHARE_OFF				LATEbits.LATE3
#define oSTB_ON					LATEbits.LATE5

#define o12V_ORFET_CNTL			LATFbits.LATF0
#define oLED_INPUT_CNTL			LATFbits.LATF1

#define oVIN_GOOD				LATFbits.LATF6

#define iPFC_OK					PORTGbits.RG6
#define iPFC_STB				PORTGbits.RG7
#define iAC_OK					PORTGbits.RG8
#define oSD1					LATGbits.LATG9
#define iSLAVE_SW                               PORTGbits.RG9           //[davidchchen]20160421 Added, Master/Slave DD Switch ISSUE

//*****************GPIO Define End****************//
#define PFC_OK			0
#define PFC_NOK			1
#define PFC_STB_OK		1
#define PFC_STB_NOK		0
#define MAIN_ON			1
#define MAIN_OFF		0
#define SLAVE_SW_EN		0   //[davidchchen]20150731 Added
#define SLAVE_SW_DIS		1   //[davidchchen]20150731 Added
#define PS_ON			0
#define PS_OFF			1
#define PRESENT			0
#define N_PRESENT		1
#define P_OK			1
#define P_N_OK			0 
#define ALERT_ON		1
#define ALERT_OFF		0
#define CONVERTER_ON	0
#define CONVERTER_OFF	1
#define SR_ON			0
#define SR_OFF			1
#define AC_GOOD			0
#define AC_N_GOOD		1
#define VIN_GOOD		1
#define VIN_N_GOOD		0
#define STB_ON			1
#define STB_OFF			0
#define Fan_Enable		1
#define Fan_Disable		0
#define RS_ON			0
#define RS_OFF			1
#define ORFET_ON		0
#define ORFET_OFF		1
#define LED_INPUT_ON	0
#define LED_INPUT_OFF	1

#define cips 0
//*****************  Global Variable ****************//

typedef struct
{
  unsigned SR_Enable : 1 ;
  unsigned Softstart : 1 ;
  unsigned SoftstartFinished : 1 ;
  unsigned PSON_H_CYCLE : 1 ;
  unsigned AC_ON_TO_OFF : 1 ;
  unsigned Vout_Regulation : 1 ;
  
  unsigned Fan1Disappear : 1 ;
  unsigned Fan2Disappear : 1 ;
  unsigned FanDutyCtrl : 1 ;
  unsigned FanControl : 1 ;
  
  //unsigned ReportDataUpdating : 1 ;             //[davidchchen]20160503 removed
  unsigned I2C_Processing : 1 ;
  unsigned EIN_DataUpdating : 1 ;
  unsigned EIN_DataUpdated : 1 ;
  unsigned EOUT_DataUpdating : 1 ;
  unsigned EOUT_DataUpdated : 1 ;
  
  unsigned AC_OFF_ClearFault : 1 ;
  unsigned AC_ON_CheckLineStatus : 1 ;
  unsigned FlashWritePage1 : 1 ;
  unsigned FlashWritePage2 : 1 ;
  unsigned FlashWritePage3 : 1 ;
  unsigned FlashWriteLocked : 1 ;
  unsigned MAIN_PROTECT_START : 1 ;
  unsigned STB_UV_START : 1 ;
  unsigned FanLock_Disable : 1 ;
  unsigned Uart1Error : 1 ;
  unsigned Uart2Error : 1 ;
  unsigned U2RX_CommOK : 1 ;
  unsigned PriFwUpdated : 1 ;
  unsigned CS_CALIBTATED : 1 ;
  unsigned LCS_CALIBRATED : 1 ; // [Tommy YR Chen] 20111103 added
  
  unsigned IOUT1_CALIBRATED : 1 ;
  unsigned IOUT2_CALIBRATED : 1 ;
  unsigned IOUT3_CALIBRATED : 1 ;
  unsigned IOUT4_CALIBRATED : 1 ; // [Tommy YR Chen] 20111103 added
  //unsigned CS_CATCH : 1 ;   //[davidchchen] 20150113 Removed
  //unsigned CS_START : 1 ;   //[davidchchen] 20150113 Removed
  
  unsigned SC_CheckStart : 1 ;
  unsigned U2_Comm_Timeout : 1 ;
  unsigned SmartOnEnabled : 1 ;
  unsigned DC_RAPID_ON_LOW : 1 ;
  unsigned StartCalibrate : 1 ;
  unsigned IsTeridianCaliMode : 1 ;
  
  unsigned U2RX_Updated : 1 ;
  unsigned SCI_Retry : 1 ;
  unsigned Teridian_ACK : 1 ;
  unsigned U2TxSend : 1 ;
  unsigned DummyLoadOff : 1 ;
  unsigned PS_ON_OFF ;
  unsigned MFR_PSON_CONTROL;        //[davidchchen]20170216 added PSON Signal Enable/disable
  
  unsigned op_cmdChanged : 1 ;
  unsigned SaveBlackBox : 1 ;
  
  unsigned VinOVFault : 1 ;
  unsigned VinUVFault : 1 ;
  unsigned Stb_PSON_L : 1 ;
  unsigned Stb_OP_OFF : 1 ;
  
  unsigned VinUVFaultDetected : 1 ;
  unsigned VinUVWarnDetected : 1 ;
  unsigned isDCInput : 1 ;
  unsigned OT_Recover : 1 ;
  unsigned Hr24_Expiry : 1 ;
  unsigned Fan_Recover : 1 ;
  unsigned Compatible_code  : 1;    //[davidchchen]20150112 Added Compatible Code to match HW version
  unsigned STB_Fault  : 1;          //[davidchchen]20160513 Added, When STB_SCP,OCP,OVP,UVP setting LED TO solid yellow

 } tPS_FLAG ;

typedef struct
{
  volatile unsigned int Counter_InRegulation ;
  unsigned InRegulation : 1 ;
  unsigned Enabled : 1 ;
  unsigned OCP : 1 ;
  unsigned OVP : 1 ;
  unsigned UVP : 1 ;
} tSTB ;

typedef struct
{
  volatile unsigned int Counter_InRegulation ;
  volatile unsigned int SR_ON_Delay ;
  unsigned InRegulation : 1 ;
  unsigned SR_Enabled : 1 ;
  unsigned CurrentShare : 1 ;
  unsigned MainEnabled : 1 ;
} tPSFB ;


/***************************Add by Peter Chung Begin*******************************************************/

typedef unsigned char BYTE ; // 8-bit unsigned
typedef unsigned int WORD ; // 16-bit unsigned
typedef unsigned long DWORD ; // 32-bit unsigned
typedef unsigned long long QWORD ; // 64-bit unsigned
typedef signed char CHAR ; // 8-bit signed
typedef signed int SHORT ; // 16-bit signed
typedef signed long LONG ; // 32-bit signed
typedef signed long long LONGLONG ; // 64-bit signed

typedef union _BYTE_VAL
{
  BYTE Val ;

  struct
  {
    unsigned char b0 : 1 ;
    unsigned char b1 : 1 ;
    unsigned char b2 : 1 ;
    unsigned char b3 : 1 ;
    unsigned char b4 : 1 ;
    unsigned char b5 : 1 ;
    unsigned char b6 : 1 ;
    unsigned char b7 : 1 ;
  } bits ;
} BYTE_VAL ;

typedef union _CHAR_VAL
{
  CHAR Val ;

  struct
  {
    unsigned char b0 : 1 ;
    unsigned char b1 : 1 ;
    unsigned char b2 : 1 ;
    unsigned char b3 : 1 ;
    unsigned char b4 : 1 ;
    unsigned char b5 : 1 ;
    unsigned char b6 : 1 ;
    unsigned char b7 : 1 ;
  } bits ;
} CHAR_VAL ;

typedef union _WORD_VAL
{
  WORD Val ;
  BYTE v[2] ;

  struct
  {
    BYTE LB ;
    BYTE HB ;
  } byte ;

  struct
  {
    unsigned char b0 : 1 ;
    unsigned char b1 : 1 ;
    unsigned char b2 : 1 ;
    unsigned char b3 : 1 ;
    unsigned char b4 : 1 ;
    unsigned char b5 : 1 ;
    unsigned char b6 : 1 ;
    unsigned char b7 : 1 ;
    unsigned char b8 : 1 ;
    unsigned char b9 : 1 ;
    unsigned char b10 : 1 ;
    unsigned char b11 : 1 ;
    unsigned char b12 : 1 ;
    unsigned char b13 : 1 ;
    unsigned char b14 : 1 ;
    unsigned char b15 : 1 ;
  } bits ;
} WORD_VAL ;

typedef union _SHORT_VAL
{
  SHORT Val ;
  BYTE v[2] ;

  struct
  {
    BYTE LB ;
    BYTE HB ;
  } byte ;

  struct
  {
    unsigned char b0 : 1 ;
    unsigned char b1 : 1 ;
    unsigned char b2 : 1 ;
    unsigned char b3 : 1 ;
    unsigned char b4 : 1 ;
    unsigned char b5 : 1 ;
    unsigned char b6 : 1 ;
    unsigned char b7 : 1 ;
    unsigned char b8 : 1 ;
    unsigned char b9 : 1 ;
    unsigned char b10 : 1 ;
    unsigned char b11 : 1 ;
    unsigned char b12 : 1 ;
    unsigned char b13 : 1 ;
    unsigned char b14 : 1 ;
    unsigned char b15 : 1 ;
  } bits ;
} SHORT_VAL ;

typedef union _DWORD_VAL
{
  DWORD Val ;
  WORD w[2] ;
  BYTE v[4] ;

  struct
  {
    WORD LW ;
    WORD HW ;
  } word ;

  struct
  {
    BYTE LB ;
    BYTE HB ;
    BYTE UB ;
    BYTE MB ;
  } byte ;

  struct
  {
    unsigned char b0 : 1 ;
    unsigned char b1 : 1 ;
    unsigned char b2 : 1 ;
    unsigned char b3 : 1 ;
    unsigned char b4 : 1 ;
    unsigned char b5 : 1 ;
    unsigned char b6 : 1 ;
    unsigned char b7 : 1 ;
    unsigned char b8 : 1 ;
    unsigned char b9 : 1 ;
    unsigned char b10 : 1 ;
    unsigned char b11 : 1 ;
    unsigned char b12 : 1 ;
    unsigned char b13 : 1 ;
    unsigned char b14 : 1 ;
    unsigned char b15 : 1 ;
    unsigned char b16 : 1 ;
    unsigned char b17 : 1 ;
    unsigned char b18 : 1 ;
    unsigned char b19 : 1 ;
    unsigned char b20 : 1 ;
    unsigned char b21 : 1 ;
    unsigned char b22 : 1 ;
    unsigned char b23 : 1 ;
    unsigned char b24 : 1 ;
    unsigned char b25 : 1 ;
    unsigned char b26 : 1 ;
    unsigned char b27 : 1 ;
    unsigned char b28 : 1 ;
    unsigned char b29 : 1 ;
    unsigned char b30 : 1 ;
    unsigned char b31 : 1 ;
  } bits ;
} DWORD_VAL ;

typedef union _LONG_VAL
{
  LONG Val ;
  WORD w[2] ;
  BYTE v[4] ;

  struct
  {
    WORD LW ;
    WORD HW ;
  } word ;

  struct
  {
    BYTE LB ;
    BYTE HB ;
    BYTE UB ;
    BYTE MB ;
  } byte ;

  struct
  {
    unsigned char b0 : 1 ;
    unsigned char b1 : 1 ;
    unsigned char b2 : 1 ;
    unsigned char b3 : 1 ;
    unsigned char b4 : 1 ;
    unsigned char b5 : 1 ;
    unsigned char b6 : 1 ;
    unsigned char b7 : 1 ;
    unsigned char b8 : 1 ;
    unsigned char b9 : 1 ;
    unsigned char b10 : 1 ;
    unsigned char b11 : 1 ;
    unsigned char b12 : 1 ;
    unsigned char b13 : 1 ;
    unsigned char b14 : 1 ;
    unsigned char b15 : 1 ;
    unsigned char b16 : 1 ;
    unsigned char b17 : 1 ;
    unsigned char b18 : 1 ;
    unsigned char b19 : 1 ;
    unsigned char b20 : 1 ;
    unsigned char b21 : 1 ;
    unsigned char b22 : 1 ;
    unsigned char b23 : 1 ;
    unsigned char b24 : 1 ;
    unsigned char b25 : 1 ;
    unsigned char b26 : 1 ;
    unsigned char b27 : 1 ;
    unsigned char b28 : 1 ;
    unsigned char b29 : 1 ;
    unsigned char b30 : 1 ;
    unsigned char b31 : 1 ;
  } bits ;
} LONG_VAL ;

typedef union _QWORD_VAL
{
  QWORD Val ;
  DWORD d[2] ;
  WORD w[4] ;
  BYTE v[8] ;

  struct
  {
    DWORD LD ;
    DWORD HD ;
  } dword ;

  struct
  {
    WORD LW ;
    WORD HW ;
    WORD UW ;
    WORD MW ;
  } word ;

  struct
  {
    unsigned char b0 : 1 ;
    unsigned char b1 : 1 ;
    unsigned char b2 : 1 ;
    unsigned char b3 : 1 ;
    unsigned char b4 : 1 ;
    unsigned char b5 : 1 ;
    unsigned char b6 : 1 ;
    unsigned char b7 : 1 ;
    unsigned char b8 : 1 ;
    unsigned char b9 : 1 ;
    unsigned char b10 : 1 ;
    unsigned char b11 : 1 ;
    unsigned char b12 : 1 ;
    unsigned char b13 : 1 ;
    unsigned char b14 : 1 ;
    unsigned char b15 : 1 ;
    unsigned char b16 : 1 ;
    unsigned char b17 : 1 ;
    unsigned char b18 : 1 ;
    unsigned char b19 : 1 ;
    unsigned char b20 : 1 ;
    unsigned char b21 : 1 ;
    unsigned char b22 : 1 ;
    unsigned char b23 : 1 ;
    unsigned char b24 : 1 ;
    unsigned char b25 : 1 ;
    unsigned char b26 : 1 ;
    unsigned char b27 : 1 ;
    unsigned char b28 : 1 ;
    unsigned char b29 : 1 ;
    unsigned char b30 : 1 ;
    unsigned char b31 : 1 ;
    unsigned char b32 : 1 ;
    unsigned char b33 : 1 ;
    unsigned char b34 : 1 ;
    unsigned char b35 : 1 ;
    unsigned char b36 : 1 ;
    unsigned char b37 : 1 ;
    unsigned char b38 : 1 ;
    unsigned char b39 : 1 ;
    unsigned char b40 : 1 ;
    unsigned char b41 : 1 ;
    unsigned char b42 : 1 ;
    unsigned char b43 : 1 ;
    unsigned char b44 : 1 ;
    unsigned char b45 : 1 ;
    unsigned char b46 : 1 ;
    unsigned char b47 : 1 ;
    unsigned char b48 : 1 ;
    unsigned char b49 : 1 ;
    unsigned char b50 : 1 ;
    unsigned char b51 : 1 ;
    unsigned char b52 : 1 ;
    unsigned char b53 : 1 ;
    unsigned char b54 : 1 ;
    unsigned char b55 : 1 ;
    unsigned char b56 : 1 ;
    unsigned char b57 : 1 ;
    unsigned char b58 : 1 ;
    unsigned char b59 : 1 ;
    unsigned char b60 : 1 ;
    unsigned char b61 : 1 ;
    unsigned char b62 : 1 ;
    unsigned char b63 : 1 ;
  } bits ;
} QWORD_VAL ;

typedef void (*_Pfn )( void ) ;
//Todo: think about if this is needed
#define BITS2WORD(sfrBitfield)  ( *((WORD*) &sfrBitfield) )
#define BITS2BYTEL(sfrBitfield) ( ((BYTE*)  &sfrBitfield)[0] )
#define BITS2BYTEH(sfrBitfield) ( ((BYTE*)  &sfrBitfield)[1] )
#define BYTE2WORD(sfrByte)  ( *((WORD*) &sfrByte) )


#define	Def_Bit0				(0b00000001)
#define	Def_Bit1				(0b00000010)
#define	Def_Bit2				(0b00000100)
#define	Def_Bit3				(0b00001000)
#define	Def_Bit4				(0b00010000)
#define	Def_Bit5				(0b00100000)
#define	Def_Bit6				(0b01000000)
#define	Def_Bit7				(0b10000000)

typedef enum
{
  //Main State
  STATE_INIT = 0 ,
  STATE_STANDBY ,
  STATE_ONING ,
  STATE_NORMAL ,
  STATE_OFFING ,
  STATE_LATCH ,

} ePSU_MAIN_STATE ;

typedef enum
{
  //Sub State
  STATE_SUB_NONE = 0 ,
  //Sub State of ONing State
  STATE_SUB_ON ,
  STATE_SUB_WAIT_OUTPUT_STABLE ,
  //Sub State of Normal State
  STATE_SUB_ATS ,
  STATE_SUB_ROA ,
  STATE_SUB_SLEEP ,
  STATE_SUB_FAULT ,
  STATE_SUB_NORMAL ,
  //Sub State of Latch State
  STATE_SUB_PSON_H ,
  STATE_SUB_PSON_L ,
  //Sub State of Standby State
  STATE_SUB_STANDBY_HICCUP ,
  STATE_SUB_STANDBY_NORMAL ,


} ePSU_SUB_STATE ;

//SR & conventor control

typedef enum
{
  STATE_FIRST_ON = 0 ,
  STATE_0_SR ,
  STATE_1_SR ,
  STATE_2_SR ,
  STATE_3_SR ,
  STATE_TRANSITION ,
} eSR_STATE ;

typedef struct _PSU_STATE
{
  BYTE mainState ;
  BYTE subState ;
  BYTE srState ;
} tPSU_STATE ;

//PSON Status

typedef enum
{
  PS_ON_L = 0 ,
  PS_ON_H ,
} ePSON_STATUS ;

//OPERATION Status

typedef enum
{
  OP_L = 0 ,
  OP_H ,
} eOPERATION_STATUS ;

/***************************Add by Peter Chung End*******************************************************/

//Output number

typedef enum
{
  OUTPUT_12V = 0 ,

  TOTAL_OUTPUT_NUM ,
} eOUTPUT_NUMBER ;

//Extern variable
extern volatile unsigned int RunTimerCNT_min ;


//[davidchchen]20160304 added RCB
/*******************************************************************************
* re-define data format
*******************************************************************************/
typedef unsigned char	u8_t;	/** 8 bit unsigned data */
typedef unsigned int	u16_t;	/** 16 bit unsigned data */
typedef unsigned long	u32_t;	/** 32 bit unsigned data */
typedef signed char		i8_t;	/** 8 bit signed data */
typedef signed int		i16_t;	/** 16 bit signed data */
typedef signed long		i32_t;	/** 32 bit signed data */
typedef void            (*funcPtr)();
/*******************************************************************************
* end of file
*******************************************************************************/

#endif

