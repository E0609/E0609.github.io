#ifndef __LED_H__
#define __LED_H__

#include "Define.h"

#if 0	// 12G

typedef struct _LED_STATUS
{
  unsigned AC_LED_STATUS : 2 ;
  unsigned DC_LED_STATUS : 2 ;
  unsigned SWAP_LED_STATUS : 2 ;
  unsigned RVSD : 2 ;
} tLED_STATUS ;

typedef enum
{
  AC_OK_OFF = 0 ,
  AC_OK_SOLID_GREEN ,
  AC_OK_ALTERNATED ,
} _AC_LED_CNTL ;

typedef enum
{
  DC_OK_OFF = 0 ,
  DC_OK_SOLID_GREEN ,
  DC_OK_ALTERNATED ,
} _DC_LED_CNTL ;

typedef enum
{
  SWAP_OK_OFF = 0 ,
  SWAP_OK_SOLID_GREEN ,
  SWAP_OK_ALTERNATED ,
} _SWAP_LED_CNTL ;

extern tLED_STATUS gLedStatus ;

/*Exported function*/
void LedControl ( ) ;

#endif


// 11G
#if 1
#define LED_BLINK_FREQ			500 //ms
#define LED_BLINK_FREQ_TYPE2	250	//ms
#define LED_BLINK_FREQ_TYPE3	100	//ms
#if 0

typedef enum
{
  LED_SYS_CNTL_DISABLE = 0x00 ,
  LED_BLINK ,
  LED_BLINK_GREEN ,
  LED_BLINK_YELLOW ,
  LED_SOLID_GREEN ,
  LED_SOLID_YELLOW ,
  LED_ALTERNATE ,
} eLED_SYS_CNTL ;
#endif
//[Peter Chung] 20101013 updated for X04-00

typedef enum
{
  LED_SYS_CNTL_DISABLE = 0x00 ,
  LED_BLINK_GREEN = 0x02 , //Blink Green at 1 Hz
  LED_BLINK_YELLOW , //Blink Amber 2s on, 1s off
  LED_SOLID_GREEN ,
  LED_SOLID_YELLOW ,
} eLED_SYS_CNTL ;

typedef enum
{
  LED_DC_OK ,
  LED_DC_NOK ,
  LED_FAULT ,
  LED_FAULT_CLEARED
} eLED_PSU_CNTL ;

typedef enum
{
  SOLID_GREEN = 1 ,
  SOLID_YELLOW = 2 ,
  ALTERNATED = 3 ,
  BLINK = 4 ,
  BLINK_GREEN = 5 , // 1Hz
  BLINK_YELLOW = 6 , // 1Hz
  LED_OFF = 7 ,
  BLINK_GREEN_TYPE2 = 8 , // 0.5Hz
  BLINK_YELLOW_TYPE2 = 9 , // 0.5Hz
  BLINK_YELLOW_TYPE3 = 10 , // 0.2Hz
} eLED_STATUS ;

typedef union _LED_STATUS
{
  BYTE Val ;

  struct
  {
    unsigned fault : 1 ;
    unsigned warning : 1 ;
    unsigned comm_err : 1 ;
    unsigned ac_loss : 1 ;
    unsigned standby : 1 ;
    unsigned U2comm_err : 1 ;       //[davidchchen]20160503 added primary and secondary side communication error
    unsigned PriRXcomm_err: 1 ;               //[davidchchen]20160503 added primary and secondary side communication error
    unsigned b7 : 1 ;
  } bits ;
} tLED_STATUS ;

extern tLED_STATUS gLedStatus ;

typedef union _LED_WARNING_STATUS
{
  BYTE Val ;

  struct
  {
    unsigned iout_oc_warning : 1 ;
    unsigned fan_warning : 1 ;
    unsigned ot1_warning : 1 ;
    unsigned ot2_warning : 1 ;
    unsigned ot3_warning : 1 ;
    unsigned vout_ov_warning : 1 ;
    unsigned vout_uv_warning : 1 ;
    unsigned b7 : 1 ;
  } bits ;
} tLED_WARNING_STATUS ;

typedef union _INPUT_LED_STATUS
{
  BYTE Val ;

  struct
  {
    unsigned vin_uv_fault : 1 ;
    unsigned vin_ov_fault : 1 ;
    unsigned vin_uv_warning : 1 ;
    unsigned vin_ov_warning : 1 ;
    unsigned b4 : 1 ;
    unsigned b5 : 1 ;
    unsigned b6 : 1 ;
    unsigned b7 : 1 ;
  } bits ;
} tINPUT_LED_STATUS ;

extern tLED_WARNING_STATUS gLedWarningStatus ;
extern tINPUT_LED_STATUS gInputLedStatus ;

/*Exported function*/
void init_Led ( ) ;
void Led_PSU_Control ( ) ;
void Led_SYS_Control ( BYTE cmd ) ;



#endif


#endif //

