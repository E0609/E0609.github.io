
#ifndef __STANDBY_H__
#define __STANDBY_H__

#include "Define.h"

#define cSTB_OK_REFH		500		//718		// 11.4V 
#define cSTB_OK_REFL		450		//630   	//705
#define cSTB_UV_BLANK		50		//10ms

#define STB_OCW_REF	(WORD)(((DWORD)30*ISB_TO_ADC)/10)		//3.0A  //[davidchchen] 20170619 Added
#define STB_OC_REF	(WORD)(((DWORD)35*ISB_TO_ADC)/10)		//3.5A  //5A
//#define STB_SC_REF	(WORD)(((DWORD)85*ISB_TO_ADC)/10)   // 8.5A
#define STB_SC_REF	(WORD)(((DWORD)55*ISB_TO_ADC)/10)		// 5.5A [davidchchen]20150911 modify
//#define STB_SC_REF	(WORD)(((DWORD)60*ISB_TO_ADC)/10)	// 6.0A //[davidchchen] 20150105 test

//Exported variable
extern BYTE STB_SCP_Delay ;
extern tSTB STB ;

//Exported function
void STBOringCntrl ( ) ;
void EnableSTBoutput ( ) ;
void DisableSTBoutput ( ) ;
void Check_STB ( ) ;
void Check_STBOVP ( ) ;
void Check_STBUVP ( ) ;
void Check_STBOCP ( ) ;
void Check_STBSCP ( ) ;
void StandbyVoltageControl ( ) ;
void init_Standby ( ) ;

#endif

