
#ifndef __STATUS_H__
#define __STATUS_H__


//Exported functions
void RefreshStatus ( ) ;
void ClearAllStatus ( BYTE page ) ;
void ClearStatusBit ( BYTE statusCmd , BYTE bitsToClear , BYTE page ) ;
BYTE isWarning ( ) ;
void ClearFaultByCommand ( BYTE page ) ;





#endif

