
#include "Led.h"
#include "Timer.h"
#include "Pmbus.h"
#include "Process.h"
#include "Sci.h"

static BYTE gSysCntl;
tLED_STATUS gLedStatus;


extern tPS_FLAG PS;
/*******************************************************************************
 * Function:        pwm1_fan_init
 * author:          WH
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     PWM FAN init
 * history:
 ******************************************************************************/
void init_Led ( )
{
  gSysCntl = FALSE;
  //gLedStatus.Val = 0;
}
/*******************************************************************************
 * Function:        pwm1_fan_init
 * author:          WH
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     PWM FAN init
 * history:
 ******************************************************************************/
static void SetLedBlinkGreen ( )
{
  static BYTE onoff = ON;
  if ( onoff )
  {
            pin_o_LED_ON =LED_ON ;
  }
  else
  {
             pin_o_LED_ON=LED_OFF ;
  }
  onoff = ! onoff;
}

/*******************************************************************************
 * Function:                       tsk_Led_PSU_Control 
 * author:                           WH
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     PWM FAN init
 * history:
 ******************************************************************************/
void tsk_Led_PSU_Control (BYTE status  )
{
  static BYTE ghLedTimer = 0;
  static BYTE previous_status = 0;
  
   if ( status != previous_status )
   {
	   if ( ghLedTimer )
	   {
		   KillTimer ( &ghLedTimer );
	   }

  if ( gLedStatus.bits.ac_lost )
  {
        pin_o_LED_ON = LED_OFF;
  }
  else if ( gLedStatus.bits.Power_ok )
  {
      pin_o_LED_ON = LED_ON;
  }
  else if ( gLedStatus.bits.stb_blinking )
  {
      ghLedTimer = SetTimer ( LED_BLINK_FREQ, SetLedBlinkGreen );	// 1 Hz
  }

  previous_status = status;
 }
}
 



