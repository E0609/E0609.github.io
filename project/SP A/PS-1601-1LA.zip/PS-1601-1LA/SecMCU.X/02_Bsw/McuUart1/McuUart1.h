/* 
 * File:   McuUart1.h
 * Author: kiranmeravanagi
 *
 * Created on 29 July, 2021, 6:36 PM
 */

#ifndef MCUUART1_H
#define	MCUUART1_H

#ifdef	__cplusplus
extern "C" {
#endif

    /*******************************************************************************
     * Global function prototypes (public to other modules)
     ******************************************************************************/


    extern void Mcu_Uart1HwInit(void);
    extern void UART1_DataInit(void);
    extern void UART1_TxData(void);
    extern void UART1_RxData(void);
    extern void UART1_TmOutMon(void);


#ifdef	__cplusplus
}
#endif

#endif	/* MCUUART1_H */

