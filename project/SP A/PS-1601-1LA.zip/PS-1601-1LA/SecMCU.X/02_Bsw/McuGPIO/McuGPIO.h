/* 
 * File:   McuGPIO.h
 * Author: 
 *
 * 
 */

#ifndef MCUGPIO_H
#define	MCUGPIO_H

#ifdef	__cplusplus
extern "C" {
#endif

#include <p33EP64GS504.h>
    
#include "Global.h"
#include "Define.h"
/*******************************************************************************
* Local constants and macros (private to module)
******************************************************************************/
#define MG_PIN_INPUT_DIRECTION    1         //Microchip Pin Input Direction
#define MG_PIN_OUTPUT_DIRECTION   0

#define MG_PIN_ANALOG             1         //Microchip Pin Analog Select
#define MG_PIN_DIGITAL            0

#define MG_PIN_OUTPUT_HIGH        1
#define MG_PIN_OUTPUT_LOW         0

/*********************** Digital output pin register ***********************************/         
#define DIO_V1_ORING_DRV_EN               LATBbits.LATB1
#define DIO_V1_EN                         LATAbits.LATA3     
#define DIO_LED_EN                        LATBbits.LATB5   
#define DIO_PWR_OK                        LATBbits.LATB12
#define DIO_5VSB_EN                       LATCbits.LATC1 
#define DIO_SR_EN                         LATCbits.LATC12       
#define DIO_VIN_OK                        LATBbits.LATB4 
#define DIO_DEBUG_OUT                     LATBbits.LATB11
/**************** set digital output pin High/Low status  ******************************/
#define PORT_OUT_V1_ORING_EN            { DIO_V1_ORING_DRV_EN = 0;\
                                          FLG_DO_V1_ORING_CTRL_EN = 1; }
#define PORT_OUT_V1_ORING_DIS           { DIO_V1_ORING_DRV_EN = 1;\
                                          FLG_DO_V1_ORING_CTRL_EN = 0; }
#define PORT_OUT_V1_SR_EN               { DIO_SR_EN = 1;\
                                          FLG_DO_V1_SR_CTRL_EN = 1; }
#define PORT_OUT_V1_SR_DIS              { DIO_SR_EN = 0;\
                                          FLG_DO_V1_SR_CTRL_EN = 0; }
#define PROT_OUT_PWOK_TO_SYS_OK         { DIO_PWR_OK = 0;\
                                          FLG_DO_PWOK_TO_SYS_OK = 1; }
#define PROT_OUT_PWOK_TO_SYS_NOT_OK     { DIO_PWR_OK = 1;\
                                          FLG_DO_PWOK_TO_SYS_OK = 0; }
#define PORT_OUT_VIN_OK_EN              { DIO_VIN_OK = 0;\
                                          FLG_DO_INOK_TO_SYS_OK = 1; }
#define PORT_OUT_VIN_OK_DIS             { DIO_VIN_OK = 1;\
                                          FLG_DO_INOK_TO_SYS_OK = 0; }
#define PORT_OUT_VSB_OUTPUT_EN          { DIO_5VSB_EN = 1;\
                                          FLG_DO_VSB_EN = 1; }
#define PORT_OUT_VSB_OUTPUT_DIS         { DIO_5VSB_EN = 0;\
                                          FLG_DO_VSB_EN = 0; }
#define PORT_OUT_V1_OUTPUT_EN           { DIO_V1_EN = 0;\
                                          FLG_DO_V1_OUTPUT_EN = 1; }
#define PORT_OUT_V1_OUTPUT_DIS          { DIO_V1_EN = 1;\
                                          FLG_DO_V1_OUTPUT_EN = 0; }  
#define PORT_OUT_LED_EN                 { DIO_LED_EN = 0;}                                         
#define PORT_OUT_LED_DIS                { DIO_LED_EN = 1;}  
    
/******************** Digital input pin register ********************************/
#define DIO_VIN_OK_FRO_PRI_HIP            PORTCbits.RC0   
#define DIO_BULK_OK_FRO_PRI_HIP           PORTCbits.RC13    
#define DIO_V1_PSON_ACTIVE_HIP            PORTCbits.RC6  
#define DIO_FAN_SPEED_HIP                 PORTBbits.RB14 
#define DIO_ADDR_A0_HIP                   PORTCbits.RC3 
#define DIO_ADDR_A1_HIP                   PORTCbits.RC4 
#define DIO_ADDR_A2_HIP                   PORTCbits.RC5 
#define DIO_I2C_SDA_HIP                   PORTCbits.RC7   //ok
#define DIO_I2C_SCL_HIP                   PORTCbits.RC8   //ok
/**************** set digital input pin High/Low status  *******************************/
#define PORT_IN_VIN_FRO_PRI_IS_OK        ( FALSE == DIO_VIN_OK_FRO_PRI_HIP )
#define PORT_IN_VIN_FRO_PRI_IS_NO_OK     ( FALSE != DIO_VIN_OK_FRO_PRI_HIP )
#define PORT_IN_VBULK_FRO_PRI_IS_OK      ( FALSE == DIO_BULK_OK_FRO_PRI_HIP )
#define PORT_IN_VBULK_FRO_PRI_IS_NO_OK   ( FALSE != DIO_BULK_OK_FRO_PRI_HIP )
#define PORT_IN_PSON_IS_ACTIVE           ( FALSE == DIO_V1_PSON_ACTIVE_HIP )
#define PORT_IN_PSON_IS_INACTIVE         ( FALSE != DIO_V1_PSON_ACTIVE_HIP )
#define PORT_IN_I2C_SDA_IS_HIGH          ( 0 != DIO_I2C_SDA_HIP )
#define PORT_IN_I2C_SDA_IS_LOW           ( 0 == DIO_I2C_SDA_HIP )
#define PORT_IN_I2C_SCL_IS_HIGH          ( 0 != DIO_I2C_SCL_HIP )
#define PORT_IN_I2C_SCL_IS_LOW           ( 0 == DIO_I2C_SCL_HIP )
/*******************************************************************************
 * Global data types (globals / structs / enums)
 ******************************************************************************/

/*******************************************************************************
 * Global data types (typedefs / structs / enums)
 ******************************************************************************/

/*******************************************************************************
 * Global function prototypes (public to other modules)
 ******************************************************************************/
extern void Mcu_GPIOHwInit(void);


#ifdef	__cplusplus
}
#endif

#endif	/* MCUGPIO_H */

