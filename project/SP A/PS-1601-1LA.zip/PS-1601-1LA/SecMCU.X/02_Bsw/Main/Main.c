/*
 * File:   Main.c
 * Author: kiranmeravanagi
 *
 * Created on March 29, 2021, 11:33 AM
 */


#include "xc.h"
#include <p33EP64GS504.h>

#include "Main.h"
#include "McuClock.h"
#include "McuGPIO.h"
#include "McuADC.h"
#include "McuDAC.h"
#include "McuTimer.h"
#include "McuPWM.h"
#include "McuI2C1.h"
#include "McuUart1.h"
//
#include "Protection.h"
#include "TimerISR.h"
#include "PsuState.h"
#include "Pmbus.h"
#include "FanCtrl.h"
#include "UartComm.h"

uint16 u16uarttxflag = 0;
/*  ------------------------------------------------------------------------------
  Module               : Mcu_RemapPinInit.c
  Function             :
  Modification history :
  ------------------------------------------------------------------------------
  Description          : Main function
  ------------------------------------------------------------------------------
  Input                : -
  Output               : -
  Modified Variables   : -
  Calling              : -
------------------------------------------------------------------------------*/
void Mcu_RemapPinInit(void)
{
  __builtin_write_OSCCONL(OSCCON & 0xbf); /* Unlock register for remap pin configuration */

  /* UART pin remap */
  RPOR13bits.RP58R = 1;      /* Assign U1Tx to pin RP58/RC10 */ 
  RPINR18bits.U1RXR = 57;    /* Assign U1Rx to pin RP57/RC9 */ 

  __builtin_write_OSCCONL(OSCCON | 0x40); /* Lock register */
}

/*  ------------------------------------------------------------------------------
  Module               : Main.c
  Function             :
  Modification history : 
  ------------------------------------------------------------------------------
  Description          : Main function
  ------------------------------------------------------------------------------
  Input                : -
  Output               : -
  Modified Variables   : -
  Calling              : -
------------------------------------------------------------------------------*/

int main(void) {
    
/* System configuration */
  Mcu_SysClkHwInit();
  PROTECT_DataInit();
  Mcu_RemapPinInit();

  
///* uC peripheral configuration */
  Mcu_GPIOHwInit();
  Mcu_ADCHwInit();
  Mcu_TMRHwInit();
  Mcu_PwmHwInit();
  Mcu_CMPHwInit();
  Mcu_DACHwInit();
  Mcu_Uart1HwInit();
  
  PMBUS_vPmbusDataInit();
  Mcu_I2C1DataInit();
  Mcu_I2C1HwInit();
  /* Bsw data initialization */
  TIMER_SchDataInit();
  UART1_DataInit();
  
    /* Appl data initialization */
  PSUstate_DataInit();
  FANCTRL_DataInit();
  
  while (1)
  {
      INTCOM1_GetTxData();
      I2C_vProcessReceiveData();
  } /* while (1) */
}

