/* 
 * File:   Main.h
 * Author: kiranmeravanagi
 *
 * Created on March 29, 2021, 11:34 AM
 */

#ifndef MAIN_H
#define	MAIN_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* MAIN_H */

