/* 
 * File:   Global.h
 * Author: kiranmeravanagi
 *
 * Created on March 29, 2021, 2:52 PM
 */

#ifndef GLOBAL_H
#define	GLOBAL_H

#ifdef	__cplusplus
extern "C" {
#endif

/*******************************************************************************
* Global constants and macros
******************************************************************************/

    /* Logic state definition */
#ifndef FALSE
#define FALSE                  0
#endif

#ifndef TRUE
#define TRUE                   (!FALSE)
#endif

#ifndef DISABLE
#define DISABLE                  0
#endif

#ifndef ENABLE
#define ENABLE                   (!DISABLE)
#endif

#ifndef LOW
#define LOW                    0
#endif

#ifndef HIGH
#define HIGH                   (!LOW)
#endif

#ifndef OFF
#define OFF                    0
#endif

#ifndef ON
#define ON                     (!OFF)
#endif


    /* Define CRC initial value*/
#define CRC_INIT_00              0x00
#define CRC_INIT_02              0x02

    /*******************************************************************************
     * Global data types (typedefs / structs / enums)
     ******************************************************************************/

    /* Definitions for 16-bit and 32-Bit signed/unsigned integers */
#ifndef DATA_TYPES
#define DATA_TYPES
    typedef unsigned char boolean;
    typedef signed char sint8;
    typedef unsigned char uint8;
    typedef signed short int sint16;    
    typedef unsigned short int uint16;  
    typedef signed long sint32;
    typedef unsigned long uint32;
    typedef signed long long sint64;
    typedef unsigned long long uint64;
    typedef float float32;
    typedef long double float64;
#endif

    typedef union {
        uint8 u8Val;
        sint8 s8Val;

        struct {
            uint8 Bits0_3 : 4;
            uint8 Bits4_7 : 4;
        } Bits4;
    } BYTE_VAL;

    typedef union {
        uint16 u16Val;
        sint16 s16Val;

        struct {
            uint8 Bits0_3 : 4;
            uint8 Bits4_7 : 4;
            uint8 Bits8_B : 4;
            uint8 BitsC_F : 4;
        } Bits4;

        struct {
            uint8 LB;
            uint8 HB;
        } Bytes;
    } WORD_VAL;

    typedef union {
        uint32 u32Val;
        sint32 s32Val;

        struct {
            uint8 Bits0_3 : 4;
            uint8 Bits4_7 : 4;
            uint8 Bits8_B : 4;
            uint8 BitsC_F : 4;
            uint8 Bits10_13 : 4;
            uint8 Bits14_17 : 4;
            uint8 Bits18_1B : 4;
            uint8 Bits1C_1F : 4;
        } Bits4;

        struct {
            uint16 LW;
            uint16 HW;
        } Words;

        struct {
            uint8 LB;
            uint8 HB;
            uint8 UB;
            uint8 MB;
        } Bytes;
    } DWORD_VAL;

    typedef union GLOBAL_U_U8BIT_ {
        uint8 ALL;

        struct {
            uint8 Bits0_3 : 4;
            uint8 Bits4_7 : 4;
        } Bits4;

        struct {
            uint8 f0 : 1;
            uint8 f1 : 1;
            uint8 f2 : 1;
            uint8 f3 : 1;
            uint8 f4 : 1;
            uint8 f5 : 1;
            uint8 f6 : 1;
            uint8 f7 : 1;
        } Bits;
    } GLOBAL_U_U8BIT;

    typedef union GLOBAL_U_U16BIT_ {
        uint16 ALL;

        struct {
            uint8 Bits0_3 : 4;
            uint8 Bits4_7 : 4;
            uint8 Bits8_B : 4;
            uint8 BitsC_F : 4;
        } Bits4;

        struct {
            uint8 LB : 8;
            uint8 HB : 8;
        } Bytes;

        struct {
            uint16 f0 : 1;
            uint16 f1 : 1;
            uint16 f2 : 1;
            uint16 f3 : 1;
            uint16 f4 : 1;
            uint16 f5 : 1;
            uint16 f6 : 1;
            uint16 f7 : 1;
            uint16 f8 : 1;
            uint16 f9 : 1;
            uint16 fa : 1;
            uint16 fb : 1;
            uint16 fc : 1;
            uint16 fd : 1;
            uint16 fe : 1;
            uint16 ff : 1;
        } Bits;
    } GLOBAL_U_U16BIT;



    /*******************************************************************************
     * Global function prototypes (public to other modules)
     ******************************************************************************/

    /* Q format definition for float to fix point */  
#define Q10(X)                   ((X < 0.0) ? (sint16)(1024 * (X) - 0.5) : (sint16)(1024 * (X) + 0.5))
#define Q12(X)                   ((X < 0.0) ? (sint16)(4096 * (X) - 0.5) : (sint16)(4096 * (X) + 0.5))
#define Q16(X)                   ((X < 0.0) ? (sint32)(65536 * (X) - 0.5) : (sint16)(65536 * (X) + 0.5))
#define U32Q12(X)                ((uint32)(4096.0F * (X) + 0.5F))
#define DIM(x)                   (sizeof(x)/sizeof(x[0]))    /* Get size of variable           */

#define DEBOUNCE_SET_CLR_1(flag,status1,status2,time_set_clear)  \
{                                                   \
  static uint16 flag##_debounce_time=0;             \
  if (status1)                                      \
  {                                                 \
    if (flag##_debounce_time >= time_set_clear)     \
    {                                               \
      flag = 1  ;                                   \
    }                                               \
    else                                            \
    {                                               \
      flag##_debounce_time++;                       \
    }                                               \
  }                                                 \
  else if (status2)                                 \
  {                                                 \
    if (flag##_debounce_time > 0)                   \
    {                                               \
      flag##_debounce_time--;                       \
    }                                               \
    else                                            \
    {                                               \
      flag = 0  ;                                   \
    }                                               \
  }                                                 \
}

#define DEBOUNCE_SET_CLR_2(flag,status1,status2,time_set,time_clr)  \
{                                                   \
  static uint16 flag##_debounce_time_set = 0;       \
  static uint16 flag##_debounce_time_clr = 0;       \
  if(!flag)                                         \
  {                                                 \
    flag##_debounce_time_clr = 0;                   \
    if(status1)                                     \
    {                                               \
      if(++flag##_debounce_time_set >= time_set)    \
      {                                             \
        flag = 1;                                   \
      }                                             \
    }                                               \
    else                                            \
    {                                               \
      flag##_debounce_time_set = 0;                 \
    }                                               \
  }                                                 \
  else                                              \
  {                                                 \
    flag##_debounce_time_set = 0;                   \
    if(status2)                                     \
    {                                               \
      if(++flag##_debounce_time_clr >= time_clr)    \
      {                                             \
        flag = 0;                                   \
      }                                             \
    }                                               \
    else                                            \
    {                                               \
      flag##_debounce_time_clr = 0;                 \
    }                                               \
  }                                                 \
}


#ifdef	__cplusplus
}
#endif

#endif	/* GLOBAL_H */

