/** *****************************************************************************
 * \file    McuAdc.c
 * \brief   MCU ADC configurations
 *
 * \section AUTHOR
 *    1. Kiran
 *
 * \section SVN
 *  $Date$
 *  $Author$
 *  $Revision$
 *
 * \section LICENSE
 * Copyright (c) Lite-On Singapore Pte Ltd
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * Included header
 ******************************************************************************/
#include <p33EP64GS504.h>


/* Module header */
#include "McuAdc.h"
#include "McuClock.h"
#include "Define.h"




/*******************************************************************************
 * Local data types (private globals / structs / enums)
 ******************************************************************************/

/*******************************************************************************
 * Local data (private to module)
 ******************************************************************************/

/*******************************************************************************
 * Global data (public to other modules)
 ******************************************************************************/

/*******************************************************************************
 * Local function prototypes (private to module)
 ******************************************************************************/
void calibrateADC(void);

/*******************************************************************************
 * Global functions (public to other modules)
 ******************************************************************************/

/*******************************************************************************
 * \brief         configure the ADC's
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void calibrateADC(void)
{
  /*
   * Power Up delay: 2048 Core Clock Source Periods (TCORESRC) for all ADC cores
   * (~14.6 us)
   */
  _WARMTIME = 11;

  /* Turn on ADC module */
  ADCON1Lbits.ADON = 1;
  /* power-on delay time */
  ADCON5Hbits.WARMTIME = 11; 
  /* Turn on analog power for dedicated core 0 */
  ADCON5Lbits.C0PWR = 1;
  while (ADCON5Lbits.C0RDY == 0);
  /* Enable ADC core 0 */
  ADCON3Hbits.C0EN = 1;

  /* Turn on analog power for dedicated core 1 */
  ADCON5Lbits.C1PWR = 1;
  while (ADCON5Lbits.C1RDY == 0);
  /* Enable ADC core 1 */
  ADCON3Hbits.C1EN = 1;

  /* Turn on analog power for dedicated core 2 */
  ADCON5Lbits.C2PWR = 1;
  while (ADCON5Lbits.C2RDY == 0);
  /* Enable ADC core 2 */
  ADCON3Hbits.C2EN = 1;

  /* Turn on analog power for dedicated core 3 */
  ADCON5Lbits.C3PWR = 1;
  while (ADCON5Lbits.C3RDY == 0);
  /* Enable ADC core 3 */
  ADCON3Hbits.C3EN = 1;

  /* Turn on analog power for shared core */
  ADCON5Lbits.SHRPWR = 1;
  while (ADCON5Lbits.SHRRDY == 0);
  /* Enable shared ADC core */
  ADCON3Hbits.SHREN = 1;

  /* Enable calibration for the dedicated core 0 */
  ADCAL0Lbits.CAL0EN = 1;
  /* Single-ended input calibration */
  ADCAL0Lbits.CAL0DIFF = 0;
  /* Start Cal */
  ADCAL0Lbits.CAL0RUN = 1;
  while (ADCAL0Lbits.CAL0RDY == 0);
  /* Cal complete */
  ADCAL0Lbits.CAL0EN = 0;

  /* Enable calibration for the dedicated core 1 */
  ADCAL0Lbits.CAL1EN = 1;
  /* Single-ended input calibration */
  ADCAL0Lbits.CAL1DIFF = 0;
  /* Start Cal */
  ADCAL0Lbits.CAL1RUN = 1;
  while (ADCAL0Lbits.CAL1RDY == 0);
  /* Cal complete */
  ADCAL0Lbits.CAL1EN = 0;

  /* Enable calibration for the dedicated core 2 */
  ADCAL0Hbits.CAL2EN = 1;
  /* Single-ended input calibration */
  ADCAL0Hbits.CAL2DIFF = 0;
  /* Start Cal */
  ADCAL0Hbits.CAL2RUN = 1;
  while (ADCAL0Hbits.CAL2RDY == 0);
  /* Cal complete */
  ADCAL0Hbits.CAL2EN = 0;

  /* Enable calibration for the dedicated core 3 */
  ADCAL0Hbits.CAL3EN = 1;
  /* Single-ended input calibration */
  ADCAL0Hbits.CAL3DIFF = 0;
  /* Start Cal */
  ADCAL0Hbits.CAL3RUN = 1;
  while (ADCAL0Hbits.CAL3RDY == 0);
  /* Cal complete */
  ADCAL0Hbits.CAL3EN = 0;

  /* Enable calibration for the shared core */
  ADCAL1Hbits.CSHREN = 1;
  /* Single-ended input calibration */
  ADCAL1Hbits.CSHRDIFF = 0;
  /* Start calibration cycle */
  ADCAL1Hbits.CSHRRUN = 1;
  /* while calibration is still in progress */
  while (ADCAL1Hbits.CSHRRDY == 0);
  /* Calibration is complete */
  ADCAL1Hbits.CSHREN = 0;
}

/*******************************************************************************
 * \brief         Initialize and configure the ADC's
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void Mcu_ADCHwInit(void)
{
  /* A/D control register
   * f_AD = Fosc/(ADCS) = 120MHz/2 = 60MHz 
   * ADC clock period t_AD = 1/f_AD ~ 16.66ns > 14.3ns (minimum ADC clock period)
   * Sampling time   =  2 * t_AD
   * Conversion Time 8*t_SRC + 14.5*t_AD ~ 308.32 nS
   */
  /* Setup ADC Clock Input Max speed of 60 MHz --> Fosc = 120 MHz */
  /* 0-Fsys, 1-Fosc(system_clock * 2), 2-FRC, 3-APLL */
  ADCON3Hbits.CLKSEL = 1;
  /* Global Clock divider (1:1) */
  ADCON3Hbits.CLKDIV = 0;
  /* Core 0 clock divider (1:2) */
  ADCORE0Hbits.ADCS = 0;
  /* Core 1 clock divider (1:2) */
  ADCORE1Hbits.ADCS = 0;
  /* Core 2 clock divider (1:2) */
  ADCORE2Hbits.ADCS = 0;
  /* Core 3 clock divider (1:2) */
  ADCORE3Hbits.ADCS = 0;
  /* 1/2 clock divider */
  ADCON2Lbits.SHRADCS = 0;
  /* Integer format */
  ADCON1Hbits.FORM = 0;
  /* AVdd as voltage reference */
  ADCON3Lbits.REFSEL = 0;

  /* ADC Cores in 12-bit resolution mode */
  /* Shared ADC Core in 12-bit resolution mode */
  ADCON1Hbits.SHRRES = 3;
  /* Core 0 ADC Core in 12-bit resolution mode */
  ADCORE0Hbits.RES = 3;
  /* Core 1 ADC Core in 12-bit resolution mode */
  ADCORE1Hbits.RES = 3;
  /* Core 2 ADC Core in 12-bit resolution mode */
  ADCORE2Hbits.RES = 3;
  /* Core 3 ADC Core in 12-bit resolution mode */
  ADCORE3Hbits.RES = 3;
  /* Shared ADC Core sample time 4Tad */
  ADCON2Hbits.SHRSAMC = 2;

  /********************************************/
  /* Configure averaging mode for Vout Feedback AD */
//  ADFL0CONbits.OVRSAM = 0b010;  //15-bit result (12.3 format)
//  ADCON4Lbits.SAMC1EN = 1;      //Core 1 delay enable
//  ADCORE1Lbits.SAMC = 6;       //8 t_ADCORE
//  ADFL0CONbits.FLCHSEL = 4;   //1  //AN1
//  ADFL0CONbits.MODE = 0b11;     //Averaging mode
//  ADFL0CONbits.FLEN = 1;        //Enable filter


  /********************************************/

  /* Configure ANx for unsigned format and single ended (0,0) */
  ADMOD0L = 0x0000;
  calibrateADC();
  /* ADC AN0 12V_ORING_MCU triggered by TIMER1 */
  ADTRIG0Lbits.TRGSRC0 = 12;
  /* ADC AN1 I_OUT_MCU triggered by TIMER1 */
  ADTRIG0Lbits.TRGSRC1 = 12;
  /* ADC AN2 CS_OUT_READ */
  ADTRIG0Hbits.TRGSRC2 = 12;
  /* ADC AN3 I_SHARE_INT */
  ADTRIG0Hbits.TRGSRC3 = 12;
  /* ADC AN4 12V_OUT_MCU*/
  ADTRIG1Lbits.TRGSRC4 = 12;
  /* ADC AN5 STB_I_OUT_MCU*/
  ADTRIG1Lbits.TRGSRC5 = 12;
  /* ADC AN6*/
//  ADTRIG1Hbits.TRGSRC6 = 12;
  /* ADC AN7 STB_5V_MCU */
  ADTRIG1Hbits.TRGSRC7 = 12;
  /* ADC AN8  */
//  ADTRIG2Lbits.TRGSRC8 = 12;
  /* ADC AN9 LLC_ADJ_EXT */
  ADTRIG2Lbits.TRGSRC9 = 12;
  /* ADC AN10  */
//  ADTRIG2Hbits.TRGSRC10 = 12;
  /* ADC AN11  */
//  ADTRIG2Hbits.TRGSRC11 = 12;
  /* ADC AN12 T_SR_MCU */
  ADTRIG3Lbits.TRGSRC12 = 12;
  /* ADC AN13  */
//  ADTRIG3Lbits.TRGSRC13 = 12;
  /* ADC AN14  */
//  ADTRIG3Hbits.TRGSRC14 = 12;
  /* ADC AN15  */
  //ADTRIG3Hbits.TRGSRC15 = 12;
  /* ADC AN17  */
//  ADTRIG4Lbits.TRGSRC17 = 12;
  /* ADC AN19  */
//  ADTRIG4Hbits.TRGSRC19 = 12;  
  /* ADC AN20  */
  //ADTRIG5Lbits.TRGSRC20 = 12;
  /* ADC AN21  */
  //ADTRIG5Lbits.TRGSRC21 = 12;
  
  /* Clear ADC interrupt flag */
  IFS7bits.ADCAN2IF = 0;
  /* Set ADC interrupt priority to 5 */
  IPC28bits.ADCAN2IP = ADCP2_INT_PRIO; 
  /* Enable the ADC AN2 interrupt */
  IEC7bits.ADCAN2IE = 1;
  /* Enable ADC Common Interrupt */
  ADIELbits.IE2 = 1;
}

/*******************************************************************************
 * \brief         Initialize and configure the cmp's
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void Mcu_CMPHwInit(void)
{
  /****************** LLC current limit ***********************/
  /* Continue working in Idle mode */
  CMP1CONbits.CMPSIDL = 0;
  /* disconnect to DACOUT, depend on the function enable or not */
  CMP1CONbits.DACOE = 0;
  /* Select CMPxB for comparator */
  CMP1CONbits.INSEL = 0b01;
  /* 1 = Low Range: Max DAC Value = AVDD,  */
  CMP1CONbits.RANGE = 1;
  /* Set reference voltage */
  CMP1DAC = 2995; 
  /* Set Interrupt priority of Comparator */
  _AC2IP = V1_OCP_PRIO;
  /* Clear Comparator interrupt flag */
  _AC2IF = 0;
  /* Analog Comparator Interrupt Enable */
  _AC2IE = 0;

#if DEBUG_DISABLE_CCL
  CMP1CONbits.CMPON = 0;
#else
  /* Turn Module ON */
  CMP1CONbits.CMPON = 0;
#endif
}






