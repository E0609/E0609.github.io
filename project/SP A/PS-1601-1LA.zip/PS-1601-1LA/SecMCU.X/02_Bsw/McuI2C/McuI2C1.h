/* 
 * File:   McuI2C.h
 * Author: Kiran
 *
 * Created on 29 September, 2020, 11:00 AM
 */

#ifndef MCUI2C_H
#define	MCUI2C_H

#ifdef	__cplusplus
extern "C" {
#endif

    /*******************************************************************************
     * Global constants and macros
     ******************************************************************************/
#define PEC_ENABLE                 TRUE//FALSE
#define I2C_FIX_SLA_ADDR           FALSE

#define I2C_STATE_IDLE             0x00
#define I2C_STATE_READ_REQ         0x01
#define I2C_STATE_WRITE_REQ        0x02
#define I2C_STATE_BLOCK_WRITE      0x03

#define I2C_DEFAULT_VAL            0xFF

#define UPDATE_NO_DLY              FALSE
#define UPDATE_WITH_DLY            TRUE



#define I2C_RX_BUF_SIZE            50
#define I2C_TX_BUF_SIZE            240
#define TIME_I2C_RELEASE           100   // * 10ms

    /*******************************************************************************
     * Global function prototypes
     ******************************************************************************/

    /*******************************************************************************
     * Global data
     ******************************************************************************/
    extern volatile uint8 I2C_u8PEC;
    extern volatile uint8 I2C_u8I2cState;
    extern volatile uint8 I2C_u8PecErrCmd;
    extern volatile uint8 I2C_u8ExpTxCnt;
    extern volatile uint8 I2C_u8ExpRxCnt;
    extern volatile uint8 I2C_u8I2cRxCnt;
    extern volatile uint8 I2C_u8I2cTxCnt;
    extern volatile uint8 I2C_u8I2cTxLen;
    extern volatile uint8 I2C_u8I2cRxLen;
    extern volatile uint8 I2C_au8I2cRxBuf[I2C_RX_BUF_SIZE];
    extern volatile uint8 I2C_au8I2cTxBuf[I2C_TX_BUF_SIZE];

    /*******************************************************************************
     * Global constants and macros
     ******************************************************************************/

    /********************************************************************************
     * \brief         reset I2C module
     *
     * \param[in]     -
     * \param[in,out] -
     * \param[out]    -
     *
     * \return        -
     *
     *******************************************************************************/
    extern void Mcu_I2C1HwInit(void);

    /********************************************************************************
     * \brief         reset I2C module
     *
     * \param[in]     -
     * \param[in,out] -
     * \param[out]    -
     *
     * \return        -
     *
     *******************************************************************************/
    extern void I2C_vI2cReset(void);

    /********************************************************************************
     * \brief         I2C interrupt. called in int.c when there is an interrupt.
     *
     * \param[in]     -
     * \param[in,out] -
     * \param[out]    -
     *
     * \return        -
     *
     *******************************************************************************/
    extern void I2C_vI2cIsr(void);

    /********************************************************************************
     * \brief         Detect Stop bit and check wait flag to handle received frame 
     *
     * \param[in]     -
     * \param[in,out] -
     * \param[out]    -
     *
     * \return        -
     *
     *******************************************************************************/
    extern void I2C_vProcessReceiveData(void);

    /********************************************************************************
     * \brief         I2C timeout handler. called in schm.c every 10ms.
     *
     * \param[in]     -
     * \param[in,out] -
     * \param[out]    -
     *
     * \return        -
     *
     *******************************************************************************/
    extern void I2C_vI2cTimeOutHandler(void);

    /********************************************************************************
     * \brief         if the slave address is not fixed check 
     *                the address every 10ms in schm.c.
     * \param[in]     -
     * \param[in,out] -
     * \param[out]    -
     *
     * \return        -
     *
     *******************************************************************************/
#if I2C_FIX_SLA_ADDR
#else
    extern void I2C_vI2cAdrCheck(void);
#endif
    /********************************************************************************
     * \brief         I2C save EEPROM Calibrate Data.
     *
     * \param[in]     -
     * \param[in,out] -
     * \param[out]    -
     *
     * \return        -
     *
     *******************************************************************************/
    extern void I2C_vEEPCaliDataSave(void);

    /********************************************************************************
     * \brief         update i2c address
     *
     * \param[in]     -
     * \param[in,out] -
     * \param[out]    -
     *
     * \return        -
     *
     *******************************************************************************/
    extern void I2C_vUpdateI2cAddress(void);

    /********************************************************************************
     * \brief         Init I2C module.
     *
     * \param[in]     -
     * \param[in,out] -
     * \param[out]    -
     *
     * \return        -
     *
     *******************************************************************************/
    extern void Mcu_I2C1DataInit(void);



#ifdef	__cplusplus
}
#endif

#endif	/* MCUI2C_H */

