/*******************************************************************************
 * \file    McuI2c.c
 * \brief   Init I2C Slave
 *
 * \section AUTHOR
 *    1. Kiran
 *
 * \section SVN
 *  $Date$
 *  $Author$
 *  $Revision$
 *
 * \section LICENSE
 * Copyright (c) 
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * Included header
 ******************************************************************************/
#include <p33EP64GS504.h>
#include <xc.h>
#include "Global.h"

/* Module header */
#include "Define.h"
#include "Crc.h"
#include "McuClock.h"
#include "McuI2C1.h"
#include "McuGPIO.h"
#include "Pmbus.h"

/*******************************************************************************
 * Global data
 ******************************************************************************/
volatile uint8 I2C_u8ExpTxCnt;
volatile uint8 I2C_u8ExpRxCnt;
volatile uint8 I2C_u8I2cRxCnt;
volatile uint8 I2C_u8I2cTxCnt;
volatile uint8 I2C_u8I2cTxLen;
volatile uint8 I2C_u8I2cRxLen;
volatile uint8 I2C_u8PEC;
volatile uint8 I2C_u8PecErrCmd;
volatile uint8 I2C_u8I2cState;

volatile uint8 I2C_au8I2cRxBuf[I2C_RX_BUF_SIZE];
volatile uint8 I2C_au8I2cTxBuf[I2C_TX_BUF_SIZE];

/*******************************************************************************
 * Local constants and macros (private to module)
 ******************************************************************************/
#if PS_24V_CS_UNIT1
#define MG_I2C_BASE_SLA_ADR        ((uint8) 0xB0)           //unit1
#elif PS_24V_CS_UNIT5
#define MG_I2C_BASE_SLA_ADR        ((uint8) 0xB8)           //unit5
#endif

#define MG_I2C_SDA_LOW_TIME_OUT    ((uint16)30U)
#define MG_I2C_SCL_LOW_TIME_OUT    ((uint16)30U)

/* I2C module register definition */
#define MG_I2C_TX_DATA_REG         I2C1TRN                           /* TX register */
#define MG_I2C_RX_DATA_REG         I2C1RCV                           /* RX register */
#define MG_I2C_RX_REG_OERR         I2C1STATbits.I2COV                /* RX register error */
#define MG_I2C_CLK_SCH_EN()        { I2C1CONLbits.SCLREL = TRUE; }   /* Enable I2C clock schretch */
#define MG_I2C_IS_READ             I2C1STATbits.R_W                  /* I2C read operation */
#define MG_I2C_RX_IS_DATA          I2C1STATbits.D_A                  /* I2C received address byte */

#define MG_I2C_STOP_IS_DETECT      (1U == I2C1STATbits.P)
#define MG_I2C_PORT_IS_OPEN        (1U == I2C1CONLbits.I2CEN)
#define MG_I2C_PORT_IS_CLOSE       (0U == I2C1CONLbits.I2CEN)
#define MG_I2C_PORT_OPEN()         { I2C1CONLbits.I2CEN = TRUE; }
#define MG_I2C_PORT_CLOSE()        { I2C1CONLbits.I2CEN = FALSE; }

#define I2C_SFR_FLAG_INT_FLAG      (IFS1bits.SI2C1IF)
#define I2C_CLEAR_INT_FLAG()       {IFS1bits.SI2C1IF = FALSE;}

#define MG_I2C_STOP_DET_FLG        I2C_mg_u16I2cHwStatus.Bits.f0
#define MG_I2C_READ_FLG            I2C_mg_u16I2cHwStatus.Bits.f1

/*******************************************************************************
 * Local data types (private typedefs / structs / enums)
 ******************************************************************************/
typedef enum MG_E_I2C_STATE_
{
  MG_E_I2C_IDLE = 0,
  MG_E_I2C_READ,
  MG_E_I2C_WRITE,
  MG_E_I2C_BLOCK_WRITE,
} MG_E_I2C_STATE;

/*******************************************************************************
 * Local data (private to module)
 ******************************************************************************/

static uint16 I2C_mg_u16SclLowCnt = 0U;
static uint16 I2C_mg_u16SdaLowCnt = 0U;
static GLOBAL_U_U8BIT I2C_mg_u8I2cAddrWr;
static GLOBAL_U_U8BIT I2C_mg_u8I2cAddrWrOld;
static GLOBAL_U_U8BIT I2C_mg_u8I2cAddrRd;
static GLOBAL_U_U16BIT I2C_mg_u16I2cHwStatus;

/*******************************************************************************
 * Local function prototypes (private to module)
 ******************************************************************************/

static void mg_vI2cHwInitSlave(void);
static void mg_vSetI2cAddress(uint8 u8Addr);
static void mg_vI2cReset(void);

/*******************************************************************************
 * Global data (public to other modules)
 ******************************************************************************/

//volatile WORD_VAL u16I2cComDebug[I2C_COM_DEBUG_REG_NUM];

/*******************************************************************************
 * Global functions (public to other modules)
 ******************************************************************************/

/********************************************************************************
 * \brief         Init I2C module for PMBus.
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void Mcu_I2C1HwInit(void)
{
  /* Init I2C as Slave, COM with System */
  mg_vI2cHwInitSlave();
} /* Mcu_I2C1HwInit() */

/********************************************************************************
 * \brief         Init I2C module.
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void Mcu_I2C1DataInit(void)
{
  uint8 u8Cnt;

  for (u8Cnt = 0; u8Cnt < I2C_RX_BUF_SIZE; u8Cnt++)
  {
    I2C_au8I2cRxBuf[u8Cnt] = 0x00;
  }

  for (u8Cnt = 0; u8Cnt < I2C_TX_BUF_SIZE; u8Cnt++)
  {
    I2C_au8I2cTxBuf[u8Cnt] = 0x00;
  }

  I2C_u8PEC = 0;
  I2C_u8PecErrCmd = 0;
  I2C_u8I2cTxLen = 0;
  I2C_u8I2cTxCnt = 0;
  I2C_u8I2cRxCnt = 0;
  I2C_u8ExpTxCnt = 0;
  I2C_u8ExpRxCnt = 0;
  u16I2cStatus0.ALL = 0;
  u8I2cCmdDetected = 0;

} /* Mcu_I2C1DataInit() */

/********************************************************************************
 * \brief         if the slave address is not fixed check.
 *                the address every 10ms in Timer_ISR.c. * Have to be called at mian init
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
#if I2C_FIX_SLA_ADDR

#else

void I2C_vUpdateI2cAddress(void)
{
  static uint8 u8AddrMatchDly = 0;
  I2C_mg_u8I2cAddrWr.ALL = MG_I2C_BASE_SLA_ADR;
  I2C_mg_u8I2cAddrWr.Bits.f1 = 0;
  I2C_mg_u8I2cAddrWr.Bits.f2 = 0;

  if (I2C_mg_u8I2cAddrWrOld.ALL != I2C_mg_u8I2cAddrWr.ALL)
  {
    if (u8AddrMatchDly > 20)
    { /*delay 200ms */
      mg_vSetI2cAddress(I2C_mg_u8I2cAddrWr.ALL);
      I2C_mg_u8I2cAddrWrOld.ALL = I2C_mg_u8I2cAddrWr.ALL;
      I2C_mg_u8I2cAddrRd.ALL = I2C_mg_u8I2cAddrWr.ALL + 1;
    }
    else
    {
      u8AddrMatchDly++;
    }
  }
  else
  {
    u8AddrMatchDly = 0;
  }
}
#endif

/********************************************************************************
 * \brief         I2C timeout handler. called in schm.c every 1ms.
 *                check if I2C bus hung up (SCL or SDA low for 35ms)
 *                if yes:
 *                release the bus of the I2C interface by reseting module
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void I2C_vI2cTimeOutHandler(void)
{
  //  static uint8 u8I2cResetActiveOld = 0;
  I2C_RESET_FLG = FALSE;

#if 0  /* No HW resret funciton */
  /* I2C Reset Pin check */
  if ((I2C_RESET_SYS_ACTIVE)
      && (!u8I2cResetActiveOld))
  {
    I2C_RESET_FLG = TRUE;
  }
  u8I2cResetActiveOld = I2C_RESET_SYS_ACTIVE;
#endif
  /* SCL status check */
  if (PORT_IN_I2C_SCL_IS_LOW)
  {
    if (I2C_mg_u16SclLowCnt < MG_I2C_SCL_LOW_TIME_OUT)
    {
      I2C_mg_u16SclLowCnt++;
    }
    else
    {
      I2C_mg_u16SclLowCnt = 0;
      I2C_RESET_FLG = TRUE;
    }
  }
  else
  {
    I2C_mg_u16SclLowCnt = 0;
  }

  /* SDA status check */
  if (PORT_IN_I2C_SDA_IS_LOW)
  {
    if (I2C_mg_u16SdaLowCnt < MG_I2C_SDA_LOW_TIME_OUT)
    {
      I2C_mg_u16SdaLowCnt++;
    }
    else
    {
      I2C_mg_u16SdaLowCnt = 0;
      I2C_RESET_FLG = TRUE;
    }
  }
  else
  {
    I2C_mg_u16SdaLowCnt = 0;
  }

  /* Reset I2C module to release lines */
  if (TRUE == I2C_RESET_FLG)
  {
    mg_vI2cReset();
  }
} /* I2C_vI2cTimeOutHandler */

/********************************************************************************
 * \brief         I2C interrupt. called in int.c when there is an interrupt.
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void __attribute__((__interrupt__, no_auto_psv)) _SI2C1Interrupt(void)
{
  uint8 u8Data = MG_I2C_RX_DATA_REG; /* Get received byte */

  I2C_CLEAR_INT_FLAG(); /* reset RBF flag */
  MG_I2C_STOP_DET_FLG = 0;
  MG_I2C_READ_FLG = 0;
  I2C_mg_u16SclLowCnt = 0;
  I2C_mg_u16SdaLowCnt = 0;

  if (I2C_u8I2cState == MG_E_I2C_IDLE)
  {
    I2C_u8I2cTxLen = 0;
    I2C_u8I2cTxCnt = 0;
    I2C_u8I2cRxCnt = 0;
    I2C_u8ExpTxCnt = 0;
    I2C_u8ExpRxCnt = 0;
    I2C_u8PEC = 0;
  }

  if (MG_I2C_RX_REG_OERR) /* receive mode = 1 receive new byte but still hold the previous one */
  {
    MG_I2C_RX_REG_OERR = 0;
    MG_I2C_CLK_SCH_EN();
    mg_vI2cHwInitSlave();
    return;
  }
  /* Select between read and write */
  if (MG_I2C_IS_READ)
  {
    /* Read operation, output from slave */
    MG_I2C_READ_FLG = 1;

    if (MG_I2C_RX_IS_DATA)
    {
      /* Last received byte is data */
      if ((I2C_u8I2cTxLen)
          && (I2C_u8I2cTxCnt <= I2C_u8I2cTxLen))
      {
        if (I2C_u8I2cTxCnt == I2C_u8I2cTxLen)
        {
#if PEC_ENABLE
          I2C_au8I2cTxBuf[I2C_u8I2cTxCnt] = I2C_u8PEC;
#else
          I2C_au8I2cTxBuf[I2C_u8I2cTxCnt] = I2C_DEFAULT_VAL;
#endif
        }
        if (!I2C1STATbits.ACKSTAT)
        {
          MG_I2C_TX_DATA_REG = I2C_au8I2cTxBuf[I2C_u8I2cTxCnt++];
        }
      } /* end else */
      else
      {
        if (!I2C1STATbits.ACKSTAT)
        {
          MG_I2C_TX_DATA_REG = I2C_DEFAULT_VAL;
        }
      }
    }
    else
    {
      /* Last received byte is slave address */
      I2C_u8I2cTxLen = 0;
      I2C_u8I2cTxCnt = 0;

#if PEC_ENABLE
      I2C_u8PEC = CRC_u8GetCrc8(I2C_u8PEC, I2C_mg_u8I2cAddrRd.ALL);
#endif

      if (u8I2cCmdDetected)
      {
        //PMBUS_vSendData();
        if (PMBUS_u8TransType.Bits.BLOCK_READ_EN || PMBUS_u8TransType.Bits.WR_BLK_RD_BLK_PRT)
        {
          I2C_u8I2cTxLen++;
          PMBUS_vSendData(u8I2cCommand);
          I2C_au8I2cTxBuf[0] = I2C_u8I2cTxLen - 1;
          if (0 == I2C_au8I2cTxBuf[0])
          {
            I2C_u8I2cTxLen = 0;
          }
        }
        else
        {
          PMBUS_vSendData(u8I2cCommand);
        }
      }
      I2C_u8I2cState = MG_E_I2C_READ;
      if (0U == I2C_u8I2cTxLen)
      {
        I2C_au8I2cTxBuf[I2C_u8I2cTxCnt] = I2C_DEFAULT_VAL;
        I2C_INVALID_CMD_FLG = TRUE;
      }
      MG_I2C_TX_DATA_REG = I2C_au8I2cTxBuf[I2C_u8I2cTxCnt++];
    }

    /* Calculate the PEC if supported */
#if PEC_ENABLE
    I2C_u8PEC = CRC_u8GetCrc8(I2C_u8PEC, MG_I2C_TX_DATA_REG);
#endif
  }
  else
  {
    /* Write operation, input to slave */
    if (MG_I2C_RX_IS_DATA)
    {
      /* Calculate the PEC if supported */
#if PEC_ENABLE
      I2C_u8PEC = CRC_u8GetCrc8(I2C_u8PEC, u8Data);
#endif

      /* Last received byte is data */
      if (I2C_u8I2cState == MG_E_I2C_WRITE)
      {
        if (I2C_u8I2cRxCnt < I2C_RX_BUF_SIZE)
        {
          I2C_au8I2cRxBuf[I2C_u8I2cRxCnt++] = u8Data;
          //for Bw_Br_Protocol
          if (1U == I2C_u8I2cRxCnt)
          {
            u8I2cCommand = I2C_au8I2cRxBuf[0];
            I2C_u8ExpRxCnt = PMB_mg_au8I2cRxNumber[u8I2cCommand];
            PMBUS_u8TransType.ALL = PMBUS_u8TransactionType[u8I2cCommand];
            u8I2cCmdDetected = 1;
          }
            //for Bw_Br_Protocol
          else if (PMBUS_u8TransType.Bits.BLOCK_WRITE_EN || PMBUS_u8TransType.Bits.WR_BLK_RD_BLK_PRT)
          {
            if (2U == I2C_u8I2cRxCnt)
            {
              if (PMB_1B_SMBALERT_MASK == u8I2cCommand && I2C_au8I2cRxBuf[1] > 1)  //special handling for 1Bh_SMBALERT_MASK
              {
                I2C_u8ExpRxCnt = 3;
                PMBUS_u8TransType.ALL = 0x00;  //write word
              }
              else
              {
                I2C_u8ExpRxCnt = I2C_au8I2cRxBuf[1] + 2; // add 2 bytes (Cmd and Cnt)
              }
            }
            if (PMBUS_u8TransType.Bits.WR_BLK_RD_BLK_PRT && (I2C_u8ExpRxCnt == I2C_u8I2cRxCnt))
            {
              I2C_BW_BR_HDL_DAT_FLG = 1;
              I2C_vProcessReceiveData();
            }
          }
        }
      }
    }
    else
    {
      /* Slave address match and slave ACK */
      if (I2C_u8I2cState != MG_E_I2C_IDLE)
      {
        /* Cmd process not finished then next cmd is coming , or page and write/read */
        if ((I2C_u8I2cState == MG_E_I2C_READ)
            || (I2C_u8I2cState == MG_E_I2C_WRITE)
            || (I2C_u8I2cState == MG_E_I2C_BLOCK_WRITE))
        {
          I2C_CMD_WAIT_FLG = TRUE;
          I2C_vProcessReceiveData();
        }
        I2C_u8I2cTxLen = 0;
        I2C_u8I2cTxCnt = 0;
        I2C_u8I2cRxCnt = 0;
      } // end if

      /* Calculate the PEC if supported */
#if PEC_ENABLE
      I2C_u8PEC = CRC_u8GetCrc8(0x00, I2C_mg_u8I2cAddrWr.ALL);
#endif


      I2C_u8I2cState = MG_E_I2C_WRITE;
    }
  }
  MG_I2C_CLK_SCH_EN();
} /* I2C_vI2cIsr */

/********************************************************************************
 * \brief         Detect Stop bit and check wait flag to handle received frame
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void I2C_vProcessReceiveData(void)
{
  if ((MG_I2C_STOP_IS_DETECT)
      || I2C_CMD_WAIT_FLG
      || I2C_BW_BR_HDL_DAT_FLG)
  {

    if ((I2C_u8I2cRxCnt > 0)
        && ((I2C_u8I2cState == I2C_STATE_WRITE_REQ)
        || (I2C_u8I2cState == I2C_STATE_BLOCK_WRITE)))
    {
      /* Disable I2C interrupt */
      IEC1bits.SI2C1IE = 0;


      if (I2C_u8I2cRxCnt == I2C_u8ExpRxCnt)
      {
        vPMBus_HandleData(u8I2cCommand);
      }
#if PEC_ENABLE
      else if (I2C_u8I2cRxCnt == I2C_u8ExpRxCnt + 1) /* Correct byte count */
      {
        if (0U == I2C_u8PEC)
        { /* PEC is correct */
          vPMBus_HandleData(u8I2cCommand);
        }
        else
        {
          if (FALSE == I2C_PEC_ERR_FLG)
          {
            I2C_PEC_ERR_FLG = TRUE;
            I2C_u8PecErrCmd = u8I2cCommand;
          }
        }
      }
#endif
      else
      {
        /* send two many or two few byte count */
        if (I2C_u8ExpRxCnt == 0)
        {
          I2C_INVALID_CMD_FLG = TRUE;
        }
        else
        {
          if (//(FALSE == PMBUS_tStatus.u8StatusCmlP0.Bits.INVALID_CMD) &&  /* cmd is supported */
              ((I2C_u8I2cRxCnt != I2C_u8ExpRxCnt) || (I2C_u8I2cRxCnt != I2C_u8ExpRxCnt + 1)))
          { /* Host sends too many bytes */
            I2C_INVALID_DATA_FLG = TRUE;
          }
        }
      }
      I2C_u8I2cRxCnt = 0;
      IEC1bits.SI2C1IE = 1;
    }
    if (!I2C_BW_BR_HDL_DAT_FLG)
    {
      I2C_u8I2cState = MG_E_I2C_IDLE;
      u8I2cCmdDetected = 0;
    }
    I2C_CMD_WAIT_FLG = 0;
    I2C_BW_BR_HDL_DAT_FLG = 0;
  } // end if
} /* I2C_vProcessReceiveData() */

/*******************************************************************************
 * Local functions (private to module)
 ******************************************************************************/

/********************************************************************************
 * \brief         reset I2C module when error occurs.
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
static void mg_vI2cReset(void)
{
  MG_I2C_PORT_CLOSE();
  Nop();
  MG_I2C_PORT_OPEN();
} /* mg_vI2cReset() */

/********************************************************************************
 * \brief         set I2C slave address
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
static void mg_vSetI2cAddress(uint8 u8Addr)
{
  MG_I2C_PORT_CLOSE()
  I2C1ADD = (u8Addr >> 1);
  //mg_vI2cHwInitSlave();
  MG_I2C_PORT_OPEN()
}

/********************************************************************************
 * \brief         Init I2C module as Slave for PMBus.
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
static void mg_vI2cHwInitSlave(void)
{
  /*
   * Initial i2c 1 Module as Slave
   * for interface with external system, GUI
   */
  /* Disable i2c interface */
  I2C1CONLbits.I2CEN = 0;
  /* Disable Slave  Events interrupt */
  IEC1bits.SI2C1IE = 0;
  /* Disable Master Events interrupt */
  IEC1bits.MI2C1IE = 0;

  I2C_mg_u8I2cAddrWr.ALL = MG_I2C_BASE_SLA_ADR;
  I2C1ADD = (I2C_mg_u8I2cAddrWr.ALL >> 1);
  I2C_mg_u8I2cAddrWrOld.ALL = I2C_mg_u8I2cAddrWr.ALL;
  I2C_mg_u8I2cAddrRd.ALL = I2C_mg_u8I2cAddrWr.ALL + 1;

  I2C1MSK = 0x00;
  /* 0 = I2CxADD is a 7-bit slave address; 1 = I2CxADD is a 10-bit slave address */
  I2C1CONLbits.A10M = 0;
  /* 0 = Slew rate control enabled; 1 = Slew rate control disabled */
  I2C1CONLbits.DISSLW = 0;
  /* 0 = Dis SMBus input thresholds; 1 = En I/O pin thresholds compliant with SMBus specification */
  I2C1CONLbits.SMEN = 1;
  /* 0 = Dis software or receive clock stretch; 1 = En software or receive clock stretch when operate as I2C slave */
  I2C1CONLbits.STREN = 1;
  /* Set Fscl = 400kHz operating at Fcy = 40MHz */
  I2C1BRG = 93;
  /* Enable and start interrupt */
  /* Set I2C1 Slave  Events Interrupt Priority */
  IPC4bits.SI2C1IP = I2C_INT_PRIO;
  /* Reset interrupt flag */
  IFS1bits.SI2C1IF = 0;
  /* Reset interrupt flag */
  IFS1bits.MI2C1IF = 0;
  /* Enable interrupt */
  IEC1bits.SI2C1IE = 1;
  /* Disable interrupt  */
  IEC1bits.MI2C1IE = 0;
  /* Enable i2c interface */
  I2C1CONLbits.I2CEN = 1;
}


/*
 * End of file
 */
