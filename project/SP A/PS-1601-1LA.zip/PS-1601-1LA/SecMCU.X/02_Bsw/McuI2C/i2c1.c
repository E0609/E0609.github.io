
/**
  I2C1 Generated Driver File

  @Company
    Microchip Technology Inc.

  @File Name
    i2c1.c

  @Summary
    This is the generated header file for the i2c1 driver using PIC24 / dsPIC33 / PIC32MM MCUs

  @Description
    This header file provides APIs for driver for i2c1.
    Generation Information :
        Product Revision  :  PIC24 / dsPIC33 / PIC32MM MCUs - 1.167.0
        Device            :  dsPIC33EP64GS504

    The generated drivers are tested against the following:
        Compiler          :  XC16 v1.50
        MPLAB             :  MPLAB X v5.35
*/

/*
    (c) 2020 Microchip Technology Inc. and its subsidiaries. You may use this
    software and any derivatives exclusively with Microchip products.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION
    WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

    MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE
    TERMS.
*/

#include "i2c1.h"
#include "Pmbus.h"
#include "McuGPIO.h"
#include "global.h"
/**
 Section: Data Types
*/

/**
  I2C Slave Driver State Enumeration

  @Summary
    Defines the different states of the i2c slave.

  @Description
    This defines the different states that the i2c slave
    used to process transactions on the i2c bus.
*/
typedef enum
{
    S_SLAVE_IDLE,
    S_SLAVE_RECEIVE_MODE,
    S_SLAVE_TRANSMIT_MODE,
    S_SLAVE_LOW_BYTE_ADDRESS_DETECT,

} I2C_SLAVE_STATES;
typedef enum MG_E_I2C_STATE_
{
  MG_E_I2C_IDLE = 0,
  MG_E_I2C_READ,
  MG_E_I2C_WRITE,
  MG_E_I2C_BLOCK_WRITE,
} MG_E_I2C_STATE;
/**
 Section: Macro Definitions
*/
/* defined for I2C1 */
#define I2C1_TRANSMIT_REG                       I2C1TRN	// Defines the transmit register used to send data.
#define I2C1_RECEIVE_REG                        I2C1RCV	// Defines the receive register used to receive data.

#define I2C1_MASK_REG                           I2C1MSK	// Defines the address mask register.
#define I2C1_ADDRESS_REG                        I2C1ADD	// Defines thsssse address register. 

// The following control bits are used in the I2C state machine to manage
// the I2C module and determine next states.
#define I2C1_GENERAL_CALL_ENABLE_BIT            I2C1CONLbits.GCEN	// I2C General Call enable control bit.
#define I2C1_10_BIT_ADDRESS_ENABLE_BIT          I2C1CONLbits.A10M	// I2C Address Mode (7 or 10 bit address) control bit.
#define I2C1_RELEASE_SCL_CLOCK_CONTROL_BIT      I2C1CONLbits.SCLREL	// I2C clock stretch/release control bit.

// The following status bits are used in the I2C state machine to determine
// the next states.

#define I2C1_READ_NOT_WRITE_STATUS_BIT          I2C1STATbits.R_W    // I2C current transaction read/write status bit.
#define I2C1_DATA_NOT_ADDRESS_STATUS_BIT        I2C1STATbits.D_A    // I2C last byte receive was data/address status bit.
#define I2C1_RECEIVE_OVERFLOW_STATUS_BIT        I2C1STATbits.I2COV	// I2C receive buffer overflow status bit.
#define I2C1_GENERAL_CALL_ADDRESS_STATUS_BIT    I2C1STATbits.GCSTAT	// I2C General Call status bit.
#define I2C1_ACKNOWLEDGE_STATUS_BIT             I2C1STATbits.ACKSTAT	// I2C ACK status bit.
#define MG_I2C_RX_REG_OERR                      I2C1STATbits.I2COV      /* RX register error */

#define EMULATE_EEPROM_SIZE        64
#define I2C_DEFAULT_VAL            0xFF
#define MG_I2C_BASE_SLA_ADR        ((uint8) 0xB0)
#define MG_I2C_SDA_LOW_TIME_OUT    ((uint16)30U)
#define MG_I2C_SCL_LOW_TIME_OUT    ((uint16)30U)

#define I2C_CLEAR_INT_FLAG()       {IFS1bits.SI2C1IF = FALSE;}
#define MG_I2C_CLK_SCH_EN()        {I2C1CONLbits.SCLREL = TRUE; }
#define MG_I2C_STOP_IS_DETECT      (1U == I2C1STATbits.P)
#define MG_I2C_NACK_IS_DETECT      (1U == I2C1STATbits.ACKSTAT)
#define MG_I2C_PORT_IS_OPEN        (1U == I2C1CONLbits.I2CEN)
#define MG_I2C_PORT_IS_CLOSE       (0U == I2C1CONLbits.I2CEN)
#define MG_I2C_PORT_OPEN()         { I2C1CONLbits.I2CEN = TRUE; }
#define MG_I2C_PORT_CLOSE()        { I2C1CONLbits.I2CEN = FALSE; }
/*******************************************************************************
 * Global data
 ******************************************************************************/
volatile uint8_t I2C_u8ExpTxCnt;
volatile uint8_t I2C_u8ExpRxCnt;
volatile uint8_t I2C_u8I2cRxCnt;
volatile uint8_t I2C_u8I2cTxCnt;
volatile uint8_t I2C_u8I2cTxLen;
volatile uint8_t I2C_u8I2cRxLen;
volatile uint8_t I2C_u8PEC;
volatile uint8_t I2C_u8PecErrCmd;
volatile uint8_t I2C_State;

volatile uint8_t I2C_au8I2cRxBuf[I2C_RX_BUF_SIZE];
volatile uint8_t I2C_au8I2cTxBuf[I2C_TX_BUF_SIZE];
uint8_t u8I2cCommand;
volatile uint8_t u8I2cCmdDetected;
FLAG_STA Flg_sta;
uint8_t i2c_stop_det_flg;
uint8_t i2c_read_flg;
static uint16 I2C_mg_u16SclLowCnt = 0U;
static uint16 I2C_mg_u16SdaLowCnt = 0U;
static uint8_t I2C_mg_u8I2cAddrWr;
static uint8_t I2C_mg_u8I2cAddrWrOld;
static uint8_t I2C_mg_u8I2cAddrRd;
/**
 Section: Local Functions
*/

inline void __attribute__ ((always_inline)) I2C1_TransmitProcess(void);
inline void __attribute__ ((always_inline)) I2C1_ReceiveProcess(void);

/**
 Section: Local Variables
*/

static I2C_SLAVE_STATES   i2c1_slave_state;
static uint8_t            *p_i2c1_write_pointer;
static uint8_t            *p_i2c1_read_pointer;

/********************************************************************************
 * \brief         Init I2C module as Slave for PMBus.
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
static void mg_vI2cHwInitSlave(void)
{
  /*
   * Initial i2c 1 Module as Slave
   * for interface with external system, GUI
   */
  /* Disable i2c interface */
  I2C1CONLbits.I2CEN = 0;
  /* Disable Slave  Events interrupt */
  IEC1bits.SI2C1IE = 0;
  /* Disable Master Events interrupt */
  IEC1bits.MI2C1IE = 0;
  
  I2C1_SlaveAddressSet(MG_I2C_BASE_SLA_ADR>>1);
  I2C_mg_u8I2cAddrWrOld = I2C_mg_u8I2cAddrWr;
  I2C_mg_u8I2cAddrRd = I2C_mg_u8I2cAddrWr + 1;

  I2C1MSK = 0x00;
  /* 0 = I2CxADD is a 7-bit slave address; 1 = I2CxADD is a 10-bit slave address */
  I2C1CONLbits.A10M = 0;
  /* 0 = Slew rate control enabled; 1 = Slew rate control disabled */
  I2C1CONLbits.DISSLW = 0;
  /* 0 = Dis SMBus input thresholds; 1 = En I/O pin thresholds compliant with SMBus specification */
  I2C1CONLbits.SMEN = 1;
  /* 0 = Dis software or receive clock stretch; 1 = En software or receive clock stretch when operate as I2C slave */
  I2C1CONLbits.STREN = 1;
  /* Set Fscl = 400kHz operating at Fcy = 40MHz */
  I2C1BRG = 93;
  /* Enable and start interrupt */
  /* Set I2C1 Slave  Events Interrupt Priority */
  IPC4bits.SI2C1IP = I2C_INT_PRIO;
  /* Reset interrupt flag */
  IFS1bits.SI2C1IF = 0;
  /* Reset interrupt flag */
  IFS1bits.MI2C1IF = 0;
  /* Enable interrupt */
  IEC1bits.SI2C1IE = 1;
  /* Disable interrupt  */
  IEC1bits.MI2C1IE = 0;
  /* Enable i2c interface */
  I2C1CONLbits.I2CEN = 1;
}

/**
  Prototype:        void I2C1_Initialize(void)
  Input:            none
  Output:           none
  Description:      I2C1_Initialize is an
                    initialization routine that takes inputs from the GUI.
  Comment:          
  Usage:            I2C1_Initialize();
*/

void I2C1_Initialize(void)
{
    mg_vI2cHwInitSlave();    
}

void __attribute__ ( ( interrupt, no_auto_psv ) ) _SI2C1Interrupt ( void )
{
    uint8_t rcv_byte = I2C1_RECEIVE_REG; /* Get received byte */

    I2C_CLEAR_INT_FLAG(); /* reset RBF flag */
  //  MG_I2C_STOP_DET_FLG = 0;
  //  MG_I2C_READ_FLG = 0;
    I2C_mg_u16SclLowCnt = 0;
    I2C_mg_u16SdaLowCnt = 0;

    if (I2C_State == MG_E_I2C_IDLE)
    {
        I2C_u8I2cTxLen = 0;
        I2C_u8I2cTxCnt = 0;
        I2C_u8I2cRxCnt = 0;
        I2C_u8ExpTxCnt = 0;
        I2C_u8ExpRxCnt = 0;
        I2C_u8PEC = 0;
    }

  if (MG_I2C_RX_REG_OERR) /* receive mode = 1 receive new byte but still hold the previous one */
  {
    MG_I2C_RX_REG_OERR = 0;
    MG_I2C_CLK_SCH_EN();
    I2C1_Initialize();
    return;
  }
  /* Select between read and write */

    if ( I2C1_READ_NOT_WRITE_STATUS_BIT == 0 ) //write
    {           
        if( I2C1_DATA_NOT_ADDRESS_STATUS_BIT == 0 ) //address
        {//cmd come,waite for command in write data.
            /* Slave address match and slave ACK */
           // UART1_Write(0xA0); //423
        /* Calculate the PEC if supported */
#if PEC_ENABLE
            I2C_u8PEC = CRC_u8GetCrc8(0x00, I2C_mg_u8I2cAddrWr);
#endif
            I2C_State = MG_E_I2C_WRITE;
        }
        else if ( I2C1_DATA_NOT_ADDRESS_STATUS_BIT == 1 ) // data
        {    
           // UART1_Write(0xA1); //423
			//UART1_Write(I2C_State);
			//UART1_Write(rcv_byte);
          /* Calculate the PEC if supported */
#if PEC_ENABLE
            I2C_u8PEC = CRC_u8GetCrc8(I2C_u8PEC, rcv_byte);
#endif

          /* Last received byte is data */
          if (I2C_State == MG_E_I2C_WRITE)
          {
            if (I2C_u8I2cRxCnt < I2C_RX_BUF_SIZE)
            {
              I2C_au8I2cRxBuf[I2C_u8I2cRxCnt++] = rcv_byte;

              //Hulk for Bw_Br_Protocol
              if (1U == I2C_u8I2cRxCnt)
              {
                
                u8I2cCommand = I2C_au8I2cRxBuf[0];
                I2C_u8ExpRxCnt = gCmd[u8I2cCommand].Len + 1; //include cmd
                PMBUS_u8TransType.ALL = (gCmd[u8I2cCommand].type & 0x01FF);  //for first 9 status
                u8I2cCmdDetected = 1;
                
              }
                //Hulk for Bw_Br_Protocol
              else if (PMBUS_u8TransType.Bits.BLOCK_WRITE_EN || PMBUS_u8TransType.Bits.WR_BLK_RD_BLK_PRT)
              {
                if (2U == I2C_u8I2cRxCnt)
                {
                  if (PMB_1B_SMBALERT_MASK == u8I2cCommand && I2C_au8I2cRxBuf[1] > 1)  //special handling for 1Bh_SMBALERT_MASK
                  {
                    I2C_u8ExpRxCnt = 3;
                    PMBUS_u8TransType.ALL = 0x00;  //write word
                  }
                  else
                  {
                    I2C_u8ExpRxCnt = I2C_au8I2cRxBuf[1] + 2; // add 2 bytes (Cmd and Cnt)
                  }
                }
                if (PMBUS_u8TransType.Bits.WR_BLK_RD_BLK_PRT && (I2C_u8ExpRxCnt == I2C_u8I2cRxCnt))
                {
                  
                  Flg_sta.i2c_bw_br_hdl_dat_flg = 1; //I2C_BW_BR_HDL_DAT_FLG
                  I2C_vProcessReceiveData();
                }
              }
			  else if(I2C_u8I2cRxCnt > 1)
			  {
                  
				Flg_sta.i2c_cmd_wait_flg = TRUE; 
				I2C_vProcessReceiveData();  
				I2C_u8I2cTxLen = 0;
				I2C_u8I2cTxCnt = 0;
				I2C_u8I2cRxCnt = 0;
			  } // end if
            }
          }
        }
    }
    else if ( I2C1_READ_NOT_WRITE_STATUS_BIT == 1 )        //read
    {        
       // MG_I2C_READ_FLG = 1;
        if( I2C1_DATA_NOT_ADDRESS_STATUS_BIT == 1 ) 	//data
        {
            //UART1_Write(0xA2);//423
            /* Read operation, output from slave */

            /* Last received byte is data */
          if ((I2C_u8I2cTxLen)
              && (I2C_u8I2cTxCnt <= I2C_u8I2cTxLen))
          {
            if (I2C_u8I2cTxCnt == I2C_u8I2cTxLen)
            {
#if PEC_ENABLE
              I2C_au8I2cTxBuf[I2C_u8I2cTxCnt] = I2C_u8PEC;
#else
              I2C_au8I2cTxBuf[I2C_u8I2cTxCnt] = I2C_DEFAULT_VAL;
#endif
            }
            if (!I2C1STATbits.ACKSTAT)
            {
              I2C1_TRANSMIT_REG = I2C_au8I2cTxBuf[I2C_u8I2cTxCnt++];
			  // UART1_Write(0xA4);//423
            }
          } /* end else */
          else
          {
            if (!I2C1STATbits.ACKSTAT)
            {
              I2C1_TRANSMIT_REG = I2C_DEFAULT_VAL;
            }
          }
#if PEC_ENABLE
            I2C_u8PEC = CRC_u8GetCrc8(I2C_u8PEC, I2C1_TRANSMIT_REG);
#endif
        }
        else if ( I2C1_DATA_NOT_ADDRESS_STATUS_BIT == 0 ) //address
        {
           // UART1_Write(0xA3);//423
            /* Read operation, output from slave */
            /* Last received byte is data */
            /* Last received byte is slave address */
            I2C_u8I2cTxLen = 0;
            I2C_u8I2cTxCnt = 0;
			I2C_u8I2cRxCnt = 0;  //for write cmd only

#if PEC_ENABLE
            I2C_u8PEC = CRC_u8GetCrc8(I2C_u8PEC, I2C_mg_u8I2cAddrRd);
#endif

            if (u8I2cCmdDetected)
            {
              //PMBUS_vSendData();
              if (PMBUS_u8TransType.Bits.BLOCK_READ_EN || PMBUS_u8TransType.Bits.WR_BLK_RD_BLK_PRT)
              {
                I2C_u8I2cTxLen++;
                PMBUS_vSendData(u8I2cCommand);
                I2C_au8I2cTxBuf[0] = I2C_u8I2cTxLen - 1;
                if (0 == I2C_au8I2cTxBuf[0])
                {
                  I2C_u8I2cTxLen = 0;
                }
              }
              else
              {
                PMBUS_vSendData(u8I2cCommand);
              }
            }
            I2C_State = MG_E_I2C_READ;
            if (0U == I2C_u8I2cTxLen)
            {
              I2C_au8I2cTxBuf[I2C_u8I2cTxCnt] = I2C_DEFAULT_VAL;
              Flg_sta.i2c_invalid_cmd_flg = TRUE; //I2C_INVALID_CMD_FLG
            }
            I2C1_TRANSMIT_REG = I2C_au8I2cTxBuf[I2C_u8I2cTxCnt++];
			//UART1_Write(0xA5);//423
#if PEC_ENABLE
            I2C_u8PEC = CRC_u8GetCrc8(I2C_u8PEC, I2C1_TRANSMIT_REG);
#endif
        }
    }
      MG_I2C_CLK_SCH_EN();
}

void I2C_vProcessReceiveData(void)
{
  if ((MG_I2C_NACK_IS_DETECT) //MG_I2C_STOP_IS_DETECT ???
      || Flg_sta.i2c_cmd_wait_flg  //I2C_CMD_WAIT_FLG
      || Flg_sta.i2c_bw_br_hdl_dat_flg) //I2C_BW_BR_HDL_DAT_FLG
  {

    if ((I2C_u8I2cRxCnt > 0)
        && ((I2C_State == I2C_STATE_WRITE_REQ)
        ))  //|| (I2C_State == I2C_STATE_BLOCK_WRITE)
    {
      /* Disable I2C interrupt */
      IEC1bits.SI2C1IE = 0;


      if (I2C_u8I2cRxCnt == I2C_u8ExpRxCnt)
      {

        vPMBus_HandleData(u8I2cCommand);
      }
#if PEC_ENABLE
      else if (I2C_u8I2cRxCnt == I2C_u8ExpRxCnt + 1) /* Correct byte count */
      {
        if (0U == I2C_u8PEC)
        { /* PEC is correct */
          vPMBus_HandleData(u8I2cCommand);
        }
        else
        {
          if (FALSE == I2C_PEC_ERR_FLG)
          {
            I2C_PEC_ERR_FLG = TRUE;
            I2C_u8PecErrCmd = u8I2cCommand;
          }
        }
      }
#endif
      else
      {
        /* send two many or two few byte count */
        if (I2C_u8ExpRxCnt == 0)
        {
          Flg_sta.i2c_invalid_cmd_flg = TRUE; //I2C_INVALID_CMD_FLG
        }
        else
        {
          if (//(FALSE == PMBUS_tStatus.u8StatusCmlP0.Bits.INVALID_CMD) &&  /* cmd is supported */
              ((I2C_u8I2cRxCnt != I2C_u8ExpRxCnt) || (I2C_u8I2cRxCnt != I2C_u8ExpRxCnt + 1)))
          { /* Host sends too many bytes */
            Flg_sta.i2c_invalid_cmd_flg = TRUE; //I2C_INVALID_DATA_FLG
          }
        }
      }
      I2C_u8I2cRxCnt = 0;
      IEC1bits.SI2C1IE = 1;
    }
   // if (!Flg_sta.i2c_bw_br_hdl_dat_flg)  //I2C_BW_BR_HDL_DAT_FLG
    {    
      I2C_State = MG_E_I2C_IDLE;
	  u8I2cCmdDetected = 0;
    }
    Flg_sta.i2c_cmd_wait_flg = 0; //I2C_CMD_WAIT_FLG
    Flg_sta.i2c_bw_br_hdl_dat_flg = 0; //I2C_BW_BR_HDL_DAT_FLG
  } // end if
} /* I2C_vProcessReceiveData() */

void Mcu_I2C1DataInit(void)
{
  uint8 u8Cnt;

  for (u8Cnt = 0; u8Cnt < I2C_RX_BUF_SIZE; u8Cnt++)
  {
    I2C_au8I2cRxBuf[u8Cnt] = 0x00;
  }

  for (u8Cnt = 0; u8Cnt < I2C_TX_BUF_SIZE; u8Cnt++)
  {
    I2C_au8I2cTxBuf[u8Cnt] = 0x00;
  }

  I2C_u8PEC = 0;
  I2C_u8PecErrCmd = 0;
  I2C_u8I2cTxLen = 0;
  I2C_u8I2cTxCnt = 0;
  I2C_u8I2cRxCnt = 0;
  I2C_u8ExpTxCnt = 0;
  I2C_u8ExpRxCnt = 0;
  Flg_sta.i16 = 0;
  u8I2cCmdDetected = 0;

} /* Mcu_I2C1DataInit() */
static void mg_vSetI2cAddress(uint8 u8Addr)
{
  MG_I2C_PORT_CLOSE()
  I2C1ADD = (u8Addr >> 1);
  //mg_vI2cHwInitSlave();
  MG_I2C_PORT_OPEN()
}

void I2C_vUpdateI2cAddress(void)
{
  static uint8 u8AddrMatchDly = 0;
  I2C_mg_u8I2cAddrWr = MG_I2C_BASE_SLA_ADR;

  if (I2C_mg_u8I2cAddrWrOld!= I2C_mg_u8I2cAddrWr)
  {
    if (u8AddrMatchDly > 20)
    { /*delay 200ms */
      mg_vSetI2cAddress(I2C_mg_u8I2cAddrWr);
      I2C_mg_u8I2cAddrWrOld = I2C_mg_u8I2cAddrWr;
      I2C_mg_u8I2cAddrRd = I2C_mg_u8I2cAddrWr + 1;
    }
    else
    {
      u8AddrMatchDly++;
    }
  }
  else
  {
    u8AddrMatchDly = 0;
  }
}

static void mg_vI2cReset(void)
{
  MG_I2C_PORT_CLOSE();
  Nop();
  MG_I2C_PORT_OPEN();
} /* mg_vI2cReset() */

/********************************************************************************
 * \brief         I2C timeout handler. called in schm.c every 1ms.
 *                check if I2C bus hung up (SCL or SDA low for 35ms)
 *                if yes:
 *                release the bus of the I2C interface by reseting module
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void I2C_vI2cTimeOutHandler(void)
{
  //  static uint8 u8I2cResetActiveOld = 0;
  Flg_sta.i2c_reset_flg = FALSE; //I2C_RESET_FLG

#if 0  /* No HW resret funciton */
  /* I2C Reset Pin check */
  if ((I2C_RESET_SYS_ACTIVE)
      && (!u8I2cResetActiveOld))
  {
    I2C_RESET_FLG = TRUE;
  }
  u8I2cResetActiveOld = I2C_RESET_SYS_ACTIVE;
#endif
  /* SCL status check */
  if (PORT_IN_I2C_SCL_IS_LOW)
  {
    if (I2C_mg_u16SclLowCnt < MG_I2C_SCL_LOW_TIME_OUT)
    {
      I2C_mg_u16SclLowCnt++;
    }
    else
    {
      I2C_mg_u16SclLowCnt = 0;
      Flg_sta.i2c_reset_flg = TRUE;  //I2C_RESET_FLG
    }
  }
  else
  {
    I2C_mg_u16SclLowCnt = 0;
  }

  /* SDA status check */
  if (PORT_IN_I2C_SDA_IS_LOW)
  {
    if (I2C_mg_u16SdaLowCnt < MG_I2C_SDA_LOW_TIME_OUT)
    {
      I2C_mg_u16SdaLowCnt++;
    }
    else
    {
      I2C_mg_u16SdaLowCnt = 0;
      Flg_sta.i2c_reset_flg = TRUE;  //I2C_RESET_FLG
    }
  }
  else
  {
    I2C_mg_u16SdaLowCnt = 0;
  }

  /* Reset I2C module to release lines */
  if (TRUE == Flg_sta.i2c_reset_flg) //I2C_RESET_FLG
  {
    mg_vI2cReset();
  }
} /* I2C_vI2cTimeOutHandler */

void I2C1_SlaveAddressMaskSet(
                                uint16_t mask)
{
    I2C1_MASK_REG = mask;
}

void I2C1_SlaveAddressSet(
                                uint16_t address)
{
    if (address > 0x7F)
    {
        // use 10 bit address
        I2C1_10_BIT_ADDRESS_ENABLE_BIT = true;
    }
    else
    {
        // use 7 bit address
        I2C1_10_BIT_ADDRESS_ENABLE_BIT = false;
    }
    i2c1_slave_state = S_SLAVE_IDLE;
    I2C1_ADDRESS_REG = address;

}


