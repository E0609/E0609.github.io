
/**
  I2C1 Generated Driver API Header File

  @Company
    Microchip Technology Inc.

  @File Name
    i2c1.h

  @Summary
    This is the generated header file for the I2C1 driver using PIC24 / dsPIC33 / PIC32MM MCUs

  @Description
    This header file provides APIs for driver for I2C1.
    Generation Information :
        Product Revision  :  PIC24 / dsPIC33 / PIC32MM MCUs - 1.167.0
        Device            :  dsPIC33EP128GS708

    The generated drivers are tested against the following:
        Compiler          :  XC16 v1.50
        MPLAB 	          :  MPLAB X v5.35
*/

/*
    (c) 2020 Microchip Technology Inc. and its subsidiaries. You may use this
    software and any derivatives exclusively with Microchip products.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION
    WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

    MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE
    TERMS.
*/

#ifndef _I2C1_H
#define _I2C1_H

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <xc.h>


/**
  I2C Slave Driver Status

  @Summary
    Defines the different status that the slave driver has
    detected over the i2c bus.

  @Description
    This defines the different status that the slave driver has
    detected over the i2c bus. The status is passed to the
    I2C1_StatusCallback() callback function that is implemented by
    the user of the slave driver as a parameter to inform the user
    that there was a change in the status of the driver due to
    transactions on the i2c bus. User of the slave driver can use these
    to manage the read or write buffers.

 */

typedef enum
{
    /* This state indicates that the slave driver has detected a transmit request from the master.
       The next transaction will be a read transaction. Application should prime the transmit
       buffer with the valid data to be sent to the master using the: I2C1_ReadPointerSet()
       
     */
    I2C1_SLAVE_TRANSMIT_REQUEST_DETECTED,
            
    /* This state indicates that the slave driver has detected a reception request from the master.
       The next transaction will be a write transaction. Application should set up the receive 
       buffer by setting the location of the receive buffer using the: I2C1_WritePointerSet()
     */
    I2C1_SLAVE_RECEIVE_REQUEST_DETECTED,

    /* This state indicates that the slave driver has received data from the master.
       Application can use this status to process the received data set up the receive
       buffer in anticipation of next reception in case the master sends more data. 
       See I2C1_SLAVE_RECEIVE_REQUEST_DETECTED.
     */
    I2C1_SLAVE_RECEIVED_DATA_DETECTED,
            
    /* This state indicates that the slave driver has detected the most significant
       byte of the 10-bit slave address. Another transaction with the least 
       significant byte of the 10-bit address with a read/write request will
       be detected next. This second detection is automatically done by the 
       driver which may return one of the following:
           a. I2C1_SLAVE_RECEIVE_REQUEST_DETECTED
           b. I2C1_SLAVE_TRANSMIT_REQUEST_DETECTED
           c. I2C1_SLAVE_10BIT_RECEIVE_REQUEST_DETECTED
       a or b is detected depending on the read/write bit of the received 
       control data. If c is detected next, the master decided to resend
       the most significant address.  
     */
    I2C1_SLAVE_10BIT_RECEIVE_REQUEST_DETECTED,

} I2C1_SLAVE_DRIVER_STATUS;

#define I2C1_SLAVE_DEFAULT_ADDRESS          99

/**
    @Summary
        Initializes and enables the i2c slave instance : 1

    @Description
        This routine initializes the i2c slave driver instance for : 1
        index, making it ready for clients to open and use it.

    @Preconditions
        None

    @Param
        None

    @Returns
        None

    @Example
        <code>
            
            uint8_t SlaveReadBuffer;
            uint8_t SlaveWriteBuffer;

            // initialize the i2c slave driver    
            I2C1_Initialize();
    
            // set up the slave driver
 
            // initialize the location of the read buffer
            I2C1_ReadPointerSet(SlaveReadBuffer);
            // initialize the location of the write buffer
            I2C1_WritePointerSet(SlaveWriteBuffer);
  
        </code>
*/

void I2C1_Initialize(void);


/**
    @Summary
        This function sets the slave address mask.

    @Description
        This function sets the 10-bit slave address mask to be able to
        respond to multiple addresses. This function should be called
        after the initialization of the module.

    @Preconditions
        None

    @Param
        mask - The address mask to be used when filtering
            addresses from the i2c master transactions.

    @Returns
        None

    @Example
        <code>
            Refer to I2C1_SlaveAddressSet() for an example	
        </code>

*/

void I2C1_SlaveAddressMaskSet(
                                uint16_t mask);

/**
    @Summary
        This function sets the slave address.

    @Description
        This function sets the 10-bit slave address to be used by the
        module when filtering transactions from the i2c masters in the
        bus. The function analyzes the given address and decides if
        the 10-bit or 7-bit mode will be enabled. Once the function
        returns, the given address is set for the slave module.

        This function should be called after the initialization of
        the module.

        When changing the slave address the module must be idle.

    @Preconditions
        None

    @Param
        address - The address to be used to determine if the transaction
            is intended for this slave module.

    @Returns
        None

    @Example
        <code>
            // initialize the i2c slave driver    
            I2C1_Initialize();
 
            // set the slave address and address mask if the default
            // values set in the initialize is not the desired values.
            I2C1_SlaveAddressMaskSet(0x0xF);
            I2C1_SlaveAddressSet(0x3C);
 
        </code>

*/

void I2C1_SlaveAddressSet(
                                uint16_t address);


/**
    @Summary
        This function sets the read pointer for the slave driver.

    @Description
        This function sets the read pointer that the driver will
        need to retrieve data that will be transmitted to the master
        whenever the master requests a read.

    @Preconditions
        None

    @Param
        *p - The pointer to the read buffer, that will be used to transmit
             data to the requesting i2c master.

    @Returns
        None

    @Example
        <code>
            Refer to I2C1_Initialize() for an example	
        </code>

*/

#define I2C_RX_BUF_SIZE            50
#define I2C_TX_BUF_SIZE            240
#define TIME_I2C_RELEASE           100   // * 10ms
#define I2C_STATE_IDLE             0x00
#define I2C_STATE_READ_REQ         0x01
#define I2C_STATE_WRITE_REQ        0x02
#define I2C_STATE_BLOCK_WRITE      0x03
//Control Status Flags
typedef union {
    unsigned int i16;
    struct {
        //0
        unsigned i2c_reset_flg:1;
        unsigned i2c_cmd_wait_flg:1;
        unsigned i2c_pec_err_flg:1;
        unsigned i2c_invalid_cmd_flg:1;
        unsigned i2c_invalid_data_flg:1;
        unsigned i2c_bw_br_hdl_dat_flg:1;
        unsigned :1;
        unsigned :1;
        unsigned :1;
        unsigned :1;
        unsigned :1;
        unsigned :1;
        unsigned :1;
        unsigned :1;
        unsigned :1;
        unsigned :1;
    };
}FLAG_STA;
extern void I2C_vProcessReceiveData(void);
extern void I2C_vI2cTimeOutHandler(void);
extern void I2C_vUpdateI2cAddress(void);
extern FLAG_STA Flg_sta;
extern FLAG_STA Hw_sta;
extern volatile uint8_t I2C_au8I2cTxBuf[I2C_TX_BUF_SIZE];
extern volatile uint8_t I2C_au8I2cRxBuf[I2C_RX_BUF_SIZE];
extern volatile uint8_t I2C_u8ExpTxCnt;
extern volatile uint8_t I2C_u8ExpRxCnt;
extern volatile uint8_t I2C_u8I2cRxCnt;
extern volatile uint8_t I2C_u8I2cTxCnt;
extern volatile uint8_t I2C_u8I2cTxLen;
extern volatile uint8_t I2C_u8I2cRxLen;
extern volatile uint8_t I2C_u8PEC;
extern volatile uint8_t I2C_u8PecErrCmd;
extern volatile uint8_t I2C_State;
extern void Mcu_I2C1DataInit(void);
#endif  // _I2C1_H