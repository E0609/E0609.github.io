/** *****************************************************************************
 * \file    Variables.c
 * \brief  
 *
 * \section AUTHOR
 *    1. 
 *
 * \section SVN
 *  $Date$
 *  $Author$
 *  $Revision$
 *
 * \section LICENSE
 * Copyright (c) 
 * All rights reserved.
 ***************************************************************************** */

/*******************************************************************************
 * Included header
 ******************************************************************************/

#include "Global.h"

/* Module header */
#define DEFINE_EXPORT_H
#include "Define.h"
#include "McuClock.h"
#include "McuAdc.h"
#include "McuGPIO.h"
#include "McuPwm.h"
/*******************************************************************************
 * Global data
 ******************************************************************************/

/*******************************************************************************
 * Local data types (private typedefs / structs / enums)
 ******************************************************************************/

/*******************************************************************************
 * Local constants and macros (private to module)
 ******************************************************************************/

/*******************************************************************************
 * Local data (private to module)
 ******************************************************************************/
uint16 u16q12VinAdcAvgPri;
uint16 u16q12IinAdcAvgPri;
uint16 u16q12PinAdcAvgPri;
uint16 u16q12VbulkAdcAvgPri;
uint64 Pout_Sum;
uint32 Pout_Avg;
//ST_INTCOM1_DATA stIntcom1_PriA;

GLOBAL_U_U16BIT uComStatus00;
GLOBAL_U_U16BIT uComStatus01;
GLOBAL_U_U16BIT uComStatus02;

GLOBAL_U_U16BIT uDigInStatus;
GLOBAL_U_U16BIT uDigOutStatus;
GLOBAL_U_U16BIT uPsuCtrlTrimStatus;


/****************PMBUS/I2C1*******************/

/*******************************************************************************
 * Global functions (public to other modules)
 ******************************************************************************/
/*******************************************************************************
 * Function:        Func64Div16to32
 * Parameters:      unsigned long long dividend, unsigned int divisor
 * Returned value:  unsigned long quotient
 * Description:     return: quotient = dividend / divisor
 * Calling:
 ******************************************************************************/
uint32_t Func64Div16to32(unsigned long long dividend, unsigned int divisor)
{
    uint16_t Remainder = 0;
    uint16_t DivResult[4];
    
    if (divisor > 0)
    {
        DivResult[3] = __builtin_divmodud((dividend >> 48), divisor, &Remainder);
        DivResult[2] = __builtin_divmodud((((dividend >> 32) & 0xFFFF) + ((unsigned long) Remainder << 16)), divisor, &Remainder);
        DivResult[1] = __builtin_divmodud((((dividend >> 16) & 0xFFFF) + ((unsigned long) Remainder << 16)), divisor, &Remainder);
        DivResult[0] = __builtin_divmodud(((dividend & 0xFFFF) + ((unsigned long) Remainder << 16)), divisor, &Remainder);

        return (((unsigned long long) DivResult[3] << 48) + ((unsigned long long) DivResult[2] << 32) +
          ((unsigned long) DivResult[1] << 16) + DivResult[0]);
    }
    else
        return (0);
}

void API_vV1AnalogFilter(void);

/*******************************************************************************
 * \brief         Initialize modules for 100us system time slice
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 ******************************************************************************/
void API_vDataInit(void)
{
  u16_CclHhrLow = 0;
  u16_CclHhrHigh = 0;
  u16q12VinAdcAvgPri = 0;
  u16q12IinAdcAvgPri = 0;
  u16q12PinAdcAvgPri = 0;
  u16q12VbulkAdcAvgPri= 0;
  uComStatus00.ALL = 0;
  uComStatus01.ALL = 0;
  uComStatus02.ALL = 0;
} /* API_vDataInit() */

/*******************************************************************************
 * \brief         filter
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 ******************************************************************************/
void API_vV1AnalogFilter(void)
{
  static uint8 u8V1Filter_Counter = 0;

  aAdcAverage[MG_U8_ADC_INDEX_V1_CURR].u32Sum += stAdcBufResult.u16AdcBufV1Curr;

  aAdcAverage[MG_U8_ADC_INDEX_V1_VOLT_VEA].u32Sum += stAdcBufResult.u16AdcBufV1VoltVEA;

  aAdcAverage[MG_U8_ADC_INDEX_V1_VOLT_EXT].u32Sum += stAdcBufResult.u16AdcBufV1VoltExt;

  aAdcAverage[MG_U8_ADC_INDEX_V1_ISHARE].u32Sum += stAdcBufResult.u16AdcBufV1IShareVolt;

  aAdcAverage[MG_U8_ADC_INDEX_V1_ILOCAL].u32Sum += stAdcBufResult.u16AdcBufV1ILocalVolt;
  
  aAdcAverage[MG_U8_ADC_INDEX_V1_TRIM].u32Sum += stAdcBufResult.u16AdcBufVoutTrim;
  
  aAdcAverage[MG_U8_ADC_INDEX_TEMP].u32Sum += stAdcBufResult.u16AdcBufNtcSr;
  
  Pout_Sum += ((uint32_t) __builtin_muluu(stAdcBufResult.u16AdcBufV1VoltVEA, stAdcBufResult.u16AdcBufV1Curr));
  
  u8V1Filter_Counter ++;
  if (u8V1Filter_Counter >= 16)
  {
    /********I1 filter********/
    aAdcAverage[MG_U8_ADC_INDEX_V1_CURR].u16q12Avg = (aAdcAverage[MG_U8_ADC_INDEX_V1_CURR].u32Sum + 8) >> 4;
    aAdcAverage[MG_U8_ADC_INDEX_V1_CURR].u32Sum = 0;

    /********V1 Int filter********/
    aAdcAverage[MG_U8_ADC_INDEX_V1_VOLT_VEA].u16q12Avg = (aAdcAverage[MG_U8_ADC_INDEX_V1_VOLT_VEA].u32Sum + 8) >> 4;
    aAdcAverage[MG_U8_ADC_INDEX_V1_VOLT_VEA].u32Sum = 0;

    /********V1 Ext filter********/
    aAdcAverage[MG_U8_ADC_INDEX_V1_VOLT_EXT].u16q12Avg = (aAdcAverage[MG_U8_ADC_INDEX_V1_VOLT_EXT].u32Sum + 8) >> 4;
    aAdcAverage[MG_U8_ADC_INDEX_V1_VOLT_EXT].u32Sum = 0;

    /********I1 share filter********/
    aAdcAverage[MG_U8_ADC_INDEX_V1_ISHARE].u16q12Avg = (aAdcAverage[MG_U8_ADC_INDEX_V1_ISHARE].u32Sum + 8) >> 4;
    aAdcAverage[MG_U8_ADC_INDEX_V1_ISHARE].u32Sum = 0;

    /********I1 local filter********/
    aAdcAverage[MG_U8_ADC_INDEX_V1_ILOCAL].u16q12Avg = (aAdcAverage[MG_U8_ADC_INDEX_V1_ILOCAL].u32Sum + 8) >> 4;
    aAdcAverage[MG_U8_ADC_INDEX_V1_ILOCAL].u32Sum = 0;
    
    /********V1 Trim filter********/
    aAdcAverage[MG_U8_ADC_INDEX_V1_TRIM].u16q12Avg = (aAdcAverage[MG_U8_ADC_INDEX_V1_TRIM].u32Sum + 8) >> 4;
    aAdcAverage[MG_U8_ADC_INDEX_V1_TRIM].u32Sum = 0;

    /********V1 SR TEMP local filter********/
    aAdcAverage[MG_U8_ADC_INDEX_TEMP].u16q12Avg = (aAdcAverage[MG_U8_ADC_INDEX_TEMP].u32Sum + 8) >> 4;
    aAdcAverage[MG_U8_ADC_INDEX_TEMP].u32Sum = 0;
    
    Pout_Avg = Func64Div16to32((Pout_Sum>>8), 16);
    Pout_Sum = 0;
    
    u8V1Filter_Counter = 0;
  }
}

/*
 * End of file
 */




