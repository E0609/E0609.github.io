/* 
 * File:   Define.h
 * Author: 
 *
 * 
 */

#ifndef DEFINE_H
#define	DEFINE_H

#ifdef	__cplusplus
extern "C" {
#endif

    

    /*******************************************************************************
     * Included header
     ******************************************************************************/
#include "Global.h"
#include "McuClock.h"
   /**************600W PSU MODEL SELECTION***************/ 
#define PS_1601_1LA_12V        1
#define PS_1601_1LB_24V        0  

#define PS_24V_CS_UNIT1           1
#define PS_24V_CS_UNIT5           0 
    
#define SEC_FW_REV              0104        //v1.4
    /*******************************************************************************
     * Global constants and macros
     ******************************************************************************/

#define TOTAL_ADC_CH_NBR    ((uint8)13U)
#define ADC_FILTER_CH_NBR   ((uint8)3U)

#define DEBUG_PHASE         0

     
#if PS_1601_1LA_12V   
#define U16Q12_V1_MAX_INT       (20.0F)    //600W
#define U16Q12_V1_MAX_SENSE     (20.0F)    //600W 
#define U16Q12_I1_MAX           (86.0F)    //88.6 if from ADC reading,(66.0F)    //600W 27.5
#define U16Q12_POUT_MAX          (U16Q12_V1_MAX_INT * U16Q12_I1_MAX)    
#define U16Q12_I1_FULL_LOAD     (50.0F)
#define U16Q12_I1_FL_ADC        Q12(U16Q12_I1_FULL_LOAD / U16Q12_I1_MAX)  
#define U16Q12_VSB_MAX_SENSE    (8.42F)
#define U16Q12_ISB_FULL_LOAD    (2.0F)
#define U16Q12_ISB_MAX          (3.3F)
#define PWM_TRIM_DUTY_DEF        1763    //18.6% duty
#elif  PS_1601_1LB_24V 
#define U16Q12_V1_MAX_INT       (28.05F)    //600W
#define U16Q12_V1_MAX_SENSE     (28.05F)    //600W 
#define U16Q12_I1_MAX           (58.0F)     //88.6 if from ADC reading,(66.0F)    //600W 27.5
#define U16Q12_POUT_MAX         (U16Q12_V1_MAX_INT * U16Q12_I1_MAX)     //1627
#define U16Q12_I1_FULL_LOAD     (25.0F)  
#define U16Q12_I1_FL_ADC        Q12(U16Q12_I1_FULL_LOAD / U16Q12_I1_MAX)
#define U16Q12_VSB_MAX_SENSE    (8.42F)
#define U16Q12_ISB_FULL_LOAD    (2.0F)
#define U16Q12_ISB_MAX          (2.75F)
#if PS_24V_CS_UNIT1
#define PWM_TRIM_DUTY_DEF       4421    //46.87% duty
#elif PS_24V_CS_UNIT5
#define PWM_TRIM_DUTY_DEF       4290    //45.5% duty
#endif    
#endif
    


    /*CT trigger point setting*/
#if PS_1601_1LA_12V    
#define V1_CT_MAX_CURRENT           (33.0F)
#define V1_CT_HL_START_CMP_SET      Q12(10.0 / V1_CT_MAX_CURRENT)   //Q12(24.0 / V1_CT_MAX_CURRENT)    
#define V1_CT_HL_NORMAL_CMP_SET     Q12(15.0 / V1_CT_MAX_CURRENT)
#elif  PS_1601_1LB_24V     
#define V1_CT_MAX_CURRENT           (33.0F)
#define V1_CT_HL_START_CMP_SET      Q12(10.0 / V1_CT_MAX_CURRENT)   //Q12(24.0 / V1_CT_MAX_CURRENT)    
#define V1_CT_HL_NORMAL_CMP_SET     Q12(15.0 / V1_CT_MAX_CURRENT)
#endif   
 

#define U16Q12_VIN_MAX              (520.9F)
#define U16Q12_IIN_MAX              (26.83F)
#define U16Q12_VBULK_MAX            (515.9F)   
    
#define T1_INT_PRIO                 5
#define T3_INT_PRIO                 2
#define ADCP2_INT_PRIO              5
#define PSEMIP_INT_PRIO             6
#define V1_OCP_PRIO                 7
#define IC1_INT_PRIO                1
#define IC2_INT_PRIO                1
#define I2C_INT_PRIO                4

#define MG_PWM_FAN_FREQ             25E3
#define FAN_PWM_PERIOD              (unsigned int)(PWMCLOCKFREQ / MG_PWM_FAN_FREQ)

    
#define MG_PWM_TRIM_FREQ             100E3
#define PWM_TRIM_PERIOD              (unsigned int)(PWMCLOCKFREQ / MG_PWM_TRIM_FREQ)
#define PWM_TRIM_PERIOD_MAX          8490    //90% duty
#define PWM_TRIM_PERIOD_MIN          943     //10% duty   
    /***********************************************
     * Uart
     **********************************************/

    /* Define UART architecture */

    /* 0: only TX to PRI1, 1: TX to PRI1 and PRI2, 2: TX to PRI1 and PRI2 and broadcast*/
#define UART1_TX_PRI_SEQUENCE         0U
#define UART1_TX_PRI_1                0U


    /* TRUE: calculate crc for one byte once,  FALSE: calculate crc for all data once */
#define UART_CAL_CRC_DISTRIBUTED      TRUE

#define UART1_TX_BUF_SIZE             ((uint16)50U)  /* COM TX to PRI */
#define UART1_RX_BUF_SIZE             ((uint16)50U)  /* COM RX from PRI */

#define UART_MIN_FRAME_LEN	          ((uint16)6U)   /* STX,ADDR,LEN,DATA0,CRC16 */
#define UART_FRAME_AUX_LEN            ((uint16)5U)   /* STX,ADDR,LEN,CRC16 */

    /* Define frame format */
#define UART_FRAME_STX                0xAA           /* Start of a UART frame */
#define UART_ADDR_PRI_1               0x51           /* MCU address */


    /* Define supported baudrate */
#define UART_BAUDRATE_9600            9600U          /* 500us RX polling */
#define UART1_BAUDRATE                UART_BAUDRATE_9600   /* set baudrate */

#define UART_RX_BYTE_TIMEOUT_9600     3U             /* Value * 1ms = time */
#define UART_RX_FRAME_TIMEOUT_9600    6U             /* Value * 1ms = time */
#define UART_TX_TIMEOUT_9600          5U             /* Value * 1ms = time */


#if (UART_BAUDRATE_9600 == UART1_BAUDRATE)
#define UART1_RX_BYTE_TIMEOUT         UART_RX_BYTE_TIMEOUT_9600
#define UART1_RX_FRAME_TIMEOUT        UART_RX_FRAME_TIMEOUT_9600
#define UART1_TX_TIMEOUT              UART_TX_TIMEOUT_9600
#endif


#define UART1_FAIL_CNT                ((uint16)1000U)   /* Total 2s for each CH, Value * 1ms = time */
#define UART2_FAIL_CNT                ((uint16)1000U)   /* Total 2s for each CH, Value * 1ms = time */



    /***********************************************
     * PSU Ctrl
     **********************************************/
#define	INPUT_RAIL_NUM		1U

    /***********************************************
     * Intcom1 status bit
     **********************************************/
#define INTCOM1_PRI_UART_FAIL     uIntcom1Status.Bits.f0
//#define INTCOM1_PRI_UART_FAIL     uIntcom1Status.Bits.f1
//#define INTCOM1_PRI_RESERVED     uIntcom1Status.Bits.f2
//#define INTCOM1_PRI_RESERVED     uIntcom1Status.Bits.f3
#define INTCOM1_PRI_NO_RX_PKG     uIntcom1Status.Bits.f4
//#define INTCOM1_PRI_RESERVED     uIntcom1Status.Bits.f5
//#define INTCOM1_PRI_RESERVED    uIntcom1Status.Bits.f6
//#define INTCOM1_PRI_RESERVED     uIntcom1Status.Bits.f7
#define INTCOM1_VIN_OK_FOR_UART    uIntcom1Status.Bits.f8

    /***********************************************
     * DIO status bit
     **********************************************/
    /* Input */
#define FLG_DI_PSON_ACTIVE            uDigInStatus.Bits.f0
#define FLG_DI_VIN_FRO_PRI_OK         uDigInStatus.Bits.f1
#define FLG_DI_BULK_FRO_PRI_OK        uDigInStatus.Bits.f2
//#define FLG_DI_RESERVED                uDigInStatus.Bits.f3
//#define FLG_DI_RESERVED            uDigInStatus.Bits.f4
#define FLG_DI_I2C_RESET_ACTIVE       uDigInStatus.Bits.f5
#define FLG_DI_I2C_ADDR_A0_HIGH       uDigInStatus.Bits.f6
#define FLG_DI_I2C_ADDR_A1_HIGH       uDigInStatus.Bits.f7
#define FLG_DI_I2C_ADDR_A2_HIGH       uDigInStatus.Bits.f8

    /* Output */
//#define FLG_DO_RESERVED           uDigOutStatus.Bits.f0
//#define FLG_DO_RESERVED                uDioOutStatus.Bits.f1
#define FLG_DO_V1_OUTPUT_EN           uDigOutStatus.Bits.f2
#define FLG_DO_VSB_EN                 uDigOutStatus.Bits.f3
#define FLG_DO_PWOK_TO_SYS_OK         uDigOutStatus.Bits.f4
#define FLG_DO_OUTPUT_LED_ON          uDigOutStatus.Bits.f5
//#define FLG_DO_RESERVED           uDigOutStatus.Bits.f6
#define FLG_DO_V1_SR_CTRL_EN          uDigOutStatus.Bits.f7
//#define FLG_DO_RESERVED              uDigOutStatus.Bits.f8
#define FLG_DO_V1_ORING_CTRL_EN       uDigOutStatus.Bits.f9
//#define FLG_DO_RESERVED               uDigOutStatus.Bits.fa
#define FLG_DO_INOK_TO_SYS_OK         uDigOutStatus.Bits.fb
//#define FLG_DO_RESERVED           uDigOutStatus.Bits.fc

    /***********************************************
     * Primary status bit
     **********************************************/
    /* Status bits */
#define FLG_PRI_VDC_IN             stIntcom1_PriA.u16PriStatus00.Bits.f0  /* 1 = input valtage is DC */
#define FLG_PRI_VIN_OK             stIntcom1_PriA.u16PriStatus00.Bits.f1  /* 1 = input voltage is OK */
#define FLG_PRI_BULK_OK            stIntcom1_PriA.u16PriStatus00.Bits.f2  /* 1 = bulk voltage is OK */
#define FLG_PRI_VIN_LINE           stIntcom1_PriA.u16PriStatus00.Bits.f3  /* 1 = low line */
#define FLG_PRI_VIN_ALERT          stIntcom1_PriA.u16PriStatus00.Bits.f4  /* 1 = input voltage alert to inform sec. */
#define FLG_PRI_BULK_OV            stIntcom1_PriA.u16PriStatus00.Bits.f5  /* 1 = bulk is over voltage */
#define FLG_PRI_PFC_OT             stIntcom1_PriA.u16PriStatus00.Bits.f6  /* 1 = PSU is over temperature */
#define FLG_PRI_PFC_OTW            stIntcom1_PriA.u16PriStatus00.Bits.f7  /* 1 = PFC stage over temperature */
    /* Control bits */
#define FLG_PRI_PFC_GO             stIntcom1_PriA.u16PriStatus00.Bits.f8  /* 1 = PFC GO */
#define FLG_PRI_RELAY_ON           stIntcom1_PriA.u16PriStatus00.Bits.f9  /* 1 = relat is closed */
#define FLG_PRI_PFC_EN             stIntcom1_PriA.u16PriStatus00.Bits.fa  /* 1 = PFC is turn on */
#define FLG_PRI_EXT_EN             stIntcom1_PriA.u16PriStatus00.Bits.fb  /* 1 = extender is turn on */
#define FLG_PRI_PFC_OT_DIS         stIntcom1_PriA.u16PriStatus00.Bits.fc  /* 1 = PSU disable OT judgement */
#define FLG_PRI_BL_MODE            stIntcom1_PriA.u16PriStatus00.Bits.fd  /* 1 = Boot loader mode */
#define FLG_PRI_BL_EXIST           stIntcom1_PriA.u16PriStatus00.Bits.fe  /* 1 = Boot loader is existing */
#define FLG_PRI_PFC_OPP            stIntcom1_PriA.u16PriStatus00.Bits.ff  /* 1 = PFC stage over power */
    /* Primary Control bits */
#define FLG_PRI_VIN_OV             stIntcom1_PriA.u16PriStatus01.Bits.f0  /* 1 = input over voltage */
#define FLG_PRI_VIN_OVW            stIntcom1_PriA.u16PriStatus01.Bits.f1  /* 1 = over voltage warning */
#define FLG_PRI_VIN_UVW            stIntcom1_PriA.u16PriStatus01.Bits.f2  /* 1 = under voltage warning */
#define FLG_PRI_VIN_SAG            stIntcom1_PriA.u16PriStatus01.Bits.f3  /* 1 = input voltage is sag */
#define FLG_PRI_VIN_UV             stIntcom1_PriA.u16PriStatus01.Bits.f4  /* 1 = input is under voltage */
#define FLG_PRI_VIN_DROPOUT        stIntcom1_PriA.u16PriStatus01.Bits.f5  /* 1 = input voltage drops to 0V */

    
    /***********************************************
     * PMBUS/I2C status bit
     **********************************************/
//#define I2C_A0_FLG                u16I2cStatus0.Bits.f0         
//#define I2C_A1_FLG                u16I2cStatus0.Bits.f1
//#define I2C_A2_FLG                u16I2cStatus0.Bits.f2
#define I2C_RESET_SYS_ACTIVE      u16I2cStatus0.Bits.f3  
#define I2C_RESET_FLG             u16I2cStatus0.Bits.f4   
//#define I2C_SCL_IO_FLG            u16I2cStatus0.Bits.f5
//#define I2C_SDA_IO_FLG            u16I2cStatus0.Bits.f6
#define I2C_CMD_WAIT_FLG          u16I2cStatus0.Bits.f7   
#define I2C_PEC_ERR_FLG           u16I2cStatus0.Bits.f8   
#define I2C_INVALID_CMD_FLG       u16I2cStatus0.Bits.f9   
#define I2C_INVALID_DATA_FLG      u16I2cStatus0.Bits.fa   
#define I2C_BW_BR_HDL_DAT_FLG     u16I2cStatus0.Bits.fb   
    /*******************************************************************************
     * Global constants and macros
     ******************************************************************************/

    /***********************************************
     * ADC
     **********************************************/
    typedef enum E_VIP_ADC_AVE_INDEX_ {
        MG_U8_ADC_INDEX_V1_VOLT_EXT = 0,   /* 0 */
        MG_U8_ADC_INDEX_V1_VOLT_VEA,       /* 1 */
        MG_U8_ADC_INDEX_V1_CURR,           /* 2 */
        MG_U8_ADC_INDEX_V1_ISHARE,         /* 3 */
        MG_U8_ADC_INDEX_V1_ILOCAL,         /* 4 */
        MG_U8_ADC_INDEX_VSB_VOLT_EXT,      /* 5 */
        MG_U8_ADC_INDEX_V1_TRIM,           /* 6 */
        MG_U8_ADC_INDEX_VSB_CURR,          /* 7 */
        MG_U8_ADC_INDEX_TEMP,              /* 8 */ 
    } E_VIP_ADC_AVE_INDEX;

    typedef struct ST_ADC_ANALOG_ {
        uint16 u16q12Max;
        uint16 u16q12Min;
        uint16 u16q12Avg;
        uint32 u32Sum;
    } ST_ADC_ANALOG;

    /***********************************************
     * UART
     **********************************************/
    typedef union U_UARTSTATUS_ {

        struct {
            uint8 u8BootMode : 1;       /* bit0 */
            uint8 u8CrcErr : 1;         /* bit1 */
            uint8 u8McuAddrErr : 1;     /* bit2 */
            uint8 u8LenErr : 1;         /* bit3 */
            uint8 u8ByteTmout : 1;      /* bit4 */
            uint8 u8FrameTmout : 1;     /* bit5 */
            uint8 u8InvalidData : 1;    /* bit6 */
            uint8 u8UartRegErr : 1;     /* bit7 */
        } Bit;
        uint8 Byte;
    } U_UARTSTATUS;

    typedef struct ST_UART_DATA_ {
        uint16 u16TxDataCnt;
        uint16 u16RxDataCnt;
        uint16 u16RxByteTmOutEna;
        uint16 u16RxByteTmOutCnt;
        uint16 u16RxFrameTmOutEna;
        uint16 u16RxFrameTmOutCnt;
        uint16 u16TxTmOutEna;
        uint16 u16TxTmOutCnt;
    } ST_UART_DATA;

    typedef struct ST_INTCOM1_DATA_ {
        WORD_VAL u16q12VinAdc;
        WORD_VAL u16q12IinAdc;
        WORD_VAL u16q12PinAdc;
        WORD_VAL u16q12VbulkAdc;
        uint8 u8VoltInFreq;
        WORD_VAL u16q12PowerFactor;
        GLOBAL_U_U16BIT u16PriStatus00;
        GLOBAL_U_U16BIT u16PriStatus01;
        WORD_VAL u16PriDebug1;
        WORD_VAL u16PriDebug2;
        WORD_VAL u16q12PfcNtc;
        WORD_VAL u16q12AmbExhaust;
        WORD_VAL u16VoltInRms;
    } ST_INTCOM1_DATA;

    typedef struct ST_INTCOM2_DATA_ {
        WORD_VAL u16q12IoutAdc;
        GLOBAL_U_U16BIT u16SecStatus00;
        GLOBAL_U_U16BIT u16SecStatus01;
        WORD_VAL u16SecDebug1;
        WORD_VAL u16SecDebug2;
        WORD_VAL u16SecDebug3;
        WORD_VAL u16SecDebug4;
    } ST_INTCOM2_DATA;

    typedef struct ST_ADC_Result_ {
        uint16 u16AdcBufV1VoltExt;
        uint16 u16AdcBufV1VoltVEA;
        uint16 u16AdcBufV1Curr;
        uint16 u16AdcBufV1ILocalVolt;
        uint16 u16AdcBufV1IShareVolt;
        uint16 u16AdcBufVsbVoltExt;
        uint16 u16AdcBufVoutTrim;
        uint16 u16AdcBufVsbCurr;
        uint16 u16AdcBufNtcSr;
        uint16 u16AdcBufV1CurrCali;
        uint16 u16AdcBufV1IShareVoltCali;
    } ST_ADC_Result;

    typedef union U_FW_VERSION_ {
        uint64 u64Val;

        struct {
            uint16 u16Version;
            uint16 u8Reserved0;
            uint16 u8Reserved1;
            uint16 u8Reserved2;
        } u16Val;

        struct {
            uint8 u8MajorVersion;
            uint8 u8MinorVersion;
            uint8 u8Reserved0;
            uint8 u8Reserved1;
            uint8 u8Reserved2;
            uint8 u8Reserved3;
            uint8 u8Reserved4;
            uint8 u8Reserved5;
        } Bytes;
    } U_FW_VERSION;

    /***********************************************
     * FAN
     **********************************************/
    typedef struct ST_FAN_CTRL_ {
        uint16 u16Cnt;
        uint16 u16RPM;
        uint16 u16q12Duty;
        uint16 u16SysCmdRPM;
        uint16 u16q12SysCmdDuty;
        sint16 s16debug;
        uint16 u16tempindex;

        struct Bits_ {
            uint8 f0Warn : 1;
            uint8 f1Fail : 1;
            uint8 f2Ovrd : 1;
            uint8 f3IoPin : 1;
            uint8 Reserve : 4;
        } Bits;
    } ST_FAN_CTRL;
    /*******************************************************************************
     * Global data types (typedefs / structs / enums)
     ******************************************************************************/
#if defined(DEFINE_EXPORT_H) 
#define EXTERN
#else
#define EXTERN extern
#endif

    
    EXTERN uint16 u16q12VinAdcAvgPri;
    EXTERN uint16 u16q12IinAdcAvgPri;
    EXTERN uint16 u16q12PinAdcAvgPri;
    EXTERN uint16 u16q12VbulkAdcAvgPri;
    
    EXTERN uint16 u16_CclHhrLow;
    EXTERN uint16 u16_CclHhrHigh;
    EXTERN sint16 PSU_s16VrefControl;
    EXTERN uint64 Pout_Sum;
    EXTERN uint32 Pout_Avg;
    
    EXTERN ST_INTCOM1_DATA stIntcom1_PriA;
    EXTERN GLOBAL_U_U16BIT uComStatus00;
    EXTERN GLOBAL_U_U16BIT uComStatus01;
    EXTERN GLOBAL_U_U16BIT uComStatus02;

    EXTERN GLOBAL_U_U16BIT uDigInStatus;
    EXTERN GLOBAL_U_U16BIT uDigOutStatus;
    EXTERN GLOBAL_U_U16BIT uPsuCtrlTrimStatus;
    
    /***********************************************
     * Uart
     **********************************************/
    EXTERN uint8 au8Uart1TxBuf[UART1_TX_BUF_SIZE];
    EXTERN uint8 au8Uart1RxBuf[UART1_RX_BUF_SIZE];
    EXTERN uint16 u16Uart1TxDataNbr;
    EXTERN uint16 u16Uart1RxDataNbr;
    EXTERN uint8 u8Uart1TxBufUpdated;
    EXTERN uint8 u8Uart1RxNewFrame;
    EXTERN uint8 u8Uart1FrameTmoutFlg;
    EXTERN uint8 u8Uart1ByteTmoutFlg;
    EXTERN uint8 u8Uart1TxTmoutFlg;
    EXTERN uint8 u8Uart1BroadcastFlg;
    EXTERN uint16 u16Uart1RxCrc;
    EXTERN U_UARTSTATUS uUart1Status;
    EXTERN GLOBAL_U_U16BIT uIntcom1Status;

    EXTERN ST_ADC_Result stAdcBufResult;
    EXTERN ST_ADC_ANALOG aAdcAverage[TOTAL_ADC_CH_NBR];

    /**********FAN**************/
    EXTERN ST_FAN_CTRL stFan;
    /***********************************************
     * PMBUS/I2C
     **********************************************/
    EXTERN volatile GLOBAL_U_U16BIT u16I2cStatus0;
    EXTERN volatile uint8 u8I2cCmdDetected;
    EXTERN uint8 u8I2cCommand;
    /***********************************************
     * Output Trim and OVP test
     **********************************************/


    /***********************************************
     * FM Revision
     **********************************************/
    EXTERN U_FW_VERSION u64PmbusFwRevPri;
    EXTERN DWORD_VAL u64PmbusFwRevSec1;
    EXTERN DWORD_VAL u64PmbusFwRevSec1Old;


    /***********************************************
     * Input Line Status
     **********************************************/
    EXTERN uint8 u8LineStatus;

    
    
#undef EXTERN

    /*******************************************************************************
     * Global function prototypes (public to other modules)
     ******************************************************************************/
    extern void API_vDataInit(void);
    extern void API_vV1AnalogFilter(void);
    extern void DIO_ReadAllDigitalInputs(void);
    extern void DIO_WriteAllDigitalOutputs(void);


#ifdef	__cplusplus
}
#endif

#endif	/* DEFINE_H */

