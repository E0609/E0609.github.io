/*******************************************************************************
 * \file    McuPWM.c
 * \brief   init PWM
 *
 * \section AUTHOR
 *    1. Kiran
 *
 * \section SVN
 *  $Date$
 *  $Author$
 *  $Revision$
 *
 * \section LICENSE
 * Copyright (c) 
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * Included header
 ******************************************************************************/
#include <p33EP64GS504.h>
#include "Global.h"

/* Module header */
#include "McuPWM.h"
#include "McuClock.h"
#include "Define.h"
/*******************************************************************************
 * Local data types (private globals / structs / enums)
 ******************************************************************************/

/*******************************************************************************
 * Local data (private to module)
 ******************************************************************************/

/*******************************************************************************
 * Global data (public to other modules)
 ******************************************************************************/

/*******************************************************************************
 * Local function prototypes (private to module)
 ******************************************************************************/

void Mcu_PwmHwInit(void);
/*******************************************************************************
 * Function:        Init_PWM
 *
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     Initialize the PWM modules
 *
 ******************************************************************************/
void Mcu_PwmHwInit(void)
{
  PTCON = 0x0000;
  PTCON2 = 0x0000;
  PTPER = 0; //40KHz
  
   /***********************************************
   * PWM 1 Configuration  -- generate I local voltage
   **********************************************/
  /* PWM module controls PWMxH pin */
  IOCON1bits.PENH = 1;
  /* PWM module controls PWMxL pin */
  IOCON1bits.PENL = 0;  //used as GPIO
  /* PWM I/O pin pair is in the True Independent PWM Output mode */
  IOCON1bits.PMOD = 3;
  /* PWMxH and PWMxL pins are mapped to their respective pins */
  IOCON1bits.SWAP = 0;
  /* Dead time is disabled added into duty cycle */
  PWMCON1bits.DTC = 2;
  /* Disable Immediate duty cycle updates */
  PWMCON1bits.IUE = 0;
  /* PHASEx/SPHASEx registers provide time base period for this PWM generator */
  PWMCON1bits.ITB = 1;

  FCLCON1bits.CLMOD = 0;
  FCLCON1bits.FLTMOD = 3;

  PHASE1 = FAN_PWM_PERIOD; //25kHZ //FAN_PWM
  PDC1 = PHASE1>>1; 
  
//  SPHASE1 = 0x2000; //LLC_EN
//  SDC1 = SPHASE1; 

  /***********************************************
   * PWM 2 Configuration  -- generate I local voltage
   **********************************************/
  /* PWM module controls PWMxH pin */
  IOCON2bits.PENH = 1;
  /* PWM module controls PWMxL pin */
  IOCON2bits.PENL = 0;  //used as GPIO for FAN SPEED
  /* PWM I/O pin pair is in the True Independent PWM Output mode */
  IOCON2bits.PMOD = 3;
  /* PWMxH and PWMxL pins are mapped to their respective pins */
  IOCON2bits.SWAP = 0;
  /* Dead time is disabled added into duty cycle */
  PWMCON2bits.DTC = 2;
  /* Disable Immediate duty cycle updates */
  PWMCON2bits.IUE = 0;
  /* PHASEx/SPHASEx registers provide time base period for this PWM generator */
  PWMCON2bits.ITB = 1;

  FCLCON2bits.CLMOD = 0;
  FCLCON2bits.FLTMOD = 3;

  PHASE2 = PWM_TRIM_PERIOD;   //TRIM
#if PS_1601_1LA_12V
  PDC2 = PWM_TRIM_DUTY_DEF;  //PWM_TRIM_PERIOD>>1; 6E3 = 18.6% duty
#elif PS_1601_1LB_24V 
  PDC2 = PWM_TRIM_DUTY_DEF;  //0x0DC6;  37% duty   4290(45.5%)
#endif 
  
//  SPHASE2 = 0;   //FAN_SPEED
//  SDC2 =  0; 

  
  /***********************************************
   * PWM 3 Configuration 
   **********************************************/
    /* PWM module controls PWMxH pin */
  IOCON3bits.PENH = 0;
  /* PWM module controls PWMxL pin */
  IOCON3bits.PENL = 0;
  

  /***********************************************
   * turn on PWM module
   **********************************************/
  /* 1 = Enable the PWM Module */
  PTCONbits.PTEN = 1;
}




