/* 
 * File:   McuDAC.h
 * Author: 
 *
 * 
 */

#ifndef MCUDAC_H
#define	MCUDAC_H

#ifdef	__cplusplus
extern "C" {
#endif

extern void Mcu_DACHwInit(void);


#ifdef	__cplusplus
}
#endif

#endif	/* MCUDAC_H */

