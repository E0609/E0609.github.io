/** *****************************************************************************
 * \file    McuDAC.c
 * \brief   MCU DAC configurations
 *
 * \section AUTHOR
 *    1. 
 *
 * \section SVN
 *  $Date$
 *  $Author$
 *  $Revision$
 *
 * \section LICENSE
 * Copyright (c) Lite-On Singapore Pte Ltd
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * Included header
 ******************************************************************************/
#include <p33EP64GS504.h>



void Mcu_DACHwInit(void);
/*******************************************************************************
 * \brief         Initialize and configure the cmp's
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void Mcu_DACHwInit(void)
{
  /****************** ISHARE BUS OUT ***********************/
  /* Continue working in Idle mode */
  CMP3CONbits.CMPSIDL = 0;
  /* disconnect to DACOUT, depend on the function enable or not */
  CMP3CONbits.DACOE = 1;
  /* Select CMPxD for comparator */
  CMP3CONbits.INSEL = 0b00;
  /* 1 = Low Range: Max DAC Value = AVDD,  */
  CMP3CONbits.RANGE = 1;
  /* Set reference voltage */
  CMP3DAC = 0;
  /* Set Interrupt priority of Comparator */
  _AC3IP = 1; //V1_OCP_PRIO;
  /* Clear Comparator interrupt flag */
  _AC3IF = 0;
  /* Analog Comparator Interrupt Enable */
  _AC3IE = 0;

#if DEBUG_DISABLE_CCL
  CMP3CONbits.CMPON = 0;
#else
  /* Turn Module ON */
  CMP3CONbits.CMPON = 1;
#endif
}

