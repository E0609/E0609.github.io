/* 
 * File:   Dig_InOut.h
 * Author: kiranmeravanagi
 *
 * Created on March 29, 2021, 11:42 AM
 */

#ifndef DIG_INOUT_H
#define	DIG_INOUT_H

#ifdef	__cplusplus
extern "C" {
#endif

    extern void DIO_WriteAllDigitalOutputs(void);
    extern void DIO_ReadAllDigitalInputs(void);


#ifdef	__cplusplus
}
#endif

#endif	/* DIG_INOUT_H */

