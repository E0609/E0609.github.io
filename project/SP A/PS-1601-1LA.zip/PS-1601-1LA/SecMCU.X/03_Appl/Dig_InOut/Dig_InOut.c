/*******************************************************************************
 * \file    Dig_InOut.c
 * \brief   Read digital input GPIO and write digital output GPIO
 *
 * \section AUTHOR
 *    1. Kiran
 *
 * \section SVN
 *  $Date$
 *  $Author$
 *  $Revision$
 *
 * \section LICENSE
 * Copyright (c) 
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * Included header
 ******************************************************************************/

#include "Global.h"

/* Module header */
#include "McuGPIO.h"
#include "Dig_InOut.h"
#include "Protection.h"
#include "Define.h"
/*******************************************************************************
 * Local constants and macros (private to module)
 ******************************************************************************/
#define MG_INPUT_OK_SET_TIME         ((uint16)800)
#define MG_INPUT_OK_CLEAR_TIME       ((uint16)110) 
#define MG_BULK_OK_SET_TIME          ((uint16)20)
#define MG_BULK_OK_CLEAR_TIME        ((uint16)10)
#define MG_PWOK_SET_DLY_TIME         ((uint16)2000)
#define MG_PSON_ACTIVE_SET_TIME      ((uint16)500)
#define MG_PSON_ACTIVE_CLEAR_TIME    ((uint16)200)

/*******************************************************************************
 * Local data (private to module)
 ******************************************************************************/


/*******************************************************************************
 * Global functions (public to other modules)
 ******************************************************************************/

void DIO_WriteAllDigitalOutputs(void);

/******************************************************************************
 * \brief     Read all input IO status
 *            called every 100us in schm.c
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *****************************************************************************/
void DIO_ReadAllDigitalInputs(void)
{
    
  /* input ok signal read */
  DEBOUNCE_SET_CLR_2(FLG_DI_VIN_FRO_PRI_OK,
                     PORT_IN_VIN_FRO_PRI_IS_OK,
                     PORT_IN_VIN_FRO_PRI_IS_NO_OK,
                     MG_INPUT_OK_SET_TIME,
                     MG_INPUT_OK_CLEAR_TIME);
  FLG_B_INPUT_OK = FLG_DI_VIN_FRO_PRI_OK;
    
  /* BULK ok signal read */
  DEBOUNCE_SET_CLR_2(FLG_DI_BULK_FRO_PRI_OK,
                     PORT_IN_VBULK_FRO_PRI_IS_OK,
                     PORT_IN_VBULK_FRO_PRI_IS_NO_OK,
                     MG_BULK_OK_SET_TIME,
                     MG_BULK_OK_CLEAR_TIME);
  FLG_B_BULK_OK = FLG_DI_BULK_FRO_PRI_OK;
  
  /* PSON signal read */
  DEBOUNCE_SET_CLR_2(FLG_DI_PSON_ACTIVE,
                     PORT_IN_PSON_IS_ACTIVE,
                     PORT_IN_PSON_IS_INACTIVE,
                     MG_PSON_ACTIVE_SET_TIME,
                     MG_PSON_ACTIVE_CLEAR_TIME);
  FLG_B_PSON_ENABLE = FLG_DI_PSON_ACTIVE;
  
      
  
} /* DIO_vReadAllDigitalInputs() */

/******************************************************************************
 * \brief     Write all input IO status       100us
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *****************************************************************************/
void DIO_WriteAllDigitalOutputs(void)
{
  static uint16 u16PwrOKDly = 0;
  static uint16 u16PwrNOKDly = 0;

  /* Power OK signal output*/
  if ((FALSE != FLG_B_INPUT_OK) && (FALSE != FLG_B_BULK_OK))  //16ms
  {   
        if ((FALSE != FLG_B_V1_PWOK_GOOD) && (FALSE != FLG_B_VSB_PWOK_GOOD) && (FALSE != FLG_B_PSON_ENABLE))
        {
          /* Power OK setting */
          if (u16PwrOKDly > MG_PWOK_SET_DLY_TIME)
          {
            u16PwrNOKDly = 2; /* No delay, when NOK */
            PROT_OUT_PWOK_TO_SYS_OK;
            FLG_B_PSU_PWOK_GOOD = TRUE;
          }
          else
          {
            u16PwrOKDly++;
          }
        }
        else
        {       
                u16PwrOKDly = 0;
                PROT_OUT_PWOK_TO_SYS_NOT_OK;
                FLG_B_PSU_PWOK_GOOD = FALSE;
        }    
  }
  else
  {
      /* Power NOK setting */
        if (u16PwrNOKDly > 0)
        {
          u16PwrNOKDly--;
        }
        else
        {
          u16PwrOKDly = 0;
          PROT_OUT_PWOK_TO_SYS_NOT_OK;
          FLG_B_PSU_PWOK_GOOD = FALSE;
        }      
  } 
  
  /*LED ON*/
  if(TRUE == FLG_B_V1_OUTPUT_OK )  
  {
      PORT_OUT_LED_EN;
  }else
  {
      PORT_OUT_LED_DIS;
  }
  
}




