/* 
 * File:   UartComm.h
 * Author: kiranmeravanagi
 *
 * Created on 29 July, 2021, 6:38 PM
 */

#ifndef UARTCOMM_H
#define	UARTCOMM_H

#ifdef	__cplusplus
extern "C" {
#endif

extern void INTCOM1_ComDataInit(void);
extern void INTCOM1_GetTxData(void);
extern void INTCOM1_GetRxData(void);

#ifdef	__cplusplus
}
#endif

#endif	/* UARTCOMM_H */

