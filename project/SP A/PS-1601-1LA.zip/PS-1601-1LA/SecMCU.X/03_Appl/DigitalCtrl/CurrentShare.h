/* 
 * File:   CurrentShare.h
 * Author: Kiranmeravanagi
 *
 * Created on 19 July, 2021, 1:24 PM
 */

#ifndef CURRENTSHARE_H
#define	CURRENTSHARE_H

#ifdef	__cplusplus
extern "C" {
#endif

    /*******************************************************************************
     * Local constants and macros (private to module)
     ******************************************************************************/
    /*******************************************************************************
     * Global constants and macros
     ******************************************************************************/
#include <p33EP64GS504.h>
    

#include "Define.h"
#include "McuClock.h"


 
    /*******************************************************************************
     * Global data
     ******************************************************************************/

    /*******************************************************************************
     * Global function prototypes
     ******************************************************************************/
    extern void VoutTrimAdjust(void); 
    extern void V1IshareCtrl(void);
    extern void V1IlocalCtrl(void);

    extern uint16 u16debugIshareInt;
    extern uint16 u16debugIshareExt;
    extern sint16 u16debugIshareDuty;
    
#ifdef	__cplusplus
}
#endif

#endif	/* CURRENTSHARE_H */

