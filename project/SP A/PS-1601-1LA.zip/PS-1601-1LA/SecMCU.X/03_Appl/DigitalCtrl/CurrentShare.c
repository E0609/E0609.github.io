/*******************************************************************************
 * \file    CurrentShare.c
 * \brief   
 *
 * \section AUTHOR
 *    1. Current share and Voltage trim function
 *
 * \section SVN
 *  $Date$
 *  $Author$
 *  $Revision$
 *
 * \section LICENSE
 * Copyright (c) Lite-ON Singapore Pte Ltd
 * All rights reserved.
 *******************************************************************************/

/*******************************************************************************
 * Included header
 ******************************************************************************/
#include <p33EP64GS504.h>
#include <xc.h>

#include "Global.h"
#include "McuPwm.h"
#include "McuAdc.h"
#include "McuGPIO.h"
#include "Define.h"
#include "Protection.h"
#include "CurrentShare.h"
/*******************************************************************************
 * Local constants and macros (private to module)
 ******************************************************************************/
#if PS_24V_CS_UNIT1
#define V1_ISHARE_GAIN            8856              // unit1
#elif PS_24V_CS_UNIT5
#define V1_ISHARE_GAIN            8970              // unit5 
#endif
/*******************************************************************************
 * Local data types (private typedefs / structs / enums)
 ******************************************************************************/

/*******************************************************************************
 * Local data (private to module)
 ******************************************************************************/
static sint16 V1_ext;
static uint16 u32IshareExtAvg;
static uint16 u32IshareIntAvg;
uint16 u16debugIshareInt;
uint16 u16debugIshareExt;
sint16 u16debugIshareDuty;
uint16 u16debugVoutduty;
/*******************************************************************************
 * Global functions (public to other modules)
 ******************************************************************************/
void VoutTrimAdjust(void);


/*******************************************************************************
 * Function:        ADCAN2Interrupt
 *
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     Handle control loop in the AN2 interrupt routine, 15us
 * Comment:         Voltage loop operation time 5uS~8uS
 ******************************************************************************/
void __attribute__((__interrupt__, no_auto_psv)) _ADCAN2Interrupt()
{
//  static uint8 u8OvpCnt = 0;
  static uint32 u32IshareDACout;
    static uint32 u32IshareDACoutSum;
    static uint16 u32IshareDACoutAvg;
  
  V1_ext = ADC_V1_VOLT_VEA;
  stAdcBufResult.u16AdcBufV1VoltVEA = V1_ext;
  stAdcBufResult.u16AdcBufV1VoltExt = ADC_V1_VOLT_EXT;
  stAdcBufResult.u16AdcBufV1Curr = ADC_I1_CURR;
  stAdcBufResult.u16AdcBufNtcSr = ADC_NTC_SR;
  stAdcBufResult.u16AdcBufV1IShareVolt = ADC_ISHARE_BUS;
  stAdcBufResult.u16AdcBufV1ILocalVolt = ADC_ISHARE_LOCAL;
  stAdcBufResult.u16AdcBufVsbVoltExt = ADC_VSB_VOLT;
  stAdcBufResult.u16AdcBufVsbCurr = ADC_VSB_CURR;
  stAdcBufResult.u16AdcBufVoutTrim = ADC_VTRIM;
  /**********************************/    
      
//  //Fast OVP detect
//  if (stAdcBufResult.u16AdcBufV1VoltVEA > MG_FAST_OV_POINT)
//  {
//    if (u8OvpCnt < 1) //15uS * (1+1) = 30uS
//    {
//      u8OvpCnt++;
//    }
//    else
//    {
//      FLG_B_V1_FW_FAST_OVP = TRUE;
//    }
//  }
//  else
//  {
//    u8OvpCnt = 0;
//  }
    

  if (FLG_B_V1_STATE == ON)
  {
    u32IshareDACout = (__builtin_mulss(stAdcBufResult.u16AdcBufV1Curr, V1_ISHARE_GAIN) >> 12);  //aAdcAverage[MG_U8_ADC_INDEX_V1_CURR].u16q12Avg
    u32IshareDACoutSum = u32IshareDACoutSum + u32IshareDACout - (u32IshareDACoutSum>>1);
    u32IshareDACoutAvg = u32IshareDACoutSum >>1;
    CMP3DAC = u32IshareDACoutAvg;
  }else
  {
      CMP3DAC = 0;
  }
  _ADCAN2IF = 0;
  return;
}
/*******************************************************************************
 * Function:        V1IlocalCtrl
 *
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     current transform to ilocal loop
 *
 ******************************************************************************/
void V1IlocalCtrl(void)
{  
    static uint32 u32IshareExtSum;
    static uint32 u32IshareIntSum;
    
    u32IshareExtSum = u32IshareExtSum + (stAdcBufResult.u16AdcBufV1IShareVolt) - (u32IshareExtSum>>2);      //aAdcAverage[MG_U8_ADC_INDEX_V1_ISHARE].u16q12Avg
    u32IshareExtAvg = u32IshareExtSum >>2;  
    
    u16debugIshareExt = u32IshareExtAvg;
    
    u32IshareIntSum = u32IshareIntSum + (stAdcBufResult.u16AdcBufV1ILocalVolt) - (u32IshareIntSum>>2);          //aAdcAverage[MG_U8_ADC_INDEX_V1_ILOCAL].u16q12Avg
    u32IshareIntAvg = u32IshareIntSum >>2;
    
    u16debugIshareInt = u32IshareIntAvg;
}


/*******************************************************************************
 * Function:        V1IshareCtrl
 *
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     current share loop
 *
 ******************************************************************************/
void V1IshareCtrl(void)
{
  static sint16 s16Err0_Ishare = 0;
  static sint16 s16Err1_Ishare = 0;
  static sint32 s32u0_ishare = 0;
  static sint32 s32u1_ishare = 0;
  static uint16 u16IshareOffset = 80;
  static uint16 u16IshareDuty;
  static uint16 u16Voutadjustduty;


  V1IlocalCtrl();
  if (FLG_B_V1_STATE)         
  {
//    if(stAdcBufResult.u16AdcBufV1Curr < Q12(5.0 / U16Q12_I1_MAX))
//    {
//      u16IshareOffset = 80;
//    }
//    else if((stAdcBufResult.u16AdcBufV1Curr > Q12(7.5 / U16Q12_I1_MAX)))
//    {
//      u16IshareOffset = 60;
//    }
    u16IshareOffset = 40;

    s16Err0_Ishare = (sint16) u32IshareExtAvg - (sint16) u32IshareIntAvg - u16IshareOffset;
    
    s16Err0_Ishare = s16Err0_Ishare >> 4;

    s32u0_ishare = s32u1_ishare + (sint32) s16Err0_Ishare * Q10(0.004) + (sint32) s16Err1_Ishare * Q10(-0.001); 

    if (s32u0_ishare < 0)
    {
      s32u0_ishare = 0;
    }
    else if (s32u0_ishare > Q10(0.5))
    {
      s32u0_ishare = Q10(0.5);
    }
    
    u16IshareDuty = ((uint32) s32u0_ishare * PWM_TRIM_PERIOD) >> 14;  
    
    u16debugIshareDuty = u16IshareDuty;
    
    u16Voutadjustduty = (uint16)(PWM_TRIM_DUTY_DEF - u16IshareDuty);
    
    if(u16Voutadjustduty > PWM_TRIM_PERIOD_MAX)
    {
        u16Voutadjustduty = PWM_TRIM_PERIOD_MAX;
    }else if(u16Voutadjustduty < PWM_TRIM_PERIOD_MIN)
    {
        u16Voutadjustduty = PWM_TRIM_PERIOD_MIN;
    }
    
    u16debugVoutduty = u16Voutadjustduty;  
    V1_TRIM_PWM_REG = u16Voutadjustduty;
    
    s16Err1_Ishare = s16Err0_Ishare;
    s32u1_ishare = s32u0_ishare;
  }
  else
  {
    s16Err0_Ishare = 0;
    s32u0_ishare = 0;
    s16Err1_Ishare = 0;
    s32u1_ishare = 0;
    V1_TRIM_PWM_REG = 0;
  }
}
/*******************************************************************************
 * Function:        VoutTrimAdjust
 *
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     V1 Output voltage adjust
 *
 ******************************************************************************/
void VoutTrimAdjust(void)
{
    static uint16 u16V1trim;
    static uint32 u32V1trimSum;
    static uint32 u32V1trimAvg;
    
    u32V1trimSum = u32V1trimSum + (aAdcAverage[MG_U8_ADC_INDEX_V1_TRIM].u16q12Avg) - (u32V1trimSum>>5);
    u32V1trimAvg = u32V1trimSum >>5;

    u16V1trim = ((uint32) (u32V1trimAvg) * PWM_TRIM_PERIOD_MAX) >> 12;
    
    if(u16V1trim > PWM_TRIM_PERIOD_MAX)
    {
        u16V1trim = PWM_TRIM_PERIOD_MAX;
    }else if(u16V1trim < PWM_TRIM_PERIOD_MIN)
    {
        u16V1trim = PWM_TRIM_PERIOD_MIN;
    }
    
    V1_TRIM_PWM_REG = u16V1trim; 
}
/*******************************************************************************
 * Function:        _CMP2Interrupt
 *
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     V1 OCP interrupt - CMP2
 *
 ******************************************************************************/

void __attribute__((__interrupt__, no_auto_psv)) _CMP2Interrupt()
{


  _AC2IF = 0;
  return;
}



