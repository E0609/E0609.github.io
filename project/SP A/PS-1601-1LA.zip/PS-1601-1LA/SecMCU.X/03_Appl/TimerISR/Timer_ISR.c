/*******************************************************************************
 * \file    
 * \brief   Timer_ISR for task processing
 *
 * \section AUTHOR
 *    1. 
 *
 * \section SVN
 *  $Date$
 *  $Author$
 *  $Revision$
 *
 * \section LICENSE
 * Copyright (c) 
 * All rights reserved.
 *******************************************************************************/

/*******************************************************************************
 * Included header
 ******************************************************************************/
#include <p33EP64GS504.h>
#include "xc.h"


/* Module header */
#include "global.h"
#include "Define.h"
#include "PsuState.h"
#include "Protection.h"
#include "McuGPIO.h"
#include "Sample.h"
#include "Timer_ISR.h"
#include "McuUart2.h"
#include "McuUart1.h"
#include "Pmbus.h"
/*******************************************************************************
 * Included header
 ******************************************************************************/

/*******************************************************************************
 * Local constants and macros (private to module)
 ******************************************************************************/

/*******************************************************************************
 * Local data types (private globals / structs / enums)
 ******************************************************************************/
typedef struct MG_stPsuFlowControl_
{
  uint16 u16BasicStepper;
  uint16 u16OnemsStepper;
  uint16 u16TenmsStepper;
} MG_stPsuFlowControl;

/*******************************************************************************
 * Local data (private to module)
 ******************************************************************************/
volatile MG_stPsuFlowControl mg_stPsuFlowCtrl;
volatile int16_t mg_stTimerStepCnt;

/*******************************************************************************
 * Global data (public to other modules)
 ******************************************************************************/
uint8 u8CTOCCnt;
/*******************************************************************************
 * Local function prototypes (private to module)
 ******************************************************************************/

/*******************************************************************************
 * Global functions (public to other modules)
 ******************************************************************************/

/*******************************************************************************
 * \brief         Initialize Timer Schedule data management
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void TIMER_SchDataInit(void)
{
  mg_stPsuFlowCtrl.u16BasicStepper = 0;
  mg_stPsuFlowCtrl.u16OnemsStepper = 0;
  mg_stPsuFlowCtrl.u16TenmsStepper = 0;
} /* TIMER_SchDataInit */

/** ****************************************************************************
 * \brief     Time slicing 1ms. called in endless loop.
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *****************************************************************************/
void __attribute__((__interrupt__, no_auto_psv)) _T1Interrupt(void)
{   
  mg_stTimerStepCnt++;
  switch (mg_stTimerStepCnt) {  //10ms
  case 1:
  {
    break;
  }
  case 2:
  {
     
    break;
  }
  case 3:
  {
    
    break;
  }
  case 4:
  {
    break;
  }
  case 5:
  {
    break;
  }
  case 6:
  {      
    Uart1_RxData();
    break;
  }
  case 7:
  {
    break;
  }
  case 8:
  {

    break;
  }
  case 9:
  {
    break;
  }
  case 10:
  {
    mg_stTimerStepCnt = 0;
    break;
  }
  default:
  {   
    mg_stTimerStepCnt = 0;
    break;
  }
  } 
  _T1IF = 0;
}


/** ****************************************************************************
 * \brief     Time slicing 100us. called in endless loop.
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *****************************************************************************/
void __attribute__((__interrupt__, no_auto_psv)) _T3Interrupt(void)
{
    
  DIO_ReadAllDigitalInputs();
  PSUstate_V1StatusControl();
  PSUstate_5VSTBStatusControl();
  DIO_WriteAllDigitalOutputs();
    Nop();
    Nop();
    LATAbits.LATA3 = 1;
    LATCbits.LATC0 = 1;
  mg_stPsuFlowCtrl.u16BasicStepper++;
  switch (mg_stPsuFlowCtrl.u16BasicStepper) {
    /* 100us per step - one step every 1ms  */
  case 1:
  {
    //Process_TxData();
	Uart1_TxData();
    
    break;
  }
  case 2:
  {
     
    break;
  }
  case 3:
  {
    
    break;
  }
  case 4:
  {
    RTV_vV1AnalogFilter();
    PROTECT_V1Curr();
    break;
  }
  case 5:
  {
    I2C_vI2cTimeOutHandler();
    break;
  }
  case 6:
  {

    break;
  }
  case 7:
  {
    break;
  }
  case 8:
  {

    break;
  }
  case 9:
  {
    break;
  }
  case 10:
  default:
  {
    mg_stPsuFlowCtrl.u16OnemsStepper++;
    switch (mg_stPsuFlowCtrl.u16OnemsStepper) {
      /* 1ms per step - one step every 10ms */
    case 1:
    {
      PMBUS_vUpdateStatusData();
      PMBUS_vUpdateDetDate();
      break;
    }
    case 2:
    {
      I2C_vUpdateI2cAddress();
      break;
    }
    case 3:
    {
        if((FLG_PMBUS_PSON)||(FLG_B_PSON_ENABLE))//status
        {
            Tx1_Buf[0]=0x02;  //ps_on
        }
        else if((FLG_PMBUS_PSON == 0)||(FLG_B_PSON_ENABLE == 0))
        {
            Tx1_Buf[0]=0x06;  //ps_off
        }  
      break;
    }
    case 4:
    {
      break;
    }
    case 5:
    {

      break;
    }
    case 6:
    {

      break;
    }
    case 7:
    {

      break;
    }
    case 8:
    {
 
      break;
    }
    case 9:
    {

      break;
    }
    case 10:
    default:
    {
      mg_stPsuFlowCtrl.u16TenmsStepper++;
      switch (mg_stPsuFlowCtrl.u16TenmsStepper) {
        /* 10ms per step - one step every 100ms  */
      case 1:
      {
        break;
      }
      case 2:
      {

        break;
      }
      case 3:
      {
        break;
      }
      case 4:
      {
          
        break;
      }
      case 5:
      {

        break;
      }
      case 6:
      {
          
        break;
      }
      case 7:
      {
        break;
      }
      case 8:
      {
        break;
      }
      case 9:
      {
        break;
      }
      case 10:
      default:
      {
        mg_stPsuFlowCtrl.u16TenmsStepper = 0;
        break;
      }
      } /* end of switch(tPsuFlowControl.u8TenmsStepper) */
      mg_stPsuFlowCtrl.u16OnemsStepper = 0;
      break;
    }
    } /* end of switch(tPsuFlowControl.u8OnemsStepper) */
    mg_stPsuFlowCtrl.u16BasicStepper = 0;
    break;
  }
  } /* end of switch (tPsuFlowControl.u8BasicStepper) */
  _T3IF = 0;
}
