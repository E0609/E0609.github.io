/* 
 * File:   TimerISR.h
 * Author: kiranmeravanagi
 *
 * Created on March 29, 2021, 11:45 AM
 */

#ifndef TIMERISR_H
#define	TIMERISR_H

#ifdef	__cplusplus
extern "C" {
#endif

    /*******************************************************************************
     * Global constants and macros (public to other modules)
     ******************************************************************************/
    extern uint8 u8CTOCCnt;


    /*******************************************************************************
     * Global function prototypes (public to other modules)
     ******************************************************************************/
    extern void TIMER_SchDataInit(void);


#ifdef	__cplusplus
}
#endif

#endif	/* TIMERISR_H */

