/******************************************************************************
 * \file    PsuState.c
 * \brief   State machine control of PSU
 *
 * \section AUTHOR
 *    1. Kiran
 *
 * \section SVN
 *  $Date$
 *  $Author$
 *  $Revision$
 *
 * \section LICENSE
 * Copyright (c) 
 * All rights reserved.
 *******************************************************************************/

/*******************************************************************************
 * Included header
 ******************************************************************************/

#include "Global.h"

/* Module header */
#include "Define.h"
#include "Protection.h"
#include "McuAdc.h"
#include "McuPwm.h"
#include "PsuState.h"
#include "McuGPIO.h"


/*******************************************************************************
 * Local constants and macros (private to module)
 ******************************************************************************/

#define PSU_PW_TURNON_DLY  5000
#define MG_V1_TURN_OFF_DLY   50 
#define MG_V1_TURN_OFF_FAULT_DLY   5 
#define PSU_VSB_TURN_ON_DLY 1000
#define MG_VSB_HOLDUP_DLY  50000


#define PSU_VSB_PWUP_DLY   500  /* 500 * 100us = 50ms */
#define PSU_VSB_OK_DLY     500     /* 500 * 100us = 50ms */
#define PSU_VSB_DOWN_DLY   17000   /* 10000 * 100us = 1.0s */
#define MG_VSB_TURN_OFF_DLY  250
/*******************************************************************************
 * Local data (private to module)
 ******************************************************************************/
static MG_V1_CTRL_STA PSU_mg_V1_state_ctrl = PSU_CTRL_V1_OFF;
static MG_VSB_CTRL_STA PSU_mg_VSB_state_ctrl = PSU_CTRL_VSB_OFF;
static uint16 psu_mg_u16V1TurnOnDly = 0;
static uint16 psu_mg_u16VsbTurnOnDly = 0;
/*******************************************************************************
 * Local function prototypes (private to module)
 ******************************************************************************/

/*******************************************************************************
 * Global data
 ******************************************************************************/

/*******************************************************************************
 * Global data types (public typedefs / structs / enums)
 ******************************************************************************/

/*******************************************************************************
 * Global functions (public to other modules)
 ******************************************************************************/
void PSUstate_DataInit(void);
void PSUstate_V1OnOffJudge(void);
void PSUstate_VsbOnOffJudge(void);
/*******************************************************************************
 * \brief         Initialize PSU State control data
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PSUstate_DataInit(void)
{  
  PSU_mg_V1_state_ctrl = PSU_CTRL_V1_OFF;
  PSU_mg_VSB_state_ctrl = PSU_CTRL_VSB_OFF;
  psu_mg_u16V1TurnOnDly = PSU_PW_TURNON_DLY;
  psu_mg_u16VsbTurnOnDly = PSU_VSB_TURN_ON_DLY;
}/* PSUstate_DataInit */


/*******************************************************************************
 * \brief         control Vsb status
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PSUstate_VsbStatusControl(void)
{
  static uint16 u16VsbPwUpDly = 0;
  static uint16 u16VsbPwOKDly = 0;
  static uint16 u16VsbPwDownDly = 0;

  PSUstate_VsbOnOffJudge();

  switch (PSU_mg_VSB_state_ctrl) {
  case PSU_CTRL_VSB_OFF:
  {
    FLG_B_VSB_STATE = OFF;

    PORT_OUT_VSB_OUTPUT_DIS;
    if ((psu_mg_u16VsbTurnOnDly > 0) && (FALSE != FLG_B_BULK_OK))
    {
      psu_mg_u16VsbTurnOnDly--;
    }
    else
    {
      if ((FALSE != FLG_B_VSB_PRISYS_CONDITION) && (FALSE == FLG_B_VSB_FAULT_CONDITION))
      {  
        PORT_OUT_VSB_OUTPUT_EN;
        FLG_B_VSB_STATE = ON;
        FLG_B_VSB_OUTPUT_OK = TRUE;
        FLG_B_VSB_PWOK_GOOD = TRUE;
        PSU_mg_VSB_state_ctrl = PSU_CTRL_VSB_RUN;
        u16VsbPwUpDly = 0;
      }
    }
    break;
  }

  case PSU_CTRL_VSB_RUN:
  {
      PROTECT_VsbVolt();
    if ((FALSE == FLG_B_VSB_PRISYS_CONDITION) || (FALSE != FLG_B_VSB_FAULT_CONDITION))
    {   
      FLG_B_VSB_STATE = OFF;
      FLG_B_VSB_OUTPUT_OK = FALSE;
      FLG_B_VSB_PWOK_GOOD = FALSE;
      u16VsbPwOKDly = 0;
      u16VsbPwDownDly = PSU_VSB_DOWN_DLY; 
      PORT_OUT_VSB_OUTPUT_DIS;
      PSU_mg_VSB_state_ctrl = PSU_CTRL_VSB_DOWN;

    }
    break;
  }

  case PSU_CTRL_VSB_DOWN:
  {
    if (u16VsbPwDownDly > 0)
    {
      u16VsbPwDownDly--;
    }
    else
    {
      PSU_mg_VSB_state_ctrl = PSU_CTRL_VSB_OFF;
    }
    break;
  }
  default:
  {
    PSU_mg_VSB_state_ctrl = PSU_CTRL_VSB_OFF;
    break;
  }
  }    
}
/*******************************************************************************
 * \brief         control V1 status
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PSUstate_V1StatusControl(void)
{
  static uint16 u16V1_PwrUpDly = 0;
  static uint16 u16V1_OutputOKDly = 0;

  PSUstate_V1OnOffJudge();

  switch (PSU_mg_V1_state_ctrl) {
  case PSU_CTRL_V1_OFF:
  {
    PSU_mg_V1PwrOff();

    if ((psu_mg_u16V1TurnOnDly > 0) && (FALSE != FLG_B_BULK_OK))
    {
      psu_mg_u16V1TurnOnDly--;
    }
    else
    {
      if ((FALSE != FLG_B_V1_PRISYS_CONDITION)
      && (FALSE == FLG_B_V1_FAULT_CONDITION))
      {
        PSU_mg_V1PwrOn();
        u16V1_PwrUpDly = 0;
        FLG_B_V1_OUTPUT_OK = TRUE;
        PSU_mg_V1_state_ctrl = PSU_CTRL_V1_RUN;
      }
    }
    u16StartMonV1UvpCnt = 0;
    PROTECT_V1Volt();
    break;
  }
  case PSU_CTRL_V1_RUN:
  {
    PROTECT_V1Volt();
    u16StartMonV1UvpCnt = 0;
    
    if ((FALSE == FLG_B_V1_PRISYS_CONDITION)
      || (FALSE != FLG_B_V1_FAULT_CONDITION))
    {
      PSU_mg_V1PwrOff();
      u16V1_PwrUpDly = 0;
      u16V1_OutputOKDly = 0;
      FLG_B_V1_OUTPUT_OK = FALSE;
      PSU_mg_V1_state_ctrl = PSU_CTRL_V1_OFF;
      psu_mg_u16V1TurnOnDly = PSU_PW_TURNON_DLY;
    }
    break;
  }

  default:
  {
    PSU_mg_V1_state_ctrl = PSU_CTRL_V1_OFF;
    break;
  }
  }
  
}

/*******************************************************************************
 * \brief         control psu on
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PSU_mg_V1PwrOn(void)
{
  FLG_B_V1_STATE = ON;
  PORT_OUT_V1_OUTPUT_EN;
  PORT_OUT_V1_ORING_EN;
  PORT_OUT_V1_SR_EN;
}

/*******************************************************************************
 * \brief         control psu off
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PSU_mg_V1PwrOff(void)
{
  FLG_B_V1_STATE = OFF;
  PORT_OUT_V1_OUTPUT_DIS;
  PORT_OUT_V1_ORING_DIS;
  PORT_OUT_V1_SR_DIS;
}

/*******************************************************************************
 * \brief         control psu Vsb start judge
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PSUstate_VsbOnOffJudge(void)
{
  static uint16 u16VsbFaultTurnOffDly = 0;
  static uint16 u16VsbHoldupDly = 0;

  if ((FALSE == FLG_B_VSB_OCP) && (FALSE == FLG_B_VSB_OVP) && (FALSE == FLG_B_VSB_HICCUP) && (FALSE == FLG_B_VSB_FAULT_LATCH)) 
  {
    FLG_B_VSB_FAULT_CONDITION = 0;
    u16VsbFaultTurnOffDly = 0;
  }
  else
  {
    if (FLG_B_VSB_OVP || FLG_B_VSB_OCP)
    {
      u16VsbFaultTurnOffDly = 0;
      FLG_B_VSB_FAULT_CONDITION = 1;
      FLG_B_VSB_PWOK_GOOD = FALSE;
    }
    else
    {
      if (u16VsbFaultTurnOffDly > MG_VSB_TURN_OFF_DLY) //de-assert PW_OK before turn off standby output
      {
        FLG_B_VSB_FAULT_CONDITION = 1;
      }
      else
      {
        u16VsbFaultTurnOffDly++;
        FLG_B_VSB_PWOK_GOOD = FALSE;
      }
    }
  }

  if (FALSE != FLG_B_BULK_OK)
  {
    FLG_B_VSB_PRISYS_CONDITION = 1;
    u16VsbHoldupDly = MG_VSB_HOLDUP_DLY;
  }
  else
  {
    if (u16VsbHoldupDly > 0)
    {
      u16VsbHoldupDly--;
      if (u16VsbHoldupDly < MG_VSB_TURN_OFF_DLY) 
      {
        FLG_B_VSB_PWOK_GOOD = FALSE;   //de-assert PW_OK before turn off standby output
      }
    }
    else
    {
      FLG_B_VSB_PRISYS_CONDITION = 0;
    }
  } 
}
/*******************************************************************************
 * \brief         control psu V1 start judge
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PSUstate_V1OnOffJudge(void)
{
  static uint16 mg_u16V1FaultTurnOffDly = 0;
  static uint16 mg_u16V1TurnOffDly = 0;
  static uint16 mg_u16pgturnondly = 0;

  if ((FALSE == FLG_B_V1_FAULT_LATCH) &&
      (FALSE == FLG_B_V1_FW_OVP) && 
      (FALSE == FLG_B_V1_OTP) &&
      (FALSE == FLG_B_V1_OC_HICCUP) && 
      (FALSE == FLG_B_V1_OCP) &&
      (FALSE == FLG_B_VSB_OCP) && 
      (FALSE == FLG_B_VSB_OVP) &&
      (FALSE == FLG_B_VSB_HICCUP) && 
      (FALSE == FLG_B_VSB_FAULT_LATCH)
      )     
  {
    FLG_B_V1_FAULT_CONDITION = 0; 
    mg_u16V1FaultTurnOffDly = 0;
    
    if (TRUE == FLG_B_V1_OUTPUT_OK)  // Power Ok 
    {
          mg_u16pgturnondly++;
          if(mg_u16pgturnondly > 99)
          {
              FLG_B_V1_PWOK_GOOD = TRUE;
              mg_u16pgturnondly = 0;
          }  
    }
  }
  else
  {
    if (FALSE != FLG_B_V1_FW_OVP) 
    {
      mg_u16V1FaultTurnOffDly = 0;
      FLG_B_V1_PWOK_GOOD = FALSE;
      FLG_B_V1_FAULT_LATCH = 1;
      FLG_B_V1_FAULT_CONDITION = 1;
    }
    else
    {
      if (mg_u16V1FaultTurnOffDly > MG_V1_TURN_OFF_FAULT_DLY)
      {
        FLG_B_V1_FAULT_CONDITION = 1;
      }
      else
      {
        mg_u16V1FaultTurnOffDly++;
        FLG_B_V1_PWOK_GOOD = FALSE;
      }
    }
  }
  
  if ((FALSE != FLG_B_PSON_ENABLE)&&
      (FALSE != FLG_B_VSB_OUTPUT_OK)&&   
      (FALSE != FLG_B_BULK_OK)
      )
  {
    mg_u16V1TurnOffDly = 0;
    FLG_B_V1_PRISYS_CONDITION = 1;
  }
  else
  {
    if (mg_u16V1TurnOffDly > MG_V1_TURN_OFF_DLY)
    {
      FLG_B_V1_PRISYS_CONDITION = 0;
    }
    else
    {
      mg_u16V1TurnOffDly++;
      FLG_B_V1_PWOK_GOOD = FALSE;
    }
  }
}





