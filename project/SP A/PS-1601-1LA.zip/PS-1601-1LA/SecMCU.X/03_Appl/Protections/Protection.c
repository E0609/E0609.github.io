/** ****************************************************************************
 * \file    Protection.c
 * \brief   Main Output and standby output protection
 *
 * \section AUTHOR
 *    1. 
 *
 * \section SVN
 *  $Date$
 *  $Author$
 *  $Revision$
 *
 * \section LICENSE
 * Copyright (c) 
 * All rights reserved.
 *******************************************************************************/

/*******************************************************************************
 * Included header
 ******************************************************************************/
#include "Global.h"
#include "Define.h"

/* Module header */

#include "McuAdc.h"
#include "McuGPIO.h"
#include "Protection.h"


/*******************************************************************************
 * Local constants and macros (private to module)
 ******************************************************************************/


/* Macro use for output judgment */

#if PS_1601_1LA_12V 
#define MG_U16Q12_V1_OVP_THR_HI       Q12(14.16 / U16Q12_V1_MAX_INT)
#define MG_U16Q12_V1_OVP_THR_LO       Q12(13.5 / U16Q12_V1_MAX_INT)
#define MG_U16Q12_V1_OVW_THR_HI       Q12(13.0 / U16Q12_V1_MAX_INT)
#define MG_U16Q12_V1_OVW_THR_LO       Q12(12.5 / U16Q12_V1_MAX_INT)
#define MG_U16Q12_V1_SCP_THR_LO       Q12(9.0 / U16Q12_V1_MAX_INT)
#define MG_U16_V1_OCP_THR_HI_HL       Q12(U16Q12_I1_FULL_LOAD * 1.10 / U16Q12_I1_MAX)   /* 110% load*/
#define MG_U16_V1_OCP_THR_LO_HL       Q12(U16Q12_I1_FULL_LOAD * 1.05 / U16Q12_I1_MAX)
#define MG_U16_V1_OCW_THR_HI_HL       Q12(U16Q12_I1_FULL_LOAD * 1.05 / U16Q12_I1_MAX)
#define MG_U16_V1_OCW_THR_LO_HL       Q12(U16Q12_I1_FULL_LOAD * 1.01 / U16Q12_I1_MAX)
#define MG_U16Q12_V1_SCP_HL_THR       Q12(U16Q12_I1_FULL_LOAD * 1.30 / U16Q12_I1_MAX)
#elif  PS_1601_1LB_24V
#define MG_U16Q12_V1_OVP_THR_HI       Q12(28.32 / U16Q12_V1_MAX_INT)
#define MG_U16Q12_V1_OVP_THR_LO       Q12(27.0 / U16Q12_V1_MAX_INT)
#define MG_U16Q12_V1_OVW_THR_HI       Q12(26.0 / U16Q12_V1_MAX_INT)
#define MG_U16Q12_V1_OVW_THR_LO       Q12(25.0 / U16Q12_V1_MAX_INT)
#define MG_U16Q12_V1_SCP_THR_LO       Q12(9.0 / U16Q12_V1_MAX_INT)
#define MG_U16_V1_OCP_THR_HI_HL       Q12(U16Q12_I1_FULL_LOAD * 1.10 / U16Q12_I1_MAX)   /* 110% load*/
#define MG_U16_V1_OCP_THR_LO_HL       Q12(U16Q12_I1_FULL_LOAD * 1.05 / U16Q12_I1_MAX)
#define MG_U16_V1_OCW_THR_HI_HL       Q12(U16Q12_I1_FULL_LOAD * 1.05 / U16Q12_I1_MAX)
#define MG_U16_V1_OCW_THR_LO_HL       Q12(U16Q12_I1_FULL_LOAD * 1.01 / U16Q12_I1_MAX)
#define MG_U16Q12_V1_SCP_HL_THR       Q12(U16Q12_I1_FULL_LOAD * 1.30 / U16Q12_I1_MAX)
#endif

#define MG_U16_V1_OVP_SET_TM           2
#define MG_U16_V1_OVW_SET_TM           10
#define MG_U16_V1_OVW_CLEAR_TM         10
#define MG_U16_I1_FAST_OCP_SET_TM      20
#define MG_U16_V1_SCP_SET_TM           2
#define MG_U16_V1_OC_RESET_TM          5000
#define MG_OCP_RETRY_TIMES             100
#define MG_OCP_HICCUP_OFF_TIME         5000


/*5Vsb Protection threshold*/
#define MG_U16Q12_VSB_OVP_THR_HI       Q12(5.75 / U16Q12_VSB_MAX_SENSE)   
#define MG_U16Q12_VSB_OVP_THR_LO       Q12(5.25 / U16Q12_VSB_MAX_SENSE)     
#define MG_U16Q12_VSB_SCP_THR_LO       Q12(3.0 / U16Q12_VSB_MAX_SENSE)
#define MG_U16Q12_VSB_SCP_HL_THR    Q12(U16Q12_ISB_FULL_LOAD * 1.50 / U16Q12_ISB_MAX)   /* 1.15 120% load*/
#define MG_U16Q12_VSB_OCP_THR_HI    Q12(U16Q12_ISB_FULL_LOAD * 1.17 / U16Q12_ISB_MAX)   /* 1.15 120% load*/
#define MG_U16Q12_VSB_OCP_THR_LO    Q12(U16Q12_ISB_FULL_LOAD * 1.05 / U16Q12_ISB_MAX)   /* 1.15 120% load*/

/*5Vsb Protection delays */
#define MG_U16_VSB_OCP_SET_TM          10
#define MG_VSB_OCP_RETRY_TIMES         10
#define MG_U16_VSB_OCP_OFF_TM          2500
#define MG_U16_VSB_OVP_SET_TM           2
/*******************************************************************************
 * Global data types (private typedefs / structs / enums)
 ******************************************************************************/
volatile GLOBAL_U_U16BIT stV1FaultFlag00, stVsbFaultFlag00, stLatchFaultFlag00;  
volatile GLOBAL_U_U16BIT stVoutStateFlag, stSysStateFlag00, stSysStateFlag01;
uint16 u16StartMonV1UvpCnt = 0;
uint8 u8V1OcpHiccupRetryTimes = 0;
uint8 u8VsbOcpHiccupRetryTimes = 0;
/*******************************************************************************
 * Local data (private to module)
 ******************************************************************************/
static uint16 MON_u16V1OcpHi = MG_U16_V1_OCP_THR_HI_HL;
static uint16 MON_u16V1OcpLo = MG_U16_V1_OCP_THR_LO_HL;

static uint16 MON_u16V1ScpHi = MG_U16Q12_V1_SCP_HL_THR;
static uint16 MON_u16VsbScpHi = MG_U16Q12_VSB_SCP_HL_THR;
/*******************************************************************************
 * Local function prototypes (private to module)
 ******************************************************************************/

/*******************************************************************************
 * Global functions (public to other modules)
 ******************************************************************************/
void PROTECT_DataInit(void);
void PROTECT_V1Volt(void);
void PROTECT_V1Curr(void);
void PROTECT_VsbVolt(void);
void PROTECT_VsbCurr(void);
void PROTECT_OTP(void);
/********************************************************************************
 * \brief         Initial all status flags
 *
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PROTECT_DataInit(void)
{
  stV1FaultFlag00.ALL = 0U;
  stVsbFaultFlag00.ALL = 0U;
  stVoutStateFlag.ALL = 0U;
  stSysStateFlag00.ALL = 0U;
  stSysStateFlag01.ALL = 0U;
  u8V1OcpHiccupRetryTimes = 0;
  u8VsbOcpHiccupRetryTimes = 0;
}


/********************************************************************************
 * \brief         Check LLC 12V voltage is OK or not
 *                Called in Timer_ISR.c every 100us
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PROTECT_V1Volt(void)
{
  static uint16 u16V1OVPDly = 0;

  /* V1 ovp monitor */
  if ((stAdcBufResult.u16AdcBufV1VoltVEA > MG_U16Q12_V1_OVP_THR_HI) || (FALSE != FLG_B_V1_FW_FAST_OVP))
  {
    if ((u16V1OVPDly < MG_U16_V1_OVP_SET_TM) && (FALSE == FLG_B_V1_FW_FAST_OVP))
    {
      u16V1OVPDly++;
    }
    else
    {
      FLG_B_V1_FAULT_LATCH = 1;
      FLG_B_V1_FW_OVP = 1;
      FLG_B_V1_FW_OVW = 1; 
      u16V1OVPDly = 0;
    }
  }
  else if (stAdcBufResult.u16AdcBufV1VoltVEA < MG_U16Q12_V1_OVP_THR_LO)
  {
    if (u16V1OVPDly > 0)
    {
      u16V1OVPDly--;
    }
  }
  
 /* V1 ovw monitor */
  DEBOUNCE_SET_CLR_2(FLG_B_V1_FW_OVW, /* The flag set or reset */
                     stAdcBufResult.u16AdcBufV1VoltVEA > MG_U16Q12_V1_OVW_THR_HI, /* set flag condition */
                     stAdcBufResult.u16AdcBufV1VoltVEA < MG_U16Q12_V1_OVW_THR_LO, /* rest flag condition */
                     MG_U16_V1_OVW_SET_TM, /* set time */
                     MG_U16_V1_OVW_CLEAR_TM); /* reset time */
}
/********************************************************************************
 * \brief         Check 5Vsb Over voltage
 *                Called in Timer_ISR.c every 100us
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PROTECT_VsbVolt(void)
{
  static uint16 u16VsbOVPDly = 0;

  /* V1 ovp monitor */
  if (stAdcBufResult.u16AdcBufVsbVoltExt > MG_U16Q12_VSB_OVP_THR_HI)
  {
    if ((u16VsbOVPDly < MG_U16_VSB_OVP_SET_TM))
    {
      u16VsbOVPDly++;
    }
    else
    {
      FLG_B_VSB_FAULT_LATCH = 1;
      FLG_B_VSB_OVP = 1;
      FLG_B_VSB_OVW = 1; 
      u16VsbOVPDly = 0;
    }
  }
  else if (stAdcBufResult.u16AdcBufVsbVoltExt < MG_U16Q12_VSB_OVP_THR_LO)
  {
    if (u16VsbOVPDly > 0)
    {
      u16VsbOVPDly--;
    }
  }
}
/********************************************************************************
 * \brief         Check main output current is OK or not
 *                 Called in Timer_ISR.c every 1ms
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PROTECT_V1Curr(void)
{
  static uint32 u32V1ScpDly = 0;
  static uint32 u32V1OcpDly = 0;
  static uint16 u16V1OcpResetCnt = 0;
  static uint16 u16V1OcpHiccupOffTimeCnt = 0;

  if (OFF != FLG_B_V1_STATE)
  {
    if ((stAdcBufResult.u16AdcBufV1Curr > MON_u16V1ScpHi) && (stAdcBufResult.u16AdcBufV1VoltVEA < MG_U16Q12_V1_SCP_THR_LO))
    {
      u16V1OcpResetCnt = 0;

      if (u32V1ScpDly < MG_U16_V1_SCP_SET_TM)
      {
        u32V1ScpDly++;
      }
      else
      { 
        FLG_B_V1_OCW = TRUE;
        FLG_B_V1_SCP_TEMP = TRUE;
        FLG_B_V1_OC_HICCUP = TRUE;
        u32V1ScpDly = 0;
      }
    }
    else if (aAdcAverage[MG_U8_ADC_INDEX_V1_CURR].u16q12Avg > MON_u16V1OcpHi)
    {
      u16V1OcpResetCnt = 0;
      if (u32V1OcpDly < MG_U16_I1_FAST_OCP_SET_TM)
      {
        u32V1OcpDly++;
      }
      else
      {
        FLG_B_V1_OCW = TRUE;
        FLG_B_V1_SCP_TEMP = TRUE;
        FLG_B_V1_OC_HICCUP = TRUE;
        u32V1OcpDly = 0;
      }
    }
    else if (aAdcAverage[MG_U8_ADC_INDEX_V1_CURR].u16q12Avg < MON_u16V1OcpLo)
    {
      if (u32V1ScpDly > 0)
      {
        u32V1ScpDly--;
      }
      if (u32V1OcpDly > 0)
      {
        u32V1OcpDly--;
      }
      if (u16V1OcpResetCnt > MG_U16_V1_OC_RESET_TM)
      {
        u32V1ScpDly = 0;
        u32V1OcpDly = 0;
        u8V1OcpHiccupRetryTimes = 0;
      }
      else
      {
        u16V1OcpResetCnt++;
      }
    }
  }
  else
  {
    u32V1ScpDly = 0;
    u32V1OcpDly = 0;
    
    if (FALSE != FLG_B_V1_OC_HICCUP)
    {
      if (u8V1OcpHiccupRetryTimes <= MG_OCP_RETRY_TIMES)
      {
        if (u16V1OcpHiccupOffTimeCnt > MG_OCP_HICCUP_OFF_TIME)
        {
          u16V1OcpHiccupOffTimeCnt = 0;
          u8V1OcpHiccupRetryTimes++;
          FLG_B_V1_OC_HICCUP = FALSE;
        }
        else
        {
          u16V1OcpHiccupOffTimeCnt++;
        }
      }
      else
      {
        if (FALSE != FLG_B_V1_SCP_TEMP)
        {
          FLG_B_V1_SCP = TRUE;
        }
        FLG_B_V1_OCP = TRUE;
        FLG_B_V1_FAULT_LATCH = TRUE;
        FLG_B_V1_OC_HICCUP = FALSE;
      }
    }
    else
    {
      u16V1OcpHiccupOffTimeCnt = 0;
    }
  }

}
/********************************************************************************
 * \brief         Check vsb over current
 *                 Called in TimerISR.c every 1ms
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PROTECT_VsbCurr(void)
{
  static uint16 u16VsbOcpDly = 0;
  static uint16 u16VsbScpDly = 0;
  static uint16 u16VsbOcpHiccupOffTimeCnt = 0;
  static uint16 u16VsbOcpResetCnt = 0;

  if (OFF != FLG_B_VSB_STATE)
  {
    if ((stAdcBufResult.u16AdcBufVsbCurr > MON_u16VsbScpHi) && (stAdcBufResult.u16AdcBufVsbVoltExt < MG_U16Q12_VSB_SCP_THR_LO))
    {
      u16VsbOcpResetCnt = 0;

      if (u16VsbScpDly < MG_U16_V1_SCP_SET_TM)
      {
        u16VsbScpDly++;
      }
      else
      { 
        FLG_B_VSB_HICCUP = TRUE;
        FLG_B_VSB_OCW = TRUE;
        u16VsbScpDly = 0;
      }
    }
    else if (stAdcBufResult.u16AdcBufVsbCurr >= MG_U16Q12_VSB_OCP_THR_HI)
    {
      u16VsbOcpResetCnt = 0;
      if (u16VsbOcpDly >= MG_U16_VSB_OCP_SET_TM)
      {
        FLG_B_VSB_HICCUP = TRUE;
        FLG_B_VSB_OCW = TRUE;
        u16VsbOcpDly = 0;
      }
      else
      {
        u16VsbOcpDly++;
      }
    }
    else if (stAdcBufResult.u16AdcBufVsbCurr < MG_U16Q12_VSB_OCP_THR_LO)
    {
      if (u16VsbScpDly > 0)
      {
        u16VsbScpDly--;
      }
      if (u16VsbOcpDly > 0)
      {
        u16VsbOcpDly--;
      }
      if (u16VsbOcpResetCnt > 5000)
      {
        u16VsbScpDly = 0;
        u16VsbOcpDly = 0;
        u8VsbOcpHiccupRetryTimes = 0;
      }
      else
      {
        u16VsbOcpResetCnt++;
      }
    }
  }
  else
  {
    u16VsbScpDly = 0;
    u16VsbOcpDly = 0;

    if (FALSE != FLG_B_VSB_HICCUP)
    {
      if (u8VsbOcpHiccupRetryTimes <= MG_VSB_OCP_RETRY_TIMES)
      {
        if (u16VsbOcpHiccupOffTimeCnt > MG_U16_VSB_OCP_OFF_TM)
        {
          u16VsbOcpHiccupOffTimeCnt = 0;
          u8VsbOcpHiccupRetryTimes++;
          FLG_B_VSB_HICCUP = FALSE;
        }
        else
        {
          u16VsbOcpHiccupOffTimeCnt++;
        }
      }
      else
      {
        FLG_B_VSB_OCP = TRUE;
        FLG_B_VSB_FAULT_LATCH = TRUE;
        FLG_B_VSB_HICCUP = FALSE;
      }
    }
    else
    {
      u16VsbOcpHiccupOffTimeCnt = 0;
    }
  }
}
/********************************************************************************
 * \brief         OTP Protection
 *
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PROTECT_OTP(void)
{
  static uint16 u16OTPoffDly = 0;
  static uint16 u16OTPrecDly = 0;

    /*OTP SR*/
    if ((aAdcAverage[MG_U8_ADC_INDEX_TEMP].u16q12Avg < 645) && (!FLG_B_V1_OTP))       //0.52V - 110deg
    {
        if(u16OTPoffDly > 30)
        {
            FLG_B_V1_OTP = 1;
            u16OTPrecDly = 0;
        }else
        {
            u16OTPoffDly++;
        }
    }else if(aAdcAverage[MG_U8_ADC_INDEX_TEMP].u16q12Avg > 930)            //100deg - 0.75V
    {
        if(u16OTPrecDly > 50)
        {
            FLG_B_V1_OTP = 0;
            u16OTPoffDly = 0;
        }else
        {
            u16OTPrecDly++;
        }
    }
}

