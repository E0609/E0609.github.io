/* 
 * File:   Protection.h
 * Author: kiranmeravanagi
 *
 * Created on March 29, 2021, 11:43 AM
 */

#ifndef PROTECTION_H
#define	PROTECTION_H

#ifdef	__cplusplus
extern "C" {
#endif

    /*******************************************************************************
     * Local constants and macros
     ******************************************************************************/

    /*******************************************************************************
     * Global data types (typedefs / structs / enums)
     ******************************************************************************/
    /***********************************************
     * Output
     **********************************************/
    /* Flags */
    /* V1 Fault */
#define FLG_B_V1_FW_OVP             stV1FaultFlag00.Bits.f0  /* 1 = V1 OVP */    
#define FLG_B_V1_OCP                stV1FaultFlag00.Bits.f1  /* 1 = V1 OCP */
#define FLG_B_V1_OCW                stV1FaultFlag00.Bits.f2  /* 1 = V1 OCW */
#define FLG_B_V1_FW_OVW             stV1FaultFlag00.Bits.f3  /* 1 = V1 OVW */
#define FLG_B_V1_SCP_TEMP           stV1FaultFlag00.Bits.f4  /* 1 = V1 SCP temp flag */
#define FLG_B_V1_FW_FAST_OVP        stV1FaultFlag00.Bits.f5  /* 1 = V1 fast OVP */
#define FLG_B_V1_OC_HICCUP          stV1FaultFlag00.Bits.f6  /* 1 = V1 OC Hiccup */
#define FLG_B_V1_SCP                stV1FaultFlag00.Bits.f7  /* 1 = V1 SCP */
#define FLG_B_V1_UVP                stV1FaultFlag00.Bits.f8  /* 1 = V1 UVP */
#define FLG_B_FAN_FAULT             stV1FaultFlag00.Bits.f9  /* 1 = Fan fault */    
#define FLG_B_FAN_WARNING           stV1FaultFlag00.Bits.fa  /* 1 = Fan Warning */
#define FLG_B_V1_OTP                stV1FaultFlag00.Bits.fa  /* 1 = SR OTP */
    
    /* Vsb Fault */
#define FLG_B_VSB_HICCUP                stVsbFaultFlag00.Bits.f0  /* 1 = Vsb Hiccup */    
#define FLG_B_VSB_OCP                   stVsbFaultFlag00.Bits.f1  /* 1 = Vsb OCP */
#define FLG_B_VSB_OVP                   stVsbFaultFlag00.Bits.f2  /* 1 = Vsb OVP */
#define FLG_B_VSB_UVP                   stVsbFaultFlag00.Bits.f3  /* 1 = Vsb UVP */
#define FLG_B_VSB_OCW                   stVsbFaultFlag00.Bits.f4  /* 1 = Vsb OCW */
#define FLG_B_VSB_OVW                   stVsbFaultFlag00.Bits.f5  /* 1 = Vsb OVW */
#define FLG_B_VSB_UVW                   stVsbFaultFlag00.Bits.f6  /* 1 = Vsb UVW */  
   
    /* Latch Fault */
#define FLG_B_V1_FAULT_LATCH            stLatchFaultFlag00.Bits.f0 /* 1 = V1 fault latch   */
#define FLG_B_VSB_FAULT_LATCH           stLatchFaultFlag00.Bits.f1 /* 1 = Vsb fault latch   */

#define FLG_B_INPUT_OK                  stSysStateFlag00.Bits.f0  /* 1 = INPUT OK */
#define FLG_B_BULK_OK                   stSysStateFlag00.Bits.f1  /* 1 = BULK OK */
#define FLG_B_PSON_ENABLE               stSysStateFlag00.Bits.f2  /* 1 = SYSTEM PSON ENABLE */
#define FLG_B_V1_FAULT_CONDITION        stSysStateFlag00.Bits.f3  /* 1 = V1 fault state */
#define FLG_B_V1_PRISYS_CONDITION       stSysStateFlag00.Bits.f4  /* 1 = V1 pri sys turn onoff state */
#define FLG_B_VSB_FAULT_CONDITION       stSysStateFlag00.Bits.f5  /* 1 = Vsb fault state */
#define FLG_B_VSB_PRISYS_CONDITION      stSysStateFlag00.Bits.f6  /* 1 = Vsb pri sys turn onoff state */


#define FLG_B_V1_STATE                  stVoutStateFlag.Bits.f0  /* 1 = V1 ON */
#define FLG_B_V1_CCL                    stVoutStateFlag.Bits.f1  /* 1 = V1 CURRENT LIMIT */
#define FLG_B_V1_CT                     stVoutStateFlag.Bits.f2  /* 1 = V1 CT */
#define FLG_B_V1_SOFT_START             stVoutStateFlag.Bits.f3  /* 1 = V1 soft start status */
#define FLG_B_V1_INIT_LOOP              stVoutStateFlag.Bits.f4  /* 1 = V1 initial loop */
#define FLG_B_V1_BURST_MODE             stVoutStateFlag.Bits.f5  /* 1 = V1 burst mode */
#define FLG_B_V1_PWOK_GOOD              stVoutStateFlag.Bits.f6  /* 1 = V1 is OK */
#define FLG_B_V1_OUTPUT_OK              stVoutStateFlag.Bits.f7  /* 1 = V1 OUTPUT OK */
#define FLG_B_V1_BOOT_CHARGE            stVoutStateFlag.Bits.f8  /* 1 = V1 soft start status */
#define FLG_B_VSB_STATE                 stVoutStateFlag.Bits.f9  /* 1 = VSB ON */   
#define FLG_B_VSB_OUTPUT_OK             stVoutStateFlag.Bits.fa  /* 1 = VSB OUTPUT OK */
#define FLG_B_VSB_PWOK_GOOD             stVoutStateFlag.Bits.fb  /* 1 = Vsb PWOK */
#define FLG_B_PSU_PWOK_GOOD             stVoutStateFlag.Bits.fc  /* 1 = V1 and Vsb PWOK */
    /*******************************************************************************
     * Global data
     ******************************************************************************/
    extern volatile GLOBAL_U_U16BIT stV1FaultFlag00, stVsbFaultFlag00, stLatchFaultFlag00;  
    extern volatile GLOBAL_U_U16BIT stVoutStateFlag, stSysStateFlag00, stSysStateFlag01;
    extern uint16 u16StartMonV1UvpCnt;
    
    /*******************************************************************************
     * Global function prototypes
     ******************************************************************************/
    extern void PROTECT_DataInit(void);
    extern void PROTECT_V1Curr(void);
    extern void PROTECT_V1Volt(void);
    extern void PROTECT_VsbCurr(void);
    extern void PROTECT_VsbVolt(void);
    extern void PROTECT_OTP(void);
    /********************************************************************************/


#ifdef	__cplusplus
}
#endif

#endif	/* PROTECTION_H */

