/*******************************************************************************
 * \file    PmbusCtrl.c
 * \brief   Pmbus communication with system
 *
 * \section AUTHOR
 *    1. Kiran
 *
 * \section SVN
 *  $Date$
 *  $Author$
 *  $Revision$
 *
 * \section LICENSE
 * Copyright (c) 
 * All rights reserved.
 *******************************************************************************/

/*******************************************************************************
 * Included header
 ******************************************************************************/
#include <p33EP64GS504.h>
#include "Global.h"
#include "xc.h"
/* Module header */
#include "Pmbus.h"
#include "Crc.h"
#include "McuI2C1.h"
#include "Protection.h"
#include "McuGPIO.h"
#include "Define.h"
#include "FanCtrl.h"
#include "CurrentShare.h"
/*******************************************************************************
 * Local constants and macros (private to module)
 ******************************************************************************/

typedef enum MG_E_SENSOR_UPDATE_
{
  MG_E_UPD_FAN_NTC = 0,
  MG_E_UPD_INPUT,
  MG_E_UPD_OUTPUT,
  MG_E_UPD_NUMBER,
} MG_E_SENSOR_UPDATE;

/*******************************************************************************
 * Local data types (private typedefs / structs / enums)
 ******************************************************************************/

/* Page Number */
#define MG_PAGE_00                     ((uint8)0)
#define MG_PAGE_01                     ((uint8)1)
#define MG_PAGE_FF                     ((uint8)0xFF)
#define MG_PAGE_MAX                    MG_PAGE_01

/* Operation Value */
#define MG_OPERATION_ON_80             (0x00U)      //(0x80U)
#define MG_ON_OFF_CONFIG_1D            (0x1DU)
#define MG_OPERATION_OFF_00            (0x00U)
#define MG_FRU_EEP_DEFAULT_DATA        (0x9AU)

/* Constant Data Definition */
//#define MG_UNLOCK_DEBUG_KEY_UL         (0x4C55)
//#define MG_LOCK_DEBUG_KEY_AAAA         (0xAAAA)

/* Delay Setting */
#define MG_STA_PWR_UP_UPD_DLY          ((uint8)300U)     /* When power up, to delay 4 seconds */
#define MG_STA_CLR_FLT_UPD_DLY         ((uint8)10U)      /* When clear fault, to delay 1 seconds */
#define MG_SMBALERT_SET_DLY            ((uint8)5U)


/*******************************************************************************
 * Local data (private to module)
 ******************************************************************************/
/*
 * supported Write commands
 * i2c received byte cnt, including cmd code, not including PEC
 */
const uint8 PMB_mg_au8I2cRxNumber[256] ={
  /*
  0   1   2   3   4   5   6   7   8   9   A   B   C   D   E   F
   */
  2,  2,  2,  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, /* $0x */
  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, /* $1x */
  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, /* $2x */
  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  3,  0,  0,  0,  0, /* $3x */
  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, /* $4x */
  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0 , 0,  0,  0,  0,  0, /* $5x */
  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, /* $6x */
  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, /* $7x */
  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  3,  3,  3, /* $8x */
  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, /* $9x */
  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, /* $Ax */
  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, /* $Bx */
  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, /* $Cx */
  3,  0,  2,  2,  0,  0,  2,  0,  0,  0,  2,  2,  0,  0,  0,  2, /* $Dx */
  2,  0,  2,  0,  0,  0,  3,  3,  2,  2,  3,  0,  0,  0,  0,  0, /* $Ex */
  2,  2,  0,  0,  0,  0,  0,  0,  0,  0,  2,  3,  0,  3,  0,  0, /* $Fx */
};

/* 
 * PMBUS transaction type
 * Bit7: 1 = Support block write - block read protocol; 0 = Unsupport block write - block read protocol
 * Bit6: Not use
 * Bit5: Not use
 * Bit4: 1 = Block write enable; 0 = Block write disable
 * Bit3: Not use
 * Bit2: Not use
 * Bit1: Not use
 * Bit0: 1 = Block read enable; 0 = Block read disable
 */
/*
 * 0x8X: block write - block read protocal
 * 0x1X: block write
 * 0x0X: disable block write
 * 0xX1: block read
 * 0xX0: disable block write
 */
const uint8 PMBUS_u8TransactionType[256] ={
  /* Write | Read */
  /* 0     1     2     3     4     5     6     7     8     9     A     B     C     D     E     F */
  0x00, 0x00, 0x00, 0x00, 0x00, 0x10, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* $0x */
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0x80, 0x00, 0x00, 0x00, 0x00, /* $1x */
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* $2x */
  0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* $3x */
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* $4x */
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* $5x */
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* $6x */
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* $7x */
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* $8x */
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* $9x */
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* $Ax */
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* $Bx */
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x11, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* $Cx */
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x10, 0x00, 0x01, 0x00, 0x00, 0x01, 0x11, 0x11, 0x00, /* $Dx */
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* $Ex */
  0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* $Fx */
};

const uint8 PMB_mg_au8QueryP0[] ={
  /* 0    1     2     3     4     5     6     7     8     9     A     B     C     D     E     F     */
  0xFC, 0xFC, 0xFC, 0x9C, 0x00, 0xDC, 0xBC, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* $0x */
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xBC, 0xBC, 0xFC, 0x00, 0x00, 0x00, 0x00, /* $1x */
  0xBC, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* $2x */
  0xBC, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xBC, 0xE0, 0x00, 0x00, 0x00, 0x00, /* $3x */
  0xA0, 0x00, 0x00, 0x00, 0x00, 0x00, 0xA0, 0x00, 0xA0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xA0, /* $4x */
  0x00, 0xA0, 0x00, 0x00, 0x00, 0xA0, 0x00, 0x00, 0x00, 0xA0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* $5x */
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* $6x */
  0x00, 0x00, 0x00, 0x00, 0xFC, 0x00, 0x00, 0x00, 0xBC, 0xBC, 0xBC, 0xBC, 0xBC, 0xBC, 0xBC, 0xBC, /* $7x */
  0xBC, 0xBC, 0x00, 0x00, 0x00, 0x00, 0xAC, 0xAC, 0xA0, 0xA0, 0xA0, 0xA0, 0xA0, 0xA0, 0xA0, 0xA0, /* $8x */
  0xA0, 0x00, 0x00, 0x00, 0x00, 0x00, 0xA0, 0xA0, 0xBC, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* $9x */
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* $Ax */
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* $Bx */
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* $Cx */
  0x00, 0xA0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* $Dx */
  0xFC, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFC, 0x00, 0x00, 0x00, 0x00, 0x00, /* $Ex */
  0xDC, 0xFC, 0xDC, 0x00, 0xFC, 0xBC, 0xBC, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00  /* $Fx */
};

static uint8 PMBUS_mg_u8Page;
static uint8 PMBUS_mg_u8EepProtect;
static MG_E_SENSOR_UPDATE PMBUS_mg_u8UpdSensor = MG_E_UPD_FAN_NTC;
static uint16 PMBUS_mg_u16StatusUpdDly = MG_STA_PWR_UP_UPD_DLY;
static uint8 PMBUS_mg_u8QueryCmd;
/*******************************************************************************
 * Local function prototypes (private to module)
 ******************************************************************************/
static void mg_vClearPageFault(void);
static void mg_vClearPage00Fault(void);
static void mg_vClearPageAllFault(void);
static uint16 mg_u16TxLinearDatFormatDiv128(uint32 u32DataIn);
/*******************************************************************************
 * Global data (public to other modules)
 ******************************************************************************/

PMBUS_U_OPERATION PMBUS_uOperation;
PMBUS_U_ON_OFF_CONFIG PMBUS_uOnOffConfig;
PMBUS_U_SYS_STATUS PMBUS_uSysStatus;
PMBUS_ST_DATA PMBUS_stData;
PMBUS_ST_STATUS PMBUS_stStatus;
WORD_VAL PMBUS_u16Vin_LinearTemp;
WORD_VAL PMBUS_u16Iin_LinearTemp;
WORD_VAL PMBUS_u16Vout_LinearTemp;
WORD_VAL PMBUS_u16Iout_LinearTemp;
PMBUS_U_TRANS_TYPE PMBUS_u8TransType;


/*******************************************************************************
 * Local data (private to module)
 ******************************************************************************/

/*******************************************************************************
 * Global functions (public to other modules)
 ******************************************************************************/

/*******************************************************************************
 * \brief         Initialize PMBus data
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PMBUS_vPmbusDataInit(void)
{
  /* System Control Status */
  PMBUS_uOperation.ALL = MG_OPERATION_ON_80;
  PMBUS_uOnOffConfig.ALL = MG_ON_OFF_CONFIG_1D;

  /* System Used Status */
  PMBUS_stStatus.u16StatusWordP0.ALL = 0;
  PMBUS_stStatus.u8StatusVoutP0.ALL = 0;
  PMBUS_stStatus.u8StatusIoutP0.ALL = 0;
  PMBUS_stStatus.u8StatusInputP0.ALL = 0;
  PMBUS_stStatus.u8StatusTempP0.ALL = 0;
  PMBUS_stStatus.u8StatusCmlP0.ALL = 0;
  PMBUS_stStatus.u8StatusOtherP0.ALL = 0;
  PMBUS_stStatus.u8StatusMfrP0.ALL = 0;
  PMBUS_stStatus.u8StatusFan12P0.ALL = 0;

  /* System Used Data */
  PMBUS_stData.u32DataCopy.u32Val = 0;
  PMBUS_stData.u16Vin_Report.u16Val = 0;
  PMBUS_stData.u16Iin_Report.u16Val = 0;
  PMBUS_stData.u16Pin_Report.u16Val = 0;
  PMBUS_stData.u16Vbulk_Report.u16Val = 0;
  PMBUS_stData.u16Vout_V1_Report.u16Val = 0;
  PMBUS_stData.u16Iout_V1_Report.u16Val = 0;
  PMBUS_stData.u16Pout_V1_Report.u16Val = 0;
  PMBUS_stData.u16Ishare_V1_Report.u16Val = 0;
  PMBUS_stData.u16Temperatue_1_Report.u16Val = 0;
  PMBUS_stData.u16Temperatue_2_Report.u16Val = 0;
  PMBUS_stData.u16Temperatue_3_Report.u16Val = 0;
  PMBUS_stData.u16FanSpeed_Report.u16Val = 0;
  PMBUS_stData.u16FanCmd_Report.u16Val = 0;


  /* Internal Used Data */
  PMBUS_uSysStatus.ALL = 0;
  PMBUS_mg_u8EepProtect = 0;


  PMBUS_mg_u8Page = 0;
  PMBUS_mg_u8UpdSensor = MG_E_UPD_FAN_NTC;

}/* PMBUS_vPmbusDataInit */

/*******************************************************************************
 * \brief          Clear fault or warning status
 *                  ucPage: page0, 1, FF
 *                  ucMode: 1: clear All, and can restart ( OPERATION )
 *                          2: clear All except STA_MFR, and can restart ( PS_ON, PS_KILL )
 *                          3: clear All, and can't restart ( CLEAR_FAULT, CLEAR_BITS )
 *                          4: clear All except STA_MFR, and can't restart
 *
 * \param[in]     -ucPage, ucMode
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PMBUS_vClearAllPageFault(void)
{
  mg_vClearPageAllFault();
}

/*******************************************************************************
 * \brief         Get linear data format value which divided by 128
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
static uint16 mg_u16TxLinearDatFormatDiv128(uint32 u32DataIn)
{
  uint16 u16Result = 0;
  if (u32DataIn > 130944)
  {
    if (u32DataIn > 2095104)
    {
      if (u32DataIn > 16760832)                                                                     //N14
      {
        u32DataIn = (u32DataIn + 16384) >> 15;
        u16Result = (uint16) (u32DataIn & 0x000003FF) + 0x4000;
      }
      else if (u32DataIn > 8380416)                                                                 //N13
      {
        u32DataIn = (u32DataIn + 8192) >> 14;
        u16Result = (uint16) (u32DataIn & 0x000003FF) + 0x3800;
      }
      else if (u32DataIn > 4190208)                                                                 //N12
      {
        u32DataIn = (u32DataIn + 4096) >> 13;
        u16Result = (uint16) (u32DataIn & 0x000003FF) + 0x3000;
      }
      else if (u32DataIn > 2095104)                                                                //N11
      {
        u32DataIn = (u32DataIn + 2048) >> 12;
        u16Result = (uint16) (u32DataIn & 0x000003FF) + 0x2800;
      }
    }
    else if (u32DataIn > 1047552)                                                                       //N10
    {
      u32DataIn = (u32DataIn + 1024) >> 11;
      u16Result = (uint16) (u32DataIn & 0x000003FF) + 0x2000;
    }
    else if (u32DataIn > 523776)                                                                        //N9
    {
      u32DataIn = (u32DataIn + 512) >> 10;
      u16Result = (uint16) (u32DataIn & 0x000003FF) + 0x1800;
    }
    else if (u32DataIn > 261888)                                                                     //N8
    {
      u32DataIn = (u32DataIn + 256) >> 9;
      u16Result = (uint16) (u32DataIn & 0x000003FF) + 0x1000;
    }
    else if (u32DataIn > 130944)                                                                    //N7
    {
      u32DataIn = (u32DataIn + 128) >> 8;
      u16Result = (uint16) (u32DataIn & 0x000003FF) + 0x0800;
    }
  }
  else if (u32DataIn > 8184)                                                                           //N3
  {
    if (u32DataIn > 65472)                                                                               //N6
    {
      u32DataIn = (u32DataIn + 64) >> 7;
      u16Result = (uint16) (u32DataIn & 0x000003FF) + 0x0000;
    }
    else if (u32DataIn > 32736)                                                                       //N5
    {
      u32DataIn = (u32DataIn + 32) >> 6;
      u16Result = (uint16) (u32DataIn & 0x000003FF) + 0xF800;
    }
    else if (u32DataIn > 16368)                                                                      //N4
    {
      u32DataIn = (u32DataIn + 16) >> 5;
      u16Result = (uint16) (u32DataIn & 0x000003FF) + 0xF000;
    }
    else if (u32DataIn > 8184)                                                                        //N3
    {
      u32DataIn = (u32DataIn + 8) >> 4;
      u16Result = (uint16) (u32DataIn & 0x000003FF) + 0xE800;
    }
  }
  else if (u32DataIn > 4092)                                                                           //N2
  {
    u32DataIn = (u32DataIn + 4) >> 3;
    u16Result = (uint16) (u32DataIn & 0x000003FF) + 0xE000;
  }
  else if (u32DataIn > 2046)                                                                           //N1
  {
    u32DataIn = (u32DataIn + 2) >> 2;
    u16Result = (uint16) (u32DataIn & 0x000003FF) + 0xD800;
  }
  else if (u32DataIn > 1023)                                                                           //N0
  {
    u32DataIn = (u32DataIn + 1) >> 1;
    u16Result = (uint16) (u32DataIn & 0x000003FF) + 0xD000;
  }
  else
  {
    u16Result = (uint16) (u32DataIn & 0x000003FF) + 0xC800;
  }
  return (u16Result);
}

/*******************************************************************************
 * \brief         Check the specific bit of the input data
 *
 * \param[in]     u16Data, u8BitNum
 * \param[in,out] -
 * \param[out]    - 
 *
 * \return        - TRUE or FALSE
 *
 *******************************************************************************/
boolean PMBUS_vCheckBit(uint16 u16Data, uint8 u8BitNum)
{
  if ((u16Data & (2^u8BitNum)) != 0)
  {
    return TRUE;
  }
  else
  {
    return FALSE;
  }
}

/*******************************************************************************
 * \brief         Copy sensor data to PMBus sensor registers   10ms
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PMBUS_vCopySensorData(void)
{
  uint16 u16Dummy = 0;
    
  switch (PMBUS_mg_u8UpdSensor) {
  case MG_E_UPD_FAN_NTC:
  {
      /* Update Fan Speed  */
    u16Dummy = mg_u16TxLinearDatFormatDiv128((uint32) stFan.u16RPM << 7);
    PMBUS_stData.u16FanSpeed_Report.u16Val = u16Dummy;
    break;
  }

  case MG_E_UPD_INPUT:
  {
      /* Update VIN_Volt */
      u16Dummy = (__builtin_muluu((stIntcom1_PriA.u16q12VinAdc.u16Val),U16Q12_VIN_MAX) >> 5);
      PMBUS_stData.u16Vin_Report.u16Val = mg_u16TxLinearDatFormatDiv128(u16Dummy);
      
      /* Update IIN_Current */
      u16Dummy = (__builtin_muluu((stIntcom1_PriA.u16q12IinAdc.u16Val),U16Q12_IIN_MAX) >> 5);
      PMBUS_stData.u16Iin_Report.u16Val = mg_u16TxLinearDatFormatDiv128(u16Dummy);
      
      /* Update Vbulk_Volt */
      u16Dummy = (__builtin_muluu((stIntcom1_PriA.u16q12VbulkAdc.u16Val),U16Q12_VBULK_MAX) >> 5);
      PMBUS_stData.u16Vbulk_Report.u16Val = mg_u16TxLinearDatFormatDiv128(u16Dummy);
    break;
  }

  case MG_E_UPD_OUTPUT:
  {
    /* Update V1_Volt */
    u16Dummy = (__builtin_muluu((aAdcAverage[MG_U8_ADC_INDEX_V1_VOLT_EXT].u16q12Avg),U16Q12_V1_MAX_INT) >> 5);
    PMBUS_stData.u16Vout_V1_Report.u16Val = u16Dummy << 4;
    
    /* Update V1_Curr */
    u16Dummy = (__builtin_muluu((aAdcAverage[MG_U8_ADC_INDEX_V1_CURR].u16q12Avg),U16Q12_I1_MAX) >> 5);
    PMBUS_stData.u16Iout_V1_Report.u16Val = mg_u16TxLinearDatFormatDiv128(u16Dummy);

    /* Update V1_Pwr */
    u16Dummy = (__builtin_muluu(Pout_Avg,U16Q12_POUT_MAX) >> 9);            //Pout_Avg-Q16
    PMBUS_stData.u16Pout_V1_Report.u16Val = mg_u16TxLinearDatFormatDiv128(u16Dummy);
    
    break;
  }
  
  case MG_E_UPD_NUMBER:
  {
    break;
  }
  }

  PMBUS_mg_u8UpdSensor++;
  if (MG_E_UPD_NUMBER <= PMBUS_mg_u8UpdSensor)
  {
    PMBUS_mg_u8UpdSensor = MG_E_UPD_FAN_NTC;
  }
}/* PMBUS_vCopySensorData */

/*******************************************************************************
 * \brief         Copy sensor data to PMBus sensor registers / 10ms
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PMBUS_vCopyStatusData(void)
{
  PMBUS_ST_STATUS sPmbusStatusTemp;
  /* First power up, need to delay 3s then to update status */
  if (0U < PMBUS_mg_u16StatusUpdDly)
  {
    PMBUS_mg_u16StatusUpdDly--;
  }
  else
  {
    sPmbusStatusTemp.u16StatusWordP0.ALL = PMBUS_stStatus.u16StatusWordP0.ALL;
    sPmbusStatusTemp.u8StatusVoutP0.ALL = PMBUS_stStatus.u8StatusVoutP0.ALL;
    sPmbusStatusTemp.u8StatusIoutP0.ALL = PMBUS_stStatus.u8StatusIoutP0.ALL;
    sPmbusStatusTemp.u8StatusInputP0.ALL = PMBUS_stStatus.u8StatusInputP0.ALL;
    sPmbusStatusTemp.u8StatusTempP0.ALL = PMBUS_stStatus.u8StatusTempP0.ALL;
    sPmbusStatusTemp.u8StatusCmlP0.ALL = PMBUS_stStatus.u8StatusCmlP0.ALL;
    sPmbusStatusTemp.u8StatusOtherP0.ALL = PMBUS_stStatus.u8StatusOtherP0.ALL;
    sPmbusStatusTemp.u8StatusMfrP0.ALL = PMBUS_stStatus.u8StatusMfrP0.ALL;
    sPmbusStatusTemp.u8StatusFan12P0.ALL = PMBUS_stStatus.u8StatusFan12P0.ALL;

    /* Update Fault Status */

    /* if Work at Aux mode, then set it base status table */
    if (PMBUS_uSysStatus.Bits.AUX_MODE)
    {
      sPmbusStatusTemp.u16StatusWordP0.ALL |= 0x2848;
      sPmbusStatusTemp.u8StatusInputP0.ALL |= 0x10;
    }
    else if (INTCOM1_PRI_UART_FAIL)
    {
      /* UART fail Mode */
      sPmbusStatusTemp.u16StatusWordP0.ALL |= 0x0842;
      sPmbusStatusTemp.u8StatusCmlP0.ALL |= 0x02;
    }
    else
    {
      /* V1 Vout status 7Ah */
      if ((FALSE != FLG_B_V1_FW_OVP))
      {
        sPmbusStatusTemp.u8StatusVoutP0.Bits.VOUT_OV_FAULT = TRUE;
      }
      if (FALSE != FLG_B_V1_FW_OVW)
      {
        sPmbusStatusTemp.u8StatusVoutP0.Bits.VOUT_OV_WARN = TRUE;
      }
      if ((FALSE != FLG_B_V1_UVP))
      {
        sPmbusStatusTemp.u8StatusVoutP0.Bits.VOUT_UV_FAULT = TRUE;
      }

      /* V1 Iout status 7Bh */
      if (FALSE != FLG_B_V1_OCW)
      {
        sPmbusStatusTemp.u8StatusIoutP0.Bits.IOUT_OC_WARN = TRUE;
      }
      if (FALSE != FLG_B_V1_OCP) 
      {
        sPmbusStatusTemp.u8StatusIoutP0.Bits.IOUT_OC_FAULT = TRUE;
      }
      if (FALSE != FLG_B_V1_SCP)
      {
        sPmbusStatusTemp.u8StatusIoutP0.Bits.IOUT_OC_LV_FAULT = TRUE;
      }
    }

    /* CML 7Eh */
    if (FALSE != I2C_PEC_ERR_FLG)
    {
      sPmbusStatusTemp.u8StatusCmlP0.Bits.PEC_FAULT = TRUE;
    }
    if (FALSE != I2C_INVALID_CMD_FLG)
    {
      sPmbusStatusTemp.u8StatusCmlP0.Bits.INVALID_CMD = TRUE;
    }
    if (FALSE != I2C_INVALID_DATA_FLG)
    {
      sPmbusStatusTemp.u8StatusCmlP0.Bits.INVALID_DATA = TRUE;
    }



    /* V1 Status word 79h */
    /* Bit15:VOUT */
    if (FALSE != sPmbusStatusTemp.u8StatusVoutP0.ALL)
    {
      sPmbusStatusTemp.u16StatusWordP0.Bits.VOUT = TRUE;
    }
    else
    {
      sPmbusStatusTemp.u16StatusWordP0.Bits.VOUT = FALSE;
    }
    /* Bit14:IOUT/POUT */
    if (FALSE != sPmbusStatusTemp.u8StatusIoutP0.ALL)
    {
      sPmbusStatusTemp.u16StatusWordP0.Bits.IOUT_POUT = TRUE;
    }
    else
    {
      sPmbusStatusTemp.u16StatusWordP0.Bits.IOUT_POUT = FALSE;
    }

    /* Bit6:OFF */
    if (OFF == FLG_B_V1_STATE)
    {
      sPmbusStatusTemp.u16StatusWordP0.Bits.V_OFF = TRUE;
    }
    else
    {
      sPmbusStatusTemp.u16StatusWordP0.Bits.V_OFF = FALSE;
    }
    /* Bit5:VOUT_OV_FAULT */
    if (FALSE != sPmbusStatusTemp.u8StatusVoutP0.Bits.VOUT_OV_FAULT)
    {
      sPmbusStatusTemp.u16StatusWordP0.Bits.VOUT_OV_FAULT = TRUE;
    }
    else
    {
      sPmbusStatusTemp.u16StatusWordP0.Bits.VOUT_OV_FAULT = FALSE;
    }
    /* Bit4:IOUT_OC_FAULT */
    if (FALSE != sPmbusStatusTemp.u8StatusIoutP0.Bits.IOUT_OC_FAULT)
    {
      sPmbusStatusTemp.u16StatusWordP0.Bits.IOUT_OC_FAULT = TRUE;
    }
    else
    {
      sPmbusStatusTemp.u16StatusWordP0.Bits.IOUT_OC_FAULT = FALSE;
    }
    /* Bit3:VIN_UV_FAULT */
//    if (FALSE != sPmbusStatusTemp.u8StatusInputP0.Bits.VIN_UV_FAULT)
//    {
//      sPmbusStatusTemp.u16StatusWordP0.Bits.VIN_UV_FAULT = TRUE;
//    }
//    else
//    {
//      sPmbusStatusTemp.u16StatusWordP0.Bits.VIN_UV_FAULT = FALSE;
//    }

    /* Bit0:NONE_OF_THE_ABOVE */
    //Not use

    PMBUS_stStatus.u16StatusWordP0.ALL = sPmbusStatusTemp.u16StatusWordP0.ALL;
    PMBUS_stStatus.u8StatusVoutP0.ALL = sPmbusStatusTemp.u8StatusVoutP0.ALL;
    PMBUS_stStatus.u8StatusIoutP0.ALL = sPmbusStatusTemp.u8StatusIoutP0.ALL;
    PMBUS_stStatus.u8StatusInputP0.ALL = sPmbusStatusTemp.u8StatusInputP0.ALL;
    PMBUS_stStatus.u8StatusTempP0.ALL = sPmbusStatusTemp.u8StatusTempP0.ALL;
    PMBUS_stStatus.u8StatusCmlP0.ALL = sPmbusStatusTemp.u8StatusCmlP0.ALL;
    PMBUS_stStatus.u8StatusOtherP0.ALL = sPmbusStatusTemp.u8StatusOtherP0.ALL;
    PMBUS_stStatus.u8StatusMfrP0.ALL = sPmbusStatusTemp.u8StatusMfrP0.ALL;
    PMBUS_stStatus.u8StatusFan12P0.ALL = sPmbusStatusTemp.u8StatusFan12P0.ALL;
  }
  /* Judge SMBALERT base fault status */

}/* PMBUS_vCopyStatusData */


/*******************************************************************************
 * \brief         Copy debug data to PMBus debug registers, every 10ms.
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PMBUS_vCopyDebugData(void)
{

}/* PMBUS_vCopyDebugData */



/********************************************************************************
 * \brief         Prepare data for system reading
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PMBUS_vSendData(uint8 u8I2cCommand)
{
  WORD_VAL u16TempData;   
    
  if (MG_PAGE_00 == PMBUS_mg_u8Page)
  {
    switch (u8I2cCommand) {
    case PMB_00_PAGE:
    {
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_mg_u8Page;
      break;
    }
    case PMB_01_OPERATION:
    {
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_uOperation.ALL;
      break;
    }
    case PMB_02_ON_OFF_CONFIG:
    {
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_uOnOffConfig.ALL;
      break;
    }
    case PMB_19_CAPABILITY:
    {
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = SUPPORT_PEC_100K;	   
      break;
    }
    case PMB_1A_QUERY:
    {
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMB_mg_au8QueryP0[PMBUS_mg_u8QueryCmd];
      break;
    }
    case PMB_20_VOUT_MODE:
    {
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_VOUT_MODE_LINEAR_Minus_11; 
      break;
    }
    case PMB_3A_FAN_CONFIG_1_2:
    {
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_FAN_CONFIG_1_2;
      break;
    }
    case PMB_3B_FAN_COMMAND_1:
    {
        u16TempData.u16Val = stFan.u16q12SysCmdDuty;
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = u16TempData.Bytes.LB;
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = u16TempData.Bytes.HB;
      break;
    }
    case PMB_40_VOUT_OV_FAULT_LIMIT:
    {
      u16TempData.u16Val = VOUT_OV_FAULT_LIMIT; 
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = u16TempData.Bytes.LB;
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = u16TempData.Bytes.HB;
      break;
    }
    case PMB_46_IOUT_OC_FAULT_LIMIT:
    {
      u16TempData.u16Val = IOUT_OC_FAULT_LIMIT; 
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = u16TempData.Bytes.LB;
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = u16TempData.Bytes.HB;
      break;
    }
    case PMB_4A_IOUT_OC_WARN_LIMIT:
    {
      u16TempData.u16Val = IOUT_OC_WARN_LIMIT; 
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = u16TempData.Bytes.LB;
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = u16TempData.Bytes.HB;
      break;
    }
    case PMB_4F_OT_FAULT_LIMIT:
    {
      u16TempData.u16Val = OT_FAULT_LIMIT_PAGE0; 
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = u16TempData.Bytes.LB;
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = u16TempData.Bytes.HB;
      break;
    }
    case PMB_51_OT_WARN_LIMIT:
    {
      u16TempData.u16Val = OT_WARN_LIMIT_PAGE0; 
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = u16TempData.Bytes.LB;
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = u16TempData.Bytes.HB;
      break;
    }
    case PMB_78_STATUS_BYTE:
    {
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_stStatus.u16StatusWordP0.Bytes.LB;
      break;
    }
    case PMB_79_STATUS_WORD:
    {
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_stStatus.u16StatusWordP0.Bytes.LB;
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_stStatus.u16StatusWordP0.Bytes.HB;
      break;
    }
    case PMB_7A_STATUS_VOUT:
    {
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_stStatus.u8StatusVoutP0.ALL;
      break;
    }
    case PMB_7B_STATUS_IOUT:
    {
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_stStatus.u8StatusIoutP0.ALL;
      break;
    }
    case PMB_7C_STATUS_INPUT:
    {
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_stStatus.u8StatusInputP0.ALL;
      break;
    }
	 case PMB_7D_STATUS_TEMPERATURE:
    {
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_stStatus.u8StatusTempP0.ALL;
      break;
    }
	case PMB_7E_STATUS_CML:
	{
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_stStatus.u8StatusCmlP0.ALL;
      break;
    }
	case PMB_7F_STATUS_OTHER:
	{
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_stStatus.u8StatusOtherP0.ALL;
      break;
    }
    case PMB_80_STATUS_MFR_SPECIFIC:
	{
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_stStatus.u8StatusMfrP0.ALL;
      break;
    }
	case PMB_81_STATUS_FANS_1_2:
	{
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_stStatus.u8StatusFan12P0.ALL;
      break;
    }
	case PMB_88_READ_VIN_WORD:
	{
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_stData.u16Vin_Report.Bytes.LB;
	  I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_stData.u16Vin_Report.Bytes.HB;
      
      break;
    }
	case PMB_89_READ_IIN_WORD:
	{
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_stData.u16Iin_Report.Bytes.LB;
	  I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_stData.u16Iin_Report.Bytes.HB;
      break;
    }
	case PMB_8A_READ_VCAP_WORD:
	{
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_stData.u16Vbulk_Report.Bytes.LB;
	  I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_stData.u16Vbulk_Report.Bytes.HB;
      break;
    }
	case PMB_8B_READ_VOUT_WORD:
	{
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_stData.u16Vout_V1_Report.Bytes.LB;
	  I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_stData.u16Vout_V1_Report.Bytes.HB;
      break;
    }
	case PMB_8C_READ_IOUT_WORD:
	{
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_stData.u16Iout_V1_Report.Bytes.LB;
	  I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_stData.u16Iout_V1_Report.Bytes.HB;
      break;
    }
	case PMB_8D_READ_TEMP1_WORD:
	{
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_stData.u16Temperatue_1_Report.Bytes.LB;
	  I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_stData.u16Temperatue_1_Report.Bytes.HB;
      break;
    }
    case PMB_8E_READ_TEMP2_WORD:
	{
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_stData.u16Temperatue_2_Report.Bytes.LB;
	  I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_stData.u16Temperatue_2_Report.Bytes.HB;
      break;
    }
	case PMB_8F_READ_TEMP3_WORD:
	{
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_stData.u16Temperatue_3_Report.Bytes.LB;
	  I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_stData.u16Temperatue_3_Report.Bytes.HB;
      break;
    }
    case PMB_90_READ_FAN_SPEED_1:
    {
        I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_stData.u16FanSpeed_Report.Bytes.LB;
        I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_stData.u16FanSpeed_Report.Bytes.HB;
      break;
    }
    case PMB_96_READ_POUT_WORD:
	{
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_stData.u16Pout_V1_Report.Bytes.LB;
	  I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_stData.u16Pout_V1_Report.Bytes.HB;
      break;
    }
    case PMB_98_PMBUS_REVISION:
    {
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = PMBUS_PARA_REVISION;
      break;
    }
    case PMB_A0_MFR_VIN_MIN:
    {
      u16TempData.u16Val = 0; 
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = u16TempData.Bytes.LB;
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = u16TempData.Bytes.HB;
      break;
    }
    case PMB_A1_MFR_VIN_MAX:
    {
      u16TempData.u16Val = 0; 
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = u16TempData.Bytes.LB;
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = u16TempData.Bytes.HB;
      break;
    }
    case PMB_A2_MFR_IIN_MAX:
    {
      u16TempData.u16Val = 0; 
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = u16TempData.Bytes.LB;
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = u16TempData.Bytes.HB;
      break;
    }
    case PMB_A3_MFR_PIN_MAX:
    {
      u16TempData.u16Val = 0; 
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = u16TempData.Bytes.LB;
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = u16TempData.Bytes.HB;
      break;
    }
    case PMB_A4_MFR_VOUT_MIN:
    {
      u16TempData.u16Val = 0; 
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = u16TempData.Bytes.LB;
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = u16TempData.Bytes.HB;
      break;
    }
    case PMB_A5_MFR_VOUT_MAX:
    {
      u16TempData.u16Val = 0; 
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = u16TempData.Bytes.LB;
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = u16TempData.Bytes.HB;
      break;
    }
    case PMB_A6_MFR_IOUT_MAX:
    {
      u16TempData.u16Val = 0; 
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = u16TempData.Bytes.LB;
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = u16TempData.Bytes.HB;
      break;
    }
    case PMB_A7_MFR_POUT_MAX:
    {
      u16TempData.u16Val = 0; 
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = u16TempData.Bytes.LB;
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = u16TempData.Bytes.HB;
      break;
    }
    case PMB_A8_MFR_TAMBIENT_MAX:
    {
      u16TempData.u16Val = 0; 
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = u16TempData.Bytes.LB;
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = u16TempData.Bytes.HB;
      break;
    }
    case PMB_A9_MFR_TAMBIENT_MIN:
    {
      u16TempData.u16Val = 0; 
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = u16TempData.Bytes.LB;
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = u16TempData.Bytes.HB;
      break;
    }
    case PMB_D0_MFR_FW_REVISION:
    {
        u16TempData.u16Val = debugtempindex; 
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = u16TempData.Bytes.LB;
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = u16TempData.Bytes.HB;
        break;
    }
    default:
    {
        I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = 0x00;
        I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = 0x00;
        I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = 0x00;
        I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = 0x00;
      break;
    }
    }
  }
}/* I2cGetData */

/*******************************************************************************
 * Function:        I2cSetData
 *
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     GUI -> MCU
 *
 ******************************************************************************/
void vPMBus_HandleData(uint8 u8I2cCommand)
{
  static uint8 u8OperationOld = 0;
  uint8 u8Data0 = I2C_au8I2cRxBuf[1];
  uint8 u8Data1 = I2C_au8I2cRxBuf[2];
  uint8 u8Data2 = I2C_au8I2cRxBuf[3];
  uint8 u8Data3 = I2C_au8I2cRxBuf[4];
  WORD_VAL u16TempData;

    u8Data0 = I2C_au8I2cRxBuf[1];
    u8Data1 = I2C_au8I2cRxBuf[2];
    u8Data2 = I2C_au8I2cRxBuf[3];
    u8Data3 = I2C_au8I2cRxBuf[4];

  switch (u8I2cCommand) {
    /************************************************************************
     *   Standard PMBus commands 
     ************************************************************************/
  case PMB_00_PAGE:
  {
    if ((MG_PAGE_00 == u8Data0) || (MG_PAGE_01 == u8Data0))
    {
      PMBUS_mg_u8Page = u8Data0;
    }
    else
    {
      I2C_INVALID_DATA_FLG = TRUE;
    }
    break;
  }
  case PMB_01_OPERATION:
  {
    if (FALSE != PMBUS_uSysStatus.Bits.AUX_MODE)
    {
      /* Ignore write at Aux_Mode */
    }
    else
    {
      if (MG_PAGE_00 == PMBUS_mg_u8Page)
      {
        if ((0x00 == u8Data0) || (0x80 == u8Data0))
        {
          if(PMBUS_uOnOffConfig.Bits.RES_TO_OPER == 1U)
          {
              PMBUS_uOperation.ALL = u8Data0;
          }
        }
        else
        {
          I2C_INVALID_DATA_FLG = TRUE;
        }
        /* PMBus Operation recycle */
        if ((PMBUS_uOperation.ALL == 0x80) && (u8OperationOld == 0U)&& (PMBUS_uOnOffConfig.Bits.RES_TO_OPER == 1U))
        {

        }
        u8OperationOld = PMBUS_uOperation.ALL;
      }
      else
      {
        I2C_INVALID_DATA_FLG = TRUE;
      }
    }
    break;
  }
  case PMB_02_ON_OFF_CONFIG:
  {
    if (MG_PAGE_00 == PMBUS_mg_u8Page)
    {
      if ((0x11 == u8Data0) || (0x15 == u8Data0) || (0x19 == u8Data0) || (0x1D == u8Data0))
      {
        PMBUS_uOnOffConfig.ALL = u8Data0;
      }
      else
      {
        I2C_INVALID_DATA_FLG = TRUE;
      }
    }
    else
    {
      I2C_INVALID_DATA_FLG = TRUE;
    }
    break;
  }
  case PMB_03_CLEAR_FAULTS:
  {
      mg_vClearPageFault();
    break;
  }
  case PMB_1A_QUERY:
  {
      PMBUS_mg_u8QueryCmd = u8Data1;   
      break;
  }
  case PMB_20_VOUT_MODE:
  {

      break;
  }
  case PMB_3B_FAN_COMMAND_1:
  {
      if (MG_PAGE_00 == PMBUS_mg_u8Page)
      {
        u16TempData.Bytes.LB = u8Data0;
        u16TempData.Bytes.HB = u8Data1;
        if (u16TempData.u16Val <= 100)
        {
          stFan.u16q12SysCmdDuty = u16TempData.u16Val;
          
        }
        else
        {
          I2C_INVALID_DATA_FLG = TRUE;
        }
      }
      else
      {
        I2C_INVALID_DATA_FLG = TRUE;
      }
    break;
  }
  case PMB_46_IOUT_OC_FAULT_LIMIT:
  {

      break;
  }
  case PMB_4A_IOUT_OC_WARN_LIMIT:
  {

      break;
  }
  case PMB_D0_MFR_FW_REVISION:
  {  
        u16TempData.Bytes.LB = u8Data0;
        u16TempData.Bytes.HB = u8Data1;
        if(u16TempData.u16Val > 3)
        {
            u16TempData.u16Val = 3;
        }
      stFan.u16tempindex = u16TempData.u16Val;
    break;
  }
  default:
  {
    break;
  }
  }
}

/*******************************************************************************
 * \brief          Clear fault or warning status
 *                  ucPage: page0, 1, FF
 *                  ucMode: 1: clear All, and can restart ( OPERATION )
 *                          2: clear All except STA_MFR, and can restart ( PS_ON, PS_KILL )
 *                          3: clear All, and can't restart ( CLEAR_FAULT, CLEAR_BITS )
 *                          4: clear All except STA_MFR, and can't restart
 *
 * \param[in]     -ucPage, ucMode
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
static void mg_vClearPage00Fault(void)
{   
//  PMBUS_S_STATUS sPmbusStatusTemp;
    
  PMBUS_stStatus.u16StatusWordP0.ALL = 0;
  PMBUS_stStatus.u8StatusVoutP0.ALL = 0;
  PMBUS_stStatus.u8StatusIoutP0.ALL = 0;
  PMBUS_stStatus.u8StatusInputP0.ALL = 0;
  PMBUS_stStatus.u8StatusTempP0.ALL = 0;
  PMBUS_stStatus.u8StatusCmlP0.ALL = 0;
  PMBUS_stStatus.u8StatusOtherP0.ALL = 0;
  PMBUS_stStatus.u8StatusMfrP0.ALL = 0;
  PMBUS_stStatus.u8StatusFan12P0.ALL = 0;
  
}

/*******************************************************************************
 * \brief          Clear fault or warning status
 *                  ucPage: page0, 1, FF
 *                  ucMode: 1: clear All, and can restart ( OPERATION )
 *                          2: clear All except STA_MFR, and can restart ( PS_ON, PS_KILL )
 *                          3: clear All, and can't restart ( CLEAR_FAULT, CLEAR_BITS )
 *                          4: clear All except STA_MFR, and can't restart
 *
 * \param[in]     -ucPage, ucMode
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
static void mg_vClearPageAllFault()
{
  mg_vClearPage00Fault();
}

/*******************************************************************************
 * \brief          Clear fault or warning status
 *                  ucPage: page0, 1, FF
 *                  ucMode: 1: clear All, and can restart ( OPERATION )
 *                          2: clear All except STA_MFR, and can restart ( PS_ON, PS_KILL )
 *                          3: clear All, and can't restart ( CLEAR_FAULT, CLEAR_BITS )
 *                          4: clear All except STA_MFR, and can't restart
 *
 * \param[in]     -ucPage, ucMode
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
static void mg_vClearPageFault(void)
{
  /* Standard PMBus Status Initial */
  switch (PMBUS_mg_u8Page) {
  case MG_PAGE_00:
  {
    I2C_INVALID_CMD_FLG = FALSE;
    I2C_INVALID_DATA_FLG = FALSE;
    I2C_PEC_ERR_FLG = FALSE;
    stV1FaultFlag00.ALL = 0;
    mg_vClearPage00Fault();
    break;
  }
  case MG_PAGE_01:
  {

    break;
  }

  default:
  {
    break;
  }
  }

  PMBUS_vCopyStatusData(); // to update status immediately
} /* PMBUS_vClearFault */



/*
 * End of file
 */

