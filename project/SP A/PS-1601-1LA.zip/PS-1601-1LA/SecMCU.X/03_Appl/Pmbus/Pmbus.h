/* 
 * File:   PmbusCtrl.h
 * Author: Kiran
 *
 * Created on 8 October, 2020, 9:31 AM
 */

#ifndef PMBUSCTRL_H
#define	PMBUSCTRL_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "Define.h"
    /*******************************************************************************
     * Global constants and macros
     ******************************************************************************/
#define SW_WDT_IS_ENABLED       (TRUE)
    /* Standard PMBus commands */
#define PMB_00_PAGE                     0x00
#define PMB_01_OPERATION                0x01  //out of spec
#define PMB_02_ON_OFF_CONFIG            0x02  //out of spec
#define PMB_03_CLEAR_FAULTS             0x03  //out of spec
#define PMB_19_CAPABILITY               0x19
#define PMB_1A_QUERY                    0x1A
#define PMB_1B_SMBALERT_MASK            0x1B
#define PMB_20_VOUT_MODE                0x20  
#define PMB_3A_FAN_CONFIG_1_2           0x3A
#define PMB_3B_FAN_COMMAND_1            0x3B
#define PMB_40_VOUT_OV_FAULT_LIMIT      0x40
#define PMB_46_IOUT_OC_FAULT_LIMIT      0x46
#define PMB_4A_IOUT_OC_WARN_LIMIT       0x4A
#define PMB_4F_OT_FAULT_LIMIT           0x4F
#define PMB_51_OT_WARN_LIMIT            0x51
#define PMB_78_STATUS_BYTE              0x78
#define PMB_79_STATUS_WORD              0x79
#define PMB_7A_STATUS_VOUT              0x7A
#define PMB_7B_STATUS_IOUT              0x7B
#define PMB_7C_STATUS_INPUT             0x7C
#define PMB_7D_STATUS_TEMPERATURE       0x7D
#define PMB_7E_STATUS_CML               0x7E
#define PMB_7F_STATUS_OTHER             0x7F
#define PMB_80_STATUS_MFR_SPECIFIC      0x80
#define PMB_81_STATUS_FANS_1_2          0x81
#define PMB_88_READ_VIN_WORD            0x88
#define PMB_89_READ_IIN_WORD            0x89
#define PMB_8A_READ_VCAP_WORD           0x8A
#define PMB_8B_READ_VOUT_WORD           0x8B
#define PMB_8C_READ_IOUT_WORD           0x8C
#define PMB_8D_READ_TEMP1_WORD          0x8D
#define PMB_8E_READ_TEMP2_WORD          0x8E
#define PMB_8F_READ_TEMP3_WORD          0x8F
#define PMB_90_READ_FAN_SPEED_1         0x90
#define PMB_96_READ_POUT_WORD           0x96
#define PMB_98_PMBUS_REVISION           0x98
#define PMB_A0_MFR_VIN_MIN              0xA0
#define PMB_A1_MFR_VIN_MAX              0xA1
#define PMB_A2_MFR_IIN_MAX              0xA2
#define PMB_A3_MFR_PIN_MAX              0xA3
#define PMB_A4_MFR_VOUT_MIN             0xA4
#define PMB_A5_MFR_VOUT_MAX             0xA5
#define PMB_A6_MFR_IOUT_MAX             0xA6
#define PMB_A7_MFR_POUT_MAX             0xA7
#define PMB_A8_MFR_TAMBIENT_MAX         0xA8
#define PMB_A9_MFR_TAMBIENT_MIN         0xA9  
    
    /* Lite-ON MFR PMBus commands */
#define PMB_BD_MFR_TAMBIENT_MIN         0xBD    
#define PMB_D0_MFR_FW_REVISION          0xD0
#define PMB_D1_MFR_ENABLE               0xD1
#define PMB_EA_MFR_CAL_SAVE             0xEA
    
    
    /* PMBus command code */
#define PMB_01_OPERATION_ON             0x80
#define PMB_01_OPERATION_OFF            0x00

#if PS_1601_1LA_12V    
#define VOUT_OV_FAULT_LIMIT             (uint16)(14 << 11)        /* 13.5V in Linear format, exponent is -11 */
#define IOUT_OC_WARN_LIMIT              (uint16)(52)
#define IOUT_OC_FAULT_LIMIT             (uint16)(55)  
#elif  PS_1601_1LB_24V
#define VOUT_OV_FAULT_LIMIT             (uint16)(27 << 11)        /* 27V in Linear format, exponent is -11 */ 
#define IOUT_OC_WARN_LIMIT              (uint16)(26.25)
#define IOUT_OC_FAULT_LIMIT             (uint16)(27.5)
#endif   
    
#define OT_WARN_LIMIT_PAGE0             (uint16)(100)               //Hotspot
#define OT_WARN_LIMIT_PAGE1             (uint16)(55)                //Ambient
#define OT_FAULT_LIMIT_PAGE0            (uint16)(110)               //Hotspot
#define OT_FAULT_LIMIT_PAGE1            (uint16)(70)                //Ambient
    /*******************************************************************************
     * PMBus Parameters Setting
     ******************************************************************************/

#define PMBUS_REV_1p3		          0x33	   /* V1.3(2013-09-06)	*/
#define PMBUS_REV_1p2		          0x22     /* V1.2(2010-09-06) */
#define PMBUS_REV_1p1		          0x11	   /* V1.1(2007-02-05)	*/
#define PMBUS_REV_1p0		          0x00	   /* V1.0(2005-03-28) */
#define PMBUS_PARA_REVISION		      PMBUS_REV_1p2


#define PMBUS_VOUT_MODE_LINEAR_Minus_11    0x15	   /* Linear, N = -11 */
#define PMBUS_VOUT_MODE_LINEAR_17h         0x17	   /* Linear, N = -9 */
#define PMBUS_VOUT_MODE_LINEAR_19h         0x19	   /* Linear, N = -7 */
#define PMBUS_VOUT_MODE_VID                0x2D	   /* VID */
#define PMBUS_VOUT_MODE_DIRECT             0x40	   /* Linear */

#define PMBUS_FAN_CONFIG_1_2               0x90    /* Fan2 is installed, Using duty control fan speed, 2 pulse per revolution */
#define SUPPORT_PEC_100K                   0x80	   /* Support 100Kbps?PEC?no ALERT#  */
    
    /*******************************************************************************
     * Global data types (typedefs / structs / enums)
     ******************************************************************************/

    typedef union PMBUS_U_OPERATION_ {
        uint8 ALL;

        struct {
            uint8 Spare : 7; /* bit0 ~ bit 6 */
            uint8 OPERATION_ON : 1; /* bit7 */
        } Bits;
    } PMBUS_U_OPERATION;

    typedef union PMBUS_U_ON_OFF_CONFIG_ {
        uint8 ALL;

        struct {
            uint8 CTRL_ACT_CMD_OFF : 1; /* bit0 */
            uint8 POL_OF_CTRL_PIN : 1; /* bit1 */
            uint8 RES_TO_CTRL_PIN : 1; /* bit2 */
            uint8 RES_TO_OPER : 1; /* bit3 */
            uint8 RES_TO_OPER_AND_CTRL_PIN : 1; /* bit4 */
            uint8 RESERVED : 3; /* bit7 */
        } Bits;
    } PMBUS_U_ON_OFF_CONFIG;

    typedef union PMBUS_U_STATUS_WORD_ {
        uint16 ALL;

        struct {
            uint8 LB : 8;
            uint8 HB : 8;
        } Bytes;

        struct {
            uint8 NONE_OF_THE_ABOVE : 1; /* bit0 */
            uint8 CML : 1; /* bit1 */
            uint8 TEMPERATURE : 1; /* bit2 */
            uint8 VIN_UV_FAULT : 1; /* bit3 */
            uint8 IOUT_OC_FAULT : 1; /* bit4 */
            uint8 VOUT_OV_FAULT : 1; /* bit5 */
            uint8 V_OFF : 1; /* bit6 */
            uint8 BUSY : 1; /* bit7 */
            uint8 UNKNOWN : 1; /* bit8 */
            uint8 OTHER : 1; /* bit9 */
            uint8 FANS : 1; /* bitA */
            uint8 POWER_GOOD : 1; /* bitB */
            uint8 MFR_SPEC : 1; /* bitC */
            uint8 INPUT : 1; /* bitD */
            uint8 IOUT_POUT : 1; /* bitE */
            uint8 VOUT : 1; /* bitF */
        } Bits;
    } PMBUS_U_STATUS_WORD;

    typedef union PMBUS_U_STATUS_VOUT_ {
        uint8 ALL;

        struct {
            uint8 VOUT_TRACK_ERROR : 1; /* bit0 */
            uint8 TOFF_MAX_WARN : 1; /* bit1 */
            uint8 TON_MAX_FAULT : 1; /* bit2 */
            uint8 VOUT_MAX_WARN : 1; /* bit3 */
            uint8 VOUT_UV_FAULT : 1; /* bit4 */
            uint8 VOUT_UV_WARN : 1; /* bit5 */
            uint8 VOUT_OV_WARN : 1; /* bit6 */
            uint8 VOUT_OV_FAULT : 1; /* bit7 */
        } Bits;
    } PMBUS_U_STATUS_VOUT;

    typedef union PMBUS_U_STATUS_IOUT_ {
        uint8 ALL;

        struct {
            uint8 POUT_OP_WARN : 1; /* bit0 */
            uint8 POUT_OP_FAULT : 1; /* bit1 */
            uint8 POWER_LIMIT_MODE : 1; /* bit2 */
            uint8 CURR_SHARE_FAULT : 1; /* bit3 */
            uint8 IOUT_UC_FAULT : 1; /* bit4 */
            uint8 IOUT_OC_WARN : 1; /* bit5 */
            uint8 IOUT_OC_LV_FAULT : 1; /* bit6 */
            uint8 IOUT_OC_FAULT : 1; /* bit7 */
        } Bits;
    } PMBUS_U_STATUS_IOUT;

    typedef union PMBUS_U_STATUS_INPUT_ {
        uint8 ALL;

        struct {
            uint8 PIN_OP_WARN : 1; /* bit0 */
            uint8 IIN_OC_WARN : 1; /* bit1 */
            uint8 IIN_OC_FAULT : 1; /* bit2 */
            uint8 OFF_FOR_VIN_LOW : 1; /* bit3 */
            uint8 VIN_UV_FAULT : 1; /* bit4 */
            uint8 VIN_UV_WARN : 1; /* bit5 */
            uint8 VIN_OV_WARN : 1; /* bit6 */
            uint8 VIN_OV_FAULT : 1; /* bit7 */
        } Bits;
    } PMBUS_U_STATUS_INPUT;

    typedef union PMBUS_U_STATUS_TEMP_ {
        uint8 ALL;

        struct {
            uint8 RESERVED_B0 : 1; /* bit0 */
            uint8 RESERVED_B1 : 1; /* bit1 */
            uint8 RESERVED_B2 : 1; /* bit2 */
            uint8 RESERVED_B3 : 1; /* bit3 */
            uint8 UT_FAULT : 1; /* bit4 */
            uint8 UT_WARN : 1; /* bit5 */
            uint8 OT_WARN : 1; /* bit6 */
            uint8 OT_FAULT : 1; /* bit7 */
        } Bits;
    } PMBUS_U_STATUS_TEMP;

    typedef union PMBUS_U_STATUS_CML_ {
        uint8 ALL;

        struct {
            uint8 MEM_LOGIC_FAULT : 1; /* bit0 */
            uint8 COMMS_FAULT : 1; /* bit1 */
            uint8 RESERVED_B2 : 1; /* bit2 */
            uint8 CPU_FAULT : 1; /* bit3 */
            uint8 MEM_FAULT : 1; /* bit4 */
            uint8 PEC_FAULT : 1; /* bit5 */
            uint8 INVALID_DATA : 1; /* bit6 */
            uint8 INVALID_CMD : 1; /* bit7 */
        } Bits;
    } PMBUS_U_STATUS_CML;

    typedef union PMBUS_U_STATUS_OTHER_ {
        uint8 ALL;

        struct {
            uint8 INVALID_OR_TEST : 1; /* bit0 */
            uint8 OUT_OR_FAULT : 1; /* bit1 */
            uint8 INB_OR_FAULT : 1; /* bit2 */
            uint8 INA_OR_FAULT : 1; /* bit3 */
            uint8 INB_BRK_FAULT : 1; /* bit4 */
            uint8 INA_BRK_FAULT : 1; /* bit5 */
            uint8 RESERVED_B6 : 1; /* bit6 */
            uint8 RESERVED_B7 : 1; /* bit7 */
        } Bits;
    } PMBUS_U_STATUS_OTHER;

    typedef union PMBUS_U_STATUS_MFR_ {
        uint8 ALL;

        struct {
            uint8 V1_OFF_DUE_VSB : 1; /* bit0 */
            uint8 Spare : 7; /* bit1 ~ bit 7 */
        } Bits;
    } PMBUS_U_STATUS_MFR;

    typedef union PMBUS_U_STATUS_FAN_12_ {
        uint8 ALL;

        struct {
            uint8 AIR_FLOW_WARNING : 1; /* bit0 */
            uint8 AIR_FLOW_FAULT : 1; /* bit1 */
            uint8 FAN_2_SPD_OVERRIDE : 1; /* bit2 */
            uint8 FAN_1_SPD_OVERRIDE : 1; /* bit3 */
            uint8 FAN_2_WARNING : 1; /* bit4 */
            uint8 FAN_1_WARNING : 1; /* bit5 */
            uint8 FAN_2_FAULT : 1; /* bit6 */
            uint8 FAN_1_FAULT : 1; /* bit7 */
        } Bits;
    } PMBUS_U_STATUS_FAN_12;

    typedef union PMBUS_U_SYS_STATUS_ {
        uint16 ALL;

        struct {
            uint8 MFR_INFO_UPDATE : 1; /* bit0 */
            uint8 QUERY_REQUEST : 1; /* bit1 */
            uint8 PAGE_AND_READ : 1; /* bit2 */
            uint8 INVALID_CMD : 1; /* bit3 */
            uint8 INVALID_DATA : 1; /* bit4 */
            uint8 UNLOCK_DEBUG : 1; /* bit5 */
            uint8 AUX_MODE : 1; /* bit6 */
            uint8 FAN_1_OVERRIDE : 1; /* bit7 */
            uint8 Reserved0 : 1; /* bit8 */
            uint8 Reserved1 : 1; /* bit9 */
            uint8 Reserved2 : 1; /* bitA */
            uint8 Reserved3 : 1; /* bitB */
            uint8 Reserved4 : 1; /* bitC */
            uint8 Reserved5 : 1; /* bitD */
            uint8 Reserved6 : 1; /* bitE */
            uint8 Reserved7 : 1; /* bitF */
        } Bits;
    } PMBUS_U_SYS_STATUS;

    
    typedef struct PMBUS_ST_DATA_ {
        WORD_VAL u16Vin_Report;
        WORD_VAL u16Iin_Report;
        WORD_VAL u16Pin_Report;
        WORD_VAL u16Vbulk_Report;
        WORD_VAL u16Vout_V1_Report;
        WORD_VAL u16Iout_V1_Report;
        WORD_VAL u16Pout_V1_Report;
        WORD_VAL u16Ishare_V1_Report;
        WORD_VAL u16Temperatue_1_Report;
        WORD_VAL u16Temperatue_2_Report;
        WORD_VAL u16Temperatue_3_Report;
        WORD_VAL u16FanSpeed_Report;
        WORD_VAL u16FanCmd_Report;
        WORD_VAL u16Num_Of_AC_Cycles;
        WORD_VAL u16Num_Of_PSON_Cycles;
        DWORD_VAL u32DataCopy;
        DWORD_VAL u32Real_Time_BlackBox;
        uint8 u8System_BlackBox[40];
    } PMBUS_ST_DATA;

    typedef struct PMBUS_ST_STATUS_ {
        PMBUS_U_STATUS_WORD u16StatusWordP0;
        PMBUS_U_STATUS_VOUT u8StatusVoutP0;
        PMBUS_U_STATUS_IOUT u8StatusIoutP0;
        PMBUS_U_STATUS_INPUT u8StatusInputP0;
        PMBUS_U_STATUS_TEMP u8StatusTempP0;
        PMBUS_U_STATUS_CML u8StatusCmlP0;
        PMBUS_U_STATUS_OTHER u8StatusOtherP0;
        PMBUS_U_STATUS_MFR u8StatusMfrP0;
        PMBUS_U_STATUS_FAN_12 u8StatusFan12P0;
    } PMBUS_ST_STATUS;


    typedef union PMBUS_U_TRANS_TYPE_ {
        uint8 ALL;

        struct {
            uint8 BLOCK_READ_EN : 1; /* bit0 */
            uint8 Reserved0 : 1; /* bit1 */
            uint8 Reserved1 : 1; /* bit2 */
            uint8 Reserved2 : 1; /* bit3 */
            uint8 BLOCK_WRITE_EN : 1; /* bit4 */
            uint8 Reserved3 : 1; /* bit5 */
            uint8 Reserved4 : 1; /* bit6 */
            uint8 WR_BLK_RD_BLK_PRT : 1; /* bit7 */
        } Bits;
    } PMBUS_U_TRANS_TYPE;

   

    /*******************************************************************************
     * Global data
     ******************************************************************************/
    extern const uint8 PMBUS_u8TransactionType[256];
    extern const uint8 PMB_mg_au8I2cRxNumber[256];
    extern PMBUS_U_OPERATION PMBUS_uOperation;
    extern PMBUS_U_ON_OFF_CONFIG PMBUS_uOnOffConfig;
    extern PMBUS_U_SYS_STATUS PMBUS_uSysStatus;
    extern PMBUS_ST_DATA PMBUS_stData;
    extern PMBUS_ST_STATUS PMBUS_stStatus;
    extern WORD_VAL PMBUS_u16Vin_LinearTemp;
    extern WORD_VAL PMBUS_u16Iin_LinearTemp;
    extern WORD_VAL PMBUS_u16Vout_LinearTemp;
    extern WORD_VAL PMBUS_u16Iout_LinearTemp;
    extern PMBUS_U_TRANS_TYPE PMBUS_u8TransType;
    /*******************************************************************************
     * Global function prototypes
     ******************************************************************************/

    /*******************************************************************************
     * \brief         Initialize PMBus data
     *
     * \param[in]     -
     * \param[in,out] -
     * \param[out]    -
     *
     * \return        -
     *
     *******************************************************************************/
    extern void PMBUS_vPmbusDataInit(void);

    /*******************************************************************************
     * \brief         Copy sensor data to PMBus sensor registers
     *
     * \param[in]     -
     * \param[in,out] -
     * \param[out]    -
     *
     * \return        -
     *
     *******************************************************************************/
    extern void PMBUS_vCopySensorData(void);

    /*******************************************************************************
     * \brief         Copy sensor data to PMBus sensor registers
     *
     * \param[in]     -
     * \param[in,out] -
     * \param[out]    -
     *
     * \return        -
     *
     *******************************************************************************/
    extern void PMBUS_vCopyStatusData(void);

    /*******************************************************************************
     * \brief         Check the specific bit of the input data
     *
     * \param[in]     u16Data, u8BitNum
     * \param[in,out] -
     * \param[out]    - 
     *
     * \return        - TRUE or FALSE
     *
     *******************************************************************************/
    extern boolean PMBUS_vCheckBit(uint16 u16Data, uint8 u8BitNum);

    /*******************************************************************************
     * \brief         Copy debug data to PMBus debug registers
     *
     * \param[in]     -
     * \param[in,out] -
     * \param[out]    -
     *
     * \return        -
     *
     *******************************************************************************/
    extern void PMBUS_vCopyDebugData(void);

    /*******************************************************************************
     * \brief          Clear fault or warning status
     *                  ucPage: page0, 1, FF
     *                  ucMode: 1: clear All, and can restart ( OPERATION )
     *                          2: clear All except STA_MFR, and can restart ( PS_ON, PS_KILL )
     *                          3: clear All, and can't restart ( CLEAR_FAULT, CLEAR_BITS )
     *                          4: clear All except STA_MFR, and can't restart
     *
     * \param[in]     -ucPage, ucMode
     * \param[in,out] -
     * \param[out]    -
     *
     * \return        -
     *
     *******************************************************************************/
    extern void PMBUS_vClearAllPageFault(void);

    /*******************************************************************************
     * Function:        PMBUS_SendData
     *
     * Parameters:      -
     * Returned value:  -
     *
     * Description:     PSU -> SYS
     *
     ******************************************************************************/
    extern void PMBUS_vSendData(uint8 u8I2cCommand);
    extern void vPMBus_HandleData(uint8 u8I2cCommand);


#ifdef	__cplusplus
}
#endif

#endif	/* PMBUSCTRL_H */

