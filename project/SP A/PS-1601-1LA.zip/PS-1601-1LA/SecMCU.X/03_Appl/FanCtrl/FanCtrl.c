/** *****************************************************************************
 * \file    FanCtrl.c
 * \brief   Fan control
 *
 * \section AUTHOR
 *    1. Kiran
 *
 * \section SVN
 *  $Date$
 *  $Author$
 *  $Revision$
 *
 * \section LICENSE
 * Copyright (c) 
 * All rights reserved.
 *******************************************************************************/
/*******************************************************************************
 * Included header
 ******************************************************************************/
#include <p33EP64GS504.h>
#include "Global.h"
#include "xc.h"

#include "Define.h"
#include "McuGPIO.h"
#include "McuPWM.h"
#include "Protection.h"
#include "FanCtrl.h"
#include "Pmbus.h"
/*******************************************************************************
 * Local constants and macros (private to module)
 ******************************************************************************/
/* fan regulate step X/4096, change the can change the Fan speed regulate loop */
#define MG_U8_FAN_REGULATE_FAST_STEP                  ((uint8)10)
#define MG_U8_FAN_REGULATE_SLOW_STEP                  ((uint8)1)
/* When fan speed error bigger then below vaule, use fase control */
#define MG_S16_FAN_FAST_CTRL_VALUE                    ((sint16)2000)
/* Set the MAX fan Speed */
#define MG_U16_FAN_SPEED_MAX                          ((uint16)10000)
/* Set the MIN fan Speed */
#define MG_U16_FAN_SPEED_MIN                          ((uint16)500)
/* Set the MAX fan Duty */
#define MG_U16_FAN_DUTY_MAX                           ((uint16)U32Q12(1.0F))
/* Set the MIN fan Duty */
#define MG_U16_FAN_DUTY_MIN                           ((uint16)U32Q12((float32)MG_U16_FAN_SPEED_MIN / (float32)MG_U16_FAN_SPEED_MAX))
/* Set fan Fail speed */
#define MG_U16_FAN_FAIL_SPEED                         ((uint16)500)
/* Set fan Fail delay time */
#define MG_U8_FAN_FAIL_SET_DLY                        ((uint8)20)  /* delay = X * 500ms */
/* Set fan OK delay time */
#define MG_U8_FAN_OK_SET_DLY                          ((uint8)20)  /* delay = X * 500ms */
/*******************************************************************************
 * Global functions (public to other modules)
 ******************************************************************************/
const uint16 u16TemperatureRangeTable[FAN_U8_TEMP_STEPS] = {27, 41, 50, 80};
const uint16 u16LoadingTable[FAN_U8_LOAD_STEPS] 	     = {0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100};
uint8 fanspeedpowerup = 0;
uint16 debugfanspeed = 0;
uint16 debugloadpercent = 0;
uint16 debugtemp = 0;
uint16 debugtempindex = 0;
uint16 debugduty = 0;
/**
====================================================================================================
								 High line Fan control  table									  
====================================================================================================
*/
const uint16 u16MinFanSpeedHighLineTable[FAN_U8_TEMP_STEPS][FAN_U8_LOAD_STEPS] =
{
    //0%	 10%	 20%	 30%	 40%	 50%	 60%	 70%	 80%	 90%	 100%      loading
    {2000,   2000,   2000,	 2000,	 2000,	 2000,	 3000,	 3000,	 3000,	 4000,	 4000},   // <27'C
    {2000,   2000,   2000,	 2000,	 3000,	 3000,	 3000,	 4000,	 4000,	 5000,	 6000},   //27-41'C
    {2000,   2000,   3000,	 3000,	 3000,	 4000,	 5000,	 6000,	 6500,	 7000,	 8500},   //41-50'C
    {4000,   4000,   5000,	 6000,	 7000,	 8000,	 9000,	 10000,	 10000,	 10000,	 10000},   //>50'C
};

//const uint16 u16MinFanSpeedHighLineTable[FAN_U8_TEMP_STEPS][FAN_U8_LOAD_STEPS] =
//{
//    //0%	 10%	 20%	 30%	 40%	 50%	 60%	 70%	 80%	 90%	 100%      loading
//    {1000,   2000,   3000,	 4000,	 5000,	 6000,	 7000,	 8000,	 9000,	 10000,	 11000},   // <27'C
//    {2000,   3000,   4000,	 5000,	 6000,	 7000,	 8000,	 9000,	 10000,	 11000,	 12000},   //27-41'C
//    {3000,   3500,   4500,	 5500,	 6500,	 7500,	 8500,	 9500,	 10500,	 11500,	 12500},   //41-50'C
//    {4300,   5300,   6300,	 7300,	 8300,	 9300,	 10300,	 11300,	 12300,	 13300,	 14300},   //>50'C
//};


/**
====================================================================================================
								 Low line Fan control  table									  
====================================================================================================
*/
const uint16 u16MinFanSpeedLowLineTable[FAN_U8_TEMP_STEPS][FAN_U8_LOAD_STEPS] =
{
    //0%	 10%	 20%	 30%	 40%	 50%	 60%	 70%	 80%	 90%	 100%      loading
    {2000,   2000,   2000,	 2000,	 2000,	 3000,	 3000,	 3000,	 4000,	 5000,	 6000},   // <27'C
    {2000,   2000,   2000,	 3000,	 3000,	 3000,	 4000,	 5000,	 6000,	 7000,	 8000},   //27-41'C
    {2000,   2000,   3000,	 3000,	 4000,	 5000,	 6000,	 7000,	 8500,	 10000,	 10000},   //41-50'C
    {4000,   4000,   5500,	 7000,	 8500,	 10000,	 10000,	 10000,	 10000,	 10000,	 10000},   //>50'C
};
/** *****************************************************************************
 * \brief         Fan Data init
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 ***************************************************************************** */
void FANCTRL_DataInit(void)
{
  uint8 u8Index;
  for (u8Index = 0; u8Index < 1; u8Index++)
  {
    stFan.u16Cnt = 0U;
    stFan.u16q12Duty = (MG_U16_FAN_DUTY_MAX >> 3); /* initial speed */
    stFan.u16q12SysCmdDuty = 0U;
    stFan.u16RPM = (MG_U16_FAN_SPEED_MAX >> 3);
    stFan.u16SysCmdRPM = 0U;
    stFan.Bits.f0Warn = 0U;
    stFan.Bits.f1Fail = 0U;
    stFan.Bits.f2Ovrd = 0U;
    stFan.Bits.f3IoPin = 0U;
    stFan.u16tempindex = 0U;
  }
}

/**
* @fn           int16 FanLookUpApps(const int16 *X, const int16 *Y, int16 dim, int32 x)
* @brief        Description: Location in Y domain
*/
uint16 FanLookUpApps(const uint16 *X, const uint16 *Y, uint16 dim, uint32 x)
{
    boolean i;
    uint32 x0, tepm, xtemp, ytemp;
    uint16 x1, y0, y1, y;
    

    for (i=0; i<dim; i++)
    {
        if (x <= X[i])
            break;
    }
    if (i == dim) i--;
    if (i == 0) i++;

    x1 = X[i];
    y1 = Y[i];
    x0 = X[i-1];
    y0 = Y[i-1];

	xtemp = x - x0;
    tepm = (uint16) __builtin_divsd(((uint32) xtemp * (y1-y0)) , (x1-x0));
	
    ytemp = tepm + y0;

    if(ytemp>32767)  // signed upper boundary
    y=32767;
    else if(ytemp<0) // signed bottom boundary
    y=0;
    else
    y = ytemp;

    return y;
}


/** *****************************************************************************
 * \brief         Fan Speed calculate, every 10ms
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 ***************************************************************************** */
void FANCTRL_SpeedCtrl(void)
{
    uint16 u16FanSpeedRef;
    sint16 s16FanSpeedErr;
    static uint16 u16SysDutyTemp = 0;
    static uint16  u16TemperatureRange;
    static uint32  u16Fanloadbase;
//	static sint16  u16Ambient;

    /*Fan speed based on temperature*/
//    if(u16Ambient <= 27)         //27 deg - 3020
//    {
//        u16TemperatureRange = 0;    // temp index
//    }else if((u16Ambient > 27)&&(u16Ambient <= 41))       //41 deg - 2576
//    {
//        u16TemperatureRange = 1;    // temp index
//    }else if((u16Ambient > 41)&&(u16Ambient <= 50))         //50deg - 2277
//    {
//        u16TemperatureRange = 2;    // temp index
//    }else
//    {
//        u16TemperatureRange = 3;    // temp index
//    }
    
    if(stFan.u16tempindex == 0)         //27 deg - 3020
    {
        u16TemperatureRange = 0;    // temp index
    }else if(stFan.u16tempindex == 1)       //41 deg - 2576
    {
        u16TemperatureRange = 1;    // temp index
    }else if(stFan.u16tempindex == 2)         //50deg - 2277
    {
        u16TemperatureRange = 2;    // temp index
    }else if(stFan.u16tempindex == 3)
    {
        u16TemperatureRange = 3;    // temp index
    }

    debugtempindex = u16TemperatureRange;
    
    /*Fan speed based on load*/
    u16Fanloadbase = (__builtin_muluu((aAdcAverage[MG_U8_ADC_INDEX_V1_CURR].u16q12Avg),100));
    u16Fanloadbase = (uint16) __builtin_divsd(u16Fanloadbase ,U16Q12_I1_FL_ADC); 
    
    if(u16Fanloadbase > 100)
        u16Fanloadbase = 100;
    
    debugloadpercent = u16Fanloadbase;
//    if(StPriStatus.bHighLine == 1)
//    {
        u16FanSpeedRef = FanLookUpApps(u16LoadingTable, u16MinFanSpeedHighLineTable[u16TemperatureRange], DIM(u16LoadingTable), u16Fanloadbase);
        debugfanspeed = u16FanSpeedRef;
        Nop();
//    }
//    else
//    {
//        u16FanSpeedRef = FanLookUpApps(u16LoadingTable, u16MinFanSpeedLowLineTable[u16TemperatureRange], DIM(u16LoadingTable), u16Fanloadbase);
//    }
    
    
        
    /* if the System fan speed command > PSU control speed, then use the system fan command, Priority 2(high) */
    if (u16FanSpeedRef < stFan.u16SysCmdRPM)
    {
      if(MG_U16_FAN_SPEED_MIN > stFan.u16SysCmdRPM)
      {
          stFan.u16SysCmdRPM = MG_U16_FAN_SPEED_MIN;
      }
      u16FanSpeedRef = stFan.u16SysCmdRPM;
      stFan.Bits.f2Ovrd = TRUE;
    }
    else
    {
      stFan.Bits.f2Ovrd = FALSE;
      u16FanSpeedRef = u16FanSpeedRef;
    }
    stFan.s16debug = u16FanSpeedRef;
    /* Step 3: Control the Fan by PWM duty */
    s16FanSpeedErr = (sint16) u16FanSpeedRef - (sint16) stFan.u16RPM;
    
    if (MG_S16_FAN_FAST_CTRL_VALUE < s16FanSpeedErr)                            /* Fan error > 2000 */
    {
      stFan.u16q12Duty += MG_U8_FAN_REGULATE_FAST_STEP;
    }
    else if (0 < s16FanSpeedErr)                                                /* 0 < Fan error < 2000 */
    {
      stFan.u16q12Duty += MG_U8_FAN_REGULATE_SLOW_STEP;
    }
    else if ((-MG_S16_FAN_FAST_CTRL_VALUE) < s16FanSpeedErr)                    /* -2000 < Fan error < 0 */
    {
      stFan.u16q12Duty -= MG_U8_FAN_REGULATE_SLOW_STEP;
    }
    else                                                                        /* Fan error < -2000 */
    {
      stFan.u16q12Duty -= MG_U8_FAN_REGULATE_FAST_STEP;
    }

    /****************** Limit the Fan duty *************************************/
    if(stFan.u16q12Duty < MG_U16_FAN_DUTY_MIN)
    {
        stFan.u16q12Duty = MG_U16_FAN_DUTY_MIN;
    }   
    else if(stFan.u16q12Duty > MG_U16_FAN_DUTY_MAX)
    {
        stFan.u16q12Duty = MG_U16_FAN_DUTY_MAX;
    }
    
    
    /********** if the System fan speed command > 0, Priority 3(Highset) *******/
    if (0 < stFan.u16q12SysCmdDuty)
    {
      u16SysDutyTemp = ((uint32) stFan.u16q12SysCmdDuty * 5243) >> 7; //((uint32) X * 4096 / 100) = ((uint32) X * 5243 >> 7)
      if (stFan.u16q12Duty < u16SysDutyTemp)
      {
        stFan.Bits.f2Ovrd = TRUE;
        stFan.u16q12Duty = u16SysDutyTemp;
      }
      else
      {
        stFan.Bits.f2Ovrd = FALSE;
      }
    }
    else
    {
      stFan.Bits.f2Ovrd = FALSE;
    }

    debugduty = stFan.u16q12Duty;
    FANCTRL_Dutyupdate(stFan.u16q12Duty);     //100% is 4096
}
/** *****************************************************************************
 * \brief         Fan Speed calculate, every 10ms
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 ***************************************************************************** */
void FANCTRL_SpeedCalc(void)
{
  uint8 u8Index;
  static uint8 au8FanFailCnt;
  static uint8 au8FanWarnCnt;
  static uint8 au8FanOKCnt;
  static uint8 u8Cnt;

  u8Cnt++;
  if (50 == u8Cnt)
  {
    u8Cnt = 0;
    for (u8Index = 0U; u8Index < 1; u8Index++)
    {
      /* Calculate Real Fan Speed, every 500ms */
      stFan.u16RPM = stFan.u16Cnt * 30;
      /* Reset Fan Speed Count */
      stFan.u16Cnt = 0U;

      /* if Input OK, then judge fan status, or it will not */
      if ((TRUE == FLG_B_INPUT_OK) && (TRUE == FLG_B_BULK_OK)) 
      {
        /* Judge the Fan warning */

        /* Judge the Fan fail */
        if (MG_U16_FAN_FAIL_SPEED > stFan.u16RPM)
        {
          if (MG_U8_FAN_FAIL_SET_DLY < au8FanFailCnt)
          {
            stFan.Bits.f1Fail = TRUE;
            au8FanOKCnt = 0U;
          }
          else
          {
            au8FanFailCnt++;
          }
        }else
        {
            if(MG_U8_FAN_OK_SET_DLY < au8FanOKCnt)
            {
                stFan.Bits.f1Fail = FALSE;
                au8FanFailCnt = 0U;
            }else
            {
               au8FanOKCnt++; 
            }
        }
        /* Judge the Fan OK */

      }
      else
      {
        stFan.Bits.f0Warn = FALSE;
        stFan.Bits.f1Fail = FALSE;
        au8FanFailCnt = 0U;
        au8FanWarnCnt = 0U;
      }
    }
    
    //FLG_B_FAN_FAULT set and clear
   if(FALSE != FLG_B_PSON_ENABLE)
   {
        if (stFan.Bits.f1Fail)
        {
          FLG_B_FAN_FAULT = TRUE;
        }
        else
        {
          FLG_B_FAN_FAULT = FALSE;
        } 
   }else
   {
       FLG_B_FAN_FAULT = FALSE;
   }

  }
}
/** *****************************************************************************
 * \brief         Fan Speed counter, every 100us or every 200us
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 ***************************************************************************** */
void FANCTRL_SpeedCnt(void)
{

  static uint16 au8FanSpeedStatus;
  static uint16 au8TachoTimerAct;
  uint8 u8Index;


  stFan.Bits.f3IoPin = DIO_FAN_SPEED_HIP;

  for (u8Index = 0; u8Index < 1; u8Index++)
  {
    if (stFan.Bits.f3IoPin != au8FanSpeedStatus)
    {
      /* > 2 * 0.2 = 0.6 ms to suppress noise */
      if (au8TachoTimerAct >= 2U)
      {
        if (stFan.u16Cnt < 0xffff)
        {
          stFan.u16Cnt++;
        }
        au8TachoTimerAct = 0;
        au8FanSpeedStatus = stFan.Bits.f3IoPin;
      }
      else
      {
        au8TachoTimerAct++;
      }
    }
    else
    {
      if (au8TachoTimerAct > 0)
      {
        au8TachoTimerAct--;
      }
    }
  }
}
/*******************************************************************************
 * \brief         Fan Speed counter, every 100us or every 200us
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 ******************************************************************************/
void FANCTRL_Dutyupdate(uint16 u16q12Duty)
{
  GLOBAL_U_U16BIT u16Dummy;
  u16Dummy.ALL = ((uint32) (u16q12Duty) * FAN_PWM_PERIOD) >> 12;
  FAN_CTRL_PWM_REG = u16Dummy.ALL;
}
