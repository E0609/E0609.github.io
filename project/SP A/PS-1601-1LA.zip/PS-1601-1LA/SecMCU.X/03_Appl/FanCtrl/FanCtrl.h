/* 
 * File:   FanCtrl.h
 * Author: kiranmeravanagi
 *
 * Created on 23 July, 2021, 2:10 PM
 */

#ifndef FANCTRL_H
#define	FANCTRL_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "global.h"
    
#define FAN_U8_TEMP_STEPS				4u			/* <27, 27-41 , 41-50 , >50 degree C*/
#define FAN_U8_LOAD_STEPS				11u			/* 0%, 10%, 20%, 30%, 40%, 50%, 60%, 70%, 80%, 90%, 100% loading*/
    
    /*******************************************************************************
     * Global constants and macros (public to other modules)
     ******************************************************************************/

    typedef union FANCTRL_U_STATUS_ {
        uint8 ALL;

        struct {
            uint8 AIR_FLOW_WARNING : 1; /* bit0 */
            uint8 AIR_FLOW_FAULT : 1;   /* bit1 */
            uint8 FAN_SPEED_OVRD : 1;   /* bit2 */
            uint8 FAN_WARNING : 1;      /* bit3 */
            uint8 FAN_FAULT : 1;        /* bit4 */
            uint8 FAN_Reserved0 : 1;    /* bit5 */
            uint8 FAN_Reserved1 : 1;    /* bit6 */
            uint8 FAN_Reserved2 : 1;    /* bit7 */
        } Bits;
    } FANCTRL_U_STATUS;

    /*******************************************************************************
     * Global data (public to other modules)
     ******************************************************************************/

    extern FANCTRL_U_STATUS FANCTRL_uFanStatus;

    /*******************************************************************************
     * Global function prototypes (public to other modules)
     ******************************************************************************/

    extern void FANCTRL_DataInit(void);
    extern void FANCTRL_SpeedCtrl(void);
    extern void FANCTRL_SpeedCnt(void);
    extern void FANCTRL_SpeedCalc(void);
    extern void FANCTRL_Dutyupdate(uint16 u16q12Duty);
    extern uint16 FanLookUpApps(const uint16 *X, const uint16 *Y, uint16 dim, uint32 x);

    extern uint16 debugtempindex;
#ifdef	__cplusplus
}
#endif

#endif	/* FANCTRL_H */

