/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/* 
 * File:   Def.h
 * Author: shuangcai
 * Comments:
 * Revision history: 
 */

#ifndef DEF_H
#define	DEF_H

#include <xc.h> // include processor files - each processor file is guarded.  
typedef   signed char      int8_t;
typedef unsigned char      uint8_t;
typedef   signed int       int16_t;
typedef unsigned int       uint16_t;
typedef   signed long      int32_t;
typedef unsigned long      uint32_t;
typedef   signed long long int64_t;
typedef unsigned long long uint64_t;


#define Q10(X)	((X < 0.0) ? (int)(1024*(X) - 0.5) : (int)(1023*(X) + 0.5))
#define Q12(X)	((X < 0.0) ? (int)(4096*(X) - 0.5) : (int)(4095*(X) + 0.5))
#define Q15(X)	((X < 0.0) ? (int)(32768*(X) - 0.5) : (int)(32767*(X) + 0.5))
#define Q24(X)  ((X < 0.0) ? (long)(16777216*(X) - 0.5) : (long)(16777215*(X) + 0.5))
#define Q27(X)  ((X < 0.0) ? (long)(134217728*(X) - 0.5) : (long)(134217727*(X) + 0.5))
#define QP16(X) (unsigned int)(65536*(X) - 0.5)

#define RELAY_STRT()        { _LATA4 = 0; _TRISA4 = 0; IOCON1bits.PENH = 1; PDC1 = 0xF009;} //(PHASE1>>1);50% duty cycle
#define RELAY_OFF()         { _LATA4 = 0;IOCON1bits.PENH = 1; _TRISA4 = 1;  PDC1 = 0x0000;}

#define DEBOUNCE_SET_CLR_2(flag,status1,status2,time_set,time_clr)  \
{                                                   \
  static uint16 flag##_debounce_time_set = 0;       \
  static uint16 flag##_debounce_time_clr = 0;       \
  if(!flag)                                         \
  {                                                 \
    flag##_debounce_time_clr = 0;                   \
    if(status1)                                     \
    {                                               \
      if(++flag##_debounce_time_set >= time_set)    \
      {                                             \
        flag = 1;                                   \
      }                                             \
    }                                               \
    else                                            \
    {                                               \
      flag##_debounce_time_set = 0;                 \
    }                                               \
  }                                                 \
  else                                              \
  {                                                 \
    flag##_debounce_time_set = 0;                   \
    if(status2)                                     \
    {                                               \
      if(++flag##_debounce_time_clr >= time_clr)    \
      {                                             \
        flag = 0;                                   \
      }                                             \
    }                                               \
    else                                            \
    {                                               \
      flag##_debounce_time_clr = 0;                 \
    }                                               \
  }                                                 \
}

#define  SQRTQ15lin10_FS(a) (   											  \
  ( 					 	   												  \
  ((a) < 1800) ?		  	   												  \
    ( ((a) < 700) ? 		       											  \
        ( ((a) < 30) ? (701 + 23 * ((a) - 15))								  \
          :  	       ( ((a) < 200) ? (1619 + 10 * ((a) - 80)) 			  \
                         :             (3840 + (((a) - 450)<<2)) 			  \
            )																  \
        )																	  \
      : ( ((a) < 1000) ? (5277 + 3 * ((a) - 850))     						  \
	      :              (6527 + (((long)(20564) * ((a) - 1300))>>13))		  \
		)																	  \
    )																		  \
  :	( ((a) < 9000) ? 														  \
	    ( ((a) < 4500) ? (9832 + (((long)(27302) * ((a) - 2950))>>14)) 		  \
          :              (14594 + (((long)(18393) * ((a) - 6500))>>14)) 	  \
        )																	  \
      :	( ((a) < 15000) ? (19829 + (((long)(27073) * ((a) - 12000))>>15))	  \
    	  :	( ((a) < 22000) ? (24286 + (((long)(22105) * ((a) - 18000))>>15)) \
			  :               (29955 + (((long)(17922) * ((a) - 27384))>>15)) \
			) 																  \
		)																	  \
    )																		  \
  ))



#endif	/* DEF_H */

