/* 
 * File:   Protection.h
 * Author: 
 *
 * 
 */

#ifndef PROTECTION_H
#define	PROTECTION_H

#ifdef	__cplusplus
extern "C" {
#endif

    /*******************************************************************************
     * Local constants and macros
     ******************************************************************************/

    /*******************************************************************************
     * Global data types (typedefs / structs / enums)
     ******************************************************************************/
    /***********************************************
     * Output
     **********************************************/
    /* Flags */
    /* V1 Fault */
    
#define FLG_B_LLC_V1_FW_OVP             stV1FaultFlag00.Bits.f0  /* 1 = V1 OVP */    
#define FLG_B_LLC_V1_HW_OVP             stV1FaultFlag00.Bits.f1  /* 1 = V1 OVW */
#define FLG_B_LLC_V1_UVP                stV1FaultFlag00.Bits.f2  /* 1 = V1 UVP */
#define FLG_B_LLC_V1_OCP                stV1FaultFlag00.Bits.f3  /* 1 = V1 OCP */
#define FLG_B_LLC_V1_OCW                stV1FaultFlag00.Bits.f4  /* 1 = V1 OCW */
#define FLG_B_LLC_V1_SCP                stV1FaultFlag00.Bits.f5  /* 1 = V1 SHORT */
#define FLG_B_FAN_FAULT                 stV1FaultFlag00.Bits.f6  /* 1 = FAN FAIL */
#define FLG_B_LLC_V1_FW_OVW             stV1FaultFlag00.Bits.f7  /* 1 = V1 OVW */
#define FLG_B_LLC_V1_FW_UVW             stV1FaultFlag00.Bits.f8  /* 1 = V1 OVP */
#define FLG_B_V1_ORING_FAULT            stV1FaultFlag00.Bits.f9  /* 1 = V1 ORI FALT */
#define FLG_B_V1_CT_FLAG                stV1FaultFlag00.Bits.fa  /* 1 = CT have been triggr */
#define FLG_B_V1_OC_HICCUP              stV1FaultFlag00.Bits.fb  /* 1 = V1 is hiccuping for OC */
#define FLG_B_V1_SCP_TEMP               stV1FaultFlag00.Bits.fc  /* 1 = V1 SCP temp flag */
#define FLG_B_V1_FW_FAST_OVP            stV1FaultFlag00.Bits.fd  /* 1 = V1 fast OVP */
#define FLG_B_V1_ISHARE_FAIL            stV1FaultFlag00.Bits.fe  /* 1 = V1 fast OVP */    
#define FLG_B_V1_SCP                    stV1FaultFlag00.Bits.ff  // 1 = V1 SCP    
/*        
#define FLG_B_LLC_V1_FW_OVP             stV1FaultFlag00.Bits.f0  // 1 = V1 OVP     
#define FLG_B_LLC_V1_OCP                stV1FaultFlag00.Bits.f1  // 1 = V1 OCP 
#define FLG_B_LLC_V1_OCW                stV1FaultFlag00.Bits.f2  // 1 = V1 OCW 
#define FLG_B_LLC_V1_FW_OVW             stV1FaultFlag00.Bits.f3  // 1 = V1 OVW 
#define FLG_B_V1_SCP_TEMP               stV1FaultFlag00.Bits.f4  // 1 = V1 SCP temp flag 
#define FLG_B_V1_FW_FAST_OVP            stV1FaultFlag00.Bits.f5  // 1 = V1 fast OVP 
#define FLG_B_V1_OC_HICCUP              stV1FaultFlag00.Bits.f6  // 1 = V1 OC Hiccup 
#define FLG_B_V1_SCP                    stV1FaultFlag00.Bits.f7  // 1 = V1 SCP 
*/

#define FLG_B_STB_OC_HICCUP             stStbFaultFlag00.Bits.f0  /* 1 = STB OCP */
    
#define FLG_B_V1_FAULT_LATCH            stLatchFaultFlag00.Bits.f0 /* 1 = V1 fault latch   */
#define FLG_B_STB_FAULT_LATCH           stLatchFaultFlag00.Bits.f1

#define FLG_B_INPUT_OK                  stSysStateFlag00.Bits.f0  /* 1 = INPUT OK */
#define FLG_B_BULK_OK                   stSysStateFlag00.Bits.f1  /* 1 = BULK OK */
#define FLG_B_PSON_ENABLE               stSysStateFlag00.Bits.f2  /* 1 = SYSTEM PSON ENABLE */
#define FLG_V1_FAULT_CONDITION          stSysStateFlag00.Bits.f3  /* 1 = V1 fault state */
#define FLG_V1_PRISYS_CONDITION         stSysStateFlag00.Bits.f4  /* 1 = V1 pri sys turn onoff state */
#define FLG_B_PSON_LAST_ENABLE          stSysStateFlag00.Bits.f5
#define FLG_B_PSON_ACTIVED              stSysStateFlag00.Bits.f6
#define FLG_B_INPUT_DELAY_OK            stSysStateFlag00.Bits.f7
#define FLG_STA_OTP                     stSysStateFlag00.Bits.f8 
#define FLG_5VSTB_FAULT_CONDITION        stSysStateFlag00.Bits.f9
    
#define FLG_STA_VIN_OK_FOR_VSB          stSysStateFlag01.Bits.f0  /* 1 = Vin voltage is OK for Vsb    */
#define FLG_STA_VIN_OK_FOR_V1           stSysStateFlag01.Bits.f1  /* 1 = Vin voltage is OK for V1 */
#define FLG_DETECTED_NO_VIN             stSysStateFlag01.Bits.f2  /* 1 = No Vin power */
#define FLG_STA_VIN_UVP                 stSysStateFlag01.Bits.f3  /* 1 = Inout voltage is too too low */
#define FLG_STA_VIN_UVW                 stSysStateFlag01.Bits.f4  /* 1 = Inout voltage is too low */
#define FLG_STA_VIN_OVP                 stSysStateFlag01.Bits.f5  /* 1 = Inout voltage is tootoo high */
#define FLG_STA_VIN_OVW                 stSysStateFlag01.Bits.f6  /* 1 = Inout voltage is too high */
#define FLG_STA_LATCH_VIN_TYPE          stSysStateFlag01.Bits.f7  /* 1 = Latch Vin type */
//#define FLG_STA_VIN_OK_FOR_V1_2         stSysStateFlag01.Bits.f8  /* 1 = Latch Vin type */
#define FLG_B_V1_ORING_INV_CMD          stSysStateFlag01.Bits.f9  /* 1 = Oring inv Cmd */
#define FLG_B_V1_ORING_TEST_TOUT_EN     stSysStateFlag01.Bits.fa  /* 1 = Oring Test Enable */    
        
#define FLG_B_V1_STATE                  stVoutStateFlag.Bits.f0  /* 1 = V1 ON */
#define FLG_B_V1_CCL                    stVoutStateFlag.Bits.f1  /* 1 = V1 CURRENT LIMIT */
#define FLG_B_V1_CT                     stVoutStateFlag.Bits.f2  /* 1 = V1 CT */
#define FLG_B_V1_SOFT_START             stVoutStateFlag.Bits.f3  /* 1 = V1 soft start status */
#define FLG_B_V1_INIT_LOOP              stVoutStateFlag.Bits.f4  /* 1 = V1 initial loop */
#define FLG_B_V1_BURST_MODE             stVoutStateFlag.Bits.f5  /* 1 = V1 burst mode */
#define FLG_B_V1_PWOK_GOOD              stVoutStateFlag.Bits.f6  /* 1 = V1 is OK */
#define FLG_B_V1_BOOT_CHARGE            stVoutStateFlag.Bits.f7  /* 1 = V1 soft start status */
#define FLG_B_V1_POK_DELAY_DONE         stVoutStateFlag.Bits.f8
    /*******************************************************************************
     * Global data
     ******************************************************************************/
    extern volatile GLOBAL_U_U16BIT stV1FaultFlag00,stStbFaultFlag00,stLatchFaultFlag00;  
    extern volatile GLOBAL_U_U16BIT stVoutStateFlag, stSysStateFlag00, stSysStateFlag01;
    extern uint16 u16StartMonV1UvpCnt;
    
    /*******************************************************************************
     * Global function prototypes
     ******************************************************************************/
    extern void PROTECT_V1OcPointset(void);
    extern void PROTECT_DataInit(void);
    extern void PROTECT_V1Curr(void);
    extern void PROTECT_V1Volt(void);
    extern void PROTECT_5VSTBDetect(void);
    extern void PROTECT_5VSTBCurrDetect(void);
    extern void PWR_GOOD_ASSERT(void);
    /********************************************************************************/
#define POK_ON_HOP            _LATB12             
#define POK_ON_DIRECTION      _TRISB12 
#define POK_IO_OUPUT_VAL      _RB12
    
#define LLC_ON_HOP            _LATA3             
#define LLC_ON_DIRECTION      _TRISA3 
#define LLC_IO_OUPUT_VAL      _RA3 
    
#define POK_EN()        { POK_ON_DIRECTION = 0; POK_ON_HOP = 0; IOCON3bits.PENL = 1;SPHASE3 = 0x2000;SDC3 = (SPHASE3<<1);} //(SPHASE2>>1) 50%;100%:SPHASE2
#define POK_DIS()       { POK_ON_HOP = 0;  IOCON3bits.PENL = 1; POK_ON_DIRECTION = 1;SDC3 = 0x0000;}

#define LLC_DIS()        { LLC_ON_DIRECTION = 0; LLC_ON_HOP = 0; IOCON1bits.PENL = 1;SPHASE1 = 0x2000;SDC1 = (SPHASE1<<1);} //(SPHASE2>>1) 50%;100%:SPHASE2
#define LLC_EN()       { LLC_ON_HOP = 0;  IOCON1bits.PENL = 1; LLC_ON_DIRECTION = 1;SDC1 = 0x0000;}
#ifdef	__cplusplus
}
#endif

#endif	/* PROTECTION_H */

