/** ****************************************************************************
 * \file    Protection.c
 * \brief   Main Output and standby output protection
 *
 * \section AUTHOR
 *    1. 
 *
 * \section SVN
 *  $Date$
 *  $Author$
 *  $Revision$
 *
 * \section LICENSE
 * Copyright (c) 
 * All rights reserved.
 *******************************************************************************/

/*******************************************************************************
 * merge from branch
 * Included header
 * demo test
 ******************************************************************************/
#include <global.h>
#include "Define.h"

/* Module header */

#include "McuAdc.h"
#include "McuGPIO.h"
#include "Protection.h"
#include "McuUart2.h"
#include "McuUart1.h"

/*******************************************************************************
 * Local constants and macros (private to module)
 ******************************************************************************/
#define MG_U16Q12_V1_REF              Q12(12.0 / U16Q12_V1_MAX_INT)
/* Macro use for output judgment */   
#define MG_U16Q12_V1_OVP_THR_HI       Q12(15.0 / U16Q12_V1_MAX_INT)
#define MG_U16Q12_V1_OVP_THR_LO       Q12(12.0 / U16Q12_V1_MAX_INT)
#define MG_U16Q12_V1_OVW_THR_HI       Q12(14.0 / U16Q12_V1_MAX_INT)
#define MG_U16Q12_V1_OVW_THR_LO       Q12(11.2 / U16Q12_V1_MAX_INT)


#define MG_U16Q12_V1_SCP_THR_LO       Q12(9.0 / U16Q12_V1_MAX_INT)


#define MG_U16_V1_OCP_THR_HI_HL    Q12(U16Q12_I1_HL_FULL_LOAD * 1.07 / U16Q12_I1_MAX)   //
#define MG_U16_V1_OCP_THR_LO_HL    Q12(U16Q12_I1_HL_FULL_LOAD * 1.02 / U16Q12_I1_MAX)   //1.10
#define MG_U16_V1_OCW_THR_HI_HL    Q12(U16Q12_I1_HL_FULL_LOAD * 1.05 / U16Q12_I1_MAX)
#define MG_U16_V1_OCW_THR_LO_HL    Q12(U16Q12_I1_HL_FULL_LOAD * 1.01 / U16Q12_I1_MAX)

#define MG_U16Q12_V1_SCP_HL_THR       Q12(1.50 * U16Q12_I1_HL_FULL_LOAD / U16Q12_I1_MAX)

#define MG_U16_OTP_THR                 0x03E1 //120
#define MG_U16_OTP_RCV                 0x0365 //110?
#define MG_U16_OTP_SET_TM              50

#define MG_U16_V1_OVP_SET_TM           2
#define MG_U16_V1_OVW_SET_TM           10
#define MG_U16_V1_OVW_CLEAR_TM         10
#define MG_U16_STB_OVP_SET_TM          2
#define MG_U16_STB_OCP_SET_TM          2

#define MG_U16Q12_STB_SCP_THR_LO      Q12(3.0 / U16Q12_STB_V_MAX_INT)
#define MG_U16Q12_STB_OVP_THR_HI      (uint16) Q12(5.5F / U16Q12_STB_V_MAX_INT)
#define MG_U16Q12_STB_OVP_THR_LO      (uint16) Q12(5.1F / U16Q12_STB_V_MAX_INT)

#define MG_U16_STB_OCP_THR_HI_HL    Q12(2.2F / U16Q12_STB_I_MAX_INT)   
#define MG_U16_STB_OCP_THR_LO_HL    Q12(2.0F / U16Q12_STB_I_MAX_INT)   

#define MG_U16Q12_STB_SCP_HL_THR       Q12(3.0 / U16Q12_STB_I_MAX_INT)

#define MG_U16_I1_FAST_OCP_SET_TM      50
#define MG_U16_V1_CCL_SCP_SET_TM       5
#define MG_U16_V1_SCP_SET_TM           30
#define MG_U16_V1_OC_RESET_TM          5000
#define MG_OCP_RETRY_TIMES             100
#define MG_OCP_HICCUP_OFF_TIME         5000

#define MG_U16_STB_FAST_OCP_SET_TM     50
#define MG_U16_STB_SCP_SET_TM          30
#define MG_U16_STB_OC_RESET_TM         5000

#define MG_U16Q12_V1_PWG_TH            Q12(36.0 / U16Q12_V1_MAX_INT)
#define MG_U16_V1_PWG_TM               1000  //100us*1000 = 100ms
#define MG_U16_V1_PWG_OFF_TM           30  //100us*10 = 1ms
/*******************************************************************************
 * Global data types (private typedefs / structs / enums)
 ******************************************************************************/
volatile GLOBAL_U_U16BIT stV1FaultFlag00, stStbFaultFlag00,stLatchFaultFlag00;  
volatile GLOBAL_U_U16BIT stVoutStateFlag, stSysStateFlag00, stSysStateFlag01;
uint16 u16StartMonV1UvpCnt = 0;
uint8 u8V1OcpHiccupRetryTimes = 0,u8StbOcpHiccupRetryTimes = 0;
/*******************************************************************************
 * Local data (private to module)
 ******************************************************************************/
static uint16 MON_u16V1OcpHi = MG_U16_V1_OCP_THR_HI_HL;
static uint16 MON_u16V1OcpLo = MG_U16_V1_OCP_THR_LO_HL;

static uint16 MON_u16V1ScpHi = MG_U16Q12_V1_SCP_HL_THR;


static uint16 MON_u16StbOcpHi = MG_U16_STB_OCP_THR_HI_HL;
static uint16 MON_u16StbOcpLo = MG_U16_STB_OCP_THR_LO_HL;

static uint16 MON_u16STBScpHi = MG_U16Q12_STB_SCP_HL_THR;
/*******************************************************************************
 * Local function prototypes (private to module)
 ******************************************************************************/

/*******************************************************************************
 * Global functions (public to other modules)
 ******************************************************************************/
void PROTECT_V1OcPointset(void);
void PROTECT_DataInit(void);
void PROTECT_V1Volt(void);
void PROTECT_V1Curr(void);

/********************************************************************************
 * \brief         Initial all status flags
 *
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PROTECT_DataInit(void)
{
  stV1FaultFlag00.ALL = 0U;
  stVoutStateFlag.ALL = 0U;
  stSysStateFlag00.ALL = 0U;
  stSysStateFlag01.ALL = 0U;
  u8V1OcpHiccupRetryTimes = 0;
}


/********************************************************************************
 * \brief         Check LLC 36V voltage is OK or not
 *                Called in Timer_ISR.c every 100us
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PROTECT_V1Volt(void)
{
  static uint16 u16MonV1OVPDly = 0,tmp_r = 0;
  tmp_r = aAdcAverage[MG_U8_ADC_INDEX_V1_VOLT_EXT].u16q12Avg;//ADCBUF4;
  //Tx_Buf[1] = tmp_r;
  //Tx_Buf[2] = tmp_r>>8;
  /* V1 ovp monitor */
  if ((stAdcBufResult.u16AdcBufV1VoltVEA > MG_U16Q12_V1_OVP_THR_HI) || (FALSE != FLG_B_V1_FW_FAST_OVP))
  {
    if ((u16MonV1OVPDly < MG_U16_V1_OVP_SET_TM) && (FALSE == FLG_B_V1_FW_FAST_OVP))
    {
      u16MonV1OVPDly++;
    }
    else
    {
      FLG_B_V1_FAULT_LATCH = 1;
      FLG_B_LLC_V1_FW_OVP = 1;
      FLG_B_LLC_V1_FW_OVW = 1; 
      u16MonV1OVPDly = 0;
    }
  }
  else if (stAdcBufResult.u16AdcBufV1VoltVEA < MG_U16Q12_V1_OVP_THR_LO)
  {
    if (u16MonV1OVPDly > 0)
    {
      u16MonV1OVPDly--;
    }
  }
  /* V1 ovw monitor */
  DEBOUNCE_SET_CLR_2(FLG_B_LLC_V1_FW_OVW, /* The flag set or reset */
                     stAdcBufResult.u16AdcBufV1VoltVEA > MG_U16Q12_V1_OVW_THR_HI, /* set flag condition */
                     stAdcBufResult.u16AdcBufV1VoltVEA < MG_U16Q12_V1_OVW_THR_LO, /* rest flag condition */
                     MG_U16_V1_OVW_SET_TM, /* set time */
                     MG_U16_V1_OVW_CLEAR_TM); /* reset time */

  /* reset time */
}

/********************************************************************************
 * \brief         Check main output current is OK or not
 *                 Called in Timer_ISR.c every 1ms
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PROTECT_V1Curr(void)
{
  static uint32 u32ScpDly = 0;
  static uint32 u32OcpDly = 0;
  static uint16 u16OcpResetCnt = 0;
  static uint16 u16OcpHiccupOffTimeCnt = 0,tmp_c = 0;
  
  tmp_c = aAdcAverage[MG_U8_ADC_INDEX_V1_CURR].u16q12Avg;//ADCBUF4;
  //Tx1_Buf[1] = tmp_c;
  //Tx1_Buf[2] = tmp_c>>8;
  if (OFF != FLG_B_V1_STATE)
  {
    if ((stAdcBufResult.u16AdcBufV1Curr > MON_u16V1ScpHi) && (stAdcBufResult.u16AdcBufV1VoltVEA < MG_U16Q12_V1_SCP_THR_LO))
    {
      u16OcpResetCnt = 0;

      if (u32ScpDly < MG_U16_V1_SCP_SET_TM)
      {
        u32ScpDly++;
      }
      else
      {
        FLG_B_LLC_V1_OCW = TRUE;
        FLG_B_V1_SCP_TEMP = TRUE;
        FLG_B_V1_OC_HICCUP = TRUE;
        u32ScpDly = 0;
      }
    }
    else if (aAdcAverage[MG_U8_ADC_INDEX_V1_CURR].u16q12Avg > MON_u16V1OcpHi)
    {
      u16OcpResetCnt = 0;
      if (u32OcpDly < MG_U16_I1_FAST_OCP_SET_TM)
      {
        u32OcpDly++;
      }
      else
      {
        FLG_B_LLC_V1_OCW = TRUE;
        FLG_B_V1_SCP_TEMP = TRUE;
        FLG_B_V1_OC_HICCUP = TRUE;
        u32OcpDly = 0;
      }
    }
    else if (aAdcAverage[MG_U8_ADC_INDEX_V1_CURR].u16q12Avg < MON_u16V1OcpLo)
    {
      if (u32ScpDly > 0)
      {
        u32ScpDly--;
      }
      if (u32OcpDly > 0)
      {
        u32OcpDly--;
      }
      if (u16OcpResetCnt > MG_U16_V1_OC_RESET_TM)
      {
        u32ScpDly = 0;
        u32OcpDly = 0;
        u8V1OcpHiccupRetryTimes = 0;
      }
      else
      {
        u16OcpResetCnt++;
      }
    }
  }
  else
  {
    u32ScpDly = 0;
    u32OcpDly = 0;
    
    if (FALSE != FLG_B_V1_OC_HICCUP)
    {
      if (u8V1OcpHiccupRetryTimes <= MG_OCP_RETRY_TIMES)
      {
        if (u16OcpHiccupOffTimeCnt > MG_OCP_HICCUP_OFF_TIME)
        {
          u16OcpHiccupOffTimeCnt = 0;
          u8V1OcpHiccupRetryTimes++;
          FLG_B_V1_OC_HICCUP = FALSE;
        }
        else
        {
          u16OcpHiccupOffTimeCnt++;
        }
      }
      else
      {
        if (FALSE != FLG_B_V1_SCP_TEMP)
        {
          FLG_B_V1_SCP = TRUE;
        }
        FLG_B_LLC_V1_OCP = TRUE;
        FLG_B_V1_FAULT_LATCH = TRUE;
        FLG_B_V1_OC_HICCUP = FALSE;
      }
    }
    else
    {
      u16OcpHiccupOffTimeCnt = 0;
    }
  }

}

/********************************************************************************
 * \brief         V1 OC value set
 *
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PROTECT_V1OcPointset(void)
{
  /***************** V1 OC value set ********************/


}

/********************************************************************************
 * \brief         - PROTECT_5VSTBDetect 100ms cycle
 *
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PROTECT_5VSTBDetect(void)
{
  static uint16 u16MonSTBOVPDly = 0;

  /* 5vstb ovp monitor */
  if (stAdcBufResult.u16AdcBufVsbVoltExt > MG_U16Q12_STB_OVP_THR_HI)
  {
    if (u16MonSTBOVPDly < MG_U16_STB_OVP_SET_TM)
    {
      u16MonSTBOVPDly++;
    }
    else
    {
      FLG_B_STB_FAULT_LATCH = 1;
      u16MonSTBOVPDly = 0;
    }
  }
  else if (stAdcBufResult.u16AdcBufVsbVoltExt < MG_U16Q12_STB_OVP_THR_LO)
  {
    if (u16MonSTBOVPDly > 0)
    {
      u16MonSTBOVPDly--;
    }
  }
  
}

/********************************************************************************
 * \brief         - PROTECT_5VSTBCurrDetect 100ms cycle
 *
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PROTECT_5VSTBCurrDetect(void)
{
  static uint32 u32StbScpDly = 0;
  static uint32 u32StbOcpDly = 0;
  static uint16 u16StbOcpResetCnt = 0;
  static uint16 u16StbOcpHiccupOffTimeCnt = 0;

  if (OFF != FLG_B_V1_STATE)
  {
    if((stAdcBufResult.u16AdcBufVsbCurr > MON_u16STBScpHi)&& (stAdcBufResult.u16AdcBufVsbVoltExt < MG_U16Q12_STB_SCP_THR_LO))
    {
      u16StbOcpResetCnt = 0;

      if (u32StbScpDly < MG_U16_STB_SCP_SET_TM)
      {
        u32StbScpDly++;
      }
      else
      {
        FLG_B_STB_OC_HICCUP = TRUE;
        u32StbScpDly = 0;
      }
    }
    else if (stAdcBufResult.u16AdcBufVsbCurr > MON_u16StbOcpHi)
    {
      u16StbOcpResetCnt = 0;
      if (u32StbOcpDly < MG_U16_STB_FAST_OCP_SET_TM)
      {
        u32StbOcpDly++;
      }
      else
      {        
        FLG_B_STB_OC_HICCUP = TRUE;
        u32StbOcpDly = 0;
      }
    }
    else if (stAdcBufResult.u16AdcBufVsbCurr < MON_u16StbOcpLo)
    {
      if (u32StbScpDly > 0)
      {
        u32StbScpDly--;
      }
      if (u32StbOcpDly > 0)
      {
        u32StbOcpDly--;
      }
      if (u16StbOcpResetCnt > MG_U16_STB_OC_RESET_TM)
      {
        u32StbScpDly = 0;
        u32StbOcpDly = 0;
        u8StbOcpHiccupRetryTimes = 0;
      }
      else
      {
        u16StbOcpResetCnt++;
      }
    }
  }
  else
  {
    u32StbScpDly = 0;
    u32StbOcpDly = 0;
    
    if (FALSE != FLG_B_STB_OC_HICCUP)
    {
      if (u8StbOcpHiccupRetryTimes <= MG_OCP_RETRY_TIMES)
      {
        if (u16StbOcpHiccupOffTimeCnt > MG_OCP_HICCUP_OFF_TIME)
        {
          u16StbOcpHiccupOffTimeCnt = 0;
          u8StbOcpHiccupRetryTimes++;
          FLG_B_STB_OC_HICCUP = FALSE;
        }
        else
        {
          u16StbOcpHiccupOffTimeCnt++;
        }
      }
      else
      {
        FLG_B_STB_FAULT_LATCH = TRUE;
        FLG_B_STB_OC_HICCUP = FALSE;
      }
    }
    else
    {
      u16StbOcpHiccupOffTimeCnt = 0;
    }
  }
}

/********************************************************************************
 * \brief         - PWR_GOOD_ASSERT
 *
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PWR_GOOD_ASSERT(void)
{
  static uint16 u16MonPwgDly = 0;
  
  if(aAdcAverage[MG_U8_ADC_INDEX_V1_VOLT_EXT].u16q12Avg < MG_U16Q12_V1_REF)  //ADCBUF4
  {
    FLG_B_V1_POK_DELAY_DONE = 0;
  }
  else
  {
    FLG_B_V1_POK_DELAY_DONE = 1;
   
  }
      
 
    if ((FALSE != FLG_V1_PRISYS_CONDITION)&&(FALSE == FLG_V1_FAULT_CONDITION))
    {
       // Tx_Buf[4]=0x04;
        if(FLG_B_V1_POK_DELAY_DONE == 1)
    	{
           if(u16MonPwgDly < MG_U16_V1_PWG_TM)
           {
             u16MonPwgDly++;
           }
           else
           {
            //PORT_OUT_V1_PWR_OK_EN;
               
             POK_EN();
             //PORT_OUT_LED_EN;
             u16MonPwgDly = 0;
           }
    	}    
    }
   else
   {
     //   Tx_Buf[4]=0x44;
        u16MonPwgDly = 0;
        FLG_B_V1_POK_DELAY_DONE = 0;
       // PORT_OUT_V1_PWR_OK_DIS;
        POK_DIS();
        //PORT_OUT_LED_DIS;
   }

}


/********************************************************************************
 * \brief         - PROTECT_TempDetect 100ms cycle
 *
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -l
 *
 * \return        -
 *
 *******************************************************************************/
void PROTECT_TempDetect(void)
{
  static uint16 u16MonOTPDly = 0,u16MonOTPRcvDly=0;

  /* 5vstb ovp monitor */
  if (stAdcBufResult.u16AdcBufTemp > MG_U16_OTP_THR)
  {
   // if (u16MonOTPDly < MG_U16_OTP_SET_TM)
    {
      u16MonOTPDly++;
    }
  //  else
    {
      FLG_STA_OTP = 1;//disabled for test
      u16MonOTPDly = 0;
    }
    u16MonOTPRcvDly = 0;
  }
  else if (stAdcBufResult.u16AdcBufVsbVoltExt < MG_U16_OTP_RCV)
  {
    u16MonOTPDly = 0;
  //  if (u16MonOTPRcvDly < MG_U16_OTP_SET_TM)
    {
      u16MonOTPRcvDly++;
    }
  //  else
    {
      FLG_STA_OTP = 0;
      u16MonOTPRcvDly = 0;
    }
  }
  
}