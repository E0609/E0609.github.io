/* 
 * File:   Dig_InOut.h
 * Author: 
 *
 * 
 */

#ifndef DIG_INOUT_H
#define	DIG_INOUT_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* DIG_INOUT_H */

