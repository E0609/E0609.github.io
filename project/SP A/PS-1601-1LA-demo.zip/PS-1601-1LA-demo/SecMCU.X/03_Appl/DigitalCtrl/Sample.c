/*******************************************************************************
 * \file    llccontrol.c
 * \brief   
 *
 * \section AUTHOR
 *    1. 
 *
 * \section SVN
 *  $Date$
 *  $Author$
 *  $Revision$
 *
 * \section LICENSE
 * Copyright (c) Lite-ON Singapore Pte Ltd
 * All rights reserved.
 *******************************************************************************/

/*******************************************************************************
 * Included header
 ******************************************************************************/
#include "global.h"
#include <p33EP64GS504.h>
#include <xc.h>
#include "McuPwm.h"
#include "McuAdc.h"
#include "McuGPIO.h"
#include "Define.h"
#include "Sample.h"
#include "Protection.h"
#include "Timer_ISR.h"
#include "PsuState.h"
#include "McuUart2.h"
/*******************************************************************************
 * Local constants and macros (private to module)
 ******************************************************************************/
#define LLC_MG_REF_2V5_CALI       Q12(2.5/3.3)
#define LLC_MG_V1_DROP_VAL        Q12(1.20 / Max_V1Out_LOOP)
#define LLC_MG_FULL_LOAD          Q12(17.0 / U16Q12_I1_MAX)
#define LLC_MG_DROP_RATE          Q12(LLC_MG_V1_DROP_VAL * 128 / LLC_MG_FULL_LOAD)
#define MG_MIN_PHASE_SHIFT        10
#define MG_FAST_OV_POINT          Q12(24.0F / U16Q12_V1_MAX_INT)
#define CCL_THR_SWITCH_DELAY      4000 //60ms/15us
/*******************************************************************************
 * Local data types (private typedefs / structs / enums)
 ******************************************************************************/

/*******************************************************************************
 * Local data (private to module)
 ******************************************************************************/
static sint16 s16LLC_PWM_Period;
static sint16 s16LLC_PWM_Duty_LLC;
static sint16 s16LLC_PWM_Duty_SR;
static sint16 llc_mg_s16ishare_compen;
static sint16 V1_ext;


/*******************************************************************************
 * Global functions (public to other modules)
 ******************************************************************************/



/*******************************************************************************
 * Function:        ADCAN2Interrupt
 *
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     Handle control loop in the AN2 interrupt routine, 15us
 * Comment:         Voltage loop operation time 5uS~8uS
 ******************************************************************************/
void __attribute__((__interrupt__, no_auto_psv)) _ADCAN2Interrupt()
{
  static uint8 u8OvpCnt = 0;
  
  V1_ext = ADC_V1_VOLT_VEA;
  stAdcBufResult.u16AdcBufV1VoltVEA = V1_ext;
  stAdcBufResult.u16AdcBufV1VoltExt = ADC_V1_VOLT_EXT;
  stAdcBufResult.u16AdcBufV1Curr = ADC_I1_CURR;
  stAdcBufResult.u16AdcBufNtcSr = 0;
  stAdcBufResult.u16AdcBufV1IShareVolt = ADC_ISHARE_BUS;
  stAdcBufResult.u16AdcBufV1ILocalVolt = ADC_ISHARE_LOCAL;
  stAdcBufResult.u16AdcBufRef2V5 = 0;
  stAdcBufResult.u16AdcBufVsbVoltExt = ADC_VSB_VOLT;
  stAdcBufResult.u16AdcBufVsbCurr = ADC_VSB_CURR;
  stAdcBufResult.u16AdcBufTemp = ADC_NTC_SR;
  /**********************************/    
      
  //Fast OVP detect
  if (stAdcBufResult.u16AdcBufV1VoltVEA > MG_FAST_OV_POINT)
  {
    if (u8OvpCnt < 1) //15uS * (1+1) = 30uS
    {
      u8OvpCnt++;
    }
    else
    {
      FLG_B_V1_FW_FAST_OVP = TRUE;
    }
  }
  else
  {
    u8OvpCnt = 0;
  }
  
  //detect PSON signal 
  FLG_B_PSON_LAST_ENABLE = FLG_B_PSON_ENABLE;
    DEBOUNCE_SET_CLR_2(FLG_B_PSON_ENABLE,
                 PORT_IN_PSON_IS_ACTIVE,
                 PORT_IN_PSON_IS_INACTIVE,
                 200,
                 4);
    
Tx_Buf[3]=FLG_B_PSON_ENABLE;
    if((FLG_B_PSON_ENABLE)&&(FALSE == FLG_B_PSON_LAST_ENABLE))
    {
       // Tx_Buf[3]=0xEE;
        PORT_OUT_LED_EN;
        FLG_B_PSON_ACTIVED = 1;
    }
    else
    {
        PORT_OUT_LED_DIS;
       // Tx_Buf[3]=0xBB;
    }
     
    
  if (FLG_B_V1_STATE == ON)
  { 
//
  }
  _ADCAN2IF = 0;
  return;
}

/*******************************************************************************
 * Function:        PWMSpEventMatchInterrupt
 *
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     PWM event match interrupt routine
 *
 ******************************************************************************/
void __attribute__((__interrupt__, no_auto_psv)) _PWMSpEventMatchInterrupt(void)
{

  PWM_LLC_PERIOD_REG = s16LLC_PWM_Period;
  PWM_LLC_DUTY_REG = s16LLC_PWM_Duty_LLC;

  PWM_SPECIAL_EVENT_REG = 0; // Special Event Interrupt is disabled
  PWM_INTERR_FLAG_REG = 0;
}

/*******************************************************************************
 * Function:        _CMP2Interrupt
 *
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     V1 OCP interrupt - CMP2
 *
 ******************************************************************************/

void __attribute__((__interrupt__, no_auto_psv)) _CMP2Interrupt()
{
  if (FLG_B_V1_STATE == ON)
  {
    PSU_mg_V1PwrOff();
    FLG_B_V1_OC_HICCUP = TRUE;          
  }

  _AC2IF = 0;
  return;
}


