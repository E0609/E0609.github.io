/* 
 * File:   llc_ctrl.h
 * Author: 
 *
 * 
 */

#ifndef LLC_CTRL_H
#define	LLC_CTRL_H

#ifdef	__cplusplus
extern "C" {
#endif

    /*******************************************************************************
     * Local constants and macros (private to module)
     ******************************************************************************/
    /*******************************************************************************
     * Global constants and macros
     ******************************************************************************/
#include "Define.h"
#include "McuClock.h"

#define MAX_FREQUENCY         250E3 
#define MIN_FREQUENCY         40E3 
#define MAX_FREQUENCY_SS      300E3 
#define MIN_FREQUENCY_SS      55E3  
#define RESONANT_FREQUENCY    70E3   

#define BURST_FREQUENCY         219E3 //190  150 195
#define MG_MAX_NOR_OPER_FREQ    220E3 //250  155 200
#define MG_MAX_NOR_SAFE_FREQ    240E3 //300  165 220

#define RESONANT_PERIOD      (unsigned int)(PWMCLOCKFREQ / RESONANT_FREQUENCY / 2)
#define MIN_PERIOD           (unsigned int)(PWMCLOCKFREQ / MAX_FREQUENCY / 2)
#define MAX_PERIOD           (unsigned int)(PWMCLOCKFREQ / MIN_FREQUENCY / 2)
#define MIN_PERIOD_SS        (unsigned int)(PWMCLOCKFREQ / MAX_FREQUENCY_SS / 2)
#define MAX_PERIOD_SS        (unsigned int)(PWMCLOCKFREQ / MIN_FREQUENCY_SS / 2)
#define MAX_PERIOD_SAFE      (unsigned int)(PWMCLOCKFREQ / 220E3 / 2)

#define BURST_PERIOD          (unsigned int)(PWMCLOCKFREQ / BURST_FREQUENCY / 2)
#define MG_MIN_NOR_OPER_PERI  (unsigned int)(PWMCLOCKFREQ / MG_MAX_NOR_OPER_FREQ / 2)
#define MG_MIN_NOR_SAFE_PERI  (unsigned int)(PWMCLOCKFREQ / MG_MAX_NOR_SAFE_FREQ  / 2)

#define MG_SHIFT_MAX         700      
#define MAX_u0_V             (unsigned int)MAX_PERIOD  
#define MIN_u0_V             (unsigned int)MIN_PERIOD 
#define MAX_u0_V_SS          (unsigned int)MAX_PERIOD_SS  
#define MIN_u0_V_SS          (unsigned int)MIN_PERIOD_SS 
#define MIN_u0_V_OP          (unsigned int)MG_MIN_NOR_OPER_PERI 
#define LLC_HB_DEADTIME          350        //1.06ns *300
#define LLC_HB_BURST_DEADTIME    550    
#define LLC_HB_START_DEADTIME    350      


#define Max_V1Out_LOOP      54.02 
#define MG_MAX_V1_SENSE     54.42    
#define V1_Ref_Set          36.00    
#define MG_V1_RATE_SENSE_DIV_LOOP Q12(MG_MAX_V1_SENSE / Max_V1Out_LOOP)     

#define V1_REF_SET_DEFAULT        Q12(V1_Ref_Set / Max_V1Out_LOOP)   

#define MAXERROR		          Q12(5.0 / Max_V1Out_LOOP)
#define MINERROR                  Q12(-5.0 / Max_V1Out_LOOP)
    /********************************************/
#define N_SS                 13

#define V1_SS_FACTOR_ML      (unsigned int)(((unsigned long)V1_REF_SET_DEFAULT << N_SS) / (100.0 * 29))
#define V1_SS_FACTOR_ZL      (unsigned int)(((unsigned long)V1_REF_SET_DEFAULT << N_SS) / (25.0 * 29))

#define V1_SS_FACTOR_K       V1_SS_FACTOR_ZL - V1_SS_FACTOR_ML 
     
    /*******************************************************************************
     * Global data
     ******************************************************************************/

    /*******************************************************************************
     * Global function prototypes
     ******************************************************************************/
    extern void InitCtrlLoop(void);

#ifdef	__cplusplus
}
#endif

#endif	/* LLC_CTRL_H */

