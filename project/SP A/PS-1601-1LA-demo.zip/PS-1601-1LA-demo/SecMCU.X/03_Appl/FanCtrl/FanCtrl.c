#include "global.h"
#include "FanCtrl.h"
#include "Define.h"
#include "McuUart1.h"

/*****************************************************************************************
 *
 *Copyright (C) 2012 Advanced Technology Development
 *                   Power SBG
 *                   LITE-ON TECHNOLOGY Corp.
 *
 *All Rights Reserved
 *
 *File Name : 
 *
 *Date : 
 *
 *Author :
 *
 *Description :
 *
 *******************************************************************************************/
//--------------- Global variable -------------------------------------------------------------

unsigned int Duty_Gain = 0;
volatile GLOBAL_U_U16BIT stFanStateFlag;
tFAN_CNTL gFan1;
tFAN_CNTL gFan2;

WORD FanDuty_Table[3][10] = {
    {SetDuty ( 30 ), SetDuty ( 30 ), SetDuty ( 30 ), SetDuty ( 34 ), SetDuty ( 36 ), SetDuty ( 41 ), SetDuty ( 50 ), SetDuty ( 58 ), SetDuty ( 69 ), SetDuty ( 80 ) },	// 25C
    {SetDuty ( 30 ), SetDuty ( 30 ), SetDuty ( 30 ), SetDuty ( 36 ), SetDuty ( 47 ), SetDuty ( 58 ), SetDuty ( 70 ), SetDuty ( 81 ), SetDuty ( 91 ), SetDuty ( 100 ) },	// 35C
    {SetDuty ( 34 ), SetDuty ( 34 ), SetDuty ( 41 ), SetDuty ( 49 ), SetDuty ( 58 ), SetDuty ( 68 ), SetDuty ( 78 ), SetDuty ( 92 ), SetDuty ( 100 ), SetDuty ( 100 ) },	// 55C
};

WORD FanDuty_Table2[3][10] = {
    {SetDuty ( 30 ), SetDuty ( 30 ), SetDuty ( 30 ), SetDuty ( 34 ), SetDuty ( 36 ), SetDuty ( 41 ), SetDuty ( 50 ), SetDuty ( 58 ), SetDuty ( 69 ), SetDuty ( 80 ) },	// 25C
    {SetDuty ( 30 ), SetDuty ( 30 ), SetDuty ( 30 ), SetDuty ( 36 ), SetDuty ( 47 ), SetDuty ( 58 ), SetDuty ( 70 ), SetDuty ( 81 ), SetDuty ( 91 ), SetDuty ( 100 ) },	// 35C
    {SetDuty ( 34 ), SetDuty ( 34 ), SetDuty ( 41 ), SetDuty ( 49 ), SetDuty ( 58 ), SetDuty ( 68 ), SetDuty ( 78 ), SetDuty ( 92 ), SetDuty ( 100 ), SetDuty ( 100 ) },	// 55C
};



//---------------Function declare--------------------------------------------------------------

void SetFanDuty ( WORD duty );

//-------------------------------------------------------------------------------------------

void CheckICAOV ( )
{
  WORD tempbuf;

  if ( IC1CON1bits.ICOV == 1 )
  {
      tempbuf = IC1BUF;
      tempbuf = IC1BUF;
      tempbuf = IC1BUF;
      tempbuf = IC1BUF;
  }
}

/*********************************************************************************************
------- Corresponding timer 2 is 200 us//Timer3 is 100us:10000count,60->600000
------- Input Capture moudule will capture the counter every 4th raising edge to ICxBuf
------- 1sec -> 5000 count of 200us, 60sec -> 300000 count of 200us
------- Since the time taken by every 4 raising edge represent the time spent of every 2 rpm
------- So that, we should divide the time of (Rpm_Capture2 - Rpm_Capture1) by 2 
------- for caculating how much time does it take every 1 rpm
 *********************************************************************************************/
void UpdateFanSpeedA ( )
{
  WORD Rpm_Capture1, Rpm_Capture2, ErrCount;
  WORD Fan_Speed;
  DWORD Fan_period;

  Rpm_Capture1 = IC1BUF;
  Rpm_Capture2 = IC1BUF;
  /*
 Tx1_Buf[1] = Rpm_Capture1;
 Tx1_Buf[2] = Rpm_Capture1>>8;
 Tx1_Buf[3] = Rpm_Capture2;
 Tx1_Buf[4] = Rpm_Capture2>>8;
   */
  if ( Rpm_Capture2 > Rpm_Capture1 )
  {
      ErrCount = Rpm_Capture2 - Rpm_Capture1;
  }
  else
  {
      ErrCount = 65535 - Rpm_Capture1 + Rpm_Capture2;
  }

  Fan_period = ErrCount << 1;

  Fan_Speed = ( WORD ) ( 1 / Fan_period );	//Timer 3 prescaler is 1:1
  gFan1.CurrentRpm = Fan_Speed;

  CheckICAOV ( );
}

//--------------------------- FanA Speed Update ---------------------------------------------

void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _IC1Interrupt ( )
{
//Capture1 = IC1BUF; // Read and save off first capture entry
//Capture2 = IC1BUF; // Read and save off second capture entry
  gFan1.Detected = TRUE;

  UpdateFanSpeedA ( );

  IFS0bits.IC1IF = 0;
}

//--------------------------- SetFanDuty  -------------------------------------------------

void SetFanDuty ( WORD duty )
{
#if FAN_PWM_INVERSED
  SDC4 = ( ( WORD ) FAN_PWM_PERIOD - duty );
#else
  PDC1 = duty;
#endif
}

//--------------------------- FanSoftAdjust  -------------------------------------------------
/*
void FanSoftAdjust ( )
{
  if ( PS.FanDutyCtrl )
  {
      PS.FanDutyCtrl = 0;
      if ( PDC1 < gFan1.TargetDuty )
      {
          PDC1 = PDC1 + 5;
      }
      else if ( PDC1 > gFan1.TargetDuty )
      {
          PDC1 = PDC1 - 1;
      }
      else
      {
          // Do nothing
      }
  }
  else
  {
      Protect.FanDutyCtrl.Flag = 1;
  }
}
*/
//----------------------------- LoadHysteresis ----- --------------------------------------
int8_t LoadHysteresis()
{
    WORD Adc_Io = aAdcAverage[MG_U8_ADC_INDEX_V1_CURR].u16q12Avg;
    static int8_t LoadCounter = 0;

    if ( Adc_Io < IOUT_LOAD_PERCENT ( 15 ) )                                                        //[davidchchen]20170707 Added Fan Issue modify
    {
        if ( ( Adc_Io > IOUT_LOAD_PERCENT ( 12 ) ) && ( LoadCounter == 1 ) )       //load_cnt = 0+1,  //[davidchchen]20170707 Added Fan Issue modify
            return  LoadCounter;
        LoadCounter = 0;
    }
    else if ( ( Adc_Io >= IOUT_LOAD_PERCENT ( 15 ) ) && ( Adc_Io < IOUT_LOAD_PERCENT ( 25 ) ) )     //[davidchchen]20170707 Added Fan Issue modify
    {
        if ( ( Adc_Io > IOUT_LOAD_PERCENT ( 22 ) ) && ( LoadCounter == 2 ) )       //load_cnt = 1+1,  //[davidchchen]20170707 Added Fan Issue modify
            return  LoadCounter;
        LoadCounter = 1;
    }
    else if ( ( Adc_Io >= IOUT_LOAD_PERCENT ( 25 ) ) && ( Adc_Io < IOUT_LOAD_PERCENT ( 35 ) ) )     //[davidchchen]20170707 Added Fan Issue modify
    {
        if ( ( Adc_Io > IOUT_LOAD_PERCENT ( 32 ) ) && ( LoadCounter == 3 ) )       //load_cnt = 2+1,  //[davidchchen]20170707 Added Fan Issue modify
            return  LoadCounter;
        LoadCounter = 2;
    }
    else if ( ( Adc_Io >= IOUT_LOAD_PERCENT ( 35 ) ) && ( Adc_Io < IOUT_LOAD_PERCENT ( 45 ) ) )     //[davidchchen]20170707 Added Fan Issue modify
    {
        if ( ( Adc_Io > IOUT_LOAD_PERCENT ( 42 ) ) && ( LoadCounter == 4 ) )       //load_cnt = 3+1,  //[davidchchen]20170707 Added Fan Issue modify
            return  LoadCounter;
        LoadCounter = 3;
    }
    else if ( ( Adc_Io >= IOUT_LOAD_PERCENT ( 45 ) ) && ( Adc_Io < IOUT_LOAD_PERCENT ( 55 ) ) )     //[davidchchen]20170707 Added Fan Issue modify
    {
        if ( ( Adc_Io > IOUT_LOAD_PERCENT ( 52 ) ) && ( LoadCounter == 5 ) )       //load_cnt = 4+1,  //[davidchchen]20170707 Added Fan Issue modify
            return  LoadCounter;
        LoadCounter = 4;
    }
    else if ( ( Adc_Io >= IOUT_LOAD_PERCENT ( 55 ) ) && ( Adc_Io < IOUT_LOAD_PERCENT ( 65 ) ) )     //[davidchchen]20170707 Added Fan Issue modify
    {
        if ( ( Adc_Io > IOUT_LOAD_PERCENT ( 62 ) ) && ( LoadCounter == 6 ) )       //load_cnt = 5+1,  //[davidchchen]20170707 Added Fan Issue modify
            return  LoadCounter;
        LoadCounter = 5;
    }
    else if ( ( Adc_Io >= IOUT_LOAD_PERCENT ( 65 ) ) && ( Adc_Io < IOUT_LOAD_PERCENT ( 75 ) ) )     //[davidchchen]20170707 Added Fan Issue modify
    {
        if ( ( Adc_Io > IOUT_LOAD_PERCENT ( 72 ) ) && ( LoadCounter == 7 ) )       //load_cnt = 6+1,  //[davidchchen]20170707 Added Fan Issue modify
            return  LoadCounter;
        LoadCounter = 6;
    }
    else if ( ( Adc_Io >= IOUT_LOAD_PERCENT ( 75 ) ) && ( Adc_Io < IOUT_LOAD_PERCENT ( 85 ) ) )     //[davidchchen]20170707 Added Fan Issue modify
    {
        if ( ( Adc_Io > IOUT_LOAD_PERCENT ( 82 ) ) && ( LoadCounter == 8 ) )       //load_cnt = 7+1,  //[davidchchen]20170707 Added Fan Issue modify
            return  LoadCounter;
        LoadCounter = 7;
    }
    else if ( ( Adc_Io >= IOUT_LOAD_PERCENT ( 85 ) ) && ( Adc_Io < IOUT_LOAD_PERCENT ( 95 ) ) )     //[davidchchen]20170707 Added Fan Issue modify
    {
        if ( ( Adc_Io > IOUT_LOAD_PERCENT ( 92 ) ) && ( LoadCounter == 9 ) )       //load_cnt = 8+1,  //[davidchchen]20170707 Added Fan Issue modify
            return  LoadCounter;
        LoadCounter = 8;
    }
    else if ( Adc_Io >= IOUT_LOAD_PERCENT ( 95 ) )
    {
      LoadCounter = 9;
    }

    return  LoadCounter;

}

//----------------------------- TempHysteresis ----- --------------------------------------
int8_t TempHysteresis()
{
    static int8_t TempCounter = 0;
    //Give a default temp_cnt
    WORD T_Inlet;  
    T_Inlet = aAdcAverage[MG_U8_ADC_INDEX_TEMP].u16q12Avg;
    
    if ( T_Inlet < 30 )
    {
        if ( ( T_Inlet > 27 ) && ( TempCounter == 1 ) )       //temp_cnt = 0+1,  
            return  TempCounter;
      TempCounter = 0;
    }
    else if ( T_Inlet >= 30 && T_Inlet < 40 )                                   
    {
        if ( ( T_Inlet > 37 ) && ( TempCounter == 2 ) )       //temp_cnt = 1+1,  
            return  TempCounter;
        TempCounter = 1;
    }
    else if ( T_Inlet >= 40 )
    {
        TempCounter = 2;
    }

    return  TempCounter;
}

//----------------------------- GetFanMinDuty ----- --------------------------------------
WORD GetFanMinDuty ( )
{
  WORD Adc_Io = aAdcAverage[MG_U8_ADC_INDEX_V1_CURR].u16q12Avg;        
  static int8_t load_cnt = 0;
  static int8_t temp_cnt = 0;
  static WORD minduty = SetDuty ( 75 );
  //WORD minduty = SetDuty ( 30 );  


    load_cnt = LoadHysteresis();
    temp_cnt = TempHysteresis();



    if ( Adc_Io <= MG_U16_V1_7A )
    {
      minduty = SetDuty ( 75 );
    }
    else if ( Adc_Io >= MG_U16_V1_10A )
    {
      minduty = FanDuty_Table[temp_cnt][load_cnt];
    }
   
  return minduty;

}

//----------------------------- Fan_MinimumDuty_Modify ----- ------------------------------

void Fan_MinimumDuty_Modify ( void )
{
  WORD minDuty;

  minDuty = GetFanMinDuty ( );

  gFan1.minDuty = ( minDuty > gFan1.OverridedDuty ) ? minDuty : gFan1.OverridedDuty;
}

//----------------------------- ConvertRatioToDuty  ------------------------------------

static WORD ConvertRatioToDuty ( int8_t ratio )
{
  WORD result;

  //mapping 0 - 100% to duty cycle 0 - 19000
  result = ( WORD ) ( ( DWORD ) FAN_PWM_PERIOD * ratio / 100 );

  return result;
}

//----------------------------- CalcFanTargetSpeed  ------------------------------------

void CalcFanTargetSpeed ( int8_t ratio )
{
  WORD minDuty;
  WORD overrideDuty;
  WORD target;

  minDuty = GetFanMinDuty ( );
  overrideDuty = ConvertRatioToDuty ( ratio );
  target = minDuty;

  if ( overrideDuty > minDuty )
  {
      //Fan Override
      target = overrideDuty;
      SetFanDuty ( overrideDuty );
      gFan1.TargetDuty = target;
  }
  else
  {
      SetFanDuty ( minDuty );
      gFan1.TargetDuty = target;
  }

  gFan1.OverridedDuty = overrideDuty;	//[Peter Chung] 20110118 modified
}

//--------------------------- Fan Duty Control By Load --------------------------------------

void UpdateFanDuty ( )
{
    WORD T_Sec,T_Pri,Adc_Io;
    Adc_Io = aAdcAverage[MG_U8_ADC_INDEX_V1_CURR].u16q12Avg;
    T_Sec = aAdcAverage[MG_U8_ADC_INDEX_TEMP].u16q12Avg;
    /* from pmbus
  if ( PS.StartCalibrate )
  {
      gFan1.TargetDuty = ( ( DWORD ) FAN_PWM_PERIOD * 50 ) / 100;
      SetFanDuty ( gFan1.TargetDuty );
      return;
  }
*/
#if 0
  if ( gFan1.OverridedDuty != 0 )
  {
      gFan1.TargetDuty = gFan1.OverridedDuty;
      SetFanDuty ( gFan1.TargetDuty );
  }
  else
#endif
  {
      if(FLG_B_NORMAL_STATE_FOR_FAN)
      {
          if(( T_Sec > FAN_ADJ_SEC_TEMP_H) || (T_Pri > FAN_ADJ_PRI_TEMP_H ))
          {			
              //increse fan duty if py or sy over temperature
            //  Protect.T_FanControl.Flag = 1;
            //  if ( PS.FanControl )
              {
                  gFan1.TargetDuty += 175;

                  if ( gFan1.TargetDuty >= FAN_PWM_PERIOD )
                  {
                      gFan1.TargetDuty = FAN_PWM_PERIOD;
                  }
                 // PS.FanControl = 0;
              }
          }
          else if ( T_Sec < FAN_ADJ_SEC_TEMP_L && T_Pri < FAN_ADJ_PRI_TEMP_L )
          {	
              //decrese fan duty if py and sy under temperature
             // Protect.T_FanControl.Flag = 1;
            //  if ( PS.FanControl )
              {
                  if ( gFan1.TargetDuty >= 100 )
                  {
                      gFan1.TargetDuty -= 100;
                  }
                  else
                  {
                      gFan1.TargetDuty = 0;
                  }
                  //min limit
                  Fan_MinimumDuty_Modify ( );

                  if ( gFan1.TargetDuty < gFan1.minDuty )
                  {
                      gFan1.TargetDuty = gFan1.minDuty;
                  }

                //  PS.FanControl = 0;
              }
          }
          else
          {
              //Protect.T_FanControl.Flag = 0;
              //Protect.T_FanControl.delay = 0;
              ////Fan_MinimumDuty_Modify();
              ////gFan1.TargetDuty = gFan1.minDuty;
              if ( Adc_Io <= MG_U16_V1_7A )
              {
                  gFan1.TargetDuty = SetDuty ( 75 );
                  if ( gFan1.OverridedDuty >= gFan1.TargetDuty )
                  {
                      gFan1.TargetDuty = gFan1.OverridedDuty;
                  }
                  SetFanDuty( gFan1.TargetDuty );
              }
          }
      }
      else if (FLG_B_STANDBY_STATE_FOR_FAN || FLG_B_LATCH_STATE_FOR_FAN)
      {
          gFan1.TargetDuty = ( ( DWORD ) FAN_PWM_PERIOD * 15 ) / 100;
      }
      else if ( FLG_B_FAULT_STATE_FOR_FAN )
      {
          if ( T_Sec > 60 || T_Pri > 75 )
          {
              gFan1.TargetDuty = FAN_PWM_PERIOD;
              SetFanDuty ( gFan1.TargetDuty );
          }
          else
          {
              gFan1.TargetDuty = FAN_PWM_DEFAULT_DUTY;
          }

          ////SetFanDuty(gFan1.TargetDuty);
      }

     // FanSoftAdjust ( );
  }
}

//--------------------------- DisableFan ----------------------------------------------------------

void DisableFan( )
{
 FLG_B_FAN_DISABLED = TRUE;  //for pmbus
 FAN_DIS();
}

//--------------------------- EnableFan ----------------------------------------------------------

void EnableFan( )
{
  FLG_B_FAN_DISABLED = FALSE;  //for pmbus
  FAN_EN();
}





