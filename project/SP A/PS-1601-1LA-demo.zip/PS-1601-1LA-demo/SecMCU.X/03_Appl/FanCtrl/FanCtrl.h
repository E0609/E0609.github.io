/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/* 
 * File:   
 * Author: 
 * Comments:
 * Revision history: 
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef XC_HEADER_TEMPLATE_H
#define	XC_HEADER_TEMPLATE_H

#include <xc.h> // include processor files - each processor file is guarded.  
#include "Define.h"
#include "McuClock.h"

#ifdef	__cplusplus
extern "C" {
#endif /* __cplusplus */

  
#define WORD uint32_t
#define DWORD uint64_t

#define FAN_PWM_INVERSED	       FALSE
#define FAN_MAX_RPM                10000

typedef struct _tFAN_CNTL {
    int16_t CurrentRpm;
    int16_t TargetDuty;
    int8_t  Detected;
    int16_t OverridedDuty;
    int16_t minDuty;
} tFAN_CNTL;    

#define MG_U16_V1_7A     Q12(7.0F/ U16Q12_I1_MAX)  
#define MG_U16_V1_10A    Q12(10.0F/U16Q12_I1_MAX) 

#define IOUT_FULL_LOAD	 Q12(50.0F/U16Q12_I1_MAX)
#define IOUT_LOAD_PERCENT(p) (WORD)((WORD)p * IOUT_FULL_LOAD / 100 )

#define GetDuty(rpm) ((DWORD)rpm * FAN_PWM_PERIOD) / FAN_MAX_RPM
#define SetDuty(percent) ((DWORD)percent * FAN_PWM_PERIOD) / 100

#define FAN_ADJ_SEC_TEMP_H 0x00   //need modify k
#define FAN_ADJ_PRI_TEMP_H 0x00   //need modify k
#define FAN_ADJ_SEC_TEMP_L 0xFF   //need modify
#define FAN_ADJ_PRI_TEMP_L 0xFF   //need modify
#define FAN_PWM_DEFAULT_DUTY ((DWORD)100 * FAN_PWM_PERIOD) / 100

extern volatile GLOBAL_U_U16BIT stFanStateFlag;
#define FLG_B_FAN_DETECTED              stFanStateFlag.Bits.f0 
#define FLG_B_NORMAL_STATE_FOR_FAN      stFanStateFlag.Bits.f1
#define FLG_B_STANDBY_STATE_FOR_FAN     stFanStateFlag.Bits.f2
#define FLG_B_LATCH_STATE_FOR_FAN       stFanStateFlag.Bits.f3
#define FLG_B_FAULT_STATE_FOR_FAN       stFanStateFlag.Bits.f4

#define FLG_B_FAN_DISABLED              stFanStateFlag.Bits.f5
   

    
#define FAN_ON_HOP            _LATA4             
#define FAN_ON_DIRECTION      _TRISA4 
#define FAN_IO_OUPUT_VAL      _RA4 
#define FAN_EN()        { FAN_ON_DIRECTION = 0; FAN_ON_HOP = 0; IOCON1bits.PENH = 1;PHASE1 = FAN_PWM_PERIOD;PDC1 = FAN_PWM_DEFAULT_DUTY;} //(PHASE2>>1) 50%;100%:PHASE2
#define FAN_DIS()       { FAN_ON_HOP = 0;  IOCON1bits.PENH = 1; FAN_ON_DIRECTION = 1;PDC1 = 0;}

#ifdef	__cplusplus
}
#endif /* __cplusplus */

#endif	/* XC_HEADER_TEMPLATE_H */

