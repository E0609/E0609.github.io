/* 
 * File:   PmbusCtrl.h
 * Author: 
 *
 * Created on 8 October, 2020, 9:31 AM
 */

#ifndef PMBUS_H
#define	PMBUS_H
#include "Global.h"
#include "i2c1.h"
#include "McuUart1.h"
#include "Protection.h"
#ifdef	__cplusplus
extern "C" {
#endif

    /*******************************************************************************
     * Global constants and macros
     ******************************************************************************/
#define SW_WDT_IS_ENABLED       (TRUE)
    /* Standard PMBus commands */
#define PMB_00_PAGE                     0x00
#define PMB_01_OPERATION                0x01
#define PMB_02_ON_OFF_CONFIG            0x02
#define PMB_03_CLEAR_FAULTS             0x03
#define PMB_05_PAGE_PLUS_WRITE          0x05
#define PMB_06_PAGE_PLUS_READ           0x06
#define PMB_10_WRITE_PROTECT            0x10
#define PMB_19_CAPABILITY               0x19
#define PMB_1A_QUERY                    0x1A
#define PMB_1B_SMBALERT_MASK            0x1B
    
#define PMB_20_VOUT_MODE                0x20
#define PMB_21_VOUT_COMMAND             0x21
#define PMB_22_VOUT_TRIM                0x22
#define PMB_23_VOUT_CAL_OFFSET          0x23
#define PMB_24_VOUT_MAX                 0x24
#define PMB_25_VOUT_MARGIN_HIGH         0x25
#define PMB_26_VOUT_MARGIN_LOW          0x26
#define PMB_27_VOUT_TRANSITION_RATE     0x27
#define PMB_28_VOUT_DROOP               0x28
#define PMB_29_VOUT_SCALE_LOOP          0x29
#define PMB_2A_VOUT_SCALE_MONITOR       0x2A  
    
#define PMB_30_COEFFICIENTS             0x30
#define PMB_31_POUT_MAX                 0x31   
#define PMB_32_MAX_DUTY                 0x32
#define PMB_33_FREQUENCY_SWITCH         0x33
#define PMB_35_VIN_ON                   0x35 
#define PMB_36_VIN_OFF                  0x36
#define PMB_37_INTERLEAVE               0x37    
#define PMB_38_IOUT_CAL_GAIN            0x38
#define PMB_39_IOUT_CAL_OFFSET          0x39    
#define PMB_3A_FAN_CONFIG_1_2           0x3A
#define PMB_3B_FAN_COMMAND_1            0x3B
#define PMB_3C_FAN_COMMAND_2            0x3C
#define PMB_3D_FAN_CONFIG_3_4           0x3D
#define PMB_3E_FAN_COMMAND_3            0x3E
#define PMB_3F_FAN_COMMAND_4            0x3F
    
#define PMB_40_VOUT_OV_FAULT_LIMIT      0x40
#define PMB_41_VOUT_OV_FAULT_RESPONSE   0x41
#define PMB_42_VOUT_OV_WARN_LIMIT       0x42
#define PMB_43_VOUT_UV_WARN_LIMIT       0x43
#define PMB_44_VOUT_UV_FAULT_LIMIT      0x44
#define PMB_45_VOUT_UV_FAULT_RESPONSE   0x45
#define PMB_46_IOUT_OC_FAULT_LIMIT      0x46
#define PMB_47_IOUT_OC_FAULT_RESPONSE   0x47
#define PMB_48_IOUT_OC_LV_FAULT_LIMIT   0x48
#define PMB_49_IOUT_OC_LV_FAULT_RESPONSE   0x49
#define PMB_4A_IOUT_OC_WARN_LIMIT       0x4A
#define PMB_4B_IOUT_UC_FAULT_LIMT       0x4B    
#define PMB_4C_IOUT_UC_FAULT_RESPONSE   0x4C  
    
#define PMB_4F_OT_FAULT_LIMIT           0x4F    
#define PMB_50_OT_FAULT_RESPONSE        0x50
#define PMB_51_OT_WARN_LIMIT            0x51
#define PMB_52_UT_WARN_LIMIT            0x52
#define PMB_53_UT_FAULT_LIMIT           0x53
#define PMB_54_UT_FAULT_RESPONSE        0X54
    
#define PMB_55_VIN_OV_FAULT_LIMIT       0x55
#define PMB_56_VIN_OV_FAULT_RESPONSE    0x56
#define PMB_57_VIN_OV_WARN_LIMIT        0x57
#define PMB_58_VIN_UV_WARN_LIMIT        0x58
#define PMB_59_VIN_UV_FAULT_LIMIT       0x59
#define PMB_5A_VIN_UV_FAULT_RESPONSE    0x5A    
#define PMB_5B_IIN_OC_FAULT_LIMIT       0x5B
#define PMB_5C_IIN_OC_FAULT_RESPONSE    0x5C    
#define PMB_5D_IIN_OC_WARN_LIMIT        0x5D
    
#define PMB_5E_POWER_GOOD_ON            0x5E
#define PMB_5F_POWER_GOOD_OFF           0x5F
#define PMB_60_TON_DELAY                0x60
#define PMB_61_TON_RISE                 0x61
#define PMB_62_TON_MAX_FAULT_LIMIT      0x62
#define PMB_63_TON_MAX_FAULT_RESPONSE      0x63    
#define PMB_64_TOFF_DELAY               0x64     
#define PMB_65_TOFF_FALL                0x65
#define PMB_66_TOFF_MAX_WARN_LIMIT      0x66
    
#define PMB_68_POUT_OP_FAULT_LIMIT      0x68
#define PMB_69_POUT_OP_FAULT_RESPONSE   0x69
#define PMB_6A_POUT_OP_WARN_LIMIT       0x6A
#define PMB_6B_PIN_OP_WARN_LIMIT        0x6B
#define PMB_72_TEST_INP_ORG_A           0x72
#define PMB_73_TEST_INP_ORG_B           0x73
#define PMB_74_TEST_OUT_ORG             0x74
#define PMB_78_STATUS_BYTE              0x78
#define PMB_79_STATUS_WORD              0x79
#define PMB_7A_STATUS_VOUT              0x7A
#define PMB_7B_STATUS_IOUT              0x7B
#define PMB_7C_STATUS_INPUT             0x7C
#define PMB_7D_STATUS_TEMPERATURE       0x7D
#define PMB_7E_STATUS_CML               0x7E
#define PMB_7F_STATUS_OTHER             0x7F
#define PMB_80_STATUS_MFR_SPECIFIC      0x80
#define PMB_81_STATUS_FANS_1_2          0x81
#define PMB_82_STATUS_FANS_3_4          0x82 
    
#define PMB_86_READ_EIN                 0x86
#define PMB_87_READ_EOUT                0x87    
#define PMB_88_READ_VIN_WORD            0x88
#define PMB_89_READ_IIN_WORD            0x89
#define PMB_8A_READ_VCAP_WORD           0x8A
#define PMB_8B_READ_VOUT_WORD           0x8B
#define PMB_8C_READ_IOUT_WORD           0x8C
#define PMB_8D_READ_TEMP1_WORD          0x8D
#define PMB_8E_READ_TEMP2_WORD          0x8E
#define PMB_8F_READ_TEMP3_WORD          0x8F
#define PMB_90_READ_FAN1_SPEED_WORD     0x90
#define PMB_91_READ_FAN2_SPEED_WORD     0x91
#define PMB_92_READ_FAN3_SPEED_WORD     0x92
#define PMB_93_READ_FAN4_SPEED_WORD     0x93
#define PMB_94_READ_DUTY_CYCLE_WORD     0x94
#define PMB_95_READ_FREQUENCY_WORD      0x95
#define PMB_96_READ_POUT_WORD           0x96
#define PMB_97_READ_PIN_WORD            0x97
#define PMB_98_PMBUS_REVISION_WORD      0x98
    
#define PMB_99_MFR_ID                   0x99
#define PMB_9A_MFR_MODEL                0x9A 
#define PMB_9B_MFR_REVISION             0x9B    
#define PMB_9C_MFR_LOCATION             0x9C
#define PMB_9D_MFR_DATE                 0x9D   
    
    
    
    
    
    /* PMBus command code */
#define PMB_01_OPERATION_ON             0x80
#define PMB_01_OPERATION_OFF            0x00

#define PMB_E1_EEPROM_ENABLE            0x01
#define PMB_E1_EEPROM_DISABLE           0x00

#define PMB_E6_WRITE_FLT_ENABLE         0x01
#define PMB_E6_WRITE_FLT_DISABLE        0x00

#define PMB_98_VERSION                  0x22
//
//#define PMB_DATA_00_AUX_MODE            0x00
/***********************************************************************************/
typedef struct _CMDS
{
  uint8_t Len ;
  uint16_t type ; //for Command Query
} tCMDS ;

#define PMB_RESERVED            0x00  
#define PMB_READ_BYTE           0x01  
#define PMB_READ_WORD           0x02  
#define PMB_BLOCK_READ          0x03   

#define PMB_SEND_BYTE           0x10  
#define PMB_WRITE_BYTE          0x20  
#define PMB_WRITE_WORD          0x30  
#define PMB_BLOCK_WRITE         0x40  
#define BLK_WR_BLK_RE_PC        0x100 

/***********************************************************************************/    
    /*******************************************************************************
     * PMBus Parameters Setting
     ******************************************************************************/

#define PMBUS_WR_PRT_80		          0x80     /* Disable all writes except to the WRITE_PROTECT command */
#define PMBUS_WR_PRT_40		          0x40     /* Disable all writes except to the WRITE_PROTECT, OPERATION and PAGE commands */
#define PMBUS_WR_PRT_20		          0x20     /* Disable all writes except to the WRITE_PROTECT, OPERATION, PAGE, ON_OFF_CONFIG and VOUT_COMMAND commands */
#define PMBUS_WR_PRT_00		          0x00     /* Enable writes to all commands. (Default) */
#define WRITE_PROTECT_DEFAULT		  PMBUS_WR_PRT_00



    /*******************************************************************************
     * Global data types (typedefs / structs / enums)
     ******************************************************************************/

    typedef union PMBUS_U_OPERATION_ {
        uint8 ALL;

        struct {
            uint8 Spare : 7; /* bit0 ~ bit 6 */
            uint8 OPERATION_ON : 1; /* bit7 */
        } Bits;
    } PMBUS_U_OPERATION;

    typedef union PMBUS_U_ON_OFF_CONFIG_ {
        uint8 ALL;

        struct {
            uint8 CTRL_ACT_CMD_OFF : 1; /* bit0 */
            uint8 POL_OF_CTRL_PIN : 1; /* bit1 */
            uint8 RES_TO_CTRL_PIN : 1; /* bit2 */
            uint8 RES_TO_OPER : 1; /* bit3 */
            uint8 RES_TO_OPER_AND_CTRL_PIN : 1; /* bit4 */
            uint8 RESERVED : 3; /* bit7 */
        } Bits;
    } PMBUS_U_ON_OFF_CONFIG;
    
    typedef union PMBUS_U_CAPABILITY_ {
        uint8 ALL;

        struct {
            uint8 RESERVED : 3; /* bit0 ~ bit3 */
            uint8 SMBALERT : 1; /* bit4 */
            uint8 MAX_BUS_SPEED : 2; /* bit5 ~ bit 6 */
            uint8 PKG_ERR_CHK : 1; /* bit7 */
        } Bits;
    } PMBUS_U_CAPABILITY;
    
    typedef union PMBUS_U_STATUS_WORD_ {
        uint16 ALL;

        struct {
            uint8 LB : 8;
            uint8 HB : 8;
        } Bytes;

        struct {
            uint8 NONE_OF_THE_ABOVE : 1; /* bit0 */
            uint8 CML : 1; /* bit1 */
            uint8 TEMPERATURE : 1; /* bit2 */
            uint8 VIN_UV_FAULT : 1; /* bit3 */
            uint8 IOUT_OC_FAULT : 1; /* bit4 */
            uint8 VOUT_OV_FAULT : 1; /* bit5 */
            uint8 V_OFF : 1; /* bit6 */
            uint8 BUSY : 1; /* bit7 */
            uint8 UNKNOWN : 1; /* bit8 */
            uint8 OTHER : 1; /* bit9 */
            uint8 FANS : 1; /* bitA */
            uint8 POWER_GOOD : 1; /* bitB */
            uint8 MFR_SPEC : 1; /* bitC */
            uint8 INPUT : 1; /* bitD */
            uint8 IOUT_POUT : 1; /* bitE */
            uint8 VOUT : 1; /* bitF */
        } Bits;
    } PMBUS_U_STATUS_WORD;

    typedef union PMBUS_U_STATUS_VOUT_ {
        uint8 ALL;

        struct {
            uint8 VOUT_TRACK_ERROR : 1; /* bit0 */
            uint8 TOFF_MAX_WARN : 1; /* bit1 */
            uint8 TON_MAX_FAULT : 1; /* bit2 */
            uint8 VOUT_MAX_WARN : 1; /* bit3 */
            uint8 VOUT_UV_FAULT : 1; /* bit4 */
            uint8 VOUT_UV_WARN : 1; /* bit5 */
            uint8 VOUT_OV_WARN : 1; /* bit6 */
            uint8 VOUT_OV_FAULT : 1; /* bit7 */
        } Bits;
    } PMBUS_U_STATUS_VOUT;

    typedef union PMBUS_U_STATUS_IOUT_ {
        uint8 ALL;

        struct {
            uint8 POUT_OP_WARN : 1; /* bit0 */
            uint8 POUT_OP_FAULT : 1; /* bit1 */
            uint8 POWER_LIMIT_MODE : 1; /* bit2 */
            uint8 CURR_SHARE_FAULT : 1; /* bit3 */
            uint8 IOUT_UC_FAULT : 1; /* bit4 */
            uint8 IOUT_OC_WARN : 1; /* bit5 */
            uint8 IOUT_OC_LV_FAULT : 1; /* bit6 */
            uint8 IOUT_OC_FAULT : 1; /* bit7 */
        } Bits;
    } PMBUS_U_STATUS_IOUT;

    typedef union PMBUS_U_STATUS_INPUT_ {
        uint8 ALL;

        struct {
            uint8 PIN_OP_WARN : 1; /* bit0 */
            uint8 IIN_OC_WARN : 1; /* bit1 */
            uint8 IIN_OC_FAULT : 1; /* bit2 */
            uint8 OFF_FOR_VIN_LOW : 1; /* bit3 */
            uint8 VIN_UV_FAULT : 1; /* bit4 */
            uint8 VIN_UV_WARN : 1; /* bit5 */
            uint8 VIN_OV_WARN : 1; /* bit6 */
            uint8 VIN_OV_FAULT : 1; /* bit7 */
        } Bits;
    } PMBUS_U_STATUS_INPUT;

    typedef union PMBUS_U_STATUS_TEMP_ {
        uint8 ALL;

        struct {
            uint8 RESERVED_B0 : 1; /* bit0 */
            uint8 RESERVED_B1 : 1; /* bit1 */
            uint8 RESERVED_B2 : 1; /* bit2 */
            uint8 RESERVED_B3 : 1; /* bit3 */
            uint8 UT_FAULT : 1; /* bit4 */
            uint8 UT_WARN : 1; /* bit5 */
            uint8 OT_WARN : 1; /* bit6 */
            uint8 OT_FAULT : 1; /* bit7 */
        } Bits;
    } PMBUS_U_STATUS_TEMP;

    typedef union PMBUS_U_STATUS_CML_ {
        uint8 ALL;

        struct {
            uint8 MEM_LOGIC_FAULT : 1; /* bit0 */
            uint8 COMMS_FAULT : 1; /* bit1 */
            uint8 RESERVED_B2 : 1; /* bit2 */
            uint8 CPU_FAULT : 1; /* bit3 */
            uint8 MEM_FAULT : 1; /* bit4 */
            uint8 PEC_FAULT : 1; /* bit5 */
            uint8 INVALID_DATA : 1; /* bit6 */
            uint8 INVALID_CMD : 1; /* bit7 */
        } Bits;
    } PMBUS_U_STATUS_CML;

    typedef union PMBUS_U_STATUS_OTHER_ {
        uint8 ALL;

        struct {
            uint8 INVALID_OR_TEST : 1; /* bit0 */
            uint8 OUT_OR_FAULT : 1; /* bit1 */
            uint8 INB_OR_FAULT : 1; /* bit2 */
            uint8 INA_OR_FAULT : 1; /* bit3 */
            uint8 INB_BRK_FAULT : 1; /* bit4 */
            uint8 INA_BRK_FAULT : 1; /* bit5 */
            uint8 RESERVED_B6 : 1; /* bit6 */
            uint8 RESERVED_B7 : 1; /* bit7 */
        } Bits;
    } PMBUS_U_STATUS_OTHER;

    typedef union PMBUS_U_STATUS_MFR_ {
        uint8 ALL;

        struct {
            uint8 V1_OFF_DUE_VSB : 1; /* bit0 */
            uint8 Spare : 7; /* bit1 ~ bit 7 */
        } Bits;
    } PMBUS_U_STATUS_MFR;

    typedef union PMBUS_U_STATUS_FAN_12_ {
        uint8 ALL;

        struct {
            uint8 AIR_FLOW_WARNING : 1; /* bit0 */
            uint8 AIR_FLOW_FAULT : 1; /* bit1 */
            uint8 FAN_2_SPD_OVERRIDE : 1; /* bit2 */
            uint8 FAN_1_SPD_OVERRIDE : 1; /* bit3 */
            uint8 FAN_2_WARNING : 1; /* bit4 */
            uint8 FAN_1_WARNING : 1; /* bit5 */
            uint8 FAN_2_FAULT : 1; /* bit6 */
            uint8 FAN_1_FAULT : 1; /* bit7 */
        } Bits;
    } PMBUS_U_STATUS_FAN_12;

    typedef union PMBUS_U_STATUS_FAN_34_ {
        uint8 ALL;

        struct {
            uint8 AIR_FLOW_WARNING : 1; /* bit0 */
            uint8 AIR_FLOW_FAULT : 1; /* bit1 */
            uint8 FAN_4_SPD_OVERRIDE : 1; /* bit2 */
            uint8 FAN_3_SPD_OVERRIDE : 1; /* bit3 */
            uint8 FAN_4_WARNING : 1; /* bit4 */
            uint8 FAN_3_WARNING : 1; /* bit5 */
            uint8 FAN_4_FAULT : 1; /* bit6 */
            uint8 FAN_3_FAULT : 1; /* bit7 */
        } Bits;
    } PMBUS_U_STATUS_FAN_34;

    typedef union PMBUS_U_UPD_STATUS0_ {
        uint16 ALL;

        struct {
            uint8 VIN_UPDTING : 1; /* bit0 */
            uint8 IIN_UPDTING : 1; /* bit1 */
            uint8 PIN_UPDTING : 1; /* bit2 */
            uint8 VOUT_V1_UPDTING : 1; /* bit3 */
            uint8 IOUT_V1_UPDTING : 1; /* bit4 */
            uint8 VOUT_VSB_UPDTING : 1; /* bit5 */
            uint8 IOUT_VSB_UPDTING : 1; /* bit6 */
            uint8 POUT_V1_UPDTING : 1; /* bit7 */
            uint8 TEMP_INLET_UPDTING : 1; /* bit8 */
            uint8 TEMP_OUTLET_UPDTING : 1; /* bit9 */
            uint8 TEMP_HTSK_UPDTING : 1; /* bitA */
            uint8 HOURS_USED_UPDTING : 1; /* bitB */
            uint8 FAN_SPD_1_UPDTING : 1; /* bitC */
            uint8 FAN_SPD_2_UPDTING : 1; /* bitD */
            uint8 FAN_SPD_3_UPDTING : 1; /* bitE */
            uint8 FAN_SPD_4_UPDTING : 1; /* bitF */
        } Bits;
    } PMBUS_U_UPD_STATUS0;

    typedef union PMBUS_U_UPD_STATUS1_ {
        uint16 ALL;

        struct {
            uint8 EIN_UPDTING : 1; /* bit0 */
            uint8 EOUT_UPDTING : 1; /* bit1 */
            uint8 STATUS_78_82_UPDTING : 1; /* bit2 */
            uint8 POUT_VSB_UPDTING : 1; /* bit3 */
            uint8 FALT_UPDT_V1_VI_OUT : 1; /* bit4 */
            uint8 FALT_UPDT_VSB_VI_OUT : 1; /* bit5 */
            uint8 VCAP_UPDTING : 1; /* bit1 */
            uint8 HOURS_USED_PRESENT_UPDTING : 1; /* bit1 */
            uint8 RESERVED : 8; /* bit1 */
        } Bits;
    } PMBUS_U_UPD_STATUS1;

    typedef union PMBUS_U_SYS_STATUS0_ {
        uint16 ALL;

        struct {
            uint8 MFR_INFO_UPDATE : 1; /* bit0 */
            uint8 QUERY_REQUEST : 1; /* bit1 */
            uint8 PAGE_PLUS_WRITE : 1; /* bit2 */
            uint8 PAGE_PLUS_READ : 1; /* bit3 */
            uint8 PAGE_AND_WRITE : 1; /* bit4 */
            uint8 PAGE_AND_READ : 1; /* bit5 */
            uint8 CEFCT_READ_EIN_EOUT : 1; /* bit6 */
            uint8 INVALID_CMD : 1; /* bit7 */
            uint8 INVALID_DATA : 1; /* bit8 */
            uint8 UNLOCK_DEBUG : 1; /* bit9 */
            uint8 AUX_MODE : 1; /* bitA */
            uint8 OUT_ORING_TEST_ON : 1; /* bitB */
            uint8 FAN_1_OVERRIDE : 1; /* bitC */
            uint8 FAN_2_OVERRIDE : 1; /* bitD */
            uint8 FAN_3_OVERRIDE : 1; /* bitE */
            uint8 FAN_4_OVERRIDE : 1; /* bitF */
        } Bits;
    } PMBUS_U_SYS_STATUS0;

    typedef union PMBUS_U_SYS_STATUS1_ {
        uint16 ALL;

        struct {
            uint8 EEPROM_ENABLE : 1; /* bit0 */
            uint8 CORRECT_BOOT_KEY : 1; /* bit1 */
            uint8 BOOT_MODE_JUMP : 1; /* bit2 */
            uint8 BOOT_RESET_FLAG : 1; /* bit3 */
            uint8 I_SHARE_CALI_DONE : 1; /* bit4 */
            uint8 I_SHARE_CALI_P1 : 1; /* bit5 */
            uint8 I_SHARE_CALI_P2 : 1; /* bit6 */
            uint8 I_SHARE_CALI_P3 : 1; /* bit7 */
            uint8 I_SHARE_CALI_P4 : 1; /* bit8 */
            uint8 SMB_MASK_REQUEST : 1; /* bit9 */
            uint8 HEALTH_CHECK_ON : 1; /* bit10 */
            uint8 RESERVED : 5; /* bita ~ f */
        } Bits;

        struct {
            uint16 LB : 8;
            uint16 HB : 8;
        } Bytes;
    } PMBUS_U_SYS_STATUS1;

    typedef union PMBUS_S_WD_CTRL_PORT_ {
        uint8 ALL;

        struct {
            uint8 BIT_0 : 1; /* bit0 */
            uint8 RESERVED : 7; /* bit1 */
        } Bits;
    } PMBUS_S_WD_CTRL_PORT;
    
    typedef struct PMBUS_S_DATA_ {
        BYTE_VAL u8AC_Themal_SD_Cnt;
        BYTE_VAL u8OC_General_SD_Cnt;
        BYTE_VAL u8FAN_VoOV_SD_Cnt;
        BYTE_VAL u8Vin_Themal_WN_Cnt;
        BYTE_VAL u8OC_FAN_WN_Cnt;
        BYTE_VAL u8Cold_Redundancy_Config;
        PMBUS_S_WD_CTRL_PORT PMBUS_sWDCtrlPort1;
        PMBUS_S_WD_CTRL_PORT PMBUS_sWDCtrlPort2;
        WORD_VAL u16Vin_Report;
        WORD_VAL u16Iin_Report;
        WORD_VAL u16Pin_Report;
        WORD_VAL u16Vbulk_Report;
        WORD_VAL u16Vout_V1_Report;
        WORD_VAL u16Iout_V1_Report;
        WORD_VAL u16Pout_V1_Report;
        WORD_VAL u16Ishare_V1_Report;
        WORD_VAL u16Temperatue_1_Report;
        WORD_VAL u16Temperatue_2_Report;
        WORD_VAL u16Temperatue_3_Report;
        WORD_VAL u16Temperatue_4_Report;
        WORD_VAL u16FanSpeed_1_Report;
        WORD_VAL u16FanSpeed_2_Report;
        WORD_VAL u16FanSpeed_3_Report;
        WORD_VAL u16FanSpeed_4_Report;
        WORD_VAL u16FanCmd_1_Report;
        WORD_VAL u16FanCmd_2_Report;
        WORD_VAL u16FanCmd_3_Report;
        WORD_VAL u16FanCmd_4_Report;
        WORD_VAL u16WDReset_Counter;
        WORD_VAL u16WD_Timer;
        WORD_VAL u16Num_Of_AC_Cycles;
        WORD_VAL u16Num_Of_PSON_Cycles;
        DWORD_VAL u32HoursUsed_Report;
        DWORD_VAL u32HoursUsedTotal;
        DWORD_VAL u32HoursUsedPresent;
        DWORD_VAL u32DataCopy;
        DWORD_VAL u32Real_Time_BlackBox;
        uint8 u8System_BlackBox[40];
    } PMBUS_ST_DATA;

    typedef struct PMBUS_S_STATUS_ {
        PMBUS_U_STATUS_WORD u16StatusWordP0;
        PMBUS_U_STATUS_VOUT u8StatusVoutP0;
        PMBUS_U_STATUS_IOUT u8StatusIoutP0;
        PMBUS_U_STATUS_INPUT u8StatusInputP0;
        PMBUS_U_STATUS_TEMP u8StatusTempP0;
        PMBUS_U_STATUS_CML u8StatusCmlP0;
        PMBUS_U_STATUS_OTHER u8StatusOtherP0;
        PMBUS_U_STATUS_MFR u8StatusMfrP0;
        PMBUS_U_STATUS_FAN_12 u8StatusFan12P0;
        PMBUS_U_STATUS_FAN_34 u8StatusFan34P0;
    } PMBUS_ST_STATUS;

    typedef struct PMBUS_S_SMB_MASK_ {
        uint8 u8Pmb7AhVoutP0;
        uint8 u8Pmb7BhIoutP0;
        uint8 u8Pmb7ChInputP0;
        uint8 u8Pmb7DhTempP0;
        uint8 u8Pmb7EhCMLP0;
        uint8 u8Pmb7FhOtherP0;
        uint8 u8Pmb80hMfrP0;
        uint8 u8Pmb81hFan12P0;
    } PMBUS_S_SMB_MASK;

    typedef union PMBUS_U_TRANS_TYPE_ {
        uint16 ALL;

        struct {
            uint8 Reserved : 1; /* bit0 */
            uint8 BYTE_READ : 1; /* bit1 */
            uint8 WORD_READ : 1; /* bit2 */
            uint8 BLOCK_READ_EN : 1; /* bit3 */
            uint8 BYTE_SEND : 1; /* bit4 */
            uint8 BYTE_WRITE : 1; /* bit5 */
            uint8 WORD_WRITE : 1; /* bit6 */
            uint8 BLOCK_WRITE_EN : 1; /* bit7 */
            uint8 WR_BLK_RD_BLK_PRT : 1; /*bit8*/
            uint8 MFR_DEFINED : 1; /*bit9*/
            uint8 EXT_CMD : 1; /*bit10*/
        } Bits;
    } PMBUS_U_TRANS_TYPE;

    
    typedef struct PMBUS_S_EIN_EOUT_ {
        uint32 u32AccumulatedPower;
        uint16 u16AccumulatedPowerReport;
        uint32 u32SampleCount;
        uint8 u8RollOverCount;
    } PMBUS_ST_EIN_EOUT;

    typedef struct _PMBUS_CMDS
    {
      BYTE_VAL PAGE; 
      PMBUS_U_OPERATION OPERATION ; 
      PMBUS_U_ON_OFF_CONFIG ON_OFF_CONFIG;
      BYTE_VAL CLEAR_FAULTS;	
      BYTE_VAL PHASE;                 //,0x00-0xFF
      BYTE PAGE_PLUS_WRITE[5] ; 
      BYTE PAGE_PLUS_READ[4] ; 
      BYTE_VAL WRITE_PROTECT; //0x10
      BYTE_VAL STORE_DEFAULT_ALL;
      BYTE_VAL RESTORE_DEFAULT_ALL;
      BYTE_VAL STORE_DEFAULT_CODE; //0x13
      BYTE_VAL RESTORE_DEFAULT_CODE; //0x14
      BYTE_VAL STORE_USER_ALL;
      BYTE_VAL RESTORE_USER_ALL;
      BYTE_VAL STORE_USER_CODE; //0x17
      BYTE_VAL RESTORE_USER_CODE; //0x18

      PMBUS_U_CAPABILITY CAPABILITY; //0X19
      BYTE_VAL QUERY; //0X1A
      WORD_VAL SMBALERT_MASK; //0X1B

      BYTE_VAL VOUT_MODE; //0x20
      WORD_VAL VOUT_COMMAND; //0X21
      WORD_VAL VOUT_TRIM; //0X22
      WORD_VAL VOUT_CAL_OFFSET; //0x23
      WORD_VAL VOUT_MAX; //0X24
      WORD_VAL VOUT_MARGIN_HIGH; //0x25
      WORD_VAL VOUT_MARGIN_LOW; //0x26
      WORD_VAL VOUT_TRANSITION_RATE; //0x27
      WORD_VAL VOUT_DROOP;//0x28
      WORD_VAL VOUT_SCALE_LOOP; //0x29
      WORD_VAL VOUT_SCALE_MONITOR; //0x2A
      BYTE COEFFICIENT[5] ; //0X30
      WORD_VAL POUT_MAX; //0x31
      WORD_VAL MAX_DUTY;//0x32
      WORD_VAL FREQUENCY_SWITCH; //0x33
      WORD_VAL VIN_ON;//0x35
      WORD_VAL VIN_OFF; //0x36
      WORD_VAL INTERLEAVE; //0x37
      WORD_VAL IOUT_CAL_GAIN; //0x38
      WORD_VAL IOUT_CAL_OFFSET; //0x39
      BYTE_VAL FAN_CONFIG_1_2; //0X3A
      WORD_VAL FAN_COMMAND_1; //0X3B
      WORD_VAL FAN_COMMAND_2; //0X3C
      BYTE_VAL FAN_CONFIG_3_4; //0X3D
      WORD_VAL FAN_COMMAND_3; //0X3E
      WORD_VAL FAN_COMMAND_4; //0X3F
      WORD_VAL VOUT_OV_FAULT_LIMIT; //0X40
      BYTE_VAL VOUT_OV_FAULT_RESPONSE; //0x41
      WORD_VAL VOUT_OV_WARN_LIMIT; //0x42
      WORD_VAL VOUT_UV_WARN_LIMIT; //0X43
      WORD_VAL VOUT_UV_FAULT_LIMIT; //0X44
      BYTE_VAL VOUT_UV_FAULT_RESPONSE; //0x45
      WORD_VAL IOUT_OC_FAULT_LIMIT; //0X46
      BYTE_VAL IOUT_OC_FAULT_RESPONSE; //0x47
      WORD_VAL IOUT_OC_LV_FAULT_LIMIT; //0X48
      BYTE_VAL IOUT_OC_LV_FAULT_RESPONSE; //0X49
      WORD_VAL IOUT_OC_WARN_LIMIT; //0X4A
      WORD_VAL IOUT_UC_FAULT_LIMIT; //0x4B
      BYTE_VAL IOUT_UC_FAULT_RESPONSE; //0x4C
      WORD_VAL OT_FAULT_LIMIT; //0x4F
      BYTE_VAL OT_FAULT_RESPONSE; //0x50
      WORD_VAL OT_WARN_LIMIT; //0x51  
      WORD_VAL UT_WARN_LIMIT; //0x52
      WORD_VAL UT_FAULT_LIMIT; //0x53
      BYTE_VAL UT_FAULT_RESPONSE; //0x54
      WORD_VAL VIN_OV_FAULT_LIMIT; //0x55
      BYTE_VAL VIN_OV_FAULT_RESPONSE; //0x56
      WORD_VAL VIN_OV_WARN_LIMIT; //0x57
      WORD_VAL VIN_UV_WARN_LIMIT; //0x58
      WORD_VAL VIN_UV_FAULT_LIMIT; //0x59
      BYTE_VAL VIN_UV_FAULT_RESPONSE; //0x5A
      WORD_VAL IIN_OC_FAULT_LIMIT; //0x5B
      BYTE_VAL IIN_OC_FAULT_RESPONSE; //0x5C
      WORD_VAL IIN_OC_WARN_LIMIT; //0X5D
      WORD_VAL POWER_GOOD_ON; //0x5E
      WORD_VAL POWER_GOOD_OFF; //0x5F
      WORD_VAL TON_DELAY; //0x60
      WORD_VAL TON_RISE; //0x61 
      WORD_VAL TON_MAX_FAULT_LIMIT; //0x62
      BYTE_VAL TON_MAX_FAULT_RESPONSE; //0x63
      WORD_VAL TOFF_DELAY; //0x64
      WORD_VAL TOFF_FALL; //0x65
      WORD_VAL TOFF_MAX_WARN_LIMIT; //0x66
      WORD_VAL POUT_OP_FAULT_LIMIT; //0x68
      BYTE_VAL POUT_OP_FAULT_RESPONSE; //0x69
      WORD_VAL POUT_OP_WARN_LIMIT ; //0X6A
      WORD_VAL PIN_OP_WARN_LIMIT ; //0X6B

      PMBUS_U_STATUS_WORD STATUS_WORD; //0X78 0X79
      PMBUS_U_STATUS_VOUT STATUS_VOUT ; //0X7A
      PMBUS_U_STATUS_IOUT STATUS_IOUT ; //0X7B
      PMBUS_U_STATUS_INPUT STATUS_INPUT ; //0X7C
      PMBUS_U_STATUS_TEMP STATUS_TEMPERATURE ; //0X7D
      PMBUS_U_STATUS_CML STATUS_CML; //0X7E
      PMBUS_U_STATUS_OTHER STATUS_OTHER;	//0X7F
      PMBUS_U_STATUS_MFR STATUS_MFR_SPECIFIC; //0X80  // CIPS
      PMBUS_U_STATUS_FAN_12 STATUS_FAN_1_2; //0X81
      PMBUS_U_STATUS_FAN_34 STATUS_FAN_3_4; //0x82
      PMBUS_ST_EIN_EOUT READ_EIN[5]; //0X86
      PMBUS_ST_EIN_EOUT READ_EOUT[5]; //0X87 

      WORD_VAL READ_VIN; //0X88
      WORD_VAL READ_IIN; //0X89
      WORD_VAL READ_VCAP; //0X8A 
      WORD_VAL READ_VOUT; //0X8B
      WORD_VAL READ_IOUT; //0X8C
      WORD_VAL READ_TEMPERATURE_1; //0X8D
      WORD_VAL READ_TEMPERATURE_2; //0X8E
      WORD_VAL READ_TEMPERATURE_3; //0X8F   
      WORD_VAL READ_FAN_SPEED_1; //0X90
      WORD_VAL READ_FAN_SPEED_2; //0X91
      WORD_VAL READ_FAN_SPEED_3; //0X92
      WORD_VAL READ_FAN_SPEED_4; //0X93
      WORD_VAL READ_DUTY_CYCLE; //0x94
      WORD_VAL READ_FREQUENCY; //0x95
      WORD_VAL READ_POUT; //0X96
      WORD_VAL READ_PIN; //0x97 
      BYTE_VAL PMBUS_REVISION; //0X98

      WORD_VAL MFR_VIN_MIN; //0XA0
      WORD_VAL MFR_VIN_MAX; //0XA1
      WORD_VAL MFR_IIN_MAX; //0XA2
      WORD_VAL MFR_PIN_MAX; //0XA3
      WORD_VAL MFR_VOUT_MIN; //0XA4
      WORD_VAL MFR_VOUT_MAX; //0XA5
      WORD_VAL MFR_IOUT_MAX; //0XA6
      WORD_VAL MFR_POUT_MAX; //0XA7
      WORD_VAL MFR_TAMBIENT_MAX; //0XA8
      WORD_VAL MFR_TAMBIENT_MIN; //0XA9
      BYTE MFR_EFFICIENCY_LL[14]; //0xAA
      BYTE MFR_EFFICIENCY_HL[14]; //0xAB
      BYTE_VAL MFR_PIN_ACCURACY; //0xAC 
      WORD_VAL MFR_MAX_TEMP_1; //0xC0
      WORD_VAL MFR_MAX_TEMP_2; //0xC1
      WORD_VAL MFR_MAX_TEMP_3; //0xC2
    } tPMBUS_CMDS ;


    #define FLG_PMBUS_PSON          stPmbusStateFlag.Bits.f0  /* 1 = Oring inv Cmd */

    /*******************************************************************************
     * Global data
     ******************************************************************************/
    extern volatile GLOBAL_U_U16BIT stPmbusStateFlag;
    extern PMBUS_U_OPERATION PMBUS_uOperation;
    extern PMBUS_U_ON_OFF_CONFIG PMBUS_uOnOffConfig;
    extern PMBUS_U_SYS_STATUS0 PMBUS_uSysStatu0;
    extern PMBUS_U_SYS_STATUS1 PMBUS_uSysStatu1;
    extern PMBUS_U_UPD_STATUS0 PMBUS_uDataUpdStatus;
    extern PMBUS_U_UPD_STATUS1 PMBUS_uDataUpdStatus1;
    extern PMBUS_ST_DATA PMBUS_stData;
    extern PMBUS_ST_STATUS PMBUS_stStatus;
    extern WORD_VAL PMBUS_u16Vin_LinearTemp;
    extern WORD_VAL PMBUS_u16Iin_LinearTemp;
    extern WORD_VAL PMBUS_u16Vout_LinearTemp;
    extern WORD_VAL PMBUS_u16Iout_LinearTemp;
    extern PMBUS_U_TRANS_TYPE PMBUS_u8TransType;
    extern PMBUS_ST_EIN_EOUT PMBUS_stEin;
    extern PMBUS_ST_EIN_EOUT PMBUS_stEinOld;
    extern PMBUS_ST_EIN_EOUT PMBUS_stEout;
    extern PMBUS_ST_EIN_EOUT PMBUS_stEoutOld;
    extern tPMBUS_CMDS gPmbusCmd;
    extern tCMDS gCmd[256];
    /*******************************************************************************
     * Global function prototypes
     ******************************************************************************/

    /*******************************************************************************
     * \brief         Initialize PMBus data
     *
     * \param[in]     -
     * \param[in,out] -
     * \param[out]    -
     *
     * \return        -
     *
     *******************************************************************************/
    extern void PMBUS_vPmbusDataInit(void);


    /*******************************************************************************
     * \brief         Copy sensor data to PMBus sensor registers
     *
     * \param[in]     -
     * \param[in,out] -
     * \param[out]    -
     *
     * \return        -
     *
     *******************************************************************************/
    extern void PMBUS_vCopyStatusData(void);

    /*******************************************************************************
     * \brief         Check the specific bit of the input data
     *
     * \param[in]     u16Data, u8BitNum
     * \param[in,out] -
     * \param[out]    - 
     *
     * \return        - TRUE or FALSE
     *
     *******************************************************************************/
    extern boolean PMBUS_vCheckBit(uint16 u16Data, uint8 u8BitNum);

    /*******************************************************************************
     * \brief         Copy debug data to PMBus debug registers
     *
     * \param[in]     -
     * \param[in,out] -
     * \param[out]    -
     *
     * \return        -
     *
     *******************************************************************************/
    extern void PMBUS_vCopyDebugData(void);

    /*******************************************************************************
     * \brief          Clear fault or warning status
     *                  ucPage: page0, 1, FF
     *                  ucMode: 1: clear All, and can restart ( OPERATION )
     *                          2: clear All except STA_MFR, and can restart ( PS_ON, PS_KILL )
     *                          3: clear All, and can't restart ( CLEAR_FAULT, CLEAR_BITS )
     *                          4: clear All except STA_MFR, and can't restart
     *
     * \param[in]     -ucPage, ucMode
     * \param[in,out] -
     * \param[out]    -
     *
     * \return        -
     *
     *******************************************************************************/
    extern void PMBUS_vClearAllPageFault(void);

    /*******************************************************************************
     * Function:        PMBUS_SendData
     *
     * Parameters:      -
     * Returned value:  -
     *
     * Description:     PSU -> SYS
     *
     ******************************************************************************/
    extern void PMBUS_vSendData(uint8 u8I2cCommand);
    extern void vPMBus_HandleData(uint8 u8I2cCommand);




#ifdef	__cplusplus
}
#endif

#endif	/* PMBUS_H */

