/*******************************************************************************
 * \file    PmbusCtrl.c
 * \brief   Pmbus communication with system
 *
 * \section AUTHOR
 *    1. 
 *
 * \section SVN
 *  $Date$
 *  $Author$
 *  $Revision$
 *
 * \section LICENSE
 * Copyright (c) 
 * All rights reserved.
 *******************************************************************************/

/*******************************************************************************
 * Included header
 * test merge from branch to trunk--branch
 ******************************************************************************/

#include "Global.h"
#include "xc.h"
#include "Pmbus.h"
//#include "Crc.h"
#include "i2c1.h"
#include "McuUart1.h"
#include "Protection.h"

/*******************************************************************************
 * Local data types (private typedefs / structs / enums)
 ******************************************************************************/

/* Page Number */
#define MG_PAGE_00                     ((uint8)0)
#define MG_PAGE_01                     ((uint8)1)
#define MG_PAGE_FF                     ((uint8)0xFF)
#define MG_PAGE_MAX                    MG_PAGE_01

/* Operation Value */
#define MG_OPERATION_ON_80             (0x00U)      //(0x80U)
#define MG_ON_OFF_CONFIG_1D            (0x1DU)
#define MG_OPERATION_OFF_00            (0x00U)
#define MG_FRU_EEP_DEFAULT_DATA        (0x9AU)
#define MG_PHASE_DEFAULT               (0xFFU)

/* Constant Data Definition */
//#define MG_UNLOCK_DEBUG_KEY_UL         (0x4C55)
//#define MG_LOCK_DEBUG_KEY_AAAA         (0xAAAA)

/* Delay Setting */
#define MG_STA_PWR_UP_UPD_DLY          ((uint8)300U)     /* When power up, to delay 4 seconds */
#define MG_STA_CLR_FLT_UPD_DLY         ((uint8)10U)      /* When clear fault, to delay 1 seconds */
#define MG_SMBALERT_SET_DLY            ((uint8)5U)


/*******************************************************************************
 * Local data (private to module)
 ******************************************************************************/
static uint8 PMBUS_mg_u8Page;
static uint8 PMBUS_mg_u8WriteProtect = PMBUS_WR_PRT_80;
static uint8 PMBUS_mg_u8EepProtect;
static uint16 PMBUS_mg_u16StatusUpdDly = MG_STA_PWR_UP_UPD_DLY;
static PMBUS_S_SMB_MASK PMBUS_mg_sSmbMask;
volatile GLOBAL_U_U16BIT stPmbusStateFlag;
/*******************************************************************************
 * Local function prototypes (private to module)
 ******************************************************************************/
static void mg_vClearPageFault(void);
static void mg_vClearPage00Fault(void);
static void mg_vClearPageAllFault(void);

/*******************************************************************************
 * Global data (public to other modules)
 ******************************************************************************/

PMBUS_U_OPERATION PMBUS_uOperation;
PMBUS_U_ON_OFF_CONFIG PMBUS_uOnOffConfig;
PMBUS_U_SYS_STATUS0 PMBUS_uSysStatu0;
PMBUS_U_SYS_STATUS1 PMBUS_uSysStatu1;
PMBUS_U_UPD_STATUS0 PMBUS_uDataUpdStatus;
PMBUS_U_UPD_STATUS1 PMBUS_uDataUpdStatus1;
PMBUS_ST_DATA PMBUS_stData;
PMBUS_ST_STATUS PMBUS_stStatus;
WORD_VAL PMBUS_u16Vin_LinearTemp;
WORD_VAL PMBUS_u16Iin_LinearTemp;
WORD_VAL PMBUS_u16Vout_LinearTemp;
WORD_VAL PMBUS_u16Iout_LinearTemp;
PMBUS_U_TRANS_TYPE PMBUS_u8TransType;
PMBUS_ST_EIN_EOUT PMBUS_stEin;
PMBUS_ST_EIN_EOUT PMBUS_stEinOld;
PMBUS_ST_EIN_EOUT PMBUS_stEout;
PMBUS_ST_EIN_EOUT PMBUS_stEoutOld;

 
tPMBUS_CMDS gPmbusCmd;
tCMDS gCmd[256] =
{
    // writeTransaction|readTransaction,       // Command name, opcode
    {sizeof(gPmbusCmd.PAGE),(PMB_WRITE_BYTE | PMB_READ_BYTE)},                  // PAGE,00h
    {sizeof(gPmbusCmd.OPERATION),(PMB_WRITE_BYTE | PMB_READ_BYTE)},             // OPERATION,01h
    {sizeof(gPmbusCmd.ON_OFF_CONFIG),PMB_WRITE_BYTE | PMB_READ_BYTE},           // ON_OFF_CONFIG,02h
    {sizeof(gPmbusCmd.CLEAR_FAULTS),PMB_SEND_BYTE},                             // CLEAR_FAULTS,03h
    {sizeof(gPmbusCmd.PHASE),(PMB_WRITE_BYTE | PMB_READ_BYTE)},                 // PHASE,04h
    {sizeof(gPmbusCmd.PAGE_PLUS_WRITE),PMB_BLOCK_WRITE},                        // PAGE_PLUS_WRITE,05h
    {sizeof(gPmbusCmd.PAGE_PLUS_READ),BLK_WR_BLK_RE_PC},                        // PAGE_PLUS_READ,06h
    {0,PMB_RESERVED},                                                           // RESERVED,07h
    {0,PMB_RESERVED},                                                           // RESERVED,08h
    {0,PMB_RESERVED},                                                           // RESERVED,09h
    {0,PMB_RESERVED},                                                           // RESERVED,0Ah
    {0,PMB_RESERVED},                                                           // RESERVED,0Bh
    {0,PMB_RESERVED},                                                           // RESERVED,0Ch
    {0,PMB_RESERVED},                                                           // RESERVED,0Dh
    {0,PMB_RESERVED},                                                           // RESERVED,0Eh
    {0,PMB_RESERVED},                                                           // RESERVED,0Fh
    {sizeof(gPmbusCmd.WRITE_PROTECT),(PMB_WRITE_BYTE | PMB_READ_BYTE)},         // WRITE_PROTECT,10h
    {sizeof(gPmbusCmd.STORE_DEFAULT_ALL),PMB_SEND_BYTE},                        // STORE_DEFAULT_ALL,11h
    {sizeof(gPmbusCmd.RESTORE_DEFAULT_ALL),PMB_SEND_BYTE},                      // RESTORE_DEFAULT_ALL,12h
    {sizeof(gPmbusCmd.STORE_DEFAULT_CODE),PMB_WRITE_BYTE},                      // STORE_DEFAULT_CODE,13h
    {sizeof(gPmbusCmd.RESTORE_DEFAULT_CODE),PMB_WRITE_BYTE},                    // RESTORE_DEFAULT_CODE,14h
    {sizeof(gPmbusCmd.STORE_USER_ALL),PMB_SEND_BYTE},                           // STORE_USER_ALL,15h
    {sizeof(gPmbusCmd.RESTORE_USER_ALL),PMB_SEND_BYTE},                         // RESTORE_USER_ALL,16h
    {sizeof(gPmbusCmd.STORE_USER_CODE),PMB_WRITE_BYTE},                         // STORE_USER_CODE,17h
    {sizeof(gPmbusCmd.RESTORE_USER_CODE),PMB_WRITE_BYTE},                       // RESTORE_USER_CODE,18h
    {sizeof(gPmbusCmd.CAPABILITY),PMB_READ_BYTE},                               // CAPABILITY,19h
    {sizeof(gPmbusCmd.QUERY),BLK_WR_BLK_RE_PC},                                 // QUERY,1Ah
    {sizeof(gPmbusCmd.SMBALERT_MASK),(PMB_WRITE_BYTE | BLK_WR_BLK_RE_PC)},      // SMBALERT_MASK,1Bh
    {0,PMB_RESERVED},                                                           // RESERVED,1Ch
    {0,PMB_RESERVED},                                                           // RESERVED,1Dh
    {0,PMB_RESERVED},                                                           // RESERVED,1Eh
    {0,PMB_RESERVED},                                                           // RESERVED,1Fh
    {sizeof(gPmbusCmd.VOUT_MODE),(PMB_WRITE_BYTE | PMB_READ_BYTE)},             // VOUT_MODE,20h
    {sizeof(gPmbusCmd.VOUT_COMMAND),(PMB_WRITE_WORD | PMB_READ_WORD)},          // VOUT_COMMAND,21h
    {sizeof(gPmbusCmd.VOUT_TRIM),(PMB_WRITE_WORD | PMB_READ_WORD)},             // VOUT_TRIM,22h
    {sizeof(gPmbusCmd.VOUT_CAL_OFFSET),(PMB_WRITE_WORD | PMB_READ_WORD)},       // VOUT_CAL_OFFSET,23h
    {sizeof(gPmbusCmd.VOUT_MAX),(PMB_WRITE_WORD | PMB_READ_WORD)},              // VOUT_MAX,24h
    {sizeof(gPmbusCmd.VOUT_MARGIN_HIGH),(PMB_WRITE_WORD | PMB_READ_WORD)},      // VOUT_MARGIN_HIGH,25h
    {sizeof(gPmbusCmd.VOUT_MARGIN_LOW),(PMB_WRITE_WORD | PMB_READ_WORD)},       // VOUT_MARGIN_LOW,26h
    {sizeof(gPmbusCmd.VOUT_TRANSITION_RATE),(PMB_WRITE_WORD | PMB_READ_WORD)},  // VOUT_TRANSITION_RATE,27h
    {sizeof(gPmbusCmd.VOUT_DROOP),(PMB_WRITE_WORD | PMB_READ_WORD)},            // VOUT_DROOP,28h
    {sizeof(gPmbusCmd.VOUT_SCALE_LOOP),(PMB_WRITE_WORD | PMB_READ_WORD)},       // VOUT_SCALE_LOOP,29h
    {sizeof(gPmbusCmd.VOUT_SCALE_MONITOR),(PMB_WRITE_WORD | PMB_READ_WORD)},    // VOUT_SCALE_MONITOR,2Ah
    {0,PMB_RESERVED},                                                           // RESERVED,2Bh
    {0,PMB_RESERVED},                                                           // RESERVED,2Ch
    {0,PMB_RESERVED},                                                           // RESERVED,2Dh
    {0,PMB_RESERVED},                                                           // RESERVED,2Eh
    {0,PMB_RESERVED},                                                           // RESERVED,2Fh
    {sizeof(gPmbusCmd.COEFFICIENT),BLK_WR_BLK_RE_PC},                           // COEFFICIENTS,30h
    {sizeof(gPmbusCmd.POUT_MAX),(PMB_WRITE_WORD | PMB_READ_WORD)},              // POUT_MAX,31h
    {sizeof(gPmbusCmd.MAX_DUTY),(PMB_WRITE_WORD | PMB_READ_WORD)},              // MAX_DUTY,32h
    {sizeof(gPmbusCmd.FREQUENCY_SWITCH),(PMB_WRITE_WORD | PMB_READ_WORD)},      // FREQUENCY_SWITCH,33h
    {0,PMB_RESERVED},                             // RESERVED,34h
    {sizeof(gPmbusCmd.VIN_ON),(PMB_WRITE_WORD | PMB_READ_WORD)},                // VIN_ON,35h
    {sizeof(gPmbusCmd.VIN_OFF),(PMB_WRITE_WORD | PMB_READ_WORD)},               // VIN_OFF,36h
    {sizeof(gPmbusCmd.INTERLEAVE),(PMB_WRITE_WORD | PMB_READ_WORD)},            // INTERLEAVE,37h
    {sizeof(gPmbusCmd.IOUT_CAL_GAIN),(PMB_WRITE_WORD | PMB_READ_WORD)},            // IOUT_CAL_GAIN,38h
    {sizeof(gPmbusCmd.IOUT_CAL_OFFSET),(PMB_WRITE_WORD | PMB_READ_WORD)},            // IOUT_CAL_OFFSET,39h
    {sizeof(gPmbusCmd.FAN_CONFIG_1_2),(PMB_WRITE_BYTE | PMB_READ_BYTE)},            // FAN_CONFIG_1_2,3Ah
    {sizeof(gPmbusCmd.FAN_COMMAND_1),(PMB_WRITE_WORD | PMB_READ_WORD)},            // FAN_COMMAND_1,3Bh
    {sizeof(gPmbusCmd.FAN_COMMAND_2),(PMB_WRITE_WORD | PMB_READ_WORD)},            // FAN_COMMAND_2,3Ch
    {sizeof(gPmbusCmd.FAN_CONFIG_3_4),(PMB_WRITE_BYTE | PMB_READ_BYTE)},            // FAN_CONFIG_3_4,3Dh
    {sizeof(gPmbusCmd.FAN_COMMAND_3),(PMB_WRITE_WORD | PMB_READ_WORD)},            // FAN_COMMAND_3,3Eh
    {sizeof(gPmbusCmd.FAN_COMMAND_4),(PMB_WRITE_WORD | PMB_READ_WORD)},            // FAN_COMMAND_4,3Fh
    {sizeof(gPmbusCmd.VOUT_OV_FAULT_LIMIT),(PMB_WRITE_WORD | PMB_READ_WORD)},            // VOUT_OV_FAULT_LIMIT,40h
    {sizeof(gPmbusCmd.VOUT_OV_FAULT_RESPONSE),(PMB_WRITE_BYTE | PMB_READ_BYTE)},            // VOUT_OV_FAULT_RESPONSE,41h
    {sizeof(gPmbusCmd.VOUT_OV_WARN_LIMIT),(PMB_WRITE_WORD | PMB_READ_WORD)},            // VOUT_OV_WARN_LIMIT,42h
    {sizeof(gPmbusCmd.VOUT_UV_WARN_LIMIT),(PMB_WRITE_WORD | PMB_READ_WORD)},            // VOUT_UV_WARN_LIMIT,43h
    {sizeof(gPmbusCmd.VOUT_UV_FAULT_LIMIT),(PMB_WRITE_WORD | PMB_READ_WORD)},            // VOUT_UV_FAULT_LIMIT,44h
    {sizeof(gPmbusCmd.VOUT_UV_FAULT_RESPONSE),(PMB_WRITE_BYTE | PMB_READ_BYTE)},            // VOUT_UV_FAULT_RESPONSE,45h
    {sizeof(gPmbusCmd.IOUT_OC_FAULT_LIMIT),(PMB_WRITE_WORD | PMB_READ_WORD)},            // IOUT_OC_FAULT_LIMIT,46h
    {sizeof(gPmbusCmd.IOUT_OC_FAULT_RESPONSE),(PMB_WRITE_BYTE | PMB_READ_BYTE)},            // IOUT_OC_FAULT_RESPONSE,47h
    {sizeof(gPmbusCmd.IOUT_OC_LV_FAULT_LIMIT),(PMB_WRITE_WORD | PMB_READ_WORD)},            // IOUT_OC_LV_FAULT_LIMIT,48h
    {sizeof(gPmbusCmd.IOUT_OC_LV_FAULT_RESPONSE),(PMB_WRITE_BYTE | PMB_READ_BYTE)},            // IOUT_OC_LV_FAULT_RESPONSE,49h
    {sizeof(gPmbusCmd.IOUT_OC_WARN_LIMIT),(PMB_WRITE_WORD | PMB_READ_WORD)},            // IOUT_OC_WARN_LIMIT,4Ah
    {sizeof(gPmbusCmd.IOUT_UC_FAULT_LIMIT),(PMB_WRITE_WORD | PMB_READ_WORD)},            // IOUT_UC_FAULT_LIMIT,4Bh
    {sizeof(gPmbusCmd.IOUT_UC_FAULT_RESPONSE),(PMB_WRITE_BYTE | PMB_READ_BYTE)},            // IOUT_UC_FAULT_RESPONSE,4Ch
    {0,PMB_RESERVED},                                                            // RESERVED,4Dh
    {0,PMB_RESERVED},                                                            // RESERVED,4Eh
    {sizeof(gPmbusCmd.OT_FAULT_LIMIT),(PMB_WRITE_WORD | PMB_READ_WORD)},            // OT_FAULT_LIMIT,4Fh
    {sizeof(gPmbusCmd.OT_FAULT_RESPONSE),(PMB_WRITE_BYTE | PMB_READ_BYTE)},            // OT_FAULT_RESPONSE,50h
    {sizeof(gPmbusCmd.OT_WARN_LIMIT),(PMB_WRITE_WORD | PMB_READ_WORD)},            // OT_WARN_LIMIT,51h
    {sizeof(gPmbusCmd.UT_WARN_LIMIT),(PMB_WRITE_WORD | PMB_READ_WORD)},            // UT_WARN_LIMIT,52h
    {sizeof(gPmbusCmd.UT_FAULT_LIMIT),(PMB_WRITE_WORD | PMB_READ_WORD)},            // UT_FAULT_LIMIT,53h
    {sizeof(gPmbusCmd.UT_FAULT_RESPONSE),(PMB_WRITE_BYTE | PMB_READ_BYTE)},            // UT_FAULT_RESPONSE,54h
    {sizeof(gPmbusCmd.VIN_OV_FAULT_LIMIT),(PMB_WRITE_WORD | PMB_READ_WORD)},            // VIN_OV_FAULT_LIMIT,55h
    {sizeof(gPmbusCmd.VIN_OV_FAULT_RESPONSE),(PMB_WRITE_BYTE | PMB_READ_BYTE)},            // VIN_OV_FAULT_RESPONSE,56h
    {sizeof(gPmbusCmd.VIN_OV_WARN_LIMIT),(PMB_WRITE_WORD | PMB_READ_WORD)},            // VIN_OV_WARN_LIMIT,57h
    {sizeof(gPmbusCmd.VIN_UV_WARN_LIMIT),(PMB_WRITE_WORD | PMB_READ_WORD)},            // VIN_UV_WARN_LIMIT,58h
    {sizeof(gPmbusCmd.VIN_UV_FAULT_LIMIT),(PMB_WRITE_WORD | PMB_READ_WORD)},            // VIN_UV_FAULT_LIMIT,59h
    {sizeof(gPmbusCmd.VIN_UV_FAULT_RESPONSE),(PMB_WRITE_BYTE | PMB_READ_BYTE)},            // VIN_UV_FAULT_RESPONSE,5Ah
    {sizeof(gPmbusCmd.IIN_OC_FAULT_LIMIT),(PMB_WRITE_WORD | PMB_READ_WORD)},            // IIN_OC_FAULT_LIMIT,5Bh
    {sizeof(gPmbusCmd.IIN_OC_FAULT_RESPONSE),(PMB_WRITE_WORD | PMB_READ_WORD)},            // IIN_OC_FAULT_RESPONSE,5Ch
    {sizeof(gPmbusCmd.IIN_OC_WARN_LIMIT),(PMB_WRITE_WORD | PMB_READ_WORD)},            // IIN_OC_WARN_LIMIT,5Dh
    {sizeof(gPmbusCmd.POWER_GOOD_ON),(PMB_WRITE_WORD | PMB_READ_WORD)},            // POWER_GOOD_ON,5Eh
    {sizeof(gPmbusCmd.POWER_GOOD_OFF),(PMB_WRITE_WORD | PMB_READ_WORD)},            // POWER_GOOD_OFF,5Fh
    {sizeof(gPmbusCmd.TON_DELAY),(PMB_WRITE_WORD | PMB_READ_WORD)},             // TON_DELAY,60h
    {sizeof(gPmbusCmd.TON_RISE),(PMB_WRITE_WORD | PMB_READ_WORD)},              // TON_RISE,61h
    {sizeof(gPmbusCmd.TON_MAX_FAULT_LIMIT),(PMB_WRITE_WORD | PMB_READ_WORD)},            // TON_MAX_FAULT_LIMIT,62h
    {sizeof(gPmbusCmd.TON_MAX_FAULT_RESPONSE),(PMB_WRITE_WORD | PMB_READ_WORD)},            // TON_MAX_FAULT_RESPONSE,63h
    {sizeof(gPmbusCmd.TOFF_DELAY),(PMB_WRITE_WORD | PMB_READ_WORD)},            // TOFF_DELAY,64h
    {sizeof(gPmbusCmd.TOFF_FALL),(PMB_WRITE_WORD | PMB_READ_WORD)},             // TOFF_FALL,65h
    {sizeof(gPmbusCmd.TOFF_MAX_WARN_LIMIT),(PMB_WRITE_WORD | PMB_READ_WORD)},            // TOFF_MAX_WARN_LIMIT,66h
    {0,PMB_RESERVED},                              // RESERVED,67h
    {sizeof(gPmbusCmd.POUT_OP_FAULT_LIMIT),(PMB_WRITE_WORD | PMB_READ_WORD)},            // POUT_OP_FAULT_LIMIT,68h
    {sizeof(gPmbusCmd.POUT_OP_FAULT_RESPONSE),(PMB_WRITE_BYTE | PMB_READ_BYTE)},            // POUT_OP_FAULT_RESPONSE,69h
    {sizeof(gPmbusCmd.POUT_OP_WARN_LIMIT),(PMB_WRITE_WORD | PMB_READ_WORD)},            // POUT_OP_WARN_LIMIT,6Ah
    {sizeof(gPmbusCmd.PIN_OP_WARN_LIMIT),(PMB_WRITE_WORD | PMB_READ_WORD)},            // PIN_OP_WARN_LIMIT,6Bh
    {0,PMB_RESERVED},                                                               // RESERVED,6Ch
    {0,PMB_RESERVED},                                                               // RESERVED,6Dh
    {0,PMB_RESERVED},                                                               // RESERVED,6Eh
    {0,PMB_RESERVED},                                                               // RESERVED,6Fh
    {0,PMB_RESERVED},                                                               // RESERVED,70h
    {0,PMB_RESERVED},                                                               // RESERVED,71h
    {0,PMB_RESERVED},                                                               // RESERVED,72h
    {0,PMB_RESERVED},                                                               // RESERVED,73h
    {0,PMB_RESERVED},                                                               // RESERVED,74h
    {0,PMB_RESERVED},                                                               // RESERVED,75h
    {0,PMB_RESERVED},                                                               // RESERVED,76h
    {0,PMB_RESERVED},                                                               // RESERVED,77h
    {1,(PMB_WRITE_BYTE | PMB_READ_BYTE)},                                           // STATUS_BYTE,78h
    {sizeof(gPmbusCmd.STATUS_WORD),(PMB_WRITE_WORD | PMB_READ_WORD)},            // STATUS_WORD,79h
    {sizeof(gPmbusCmd.STATUS_VOUT),(PMB_WRITE_BYTE | PMB_READ_BYTE)},            // STATUS_VOUT,7Ah
    {sizeof(gPmbusCmd.STATUS_IOUT),(PMB_WRITE_BYTE | PMB_READ_BYTE)},            // STATUS_IOUT,7Bh
    {sizeof(gPmbusCmd.STATUS_INPUT),(PMB_WRITE_BYTE | PMB_READ_BYTE)},            // STATUS_INPUT,7Ch
    {sizeof(gPmbusCmd.STATUS_TEMPERATURE),(PMB_WRITE_BYTE | PMB_READ_BYTE)},            // STATUS_TEMPERATURE,7Dh
    {sizeof(gPmbusCmd.STATUS_CML),(PMB_WRITE_BYTE | PMB_READ_BYTE)},            // STATUS_CML,7Eh
    {sizeof(gPmbusCmd.STATUS_OTHER),(PMB_WRITE_BYTE | PMB_READ_BYTE)},            // STATUS_OTHER,7Fh
    {sizeof(gPmbusCmd.STATUS_MFR_SPECIFIC),(PMB_WRITE_BYTE | PMB_READ_BYTE)},            // STATUS_MFR_SPECIFIC,80h
    {sizeof(gPmbusCmd.STATUS_FAN_1_2),(PMB_WRITE_BYTE | PMB_READ_BYTE)},            // STATUS_FANS_1_2,81h
    {sizeof(gPmbusCmd.STATUS_FAN_3_4),(PMB_WRITE_BYTE | PMB_READ_BYTE)},            // STATUS_FANS_3_4,82h
    {0,PMB_RESERVED},                                                           // RESERVED,83h
    {0,PMB_RESERVED},                                                           // RESERVED,84h
    {0,PMB_RESERVED},                                                           // RESERVED,85h
    {sizeof(gPmbusCmd.READ_EIN),PMB_BLOCK_READ},                                // READ_EIN,86h
    {sizeof(gPmbusCmd.READ_EOUT),PMB_BLOCK_READ},                               // READ_EOUT,87h
    {sizeof(gPmbusCmd.READ_VIN),PMB_READ_WORD},                                 // READ_VIN,88h
    {sizeof(gPmbusCmd.READ_IIN),PMB_READ_WORD},                                 // READ_IIN,89h
    {sizeof(gPmbusCmd.READ_VCAP),PMB_READ_WORD},                                // READ_VCAP,8Ah
    {sizeof(gPmbusCmd.READ_VOUT),PMB_READ_WORD},                                // READ_VOUT,8Bh
    {sizeof(gPmbusCmd.READ_IOUT),PMB_READ_WORD},                                // READ_IOUT,8Ch
    {sizeof(gPmbusCmd.READ_TEMPERATURE_1),PMB_READ_WORD},                       // READ_TEMPERATURE_1,8Dh
    {sizeof(gPmbusCmd.READ_TEMPERATURE_2),PMB_READ_WORD},                       // READ_TEMPERATURE_2,8Eh
    {sizeof(gPmbusCmd.READ_TEMPERATURE_3),PMB_READ_WORD},                       // READ_TEMPERATURE_3,8Fh
    {sizeof(gPmbusCmd.READ_FAN_SPEED_1),PMB_READ_WORD},                         // READ_FAN_SPEED_1,90h
    {sizeof(gPmbusCmd.READ_FAN_SPEED_2),PMB_READ_WORD},                         // READ_FAN_SPEED_2,91h
    {sizeof(gPmbusCmd.READ_FAN_SPEED_3),PMB_READ_WORD},                         // READ_FAN_SPEED_3,92h
    {sizeof(gPmbusCmd.READ_FAN_SPEED_4),PMB_READ_WORD},                         // READ_FAN_SPEED_4,93h
    {sizeof(gPmbusCmd.READ_DUTY_CYCLE),PMB_READ_WORD},                          // READ_DUTY_CYCLE,94h
    {sizeof(gPmbusCmd.READ_FREQUENCY),PMB_READ_WORD},                           // READ_FREQUENCY,95h
    {sizeof(gPmbusCmd.READ_POUT),PMB_READ_WORD},                                // READ_POUT,96h
    {sizeof(gPmbusCmd.READ_PIN),PMB_READ_WORD},                                 // READ_PIN,97h
    {sizeof(gPmbusCmd.PMBUS_REVISION),PMB_READ_BYTE},                           // PMBUS_REVISION,98h
    
    {2,(PMB_BLOCK_WRITE | PMB_BLOCK_READ)},                                     // MFR_ID,99h
    {2,(PMB_BLOCK_WRITE | PMB_BLOCK_READ)},                                     // MFR_MODEL,9Ah
    {2,(PMB_BLOCK_WRITE | PMB_BLOCK_READ)},                                     // MFR_REVISION,9Bh
    {2,(PMB_BLOCK_WRITE | PMB_BLOCK_READ)},                                     // MFR_LOCATION,9Ch
    {2,(PMB_BLOCK_WRITE | PMB_BLOCK_READ)},                                     // MFR_DATE,9Dh
    {2,(PMB_BLOCK_WRITE | PMB_BLOCK_READ)},                                     // MFR_SERIAL,9Eh
    {2,PMB_BLOCK_READ},                                                         // APP_PROFILE_SUPPORT,9Fh
    
    {sizeof(gPmbusCmd.MFR_VIN_MIN),PMB_READ_WORD},                              // MFR_VIN_MIN,A0h
    {sizeof(gPmbusCmd.MFR_VIN_MAX),PMB_READ_WORD},                              // MFR_VIN_MAX,A1h
    {sizeof(gPmbusCmd.MFR_IIN_MAX),PMB_READ_WORD},                              // MFR_IIN_MAX,A2h
    {sizeof(gPmbusCmd.MFR_PIN_MAX),PMB_READ_WORD},                              // MFR_PIN_MAX,A3h
    {sizeof(gPmbusCmd.MFR_VOUT_MIN),PMB_READ_WORD},                             // MFR_VOUT_MIN,A4h
    {sizeof(gPmbusCmd.MFR_VOUT_MAX),PMB_READ_WORD},                             // MFR_VOUT_MAX,A5h
    {sizeof(gPmbusCmd.MFR_IOUT_MAX),PMB_READ_WORD},                             // MFR_IOUT_MAX,A6h
    {sizeof(gPmbusCmd.MFR_POUT_MAX),PMB_READ_WORD},                             // MFR_POUT_MAX,A7h
    {sizeof(gPmbusCmd.MFR_TAMBIENT_MAX),PMB_READ_WORD},                         // MFR_TAMBIENT_MAX,A8h
    
    {sizeof(gPmbusCmd.MFR_TAMBIENT_MIN),PMB_READ_WORD},                         // MFR_TAMBIENT_MIN,A9h
    
    {sizeof(gPmbusCmd.MFR_EFFICIENCY_LL),PMB_BLOCK_READ},                       // MFR_EFFICIENCY_LL,AAh
    {sizeof(gPmbusCmd.MFR_EFFICIENCY_HL), PMB_BLOCK_READ},                      // MFR_EFFICIENCY_HL,ABh
    {sizeof(gPmbusCmd.MFR_PIN_ACCURACY),PMB_READ_BYTE},                         // MFR_PIN_ACCURACY,ACh
    {2,PMB_BLOCK_READ},                                                         // IC_DEVICE_ID,ADh
    {2,PMB_BLOCK_READ},                                                         // IC_DEVICE_REV,AEh
    {2,PMB_RESERVED},                                                           // RESERVED,Afh
    {2,(PMB_BLOCK_WRITE | PMB_BLOCK_READ)},                                     // USER_DATA_00,B0h
    {2,(PMB_BLOCK_WRITE | PMB_BLOCK_READ)},                                     // USER_DATA_01,B1h
    {2,(PMB_BLOCK_WRITE | PMB_BLOCK_READ)},                                     // USER_DATA_02,B2h
    {2,(PMB_BLOCK_WRITE | PMB_BLOCK_READ)},                                     // USER_DATA_03,B3h
    {2,(PMB_BLOCK_WRITE | PMB_BLOCK_READ)},                                     // USER_DATA_04,B4h
    {2,(PMB_BLOCK_WRITE | PMB_BLOCK_READ)},                                     // USER_DATA_05,B5h
    {2,(PMB_BLOCK_WRITE | PMB_BLOCK_READ)},                                     // USER_DATA_06,B6h
    {2,(PMB_BLOCK_WRITE | PMB_BLOCK_READ)},                                     // USER_DATA_07,B7h
    {2,(PMB_BLOCK_WRITE | PMB_BLOCK_READ)},                                     // USER_DATA_08,B8h
    {2,(PMB_BLOCK_WRITE | PMB_BLOCK_READ)},                                     // USER_DATA_09,B9h
    {2,(PMB_BLOCK_WRITE | PMB_BLOCK_READ)},                                     // USER_DATA_10,BAh
    {2,(PMB_BLOCK_WRITE | PMB_BLOCK_READ)},                                     // USER_DATA_11,BBh
    {2,(PMB_BLOCK_WRITE | PMB_BLOCK_READ)},                                     // USER_DATA_12,BCh
    {2,(PMB_BLOCK_WRITE | PMB_BLOCK_READ)},                                     // USER_DATA_13,BDh
    {2,(PMB_BLOCK_WRITE | PMB_BLOCK_READ)},                                     // USER_DATA_14,BEh
    {2,(PMB_BLOCK_WRITE | PMB_BLOCK_READ)},                                     // USER_DATA_15,BFh
    {sizeof(gPmbusCmd.MFR_MAX_TEMP_1),(PMB_WRITE_WORD | PMB_READ_WORD)},        // MFR_MAX_TEMP_1,C0h
    {sizeof(gPmbusCmd.MFR_MAX_TEMP_2),(PMB_WRITE_WORD | PMB_READ_WORD)},        // MFR_MAX_TEMP_2,C1h
    {sizeof(gPmbusCmd.MFR_MAX_TEMP_3),(PMB_WRITE_WORD | PMB_READ_WORD)},        // MFR_MAX_TEMP_3,C2h
};    

/*******************************************************************************
 * Local data (private to module)
 ******************************************************************************/

/*******************************************************************************
 * Global functions (public to other modules)
 ******************************************************************************/

/*******************************************************************************
 * \brief         Initialize PMBus data
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PMBUS_vPmbusDataInit(void)
{
//  uint16 u8Cnt = 0;
  /* System Control Status */

  gPmbusCmd.OPERATION.ALL = MG_OPERATION_ON_80;
  gPmbusCmd.ON_OFF_CONFIG.ALL = MG_ON_OFF_CONFIG_1D;
  gPmbusCmd.PHASE.u8Val = MG_PHASE_DEFAULT;
  gPmbusCmd.CAPABILITY.ALL = 0;
  /* System Used Status */

  gPmbusCmd.STATUS_CML.ALL = 0;
  gPmbusCmd.STATUS_FAN_1_2.ALL = 0;
  gPmbusCmd.STATUS_FAN_3_4.ALL = 0;
  gPmbusCmd.STATUS_INPUT.ALL = 0;
  gPmbusCmd.STATUS_IOUT.ALL = 0;
  gPmbusCmd.STATUS_MFR_SPECIFIC.ALL = 0;
  gPmbusCmd.STATUS_OTHER.ALL = 0;
  gPmbusCmd.STATUS_TEMPERATURE.ALL = 0;
  gPmbusCmd.STATUS_VOUT.ALL = 0;
  gPmbusCmd.STATUS_WORD.ALL = 0;
 
#if 0  
  /* System Used Data */
  PMBUS_stData.u32DataCopy.u32Val = 0;
  PMBUS_stData.u16Vin_Report.u16Val = 0;
  PMBUS_stData.u16Iin_Report.u16Val = 0;
  PMBUS_stData.u16Pin_Report.u16Val = 0;
  PMBUS_stData.u16Vbulk_Report.u16Val = 0;
  PMBUS_stData.u16Vout_V1_Report.u16Val = 0;
  PMBUS_stData.u16Iout_V1_Report.u16Val = 0;
  PMBUS_stData.u16Pout_V1_Report.u16Val = 0;
  PMBUS_stData.u16Ishare_V1_Report.u16Val = 0;
  PMBUS_stData.u16Temperatue_1_Report.u16Val = 0;
  PMBUS_stData.u16Temperatue_2_Report.u16Val = 0;
  PMBUS_stData.u16Temperatue_3_Report.u16Val = 0;
  PMBUS_stData.u16FanSpeed_1_Report.u16Val = 0;
  PMBUS_stData.u16FanSpeed_2_Report.u16Val = 0;
  PMBUS_stData.u16FanCmd_1_Report.u16Val = 0;
  PMBUS_stData.u16FanCmd_2_Report.u16Val = 0;
  PMBUS_stData.u32HoursUsed_Report.u32Val = 0;
  PMBUS_stData.u32HoursUsedTotal.u32Val = 0;
  PMBUS_stData.u32HoursUsedPresent.u32Val = 0;
  PMBUS_stData.u8Cold_Redundancy_Config.u8Val = 0; /* D0h */
  PMBUS_stData.u16WDReset_Counter.u16Val = 0;
  PMBUS_stData.u16WD_Timer.u16Val = 300;    /* E7h */
  PMBUS_stData.PMBUS_sWDCtrlPort1.Bits.BIT_0 = 0; /* E8h */
  PMBUS_stData.PMBUS_sWDCtrlPort2.Bits.BIT_0 = 1; /* E9h */

  
  PMBUS_stEin.u32AccumulatedPower = 0;
  PMBUS_stEin.u8RollOverCount = 0;
  PMBUS_stEin.u32SampleCount = 0;
  PMBUS_stEinOld.u32AccumulatedPower = 0;
  PMBUS_stEinOld.u8RollOverCount = 0;
  PMBUS_stEinOld.u32SampleCount = 0;
  PMBUS_stEout.u32AccumulatedPower = 0;
  PMBUS_stEout.u8RollOverCount = 0;
  PMBUS_stEout.u32SampleCount = 0;
  PMBUS_stEoutOld.u32AccumulatedPower = 0;
  PMBUS_stEoutOld.u8RollOverCount = 0;
  PMBUS_stEoutOld.u32SampleCount = 0;
#endif
  
  /* Internal Used Data */
  PMBUS_uSysStatu0.ALL = 0;
  //PMBUS_uSysStatu1.ALL = 0;
  //PMBUS_uDataUpdStatus.ALL = 0;
  //PMBUS_uDataUpdStatus1.ALL = 0;
  //PMBUS_mg_u8EepProtect = 0;
/*
  PMBUS_mg_sSmbMask.u8Pmb7AhVoutP0 = 0x00;
  PMBUS_mg_sSmbMask.u8Pmb7BhIoutP0 = 0x00;
  PMBUS_mg_sSmbMask.u8Pmb7ChInputP0 = 0x40;
  PMBUS_mg_sSmbMask.u8Pmb7DhTempP0 = 0x00;
  PMBUS_mg_sSmbMask.u8Pmb7EhCMLP0 = 0xC0;
  PMBUS_mg_sSmbMask.u8Pmb7FhOtherP0 = 0x00;
  PMBUS_mg_sSmbMask.u8Pmb80hMfrP0 = 0x00;
  PMBUS_mg_sSmbMask.u8Pmb81hFan12P0 = 0x08;
*/
 // PMBUS_mg_u8Page = 0;
  gPmbusCmd.PAGE.u8Val = 0;
 

}/* PMBUS_vPmbusDataInit */

/*******************************************************************************
 * \brief          Clear fault or warning status
 *                  ucPage: page0, 1, FF
 *                  ucMode: 1: clear All, and can restart ( OPERATION )
 *                          2: clear All except STA_MFR, and can restart ( PS_ON, PS_KILL )
 *                          3: clear All, and can't restart ( CLEAR_FAULT, CLEAR_BITS )
 *                          4: clear All except STA_MFR, and can't restart
 *
 * \param[in]     -ucPage, ucMode
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PMBUS_vClearAllPageFault(void)
{
  mg_vClearPageAllFault();
}


/*******************************************************************************
 * \brief         Check the specific bit of the input data
 *
 * \param[in]     u16Data, u8BitNum
 * \param[in,out] -
 * \param[out]    - 
 *
 * \return        - TRUE or FALSE
 *
 *******************************************************************************/
boolean PMBUS_vCheckBit(uint16 u16Data, uint8 u8BitNum)
{
  if ((u16Data & (2^u8BitNum)) != 0)
  {
    return TRUE;
  }
  else
  {
    return FALSE;
  }
}

/*******************************************************************************
 * \brief         Copy status data to PMBus sensor registers / 10ms
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PMBUS_vCopyStatusData(void)
{
  PMBUS_ST_STATUS sPmbusStatusTemp;
  /* First power up, need to delay 3s then to update status */
  if (0U < PMBUS_mg_u16StatusUpdDly)
  {
    PMBUS_mg_u16StatusUpdDly--;
  }
  else
  {
    sPmbusStatusTemp.u16StatusWordP0.ALL = gPmbusCmd.STATUS_WORD.ALL;
    sPmbusStatusTemp.u8StatusVoutP0.ALL = gPmbusCmd.STATUS_VOUT.ALL;
    sPmbusStatusTemp.u8StatusIoutP0.ALL = gPmbusCmd.STATUS_IOUT.ALL;
    sPmbusStatusTemp.u8StatusInputP0.ALL = gPmbusCmd.STATUS_INPUT.ALL;
    sPmbusStatusTemp.u8StatusTempP0.ALL = gPmbusCmd.STATUS_TEMPERATURE.ALL;
    sPmbusStatusTemp.u8StatusCmlP0.ALL = gPmbusCmd.STATUS_CML.ALL;
    sPmbusStatusTemp.u8StatusOtherP0.ALL = gPmbusCmd.STATUS_OTHER.ALL;
    sPmbusStatusTemp.u8StatusMfrP0.ALL = gPmbusCmd.STATUS_MFR_SPECIFIC.ALL;
    sPmbusStatusTemp.u8StatusFan12P0.ALL = gPmbusCmd.STATUS_FAN_1_2.ALL;
    /* Update Fault Status */

    /* if Work at Aux mode, then set it base status table */
    if (PMBUS_uSysStatu0.Bits.AUX_MODE)
    {
      sPmbusStatusTemp.u16StatusWordP0.ALL |= 0x2848;
      sPmbusStatusTemp.u8StatusInputP0.ALL |= 0x10;
    }
    else if (Uart_flg_sta.com1_pri2_uart_fail) //INTCOM1_PRI1_UART_FAIL
    {
      /* UART fail Mode */
      sPmbusStatusTemp.u16StatusWordP0.ALL |= 0x0842;
      sPmbusStatusTemp.u8StatusCmlP0.ALL |= 0x02;
    }
    else
    {
      /* V1 Vout status 7Ah */
      if ((FALSE != FLG_B_LLC_V1_FW_OVP))
      {
        sPmbusStatusTemp.u8StatusVoutP0.Bits.VOUT_OV_FAULT = TRUE;
      }
      //      if (FALSE != FLG_B_LLC_V1_FW_OVW)
      //      {
      //        sPmbusStatusTemp.u8StatusVoutP0.Bits.VOUT_OV_WARN = TRUE;
      //      }
      if ((FALSE != FLG_B_LLC_V1_UVP))
      {
        sPmbusStatusTemp.u8StatusVoutP0.Bits.VOUT_UV_FAULT = TRUE;
      }
      //      if (FALSE != FLG_B_LLC_V1_FW_UVW)
      //      {
      //        sPmbusStatusTemp.u8StatusVoutP0.Bits.VOUT_UV_WARN = TRUE;
      //        sPmbusStatusTemp.u8StatusVoutP1.Bits.VOUT_UV_WARN = TRUE;
      //      }
      /* V1 Iout status 7Bh */
      if (FALSE != FLG_B_LLC_V1_OCW)
      {
        sPmbusStatusTemp.u8StatusIoutP0.Bits.IOUT_OC_WARN = TRUE;
      }
      if (FALSE != FLG_B_LLC_V1_OCP) 
      {
        sPmbusStatusTemp.u8StatusIoutP0.Bits.IOUT_OC_FAULT = TRUE;
      }
      if (FALSE != FLG_B_LLC_V1_SCP)
      {
        sPmbusStatusTemp.u8StatusIoutP0.Bits.IOUT_OC_LV_FAULT = TRUE;
      }

    }

    /* CML 7Eh */
    if (FALSE != Flg_sta.i2c_pec_err_flg) //I2C_PEC_ERR_FLG
    {
      sPmbusStatusTemp.u8StatusCmlP0.Bits.PEC_FAULT = TRUE;
      
    }
    if (FALSE != Flg_sta.i2c_invalid_cmd_flg) //I2C_INVALID_CMD_FLG
    {
      sPmbusStatusTemp.u8StatusCmlP0.Bits.INVALID_CMD = TRUE;
    }
    if (FALSE != Flg_sta.i2c_invalid_data_flg) //I2C_INVALID_DATA_FLG
    {
      sPmbusStatusTemp.u8StatusCmlP0.Bits.INVALID_DATA = TRUE;
    }

    /* V1 Status word 79h */
    /* Bit15:VOUT */
    if (FALSE != sPmbusStatusTemp.u8StatusVoutP0.ALL)
    {
      sPmbusStatusTemp.u16StatusWordP0.Bits.VOUT = TRUE;
    }
    else
    {
      sPmbusStatusTemp.u16StatusWordP0.Bits.VOUT = FALSE;
    }
    /* Bit14:IOUT/POUT */
    if (FALSE != sPmbusStatusTemp.u8StatusIoutP0.ALL)
    {
      sPmbusStatusTemp.u16StatusWordP0.Bits.IOUT_POUT = TRUE;
    }
    else
    {
      sPmbusStatusTemp.u16StatusWordP0.Bits.IOUT_POUT = FALSE;
    }

    /* Bit6:OFF */
    if (OFF == FLG_B_V1_STATE)
    {
      sPmbusStatusTemp.u16StatusWordP0.Bits.V_OFF = TRUE;
    }
    else
    {
      sPmbusStatusTemp.u16StatusWordP0.Bits.V_OFF = FALSE;
    }
    /* Bit5:VOUT_OV_FAULT */
    if (FALSE != sPmbusStatusTemp.u8StatusVoutP0.Bits.VOUT_OV_FAULT)
    {
      sPmbusStatusTemp.u16StatusWordP0.Bits.VOUT_OV_FAULT = TRUE;
    }
    else
    {
      sPmbusStatusTemp.u16StatusWordP0.Bits.VOUT_OV_FAULT = FALSE;
    }
    /* Bit4:IOUT_OC_FAULT */
    if (FALSE != sPmbusStatusTemp.u8StatusIoutP0.Bits.IOUT_OC_FAULT)
    {
      sPmbusStatusTemp.u16StatusWordP0.Bits.IOUT_OC_FAULT = TRUE;
    }
    else
    {
      sPmbusStatusTemp.u16StatusWordP0.Bits.IOUT_OC_FAULT = FALSE;
    }
    /* Bit3:VIN_UV_FAULT */
//    if (FALSE != sPmbusStatusTemp.u8StatusInputP0.Bits.VIN_UV_FAULT)
//    {
//      sPmbusStatusTemp.u16StatusWordP0.Bits.VIN_UV_FAULT = TRUE;
//    }
//    else
//    {
//      sPmbusStatusTemp.u16StatusWordP0.Bits.VIN_UV_FAULT = FALSE;
//    }

    /* Bit0:NONE_OF_THE_ABOVE */
    //Not use
    gPmbusCmd.STATUS_WORD.ALL = sPmbusStatusTemp.u16StatusWordP0.ALL;
    gPmbusCmd.STATUS_VOUT.ALL = sPmbusStatusTemp.u8StatusVoutP0.ALL;
    gPmbusCmd.STATUS_IOUT.ALL = sPmbusStatusTemp.u8StatusIoutP0.ALL;
    gPmbusCmd.STATUS_IOUT.ALL = sPmbusStatusTemp.u8StatusInputP0.ALL;
    gPmbusCmd.STATUS_TEMPERATURE.ALL = sPmbusStatusTemp.u8StatusTempP0.ALL;
    gPmbusCmd.STATUS_CML.ALL = sPmbusStatusTemp.u8StatusCmlP0.ALL;
    gPmbusCmd.STATUS_OTHER.ALL = sPmbusStatusTemp.u8StatusOtherP0.ALL;
    gPmbusCmd.STATUS_MFR_SPECIFIC.ALL = sPmbusStatusTemp.u8StatusMfrP0.ALL;
    gPmbusCmd.STATUS_FAN_1_2.ALL = sPmbusStatusTemp.u8StatusFan12P0.ALL;
  }
  /* Judge SMBALERT base fault status */

}/* PMBUS_vCopyStatusData */


/*******************************************************************************
 * \brief         Copy debug data to PMBus debug registers, every 10ms.
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PMBUS_vCopyDebugData(void)
{

}/* PMBUS_vCopyDebugData */



/********************************************************************************
 * \brief         Prepare data for system reading
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
#if 1
void PMBUS_vSendData(uint8 u8I2cCommand)
{
       
  //if (MG_PAGE_00 == PMBUS_mg_u8Page)
  if (MG_PAGE_00 == gPmbusCmd.PAGE.u8Val)
  {
    switch (u8I2cCommand) {
    case PMB_00_PAGE:
    {
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = gPmbusCmd.PAGE.u8Val;
    }
    case PMB_01_OPERATION:
    {
        //UART1_Write(0xE2);
		//UART1_Write(gPmbusCmd.OPERATION.ALL);
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = gPmbusCmd.OPERATION.ALL;
      break;
    }
	case PMB_20_VOUT_MODE:
    {
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = 0xFF;
      break;
    }
    case PMB_02_ON_OFF_CONFIG:
    {
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = gPmbusCmd.ON_OFF_CONFIG.ALL;
      break;
    }
    case PMB_78_STATUS_BYTE:
    {
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = gPmbusCmd.STATUS_WORD.Bytes.LB;
      break;
    }
    case PMB_79_STATUS_WORD:
    { 
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = gPmbusCmd.STATUS_WORD.Bytes.LB;
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = gPmbusCmd.STATUS_WORD.Bytes.HB;
      break;
    }
    case PMB_7A_STATUS_VOUT:
    {
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = gPmbusCmd.STATUS_VOUT.ALL;
      break;
    }
    case PMB_7B_STATUS_IOUT:
    {
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = gPmbusCmd.STATUS_IOUT.ALL;
      break;
    }
    case PMB_7C_STATUS_INPUT:
    {
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = gPmbusCmd.STATUS_INPUT.ALL;
      break;
    }
	 case PMB_7D_STATUS_TEMPERATURE:
    {
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = gPmbusCmd.STATUS_TEMPERATURE.ALL;
      break;
    }
	case PMB_7E_STATUS_CML:
	{
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = gPmbusCmd.STATUS_CML.ALL;
      break;
    }
	case PMB_7F_STATUS_OTHER:
	{
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = gPmbusCmd.STATUS_OTHER.ALL;
      break;
    }
	case PMB_80_STATUS_MFR_SPECIFIC:
	{
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = gPmbusCmd.STATUS_MFR_SPECIFIC.ALL;
      break;
    }
	case PMB_81_STATUS_FANS_1_2:
	{
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = gPmbusCmd.STATUS_FAN_1_2.ALL;
      break;
    }
	case PMB_88_READ_VIN_WORD:
	{
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = 0x11;//gPmbusCmd.READ_VIN.Bytes.LB;
	  I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = 0x22;//gPmbusCmd.READ_VIN.Bytes.HB;
      
      break;
    }
	case PMB_89_READ_IIN_WORD:
	{
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = 0x33;//gPmbusCmd.READ_IIN.Bytes.LB;
	  I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = 0x44;//gPmbusCmd.READ_IIN.Bytes.HB;
      break;
    }
	case PMB_8A_READ_VCAP_WORD:
	{
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = 0xFF;
	  I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = 0xFF;
      break;
    }
	case PMB_8B_READ_VOUT_WORD:
	{
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = 0x55;//gPmbusCmd.READ_VOUT.Bytes.LB;
	  I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = 0x66;//gPmbusCmd.READ_VOUT.Bytes.HB;
      break;
    }
	case PMB_8C_READ_IOUT_WORD:
	{
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = 0xFF;
	  I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = 0xFF;
      break;
    }
	case PMB_8D_READ_TEMP1_WORD:
	{
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = 0xFF; //gPmbusCmd.READ_TEMPERATURE_1.Bytes.LB;
	  I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = 0xFF; //gPmbusCmd.READ_TEMPERATURE_1.Bytes.HB;
      break;
    }
	case PMB_8E_READ_TEMP2_WORD:
	{
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = 0xFF; //gPmbusCmd.READ_TEMPERATURE_2.Bytes.LB;
	  I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = 0xFF; //gPmbusCmd.READ_TEMPERATURE_2.Bytes.HB;
      break;
    }
	case PMB_8F_READ_TEMP3_WORD:
	{
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = 0xFF;
	  I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = 0xFF;
      break;
    }
	case PMB_90_READ_FAN1_SPEED_WORD:
	{
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = 0xFF;
	  I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = 0xFF;
      break;
    }
	case PMB_96_READ_POUT_WORD:
	{
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = 0xFF;
	  I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = 0xFF;
      break;
    }
	case PMB_97_READ_PIN_WORD:
	{
      I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = 0xFF;
	  I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = 0xFF;
      break;
    }
    default:
    {
        I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = 0x00;
        I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = 0x00;
        I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = 0x00;
        I2C_au8I2cTxBuf[I2C_u8I2cTxLen++] = 0x00;
      break;
    }
    }
  }
}/* I2cGetData */
#endif

/*******************************************************************************
 * Function:        I2cSetData
 *
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     GUI -> MCU
 *
 ******************************************************************************/
void vPMBus_HandleData(uint8 u8I2cCommand)
{
  static uint8 u8OperationOld = 0;
  uint8 u8Data0;
  uint8 u8Data1;
  uint8 u8Data2;
  uint8 u8Data3;

//  if (FALSE == FLG_STA_WRITE_PLUS_FLG)
//  {
    u8Data0 = I2C_au8I2cRxBuf[1];
    u8Data1 = I2C_au8I2cRxBuf[2];
    u8Data2 = I2C_au8I2cRxBuf[3];
    u8Data3 = I2C_au8I2cRxBuf[4];
//  }
//  else
//  {
//    FLG_STA_WRITE_PLUS_FLG = FALSE;
//    u8Data0 = I2C_au8I2cRxBuf[4];
//    u8Data1 = I2C_au8I2cRxBuf[5];
//    u8Data2 = I2C_au8I2cRxBuf[6];
//    u8Data3 = I2C_au8I2cRxBuf[7];
//  }

  switch (u8I2cCommand) {
    /************************************************************************
     *   Standard PMBus commands 
     ************************************************************************/
  case PMB_00_PAGE:
  {
  	//UART1_Write(0xF0);
    if ((MG_PAGE_00 == u8Data0) || (MG_PAGE_01 == u8Data0))
    {
      //PMBUS_mg_u8Page = u8Data0;
      gPmbusCmd.PAGE.u8Val = u8Data0;
	  //UART1_Write(PMBUS_mg_u8Page);
    }
    else
    {
       Flg_sta.i2c_invalid_data_flg = TRUE; //I2C_INVALID_DATA_FLG
    }
    break;
  }
  case PMB_01_OPERATION:
  {
    //Tx1_Buf[1]=0xF1;
    if (FALSE != PMBUS_uSysStatu0.Bits.AUX_MODE)
    {
      /* Ignore write at Aux_Mode */
    }
    else
    {
      //if (MG_PAGE_00 == PMBUS_mg_u8Page)
      if (MG_PAGE_00 == gPmbusCmd.PAGE.u8Val) 
      {
        if ((0x00 == u8Data0) || (0x80 == u8Data0))
        {
          //if(PMBUS_uOnOffConfig.Bits.RES_TO_OPER == 1U)
          if(gPmbusCmd.ON_OFF_CONFIG.Bits.RES_TO_OPER == 1U)  
          {
              //PMBUS_uOperation.ALL = u8Data0;
              gPmbusCmd.OPERATION.ALL = u8Data0;
          }
        }
        else
        {
          Flg_sta.i2c_invalid_data_flg = TRUE; //I2C_INVALID_DATA_FLG
        }
        /* PMBus Operation recycle */
        //if ((PMBUS_uOperation.ALL == 0x80) && (u8OperationOld == 0U)&& (PMBUS_uOnOffConfig.Bits.RES_TO_OPER == 1U))
        if ((gPmbusCmd.OPERATION.ALL == 0x80) && (u8OperationOld == 0U)&& (gPmbusCmd.ON_OFF_CONFIG.Bits.RES_TO_OPER == 1U))
        {
            FLG_PMBUS_PSON = 1;//pson
        }
        //else if((PMBUS_uOperation.ALL == 0x00) && (u8OperationOld == 0x80)&& (PMBUS_uOnOffConfig.Bits.RES_TO_OPER == 1U))
        else if((gPmbusCmd.OPERATION.ALL == 0x00) && (u8OperationOld == 0x80)&& (gPmbusCmd.ON_OFF_CONFIG.Bits.RES_TO_OPER == 1U))
        {
            FLG_PMBUS_PSON = 0;//psoff
        }
        //u8OperationOld = PMBUS_uOperation.ALL;
        u8OperationOld = gPmbusCmd.OPERATION.ALL;
      }
      else
      {
        Flg_sta.i2c_invalid_data_flg = TRUE; //I2C_INVALID_DATA_FLG
      }
    }
    break;
  }
  case PMB_02_ON_OFF_CONFIG:
  {
    //Tx1_Buf[2]=0xF3;
    //if (MG_PAGE_00 == PMBUS_mg_u8Page)
    if (MG_PAGE_00 == gPmbusCmd.PAGE.u8Val)    
    {
      if ((0x11 == u8Data0) || (0x15 == u8Data0) || (0x19 == u8Data0) || (0x1D == u8Data0))
      {
        //PMBUS_uOnOffConfig.ALL = u8Data0;
        gPmbusCmd.ON_OFF_CONFIG.ALL = u8Data0;
      }
      else
      {
        Flg_sta.i2c_invalid_data_flg = TRUE; //I2C_INVALID_DATA_FLG
      }
    }
    else
    {
      Flg_sta.i2c_invalid_data_flg = TRUE; //I2C_INVALID_DATA_FLG
    }
    break;
  }
  case PMB_03_CLEAR_FAULTS:
  {
    if (PMBUS_mg_u8WriteProtect == 0x00)
    {
      mg_vClearPageFault();
    }
    break;
  }
  case PMB_05_PAGE_PLUS_WRITE:
  {
      break;
  }
  case PMB_06_PAGE_PLUS_READ:
  {
      break;
  }
  case PMB_10_WRITE_PROTECT:
  {
      break;
  }
  case PMB_19_CAPABILITY:
  {
      break;
  }
  case PMB_1A_QUERY:
  {
      break;
  }
  case PMB_1B_SMBALERT_MASK:
  {
      break;
  }
  case PMB_20_VOUT_MODE:
  {
      break;
  }
  case PMB_21_VOUT_COMMAND:
  {
      break;
  }
  case PMB_22_VOUT_TRIM:
  {
      break;
  }
  case PMB_23_VOUT_CAL_OFFSET:
  {
      break;
  }
  case PMB_24_VOUT_MAX:
  {
      //check the setting should be in correct range
      break;
  }
  case PMB_25_VOUT_MARGIN_HIGH:
  {
      break;
  }
  case PMB_26_VOUT_MARGIN_LOW:
  {
      break;
  }
  case PMB_27_VOUT_TRANSITION_RATE:
  {
      break;
  }
  case PMB_28_VOUT_DROOP:
  {
      break;
  }
  case PMB_29_VOUT_SCALE_LOOP:
  {
      break;
  }
  case PMB_2A_VOUT_SCALE_MONITOR:
  {
      break;
  }
  case PMB_30_COEFFICIENTS:
  {
      break;
  }
  case PMB_3A_FAN_CONFIG_1_2:
  {
      break;
  }
  case PMB_3B_FAN_COMMAND_1:
  {
      break;
  }
  case PMB_3C_FAN_COMMAND_2:
  {
      break;
  }
  default:
  {
    break;
  }
  }
}

/*******************************************************************************
 * \brief          Clear fault or warning status
 *                  ucPage: page0, 1, FF
 *                  ucMode: 1: clear All, and can restart ( OPERATION )
 *                          2: clear All except STA_MFR, and can restart ( PS_ON, PS_KILL )
 *                          3: clear All, and can't restart ( CLEAR_FAULT, CLEAR_BITS )
 *                          4: clear All except STA_MFR, and can't restart
 *
 * \param[in]     -ucPage, ucMode
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
static void mg_vClearPage00Fault(void)
{   
  gPmbusCmd.STATUS_CML.ALL = 0;
  gPmbusCmd.STATUS_FAN_1_2.ALL = 0;
  gPmbusCmd.STATUS_FAN_3_4.ALL = 0;
  gPmbusCmd.STATUS_INPUT.ALL = 0;
  gPmbusCmd.STATUS_IOUT.ALL = 0;
  gPmbusCmd.STATUS_MFR_SPECIFIC.ALL = 0;
  gPmbusCmd.STATUS_OTHER.ALL = 0;
  gPmbusCmd.STATUS_TEMPERATURE.ALL = 0;
  gPmbusCmd.STATUS_VOUT.ALL = 0;
  gPmbusCmd.STATUS_WORD.ALL = 0;
  gPmbusCmd.FAN_COMMAND_1.u16Val = 0;
  gPmbusCmd.FAN_COMMAND_2.u16Val = 0;
  gPmbusCmd.FAN_CONFIG_1_2.u8Val = 0;
  gPmbusCmd.FAN_CONFIG_3_4.u8Val = 0;
  gPmbusCmd.READ_FAN_SPEED_1.u16Val = 0;
  gPmbusCmd.READ_FAN_SPEED_2.u16Val = 0;
  gPmbusCmd.READ_IIN.u16Val = 0;
  FLG_B_V1_ORING_INV_CMD = FALSE;  
  FLG_B_V1_ISHARE_FAIL = FALSE;
}

/*******************************************************************************
 * \brief          Clear fault or warning status
 *                  ucPage: page0, 1, FF
 *                  ucMode: 1: clear All, and can restart ( OPERATION )
 *                          2: clear All except STA_MFR, and can restart ( PS_ON, PS_KILL )
 *                          3: clear All, and can't restart ( CLEAR_FAULT, CLEAR_BITS )
 *                          4: clear All except STA_MFR, and can't restart
 *
 * \param[in]     -ucPage, ucMode
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
static void mg_vClearPageAllFault()
{
  mg_vClearPage00Fault();
}

/*******************************************************************************
 * \brief          Clear fault or warning status
 *                  ucPage: page0, 1, FF
 *                  ucMode: 1: clear All, and can restart ( OPERATION )
 *                          2: clear All except STA_MFR, and can restart ( PS_ON, PS_KILL )
 *                          3: clear All, and can't restart ( CLEAR_FAULT, CLEAR_BITS )
 *                          4: clear All except STA_MFR, and can't restart
 *
 * \param[in]     -ucPage, ucMode
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
static void mg_vClearPageFault(void)
{
  /* Standard PMBus Status Initial */
  //switch (PMBUS_mg_u8Page) {
  switch (gPmbusCmd.PAGE.u8Val) {  
  case MG_PAGE_00:
  {
    Flg_sta.i2c_invalid_cmd_flg = FALSE; //I2C_INVALID_CMD_FLG
    Flg_sta.i2c_invalid_data_flg = FALSE; //I2C_INVALID_DATA_FLG
    Flg_sta.i2c_pec_err_flg = FALSE; //I2C_PEC_ERR_FLG
    stV1FaultFlag00.ALL = 0;
    mg_vClearPage00Fault();
    break;
  }
  case MG_PAGE_01:
  {

    break;
  }

  default:
  {
    break;
  }
  }

  PMBUS_vCopyStatusData(); // to update status immediately
} /* PMBUS_vClearFault */



/*
 * End of file
 */
