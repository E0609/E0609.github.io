/* 
 * File:   UartComm.h
 * Author: 
 *
 * 
 */

#ifndef UARTCOMM_H
#define	UARTCOMM_H

#ifdef	__cplusplus
extern "C" {
#endif

extern unsigned char UART_CRC8_Isr(unsigned char inCrc, unsigned char inData);
extern unsigned char UART_CRC8(unsigned char inCrc, unsigned char inData);


#ifdef	__cplusplus
}
#endif

#endif	/* UARTCOMM_H */

