#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include "xc.h"
#include "global.h"
/*******************************************************************************
 * Function:        UART_CRC8 * called from ISR
 * Parameters:      crc - pointer to crc byte
 *                  data - data for crc calculation *
 * Description:     Add data to crc calculated as 8 bit value.
 ******************************************************************************/
unsigned char UART_CRC8_Isr(unsigned char inCrc, unsigned char inData)
{
    uint8_t i, crc;

    crc = inCrc ^ inData;
    for(i = 0; i < 8; i++)
    {
        if ((crc & 0x80) != 0)
        {
            crc <<= 1;
            crc ^= 0x07;
        }
        else
            crc <<= 1;
    }
    return (crc);
}

/*******************************************************************************
 * Function:        UART_CRC8 * called from main
 * Parameters:      crc - pointer to crc byte
 *                  data - data for crc calculation *
 * Description:     Add data to crc calculated as 8 bit value.
 ******************************************************************************/
unsigned char  UART_CRC8(unsigned char inCrc, unsigned char inData)
{
    uint8_t i, crc;

    crc = inCrc ^ inData;
    for(i = 0; i < 8; i++)
    {

        if ((crc & 0x80) != 0)
        {
            crc <<= 1;
            crc ^= 0x07;
        }
        else
            crc <<= 1;
    }
        return (crc);
}

