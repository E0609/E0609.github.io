/******************************************************************************
 * \file    PsuState.c
 * \brief   State machine control of PSU
 *
 * \section AUTHOR
 *    
 *
 * \section SVN
 *  $Date$
 *  $Author$
 *  $Revision$
 *
 * \section LICENSE
 * Copyright (c) 
 * All rights reserved.
 *******************************************************************************/

/*******************************************************************************
 * Included header
 ******************************************************************************/

#include "global.h"

/* Module header */
#include "Define.h"
#include "Protection.h"
#include "McuAdc.h"
#include "McuPwm.h"
#include "PsuState.h"

#include "McuGPIO.h"
#include "Sample.h"
#include "McuUart2.h"
#include "McuUart1.h"
#include "FanCtrl.h"
/*******************************************************************************
 * Local constants and macros (private to module)
 ******************************************************************************/

#define PSU_PW_TURNON_DLY  10000
#define MG_V1_TURN_OFF_DLY   10  
#define MG_5VSB_TURN_OFF_DLY  10

/*******************************************************************************
 * Local data (private to module)
 ******************************************************************************/
static MG_V1_CTRL_STA PSU_mg_V1_state_ctrl = PSU_CTRL_V1_OFF;
static uint16 psu_mg_u16V1TurnOnDly = 0,psuPWMOffDly = 0;
/*******************************************************************************
 * Local function prototypes (private to module)
 ******************************************************************************/

/*******************************************************************************
 * Global data
 ******************************************************************************/

/*******************************************************************************
 * Global data types (public typedefs / structs / enums)
 ******************************************************************************/

/*******************************************************************************
 * Global functions (public to other modules)
 ******************************************************************************/
void PSUstate_DataInit(void);
void PSUstate_V1OnOffJudge(void);

/*******************************************************************************
 * \brief         Initialize PSU State control data
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PSUstate_DataInit(void)
{
  PSU_mg_V1_state_ctrl = PSU_INIT;
  psu_mg_u16V1TurnOnDly = PSU_PW_TURNON_DLY;
  PORT_OUT_5VSB_EN;
}/* PSUstate_DataInit */

/*******************************************************************************
 * \brief         control V1 status
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *100us
 *******************************************************************************/
void PSUstate_V1StatusControl(void)
{
  static uint16 u16V1_PwrUpDly = 0,tmp_r=0;
  static uint16 u16V1_OutputOKDly = 0,TimerCnt1_set = 0,TimerCnt2_set = 0;

  PSUstate_V1OnOffJudge();
  //Tx_Buf[0] = 0xAA;

    if(FLG_B_PSON_ACTIVED)
    {
       // Tx_Buf[4]=0xDD;
        if((psu_mg_u16V1TurnOnDly != 3000)&&(TimerCnt1_set == 0))
        {
            psu_mg_u16V1TurnOnDly = 3000;
            TimerCnt1_set = 1;
        }
        FLG_B_PSON_ACTIVED = 0;
    }
    else
    {
        if((psu_mg_u16V1TurnOnDly != 10000)&&( TimerCnt2_set == 0))
        {
            psu_mg_u16V1TurnOnDly = 10000;
            TimerCnt2_set = 1;
        }
       // Tx_Buf[3]=0xCC;
    }
  //UpdateFanDuty();
  switch (PSU_mg_V1_state_ctrl) {
  case PSU_CTRL_V1_OFF:
  {
    PSU_mg_V1PwrOff();
    if((FLG_B_PSON_ACTIVED)||(FLG_B_PSON_ENABLE))
    {
        if (psu_mg_u16V1TurnOnDly > 0)
        {
         //   Tx_Buf[2]= 0xAA;
          psu_mg_u16V1TurnOnDly--;
        }
        else
        {
             TimerCnt1_set = 0;
             TimerCnt2_set = 0;
        //     Tx_Buf[2]= 0x00;
          if ((FALSE != FLG_V1_PRISYS_CONDITION)
          && (FALSE == FLG_V1_FAULT_CONDITION))
          {
            PSU_mg_V1PwrOn();
            u16V1_PwrUpDly = 0;
            PSU_mg_V1_state_ctrl = PSU_CTRL_V1_RUN;
            FLG_B_NORMAL_STATE_FOR_FAN = 1;
          }
        }
    }
    u16StartMonV1UvpCnt = 0;
    PROTECT_V1Volt();
    PWR_GOOD_ASSERT();

    break;
  }
  case PSU_CTRL_V1_RUN:
  {
    PWR_GOOD_ASSERT();
    PROTECT_V1Volt();
    u16StartMonV1UvpCnt = 0;
    
    if ((FALSE == FLG_V1_PRISYS_CONDITION)
      || (FALSE != FLG_V1_FAULT_CONDITION))
    {
      PSU_mg_V1PwrOff();
      u16V1_PwrUpDly = 0;
      u16V1_OutputOKDly = 0;
      PSU_mg_V1_state_ctrl = PSU_CTRL_V1_OFF;
      //psu_mg_u16V1TurnOnDly = PSU_PW_TURNON_DLY;
    }
    break;
  }

  default:
  {
    PSU_mg_V1_state_ctrl = PSU_CTRL_V1_OFF;
    break;
  }
  }
  
}

/*******************************************************************************
 * \brief         control psu on
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void PSU_mg_V1PwrOn(void)
{
  //  Tx_Buf[7]=0x07;
  //  Tx_Buf[6]=0x00;   
  FLG_B_V1_STATE = ON;
  PORT_OUT_V1_ORING_EN;
  PORT_OUT_V1_SR_EN;
  LLC_EN();
  PORT_OUT_5VSB_EN;
  //PORT_OUT_LLC_EN;
  //PWM_V1_HB_ENABLE_H_REG = 1;
  //PWM_V1_HB_ENABLE_L_REG = 1;
}

/*******************************************************************************
 * \brief         control psu off
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *100us
 *******************************************************************************/
void PSU_mg_V1PwrOff(void)
{
	static uint16_t mg_u16V1MOPTurnOffDly=0,mg_u16V1_OFF_delay_ok = 0;

    //if(FLG_B_V1_FAULT_LATCH || FLG_B_STB_FAULT_LATCH)
   // {
     //   mg_u16V1MOPTurnOffDly = 0;
   // }
   // else
    {
        if(mg_u16V1MOPTurnOffDly < 25)//1.5ms ?delay after POK
        {            
            mg_u16V1MOPTurnOffDly++ ;
            mg_u16V1_OFF_delay_ok = 0;
        }
        else
        {
         mg_u16V1MOPTurnOffDly = 0;
         mg_u16V1_OFF_delay_ok = 1;
        }
    }
    if(mg_u16V1_OFF_delay_ok == 1)
    {
        FLG_B_V1_STATE = OFF;
        PORT_OUT_V1_ORING_DIS;
        PORT_OUT_V1_SR_DIS;

      //LLC disable if outputOVP,OCP,OTP
        LLC_DIS(); //PFC_NOK already off the LLC in primary
     // PORT_OUT_LLC_DIS;
        mg_u16V1_OFF_delay_ok = 0;
    }
}
/*******************************************************************************
 * \brief         control psu 5VSB judge
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *100us
 * \return        -
 *
 *******************************************************************************/
void PSUstate_5VSBOnOffJudge(void)
{
    static uint16 mg_u16STBFaultTurnOffDly = 0;
    
      if ((FALSE == FLG_B_STB_OC_HICCUP)&&
      (FALSE == FLG_B_STB_FAULT_LATCH))
      {
          FLG_5VSTB_FAULT_CONDITION = 0; 
        mg_u16STBFaultTurnOffDly = 0;
      }
      else
      {
         if(FLG_B_STB_FAULT_LATCH == 1)
        {
            FLG_5VSTB_FAULT_CONDITION = 1; 
        }
         if(FLG_B_STB_OC_HICCUP)
         {
             if (mg_u16STBFaultTurnOffDly > MG_5VSB_TURN_OFF_DLY)
             {
               FLG_5VSTB_FAULT_CONDITION = 1;
             }
             else
             {
               mg_u16STBFaultTurnOffDly++;
             }  
         }
      }

    
}

/*******************************************************************************
 * \brief         control psu V1 start judge
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *100us
 * \return        -
 *
 *******************************************************************************/
void PSUstate_V1OnOffJudge(void)
{
  static uint16 mg_u16V1FaultTurnOffDly = 0;
  static uint16 mg_u16V1TurnOffDly = 0,mg_u16InputNokDly=0;

  if ((FALSE == FLG_B_V1_FAULT_LATCH) &&
      (FALSE == FLG_B_LLC_V1_FW_OVP) && 
      (FALSE == FLG_B_V1_OC_HICCUP) && 
      (FALSE == FLG_B_LLC_V1_OCP) &&
      (FALSE == FLG_B_STB_FAULT_LATCH)&&
      (FALSE == FLG_STA_OTP)    
      )     
  {
   // Tx_Buf[2]= 0x02;  
    FLG_V1_FAULT_CONDITION = 0; 
    mg_u16V1FaultTurnOffDly = 0;
  }
  else
  {
    //   Tx_Buf[2]= 0x022; 
    if (FALSE != FLG_B_LLC_V1_FW_OVP) 
    {
      mg_u16V1FaultTurnOffDly = 0;
      FLG_B_V1_PWOK_GOOD = FALSE;
      FLG_B_V1_FAULT_LATCH = 1;
      FLG_V1_FAULT_CONDITION = 1;
    }
    else
    {
      if (mg_u16V1FaultTurnOffDly > MG_V1_TURN_OFF_DLY)
      {
        FLG_V1_FAULT_CONDITION = 1;
      }
      else
      {
        mg_u16V1FaultTurnOffDly++;
        FLG_B_V1_PWOK_GOOD = FALSE;
      }
    }
    
    if (FALSE != FLG_B_STB_FAULT_LATCH) //5VSTB ovp go to latch mode
    {     
      FLG_B_V1_FAULT_LATCH = 1;
    }
  }
   if(FLG_B_INPUT_OK)
  {
    PORT_OUT_VIN_OK_EN;
    FLG_B_INPUT_DELAY_OK = 0;
    mg_u16InputNokDly = 0;
  }
  else
  {
    PORT_OUT_VIN_OK_DIS;
    if(mg_u16InputNokDly > 200) //20ms
    {
        FLG_B_INPUT_DELAY_OK = 1; 
        mg_u16InputNokDly = 0;
    }
    else
    {
        mg_u16InputNokDly++;
    }
  }  
  if ((FALSE != FLG_B_PSON_ENABLE)&&
      (FALSE != FLG_B_BULK_OK)&&
      (FALSE == FLG_B_INPUT_DELAY_OK)
      )
  {

    mg_u16V1TurnOffDly = 0;
    FLG_V1_PRISYS_CONDITION = 1;
  }
  else
  {

    if (mg_u16V1TurnOffDly > MG_V1_TURN_OFF_DLY)
    {
      FLG_V1_PRISYS_CONDITION = 0;
    }
    else
    {
      mg_u16V1TurnOffDly++;
      FLG_B_V1_PWOK_GOOD = FALSE;
    }
  }
}

/*******************************************************************************
 * \brief         control 5VSTB status
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *100us
 *******************************************************************************/
void PSUstate_5VSTBStatusControl(void)
{  
  PROTECT_5VSTBDetect();
  PROTECT_5VSTBCurrDetect();
  PSUstate_5VSBOnOffJudge();
  if(FALSE != FLG_5VSTB_FAULT_CONDITION)
  {
    PORT_OUT_5VSB_DIS;
  }

}


