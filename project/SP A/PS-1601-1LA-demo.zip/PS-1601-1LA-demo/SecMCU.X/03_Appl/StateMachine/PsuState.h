/* 
 * File:   PsuState.h
 * Author: 
 *
 * 
 */

#ifndef PSUSTATE_H
#define	PSUSTATE_H

#ifdef	__cplusplus
extern "C" {
#endif

/*******************************************************************************
 * Included header
 ******************************************************************************/

/*******************************************************************************
 * Local constants and macros (private to module)
 ******************************************************************************/



/*******************************************************************************
 * Global data types (globals / structs / enums)
 ******************************************************************************/

    typedef enum MG_V1_CTRL_STA_ {
        PSU_INIT = 0,
        PSU_CTRL_V1_OFF,
        PSU_CTRL_V1_UP,
        PSU_CTRL_V1_RUN,
    } MG_V1_CTRL_STA;


 
/*******************************************************************************
 * Global data
 ******************************************************************************/


/*******************************************************************************
 * Global function prototypes
 ******************************************************************************/
    extern void PSU_mg_V1PwrOn(void);
    extern void PSU_mg_V1PwrOff(void);
    extern void PSUstate_V1StatusControl(void);
    extern void PSUstate_DataInit();


#ifdef	__cplusplus
}
#endif

#endif	/* PSUSTATE_H */

