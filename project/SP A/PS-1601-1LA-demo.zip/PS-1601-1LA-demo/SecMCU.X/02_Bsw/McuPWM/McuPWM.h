/* 
 * File:   McuPWM.h
 * Author: 
 *
 * 
 */

#ifndef MCUPWM_H
#define	MCUPWM_H

#ifdef	__cplusplus
extern "C" {
#endif

    /*******************************************************************************
     * Included header
     ******************************************************************************/
#include "global.h"

    /*******************************************************************************
     * Global constants and macros
     ******************************************************************************/

    /*******************************************************************************
     * Global data types (globals / structs / enums)
     ******************************************************************************/
#define PWM_LLC_DUTY_REG           PDC5
#define PWM_LLC_PERIOD_REG         PTPER
#define PWM_V1_HB_ENABLE_H_REG     IOCON5bits.PENH
#define PWM_V1_HB_ENABLE_L_REG     IOCON5bits.PENL  
#define PWM_SPECIAL_EVENT_REG      PTCONbits.SEIEN     /* Enable Special Event Interrupt to update PWM */
#define PWM_INTERR_FLAG_REG        IFS3bits.PSEMIF     /* PWM Interrupt FLAG, clear by FW */    
    /*******************************************************************************
     * Global data
     ******************************************************************************/

    /*******************************************************************************
     * Global function prototypes
     ******************************************************************************/
    extern void Mcu_PwmHwInit(void);


#ifdef	__cplusplus
}
#endif

#endif	/* MCUPWM_H */

