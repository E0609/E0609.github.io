/*******************************************************************************
 * \file    McuGPIO.c
 * \brief   MCU IO port configurations
 *
 * \section AUTHOR
 *    1.shuangcai
 *
 * \section SVN
 *  $Date$
 *  $Author$
 *  $Revision$
 *
 * \section LICENSE
 * Copyright (c) Lite-On Singapore Pte Ltd
 * All rights reserved.
 ******************************************************************************/
#include <p33EP64GS504.h>
/*******************************************************************************
 * Included header
 ******************************************************************************/

/* Module header */
#include "McuGPIO.h"

/*******************************************************************************
 * Local constants and macros (private to module)
 ******************************************************************************/

/*******************************************************************************
 * Local data types (private globals / structs / enums)
 ******************************************************************************/

/*******************************************************************************
 * Local data (private to module)
 ******************************************************************************/

/*******************************************************************************
 * Global data (public to other modules)
 ******************************************************************************/

/*******************************************************************************
 * Local function prototypes (private to module)
 ******************************************************************************/

/*******************************************************************************
 * Global functions (public to other modules)
 ******************************************************************************/

/*******************************************************************************
 * Local functions (private to module)
 ******************************************************************************/

/*******************************************************************************
 * Function:        Mcu_GPIOHwInit
 *
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     Initialize the general purpose IO (GPIO)
 *
 ******************************************************************************/
void Mcu_GPIOHwInit(void)
{
  /* Set PORT as input or output    * 1 = input (default)   * 0 = output */

  LATA = 0x0000;
  TRISA = 0xffff;   //MG_PIN_INPUT_DIRECTION;
  ANSELA = 0x0000;  //MG_PIN_DIGITAL;
  /* 12V_BEF_OR */
  TRISAbits.TRISA0 = MG_PIN_INPUT_DIRECTION;
  ANSELAbits.ANSA0 = MG_PIN_ANALOG;

  /* I_OUT */
  TRISAbits.TRISA1 = MG_PIN_INPUT_DIRECTION;
  ANSELAbits.ANSA1 = MG_PIN_ANALOG;

  /* ISHARE_OUT_READ */
  TRISAbits.TRISA2 = MG_PIN_INPUT_DIRECTION;
  ANSELAbits.ANSA2 = MG_PIN_ANALOG;

   /*LLC_EN_MCU*/
  TRISAbits.TRISA3 = MG_PIN_OUTPUT_DIRECTION;

  /* FAN_PWM */
  TRISAbits.TRISA4 = MG_PIN_OUTPUT_DIRECTION;

  LATB = 0x0000;
  TRISB = 0xffff;   //MC_PIN_INPUT_DIRECTION;
  ANSELB = 0x0000;  //MC_PIN_DIGITAL;
  /* ISHARE_INT */
  TRISBbits.TRISB0 = MG_PIN_INPUT_DIRECTION;
  ANSELBbits.ANSB0 = MG_PIN_ANALOG;

  /* ORING_EN */
  TRISBbits.TRISB1 = MG_PIN_OUTPUT_DIRECTION; 

  /* STB_5V_DET*/
  TRISBbits.TRISB2 = MG_PIN_INPUT_DIRECTION;
  ANSELBbits.ANSB2 = MG_PIN_ANALOG;
  
  /* ISHARE_OUT */
  TRISBbits.TRISB3 = MG_PIN_OUTPUT_DIRECTION;
  ANSELBbits.ANSB3 = MG_PIN_ANALOG;

  /* not used */
  TRISBbits.TRISB4 = MG_PIN_INPUT_DIRECTION;

  /* LED */
  TRISBbits.TRISB5 = MG_PIN_OUTPUT_DIRECTION;

  /* PGED_SEC  */
  TRISBbits.TRISB6 = MG_PIN_INPUT_DIRECTION;
  ANSELBbits.ANSB6 = MG_PIN_DIGITAL;

  /* PGEC_SEC */
  TRISBbits.TRISB7 = MG_PIN_INPUT_DIRECTION;
  ANSELBbits.ANSB7 = MG_PIN_DIGITAL;

  /* EEPROM_SDA */
  //TRISBbits.TRISB8 = MG_PIN_INPUT_DIRECTION;
  TRISBbits.TRISB8 = MG_PIN_INPUT_DIRECTION;  //temp us as uart Rx
  
  /* 12V_MAIN */
  TRISBbits.TRISB9 = MG_PIN_INPUT_DIRECTION;
  ANSELBbits.ANSB9 = MG_PIN_ANALOG;

    /* STB_I_SENSE */
  TRISBbits.TRISB10 = MG_PIN_INPUT_DIRECTION;       
  ANSELBbits.ANSB10 = MG_PIN_ANALOG;
  
  /* S_DEBUG*/
  TRISBbits.TRISB11 = MG_PIN_OUTPUT_DIRECTION;

  /* PGOOD */
  TRISBbits.TRISB12 = MG_PIN_OUTPUT_DIRECTION;

  /* 12V_TRIM_PWM */
  TRISBbits.TRISB13 = MG_PIN_OUTPUT_DIRECTION;

  /* FAN_SPEED */
  TRISBbits.TRISB14 = MG_PIN_INPUT_DIRECTION;

  /* EEPROM_SCL */
  //TRISBbits.TRISB15 = MG_PIN_INPUT_DIRECTION;
  TRISBbits.TRISB15 = MG_PIN_OUTPUT_DIRECTION;  //temp use as uart Tx
  LATC = 0x0000;
  TRISC = 0xffff;   //MC_PIN_INPUT_DIRECTION;
  ANSELC = 0x0000;  //MC_PIN_DIGITAL;
  /* Set PORTC as input or output */
  
  /* AC_OK_IN*/
  TRISCbits.TRISC0 = MG_PIN_INPUT_DIRECTION;
  ANSELCbits.ANSC0 = MG_PIN_DIGITAL;
  /* 5Vsb_EN */
  TRISCbits.TRISC1 = MG_PIN_OUTPUT_DIRECTION;

  /*AC_OK_OUT */
  TRISCbits.TRISC2 = MG_PIN_OUTPUT_DIRECTION;

  /* PS_A0 */
  TRISCbits.TRISC3 = MG_PIN_INPUT_DIRECTION;
  ANSELCbits.ANSC4 = MG_PIN_DIGITAL;
  
  /* PS_A1  */
  TRISCbits.TRISC4 = MG_PIN_INPUT_DIRECTION;
  ANSELCbits.ANSC4 = MG_PIN_DIGITAL;

  /* PS_A2 */
  TRISCbits.TRISC5 = MG_PIN_INPUT_DIRECTION;
  ANSELCbits.ANSC5 = MG_PIN_DIGITAL;

  /* PS_ON */
  TRISCbits.TRISC6 = MG_PIN_INPUT_DIRECTION;
  ANSELCbits.ANSC6 = MG_PIN_DIGITAL;
  
  /* PMBUS_SDA */
  TRISCbits.TRISC7 = MG_PIN_INPUT_DIRECTION;

  /* PMBUS_SCL */
  TRISCbits.TRISC8 = MG_PIN_INPUT_DIRECTION;

  /* SEC_Rx */
  TRISCbits.TRISC9 = MG_PIN_INPUT_DIRECTION;

  /* SEC_Tx*/
  TRISCbits.TRISC10 = MG_PIN_OUTPUT_DIRECTION;

    /* T_SR */
  TRISCbits.TRISC11 = MG_PIN_INPUT_DIRECTION;      // NA in 706
  ANSELCbits.ANSC11 = MG_PIN_ANALOG;
  
  /* SR_En */
  TRISCbits.TRISC12 = MG_PIN_OUTPUT_DIRECTION;
 
  /* PFC_OK_IN */
  TRISCbits.TRISC13 = MG_PIN_INPUT_DIRECTION;
  
  /*
   * Set PORTx as open-drain or push-pull
   * 1 = open-drain (5V)
   * 0 = push-pull  (default)
   */
  ODCCbits.ODCC7 = 1; // PMBUS_SDA
  ODCCbits.ODCC8 = 1; // PMBUS_SCL
  //ODCBbits.ODCB15 = 1; //EEPROM_SCL //temp use as Uart
  //ODCBbits.ODCB8 = 1; //EEPROM_SDA  //temp use as Uart

}

