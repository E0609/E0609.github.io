/**
  UART2 Generated Driver File 

  @Company
    Microchip Technology Inc.

  @File Name
    uart2.c

  @Summary
    This is the generated source file for the UART2 driver using PIC24 / dsPIC33 / PIC32MM MCUs

  @Description
    This source file provides APIs for driver for UART2. 
    Generation Information : 
        Product Revision  :  PIC24 / dsPIC33 / PIC32MM MCUs - 1.167.0
        Device            :  dsPIC33EP64GS506
    The generated drivers are tested against the following:
        Compiler          :  XC16 v1.50
        MPLAB             :  MPLAB X v5.35
*/

/*
    (c) 2020 Microchip Technology Inc. and its subsidiaries. You may use this
    software and any derivatives exclusively with Microchip products.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION
    WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

    MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE
    TERMS.
*/

/**
  Section: Included Files
*/
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include "xc.h"
#include "McuUart2.h"
#include "../RealtimeVar/Define.h"
#include "../McuClock/McuClock.h"
#include "UartComm.h"
/**
  Section: Data Type Definitions
*/

/** UART Driver Queue Status

  @Summary
    Defines the object required for the status of the queue.
*/

static uint8_t * volatile rxTail;
static uint8_t *rxHead;
static uint8_t *txTail;
static uint8_t * volatile txHead;
static bool volatile rxOverflowed;
//Rx
UART_FLAGS UART_2;
unsigned char Rx_Timeout = 0, Rx_State = 0, Rx_Len = 0, Rx_Pntr = 0;
unsigned char Rx_Buf[COMM_BUF_SIZE], Rx_CRC8 = 0;


//Tx 
unsigned int Tx_Start_Count = 0;
unsigned char Tx_Timeout = 0, Tx_State = 0, Tx_Pntr = 0, Tx_Wait_Count = 0,Tx_add=0;
unsigned char Tx_CRC8 = 0, Tx_Buf[32], Tx_Seq = 0;
/** UART Driver Queue Length

  @Summary
    Defines the length of the Transmit and Receive Buffers

*/

/* We add one extra byte than requested so that we don't have to have a separate
 * bit to determine the difference between buffer full and buffer empty, but
 * still be able to hold the amount of data requested by the user.  Empty is
 * when head == tail.  So full will result in head/tail being off by one due to
 * the extra byte.
 */
#define UART2_CONFIG_TX_BYTEQ_LENGTH (8+1)
#define UART2_CONFIG_RX_BYTEQ_LENGTH (8+1)

/** UART Driver Queue

  @Summary
    Defines the Transmit and Receive Buffers

*/

static uint8_t txQueue[UART2_CONFIG_TX_BYTEQ_LENGTH];
static uint8_t rxQueue[UART2_CONFIG_RX_BYTEQ_LENGTH];

void (*UART2_TxDefaultInterruptHandler)(void);
void (*UART2_RxDefaultInterruptHandler)(void);

/**
  Section: Driver Interface
*/

void UART2_Initialize(void)
{/*
    IEC1bits.U2TXIE = 0;
    IEC1bits.U2RXIE = 0;

    // STSEL 1; IREN disabled; PDSEL 8N; UARTEN enabled; RTSMD disabled; USIDL disabled; WAKE disabled; ABAUD disabled; LPBACK disabled; BRGH enabled; URXINV disabled; UEN TX_RX; 
    // Data Bits = 8; Parity = None; Stop Bits = 1;
    U2MODE = (0x8008 & ~(1<<15));  // disabling UART ON bit
    // UTXISEL0 TX_ONE_CHAR; UTXINV disabled; OERR NO_ERROR_cleared; URXISEL RX_ONE_CHAR; UTXBRK COMPLETED; UTXEN disabled; ADDEN disabled; 
    U2STA = 0x00;
    // BaudRate = 9600; Frequency = 1842500 Hz; BRG 47; 
    U2BRG = 0x2F;
    
    txHead = txQueue;
    txTail = txQueue;
    rxHead = rxQueue;
    rxTail = rxQueue;
   
    rxOverflowed = false;

    UART2_SetTxInterruptHandler(&UART2_Transmit_CallBack);

    UART2_SetRxInterruptHandler(&UART2_Receive_CallBack);

    IEC1bits.U2RXIE = 1;
    
    //Make sure to set LAT bit corresponding to TxPin as high before UART initialization
    U2MODEbits.UARTEN = 1;   // enabling UART ON bit
    U2STAbits.UTXEN = 1;
  */
    
}
#define MG_UART1_BAUD_RATE_SET      (((59881250 / 9600U)>>4) - 1UL)
void Mcu_Uart2HwInit(void)
{

  U2MODEbits.UARTEN = 0; /* Bit15 TX, RX DISABLED, ENABLE at end of func */
  U2MODEbits.USIDL = 0; /* Bit13 Continue in Idle */
  U2MODEbits.IREN = 0; /* Bit12 No IR translation */
  U2MODEbits.RTSMD = 0; /* Bit11 Simplex Mode */
  U2MODEbits.UEN = 0; /* Bits8, 9 TX,RX enabled, CTS,RTS not */
  U2MODEbits.WAKE = 0; /* Bit7 No wake up */
  U2MODEbits.LPBACK = 0; /* Bit6 No loop back */
  U2MODEbits.ABAUD = 0; /* Bit5 No autobaud */
  U2MODEbits.URXINV = 0; /* Bit4 IdleState = 1 */
  U2MODEbits.BRGH = 0; /* Bit3 16 clocks per bit period */
  U2MODEbits.PDSEL = 0; /* Bits1, 2 8bit, No Parity */
  U2MODEbits.STSEL = 0; /* Bit0 One Stop Bit */

  U2BRG = 0x184;//MG_UART1_BAUD_RATE_SET; /* Set baudrate */

  /* Load all values in for U1STA SFR */
  U2STAbits.UTXISEL1 = 0; /* Bit15 Interrupt when char is transferred */
  U2STAbits.UTXINV = 0; /* Bit14 N/A, IRDA config */
  U2STAbits.UTXISEL0 = 0; /* Bit13 Interrupt when char is transferred */
  U2STAbits.UTXBRK = 0; /* Bit11 Disabled */
  U2STAbits.UTXEN = 0; /* Bit10 TX pins controlled by io port */
  U2STAbits.URXISEL = 0; /* Bits6, 7 Interrupt on character received */
  U2STAbits.ADDEN = 0; /* Bit5 Address detect disabled */

  /* Init interrupt functions */
  //  IPC2bits.U1RXIP    = UART_RX_INT_PRIO;
  //  IPC3bits.U1TXIP    = UART_TX_INT_PRIO;
  IFS1bits.U2TXIF = 0; /* Clear transmit interrupt flag */
  IEC1bits.U2TXIE = 0; /* Enable transmit interrupt */
  IFS1bits.U2RXIF = 0; /* Clear receive interrupt flag */
  IEC1bits.U2RXIE = 1; /* Enable receive interrupt */

  U2MODEbits.UARTEN = 1; /* Enable uart */
  U2STAbits.UTXEN = 1; /* Enable tranmitter */
}
/**
    Maintains the driver's transmitter state machine and implements its ISR
*/

void UART2_SetTxInterruptHandler(void* handler)
{
    if(handler == NULL)
    {
        UART2_TxDefaultInterruptHandler = &UART2_Transmit_CallBack;
    }
    else
    {
        UART2_TxDefaultInterruptHandler = handler;
    }
} 

void __attribute__ ( ( interrupt, no_auto_psv ) ) _U2TXInterrupt ( void )
{
    if(UART2_TxDefaultInterruptHandler)
    {
        UART2_TxDefaultInterruptHandler();
    }

    if(txHead == txTail)
    {
        IEC1bits.U2TXIE = 0;
    }
    else
    {
        IFS1bits.U2TXIF = 0;

        while(!(U2STAbits.UTXBF == 1))
        {
            U2TXREG = *txHead++;

            if(txHead == (txQueue + UART2_CONFIG_TX_BYTEQ_LENGTH))
            {
                txHead = txQueue;
            }

            // Are we empty?
            if(txHead == txTail)
            {
                break;
            }
        }
    }
}

void __attribute__ ((weak)) UART2_Transmit_CallBack ( void )
{ 

}

void UART2_SetRxInterruptHandler(void* handler)
{
    if(handler == NULL)
    {
        UART2_RxDefaultInterruptHandler = &UART2_Receive_CallBack;
    }
    else
    {
        UART2_RxDefaultInterruptHandler = handler;
    }
}

void __attribute__ ( ( interrupt, no_auto_psv ) ) _U2RXInterrupt( void )
{
    if(UART2_RxDefaultInterruptHandler)
    {
        UART2_RxDefaultInterruptHandler();
    }
    
    IFS1bits.U2RXIF = 0;
	
    while((U2STAbits.URXDA == 1))
    {
        *rxTail = U2RXREG;

        // Will the increment not result in a wrap and not result in a pure collision?
        // This is most often condition so check first
        if ( ( rxTail    != (rxQueue + UART2_CONFIG_RX_BYTEQ_LENGTH-1)) &&
             ((rxTail+1) != rxHead) )
        {
            rxTail++;
        } 
        else if ( (rxTail == (rxQueue + UART2_CONFIG_RX_BYTEQ_LENGTH-1)) &&
                  (rxHead !=  rxQueue) )
        {
            // Pure wrap no collision
            rxTail = rxQueue;
        } 
        else // must be collision
        {
            rxOverflowed = true;
        }
    }
}

void __attribute__ ((weak)) UART2_Receive_CallBack(void)
{

}

void __attribute__ ( ( interrupt, no_auto_psv ) ) _U2ErrInterrupt( void )
{
    if ((U2STAbits.OERR == 1))
    {
        U2STAbits.OERR = 0;
    }
    
    IFS4bits.U2EIF = 0;
}

/**
  Section: UART Driver Client Routines
*/

uint8_t UART2_Read( void)
{
    uint8_t data = 0;

    while (rxHead == rxTail )
    {
    }
    
    data = *rxHead;

    rxHead++;

    if (rxHead == (rxQueue + UART2_CONFIG_RX_BYTEQ_LENGTH))
    {
        rxHead = rxQueue;
    }
    return data;
}

void UART2_Write( uint8_t byte)
{
    while(UART2_IsTxReady() == 0)
    {
    }

    *txTail = byte;

    txTail++;
    
    if (txTail == (txQueue + UART2_CONFIG_TX_BYTEQ_LENGTH))
    {
        txTail = txQueue;
    }

    IEC1bits.U2TXIE = 1;
}

bool UART2_IsRxReady(void)
{    
    return !(rxHead == rxTail);
}

bool UART2_IsTxReady(void)
{
    uint16_t size;
    uint8_t *snapshot_txHead = (uint8_t*)txHead;
    
    if (txTail < snapshot_txHead)
    {
        size = (snapshot_txHead - txTail - 1);
    }
    else
    {
        size = ( UART2_CONFIG_TX_BYTEQ_LENGTH - (txTail - snapshot_txHead) - 1 );
    }
    
    return (size != 0);
}

bool UART2_IsTxDone(void)
{
    if(txTail == txHead)
    {
        return (bool)U2STAbits.TRMT;
    }
    
    return false;
}


/*******************************************************************************

  !!! Deprecated API !!!
  !!! These functions will not be supported in future releases !!!

*******************************************************************************/

static uint8_t UART2_RxDataAvailable(void)
{
    uint16_t size;
    uint8_t *snapshot_rxTail = (uint8_t*)rxTail;
    
    if (snapshot_rxTail < rxHead) 
    {
        size = ( UART2_CONFIG_RX_BYTEQ_LENGTH - (rxHead-snapshot_rxTail));
    }
    else
    {
        size = ( (snapshot_rxTail - rxHead));
    }
    
    if(size > 0xFF)
    {
        return 0xFF;
    }
    
    return size;
}

static uint8_t UART2_TxDataAvailable(void)
{
    uint16_t size;
    uint8_t *snapshot_txHead = (uint8_t*)txHead;
    
    if (txTail < snapshot_txHead)
    {
        size = (snapshot_txHead - txTail - 1);
    }
    else
    {
        size = ( UART2_CONFIG_TX_BYTEQ_LENGTH - (txTail - snapshot_txHead) - 1 );
    }
    
    if(size > 0xFF)
    {
        return 0xFF;
    }
    
    return size;
}

unsigned int __attribute__((deprecated)) UART2_ReadBuffer( uint8_t *buffer ,  unsigned int numbytes)
{
    unsigned int rx_count = UART2_RxDataAvailable();
    unsigned int i;
    
    if(numbytes < rx_count)
    {
        rx_count = numbytes;
    }
    
    for(i=0; i<rx_count; i++)
    {
        *buffer++ = UART2_Read();
    }
    
    return rx_count;    
}

unsigned int __attribute__((deprecated)) UART2_WriteBuffer( uint8_t *buffer , unsigned int numbytes )
{
    unsigned int tx_count = UART2_TxDataAvailable();
    unsigned int i;
    
    if(numbytes < tx_count)
    {
        tx_count = numbytes;
    }
    
    for(i=0; i<tx_count; i++)
    {
        UART2_Write(*buffer++);
    }
    
    return tx_count;  
}

UART2_TRANSFER_STATUS __attribute__((deprecated)) UART2_TransferStatusGet (void )
{
    UART2_TRANSFER_STATUS status = 0;
    uint8_t rx_count = UART2_RxDataAvailable();
    uint8_t tx_count = UART2_TxDataAvailable();
    
    switch(rx_count)
    {
        case 0:
            status |= UART2_TRANSFER_STATUS_RX_EMPTY;
            break;
        case UART2_CONFIG_RX_BYTEQ_LENGTH:
            status |= UART2_TRANSFER_STATUS_RX_FULL;
            break;
        default:
            status |= UART2_TRANSFER_STATUS_RX_DATA_PRESENT;
            break;
    }
    
    switch(tx_count)
    {
        case 0:
            status |= UART2_TRANSFER_STATUS_TX_FULL;
            break;
        case UART2_CONFIG_RX_BYTEQ_LENGTH:
            status |= UART2_TRANSFER_STATUS_TX_EMPTY;
            break;
        default:
            break;
    }

    return status;    
}

uint8_t __attribute__((deprecated)) UART2_Peek(uint16_t offset)
{
    uint8_t *peek = rxHead + offset;
    
    while(peek > (rxQueue + UART2_CONFIG_RX_BYTEQ_LENGTH))
    {
        peek -= UART2_CONFIG_RX_BYTEQ_LENGTH;
    }
    
    return *peek;
}

bool __attribute__((deprecated)) UART2_ReceiveBufferIsEmpty (void)
{
    return (UART2_RxDataAvailable() == 0);
}

bool __attribute__((deprecated)) UART2_TransmitBufferIsFull(void)
{
    return (UART2_TxDataAvailable() == 0);
}

uint16_t __attribute__((deprecated)) UART2_StatusGet (void)
{
    return U2STA;
}

unsigned int __attribute__((deprecated)) UART2_TransmitBufferSizeGet(void)
{
    if(UART2_TxDataAvailable() != 0)
    { 
        if(txHead > txTail)
        {
            return((txHead - txTail) - 1);
        }
        else
        {
            return((UART2_CONFIG_TX_BYTEQ_LENGTH - (txTail - txHead)) - 1);
        }
    }
    return 0;
}

unsigned int __attribute__((deprecated)) UART2_ReceiveBufferSizeGet(void)
{
    if(UART2_RxDataAvailable() != 0)
    {
        if(rxHead > rxTail)
        {
            return((rxHead - rxTail) - 1);
        }
        else
        {
            return((UART2_CONFIG_RX_BYTEQ_LENGTH - (rxTail - rxHead)) - 1);
        } 
    }
    return 0;
}

void __attribute__((deprecated)) UART2_Enable(void)
{
    U2MODEbits.UARTEN = 1;
    U2STAbits.UTXEN = 1;
}

void __attribute__((deprecated)) UART2_Disable(void)
{
    U2MODEbits.UARTEN = 0;
    U2STAbits.UTXEN = 0;
}

/*******************************************************************************
 * Function:        SendByte
 * Parameters:      mode for CRC, data for tranmission
 * Returned value:  -
 * Description:     Handle the byte transmission, calculate the CRC and then TX.
 * Calling:
 ******************************************************************************/
void SendByte(unsigned char data)
{

    Tx_CRC8 = UART_CRC8(Tx_CRC8, data);    
    U2TXREG = data;
}


/*******************************************************************************
 * Function:        Process_RxData
 * Description:     Handle the Received Bytes Called from 10mS Loop
 * Calling:         every 10ms
 ******************************************************************************/

void Process_RxData(void)
{

#if 1

    static unsigned int Boot_Set_Count = 0;
//    unsigned char Temp_ui8;
    

    //Handle Rx Timeout
    if(UART_2.Rx_Timeout_En == TRUE)
    {

        Rx_Timeout++;
        if(Rx_Timeout > COMM_RX_TIMEOUT)
        {            
            Rx_State = RX_START;                
            UART_2.Rx_Timeout_En = FALSE;
        }
    }
    else
        Rx_Timeout = 0;
    

    if(UART_2.RX_Data_Rdy == TRUE)  
    {
        UART_2.RX_Data_Rdy = FALSE;
    }  
	#endif
}
/************************************************************************************
 * Function:        Process_TxData
 * Description:     Send data for transmission to Secondary side.calling every 1ms
 ***********************************************************************************/


void Process_TxData(void)
{

    if ((U2STAbits.PERR == TRUE) && (U2STAbits.FERR == TRUE))
        Mcu_Uart2HwInit();

    if(!UART_2.Tx_Startup)
    {
        Tx_Start_Count++;
        if(Tx_Start_Count > TX_STARTUP_DELAY)
        {

            Tx_Start_Count = 0;
            UART_2.Tx_Startup = 1;
        }

    }
    else if(!UART_2.Tx_Data_Ready)
    {        
        Tx_State = SEND_KEY;
        Tx_Pntr = 0;
        UART_2.Tx_Data_Ready = TRUE;    
    }
        
    if(UART_2.Tx_Wait)
    {
        Tx_Wait_Count++;
        if(Tx_Wait_Count > TX_WAIT_DELAY) //Between each Tx Packet
        {

            UART_2.Tx_Wait = 0;
            Tx_Wait_Count = 0;
        }

    }    
    else if(UART_2.Tx_Data_Ready) //Send Total 10 Bytes
    {

        if(U2STAbits.TRMT == TRUE) 
        {

            switch(Tx_State)
            {
                case TX_IDLE:
                    //do nothing
                    break;
                case SEND_KEY://1 Byte Key
                    Tx_CRC8 = 0;
                    //SendByte(0xAA); //for test
					//SendByte(0x51); //for test
					//SendByte(0x1C); //for test
                    Tx_State = SEND_ADDR;
                    break;
                case SEND_ADDR://1 Byte Address
                	if(Tx_add > 13)//13
                	{
                    	Tx_State = SEND_DATA;
                        Tx_add = 0;
                	}
                   // SendByte(0xFF); //for test
                    Tx_add++;
                    break;
                case SEND_DATA: //7 Bytes - 1 Byte Index and 6 Bytes Data
                    SendByte(Tx_Buf[Tx_Pntr++]); 
                    if(Tx_Pntr > 7)//13
                    {
                        Tx_State = SEND_CRC8;
                        Tx_Pntr = 0;
                    }
                    break;
                case SEND_CRC8://1 Byte CRC8 from 0 - 8
                   // SendByte(Tx_CRC8);  //for test
                    Tx_State = WAIT_2_END_TX;
                    break;
                case WAIT_2_END_TX:   
                    Tx_State = TX_IDLE;
                    UART_2.Tx_Data_Ready = 0;
                    UART_2.Tx_Wait = 1; 
                    break;
                default:              
                    Tx_State = TX_IDLE;
                    UART_2.Tx_Data_Ready = 0;
                    UART_2.Tx_Wait = 1;       
                    break;
            }
            Tx_Timeout = 0;
        }

        else if(UART_2.Tx_Data_Ready) //Transmit Timeout
        {

            //Transmit Timeout Routine
            Tx_Timeout = 0;
            
        }
    }           
} 
