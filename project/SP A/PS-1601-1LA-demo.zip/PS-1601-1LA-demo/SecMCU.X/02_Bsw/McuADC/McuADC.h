/* 
 * File:   McuADC.h
 * Author: 
 *
 * Created on March 23, 2021, 10:17 AM
 */

#ifndef MCUADC_H
#define	MCUADC_H

#ifdef	__cplusplus
extern "C" {
#endif

/*******************************************************************************
 * Global data types (globals / structs / enums)
 ******************************************************************************/
/* V1 sample for loop calculation */
#define ADC_V1_VOLT_EXT      ADCBUF4    /* V1 feedback voltage after oring */
#define ADC_V1_VOLT_VEA      ADCBUF0    /* V1 feedback voltage before oring //for control loop */
#define ADC_I1_CURR          ADCBUF1    /* V1 output current */
//#define ADC_VSENSE           ADCBUF6
//#define ADC_VTRIM            ADCBUF 
    
/* Vsb 5V feedback */
#define ADC_VSB_VOLT         ADCBUF7   /* Vsb feedback voltage */
#define ADC_VSB_CURR         ADCBUF5  /* Vsb feedback current */
    
/* Ilocal and Ishare sample for current share */
#define ADC_ISHARE_BUS       ADCBUF2    /* iBus sample for current share */
#define ADC_ISHARE_LOCAL     ADCBUF3    /* iLocal sample for current share */

/* NTC and others sample */
//#define ADC_NTC_AMB          ADCBUF10    /* Ambient temperature sample*/
#define ADC_NTC_SR             ADCBUF12    /* SR temperature sample*/ 
           
/*******************************************************************************
 * Global function prototypes
 ******************************************************************************/

extern void Mcu_ADCHwInit(void);
extern void Mcu_CMPHwInit(void);


#ifdef	__cplusplus
}
#endif

#endif	/* MCUADC_H */

