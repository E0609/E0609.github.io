/* 
 * File:   Main.h
 * Author: Kiran
 *
 * Created on March 19, 2021, 1:19 PM
 */

#ifndef MAIN_H
#define	MAIN_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* MAIN_H */

