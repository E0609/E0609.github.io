/*
 * File:   Main.c
 * Author: Kiran 123
 *
 * Created on March 19, 2021, 1:18 PM
 */


#include "xc.h"
#include <p33EP64GS504.h>

#include "Main.h"
#include "McuClock.h"
#include "McuGPIO.h"
#include "McuADC.h"
#include "McuDAC.h"
#include "McuTimer.h"
#include "McuPWM.h"
#include "Protection.h"
#include "Timer_ISR.h"
#include "PsuState.h"
#include "Sample.h"
#include "McuUart2.h"
#include "i2c1.h"

/*  ------------------------------------------------------------------------------
  Module               : Mcu_RemapPinInit.c
  Function             :
  Modification history :
  ------------------------------------------------------------------------------
  Description          : Main function
  ------------------------------------------------------------------------------
  Input                : -
  Output               : -
  Modified Variables   : -
  Calling              : -
------------------------------------------------------------------------------*/
void Mcu_RemapPinInit(void)
{
  __builtin_write_OSCCONL(OSCCON & 0xbf); /* Unlock register for remap pin configuration */

  /* UART pin remap */
  
  RPOR13bits.RP58R = 0x0001;    //RC10->UART1:U1TX
  RPINR18bits.U1RXR = 0x0039;    //RC9->UART1:U1RX

  RPINR19bits.U2RXR = 0x0028;    //RB8->UART2:U2RX
  RPOR7bits.RP47R = 0x0003;    //RB15->UART2:U2TX

  RPINR7bits.IC1R = 0x002E;  //RB14 - > IC1
  __builtin_write_OSCCONL(OSCCON | 0x40); /* Lock register */
}

/*  ------------------------------------------------------------------------------
  Module               : Main.c
  Function             :
  Modification history : 
  ------------------------------------------------------------------------------
  Description          : Main function
  ------------------------------------------------------------------------------
  Input                : -
  Output               : -
  Modified Variables   : -
  Calling              : -
------------------------------------------------------------------------------*/

int main(void) {
    
  /* System configuration */
  Mcu_SysClkHwInit();
  PROTECT_DataInit();
  Mcu_RemapPinInit();

  
/* uC peripheral configuration */
  Mcu_GPIOHwInit();
  Mcu_Uart2HwInit();
  UART1_Initialize();
  Mcu_ADCHwInit();
  Mcu_TMRHwInit();
  Mcu_PwmHwInit();
  Mcu_DACHwInit();
  Mcu_CMPHwInit();
  I2C1_Initialize();
  

  TIMER_SchDataInit();
  EnableFan();
  /* Appl data initialization */
  PSUstate_DataInit();
 // InitCtrlLoop();
  
  while (1)
  {

      Nop();

  } /* while (1) */
}
