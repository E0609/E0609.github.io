/** *****************************************************************************
 * \file    McuDAC.c
 * \brief   MCU DAC configurations
 *
 * \section AUTHOR
 *    1. 
 *
 * \section SVN
 *  $Date$
 *  $Author$
 *  $Revision$
 *
 * \section LICENSE
 * Copyright (c) Lite-On Singapore Pte Ltd
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * Included header
 ******************************************************************************/
#include <p33EP64GS504.h>



void Mcu_DACHwInit(void);
/*******************************************************************************
 * \brief         Initialize and configure the cmp's
 *
 * \param[in]     -
 * \param[in,out] -
 * \param[out]    -
 *
 * \return        -
 *
 *******************************************************************************/
void Mcu_DACHwInit(void)
{
//The following code example will set the Input Capture1 module for interrupts on every
//second capture event; captured on every fourth rising edge. The clock source for the timer
//would be the system clock. Sync/Trig source is disabled.
//Setup Input Capture1 interrupt for desired priority level (this example assigns level 1
//priority)
IFS0bits.IC1IF = 0; // Clear the IC1 interrupt status flag
IEC0bits.IC1IE = 0; // Enable IC1 interrupts
IPC0bits.IC1IP = 1; // Set module interrupt priority as 1
IC1CON1bits.ICSIDL = 0; // Input capture will continue to operate in CPU idle mode
IC1CON1bits.ICTSEL = 0; //0:timer3 //0b111 Peripheral (FP) is the clock source for the IC1 module
IC1CON1bits.ICI = 1; // Interrupt on every capture event
IC1CON1bits.ICBNE = 0; // Input capture is empty
IC1CON1bits.ICM = 0b100; // Capture mode; every fourth rising edge (Prescaler Capture mode)
IC1CON2bits.IC32 = 0; // Cascade module operation is disabled
IC1CON2bits.ICTRIG = 0; // Input source used to synchronize the input capture timer of
// another module (Synchronization mode)
IC1CON2bits.TRIGSTAT = 0; // IC1TMR has not been triggered and is being held clear
IC1CON2bits.SYNCSEL = 0; // No Sync or Trigger source for the IC1 module
// The following code shows how to read the capture buffer when
// an interrupt is generated.
// Example code for Input Capture 1 ISR:
}

