/**
  UART1 Generated Driver File 

  @Company
    Microchip Technology Inc.

  @File Name
    uart1.c

  @Summary
    This is the generated source file for the UART1 driver using PIC24 / dsPIC33 / PIC32MM MCUs

  @Description
    This source file provides APIs for driver for UART1. 
    Generation Information : 
        Product Revision  :  PIC24 / dsPIC33 / PIC32MM MCUs - 1.167.0
        Device            :  dsPIC33EP64GS504
    The generated drivers are tested against the following:
        Compiler          :  XC16 v1.50
        MPLAB             :  MPLAB X v5.35
*/

/*
    (c) 2020 Microchip Technology Inc. and its subsidiaries. You may use this
    software and any derivatives exclusively with Microchip products.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION
    WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

    MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE
    TERMS.
*/

/**
  Section: Included Files
*/
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include "xc.h"
#include "McuUart1.h"
#include "global.h"
#include "../RealtimeVar/Define.h"
#include "../McuClock/McuClock.h"
#include "UartComm.h"
#include "McuUart2.h"
#include "Pmbus.h"
/**
  Section: Data Type Definitions
*/

/** UART Driver Queue Status

  @Summary
    Defines the object required for the status of the queue.
*/

static uint8_t * volatile rxTail;
static uint8_t *rxHead;
static uint8_t *txTail;
static uint8_t * volatile txHead;
static bool volatile rxOverflowed;

/** UART Driver Queue Length

  @Summary
    Defines the length of the Transmit and Receive Buffers

*/

/* We add one extra byte than requested so that we don't have to have a separate
 * bit to determine the difference between buffer full and buffer empty, but
 * still be able to hold the amount of data requested by the user.  Empty is
 * when head == tail.  So full will result in head/tail being off by one due to
 * the extra byte.
 */
#define UART1_CONFIG_TX_BYTEQ_LENGTH (8+1)
#define UART1_CONFIG_RX_BYTEQ_LENGTH (64+1)

/** UART Driver Queue

  @Summary
    Defines the Transmit and Receive Buffers

*/

static uint8_t txQueue[UART1_CONFIG_TX_BYTEQ_LENGTH];
static uint8_t rxQueue[UART1_CONFIG_RX_BYTEQ_LENGTH];
UART1_FLAG_STA Uart_flg_sta;
UART1_PRI_DATA Uart_pri_data;
void (*UART1_TxDefaultInterruptHandler)(void);
void (*UART1_RxDefaultInterruptHandler)(void);

/**
  Section: Driver Interface
*/
//Rx
UART1_FLAGS UART_1;
unsigned char Rx1_Timeout = 0, Rx1_State = 0, Rx1_Len = 0, Rx1_Pntr = 0;
unsigned char Rx1_Buf[COMM1_BUF_SIZE], Rx1_CRC8 = 0, Read_Req_Addr = 0;
int i=0;

//Tx 
unsigned int Tx1_Start_Count = 0;
unsigned char Tx1_Timeout = 0, Tx1_State = 0, Tx1_Pntr = 0, Tx1_Wait_Count = 0,Tx1_add=0;
unsigned char Tx1_CRC8 = 0, Tx1_Buf[32], Tx1_Seq = 0;
#if 0
void UART1_Initialize(void)
{
    IEC0bits.U1TXIE = 0;
    IEC0bits.U1RXIE = 0;

    // STSEL 1; IREN disabled; PDSEL 8N; UARTEN enabled; RTSMD disabled; USIDL disabled; WAKE disabled; ABAUD disabled; LPBACK disabled; BRGH enabled; URXINV disabled; UEN TX_RX; 
    // Data Bits = 8; Parity = None; Stop Bits = 1;
    U1MODE = (0x8008 & ~(1<<15));  // disabling UART ON bit
    // UTXISEL0 TX_ONE_CHAR; UTXINV disabled; OERR NO_ERROR_cleared; URXISEL RX_ONE_CHAR; UTXBRK COMPLETED; UTXEN disabled; ADDEN disabled; 
    U1STA = 0x00;
    // BaudRate = 9600; Frequency = 39613750 Hz; BRG 1031; 
    U1BRG = 0x184;
    
    txHead = txQueue;
    txTail = txQueue;
    rxHead = rxQueue;
    rxTail = rxQueue;
   
    rxOverflowed = false;

    UART1_SetTxInterruptHandler(&UART1_Transmit_CallBack);

    UART1_SetRxInterruptHandler(&UART1_Receive_CallBack);

    IEC0bits.U1RXIE = 1;
    
    //Make sure to set LAT bit corresponding to TxPin as high before UART initialization
    U1MODEbits.UARTEN = 1;   // enabling UART ON bit
    U1STAbits.UTXEN = 1;
}
#endif
#if 1
void UART1_Initialize(void)
{
  U1MODEbits.UARTEN = 0; /* Bit15 TX, RX DISABLED, ENABLE at end of func */
  U1MODEbits.USIDL = 0; /* Bit13 Continue in Idle */
  U1MODEbits.IREN = 0; /* Bit12 No IR translation */
  U1MODEbits.RTSMD = 0; /* Bit11 Simplex Mode */
  U1MODEbits.UEN = 0; /* Bits8, 9 TX,RX enabled, CTS,RTS not */
  U1MODEbits.WAKE = 0; /* Bit7 No wake up */
  U1MODEbits.LPBACK = 0; /* Bit6 No loop back */
  U1MODEbits.ABAUD = 0; /* Bit5 No autobaud */
  U1MODEbits.URXINV = 0; /* Bit4 IdleState = 1 */
  U1MODEbits.BRGH = 0; /* Bit3 16 clocks per bit period */
  U1MODEbits.PDSEL = 0; /* Bits1, 2 8bit, No Parity */
  U1MODEbits.STSEL = 0; /* Bit0 One Stop Bit */

  U1BRG = 0x184; /* Set baudrate */

  /* Load all values in for U1STA SFR */
  U1STAbits.UTXISEL1 = 0; /* Bit15 Interrupt when char is transferred */
  U1STAbits.UTXINV = 0; /* Bit14 N/A, IRDA config */
  U1STAbits.UTXISEL0 = 0; /* Bit13 Interrupt when char is transferred */
  U1STAbits.UTXBRK = 0; /* Bit11 Disabled */
  U1STAbits.UTXEN = 0; /* Bit10 TX pins controlled by io port */
  U1STAbits.URXISEL = 0; /* Bits6, 7 Interrupt on character received */
  U1STAbits.ADDEN = 0; /* Bit5 Address detect disabled */

  /* Init interrupt functions */
  //  IPC2bits.U1RXIP    = UART_RX_INT_PRIO;
  //  IPC3bits.U1TXIP    = UART_TX_INT_PRIO;
  IFS0bits.U1TXIF = 0; /* Clear transmit interrupt flag */
  IEC0bits.U1TXIE = 0; /* Enable transmit interrupt */
  IFS0bits.U1RXIF = 0; /* Clear receive interrupt flag */
  IEC0bits.U1RXIE = 1; /* Enable receive interrupt */


  rxOverflowed = false;

  UART1_SetTxInterruptHandler(&UART1_Transmit_CallBack);

  UART1_SetRxInterruptHandler(&UART1_Receive_CallBack);

  U1MODEbits.UARTEN = 1; /* Enable uart */
  U1STAbits.UTXEN = 1; /* Enable tranmitter *//* Enable receive interrupt */
}
#endif
/**
    Maintains the driver's transmitter state machine and implements its ISR
*/

void UART1_SetTxInterruptHandler(void* handler)
{
    if(handler == NULL)
    {
        UART1_TxDefaultInterruptHandler = &UART1_Transmit_CallBack;
    }
    else
    {
        UART1_TxDefaultInterruptHandler = handler;
    }
} 

void __attribute__ ( ( interrupt, no_auto_psv ) ) _U1TXInterrupt ( void )
{
    if(UART1_TxDefaultInterruptHandler)
    {
        UART1_TxDefaultInterruptHandler();
    }

    if(txHead == txTail)
    {
        IEC0bits.U1TXIE = 0;
    }
    else
    {
        IFS0bits.U1TXIF = 0;

        while(!(U1STAbits.UTXBF == 1))
        {
            U1TXREG = *txHead++;

            if(txHead == (txQueue + UART1_CONFIG_TX_BYTEQ_LENGTH))
            {
                txHead = txQueue;
            }

            // Are we empty?
            if(txHead == txTail)
            {
                break;
            }
        }
    }
}

void __attribute__ ((weak)) UART1_Transmit_CallBack ( void )
{ 

}

void UART1_SetRxInterruptHandler(void* handler)
{
    if(handler == NULL)
    {
        UART1_RxDefaultInterruptHandler = &UART1_Receive_CallBack;
    }
    else
    {
        UART1_RxDefaultInterruptHandler = handler;
    }
}

void __attribute__ ( ( interrupt, no_auto_psv ) ) _U1RXInterrupt( void )
{
    U1TXREG = U1RXREG;  //for receive test
    if(UART1_RxDefaultInterruptHandler)
    {
        UART1_RxDefaultInterruptHandler();
    }
    
    IFS0bits.U1RXIF = 0;
	
    while((U1STAbits.URXDA == 1))
    {
        *rxTail = U1RXREG;

        // Will the increment not result in a wrap and not result in a pure collision?
        // This is most often condition so check first
        if ( ( rxTail    != (rxQueue + UART1_CONFIG_RX_BYTEQ_LENGTH-1)) &&
             ((rxTail+1) != rxHead) )
        {
            rxTail++;
        } 
        else if ( (rxTail == (rxQueue + UART1_CONFIG_RX_BYTEQ_LENGTH-1)) &&
                  (rxHead !=  rxQueue) )
        {
            // Pure wrap no collision
            rxTail = rxQueue;
        } 
        else // must be collision
        {
            rxOverflowed = true;
        }
    }
}

void __attribute__ ((weak)) UART1_Receive_CallBack(void)
{
	uint8_t Rx_Data;

	//Rx_Data = UART1_Read();//make error
	Rx_Data = U1RXREG;   
   // U2TXREG = Rx_Data; //for test
    switch(Rx1_State) 
    {
        case RX_START:
            if(Rx_Data == STX1)
            {
                Rx1_State = GET_DATA_LEN;
                Rx1_CRC8 = UART_CRC8_Isr(0, Rx_Data); 
                Rx1_Pntr = 0;
                Rx1_Len = 0;
                Rx1_Timeout = 0;
                UART_1.Rx_Timeout_En = TRUE;
				//UART1_Write(0xB1);
            }
            break;
        case VERIFY_ADDR:
            if(Rx_Data == UART1_RX_ADDRESS)
            {
                Rx1_CRC8 = UART_CRC8_Isr(Rx1_CRC8, Rx_Data);  
                Rx1_State = GET_DATA_LEN;
                Rx1_Timeout = 0;
				//UART1_Write(0xB2);
            }
            else
            {
                Rx1_State = RX_START;                
                UART_1.Rx_Timeout_En = FALSE;
            }
            break;
        case GET_DATA_LEN:
            if(Rx_Data > 0)
            {
                Rx1_CRC8 = UART_CRC8_Isr(Rx1_CRC8, Rx_Data);  
                Rx1_Len = Rx_Data;
                Rx1_State = GET_DATA;
                Rx1_Timeout = 0;  
				//UART1_Write(0xB3);
            }
            else    //No Data
            {
                Rx1_State = RX_START;                
                UART_1.Rx_Timeout_En = FALSE;                
            }
            break;
        case GET_DATA:
				//UART1_Write(0xB4);
				//UART1_Write(Rx_Data);
            if(Rx1_Pntr < COMM1_BUF_SIZE)
            {
                if(UART_1.RX_Data_Rdy == FALSE)
                {                
                    Rx1_CRC8 = UART_CRC8_Isr(Rx1_CRC8, Rx_Data);  
                    Rx1_Buf[Rx1_Pntr++] =Rx_Data;
                    Rx1_Timeout = 0;       
                    if(Rx1_Pntr >= Rx1_Len) //actual_len not include crc8Byte lenByte
                        Rx1_State = GET_CRC8;                         
                }
                else  //if previous data is not processed yet
                {
                    Rx1_State = RX_START;                
                    UART_1.Rx_Timeout_En = FALSE;                       
                }

            }
            else                
            {         
                Rx1_State = RX_START;                
                UART_1.Rx_Timeout_En = FALSE; 
            }
            break;
        case GET_CRC8:
			//UART1_Write(Rx_Data);
            Rx1_CRC8 = UART_CRC8_Isr(Rx1_CRC8, Rx_Data); //not include len and crc8 value

            if(Rx1_CRC8 == 0)    //CRC8 Match
            {
                UART_1.RX_Data_Rdy = TRUE;
                Rx1_State = RX_START;                
                UART_1.Rx_Timeout_En = FALSE;  
				//UART1_Write(0xB5);
            }
            else    //CRC8 Error
            {
                Rx1_State = RX_START;                
                UART_1.Rx_Timeout_En = FALSE; 
				//UART1_Write(0xB6);
            }
            break;
        default:
            Rx1_State = RX_START;                
            UART_1.Rx_Timeout_En = FALSE;  
            break;
    }
}

void __attribute__ ( ( interrupt, no_auto_psv ) ) _U1ErrInterrupt( void )
{
    if ((U1STAbits.OERR == 1))
    {
        U1STAbits.OERR = 0;
    }
    
    IFS4bits.U1EIF = 0;
}

/**
  Section: UART Driver Client Routines
*/

uint8_t UART1_Read( void)
{
    uint8_t data = 0;

    while (rxHead == rxTail )
    {
    }
    
    data = *rxHead;

    rxHead++;

    if (rxHead == (rxQueue + UART1_CONFIG_RX_BYTEQ_LENGTH))
    {
        rxHead = rxQueue;
    }
    return data;
}

void UART1_Write( uint8_t byte)
{
    while(UART1_IsTxReady() == 0)
    {
    }

    *txTail = byte;

    txTail++;
    
    if (txTail == (txQueue + UART1_CONFIG_TX_BYTEQ_LENGTH))
    {
        txTail = txQueue;
    }

    IEC0bits.U1TXIE = 1;
}

bool UART1_IsRxReady(void)
{    
    return !(rxHead == rxTail);
}

bool UART1_IsTxReady(void)
{
    uint16_t size;
    uint8_t *snapshot_txHead = (uint8_t*)txHead;
    
    if (txTail < snapshot_txHead)
    {
        size = (snapshot_txHead - txTail - 1);
    }
    else
    {
        size = ( UART1_CONFIG_TX_BYTEQ_LENGTH - (txTail - snapshot_txHead) - 1 );
    }
    
    return (size != 0);
}

bool UART1_IsTxDone(void)
{
    if(txTail == txHead)
    {
        return (bool)U1STAbits.TRMT;
    }
    
    return false;
}

int __attribute__((__section__(".libc.write"))) write(int handle, void *buffer, unsigned int len) 
{
    unsigned int i;
    uint8_t *data = buffer;

    for(i=0; i<len; i++)
    {
        while(UART1_IsTxReady() == false)
        {
        }

        UART1_Write(*data++);
    }
  
    return(len);
}

/*******************************************************************************

  !!! Deprecated API !!!
  !!! These functions will not be supported in future releases !!!

*******************************************************************************/

static uint8_t UART1_RxDataAvailable(void)
{
    uint16_t size;
    uint8_t *snapshot_rxTail = (uint8_t*)rxTail;
    
    if (snapshot_rxTail < rxHead) 
    {
        size = ( UART1_CONFIG_RX_BYTEQ_LENGTH - (rxHead-snapshot_rxTail));
    }
    else
    {
        size = ( (snapshot_rxTail - rxHead));
    }
    
    if(size > 0xFF)
    {
        return 0xFF;
    }
    
    return size;
}

static uint8_t UART1_TxDataAvailable(void)
{
    uint16_t size;
    uint8_t *snapshot_txHead = (uint8_t*)txHead;
    
    if (txTail < snapshot_txHead)
    {
        size = (snapshot_txHead - txTail - 1);
    }
    else
    {
        size = ( UART1_CONFIG_TX_BYTEQ_LENGTH - (txTail - snapshot_txHead) - 1 );
    }
    
    if(size > 0xFF)
    {
        return 0xFF;
    }
    
    return size;
}

unsigned int __attribute__((deprecated)) UART1_ReadBuffer( uint8_t *buffer ,  unsigned int numbytes)
{
    unsigned int rx_count = UART1_RxDataAvailable();
    unsigned int i;
    
    if(numbytes < rx_count)
    {
        rx_count = numbytes;
    }
    
    for(i=0; i<rx_count; i++)
    {
        *buffer++ = UART1_Read();
    }
    
    return rx_count;    
}

unsigned int __attribute__((deprecated)) UART1_WriteBuffer( uint8_t *buffer , unsigned int numbytes )
{
    unsigned int tx_count = UART1_TxDataAvailable();
    unsigned int i;
    
    if(numbytes < tx_count)
    {
        tx_count = numbytes;
    }
    
    for(i=0; i<tx_count; i++)
    {
        UART1_Write(*buffer++);
    }
    
    return tx_count;  
}

UART1_TRANSFER_STATUS __attribute__((deprecated)) UART1_TransferStatusGet (void )
{
    UART1_TRANSFER_STATUS status = 0;
    uint8_t rx_count = UART1_RxDataAvailable();
    uint8_t tx_count = UART1_TxDataAvailable();
    
    switch(rx_count)
    {
        case 0:
            status |= UART1_TRANSFER_STATUS_RX_EMPTY;
            break;
        case UART1_CONFIG_RX_BYTEQ_LENGTH:
            status |= UART1_TRANSFER_STATUS_RX_FULL;
            break;
        default:
            status |= UART1_TRANSFER_STATUS_RX_DATA_PRESENT;
            break;
    }
    
    switch(tx_count)
    {
        case 0:
            status |= UART1_TRANSFER_STATUS_TX_FULL;
            break;
        case UART1_CONFIG_RX_BYTEQ_LENGTH:
            status |= UART1_TRANSFER_STATUS_TX_EMPTY;
            break;
        default:
            break;
    }

    return status;    
}

uint8_t __attribute__((deprecated)) UART1_Peek(uint16_t offset)
{
    uint8_t *peek = rxHead + offset;
    
    while(peek > (rxQueue + UART1_CONFIG_RX_BYTEQ_LENGTH))
    {
        peek -= UART1_CONFIG_RX_BYTEQ_LENGTH;
    }
    
    return *peek;
}

bool __attribute__((deprecated)) UART1_ReceiveBufferIsEmpty (void)
{
    return (UART1_RxDataAvailable() == 0);
}

bool __attribute__((deprecated)) UART1_TransmitBufferIsFull(void)
{
    return (UART1_TxDataAvailable() == 0);
}

uint16_t __attribute__((deprecated)) UART1_StatusGet (void)
{
    return U1STA;
}

unsigned int __attribute__((deprecated)) UART1_TransmitBufferSizeGet(void)
{
    if(UART1_TxDataAvailable() != 0)
    { 
        if(txHead > txTail)
        {
            return((txHead - txTail) - 1);
        }
        else
        {
            return((UART1_CONFIG_TX_BYTEQ_LENGTH - (txTail - txHead)) - 1);
        }
    }
    return 0;
}

unsigned int __attribute__((deprecated)) UART1_ReceiveBufferSizeGet(void)
{
    if(UART1_RxDataAvailable() != 0)
    {
        if(rxHead > rxTail)
        {
            return((rxHead - rxTail) - 1);
        }
        else
        {
            return((UART1_CONFIG_RX_BYTEQ_LENGTH - (rxTail - rxHead)) - 1);
        } 
    }
    return 0;
}

void __attribute__((deprecated)) UART1_Enable(void)
{
    U1MODEbits.UARTEN = 1;
    U1STAbits.UTXEN = 1;
}

void __attribute__((deprecated)) UART1_Disable(void)
{
    U1MODEbits.UARTEN = 0;
    U1STAbits.UTXEN = 0;
}

/*******************************************************************************
 * Function:        Uart1SendByte
 * Parameters:      mode for CRC, data for tranmission
 * Returned value:  -
 * Description:     Handle the byte transmission, calculate the CRC and then TX.
 * Calling:
 ******************************************************************************/
void Uart1SendByte(unsigned char data)
{

    Tx1_CRC8 = UART_CRC8(Tx1_CRC8, data);    
    U1TXREG = data;
}


/*******************************************************************************
 * Function:        Process_RxData
 * Description:     Handle the Received Bytes Called from 10mS Loop
 * Calling:         every 10ms
 ******************************************************************************/

void Uart1_RxData(void)
{

    static unsigned int Boot_Set_Count = 0;
//    unsigned char Temp_ui8;
    

    //Handle Rx Timeout
    if(UART_1.Rx_Timeout_En == TRUE)
    {

        Rx1_Timeout++;
        if(Rx1_Timeout > COMM1_RX_TIMEOUT)
        {            
            Rx1_State = RX_START;                
            UART_1.Rx_Timeout_En = FALSE;
        }
    }
    else
        Rx1_Timeout = 0;
    

    if(UART_1.RX_Data_Rdy == TRUE)  
    {
/*
        UART2_Write(0xAA);
        UART2_Write(0x0D);
        UART2_Write(Rx1_Buf[0]);
        UART2_Write(Rx1_Buf[1]);
        UART2_Write(Rx1_Buf[2]);
        UART2_Write(Rx1_Buf[3]);
        UART2_Write(Rx1_Buf[4]);
        UART2_Write(Rx1_Buf[5]);
        UART2_Write(Rx1_Buf[6]);
        UART2_Write(Rx1_Buf[7]);
        UART2_Write(Rx1_Buf[8]);
        UART2_Write(Rx1_Buf[9]);
        UART2_Write(Rx1_Buf[10]);
        UART2_Write(Rx1_Buf[11]);
        UART2_Write(Rx1_Buf[12]);
        UART2_Write(0xFF);
 */
        gPmbusCmd.READ_TEMPERATURE_1.Bytes.LB = Rx1_Buf[1]; //Pri Temp1
        gPmbusCmd.READ_TEMPERATURE_1.Bytes.HB = Rx1_Buf[2];
        gPmbusCmd.READ_TEMPERATURE_2.Bytes.LB = Rx1_Buf[3]; //Pri Temp2
        gPmbusCmd.READ_TEMPERATURE_2.Bytes.HB = Rx1_Buf[4]; 
        gPmbusCmd.READ_VIN.Bytes.LB =  Rx1_Buf[7];          //Pri Vin
        gPmbusCmd.READ_VIN.Bytes.HB =  Rx1_Buf[8];
        gPmbusCmd.READ_VOUT.Bytes.LB = Rx1_Buf[9];          //Pri Vbulk
        gPmbusCmd.READ_VOUT.Bytes.HB = Rx1_Buf[10];
        gPmbusCmd.READ_IIN.Bytes.LB = Rx1_Buf[11];          //Pri Iin
        gPmbusCmd.READ_IIN.Bytes.HB = Rx1_Buf[12];
        //gPmbusCmd.READ_PIN.Bytes.LB = Rx_Buf[18];         //Pri Pin
        //gPmbusCmd.READ_PIN.Bytes.HB = Rx_Buf[19];
        UART_1.RX_Data_Rdy = FALSE;
    }  
}
/************************************************************************************
 * Function:        Process_TxData
 * Description:     Send data for transmission to Secondary side.calling every 1ms
 ***********************************************************************************/


void Uart1_TxData(void)
{

    if ((U1STAbits.PERR == TRUE) && (U1STAbits.FERR == TRUE))
        UART1_Initialize();

    if(!UART_1.Tx_Startup)
    {
        Tx1_Start_Count++;
        if(Tx1_Start_Count > TX1_STARTUP_DELAY)
        {

            Tx1_Start_Count = 0;
            UART_1.Tx_Startup = 1;
        }

    }
    else if(!UART_1.Tx_Data_Ready)
    {        
        Tx1_State = SEND_KEY;
        Tx1_Pntr = 0;
        UART_1.Tx_Data_Ready = TRUE;    
    }
        
    if(UART_1.Tx_Wait)
    {
        Tx1_Wait_Count++;
        if(Tx1_Wait_Count > TX1_WAIT_DELAY) //Between each Tx Packet
        {

            UART_1.Tx_Wait = 0;
            Tx1_Wait_Count = 0;
        }

    }    
    else if(UART_1.Tx_Data_Ready) //Send Total 10 Bytes
    {

        if(U1STAbits.TRMT == TRUE) 
        {
            switch(Tx1_State)
            {
                case TX_IDLE:
                    //do nothing
                    break;
                case SEND_KEY://1 Byte Key
                    Tx1_CRC8 = 0;
                    Tx_Buf[2]=0xBB;
                    //Uart1SendByte(0xAA);
                    //Uart1SendByte(0x04);
                    Tx1_State = SEND_DATA;//SEND_KEY;
                    break;
                case SEND_ADDR://1 Byte Address
                	if(Tx1_add > 13)//13
                	{
                    	Tx1_State = SEND_DATA;
                        Tx1_add = 0;
                	}
                   // Uart1SendByte(0xFF); //for test
                    Tx1_add++;
                    break;
                case SEND_DATA: //7 Bytes - 1 Byte Index and 6 Bytes Data
                    Uart1SendByte(Tx1_Buf[Tx1_Pntr++]); 
                    if(Tx1_Pntr > 7)//1//7//13
                    {
                        Tx1_State = SEND_CRC8;
                        Tx1_Pntr = 0;
                    }
                    break;
                case SEND_CRC8://1 Byte CRC8 from 0 - 8
                  //  Uart1SendByte(Tx1_CRC8);  
                    Tx1_State = WAIT_2_END_TX;
                    break;
                case WAIT_2_END_TX:   
                    Tx1_State = TX_IDLE;
                    UART_1.Tx_Data_Ready = 0;
                    UART_1.Tx_Wait = 1; 
                    break;
                default:              
                    Tx1_State = TX_IDLE;
                    UART_1.Tx_Data_Ready = 0;
                    UART_1.Tx_Wait = 1;       
                    break;
            }
            Tx1_Timeout = 0;
        }

        else if(UART_1.Tx_Data_Ready) //Transmit Timeout
        {
            //Transmit Timeout Routine
            Tx1_Timeout = 0;
            
        }
    }           
} 