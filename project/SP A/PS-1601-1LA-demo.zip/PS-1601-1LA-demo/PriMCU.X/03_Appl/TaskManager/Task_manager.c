#include "headers.h"
//Primary Data
PRIMARY_DATA PRI_DATA;
PRIMARY_STATE PRI_STATE;
POWER_METER Pmeter;
VinVoltage Vin_Mon;
FLAG_STA TFCtrl;
unsigned int Vbus;
unsigned int Vin;
unsigned int Iin;
//Bulk and Temperature ADC Averaging
unsigned long ADC_Arr[4] = {0,0,0,0};
unsigned long TMP_ADC=0;
unsigned char ADC_Acc_Cnt = 0,T_ADC_Count = 0;
//line voltage 
int uin_fil[48] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,};
int uin_fil_ptr = 0;
long uin_fil_sum_50 = 0;
long uin_fil_sum_60 = 0;
int uin_filtered = 0;
// dc link voltage
int udc_fil[48] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,};
int udc_fil_ptr = 0;
long udc_fil_sum_50 = 0;
long udc_fil_sum_60 = 0;
int udc_filtered = 0;
int udc_filter_input = 0;

// input current, this is only needed for display purposes
int iin_fil[48] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,};
int iin_fil_ptr = 0;
long iin_fil_sum_50 = 0;
long iin_fil_sum_60 = 0;
int iin_filtered = 0;

// ... peak detection
int uin_filtered_peak = 0;
int uin_filter_input = 0;
int uin_Peak_detect = 0;
static int freq_sw_cnt = 0, line_freq = 50;
static long sum50 = 0, sum60 = 0;
static int cor50 = 0, cnt50 = 0, cor60 = 0, cnt60 = 0;
unsigned int Bulk_OK_Var_Delay = 0;
static unsigned char PFC_State = PFC_INIT,Bulk_Startup_Sta=0;
SM_state ctl_state;
volatile IIR_lowpass_int_t Ifilter;
uint16_t Iin_filt = 0;

/*******************************************************************************
 * Function:        LineFreqDetect
 * Parameters:      
 * Returned value:  
 * Description:     
 * Calling:
 ******************************************************************************/
void LineFreqDetect(void)
{
    // determine line frequency by correlation filter (small sums mean good correlation)
    // 50 Hz correlation:
    if (cnt50 < 48)
        sum50 += Vin;
    else
        sum50 -= Vin;
    if (++cnt50 >= (2 * 48)) {
        cnt50 = 0;
        cor50 = sum50 >> 5;
        if (cor50 < 0) cor50 = -cor50;
        sum50 = 0;
    }
    // 60 Hz correlation:
    if (cnt60 < 40)
        sum60 += Vin;
    else
        sum60 -= Vin;
    if (++cnt60 >= (2 * 40)) {
        cnt60 = 0;
        cor60 = sum60 >> 5;
        if (cor60 < 0) cor60 = -cor60;
        sum60 = 0;
    }
    if (freq_sw_cnt >= 480) // 50 Hz detected for >100 ms
        line_freq = 50;
    else if ((cor60 > 10) && (cor50 < cor60)) // better correlation with 50 Hz
        ++freq_sw_cnt; // 1 step towards 50 Hz position
    if (freq_sw_cnt <= -480) // 60 Hz detected for >100 ms
        line_freq = 60;
    else if ((cor50 > 10) && (cor60 < cor50)) // better correlation with 50 Hz
        --freq_sw_cnt; // 1 step towards 60 Hz position

}

/*******************************************************************************
 * Function:        CalcSquareRoot
 * Parameters:      ulValue - squared value
 * Returned value:  square root from ulValue
 * Description:     This function has the aim to calculate the square root from
 *                  ulValue. The result is limited to a maximum resolution of 12bit.
 * Calling:
 ******************************************************************************/
uint16_t CalcSquareRoot(unsigned long ulValue)
{
    uint8_t ucBitPos;
    uint16_t uiLastResult;
    uint16_t uiResult = 0;
    uint32_t ulResultSqr;

    if (ulValue != 0)
    {
        // If ulValue is not zero then perform calculation
        for (ucBitPos = 12; ucBitPos >= 1; ucBitPos--)
        {
            uiLastResult = uiResult;
            uiResult |= (0x0001 << (ucBitPos - 1));
            ulResultSqr = (__builtin_mulss(uiResult, uiResult));
            if (ulValue < ulResultSqr)
                uiResult = uiLastResult;
        }
    }
    return ( uiResult);
} // CalcSquareRoot()

/*******************************************************************************
 * Function:        Func64Div16to32
 * Parameters:      unsigned long long dividend, unsigned int divisor
 * Returned value:  unsigned long quotient
 * Description:     return: quotient = dividend / divisor
 * Calling:
 ******************************************************************************/
uint32_t Func64Div16to32(unsigned long long dividend, unsigned int divisor)
{
    uint16_t Remainder = 0;
    uint16_t DivResult[4];
    
    if (divisor > 0)
    {
        DivResult[3] = __builtin_divmodud((dividend >> 48), divisor, &Remainder);
        DivResult[2] = __builtin_divmodud((((dividend >> 32) & 0xFFFF) + ((unsigned long) Remainder << 16)), divisor, &Remainder);
        DivResult[1] = __builtin_divmodud((((dividend >> 16) & 0xFFFF) + ((unsigned long) Remainder << 16)), divisor, &Remainder);
        DivResult[0] = __builtin_divmodud(((dividend & 0xFFFF) + ((unsigned long) Remainder << 16)), divisor, &Remainder);

        return (((unsigned long long) DivResult[3] << 48) + ((unsigned long long) DivResult[2] << 32) +
          ((unsigned long) DivResult[1] << 16) + DivResult[0]);
    }
    else
        return (0);
}
/*******************************************************************************
 * Function:        LowerPass_filter_Iin
 * Parameters:      
 * Returned value:  
 * Description:   Iin_filter[n] = a0*Iin[n] + a1*Iin[n-1] + a2*Iin[n-2] - b0*Iin_out[n-1] - b1*Iin_out[n-2]  
 * Calling: 1ms
 ******************************************************************************/
static inline void LowerPass_filter_Iin()
{
	//section1 
	Ifilter.in[0] = Iin_filt;
    Ifilter.tmpb0u0 = __builtin_mulss(Ifilter.a[0],Ifilter.in[0]);
    Ifilter.tmpb1u1 = __builtin_mulss(Ifilter.a[1],Ifilter.in[1]);
    Ifilter.tmpb2u2 = __builtin_mulss(Ifilter.a[2],Ifilter.in[2]);
    
	// Section 1 calculation
	Ifilter.tmpa1y1 = __builtin_mulss(Ifilter.b[1],Ifilter.out[1]);
   	Ifilter.tmpa2y2 = __builtin_mulss(Ifilter.b[2],Ifilter.out[2]);
    
	Ifilter.out[0] = (Ifilter.tmpb0u0 + Ifilter.tmpb1u1 + Ifilter.tmpb2u2 - Ifilter.tmpa1y1 - Ifilter.tmpa2y2)>>15; 
            
	Ifilter.in[2] = Ifilter.in[1];
	Ifilter.in[1] = Ifilter.in[0];

	Ifilter.out[2] = Ifilter.out[1];
	Ifilter.out[1] = Ifilter.out[0];
    

        if(Ifilter.out[0] < 1)
        {
            Ifilter.out[0] = 1;
        } 
    
    Ifilter.f_out = Ifilter.out[0]<<2;
}

/*******************************************************************************
 * Function:        Power_meter
 * Parameters:      
 * Returned value:  
 * Description:     
 * Calling: 
 ******************************************************************************/
void Power_meter(void)
{
    //PTPER=PFC_PWM_PERIOD;
    Iin = I_PFC_MCU_BUF;
    if (L_VOLTAGE_BUF > N_VOLTAGE_BUF)
        Vin = (L_VOLTAGE_BUF - N_VOLTAGE_BUF);
    else
        Vin = (N_VOLTAGE_BUF - L_VOLTAGE_BUF);
    Vbus = VDC_MCU_BUF;
    
    if(PRI_STATE.VPOL == 0)
    {
        if((L_VOLTAGE_BUF > N_VOLTAGE_BUF + 10) && (Pmeter.Sample_Cnt_Tmp > 100))//10,6
            PRI_STATE.VPOL = 1;
    }
    else
    {
        if((N_VOLTAGE_BUF > L_VOLTAGE_BUF + 10) && (Pmeter.Sample_Cnt_Tmp > 100))//10,6
            PRI_STATE.VPOL = 0;
    }

    Pmeter.Vin_Sum_Tmp += ((uint32_t) __builtin_muluu(Vin, Vin));
    Pmeter.Iin_Sum_Tmp += ((uint32_t) __builtin_muluu(Iin, Iin));
    Pmeter.Pin_Sum_Tmp += ((uint32_t) __builtin_muluu(Vin, Iin));
    
    Pmeter.Sample_Cnt_Tmp++;

    if(((PRI_STATE.VPOL_1 != PRI_STATE.VPOL) && (Pmeter.Sample_Cnt_Tmp > 240)) || (Pmeter.Sample_Cnt_Tmp > 1200)) //14,70// 14ms   
    {
        PRI_STATE.New_AC_Data = 1;
        Pmeter.Vin_Sum = Pmeter.Vin_Sum_Tmp;
        Pmeter.Iin_Sum = Pmeter.Iin_Sum_Tmp;
        Pmeter.Pin_Sum = Pmeter.Pin_Sum_Tmp>>8;
        Pmeter.Sample_Cnt = Pmeter.Sample_Cnt_Tmp;
        Pmeter.Vin_Sum_Tmp = 0;
        Pmeter.Iin_Sum_Tmp = 0;
        Pmeter.Pin_Sum_Tmp = 0;
        Pmeter.Sample_Cnt_Tmp = 0;
        

    }
    PRI_STATE.VPOL_1 = PRI_STATE.VPOL; 
}
/*******************************************************************************
 * Function:        AC_OK_Disable
 * Description:     
 * Calling:         
 *****************************************************************************/
void AC_OK_Disable(void)
{
    AC_OK_PRI_SetHigh();
}
/*******************************************************************************
 * Function:        AC_OK_Enable
 * Description:     
 * Calling:         
 *****************************************************************************/
void AC_OK_Enable(void)
{
    AC_OK_PRI_SetLow();
}
/*******************************************************************************
 * Function:        Relay_ON_Enable
 * Description:     
 * Calling:         
 *****************************************************************************/
void Relay_ON_Enable(void)
{
    RELAY_STRT();
}
/*******************************************************************************
 * Function:        Relay_ON_Disable
 * Description:     
 * Calling:         
 *****************************************************************************/
void Relay_ON_Disable(void)
{
    RELAY_OFF();
}
/*******************************************************************************
 * Function:        BULK_VOLT_REG_Disable
 * Description:     
 * Calling:         
 *****************************************************************************/
void BULK_VOLT_REG_Disable(void)
{
    BULK_VOLT_REG_MCU_SetLow();
}
/*******************************************************************************
 * Function:        BULK_VOLT_REG_Enable
 * Description:     
 * Calling:         
 *****************************************************************************/
void BULK_VOLT_REG_Enable(void)
{
    BULK_VOLT_REG_MCU_SetHigh();
}

/*******************************************************************************
 * Function:        LLC_IC_Disable
 * Description:     
 * Calling:         
 *****************************************************************************/
void LLC_IC_Disable(void)
{
    PRI_LLC_EN_ON_L_MCU_SetHigh();
}
/*******************************************************************************
 * Function:        LLC_IC_Enable
 * Description:     
 * Calling:         
 *****************************************************************************/
void LLC_IC_Enable(void)
{
    PRI_LLC_EN_ON_L_MCU_SetLow();
}
/*******************************************************************************
 * Function:        PFC_IC_Disable
 * Description:     
 * Calling:         
 *****************************************************************************/
void PFC_IC_Disable(void)
{
    PFC_ON_H_SetLow();
}
/*******************************************************************************
 * Function:        PFC_IC_Enable
 * Description:     
 * Calling:         
 *****************************************************************************/
void PFC_IC_Enable(void)
{
    PFC_ON_H_SetHigh();
}
/*******************************************************************************
 * Function:        PFC_OK_Disable
 * Description:     
 * Calling:         
 *****************************************************************************/
void PFC_OK_Disable(void)
{
    PFC_OK_PRI_SetHigh();
}
/*******************************************************************************
 * Function:        PFC_OK_Enable
 * Description:     
 * Calling:         
 *****************************************************************************/
void PFC_OK_Enable(void)
{
   PFC_OK_PRI_SetLow();
}
/*******************************************************************************
 * Function:        AC_RMS_Calculation
 * Description:     Tasks Related to RMS Calculation
 * Calling:         every 1mS total < 8 Taks. Each Task to be completed in < 30uS
 *****************************************************************************/
void AC_RMS_Calculation(void)
{
    unsigned long Temp_ui32;
    unsigned int AC_Gain;
    unsigned int Temp_ui16, Temp_IADC;
    
    TFCtrl.AC_Tasks++;
    switch(TFCtrl.AC_Tasks)
    {
        case 1:
            if(PRI_STATE.New_AC_Data)
            {    
                Pmeter.Vin_Sum2 = Pmeter.Vin_Sum;
                Pmeter.Iin_Sum2 = Pmeter.Iin_Sum;
                Pmeter.Pin_Sum2 = Pmeter.Pin_Sum;
                Pmeter.Sample_Cnt2 = Pmeter.Sample_Cnt;
                
                Pmeter.Vin_Sum = 0;
                Pmeter.Iin_Sum = 0;
                Pmeter.Pin_Sum = 0;
                Pmeter.Sample_Cnt = 0;
                
                PRI_STATE.New_AC_Data = 0;
                PRI_STATE.Start_AC_Calc = 1; 
            }
            break;
        case 2:
            //Vin RMS ADC Calculation
            if(PRI_STATE.Start_AC_Calc)
            {   
                Temp_ui32 = Func64Div16to32(Pmeter.Vin_Sum2, Pmeter.Sample_Cnt2);
                PRI_DATA.VRms_ADC = CalcSquareRoot(Temp_ui32); 
                   
                Pmeter.Vin_Sum2 = 0;
               
            }
            break;
        case 3:
            //Iin RMS ADC Calculation
            if(PRI_STATE.Start_AC_Calc)
            {
                Temp_ui32 = Func64Div16to32(Pmeter.Iin_Sum2, Pmeter.Sample_Cnt2);
                PRI_DATA.IRms_ADC = CalcSquareRoot(Temp_ui32); 
                Pmeter.Iin_Sum2 = 0;
            }
            break;
        case 4:
            //Pin RMS ADC Calculation
            if(PRI_STATE.Start_AC_Calc)
            {
                Temp_ui32 = Func64Div16to32(Pmeter.Pin_Sum2, Pmeter.Sample_Cnt2);
                PRI_DATA.PIN_Rms_ADC = (unsigned int) Temp_ui32;
                Pmeter.Pin_Sum2 = 0;
            }
            break;
        case 5:
            //Vin RMS Calculation in 125mV Resolution
            if(PRI_STATE.Start_AC_Calc)
            {
                AC_Gain = PRI_DATA.VIN_HL_Gain;   //mod
                Temp_ui32 = (unsigned long) __builtin_muluu(PRI_DATA.VRms_ADC,AC_Gain);
                PRI_DATA.VRMS_Inst = (unsigned int) ( (Temp_ui32+2048) >> PRI_DATA.VIN_Div);  //(actually voltage)*AC_Gain
            }
            break;
        case 6:
            //Iin RMS Calculatio n in 15.625mA Resolution
            if(PRI_STATE.Start_AC_Calc)
            {
                if(PRI_STATE.VAC_Range_LL)   //if Low Line
                {
                    if(PRI_DATA.IRms_ADC > PRI_DATA.IIN_LL_4A_ADC) //>4A -> 10A Gain
                    {
                        AC_Gain = PRI_DATA.IIN_LL_6A_Gain;
                        Temp_IADC = PRI_DATA.IRms_ADC - PRI_DATA.IIN_LL_4A_ADC;
                        Temp_ui16 = PRI_DATA.IIN_LL_4A_Val;
                    }
                    else if(PRI_DATA.IRms_ADC > PRI_DATA.IIN_LL_1A_ADC) //>1A -> 4A Gain
                    {
                        AC_Gain = PRI_DATA.IIN_LL_4A_Gain;
                        Temp_IADC = PRI_DATA.IRms_ADC - PRI_DATA.IIN_LL_1A_ADC;
                        Temp_ui16 = PRI_DATA.IIN_LL_1A_Val;
                    }
                    else //<1A -> 1A Gain
                    {
                        AC_Gain = PRI_DATA.IIN_LL_1A_Gain;
                        Temp_IADC = PRI_DATA.IRms_ADC;
                        Temp_ui16 = 0;
                    }                    
                }
                else // High Line
                {
                    if(PRI_DATA.IRms_ADC > PRI_DATA.IIN_HL_2A_ADC) //>2A -> 5A Gain
                    {
                        AC_Gain = PRI_DATA.IIN_HL_3A_Gain;
                        Temp_IADC = PRI_DATA.IRms_ADC - PRI_DATA.IIN_HL_2A_ADC;  
                        Temp_ui16 = PRI_DATA.IIN_HL_2A_Val;
                    }
                    else if(PRI_DATA.IRms_ADC > PRI_DATA.IIN_HL_0A5_ADC) //>0.5A -> 2A Gain
                    {
                        AC_Gain = PRI_DATA.IIN_HL_2A_Gain;
                        Temp_IADC = PRI_DATA.IRms_ADC - PRI_DATA.IIN_HL_0A5_ADC;
                        Temp_ui16 = PRI_DATA.IIN_HL_0A5_Val;
                    }
                    else //<0.5A -> 0.5A Gain
                    {
                        AC_Gain = PRI_DATA.IIN_HL_0A5_Gain;
                        Temp_IADC = PRI_DATA.IRms_ADC;
                        Temp_ui16 = 0;
                    }                              
               }
                Temp_ui32 = (unsigned long) __builtin_muluu(Temp_IADC, AC_Gain); 
                PRI_DATA.IRMS_Inst = Temp_ui16 + (unsigned int) ((Temp_ui32+2048) >> PRI_DATA.IIN_Div);
            }
            break;
         case 7:
             /*
            //Pin RMS Calculation in 250mW Resolution
            if(PRI_DATA.Start_AC_Calc)
            {
                if(PRI_DATA.VAC_Range_LL)   //if Low Line
                {
                    if(PRI_DATA.PIN_Rms_ADC > PRI_DATA.PIN_LL_4A_ADC) //>4A -> 10A Gain
                    {
                        AC_Gain = PRI_DATA.PIN_LL_10A_Gain;
                        Temp_IADC = PRI_DATA.PIN_Rms_ADC - PRI_DATA.PIN_LL_4A_ADC;
                        Temp_ui16 = PRI_DATA.PIN_LL_4A_Val;
                    }
                    else if(PRI_DATA.PIN_Rms_ADC > PRI_DATA.PIN_LL_1A_ADC) //>1A -> 4A Gain
                    {
                        AC_Gain = PRI_DATA.PIN_LL_4A_Gain;
                        Temp_IADC = PRI_DATA.PIN_Rms_ADC - PRI_DATA.PIN_LL_1A_ADC;
                        Temp_ui16 = PRI_DATA.PIN_LL_1A_Val;
                    }
                    else //<1A -> 1A Gain
                    {
                        AC_Gain = PRI_DATA.PIN_LL_1A_Gain;
                        Temp_IADC = PRI_DATA.PIN_Rms_ADC;
                        Temp_ui16 = 0;
                    }                    
                }
                else // High Line
                {
                    if(PRI_DATA.PIN_Rms_ADC > PRI_DATA.PIN_HL_2A_ADC) //>2A -> 5A Gain
                    {
                        AC_Gain = PRI_DATA.PIN_HL_5A_Gain;
                        Temp_IADC = PRI_DATA.PIN_Rms_ADC - PRI_DATA.PIN_HL_2A_ADC;
                        Temp_ui16 = PRI_DATA.PIN_HL_2A_Val;
                    }
                    else if(PRI_DATA.PIN_Rms_ADC > PRI_DATA.PIN_HL_0A5_ADC) //>0.5A -> 2A Gain
                    {
                        AC_Gain = PRI_DATA.PIN_HL_2A_Gain;
                        Temp_IADC = PRI_DATA.PIN_Rms_ADC - PRI_DATA.PIN_HL_0A5_ADC;
                        Temp_ui16 = PRI_DATA.PIN_HL_0A5_Val;
                    }
                    else //<0.5A -> 0.5A Gain
                    {
                        AC_Gain = PRI_DATA.PIN_HL_0A5_Gain;
                        Temp_IADC = PRI_DATA.PIN_Rms_ADC;
                        Temp_ui16 = 0;
                    }                                   
                }

               // Temp_ui32 = (unsigned long) __builtin_muluu(Temp_IADC, AC_Gain); 
               // PRI_DATA.PIN_Inst = Temp_ui16 + (unsigned int) ((Temp_ui32+512) >> PRI_DATA.PIN_Div);
            }
            */
            break;
        case 8:
            if(PRI_STATE.Start_AC_Calc)
            {
                Pmeter.VRms_Sum += PRI_DATA.VRMS_Inst;
                Pmeter.IRms_Sum += PRI_DATA.IRMS_Inst;
                Pmeter.PRms_Sum += PRI_DATA.PIN_Inst;
                Pmeter.VRms_ADC_Sum+=PRI_DATA.VRms_ADC;
                Pmeter.IRms_ADC_Sum+=PRI_DATA.IRms_ADC;
                Pmeter.PRms_ADC_Sum+=PRI_DATA.PIN_Rms_ADC;
                Pmeter.Rms_Avg_Count++;
                if(Pmeter.Rms_Avg_Count > 31)       //32 Samples
                {
                    PRI_DATA.VRMS_Avg = (unsigned int) (Pmeter.VRms_Sum >>5); 
                    PRI_DATA.IRMS_Avg = (unsigned int) (Pmeter.IRms_Sum >>5); 
                    PRI_DATA.PIN_Avg = (unsigned int) (Pmeter.PRms_Sum >>5); 
                    PRI_DATA.VRMS_ADC_Avg = (unsigned int) (Pmeter.VRms_ADC_Sum >>5); 
                    PRI_DATA.IRMS_ADC_Avg = (unsigned int) (Pmeter.IRms_ADC_Sum >>5); 
                    PRI_DATA.PIN_ADC_Avg = (unsigned int) (Pmeter.PRms_ADC_Sum >>5);
                    Pmeter.VRms_Sum = 0;
                    Pmeter.IRms_Sum = 0;
                    Pmeter.PRms_Sum = 0;
                    Pmeter.VRms_ADC_Sum = 0;
                    Pmeter.IRms_ADC_Sum = 0;
                    Pmeter.Rms_Avg_Count = 0; 
                    Pmeter.PRms_ADC_Sum = 0;
                    /*
                      //Calculate Drop Out Time
                    if(PRI_DATA.PIN_Avg < DROPOUT_MAXLOAD)
                    {
                        Temp_ui16 = (unsigned long) DROPOUT_MAXLOAD - PRI_DATA.PIN_Avg;
                        Temp_ui32 =  __builtin_muluu(Temp_ui16, ADD_DO_GAIN); 
                        Temp_ui16 = (unsigned int) (Temp_ui32 >> 12);
                        Dropout_Delay = DROPOUT_TRIG_DELAY_FL + Temp_ui16;
                    }
                    else
                        Dropout_Delay = DROPOUT_TRIG_DELAY_FL;
                    */
	            }
                PRI_STATE.Start_AC_Calc = 0;
            }
            TFCtrl.AC_Tasks = 0; 
            break;
        default:
            TFCtrl.AC_Tasks = 0; 
            break;
    }
}
/*******************************************************************************
 * Function:        InputOutput_sample *
 * Description:     Input and output voltage,current filtering 
 * Calling:         every 100us 
 ******************************************************************************/
void InputOutput_filter(void)
{
    if (L_VOLTAGE_BUF > N_VOLTAGE_BUF)
        Vin = (L_VOLTAGE_BUF - N_VOLTAGE_BUF);
    else
        Vin = (N_VOLTAGE_BUF - L_VOLTAGE_BUF);
    Vbus = VDC_MCU_BUF;
    Iin = I_PFC_MCU_BUF;
    //moving average filter for line voltage 
    uin_fil_sum_50 -= uin_fil[uin_fil_ptr];
    uin_fil_sum_60 -= uin_fil[(uin_fil_ptr >= 40) ? (uin_fil_ptr - 40) : (uin_fil_ptr + 48 - 40)];
    uin_fil[uin_fil_ptr] = Vin;
    uin_fil_sum_50 += uin_fil[uin_fil_ptr];
    uin_fil_sum_60 += uin_fil[uin_fil_ptr];
    if (++uin_fil_ptr >= 48) uin_fil_ptr = 0;
    
    //moving average filter for output voltage
    udc_fil_sum_50 -= udc_fil[udc_fil_ptr];
    udc_fil_sum_60 -= udc_fil[(udc_fil_ptr >= 40) ? (udc_fil_ptr - 40) : (udc_fil_ptr + 48 - 40)];
    udc_fil[udc_fil_ptr] = Vbus;
    udc_fil_sum_50 += udc_fil[udc_fil_ptr];
    udc_fil_sum_60 += udc_fil[udc_fil_ptr];
    if (++udc_fil_ptr >= 48) udc_fil_ptr = 0;
    
    //moving average filter for input current
    iin_fil_sum_50 -= iin_fil[iin_fil_ptr];
    iin_fil_sum_60 -= iin_fil[(iin_fil_ptr >= 40) ? (iin_fil_ptr - 40) : (iin_fil_ptr + 48 - 40)];
    iin_fil[iin_fil_ptr] = Iin;
    iin_fil_sum_50 += iin_fil[iin_fil_ptr];
    iin_fil_sum_60 += iin_fil[iin_fil_ptr];
    if (++iin_fil_ptr >= 48) iin_fil_ptr = 0;
    
    LineFreqDetect();
        // calculate uin_filtered and udc_filtered depending on line frequency
    if (line_freq == 50) {
        uin_filtered = (1365L * uin_fil_sum_50) >> (16 + 2); // div by 48, [10 bits]
        udc_filtered = (1365L * udc_fil_sum_50) >> (16 + 2); // div by 48, [10 bits]
        iin_filtered = (2 * 1365L * iin_fil_sum_50) >> (16 + 2); // div by 48, [10 bits]
    } else { // line_freq==60
        uin_filtered = (1638L * uin_fil_sum_60) >> (16 + 2); // div by 40, [10 bits]
        udc_filtered = (1638L * udc_fil_sum_60) >> (16 + 2); // div by 40, [10 bits]
        iin_filtered = (2 * 1638L * iin_fil_sum_60) >> (16 + 2); // div by 40, [10 bits]
    }
}

/*******************************************************************************
 * Function:        InputOutput_sample *
 * Description:     Input voltage peak detect
 * Calling:         every 100us
 ******************************************************************************/
void InputVoltage_PeakDetec(void)
{
   //Input Peak Sensing
    Vin_Mon.Count++;
    if(Vin > Vin_Mon.VPeak_Temp)
        Vin_Mon.VPeak_Temp = Vin;
    if(Iin > Vin_Mon.IPeak_Temp)
        Vin_Mon.IPeak_Temp = Iin;
    
    if(PRI_STATE.VPOL_2 != PRI_STATE.VPOL)
    {
        if(Vin_Mon.Count > (AC_130_HALF_PERIOD_MAX*2) &&  Vin_Mon.Count < (AC_45_HALF_PERIOD_MAX*2)) //130HZ to 45HZ,From 7.6mS to 11.2mS
        {
            PRI_DATA.VIN_PEAK_ADC = Vin_Mon.VPeak_Temp;
            PRI_DATA.IIN_PEAK_ADC = Vin_Mon.IPeak_Temp;
            Vin_Mon.VPeak_Temp = 0;
            Vin_Mon.IPeak_Temp = 0;
        }
        Vin_Mon.Count = 0;
    }
    else if(Vin_Mon.Count > (AC_45_HALF_PERIOD_MAX*2))
    {
        PRI_DATA.VIN_PEAK_ADC = Vin_Mon.VPeak_Temp;
        PRI_DATA.IIN_PEAK_ADC = Vin_Mon.IPeak_Temp;
        Vin_Mon.VPeak_Temp = 0;
        Vin_Mon.IPeak_Temp = 0;
        Vin_Mon.Count = 0;        
    }
    
    PRI_STATE.VPOL_2 = PRI_STATE.VPOL;
}

 /*******************************************************************************
 * Function:        Vac_Dropout_Detect *
 * Description:     Vac dropout detect,dropout happen return 1
 * Calling:         every 100us
 ******************************************************************************/
void Vac_Dropout_Detect(void)
{
    static unsigned int rcv_cnt = 0,Drop_dly_Cnt=0;
    if(!PRI_STATE.A_AC_Dropout)     
    {
        if(Vin < DROPOUT_THD_ADC_PK)
        {   
            if(Drop_dly_Cnt > DROPOUT_DELAY2_TIME) //can be Dynamic according to Pin
            {  
                Drop_dly_Cnt = 0;
                PRI_STATE.A_AC_Dropout = 1;

                return;
            }
            else if (Drop_dly_Cnt > DROPOUT_DELAY1_TIME)
            {

                AC_OK_Disable();
            }

            Drop_dly_Cnt++;
          //  rcv_cnt = 0;
            if(rcv_cnt!=0)
                rcv_cnt--;
        }
        else
        {      

            Drop_dly_Cnt = 0;
           // Tx_Buf[1]= 0x00;
            if(Drop_dly_Cnt!=0)
                Drop_dly_Cnt--; 
            rcv_cnt++;
            if((rcv_cnt > DROPOUT_RCV_DELAY1_TIME)&&(!PRI_STATE.A_AC_IOV))//one cycle 14ms
            {
                //Tx_Buf[3]=0x33;
                AC_OK_Enable();
                rcv_cnt = 0;
            }
        }
    }
    return;
}
 /*******************************************************************************
 * Function:        Vac_InstUVP_Detect *
 * Description:     Vac Instant UVP detect,under voltage happen return 1
 * Calling:         every 100us
 ******************************************************************************/
void Vac_InstUVP_Detect(void)
{
    static unsigned int InstUV_Dly_Cnt=0;
    if(!PRI_STATE.A_AC_IUV)     
    {
        if(Vin < INST_UVP_THD_ADC_PK)
        {            
            if(InstUV_Dly_Cnt > INST_UVP_DELAY_TIME)
            {
                InstUV_Dly_Cnt = 0;
                PRI_STATE.A_AC_IUV = 1;
                return;
            }
            else
                InstUV_Dly_Cnt++;

        }
        else
        {
            if(InstUV_Dly_Cnt > 0)
                InstUV_Dly_Cnt--;
        }
    }
    return;
}
 /*******************************************************************************
 * Function:        Vac_InstOVP_Detect *
 * Description:     Vac Instant OVP detect,over voltage happen return 1
 * Calling:         every 100us
 ******************************************************************************/
void Vac_InstOVP_Detect(void)
{
    static unsigned int Inst_OV_Dly_Cnt=0;
    
    if(!PRI_STATE.A_AC_IOV)      
    {
        if(Vin > INST_OVP_THD_ADC_PK)
        {            
            if(Inst_OV_Dly_Cnt > INST_OVP_THD_DELAY)
            {
                Inst_OV_Dly_Cnt = 0;
                PRI_STATE.A_AC_IOV = 1;
                return;
            }
            else
                Inst_OV_Dly_Cnt++;
        }
        else
        {            
            if(Inst_OV_Dly_Cnt!=0)
                Inst_OV_Dly_Cnt--;    
        }
    }
    return;
}
 /*******************************************************************************
 * Function:        Vac_Sag_Detect *
 * Description:     Vac sag detect,sag happen return 1
 * Calling:         every 1ms
 ******************************************************************************/
void Vac_Sag_Detect(void)
{
    static unsigned int AC_Sag_Dly_Cnt =0;
   //VIN Sag Detection            
    if(!PRI_STATE.A_AC_Sag)  
    {
        if(PRI_DATA.VRMS_Inst < AC_SAG_THD)
        {            
            if(AC_Sag_Dly_Cnt > AC_SAG_DELAY_TIME)
            {
                AC_Sag_Dly_Cnt = 0;
                PRI_STATE.A_AC_Sag = 1;
                return;
            }
            else
                AC_Sag_Dly_Cnt++;
        }
        else
        {
            if(AC_Sag_Dly_Cnt!=0)
                AC_Sag_Dly_Cnt--;                
        }
    }

    return;
}

 /*******************************************************************************
 * Function:        VacRms_OVP_Detect *
 * Description:     Vac rms OVP detect,OVP happen return 1
 * Calling:         every 1ms
 ******************************************************************************/
void VacRms_OVP_Detect(void)
{
    static unsigned int AC_OVP_cnt =0,AC_OVP_Rcv_cnt =0;

   //Input Over Voltage
    if(!PRI_STATE.A_AC_OV)        //if Input OK Test for Over Voltage
    {
        if(PRI_DATA.VRMS_Inst > AC_OV_TRIG_THD)
        {
            AC_OVP_cnt++;
            if(AC_OVP_cnt > AC_OV_TRIG_DELAY)
            {
                AC_OVP_cnt = 0;
                PRI_STATE.A_AC_OV = 1;
                return;
            }
        }
        else
        {
            if(AC_OVP_cnt > 0)
               AC_OVP_cnt--; 
        }
    }
    else                        //if Input Over voltage test for Pass
    {
        if(PRI_DATA.VRMS_Inst < AC_OV_RECVR_THD)
        {
            AC_OVP_Rcv_cnt++;
            if(AC_OVP_Rcv_cnt > AC_OV_RECVR_DELAY)
            {
                AC_OVP_Rcv_cnt = 0;
                PRI_STATE.A_AC_OV = 0;
                return;
            }
        }
        else
        {
            if(AC_OVP_Rcv_cnt > 0)
               AC_OVP_Rcv_cnt--; 
        }
    }
    return;
}

 /*******************************************************************************
 * Function:        VacRms_UVP_Warning *
 * Description:     Vac rms UVP warning,UVP happen return 1
 * Calling:         every 1ms
 ******************************************************************************/
void VacRms_UVP_Warning(void)
{
    static unsigned int AC_UVW_Cnt=0,AC_UVW_Rcv_Cnt=0;

        //Input Under Voltage Warning
    if(!PRI_STATE.A_AC_UVW)        
    {
        if(PRI_DATA.VRMS_Inst < AC_UVW_TRIG_THD && !PRI_STATE.A_AC_Sag)
        {
            AC_UVW_Cnt++;
            if(AC_UVW_Cnt > AC_UVW_TRIG_DELAY)
            {
                AC_UVW_Cnt = 0;
                PRI_STATE.A_AC_UVW = 1;
                return;
            }
        }
        else
        {
            if(AC_UVW_Cnt > 0)
               AC_UVW_Cnt--; 
        }
    }
    else                        //if Input Under voltage Warning test for Pass
    {
        if(PRI_DATA.VRMS_Inst > AC_UVW_RECVR_THD)
        {
            AC_UVW_Rcv_Cnt++;
            if(AC_UVW_Rcv_Cnt > AC_UVW_RECVR_DELAY)
            {
                AC_UVW_Rcv_Cnt = 0;
                PRI_STATE.A_AC_UVW = 0;
                return;
            }
        }
        else
        {
            if(AC_UVW_Rcv_Cnt > 0)
               AC_UVW_Rcv_Cnt--; 
        }
    }
    return;
}

 /*******************************************************************************
 * Function:        VacRms_OVP_Warning *
 * Description:     Vac rms OVP warning,OVP happen return 1
 * Calling:         every 1ms
 ******************************************************************************/
void VacRms_OVP_Warning(void)
{
    static unsigned int AC_OVW_Cnt=0;
    //Input Over Voltage Warning
    if(!PRI_STATE.A_AC_OVW)          {
        if(PRI_DATA.VRMS_Inst > AC_OVW_TRIG_THD && !PRI_STATE.A_AC_OV)
        {
            AC_OVW_Cnt++;
            if(AC_OVW_Cnt > AC_OVW_TRIG_DELAY)
            {
                AC_OVW_Cnt = 0;
                PRI_STATE.A_AC_OVW = 1;
                return;
            }
        }
        else
            AC_OVW_Cnt = 0;
    }
    else                        //if Input OVER  voltage Warning test for Pass
    {
        if(PRI_DATA.VRMS_Inst < AC_OVW_RECVR_THD)
        {
            AC_OVW_Cnt++;
            if(AC_OVW_Cnt > AC_OVW_RECVR_DELAY)
            {
                AC_OVW_Cnt = 0;
                PRI_STATE.A_AC_OVW = 0;
                return;
            }
        }
        else
            AC_OVW_Cnt = 0;
    }
    return;
}

 /*******************************************************************************
 * Function:        IacRms_OCW_Warning *
 * Description:     Iac rms OCP warning,OCP happen return 1
 * Calling:         every 1ms
 ******************************************************************************/
void IacRms_OCW_Warning(void)
{
    static unsigned AC_OCW_Cnt=0;
   //Input Over Current Warning
    if(!PRI_STATE.A_AC_OCW)         
    {
        if(PRI_DATA.IRMS_Inst > AC_OCW_TRIG_THD)
        {
            AC_OCW_Cnt++;
            if(AC_OCW_Cnt > AC_OCW_TRIG_DELAY)
            {
                AC_OCW_Cnt = 0;
                PRI_STATE.A_AC_OCW = 1;
                return;
            }
        }
        else
            AC_OCW_Cnt = 0;
    }
    else                        //if Input OVER  voltage Warning test for Pass
    {
        if(PRI_DATA.IRMS_Inst < AC_OCW_RECVR_THD)
        {
            AC_OCW_Cnt++;
            if(AC_OCW_Cnt > AC_OCW_RECVR_DELAY)
            {
                AC_OCW_Cnt = 0;
                PRI_STATE.A_AC_OCW = 0;
                return;
            }
        }
        else
            AC_OCW_Cnt = 0;
    }
    return;
}
 /*******************************************************************************
 * Function:        AC_Line_Detect
 * Description:     
 * Calling:         every 10ms
 ******************************************************************************/
void AC_Line_Detect()
{
    static unsigned int V_Range_Count = 0; 
    //Detect Line Voltage Level
    if(!PRI_STATE.VAC_Range_LL) //if High Line Sense for Low Line
    {
        if(PRI_DATA.VIN_PEAK_ADC < VIN_LOW_LINE_ADC_PK)  // < 166VAC
        {
            V_Range_Count++;
            if(PRI_DATA.VIN_PEAK_ADC < VIN_LOW_LINE_ADC_PK2)  // < 125VAC
            {
                if(V_Range_Count > 12)   // 5ms*12=60mS
                {
                    V_Range_Count = 0;
                    PRI_STATE.VAC_Range_LL = 1;
                }
            }
            else if(PRI_DATA.VIN_PEAK_ADC < VIN_LOW_LINE_ADC_PK1)  // < 145VAC
            {
                if(V_Range_Count > 30)   // 5ms*120=150mS
                {
                    V_Range_Count = 0;
                    PRI_STATE.VAC_Range_LL = 1;
                }
            }
            else
            {
                if(V_Range_Count > 60)   // 5m*60=300mS
                {
                    V_Range_Count = 0;
                    PRI_STATE.VAC_Range_LL = 1;
                }                                
            }                            
        }
        else
            V_Range_Count = 0;
    }
    else
    {
        if(PRI_DATA.VIN_PEAK_ADC > VIN_HIGH_LINE_ADC_PK)  // > 170VAC
        {
            V_Range_Count++;
            if(V_Range_Count > 2)   //2 *5ms = 10ms ,in *10mS Steps
            {
                PRI_STATE.VAC_Range_LL = 0;
            }
        }
        else
            V_Range_Count = 0;
    }
}
/*******************************************************************************
 * Function:        Input_Measurement *
 * Description:     input voltage fail detection
 * Calling:         every 100us
 ******************************************************************************/
void Input_Measurement(void)
{
    InputVoltage_PeakDetec();
    if(PRI_STATE.AC_OK)
    {
        Vac_Dropout_Detect();
    }
    Vac_InstUVP_Detect();    //Instant under voltage
    Vac_InstOVP_Detect();
    
    if(!PRI_STATE.AC_OK)   //for input more than OVP THR when starting
    {
        if(PRI_STATE.A_AC_OV)
        {
          //  Tx_Buf[1]=0xBB;
                PRI_STATE.AC_OK = 0;
                AC_OK_Disable();
        }
    }
    //AC OK Pin Control
    if(PRI_STATE.AC_OK)   
    {     
        if(PRI_STATE.A_AC_Dropout || PRI_STATE.A_AC_IUV || PRI_STATE.A_AC_IOV || PRI_STATE.A_AC_Sag)
        {
            PRI_STATE.AC_OK = 0;
            Tx_Buf[5]=0x55;
			AC_OK_Disable(); 
        }
    }
   
        
}
/*******************************************************************************
 * Function:        Input_Rms_Measurement *
 * Description:     
 * Calling:         1ms
 ******************************************************************************/

void Input_Rms_Measurement()
{
    Vac_Sag_Detect();
    VacRms_OVP_Detect();
//  VacRms_UVP_Warning();
//  VacRms_OVP_Warning();
//  IacRms_OCW_Warning();
}
/*******************************************************************************
 * Function:        Input_Judgement
 * Description:     Judge input peak voltage,fast input fail detetion, PLD,AC_OK judgment 
 * Calling:         every 1ms
 ******************************************************************************/
void Input_Judgement(void)
{
    static unsigned int Vin_OK_Cnt=0;
    if(!PRI_STATE.AC_OK) //if AC not OK
    {
        if((PRI_DATA.VRMS_Inst > VIN_OK_THD) && (!PRI_STATE.A_AC_OV))//(PRI_DATA.VIN_PEAK_ADC < INST_OVP_THD_ADC_PK))
        {
            if(Vin_OK_Cnt > VIN_OK_DELAY) 
            {
                PRI_STATE.AC_OK = 1;
                PRI_STATE.A_AC_Dropout = 0;
                PRI_STATE.A_AC_IUV = 0;
                PRI_STATE.A_AC_IOV = 0;
                PRI_STATE.A_AC_Sag = 0;

                Vin_OK_Cnt = 0;
                //Tx_Buf[1]=0xCC;

				AC_OK_Enable(); 
            }
            else
                Vin_OK_Cnt++;
        }
        else if(Vin_OK_Cnt > 0)
            Vin_OK_Cnt--; 
    }
}
/*******************************************************************************
 * Function:        Thermistor_measurement
 * Description:     
 * Calling:         every 1ms
 ******************************************************************************/

void Thermistor_measurement()
{
    static unsigned int tmp_a=0,tmp_b=0;
    
	TMP_ADC += T_PFC_BUF;	
    ADC_Arr[2] += T_AMBIENT_MCU_BUF;	
	T_ADC_Count++;
	
	if(T_ADC_Count > 31)
	{
		tmp_a = (unsigned int)( (TMP_ADC+16)>>5 ); 
       // Tx_Buf[1] = tmp_a;
       // Tx_Buf[2] = tmp_a>>8;
        tmp_b = (unsigned int)( (ADC_Arr[2]+16)>>5 ); 
		TMP_ADC = 0;
        ADC_Arr[2] = 0;
		T_ADC_Count = 0;
	}
   // Temp_ui32_a = (unsigned long) __builtin_muluu(tmp_a, 4096); //gain 0.8*128=102
   // tmp_a = (unsigned int) ((Temp_ui32_a + 2048) >> PRI_DATA.BULK_DIV);
   // Temp_ui32_b = (unsigned long) __builtin_muluu(tmp_b, 1); //gain 0.8
    PRI_DATA.T_PFC_A = tmp_a;
    PRI_DATA.T_PFC_B = tmp_b;
    
}	

/*******************************************************************************
 * Function:        Relay_Control
 * Description:     Relay control on/off timing
 * Calling:         every 1ms
 ******************************************************************************/
void Relay_Control(void)
{
    static unsigned int Relay_Start_Cnt = 0;
    
   if(PRI_DATA.VIN_PEAK_ADC > RELAY_ON_THD_ADC_PK)
    {
        if(!PRI_STATE.Relay_Start)
        {
                //Tx_Buf[1]=0xA2;

            Relay_Start_Cnt++;
           
            if((((int)PRI_DATA.VIN_PEAK_ADC - (int) Vbus) < (int) VIN_VBUS_DIFF_ADC) && Relay_Start_Cnt > RELAY_START_DELAY)
            {
                Relay_Start_Cnt = 0;
                PRI_STATE.Relay_Start = 1;
				Relay_ON_Enable();  
                // Tx_Buf[1]=0x01;
                //  Tx_Buf[2]=0x00;
            }
        }
    }
    else if((PRI_DATA.VIN_PEAK_ADC < RELAY_OFF_THD_ADC_PK) && (!PRI_STATE.PFC_En))
    {
        // Tx_Buf[2]=0x02;
        PRI_STATE.Relay_PWM_ON = 0;
        PRI_STATE.Relay_Start = 0;
       // Tx_Buf[4]=0x04;
        Relay_ON_Disable();
        Relay_Start_Cnt = 0;  
    }
}

/*******************************************************************************
 * Function:        Bulk_Measurement *
 * Description:     Bulk Voltage fail detection
 * Calling:         every 100us
 ******************************************************************************/
void Bulk_Measurement(void)
{
    static uint16_t tmp_p;
    static unsigned int Bulk_UV1_Cnt = 0,Bulk_UV2_Cnt = 0,Bulk_Ok_Cnt = 0,Bulk_ovp_l2_cnt=0;
    //Bulk UV 1 - Fast Response
    if(!PRI_STATE.A_BULK_UV1)        //Bulk Pass Test for Under Voltage
    {
        if(Vbus < BULK_UV1_THD_ADC)
        {
            Bulk_UV1_Cnt++;
            if(Bulk_UV1_Cnt > BULK_UV1_TRIG_DELAY)
            {
                PRI_STATE.A_BULK_UV1 = 1;
                Bulk_UV1_Cnt = 0;
            }
        }
        else
            Bulk_UV1_Cnt = 0;
    }
    
    ///Bulk UV 2  - Slow Response
    if(!PRI_STATE.A_BULK_UV2)        //if Bulk Pass Test for Under Voltage
    {
        if(Vbus < BULK_UV2_THD_ADC)
        {
            Bulk_UV2_Cnt++;
            if(Bulk_UV2_Cnt > BULK_UV2_TRIG_DELAY)
            {
                PRI_STATE.A_BULK_UV2 = 1;
                Bulk_UV2_Cnt = 0;
            }
        }
        else
            Bulk_UV2_Cnt = 0;
    }
    
    if(PRI_STATE.A_BULK_UV1 || PRI_STATE.A_BULK_UV2)                         //if Bulk Under voltage test for Pass
    {
        if(Vbus > BULK_OK_THD_ADC && PRI_STATE.PFC_En) 
        {
            Bulk_Ok_Cnt++;
            if(Bulk_Ok_Cnt > (BULK_OK_DLY + Bulk_OK_Var_Delay))
            {
                PRI_STATE.A_BULK_UV1 = 0;
                PRI_STATE.A_BULK_UV2 = 0;
                Bulk_Ok_Cnt = 0;
                Bulk_OK_Var_Delay = 0;
            }
        }
        else
            Bulk_Ok_Cnt = 0;
    }
    
    if(PRI_DATA.BULK_ADC_AVG > BULK_OV_THD_ADC)  //Bulk OVP //high level go latch
    {
       // Tx_Buf[4]=0xFF;
        PRI_STATE.A_BULK_OV_H_ALERT = 1;   
        PFC_IC_Disable();
        PRI_STATE.PFC_En = 0;
    }
    
    if(PRI_DATA.BULK_ADC_AVG > BULK_OV_LEVEL1_THD_ADC) //middle level wait for voltage go down
    {
            tmp_p = PRI_DATA.BULK_ADC_AVG;
			//Tx_Buf[5] = tmp_p;
			//Tx_Buf[6] = tmp_p >> 8;
        Bulk_ovp_l2_cnt++;
        if(Bulk_ovp_l2_cnt > BULK_OV_LEVEL1_RECVR_DELAY)
        {
            PRI_STATE.A_BULK_OV_ALERT = 1;   
          //  Tx_Buf[2]=0x33;

            PFC_IC_Disable(); 
            Bulk_ovp_l2_cnt = 0;
            PRI_STATE.PFC_En = 0;
        }
    }
    else
    {
        if(Bulk_ovp_l2_cnt > 0)
            Bulk_ovp_l2_cnt--;
    }    
    
    //Bulk OK Pin Control
    if(PRI_STATE.BULK_OK)   
    {      
        if((PRI_STATE.A_BULK_UV2)||(PRI_STATE.A_BULK_UV1))   
        {
            PRI_STATE.BULK_OK = 0;
            PRI_STATE.BULK_OFF = 1;
            PFC_IC_Disable();  
            PRI_STATE.PFC_En = 0;
            PRI_STATE.LLC_ok_en = 0;
            PFC_OK_Disable();
            //LLC_IC_Disable();
            Tx_Buf[3]=0x03;
        }
        Tx_Buf[1]=0x11;
    }
    else
    {
       
        if((!PRI_STATE.A_BULK_UV2)&&(!PRI_STATE.A_BULK_UV1))  
        {
            PRI_STATE.BULK_OK = 1;
            PRI_STATE.BULK_OFF = 0;
           // temp = ADCBUF5;
            //Tx_Buf[5]=temp;
           // Tx_Buf[6]=temp>>8;
            PFC_OK_Enable();
            PRI_STATE.LLC_ok_en = 1;
            //LLC_IC_Enable(); 
        }
    }
}
/*******************************************************************************
 * Function:        TMP_Judgement
 * Description:     
 * Calling:         every 1ms
 ******************************************************************************/

void TMP_Judgement()
{
    static int pfc_otp_cnt = 0,pfc_otp_rcv_cnt = 0,amb_otp_cnt=0,amb_otp_rcv_cnt=0;
    
    if(!PRI_STATE.PFC_OTP)        //if Input OK Test for Over Voltage
    {
        if(PRI_DATA.T_PFC_A < PRI_PFC_MAX_TMP)  //120  reverse logic
        {
            pfc_otp_cnt++;
           // if(pfc_otp_cnt > PFC_OTP_TRIG_DELAY)
            {
                pfc_otp_cnt = 0;
                PRI_STATE.PFC_OTP = 1;
                //Tx_Buf[1] = 0xBB;
            }
        }
        else
            pfc_otp_cnt = 0;
        pfc_otp_rcv_cnt = 0;
    }
    else                        //if Input Over voltage test for Pass
    {
        pfc_otp_cnt = 0;
        if(PRI_DATA.T_PFC_A > PRI_PFC_RECV_TMP)
        {
            pfc_otp_rcv_cnt++;
          //  if(pfc_otp_rcv_cnt > PRI_PFC_OTP_RECV_DELAY)
            {
                pfc_otp_rcv_cnt = 0;
                PRI_STATE.PFC_OTP = 0;
                //Tx_Buf[1] = 0xCC;
            }
        }
        else
            pfc_otp_rcv_cnt = 0;
    }
        
    if(!PRI_STATE.AMB_OTP)        //if Input OK Test for Over Voltage
    {
        if(PRI_DATA.T_PFC_B < PRI_AMBIENT_MAX_TMP) //50
        {
            amb_otp_cnt++;
            // if(amb_otp_cnt > AMB_OTP_TRIG_DELAY)
            {
                amb_otp_cnt = 0;
                PRI_STATE.AMB_OTP = 1;
            }
        }
        else
            amb_otp_cnt = 0;
        amb_otp_rcv_cnt = 0;
    }
    else
    {
        if(PRI_DATA.T_PFC_B > PRI_AMBIENT_RECV_TMP)
        {
            amb_otp_rcv_cnt++;
          //  if(amb_otp_rcv_cnt > PRI_AMB_OTP_RECV_DELAY)
            {
                amb_otp_rcv_cnt = 0;
                PRI_STATE.AMB_OTP = 0;
            }
        }
        else
            amb_otp_rcv_cnt = 0;
        amb_otp_cnt = 0;
    }
    return;
}

/*******************************************************************************
 * Function:        Status_Control
 * Description:     status control on/off timing
 * Calling:         every 1ms
 ******************************************************************************/
void Status_Control(void)
{   

    static unsigned int Bulk_OFF_OVP_H_cnt = 0, Bulk_OFF_OVP_cnt= 0,PFC_ON_Cnt = 0,PFC_OFF_Cnt = 0,PFC_Restart_Cnt = 0;

    switch(PFC_State)
    {
        case PFC_INIT: 
            if(PRI_STATE.AC_OK && PRI_STATE.Relay_Start)
            {
                if((PFC_ON_Cnt > PFC_ON_DELAY))//&&(PRI_STATE.PS_ON_En == 1)) //comment for testing
                {
                    PFC_ON_Cnt = 0;
                    PRI_STATE.PFC_En = 1; 
                    Bulk_Startup_Sta = 1;           
                    PFC_State = PFC_ON;
                    PFC_IC_Enable(); 
                    //To Provide Consistent Bulk OK Delay to Sec Side
                    if(PRI_DATA.VRMS_Inst > 100)                        //>100V*Resolution,Resolution=1
                        Bulk_OK_Var_Delay = PRI_DATA.VRMS_Inst - 100;   //-100*Resolution,Resolution=1
                    else
                        Bulk_OK_Var_Delay = 0;
                }
                else
                    PFC_ON_Cnt++;
            }
            else
            {
                if(PFC_ON_Cnt > 0)
                    PFC_ON_Cnt--;
            }
            PFC_Restart_Cnt = 0;
            break;
        case PFC_ON: 
            if(PRI_STATE.PS_ON_En == 0)
            {
             //   PRI_STATE.PFC_En = 0;//comment for testing
            //    PFC_IC_Disable();//comment for testing
            //    PFC_State = PFC_OFF; //comment for testing
           //     Tx_Buf[6]=0x77;
            }
           //  Tx_Buf[1]=0x00;
            if(!PRI_STATE.AC_OK)
            {
                //Tx_Buf[1]=0x22;
                PFC_OFF_Cnt++;
                if(PFC_OFF_Cnt > PFC_OFF_DELAY)//9ms
                {
                    PFC_OFF_Cnt = 0;
                    PFC_IC_Disable(); 
                   //Relay_ON_Disable();//before add to do input OVP happen relay off to release the vbulk voltage,OVP should do seperate protection,when OVP happend off PFC IC and Relay,send PFC not ok to secondary
                  //  Tx_Buf[1]=0x11;
                   // PFC_OK_Disable(); //no need to turn off PFC here, PFC will off when vbulk <280V,except input OVP
                    PRI_STATE.PFC_En = 0;
                   //PFC_ALWAYS_OFF:AC not ok go to latch mode
                    if(PRI_STATE.A_AC_IOV == 1)
                    {
                        PFC_OK_Disable();  //for secondary off the main output when input OVP,others pfc not ok is base on Vbulk < 300V
                        PRI_STATE.BULK_OK = 0;
                    }
                    
                     PFC_State = PFC_OFF;
                }
            }
            else
            {
                PFC_OFF_Cnt = 0;
            }
            if(PRI_STATE.A_BULK_OV_H_ALERT)//PFC IC already off in faster loop
            {
                Bulk_OFF_OVP_H_cnt++; 
                if(Bulk_OFF_OVP_H_cnt > PFC_OFF_DELAY) 
                {
                    Bulk_OFF_OVP_H_cnt =0;
                    PRI_STATE.PFC_En = 0;
                  //  PFC_OK_Disable();
                    //Tx_Buf[2]=0x22;
                    PFC_State = PFC_ALWAYS_OFF; 
                   // Tx_Buf[3]=0xEE;
                }
            }
            else
            {
                if(Bulk_OFF_OVP_H_cnt > 0)
                    Bulk_OFF_OVP_H_cnt--;
            }

            if(PRI_STATE.A_BULK_OV_ALERT)//PFC IC already off in faster loop
            {
                Bulk_OFF_OVP_cnt++; 
             //   if(Bulk_OFF_OVP_cnt > PFC_OFF_DELAY)  
                {
                    Bulk_OFF_OVP_cnt =0;
                    PRI_STATE.PFC_En = 0;
                   // PFC_OK_Disable();
                   // Tx_Buf[6]=0xCC;
                   // LLC_IC_Disable();
                    PRI_STATE.LLC_ok_en = 0;
                    PFC_State = PFC_OFF; 
                    //Tx_Buf[7]=0x07;
                }
            }
            else
            {
                if(Bulk_OFF_OVP_cnt > 0)
                    Bulk_OFF_OVP_cnt--;
            }
       
            if((PRI_STATE.AMB_OTP)||(PRI_STATE.PFC_OTP)) //tmp protection
            {
                PRI_STATE.PFC_En = 0;
                PFC_IC_Disable();
             //   PFC_OK_Disable();
              //  Tx_Buf[4]=0x44;
              //  LLC_IC_Disable();
                PRI_STATE.LLC_ok_en = 0;
                PFC_State = PFC_OFF; 
               // Tx_Buf[6]=0xBB;
            }
            else
            {
                //Tx_Buf[2]=0xEE;
            }
            if(PRI_DATA.Filted_IRms_ADC > 0x4095)//18://10A:0x3161 //0x2521 //current protection,8amps?
            {
                PRI_STATE.PFC_En = 0;
                PFC_IC_Disable();
               // PFC_OK_Disable();
               // Tx_Buf[6]=0x66;
               // LLC_IC_Disable();
                PFC_State = PFC_OFF;          
            }
            if((PRI_DATA.PIN_ADC_Avg > 0x0EE4)||(PRI_DATA.VRMS_ADC_Avg > 0x079D)) //input power 400w,input 250V  (0x11FF,0x079D) 0x17EF = 0x11FF*1.33,0x17EF 500W,0x0EE4 400W
            {
               BULK_VOLT_REG_Enable();
               // Tx_Buf[2]=0xBB;
            }
            else
            {
               BULK_VOLT_REG_Disable();
               // Tx_Buf[2]=0xEE;
            }
            PFC_Restart_Cnt = 0;
            if(PRI_STATE.BULK_OFF == 1)  // after ac drop, vbulk < 290V ,pfc off,psu off
            {
                PFC_State = PFC_OFF;
            }
            break;
        case PFC_OFF:  //Wait for Restart Delay
           if(!PRI_STATE.AC_OK)
            {
                //PFC_IC_Disable();  
                PRI_STATE.PFC_En = 0; 
                if(PRI_STATE.A_AC_IOV == 1)
                {
                   // Tx_Buf[6]=0x06;
                    PFC_OK_Disable();  //for secondary off the main output when input OVP,others pfc not ok is base on Vbulk < 300V
                    PRI_STATE.BULK_OK = 0;
                }
                else
                {
                   // Tx_Buf[6]=0;
                }
            }
            if(PFC_Restart_Cnt < PFC_RESTART_DELAY)
            {
                PFC_Restart_Cnt++;
            }
            else
            {
                PFC_State = PFC_INIT;
                PFC_Restart_Cnt = 0;
                //Env_Init();
            }
           if(PRI_STATE.PFC_En == 0)
           {
                PFC_IC_Disable();
           }
          //  PRI_STATE.A_AC_Dropout = 0;
          //  PRI_STATE.A_AC_IUV = 0;
          //  PRI_STATE.A_AC_Sag = 0;
            PFC_OFF_Cnt = 0;
            PRI_STATE.Relay_Start = 0;
            Relay_ON_Disable();
            PRI_STATE.PFC_En = 0;
            PRI_STATE.BULK_OFF = 0;
            break;
        case PFC_ALWAYS_OFF:
           // LLC_IC_Disable();
            PRI_STATE.LLC_ok_en = 0;
            break;
        default:
            PFC_State = PFC_INIT;
            PFC_ON_Cnt = 0;
            PFC_OFF_Cnt = 0;
            break;
    }
   
}
//100us 
void VBulk_Rms_Calculation(void)
{
    unsigned long Temp_ui32;
            //Bulk Voltage Calculation
    ADC_Arr[0] += Vbus;

    ADC_Acc_Cnt++;
    if(ADC_Acc_Cnt > 31)            
    {               
        PRI_DATA.BULK_ADC_AVG = (unsigned int)( (ADC_Arr[0]+16) >> 5 );                
        Temp_ui32 = (unsigned long) __builtin_muluu(PRI_DATA.BULK_ADC_AVG, PRI_DATA.BULK_GAIN); 
        PRI_DATA.DC_BULK = (unsigned int) ((Temp_ui32 + 2048) >> PRI_DATA.BULK_DIV);

        ADC_Arr[0] = 0;
        ADC_Acc_Cnt = 0;                 
    }
}
//100us
void LLC_enable_Judgment()
{
    int16_t tmp_p;
  static unsigned int LLC_on_Cnt = 0,LLC_off_Cnt=0;
    if(PRI_STATE.LLC_ok_en)  //directly disable in loop,got problems when status entered pfc_off 
    {
        if(LLC_on_Cnt < LLC_ON_DELAY)  
        {
            LLC_on_Cnt++; 
        }
        else
        {
           LLC_IC_Enable();
           LLC_on_Cnt = 0;
        } 
        LLC_off_Cnt = 0;
    }
    else
    {
        if(LLC_off_Cnt < LLC_OFF_DELAY)  
        {
            LLC_off_Cnt++; 
        }
        else
        {
           LLC_IC_Disable();
           LLC_off_Cnt = 0;
        }
         LLC_on_Cnt = 0;
    }
}
/*******************************************************************************
 * Function:        Task_handler()
 * Description:     200uS/1mS/10mS Taskes called from T1 interrupt
 * Calling:         every 100us
 *****************************************************************************/

void Task_handler(void)
{    
    int16_t tmp_p;
   //power meter called in ADC interrupt
    Input_Measurement();
    Bulk_Measurement();
    VBulk_Rms_Calculation();
    LLC_enable_Judgment();
    TFCtrl.StepCounter_basc++;
    switch(TFCtrl.StepCounter_basc)   //1mS Tasks
    {
        case 1:
            Input_Rms_Measurement();
            Input_Judgement();         
            Relay_Control();
            TMP_Judgement();
            break;
        case 2: 
            Status_Control();
            break;
        case 3:
            //UART Tx Processing to Secondary
            Uart_TxData(); 
            break;
        case 4:
            AC_RMS_Calculation();   
            Thermistor_measurement();
            Iin_filt = PRI_DATA.IRms_ADC;
            LowerPass_filter_Iin();
            PRI_DATA.Filted_IRms_ADC = Ifilter.f_out;
            break;
        case 5:
            break;
        case 6:
            break;
        case 7:
            break;
        case 8:
            break;
        case 9:
            break;
        case 10:
            TFCtrl.StepCounter_basc = 0;
            TFCtrl.StepCounter_10basc++;
            switch(TFCtrl.StepCounter_10basc)  //10mS Tasks,5ms
            {
                case 1:
                    //Process Receiver Data once Every 10mS in timer3
                    break;
                    AC_Line_Detect();
                case 2:                 
                    break; 
                case 3:
                    break;
                case 4:
                   // Tx_Buf[0] = 0xAA;
                  //   Tx_Buf[1] = 0x02;
                  //   Tx_Buf[2] = 0x03;
                    // uart comm data
                    /*
                    Tx_Buf[0] = 0; //status
                    Tx_Buf[1]=0;
                    Tx_Buf[2]=0;
                    tmp_p = PRI_DATA.T_PFC_A;//PRI_DATA.T_PFC_A;
                    Tx_Buf[2] = tmp_p; //T1_H
                    Tx_Buf[1] = tmp_p>>8; //T1_L                  
                    Tx_Buf[3]=0;
                    Tx_Buf[4]=0;
                    tmp_p = PRI_DATA.T_PFC_B;//PRI_DATA.T_PFC_B;
                    Tx_Buf[4] = tmp_p; //T1_H
                    Tx_Buf[3] = tmp_p>>8; //T1_L
                    Tx_Buf[5] = 0; //FW_REV_LB
                    Tx_Buf[6] = 0; //FW_REV_HB                     
                   Tx_Buf[7] = 0; //FW_REV_LB
                    Tx_Buf[8] = 0; //FW_REV_HB
                    tmp_p = PRI_DATA.VRMS_Avg;
                    Tx_Buf[8] = tmp_p; //Vac_LB
                    Tx_Buf[7] = tmp_p >> 8; //Vac_HB
                    Tx_Buf[9] = 0; //FW_REV_LB
                    Tx_Buf[10] = 0; //FW_REV_HB
                    tmp_p = PRI_DATA.DC_BULK;
                    Tx_Buf[10] = tmp_p; //Vdc_LB
                    Tx_Buf[9] = tmp_p >> 8; //Vdc_HB
                    Tx_Buf[11] = 0; //FW_REV_LB
                    Tx_Buf[12] = 0; //FW_REV_HB
                    tmp_p = PRI_DATA.Filted_IRms_ADC;
                    Tx_Buf[12] = tmp_p; //Vdc_LB
                    Tx_Buf[11] = tmp_p >> 8; //Vdc_HB
                    */
                 
/*
                    Tx_Buf[0]=0;
                    Tx_Buf[1]=1;
                    Tx_Buf[2]=2; //T1_H
                    Tx_Buf[3]=3; //T1_L                  
                    Tx_Buf[4]=4;
                    Tx_Buf[5]=5;
                    Tx_Buf[6]=6; //T1_H
                    Tx_Buf[7]=7; //T1_L
                    Tx_Buf[8]=8; //FW_REV_LB
                    Tx_Buf[9]=9; //FW_REV_HB                     
                    Tx_Buf[10]=10; //FW_REV_LB
                    Tx_Buf[11]=11; //FW_REV_HB
                    Tx_Buf[12]=12; //FW_REV_HB
 */
                   /* 
                    tmp_p = PRI_DATA.VRMS_ADC_Avg;
                    Tx_Buf[3] = tmp_p; //VRMS_Avg:real value not ADC value
					Tx_Buf[4] = tmp_p >> 8; //VRMS_Avg:real value not ADC value
                    
                    tmp_p = PRI_DATA.Filted_IRms_ADC;
                 //   Tx_Buf[3] = tmp_p;
                 //   Tx_Buf[4] = tmp_p >> 8;

                    tmp_p = PRI_DATA.IRMS_Avg;
                 //   Tx_Buf[3] = tmp_p;  //real_current *16
                 //   Tx_Buf[4] = tmp_p >> 8;
                    tmp_p = PRI_DATA.BULK_ADC_AVG;
                    tmp_p = PRI_DATA.BULK_ADC_AVG;
					Tx_Buf[5] = tmp_p;
					Tx_Buf[6] = tmp_p >> 8;
                    if(PRI_DATA.VRMS_Avg > 260)  
                //        Tx_Buf[7] = 0xBB;
                */
    /*                
                    Tx_Buf[3]=0;
                    Tx_Buf[4]=0;
                    tmp_p = PRI_DATA.PIN_ADC_Avg;//PRI_DATA.T_PFC_A;
                    Tx_Buf[3] = tmp_p; //T1_L
                    Tx_Buf[4] = tmp_p>>8; //T1_H
       */             
/*
                    Tx_Buf[3]=0;
                    Tx_Buf[4]=0;
                    tmp_p = PRI_DATA.T_PFC_A;//PRI_DATA.T_PFC_A;
                    Tx_Buf[3] = tmp_p; //T1_L
                    Tx_Buf[4] = tmp_p>>8; //T1_H
                    Tx_Buf[5]=0;
                    Tx_Buf[6]=0;
                    tmp_p = PRI_DATA.T_PFC_B;//PRI_DATA.T_PFC_B;
                    Tx_Buf[5] = tmp_p; //T1_L
                    Tx_Buf[6] = tmp_p>>8; //T1_H
 */
                    break;
                case 5:
                    break;
                case 6:
                    break;
                case 7:
                    break;
                case 8:
                    break;
                case 9:
                   // lED1_Toggle();
                    break;
                case 10:
                    TFCtrl.StepCounter_10basc = 0;                       
                default:
                    TFCtrl.StepCounter_10basc = 0;           
                    break;
            }
            break;
	
        default:
            TFCtrl.StepCounter_basc = 0;           
            break;
    }           
   
   // ClrWdt(); // clear watch dog counter  
    return;
}
