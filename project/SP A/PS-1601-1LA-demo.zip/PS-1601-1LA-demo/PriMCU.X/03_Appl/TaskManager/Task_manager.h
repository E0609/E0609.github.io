/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/* 
 * File:   task_manager.h
 * Author: shuangcai
 * Comments:
 * Revision history: 
 */
#include "headers.h"
#ifndef TASK_MANAGER_H
#define	TASK_MANAGER_H
//Control Status Flags
typedef union {
    unsigned int i16[3];
    struct {
        unsigned Tsk_Start:1;
        unsigned :1;
        unsigned :1;
        unsigned :1;
        unsigned :1;
        unsigned :1;
        unsigned :1;
        unsigned :1;
        unsigned :1;
        unsigned :1;
        unsigned :1;
        unsigned :1;
        unsigned :1;
        unsigned :1;
        unsigned :1;
        unsigned :1;
        //
        unsigned StepCounter_basc:8;
        unsigned StepCounter_10basc:8;
        unsigned StepCounter_100basc:8;
        unsigned AC_Tasks:8;        
    };
}FLAG_STA;
extern FLAG_STA TFCtrl;
typedef struct
{
    unsigned int VPeak_Temp;
    unsigned int IPeak_Temp;
    unsigned int Count;
}VinVoltage;
extern VinVoltage Vin_Mon;
typedef struct
{
    unsigned int Sample_Cnt_Tmp;
    unsigned long long Vin_Sum_Tmp;
    unsigned long long Iin_Sum_Tmp;
    unsigned long long Pin_Sum_Tmp;
    
    unsigned int Sample_Cnt;
    unsigned long long Vin_Sum;
    unsigned long long Iin_Sum;
    unsigned long long Pin_Sum;
    
    unsigned int Sample_Cnt2;
    unsigned long long Vin_Sum2;
    unsigned long long Iin_Sum2;
    unsigned long long Pin_Sum2;
    
    unsigned long VRms_Sum;
    unsigned long IRms_Sum;
    unsigned long PRms_Sum;
    unsigned long VRms_ADC_Sum;
    unsigned long IRms_ADC_Sum;
    unsigned long PRms_ADC_Sum;
    unsigned int Rms_Avg_Count;    
}POWER_METER;
extern POWER_METER Pmeter;

//Primary Data
typedef union {
    unsigned int i16[80];
    struct{
        unsigned int STATUS1;                   //0
        unsigned int STATUS2;                   //1
        unsigned int ALA_STAT;                  //2
        unsigned int ALA_LATCH;                 //3
        unsigned int VRMS_Avg;                  //4
        unsigned int IRMS_Avg;                  //5
        unsigned int PIN_Avg;                   //6
        unsigned int DC_BULK;                   //7
        unsigned int T_PFC_A;             //8
        unsigned int T_PFC_B;             //9
        unsigned int T_BOOSTDIODE;            //10
        unsigned int FREQ_PF;                   //11
        unsigned int VRMS_Inst;                 //12
        unsigned int IRMS_Inst;                 //13
        unsigned int PIN_Inst;                  //14
        unsigned int BL_STATUS;                 //15
        unsigned int REV;                  //16 modified unsigned int Microchip reference_REV;
        unsigned int CIS_REV;                   //17
        unsigned int RES_1;                     //18
        unsigned int RES_2;                     //19
        unsigned int RES_3;                     //20
        
        //Debug Data 's 12 Words
        unsigned int VRms_ADC;                  //21
        unsigned int IRms_ADC;                  //22
        unsigned int PIN_Rms_ADC;               //23
        unsigned int VRMS_ADC_Avg;              //24
        unsigned int IRMS_ADC_Avg;              //25
        unsigned int PIN_ADC_Avg;               //26
        unsigned int VIN_PEAK_ADC;              //27
        unsigned int IIN_PEAK_ADC;              //28
        unsigned int BULK_ADC_AVG;              //29
        unsigned int Filted_IRms_ADC;           //30
        unsigned int D_Data[2];                 //31 - 32
        
        //Cal Data 's 32 - 76
        unsigned int VIN_LL_Gain;               //33    
        unsigned int VIN_HL_Gain;               //34
        unsigned int VIN_Div;                   //35
                
        unsigned int IIN_LL_1A_Gain;            //36 - 53
        unsigned int IIN_LL_1A_ADC;             //  
        unsigned int IIN_LL_1A_Val;             //  
        unsigned int IIN_LL_4A_Gain;            //  
        unsigned int IIN_LL_4A_ADC;             //  
        unsigned int IIN_LL_4A_Val;             //  
        unsigned int IIN_LL_6A_Gain;           //  
        unsigned int IIN_LL_6A_ADC;            //  
        unsigned int IIN_LL_6A_Val;            //  
        unsigned int IIN_HL_0A5_Gain;           //  
        unsigned int IIN_HL_0A5_ADC;            //  
        unsigned int IIN_HL_0A5_Val;            //  
        unsigned int IIN_HL_2A_Gain;            //   
        unsigned int IIN_HL_2A_ADC;             //  
        unsigned int IIN_HL_2A_Val;             //  
        unsigned int IIN_HL_3A_Gain;            //  
        unsigned int IIN_HL_3A_ADC;             //  
        unsigned int IIN_HL_3A_Val;             //  
         
        unsigned int PIN_LL_1A_Gain;            //54 - 71
        unsigned int PIN_LL_1A_ADC;             //  
        unsigned int PIN_LL_1A_Val;             //  
        unsigned int PIN_LL_4A_Gain;            //  
        unsigned int PIN_LL_4A_ADC;             //  
        unsigned int PIN_LL_4A_Val;             //  
        unsigned int PIN_LL_10A_Gain;           //  
        unsigned int PIN_LL_10A_ADC;            //  
        unsigned int PIN_LL_10A_Val;            //  
        unsigned int PIN_HL_0A5_Gain;           //  
        unsigned int PIN_HL_0A5_ADC;            //  
        unsigned int PIN_HL_0A5_Val;            //  
        unsigned int PIN_HL_2A_Gain;            //  
        unsigned int PIN_HL_2A_ADC;             //  
        unsigned int PIN_HL_2A_Val;             //  
        unsigned int PIN_HL_5A_Gain;            //  
        unsigned int PIN_HL_5A_ADC;             //  
        unsigned int PIN_HL_5A_Val;             //          
        
        unsigned int BULK_GAIN;                 //72
        unsigned int CAL_RES1;                  //73          
        unsigned int CAL_RES2;                  //74
        
        unsigned int IIN_Div;                   //75
        unsigned int PIN_Div;                   //76    
        unsigned int BULK_DIV;                  //77           
        
        unsigned int CAL_RES3;                  //78    
        unsigned int CAL_LOCK_KEY;              //79         
        unsigned int CAL_DATA_CRC;              //80
    };
}PRIMARY_DATA;

typedef union {
    unsigned char i8[6];
    struct{//Bits
        //Status1 - 0
        unsigned Startup:1;
        unsigned AC_OK:1;
        unsigned BULK_OK:1;
        unsigned Relay_Start:1;

        unsigned Relay_PWM_ON:1;
        unsigned PS_ON_En:1;
        unsigned PFC_En:1;
        unsigned Sec_CMD_PFC_Dis:1;
        
        unsigned Sec_CMD_Droop_En:1;
        unsigned BULK_OFF:1;
        unsigned VAC_Range_LL:1;

        unsigned Eep_Wr_Sta:1;
        unsigned Cal_CRC_Err:1;
        unsigned Cal_Unlock_Sta:1;                      //0 - Disabled , 1 = Enabled
        unsigned Flash_Wr_Sta:2;

         //Status2 -  Digital PFC Status bits
        unsigned CL_1st_PASS:1;
        unsigned CL_SoftStart:1;
        unsigned FF_Boost_1:1;
        unsigned Bulk_High_Sta:1;
        unsigned Bulk_Range:4;
        
        unsigned VPOL:1;
        unsigned VPOL_1:1;
        unsigned VPOL_2:1;
        unsigned New_AC_Data:1;
        
        unsigned Start_AC_Calc:1;     
        //Alarm - 2
        unsigned A_AC_Dropout:1;
        unsigned A_AC_IUV:1;            //Instant UV
        unsigned A_AC_IOV:1;            //Instant OV
        unsigned A_AC_Sag:1;
        unsigned A_AC_OV:1;             //Cycle RMS OV    
        unsigned A_ALERT_PFC:1;          //Alert to Control Loop  
        unsigned A_ALERT_SEC:1;          //Alert to Secondary Side for PG requirements
        unsigned A_AC_UVW:1;
        unsigned A_AC_OVW:1;
        unsigned A_AC_OCW:1;
        unsigned A_AC_OPW:1;
        unsigned A_BULK_UV1:1;
        unsigned A_BULK_UV2:1;
        unsigned A_BULK_OV_ALERT:1;
        unsigned A_BULK_OVP:1;
        unsigned LLC_ok_en:1;
        unsigned A_BULK_OV_H_ALERT:1;
        unsigned PFC_OTP:1;
        unsigned AMB_OTP:1;
    };
}PRIMARY_STATE;

typedef struct IIR_lowpass_int
{
	int16_t a[3];				
	int16_t b[3];								
	int16_t in[3];			
	int16_t out[3];				
    int16_t f_out;
    int32_t tmpb0u0;				/**< Intermediate calculation for section 1*/
	int32_t tmpb1u1;				/**< Intermediate calculation for section 1 */
	int32_t tmpb2u2;				/**< Intermediate calculation for section 2 */
	int32_t tmpa1y1;	
 	int32_t tmpa2y2;	         
} IIR_lowpass_int_t;
extern volatile IIR_lowpass_int_t Ifilter;

typedef enum STATE{
PFC_ALWAYS_OFF =0,
PFC_INIT,
PFC_ON,
PFC_OFF,
}SM_state;
/*
#define PFC_ALWAYS_OFF          0
#define PFC_INIT                0
#define PFC_ON                  1
#define PFC_OFF                 2
*/
extern PRIMARY_DATA PRI_DATA;
extern PRIMARY_STATE PRI_STATE;

#define Resolution 1 //1/0.125,if put resolution all the limitation trigger value also multipy by this value,the output is multiply by this Resolution value also,need divide first to print out.

#define AC_130_HALF_PERIOD_MAX 38  //38*200us = 7.6m,130Hz->(1/130)/2=7.6ms)
#define AC_45_HALF_PERIOD_MAX 56   //56*200us =11.2ms,45Hz->(1/45)/2 = 11.1ms

#define VIN_OK_THD            82        // in RMS voltage
#define VIN_OK_THD_RL         VIN_OK_THD*Resolution
#define VIN_OK_THD_ADC        (unsigned int)(((unsigned long)VIN_OK_THD_RL<<DEF_AC_VDIV)/(unsigned int)DEF_AC_VGAIN_LL)  //RMS
#define VIN_OK_THD_ADC_PK     (unsigned int)((float)VIN_OK_THD_ADC * 1.41421356)

#define DROPOUT_THD             14//20/1.414
#define DROPOUT_THD_RL          DROPOUT_THD*Resolution
#define DROPOUT_THD_ADC        (unsigned int)(((unsigned long)DROPOUT_THD_RL<<DEF_AC_VDIV)/(unsigned int)DEF_AC_VGAIN_LL) //RMS
#define DROPOUT_THD_ADC_PK     (unsigned int)((float)DROPOUT_THD_ADC * 1.41421356)
#define DROPOUT_DELAY1_TIME      30 //100us*140 = 14ms hold up time,3ms
#define DROPOUT_DELAY2_TIME      500 //100us*500 = 50ms
#define DROPOUT_RCV_DELAY1_TIME  80 //100us*80 = 8ms,14ms hold up time

#define INST_UVP_THD            56 //=80/1.414
#define INST_UVP_THD_RL         INST_UVP_THD*Resolution
#define INST_UVP_THD_ADC        (unsigned int)(((unsigned long)INST_UVP_THD_RL<<DEF_AC_VDIV)/(unsigned int)DEF_AC_VGAIN_LL)  //RMS
#define INST_UVP_THD_ADC_PK     (unsigned int)((float)INST_UVP_THD_ADC * 1.41421356)
#define INST_UVP_DELAY_TIME     5000//500ms


#define INST_OVP_THD            270 //in RMS voltage
#define INST_OVP_THD_RL         INST_OVP_THD*Resolution
#define INST_OVP_THD_ADC        (unsigned int)(((unsigned long)INST_OVP_THD_RL<<DEF_AC_VDIV)/(unsigned int)DEF_AC_VGAIN_LL)  //RMS
#define INST_OVP_THD_ADC_PK     (unsigned int)((float)INST_OVP_THD_ADC * 1.41421356)
#define INST_OVP_THD_DELAY      2 

#define AC_SAG_THD              77
#define AC_SAG_THD_RL           AC_SAG_THD*Resolution
#define AC_SAG_THD_ADC          (unsigned int)(((unsigned long)AC_SAG_THD_RL<<DEF_AC_VDIV)/(unsigned int)DEF_AC_VGAIN_LL)  //RMS
#define AC_SAG_THD_ADC_PK       (unsigned int)((float)AC_SAG_THD * 1.41421356)
#define AC_SAG_DELAY_TIME       500 //1ms=500ms

#define AC_OV_TRIG_THD          270 //in RMS voltage
#define AC_OV_TRIG_THD_RL        AC_OV_TRIG_THD*Resolution
#define AC_OV_TRIG_THD_ADC      (unsigned int)(((unsigned long)AC_OV_TRIG_THD_RL<<DEF_AC_VDIV)/(unsigned int)DEF_AC_VGAIN_LL)  //RMS
#define AC_OV_TRIG_THD_ADC_PK   (unsigned int)((float)AC_OV_TRIG_THD_ADC * 1.41421356)
#define AC_OV_TRIG_DELAY        20

#define AC_OV_RECVR_THD          260 //in RMS voltage
#define AC_OV_RECVR_THD_RL       AC_OV_RECVR_THD*Resolution
#define AC_OV_RECVR_THD_ADC      (unsigned int)(((unsigned long)AC_OV_RECVR_THD_RL<<DEF_AC_VDIV)/(unsigned int)DEF_AC_VGAIN_LL)  //RMS
#define AC_OV_RECVR_THD_ADC_PK   (unsigned int)((float)AC_OV_RECVR_THD_ADC * 1.41421356)
#define AC_OV_RECVR_DELAY       200

#define AC_UVW_TRIG_THD          80//70//0.5*VIN_OK_THD //in RMS voltage
#define AC_UVW_TRIG_THD_RL       AC_UVW_TRIG_THD*Resolution
#define AC_UVW_TRIG_THD_ADC      (unsigned int)(((unsigned long)AC_UVW_TRIG_THD_RL<<DEF_AC_VDIV)/(unsigned int)DEF_AC_VGAIN_LL)  //RMS
#define AC_UVW_TRIG_THD_ADC_PK   (unsigned int)((float)AC_UVW_TRIG_THD_ADC * 1.41421356)
#define AC_UVW_TRIG_DELAY        AC_SAG_DELAY_TIME+50

#define AC_UVW_RECVR_THD         82// 72//AC_UVW_TRIG_THD*1.05 //in RMS voltage
#define AC_UVW_RECVR_THD_RL       AC_UVW_RECVR_THD*Resolution
#define AC_UVW_RECVR_THD_ADC      (unsigned int)(((unsigned long)AC_UVW_RECVR_THD_RL<<DEF_AC_VDIV)/(unsigned int)DEF_AC_VGAIN_LL)  //RMS
#define AC_UVW_RECVR_THD_ADC_PK   (unsigned int)((float)AC_UVW_RECVR_THD_ADC * 1.41421356)
#define AC_UVW_RECVR_DELAY         200 //

#define AC_OVW_TRIG_THD          275 //in RMS voltage
#define AC_OVW_TRIG_THD_RL       AC_OVW_TRIG_THD*Resolution
#define AC_OVW_TRIG_THD_ADC      (unsigned int)(((unsigned long)AC_OVW_TRIG_THD_RL<<DEF_AC_VDIV)/(unsigned int)DEF_AC_VGAIN_LL)  //RMS
#define AC_OVW_TRIG_THD_ADC_PK   (unsigned int)((float)AC_OVW_TRIG_THD_ADC * 1.41421356)
#define AC_OVW_TRIG_DELAY 150

#define AC_OVW_RECVR_THD          270 //in RMS voltage
#define AC_OVW_RECVR_THD_RL       AC_OVW_RECVR_THD*Resolution
#define AC_OVW_RECVR_THD_ADC      (unsigned int)(((unsigned long)AC_OVW_RECVR_THD_RL<<DEF_AC_VDIV)/(unsigned int)DEF_AC_VGAIN_LL)  //RMS
#define AC_OVW_RECVR_THD_ADC_PK   (unsigned int)((float)AC_OVW_RECVR_THD_ADC * 1.41421356)
#define AC_OVW_RECVR_DELAY 200

#define AC_OCW_TRIG_THD          18 //in RMS voltage
#define AC_OCW_TRIG_THD_RL       AC_OCW_TRIG_THD*Resolution
#define AC_OCW_TRIG_THD_ADC      (unsigned int)(((unsigned long)AC_OCW_TRIG_THD_RL<<DEF_AC_VDIV)/(unsigned int)DEF_AC_VGAIN_LL)  //RMS
#define AC_OCW_TRIG_THD_ADC_PK   (unsigned int)((float)AC_OCW_TRIG_THD_ADC * 1.41421356)
#define AC_OCW_TRIG_DELAY 200

#define AC_OCW_RECVR_THD          18 //in RMS voltage
#define AC_OCW_RECVR_THD_RL       AC_OCW_RECVR_THD*Resolution
#define AC_OCW_RECVR_THD_ADC      (unsigned int)(((unsigned long)AC_OCW_RECVR_THD_RL<<DEF_AC_VDIV)/(unsigned int)DEF_AC_VGAIN_LL)  //RMS
#define AC_OCW_RECVR_THD_ADC_PK   (unsigned int)((float)AC_OCW_RECVR_THD_ADC * 1.41421356)
#define AC_OCW_RECVR_DELAY 200

#define VIN_OK_DELAY             100  //1*100 ms

#define RELAY_ON_THD             80//60//0.8*VIN_OK_THD //in RMS voltage
#define RELAY_ON_THD_RL          RELAY_ON_THD*Resolution
#define RELAY_ON_THD_ADC         (unsigned int)(((unsigned long)RELAY_ON_THD_RL<<DEF_AC_VDIV)/(unsigned int)DEF_AC_VGAIN_LL)  //RMS
#define RELAY_ON_THD_ADC_PK      (unsigned int)((float)RELAY_ON_THD_ADC * 1.41421356)
#define RELAY_START_DELAY         200    //200*1ms=100ms
  
#define RELAY_OFF_THD             75//55 //6 // 0.1*VIN_OK_THD //in RMS voltage
#define RELAY_OFF_THD_RL          RELAY_OFF_THD*Resolution
#define RELAY_OFF_THD_ADC         (unsigned int)(((unsigned long)RELAY_OFF_THD_RL<<DEF_AC_VDIV)/(unsigned int)DEF_AC_VGAIN_LL)  //RMS
#define RELAY_OFF_THD_ADC_PK      (unsigned int)((float)RELAY_OFF_THD_ADC * 1.41421356)

#define VIN_VBUS_DIFF             5 //in RMS voltage
#define VIN_VBUS_DIFF_RL          VIN_VBUS_DIFF*Resolution
#define VIN_VBUS_DIFF_ADC         (unsigned int)(((unsigned long)VIN_VBUS_DIFF_RL<<DEF_AC_VDIV)/(unsigned int)DEF_AC_VGAIN_LL)  //RMS

#define VIN_VBUS_DIFF2             2 //in RMS voltage
#define VIN_VBUS_DIFF2_RL          VIN_VBUS_DIFF2*Resolution
#define VIN_VBUS_DIFF2_ADC         (unsigned int)(((unsigned long)VIN_VBUS_DIFF2_RL<<DEF_AC_VDIV)/(unsigned int)DEF_AC_VGAIN_LL)  //RMS

#define REFERENCE_OUTPUT_VOLTAGE    390

#define BULK_UV1_THD            290//0.75*REFERENCE_OUTPUT_VOLTAGE   //in Volts  
#define BULK_UV1_THD_RL        (BULK_UV1_THD * Resolution)  
#define BULK_UV1_THD_ADC       (unsigned int)(((unsigned long)BULK_UV1_THD_RL<<DEF_BULK_SCALE)/(unsigned int)DEF_BULK_GAIN) 
#define BULK_UV1_TRIG_DELAY    24*2 //24*2*100us-> 5ms

#define BULK_UV2_THD           290//0.65*REFERENCE_OUTPUT_VOLTAGE   //in Volts  
#define BULK_UV2_THD_RL        (BULK_UV2_THD * Resolution)  
#define BULK_UV2_THD_ADC       (unsigned int)(((unsigned long)BULK_UV2_THD_RL<<DEF_BULK_SCALE)/(unsigned int)DEF_BULK_GAIN)
#define BULK_UV2_TRIG_DELAY    4 //2*200us->0.4ms

#define BULK_OK_THD             370   //in Volts  
#define BULK_OK_THD_RL          (BULK_OK_THD * Resolution)  
#define BULK_OK_THD_ADC         (unsigned int)(((unsigned long)BULK_OK_THD_RL<<DEF_BULK_SCALE)/(unsigned int)DEF_BULK_GAIN)

#define BULK_OV_THD             507//507//1.3*REFERENCE_OUTPUT_VOLTAGE   //in Volts  
#define BULK_OV_THD_RL          (BULK_OV_THD * Resolution)  
#define BULK_OV_THD_ADC         (unsigned int)(((unsigned long)BULK_OV_THD_RL<<DEF_BULK_SCALE)/(unsigned int)DEF_BULK_GAIN)

#define BULK_OV_LEVEL1_THD      468//1.2*REFERENCE_OUTPUT_VOLTAGE   //in Volts  
#define BULK_OV_LEVEL1_THD_RL   (BULK_OV_LEVEL1_THD * Resolution)  
#define BULK_OV_LEVEL1_THD_ADC  (unsigned int)(((unsigned long)BULK_OV_LEVEL1_THD_RL<<DEF_BULK_SCALE)/(unsigned int)DEF_BULK_GAIN)
#define BULK_OV_LEVEL1_RECVR_DELAY     1000 //100ms

#define BULK_OV_REC            0.9*REFERENCE_OUTPUT_VOLTAGE   //in Volts  
#define BULK_OV_REC_RL         (BULK_OV_REC * Resolution)  
#define BULK_OV_REC_ADC        (unsigned int)(((unsigned long)BULK_OV_REC_RL<<DEF_BULK_SCALE)/(unsigned int)DEF_BULK_GAIN)
#define BULK_OV_RECVR_DELAY    200*5  //200ms

#define LLC_EN_BULK_L_THD           280   //in Volts  
#define LLC_EN_BULK_L_THD_RL        (LLC_EN_BULK_L_THD * Resolution)  
//#define LLC_EN_BULK_L_THD_ADC       (unsigned int)(((unsigned long)LLC_EN_BULK_L_THD_RL<<DEF_BULK_SCALE)/(unsigned int)DEF_BULK_GAIN)

#define LLC_EN_BULK_H_THD           365   //in Volts  
#define LLC_EN_BULK_H_THD_RL        (LLC_EN_BULK_H_THD * Resolution)  
#define LLC_EN_BULK_H_THD_ADC       (unsigned int)(((unsigned long)BULK_OV_REC_RL<<DEF_BULK_SCALE)/(unsigned int)DEF_BULK_GAIN)
//#define LLC_EN_BULK_H_THD_ADC       (unsigned int)(((unsigned long)LLC_EN_BULK_H_THD_RL<<DEF_BULK_SCALE)/(unsigned int)DEF_BULK_GAIN)

//Vin Range Detection
#define VIN_LOW_LINE_TRIG_VOL   166         // <166V in RMS Volts
#define VIN_LOW_LINE_THD        (VIN_LOW_LINE_TRIG_VOL * Resolution)  // in Converted RMS Volts
#define VIN_LOW_LINE_ADC_RMS    (unsigned int)(((unsigned long)VIN_LOW_LINE_THD<<DEF_AC_VDIV)/(unsigned int)DEF_AC_VGAIN_LL)
#define VIN_LOW_LINE_ADC_PK     (unsigned int)((float)VIN_LOW_LINE_ADC_RMS * 1.41421356)

#define VIN_LOW_LINE_TRIG_VOL1  145         // <145V in RMS Volts
#define VIN_LOW_LINE_THD1       (VIN_LOW_LINE_TRIG_VOL1 * Resolution)  // in Converted RMS Volts
#define VIN_LOW_LINE_ADC_RMS1   (unsigned int)(((unsigned long)VIN_LOW_LINE_THD1<<DEF_AC_VDIV)/(unsigned int)DEF_AC_VGAIN_LL)
#define VIN_LOW_LINE_ADC_PK1    (unsigned int)((float)VIN_LOW_LINE_ADC_RMS1 * 1.41421356)

#define VIN_LOW_LINE_TRIG_VOL2  125         // <125V in RMS Volts
#define VIN_LOW_LINE_THD2       (VIN_LOW_LINE_TRIG_VOL2 * Resolution)  // in Converted RMS Volts
#define VIN_LOW_LINE_ADC_RMS2   (unsigned int)(((unsigned long)VIN_LOW_LINE_THD2<<DEF_AC_VDIV)/(unsigned int)DEF_AC_VGAIN_LL)
#define VIN_LOW_LINE_ADC_PK2    (unsigned int)((float)VIN_LOW_LINE_ADC_RMS2 * 1.41421356)

#define VIN_HIGH_LINE_TRIG_VOL  170         // >170V in RMS Volts
#define VIN_HIGH_LINE_THD       (VIN_HIGH_LINE_TRIG_VOL * Resolution)  // in Converted RMS Volts
#define VIN_HIGH_LINE_ADC_RMS   (unsigned int)(((unsigned long)VIN_HIGH_LINE_THD<<DEF_AC_VDIV)/(unsigned int)DEF_AC_VGAIN_LL)
#define VIN_HIGH_LINE_ADC_PK    (unsigned int)((float)VIN_HIGH_LINE_ADC_RMS * 1.41421356)

#define VIN_DEBUG_REF           17         
#define VIN_DEBUG_REF_THD       (VIN_DEBUG_REF * Resolution)  // in Converted RMS Volts
#define VIN_DEBUG_REF_ADC_RMS   (unsigned int)(((unsigned long)VIN_DEBUG_REF_THD<<DEF_AC_VDIV)/(unsigned int)DEF_AC_VGAIN_LL)
#define VIN_DEBUG_REF_ADC_PK    (unsigned int)((float)VIN_DEBUG_REF_ADC_RMS * 1.41421356)

#define BULK_OK_DLY                 20  //20*100us

#define PFC_ON_DELAY                40    //40*1ms=40ms
#define PFC_OFF_DELAY               20    //1ms*16=16ms
#define PFC_RESTART_DELAY           150 //150*1 = 150ms 
#define LLC_ON_DELAY                2000  //3000*0.1ms = 120ms,:300ms
#define LLC_OFF_DELAY               2000  //long enough to let the secondary off llc
#define IIR_QFORMAT  14

void Task_handler(void);
void Power_meter(void);
extern void BULK_VOLT_REG_Disable(void);
extern void BULK_VOLT_REG_Enable(void);
extern void LLC_IC_Disable(void);
extern void LLC_IC_Enable(void);
extern void PFC_IC_Disable(void);
extern void PFC_IC_Enable(void);
extern void Relay_ON_Enable(void);
extern void Relay_ON_Disable(void);
extern void AC_OK_Disable(void);
extern void AC_OK_Enable(void);
extern void PFC_OK_Disable(void);
extern void PFC_OK_Enable(void);
#endif	/* TASK_MANAGER_H */


