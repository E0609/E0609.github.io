#include "headers.h"
/*******************************************************************************
 * Function:        Init_Data
 * Description:     Initialize the secondary data informations.
 ******************************************************************************/
void Init_Data(void)
{      
    //Init Status registers
    PRI_DATA.STATUS1 = 0; 
    PRI_DATA.STATUS2 = 0; 
    
    //Init Alarm Registers    
    //AC
    PRI_STATE.A_AC_Dropout = 0;
    PRI_STATE.A_AC_Sag = 0;
    PRI_STATE.A_AC_IUV = 0;
    PRI_STATE.Bulk_High_Sta = 0;  
        
    //Bulk
    PRI_STATE.A_BULK_UV1 = 1;
    PRI_STATE.A_BULK_UV2 = 1;   
    
   
    //Init Startup Internal Parameters/Registers
    Vin_Mon.VPeak_Temp = 0;
    Vin_Mon.IPeak_Temp = 0;
    Vin_Mon.Count = 0;    
    TFCtrl.i16[0] = 0;
    TFCtrl.i16[1] = 0;
    TFCtrl.i16[2] = 0;
    TFCtrl.i16[3] = 0;
        
    Pmeter.Vin_Sum_Tmp = 0;
    Pmeter.Iin_Sum_Tmp = 0;
    Pmeter.Pin_Sum_Tmp = 0;    
    Pmeter.VRms_Sum = 0;
    Pmeter.PRms_Sum = 0;
    Pmeter.IRms_Sum = 0;
    Pmeter.Rms_Avg_Count = 0;
    
    //Init Thresholds and Delays
    //Dropout_Delay = DROPOUT_TRIG_DELAY_FL;


    PRI_DATA.VIN_LL_Gain = DEF_AC_VGAIN_LL;
    PRI_DATA.VIN_HL_Gain = DEF_AC_VGAIN_HL;
    PRI_DATA.VIN_Div = DEF_AC_VDIV;

    PRI_DATA.IIN_LL_1A_Gain = DEF_AC_1A_IGAIN_LL;
    PRI_DATA.IIN_LL_1A_ADC = DEF_AC_1A_ADC_LL;    
    PRI_DATA.IIN_LL_1A_Val = DEF_AC_1A_CUR_LL;
    PRI_DATA.IIN_LL_4A_Gain = DEF_AC_4A_IGAIN_LL;
    PRI_DATA.IIN_LL_4A_ADC = DEF_AC_4A_ADC_LL;    
    PRI_DATA.IIN_LL_4A_Val = DEF_AC_4A_CUR_LL;
    PRI_DATA.IIN_LL_6A_Gain = DEF_AC_6A_IGAIN_LL;
    PRI_DATA.IIN_LL_6A_ADC = DEF_AC_6A_ADC_LL;    
    PRI_DATA.IIN_LL_6A_Val = DEF_AC_6A_CUR_LL;

    PRI_DATA.IIN_HL_0A5_Gain = DEF_AC_0A5_IGAIN_HL;
    PRI_DATA.IIN_HL_0A5_ADC = DEF_AC_0A5_ADC_HL;    
    PRI_DATA.IIN_HL_0A5_Val = DEF_AC_0A5_CUR_HL; 
    PRI_DATA.IIN_HL_2A_Gain = DEF_AC_2A_IGAIN_HL;
    PRI_DATA.IIN_HL_2A_ADC = DEF_AC_2A_ADC_HL;    
    PRI_DATA.IIN_HL_2A_Val = DEF_AC_2A_CUR_HL; 
    PRI_DATA.IIN_HL_3A_Gain = DEF_AC_3A_IGAIN_HL;
    PRI_DATA.IIN_HL_3A_ADC = DEF_AC_3A_ADC_HL;    
    PRI_DATA.IIN_HL_3A_Val = DEF_AC_3A_CUR_HL; 

    PRI_DATA.IIN_Div = DEF_AC_IDIV;

    PRI_DATA.BULK_GAIN =  DEF_BULK_GAIN;
    PRI_DATA.BULK_DIV =  DEF_BULK_SCALE;
    
    }

void IIR_param_init(void)
{
    /*sampling 10k,filtering 1000,Q:0.7*/
   //a0 = 0.06745508395870334>>1 = 1105   //  1547
   //a1 = 0.13491016791740668>>1 = 2210   //  3537
   //a2 = 0.06745508395870334>>1 = 1105   //  1768
   //b1 = -1.1429772843080923>>1 = 18727  //  29962
   //b2 = 0.41279762014290533>>1 = 6763   //  10817
  
    Ifilter.a[0] = 1222;
    Ifilter.a[1] = 2445;
    Ifilter.a[2] = 1222;
    Ifilter.b[1] = -20712;
    Ifilter.b[2] = 7480;

	Ifilter.out[0] = 0;
	Ifilter.out[1] = 0;
	Ifilter.out[2] = 0;
	Ifilter.in[0] = 0;
	Ifilter.in[1] = 0;
	Ifilter.in[2] = 0;
    Ifilter.f_out = 0;
}

void Env_Init(void)
{
    Init_Data();
    BULK_VOLT_REG_Disable();
    LLC_IC_Disable();
    PFC_IC_Disable();
    Relay_ON_Disable();
    AC_OK_Disable();
    PFC_OK_Disable();
    IIR_param_init();
}