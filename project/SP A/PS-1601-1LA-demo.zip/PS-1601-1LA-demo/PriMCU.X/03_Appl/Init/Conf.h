/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/* 
 * File:   
 * Author: 
 * Comments:
 * Revision history: 
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef XC_HEADER_TEMPLATE_H
#define	XC_HEADER_TEMPLATE_H

#include <xc.h> // include processor files - each processor file is guarded.  

#define TRUE    1
#define FALSE   0

#define VinMax              521		
#define IinMax              13           //Amps
#define VbulkMax            521			 //Volts
							
#define IrefMaxCMP          13		       
							
#define PFC_OC_CMP_set      12            //Clamp PWM Fault Current Amps
#define PFC_OC_CMP_ADC_SET      PFC_OC_CMP_set*388  //388 = 1939/5 (1939 is the reading ADC value of 5A))
// ACV Gain value for 125mV resolution 

#define DEF_AC_VGAIN_LL         VinMax//VinMax*Resolution
#define DEF_AC_VGAIN_HL         VinMax
// ACV Divisor value for Both Lines for 125mV Resolution
#define DEF_AC_VDIV             12

    //For IIN for 0.15625 mA Resolution
#define DEF_AC_1A_IGAIN_LL      14
#define DEF_AC_1A_ADC_LL        276
#define DEF_AC_1A_CUR_LL        1
#define DEF_AC_4A_IGAIN_LL      13
#define DEF_AC_4A_ADC_LL        1216
#define DEF_AC_4A_CUR_LL        4
#define DEF_AC_6A_IGAIN_LL      13
#define DEF_AC_6A_ADC_LL        1845
#define DEF_AC_6A_CUR_LL        6

#define DEF_AC_0A5_IGAIN_HL     17.9
#define DEF_AC_0A5_ADC_HL       114
#define DEF_AC_0A5_CUR_HL       0.5
#define DEF_AC_2A_IGAIN_HL      14
#define DEF_AC_2A_ADC_HL        584
#define DEF_AC_2A_CUR_HL        2
#define DEF_AC_3A_IGAIN_HL      13.6
#define DEF_AC_3A_ADC_HL        900
#define DEF_AC_3A_CUR_HL        3

// ACI Divisor value for Both Lines for 15.625mA Resolution
#define DEF_AC_IDIV             12




    //For Bulk
// (char) - Gain for Bulk Voltage @ 500mV resolution 
#define DEF_BULK_GAIN           VbulkMax*Resolution
// (char) - Divide by 4096
#define DEF_BULK_SCALE          12
#define PRI_PFC_MAX_TMP         0x040D   //120, read and cal it as 96 //40D,3F8
#define PRI_PFC_RECV_TMP        0x06F2   //80, read and cal it as 66
#define PRI_AMBIENT_MAX_TMP     0x0845   //70,50:0x09F7
#define PRI_AMBIENT_RECV_TMP    0x09F7   //48:0x0A1D
#define PFC_OTP_TRIG_DELAY      100
#define AMB_OTP_TRIG_DELAY      100
#define PRI_PFC_OTP_RECV_DELAY  100
#define PRI_AMB_OTP_RECV_DELAY  100
void Env_Init(void);
#endif	/* XC_HEADER_TEMPLATE_H */


#define PWMCLOCKFREQ        943360000       // 117.92*8*1000000

#define PFC_FREQ           (65E3)          // Hz, PFC switching frequency
//#define PFC_FREQ_MAX        (90E3)      // Hz, maximum frequency

#define PFC_PWM_PERIOD     (unsigned int)(PWMCLOCKFREQ / PFC_FREQ)     // PFC PWM Period
//#define PFC_PWM_PERIOD_MIN  (unsigned int)(PWMCLOCKFREQ / PFC_FREQ_MAX)  // minimum PWM Period to anti-mistake for division calculation
#define PFC_IC_ENABLE               _LATA3
#define PFC_IC_ENABLE_DIRECTION     _TRISA3

/************** ADC buffer Definition **************/
#define I_PFC_MCU_BUF               ADCBUF3        
#define L_VOLTAGE_BUF               ADCBUF0   /* Line L voltage */
#define N_VOLTAGE_BUF               ADCBUF1    /* Line N voltage */
#define VDC_MCU_BUF                 ADCBUF5	   /* Bus  voltage */
#define T_AMBIENT_MCU_BUF           ADCBUF2
#define T_PFC_BUF                   ADCBUF4 

#define REF_2V5_CALI            Q10(2.495/3.287)