#ifndef DSP_INTERRUPT_H
#define	DSP_INTERRUPT_H
void Init_Timer1_Callback();
void Init_ADC_Callback();

BYTE SetTimer ( WORD Elapse, _Pfn pTimerFunc );
void KillTimer ( BYTE *pTimerID );
void UpdateFanSpeedA ( );
#endif

