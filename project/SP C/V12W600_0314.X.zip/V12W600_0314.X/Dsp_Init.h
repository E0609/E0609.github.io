

#ifndef _XTAL_FREQ
#define _XTAL_FREQ  119762500UL
#endif

#include <xc.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

#ifndef DSP_INIT_H
#define	DSP_INIT_H
/** 
 * CORCON initialization type enumerator. Supported types:
 * CORCON_MODE_PORVALUES
 * CORCON_MODE_ENABLEALLSATNORMAL_ROUNDBIASED
 * CORCON_MODE_ENABLEALLSATNORMAL_ROUNDUNBIASED
 * CORCON_MODE_DISABLEALLSAT_ROUNDBIASED
 * CORCON_MODE_DISABLEALLSAT_ROUNDUNBIASED
 * CORCON_MODE_ENABLEALLSATSUPER_ROUNDBIASED
 * CORCON_MODE_ENABLEALLSATSUPER_ROUNDUNBIASED
 */
typedef enum tagCORCON_MODE_TYPE
{ 
    CORCON_MODE_PORVALUES   = 0x0020,                       /** Use POR values of CORCON */
    CORCON_MODE_ENABLEALLSATNORMAL_ROUNDBIASED = 0x00E2,    /** Enable saturation for ACCA, ACCB
                                                             *  and Dataspace write, enable normal
                                                             *  ACCA/ACCB saturation mode and set
                                                             *  rounding to Biased (conventional)
                                                             *  mode. Rest of CORCON settings are
                                                             *  set to the default POR values.
                                                             *  */
    CORCON_MODE_ENABLEALLSATNORMAL_ROUNDUNBIASED = 0x00E0,  /** Enable saturation for ACCA, ACCB
                                                             *  and Dataspace write, enable normal
                                                             *  ACCA/ACCB saturation mode and set
                                                             *  rounding to Unbiased (convergent)
                                                             *  mode. Rest of CORCON settings are
                                                             *  set to the default POR values.
                                                             *  */
    CORCON_MODE_DISABLEALLSAT_ROUNDBIASED = 0x0022,         /** Disable saturation for ACCA, ACCB
                                                             *  and Dataspace write and set
                                                             *  rounding to Biased (conventional)
                                                             *  mode. Rest of CORCON settings are
                                                             *  set to the default POR values.
                                                             *  */
    CORCON_MODE_DISABLEALLSAT_ROUNDUNBIASED = 0x0020,       /** Disable saturation for ACCA, ACCB
                                                             *  and Dataspace write and set
                                                             *  rounding to Unbiased (convergent)
                                                             *  mode. Rest of CORCON settings are
                                                             *  set to the default POR values.
                                                             *  */
    CORCON_MODE_ENABLEALLSATSUPER_ROUNDBIASED = 0x00F2,    /** Enable saturation for ACCA, ACCB
                                                             *  and Dataspace write, enable super
                                                             *  ACCA/ACCB saturation mode and set
                                                             *  rounding to Biased (conventional)
                                                             *  mode. Rest of CORCON settings are
                                                             *  set to the default POR values.
                                                             *  */
    CORCON_MODE_ENABLEALLSATSUPER_ROUNDUNBIASED = 0x00F0,  /** Enable saturation for ACCA, ACCB
                                                             *  and Dataspace write, enable super
                                                             *  ACCA/ACCB saturation mode and set
                                                             *  rounding to Unbiased (convergent)
                                                             *  mode. Rest of CORCON settings are
                                                             *  set to the default POR values.
                                                             *  */
} SYSTEM_CORCON_MODES;

#define AN_12V_ORING_MCU_SetHigh()            (_LATA0 = 1)
#define AN_12V_ORING_MCU_SetLow()             (_LATA0 = 0)
#define AN_12V_ORING_MCU_Toggle()             (_LATA0 ^= 1)
#define AN_12V_ORING_MCU_GetValue()           _RA0
#define AN_12V_ORING_MCU_SetDigitalInput()    (_TRISA0 = 1)
#define AN_12V_ORING_MCU_SetDigitalOutput()   (_TRISA0 = 0)


#define I_SHARE_INT_SetHigh()            (_LATB0 = 1)
#define I_SHARE_INT_SetLow()             (_LATB0 = 0)
#define I_SHARE_INT_Toggle()             (_LATB0 ^= 1)
#define I_SHARE_INT_GetValue()           _RB0
#define I_SHARE_INT_SetDigitalInput()    (_TRISB0 = 1)
#define I_SHARE_INT_SetDigitalOutput()   (_TRISB0 = 0)

#define  PIN_STB_EN_SetHigh()            (_LATB2 = 1)
#define  PIN_STB_EN_SetLow()             (_LATB2 = 0)
#define PIN_STB_EN_Toggle()             (_LATB2 ^= 1)
#define PIN_STB_EN_GetValue()           _RB2
#define PIN_STB_EN_SetDigitalInput()    (_TRISB2 = 1)
#define PIN_STB_EN_SetDigitalOutput()   (_TRISB2 = 0)

#define AN_STB_I_OUT_MCU_SetHigh()             (_LATB10 = 1)
#define AN_STB_I_OUT_MCU_SetLow()              (_LATB10 = 0)
#define AN_STB_I_OUT_MCU_Toggle()              (_LATB10 ^= 1)
#define AN_STB_I_OUT_MCU_GetValue()            _RB10
#define AN_STB_I_OUT_MCU_SetDigitalInput()     (_TRISB10 = 1)
#define AN_STB_I_OUT_MCU_SetDigitalOutput()    (_TRISB10 = 0)

#define PIN_POK_MCU_SetHigh()           (_LATB12 = 1)
#define PIN_POK_MCU_SetLow()            (_LATB12 = 0)
#define PIN_POK_MCU_Toggle()            (_LATB12 ^= 1)
#define PIN_POK_MCU_GetValue()          _RB12
#define PIN_POK_MCU_SetDigitalInput()   (_TRISB12 = 1)
#define PIN_POK_MCU_SetDigitalOutput()  (_TRISB12 = 0)

#define PIN_DAC_OUT_SetHigh()           (_LATB3 = 1)
#define PIN_DAC_OUT_SetLow()            (_LATB3 = 0)
#define PIN_DAC_OUT_Toggle()            (_LATB3 ^= 1)
#define PIN_DAC_OUT_GetValue()          _RB3
#define PIN_DAC_OUT_SetDigitalInput()   (_TRISB3 = 1)
#define PIN_DAC_OUT_SetDigitalOutput()  (_TRISB3 = 0)

#define oPIN_LED_SetHigh()            (_LATB5 = 1)
#define oPIN_LED_SetLow()             (_LATB5 = 0)
#define oPIN_LED_Toggle()             (_LATB5 ^= 1)
#define oPIN_LED_GetValue()           _RB5
#define oPIN_LED_SetDigitalInput()    (_TRISB5 = 1)
#define oPIN_LED_SetDigitalOutput()   (_TRISB5 = 0)

#define PIN_DEBUG_SetHigh()            (_LATB8 = 1)
#define PIN_DEBUG_SetLow()             (_LATB8 = 0)
#define PIN_DEBUG_Toggle()             (_LATB8 ^= 1)
#define PIN_DEBUG_GetValue()           _RB8
#define PIN_DEBUG_SetDigitalInput()    (_TRISB8 = 1)
#define PIN_DEBUG_SetDigitalOutput()   (_TRISB8 = 0)

#define V_12V_OUT_MCU_SetHigh()              (_LATB9 = 1)
#define V_12V_OUT_MCU_SetLow()               (_LATB9 = 0)
#define V_12V_OUT_MCU_Toggle()               (_LATB9 ^= 1)
#define V_12V_OUT_MCU_GetValue()             _RB9
#define V_12V_OUT_MCU_SetDigitalInput()      (_TRISB9 = 1)
#define V_12V_OUT_MCU_SetDigitalOutput()     (_TRISB9 = 0)



#define AN_T_SR_MCU_SetHigh()             (_LATC11 = 1)
#define AN_T_SR_MCU_SetLow()              (_LATC11 = 0)
#define AN_T_SR_MCU_Toggle()              (_LATC11 ^= 1)
#define AN_T_SR_MCU_GetValue()            _RC11
#define AN_T_SR_MCU_SetDigitalInput()     (_TRISC11 = 1)
#define AN_T_SR_MCU_SetDigitalOutput()    (_TRISC11 = 0)

#define SR_EN_MCU_SetHigh()             (_LATC12 = 1)
#define SR_EN_MCU_SetLow()              (_LATC12 = 0)
#define SR_EN_MCU_Toggle()              (_LATC12 ^= 1)
#define SR_EN_MCU_GetValue()            _RC12
#define SR_EN_MCU_SetDigitalInput()     (_TRISC12 = 1)
#define SR_EN_MCU_SetDigitalOutput()    (_TRISC12 = 0)

#define iPIN_PFC_OK_SetHigh()             (_LATC13 = 1)
#define iPIN_PFC_OK_SetLow()              (_LATC13 = 0)
#define iPIN_PFC_OK_Toggle()              (_LATC13 ^= 1)
#define iPIN_PFC_OK_GetValue()            _RC13
#define iPIN_PFC_OK_SetDigitalInput()     (_TRISC13 = 1)
#define iPIN_PFC_OK_SetDigitalOutput()    (_TRISC13 = 0)

#define oPIN_LLC_EN_MCU_SetHigh()             (_LATA3 = 1)
#define oPIN_LLC_EN_MCU_SetLow()              (_LATA3 = 0)
#define oPIN_LLC_EN_MCU_Toggle()           (_LATA3 ^= 1)
#define oPIN_LLC_EN_MCU_GetValue()             _RA3
#define oPIN_LLC_EN_MCU_SetDigitalInput()      (_TRISA3 = 1)
#define oPIN_LLC_EN_MCU_SetDigitalOutput()     (_TRISA3 = 0)


#define oPIN_STB_EN_MCU_SetHigh()             (_LATC1 = 1)
#define oPIN_STB_EN_MCU_SetLow()              (_LATC1 = 0)

#define PIN_ACOK_OUT_Value()             (_LATC2 )
#define PIN_ACOK_OUT_SetHigh()             (_LATC2 = 1)
#define PIN_ACOK_OUT_SetLow()              (_LATC2 = 0)
#define PIN_ACOK_OUT_Toggle()              (_LATC2 ^= 1)
#define PIN_ACOK_OUT_GetValue()            _RC2
#define PIN_ACOK_OUT_SetDigitalInput()     (_TRISC2 = 1)
#define PIN_ACOK_OUT_SetDigitalOutput()    (_TRISC2 = 0)


#define iPIN_ACOK_IN_SetHigh()             (_LATC0 = 1)
#define iPIN_ACOK_IN_SetLow()              (_LATC0 = 0)
#define iPIN_ACOK_IN_Toggle()              (_LATC0 ^= 1)
#define iPIN_ACOK_IN_GetValue()            _RC0
#define iPIN_ACOK_IN_SetDigitalInput()     (_TRISC0 = 1)
#define iPIN_ACOK_IN_SetDigitalOutput()    (_TRISC0 = 0)

#define iPIN_PS_ON_SetHigh()             (_LATC6 = 1)
#define iPIN_PS_ON_MCU_SetLow()              (_LATC6 = 0)
#define iPIN_PS_ON_MCU_Toggle()              (_LATC6 ^= 1)
#define iPIN_PS_ON_MCU_GetValue()            _RC6
#define iPIN_PS_ON_MCU_SetDigitalInput()     (_TRISC6 = 1)
#define iPIN_PS_ON_MCU_SetDigitalOutput()    (_TRISC6 = 0)
  
#define oPIN_12V_ORING_EN_Value()           (_LATB1)
#define oPIN_12V_ORING_EN_SetHigh()           (_LATB1 = 1)
#define oPIN_12V_ORING_EN_SetLow()            (_LATB1 = 0)
#define oPIN_12V_ORING_EN_Toggle()            (_LATB1 ^= 1)
#define oPIN_12V_ORING_EN_GetValue()          _RB1
#define oPIN_12V_ORING_EN_SetDigitalInput()   (_TRISB1 = 1)
#define PIN_V_SetDigitalOutput()  (_TRISB1 = 0)


//#define oPIN_12V_ORING_EN_Value()           (_LATB1)
//#define oPIN_12V_ORING_EN_SetHigh()           (_LATB1 = 1)
//#define oPIN_12V_ORING_EN_SetLow()            (_LATB1 = 0)
//#define oPIN_12V_ORING_EN_Toggle()            (_LATB1 ^= 1)
//#define oPIN_12V_ORING_EN_GetValue()          _RB1
//#define oPIN_12V_ORING_EN_SetDigitalInput()   (_TRISB1 = 1)
//#define PIN_V_SetDigitalOutput()  (_TRISB1 = 0)
        
#ifndef _XTAL_FREQ
#define _XTAL_FREQ  119762500UL
#endif


// wh  600W 
#define Voltage_Adjustment 0.05

#define Bus12V_OVP   12*(1+ Voltage_Adjustment)
#define Bus12V_UVP   12*(1- Voltage_Adjustment)

#define Bus12V_WOV   12*(1+ Voltage_Adjustment)*0.95
#define Bus12V_OV_RECOVERY   12*(1+ Voltage_Adjustment)*0.92
#define Bus12V_WUV   12*(1- Voltage_Adjustment)*1.02
#define Bus12V_UV_RECOVERY   12*(1- Voltage_Adjustment)*1.05

 // 3v3 =4096 12bits;       12v * R_devider = 12V *2/(2_8.76) =2.43V; 4906*2.43/3.3 = 3016
#define V_out_value(x)   (unsigned int)    (float) ( x* 2/(2+8.76) )*(4096/3.3)
#define V_ORING_value(x)   (unsigned int)    (float) ( x* 2/(2+8.76) )*(4096/3.3)

#define STB_OVP   5*(1+ Voltage_Adjustment)
#define STB_UVP   5*(1- Voltage_Adjustment)
#define STB_WOV   5*(1+ Voltage_Adjustment)*0.95
#define STB_OV_RECOVERY   5*(1+ Voltage_Adjustment)*0.92
#define STB_WUV   5*(1- Voltage_Adjustment)*1.02
#define STB_UV_RECOVERY   5*(1- Voltage_Adjustment)*1.05

#define V_STBout_value(x)   (unsigned int)    (float) ( x* 2/(2+2 ))*(4096/3.3)

#define Current_auto_Recovery_H 0.5
#define Current_auto_Recovery_L 0.15
#define Bus_I_OCP_RECOVERY_H  50*(1+ Current_auto_Recovery_H)
#define Bus_I_OCP_RECOVERY_L   50*(1+ Current_auto_Recovery_L)
#define I_out_value(x)   (unsigned int)    (float) ( x* (0.0005/2 )*200)*(4096/3.3)

#define STB_Current_auto_Recovery_H 0.1
#define STB_Current_auto_Recovery_L 0.05
#define STB_Bus_I_OCP_RECOVERY_H  50*(1+ Current_auto_Recovery_H)
#define STB_Bus_I_OCP_RECOVERY_L   50*(1+ Current_auto_Recovery_L)
#define    I_STBout_value(x)   (unsigned int)    (float) ( x* (0.01/2 )*200)*(4096/3.3)


#define I_recovery_H 0.5
#define I_recovery_L 0.15
#define Main_I_OCP_Max   50*(1+ I_recovery_H)
#define Main_I_out_value(x)   (unsigned int)    (float) (4096/3.3)*( x* 200)*(0.0005/2)
#define STB_I_out_value(x)   (unsigned int)    (float) (4096/3.3)*( x* 200)*(0.001/2)

#define I_share_value(x)    (float) (4096/3.3)* x * (3.32/(10+3.32))
#define CS_Read_value(x)    (float) (4096/3.3)* x * (3.32/(10+3.32))

// wh
#define CLOCK_SystemFrequencyGet()        (119762500UL)
#define CLOCK_PeripheralFrequencyGet()    (CLOCK_SystemFrequencyGet() / 2)
#define CLOCK_InstructionFrequencyGet()   (CLOCK_SystemFrequencyGet() / 2)

#define BULK_OVP_PRIO       5
#define TMR1_INTERRUPT_TICKER_FACTOR    1

#define ADC1_SCAN_MODE_SELECTED true


#define LED_AC_LOST 0
#define LED_GREEN 1
#define LED_BLINKING 2


typedef enum
{
    
	CMP1_INPUT_CMP1D  = 0x3,
	CMP1_INPUT_CMP1C  = 0x2,
	CMP1_INPUT_CMP1B  = 0x1,
	CMP1_INPUT_CMP1A  = 0x0,
	CMP1_INPUT_PGA2  = 0x1,
	CMP1_INPUT_PGA1  = 0x0
	
}CMP1_INPUT;


typedef enum
{
    
	CMP2_INPUT_CMP2D  = 0x3,
	CMP2_INPUT_CMP2C  = 0x2,
	CMP2_INPUT_CMP2B  = 0x1,
	CMP2_INPUT_CMP2A  = 0x0,
	CMP2_INPUT_PGA2  = 0x1,
	CMP2_INPUT_PGA1  = 0x0
	
}CMP2_INPUT;


typedef enum
{
    
	CMP3_INPUT_CMP3D  = 0x3,
	CMP3_INPUT_CMP3C  = 0x2,
	CMP3_INPUT_CMP3B  = 0x1,
	CMP3_INPUT_CMP3A  = 0x0,
	CMP3_INPUT_PGA2  = 0x1,
	CMP3_INPUT_PGA1  = 0x0
	
}CMP3_INPUT;
	
typedef struct _TMR_OBJ_STRUCT
{
    /* Timer Elapsed */
    volatile bool           timerElapsed;
    /*Software Counter value*/
    volatile uint8_t        count;

} TMR_OBJ;



typedef enum 
{
    V_12V_OUT_MCU,//Channel Name:AN4   Assigned to:Shared Channel
    AN_T_SR_MCU,//Channel Name:AN12   Assigned to:Shared Channel
    SR_EN_MCU,//Channel Name:AN14   Assigned to:Shared Channel
    AN_12V_ORING_MCU,//Channel Name:AN0   Assigned to:Dedicated Core0
    I_SHARE_INT,//Channel Name:AN3   Assigned to:Dedicated Core3
} ADC1_CHANNEL;



void ADC1_Initialize (void);
void ADC1_Core0PowerEnable(void);
void ADC1_Core0Calibration(void);
void ADC1_Core3PowerEnable(void);
void ADC1_Core3Calibration(void);
void ADC1_SharedCorePowerEnable(void);
void ADC1_SharedCoreCalibration(void);

void PIN_MANAGER_Initialize (void);
void CLOCK_Initialize(void);
bool CLOCK_AuxPllLockStatusGet();
void CMP_Initialize(void);
void PWM_Initialize (void);
void TMR1_Initialize (void);

void init_Fan ( );


void SYSTEM_Initialize(void);
void __attribute__((__section__("APP_IMAGE"))) Env_Init(void);
extern TMR_OBJ tmr1_obj;

#endif	/*DSP_INIT_H*/
/**
 End of File
*/

