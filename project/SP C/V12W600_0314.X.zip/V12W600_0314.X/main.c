
#include "Include_headers.h"

static BYTE gtLedTimer = 0;

void __attribute__((__section__("APP_IMAGE_START"))) App_Code(void)
{     
    Env_Init();
//    SR_EN_MCU_SetLow()  ;	  // always on in this solution 
//   gtLedTimer =  SetTimer ( 1000, drv_LED_hnd );
 //delay();)
	
    while (1)
    {
        if(Control.Tsk_200uS)
        {
            Task_200uS();
            Control.Tsk_200uS = 0;
        }
        
        //This Instruction is Must Else MCU will Reset
        Nop();
		

	
    }
}

/*
                         Main application
 */
int main(void)
{
   
    //Reserved for Bootloader Operations
    // Init_DSP_BL();
    // initialize the device
    SYSTEM_Initialize();
	App_Code();
    return 0;

}

/**
 End of File
*/

