#include "Include_headers.h"
#include "Dsp_Interrupt.h"
//#include "lib"

   #define  MAX_SYS_TIMER 8
SYS_TIMER SysTimer[MAX_SYS_TIMER];
QWORD SysTimerCount = 0;





void (*TMR1_InterruptHandler)(void) = NULL;
void (*ADC1_I_SHARE_INTDefaultInterruptHandler)(uint16_t adcVal);



/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

static 
void sys_timer_setting()
{

      BYTE i;
  QWORD DiffTime;

  SysTimerCount ++;

  for ( i = 0; i < MAX_SYS_TIMER; i ++ )
  {
      if ( SysTimer[i].Active )
      {
          DiffTime = SysTimerCount - SysTimer[i].StartTime;
          if ( DiffTime == SysTimer[i].Elapse )
          {
              if ( SysTimer[i].pTimerFunc ) SysTimer[i].pTimerFunc ( );
              SysTimer[i].StartTime = SysTimerCount;
          }
      }
  }
}


/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
//-------------------------------- SetTimer ms--------------------------------------

BYTE SetTimer ( WORD Elapse, _Pfn pTimerFunc )
{
  BYTE i;

  if ( Elapse == 0 )
  {
      if ( pTimerFunc != NULL )
      {
          pTimerFunc ( );
      }
  }
  else
  {
      for ( i = 0; i < MAX_SYS_TIMER; i ++ )
      {
          if ( SysTimer[i].Active == 0 )
          {
              SysTimer[i].Active = 1;
              SysTimer[i].pTimerFunc = pTimerFunc;
              SysTimer[i].Elapse = Elapse;
              SysTimer[i].StartTime = SysTimerCount;
              return i + 1;
          }
      }
  }
  return 0;
}

/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/

void KillTimer ( BYTE *pTimerID )
{
  if ( *pTimerID <= 0 || * pTimerID > MAX_SYS_TIMER ) return;

  SysTimer[*pTimerID - 1].Active = 0;

  *pTimerID = 0;
}

void __attribute__ ( ( interrupt, no_auto_psv ) ) _T1Interrupt (  )
{
    /* Check if the Timer Interrupt/Status is set */

    //***User Area Begin

    // ticker function call;
    // ticker is 1 -> Callback function gets called everytime this ISR executes
    if(TMR1_InterruptHandler) 
    { 
           TMR1_InterruptHandler(); 
    }

    //***User Area End

    tmr1_obj.count++;
    tmr1_obj.timerElapsed = true;
    IFS0bits.T1IF = false;
}

void __attribute__ ((weak)) TMR1_CallBack(void)
{
    Control.Tsk_200uS = 1;
    sys_timer_setting();
}

void  TMR1_SetInterruptHandler(void (* InterruptHandler)(void))
{ 
    IEC0bits.T1IE = false;
    TMR1_InterruptHandler = InterruptHandler; 
    IEC0bits.T1IE = true;
}

void __attribute__ ((weak)) ADC1_I_SHARE_INT_CallBack( uint16_t adcVal )
{ 
    Control_Loop();
 //PIN_AC_OK_OUT_Toggle();
}

void ADC1_SetI_SHARE_INTInterruptHandler(void* handler)
{
    ADC1_I_SHARE_INTDefaultInterruptHandler = handler;
}

void __attribute__ ( ( __interrupt__ , auto_psv, weak ) ) _ADCAN3Interrupt ( void )
{
    uint16_t valI_SHARE_INT;
    //Read the ADC value from the ADCBUF
    valI_SHARE_INT = ADCBUF3;

    if(ADC1_I_SHARE_INTDefaultInterruptHandler) 
    { 
        ADC1_I_SHARE_INTDefaultInterruptHandler(valI_SHARE_INT); 
    }

    //clear the I_SHARE_INT interrupt flag
    IFS7bits.ADCAN3IF = 0;
}

/*******************************************************************************
 * Function:        _CMP3Interrupt
 *
 * Parameters:      -
 * Returned value:  -
 *
 * Description:     BULK OVP interrupt - CMP3B
 *
 ******************************************************************************/

void __attribute__((__interrupt__, no_auto_psv)) _CMP3Interrupt()
{
    /*Turn OFF LLC - Latch*/
    PWM_DISABLE();
    oPIN_LLC_EN_MCU_SetLow() ;
    OP_DATA.LLC_En = 0;
    _AC3IF = 0;

} 

void __attribute__((__interrupt__, no_auto_psv)) _CMP2Interrupt()
{

    if(!OP_DATA.CL_SoftStart)
    {
        /*Turn OFF PFC - Latch*/
        PWM_DISABLE();
        oPIN_LLC_EN_MCU_SetLow() ;
        OP_DATA.LLC_En = 0;
    }
  _AC2IF = 0;

}

void Init_Timer1_Callback()
{
    if(TMR1_InterruptHandler == NULL)
    {
        TMR1_SetInterruptHandler(&TMR1_CallBack);
    }
}

void Init_ADC_Callback()
{
  ADC1_SetI_SHARE_INTInterruptHandler(&ADC1_I_SHARE_INT_CallBack);
}


/************************************************************************
 * author:                     WH
 * description:
 * input:
 * output:
 * version:
 * remark:
 * history:
 * ***********************************************************************/
void __attribute__((__interrupt__,no_auto_psv)) _CNInterrupt(void)
{       
//#define PFC_NOK  0
//     oPIN_12V_ORING_EN_Value()  =iPIN_PS_ON_MCU_GetValue() ;           
//     PIN_ACOK_OUT_Value()  =iPIN_ACOK_IN_GetValue();   
//     
//     if(iPIN_PFC_OK_GetValue() &&   iPIN_ACOK_IN_GetValue() )
//     {
//        PIN_STB_EN_SetHigh() ;
//     }
//     else if (!iPIN_PFC_OK_GetValue() )
//     {
//         PIN_STB_EN_SetLow() ;
//     }
 
 
#if remove 
 if ( iAC_OK == AC_N_GOOD && ( ( _SD_Flag.STB_OCP == 0 ) && ( _SD_Flag.STB_OVP == 0 ) && ( _SD_Flag.STB_UVP == 0 ) ) /*&& (AcOffBlankingTime >= 5)*/ )    
      {
          if ( PIN_oPIN_LLC_EN_MCU == P_N_OK )	// hbllc 
          {
                  gPagePlusStatus.PAGE[PS.isDCInput].STATUS_INPUT.bits.UNIT_OFF = 1;
                  if ( Real_Vac < Parameter.VIN_UV_WARN_LIMIT[PS.isDCInput] )
                  {
                      gPagePlusStatus.PAGE[PS.isDCInput].STATUS_INPUT.bits.VIN_UV_WARNING = 1;
                  }
                  if ( Real_Vac < Parameter.VIN_UV_FAULT_LIMIT[PS.isDCInput] )
                  {
                      gPagePlusStatus.PAGE[PS.isDCInput].STATUS_INPUT.bits.VIN_UV_FAULT = 1;
                  } 
          }
      }
#endif
 IFS1bits.CNIF = 0;    
}


void __attribute__ ( ( __interrupt__, no_auto_psv ) ) _IC1Interrupt ( )
{
//  gFan1.Detected = TRUE;
//
//  UpdateFanSpeedA ( );

  IFS0bits.IC1IF = 0;
}