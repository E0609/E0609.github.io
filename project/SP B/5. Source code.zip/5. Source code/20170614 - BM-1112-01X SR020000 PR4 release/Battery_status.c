#include <p24FJ64GA006.h>
#include "bms_Pin_Define.h"
#include "GenericTypeDefs.h"
#include "I2C.h"
#include "Battery_status.h"
#include "PMBusData.h"
#include "PMBus_status.h"
#include "Failure.h"
#include "EEPROM.h"
#include <string.h>

u16_t Voltage_1x = 0, Voltage_2x = 0, Voltage_3x = 0;
u8_t Battery_count = 0;
u8_t Battery_count2 = 0;
u8_t Battery_Current_Read_Flag = 0;
u8_t Read_Battery_Process_Flag = 0;
u8_t RSOC_update_Flag = 0;
u8_t Remaining_Capacity_update_Flag = 0;


Cell_Info_T Cell_Info;
Battery_Status_T Battery_Status;
/************ Battery Diagnostic **************/
void Battery_diagnostic(void)  //Ū���q����l���A
{
  I2C1_write(Battery_Address, ReadBattery_ManufacturerAccess, Battery_Learning_Low_Disable, Battery_Learning_High);
  asm("NOP");
  asm("NOP");
}

void Read_Battery_data(void)
{

  if(Battery_count == 3)
  {
    Battery_count = 0;
  }
  
  Battery_count++;

//  Battery_count = 2;
  switch(Battery_count)
  {
    case 1:
    I2C1_Read(Battery_Address,ReadBattery_Temperature);          // ReadBattery_Temperature
    if(I2C_State.PEC_error == 0 && I2C_State.Communication_Fail == 0)
    {
      Cell_Info.Temp = ((data_high<< 8 ) + data_low)/10;
    }
    asm("NOP");
    asm("NOP"); 

     break;

    case 2:
    I2C1_Block_Read(Battery_Address, ReadBattery_MoreData, 40);
    if(I2C_State.PEC_error == 0 && I2C_State.Communication_Fail == 0)
    {
      Cell_Info.Voltage = ((BatteryBlockBuff[1] << 8 ) + BatteryBlockBuff[0])*2;
      Cell_Info.Current = ((BatteryBlockBuff[3] << 8 ) + BatteryBlockBuff[2]);
      Cell_Info.Current = Cell_Info.Current *8;
      Cell_Info.Cell1Voltage = (BatteryBlockBuff[5] << 8 ) + BatteryBlockBuff[4];
      Cell_Info.Cell2Voltage = (BatteryBlockBuff[7] << 8 ) + BatteryBlockBuff[6];
      Cell_Info.Cell3Voltage = (BatteryBlockBuff[9] << 8 ) + BatteryBlockBuff[8];
      Cell_Info.Cell4Voltage = (BatteryBlockBuff[11] << 8 ) + BatteryBlockBuff[10];
      Cell_Info.Cell5Voltage = (BatteryBlockBuff[13] << 8 ) + BatteryBlockBuff[12];
      Cell_Info.Cell6Voltage = (BatteryBlockBuff[15] << 8 ) + BatteryBlockBuff[14];
      Cell_Info.Cell7Voltage = (BatteryBlockBuff[17] << 8 ) + BatteryBlockBuff[16];
      Cell_Info.Cell8Voltage = (BatteryBlockBuff[19] << 8 ) + BatteryBlockBuff[18];
      Cell_Info.Cell9Voltage = (BatteryBlockBuff[23] << 8 ) + BatteryBlockBuff[22];
      Cell_Info.Cell10Voltage = (BatteryBlockBuff[25] << 8 ) + BatteryBlockBuff[24];
      Cell_Info.Cell11Voltage = (BatteryBlockBuff[27] << 8 ) + BatteryBlockBuff[26];
      Cell_Info.Cell12Voltage = (BatteryBlockBuff[29] << 8 ) + BatteryBlockBuff[28];
      Cell_Info.Cell13Voltage = (BatteryBlockBuff[33] << 8 ) + BatteryBlockBuff[32];
    }
    if(Cell_Info.Voltage < Discharging_Cell_Cutoff_Voltage && DISCHG_EN1 == 1)
    {
      Discharger_Delay.Cell_UV_Fault_Cnt ++;
    }
    else
    {
      Discharger_Delay.Cell_UV_Fault_Cnt = 0;
    }

    if(Cell_Info.Voltage >= Charging_Cell_OV_Protection_Threshold && CHG_EN == 0)
    {
      Charger_Cell_OVP_cnt ++;
    }
    else
    {
      Charger_Cell_OVP_cnt = 0;
    }
    Battery_Current_Read_Flag = 1;
    asm("NOP");
    asm("NOP");

      break;

    case 3:
    if(Battery_count2 == 11)
    {
      Battery_count2 = 0;    
    }
    Battery_count2++;
      switch(Battery_count2)
      {
        case 1:
        I2C1_Read(Battery_Address,ReadBattery_RemainingCapacity);
        if(I2C_State.PEC_error == 0 && I2C_State.Communication_Fail == 0)
        {  
          Cell_Info.RemainingCapacity = (data_high<< 8 ) + data_low;
          Remaining_Capacity_update_Flag = 1;
        }
		asm("NOP");
        asm("NOP");
          break;

        case 2:
        I2C1_Read(Battery_Address,ReadBattery_RelativeStateOfCharge);
        if(I2C_State.PEC_error == 0 && I2C_State.Communication_Fail == 0)
        {
          Cell_Info.RSOC = (data_high<< 8 ) + data_low;
          RSOC_update_Flag = 1;
        }
        asm("NOP");
        asm("NOP");
          break;

        case 3:
        I2C1_Read(Battery_Address,ReadBattery_AbsoluteStateOfCharge);
        if(I2C_State.PEC_error == 0 && I2C_State.Communication_Fail == 0)
		{
          Cell_Info.ASOC = (data_high<< 8 ) + data_low;
        }      
		asm("NOP");
        asm("NOP");
          break;

        case 4:
        I2C1_Read(Battery_Address,ReadBattery_PFStatus);
        if(I2C_State.PEC_error == 0 && I2C_State.Communication_Fail == 0)
		{
		  Cell_Info.PermanentFailureStatus.Val = (data_high<< 8 ) + data_low;
        }      
		asm("NOP");
        asm("NOP");
          break;
           
        case 5:
        I2C1_Read(Battery_Address,ReadBattery_BatteryStatus);
        if(I2C_State.PEC_error == 0 && I2C_State.Communication_Fail == 0)
		{
		  Cell_Info.BatteryStatus.Val = (data_high<< 8 ) + data_low;
  		}      
		asm("NOP");
        asm("NOP");
          break;

        case 6:
        I2C1_Read(Battery_Address,ReadBattery_ProtectionStatus);
        if(I2C_State.PEC_error == 0 && I2C_State.Communication_Fail == 0)
		{
		  Cell_Info.ProtectionStatus.Val = (data_high<< 8 ) + data_low;
  		}      
		asm("NOP");
        asm("NOP");
          break;

        case 7:
        I2C1_Read(Battery_Address,ReadBattery_MinCellVoltageHistory);
        if(I2C_State.PEC_error == 0 && I2C_State.Communication_Fail == 0)
		{
		  Cell_Info.CellMinVoltageHis = (data_high<< 8 ) + data_low;
  		}
        asm("NOP");
        asm("NOP");
          break;

               
        case 8:
        I2C1_Read(Battery_Address,ReadBattery_CycleCount);
        if(I2C_State.PEC_error == 0 && I2C_State.Communication_Fail == 0)
		{
          Cell_Info.CycleCount = (data_high << 8 ) + data_low;
          if(EEPROM_Info.Cycle_Cnt_Offset != 65535)
          {
             Cell_Info.CycleCount = (Cell_Info.CycleCount - EEPROM_Info.Cycle_Cnt_Offset);
          }
          
  		}
        asm("NOP");
        asm("NOP");
          break;

        case 9:
        I2C1_Block_Read(Battery_Address, ReadBattery_ManufactureName, 4);
        if(I2C_State.PEC_error == 0 && I2C_State.Communication_Fail == 0)
		{
           memcpy(pu8BatteryName, BatteryBlockBuff, sizeof(pu8BatteryName));
        }
        asm("NOP");
        asm("NOP");
          break;

        case 10:
        I2C1_Read(Battery_Address, ReadBattery_StateOfHealth);
        if(I2C_State.PEC_error == 0 && I2C_State.Communication_Fail == 0)
		{
           Cell_Info.SOH = (data_high << 8 ) + data_low;
        }
        asm("NOP");
        asm("NOP");
          break;

        case 11:
        I2C1_Read(Battery_Address, ReadBattery_FullChargeCapacity);
        if(I2C_State.PEC_error == 0 && I2C_State.Communication_Fail == 0)
		{
           Cell_Info.FullChargeCapacity = (data_high << 8 ) + data_low;
        }
        asm("NOP");
        asm("NOP");
          break;          
      
        default:
 
          break;
        
      }   

  }  

}



void Battery_status(void)
{
   if(System_Run.I2C_Time_40ms == 1)
   {
     I2C_State.Old_Communication = I2C_State.Communication_Fail;
     System_Run.I2C_Time_40ms = 0;
     if(I2C_State.Old_Communication == 1)
     {
       I2C_State.Communication_Fail_Count ++;
                 
       if(I2C_State.Communication_Fail_Count >= 250)
       {
          Failure_type.bits.BMS_Communication_loss = 1;
          if(Failure_type.val != 0)
          {
            SystemControl.bits.Flag_Failure = 1;
          }
       }

     }
     else
     {
       I2C_State.Communication_Fail_Count = 0;
       Failure_type.bits.BMS_Communication_loss = 0;
       
     }
      
     I2C_State.Communication_Fail = 0;
     
     Read_Battery_Process_Flag = 1;
     Read_Battery_data();                      // if this flag equal one describe i2c bus will use now
     Read_Battery_Process_Flag = 0;
     

   }


}


void Status_BBU_update(void)
{
//--------------------- Remaining Capacity status ---------------------//
   if(Cell_Info.RemainingCapacity <= Cell_low_Capacity_Warning_Threshold)
   {
      Warning_type.bits.Cell_low_Capacity_Warning = 1;
      u8StatusP0BBU = u8StatusP0BBU | Status_BBU_bits_Battery_Low_Warning;
      u8StatusP1BBU = u8StatusP1BBU | Status_BBU_bits_Battery_Low_Warning;
   }
   
   else if(Cell_Info.RemainingCapacity > Cell_low_Capacity_Recover_Threshold)
   {
      Warning_type.bits.Cell_low_Capacity_Warning = 0;
      u8StatusP0BBU = (u8StatusP0BBU & ~(Status_BBU_bits_Battery_Low_Warning));
      u8StatusP1BBU = (u8StatusP1BBU & ~(Status_BBU_bits_Battery_Low_Warning));
   }


//-------------------- State of Health warning less than 60% -------------------//
   if(Cell_Info.SOH <= Battery_SOH_Warning_Threshold)
   {
      u8StatusP0BBU = u8StatusP0BBU | Status_BBU_bits_Battery_SOH_Low_Warning; 
      u8StatusP1BBU = u8StatusP1BBU | Status_BBU_bits_Battery_SOH_Low_Warning;
   }
   else
   {
      u8StatusP0BBU = (u8StatusP0BBU & ~(Status_BBU_bits_Battery_SOH_Low_Warning)); 
      u8StatusP1BBU = (u8StatusP1BBU & ~(Status_BBU_bits_Battery_SOH_Low_Warning)); 
   }

 //---------------- Discharge Remaining time less than 3 minute(180 Sec) --------------//  
   if(Cell_Info.Discharge_Remain_Time < Discharge_Remaining_Time_warning_Threshold)
   {
    
     u8StatusP0BBU = u8StatusP0BBU | Status_BBU_bits_Disharge_Remain_time_less;
     u8StatusP1BBU = u8StatusP1BBU | Status_BBU_bits_Disharge_Remain_time_less;

   }
   else
   {
     u8StatusP0BBU = u8StatusP0BBU & ~(Status_BBU_bits_Disharge_Remain_time_less);
     u8StatusP1BBU = u8StatusP1BBU & ~(Status_BBU_bits_Disharge_Remain_time_less);
   }   

//------------------- BMS communication loss 10 sec ------------------//
   if(Failure_type.bits.BMS_Communication_loss == 1)
   {
      u8StatusP0BBU = u8StatusP0BBU | Status_BBU_bits_BMS_Communication_loss;
      u8StatusP1BBU = u8StatusP1BBU | Status_BBU_bits_BMS_Communication_loss;
      u16StatusP0Word = (u16StatusP0Word | Status_Word_bits_CML);
      u16StatusP1Word = (u16StatusP1Word | Status_Word_bits_CML);     
   }
   else
   {
      u8StatusP0BBU = (u8StatusP0BBU & ~(Status_BBU_bits_BMS_Communication_loss));
      u8StatusP1BBU = (u8StatusP1BBU & ~(Status_BBU_bits_BMS_Communication_loss));
      if(u8StatusP0CML == 0)
      {
       u16StatusP0Word = (u16StatusP0Word & ~(Status_Word_bits_CML));
       u16StatusP1Word = (u16StatusP1Word & ~(Status_Word_bits_CML));
      }
   }

//------------------- Cell Any PF appear -------------//
   if(Cell_Info.PermanentFailureStatus.Val != 0)
   {
      u8StatusP0BBU = u8StatusP0BBU | Status_BBU_bits_Battery_PF;
      u8StatusP1BBU = u8StatusP1BBU | Status_BBU_bits_Battery_PF;
      Failure_type.bits.Cell_PF = 1;
   }
   else
   {
      u8StatusP0BBU =(u8StatusP0BBU & ~(Status_BBU_bits_Battery_PF));
      u8StatusP1BBU =(u8StatusP1BBU & ~(Status_BBU_bits_Battery_PF));  
   }

   if(Cell_Info.CycleCount > u16CycleCntLimit)
   {
      u8StatusP0BBU = u8StatusP0BBU | Status_BBU_bits_Battery_Cycle_Cnt_Warning;
      u8StatusP1BBU = u8StatusP1BBU | Status_BBU_bits_Battery_Cycle_Cnt_Warning;
   }
   else
   {
      u8StatusP0BBU = (u8StatusP0BBU & ~(Status_BBU_bits_Battery_Cycle_Cnt_Warning));
      u8StatusP1BBU = (u8StatusP1BBU & ~(Status_BBU_bits_Battery_Cycle_Cnt_Warning));
   }

   if(Cell_Info.ProtectionStatus.bits.COC == 1)
   {
      Failure_type.bits.Charger_Output_OCP = 1; 
   }


}

void Battery_SelfDetect(void)
{
  if(u16BBS_Control == 1)           // need aging comparsion
  {
    if(Cell_Info.BatteryStatus.bits.Aging_Comparison_Request == 0 && Cell_Info.BatteryStatus.bits.Aging_Comparison_Ready == 0 && 
       Cell_Info.BatteryStatus.bits.Aging_Comparison_Done == 0)
    {
      I2C1_write(Battery_Address, ReadBattery_ManufacturerAccess, Battery_Learning_Low_Enable, Battery_Learning_High);
    }        
  }
  else if(u16BBS_Control == 2)
  {
    if(Cell_Info.BatteryStatus.bits.Aging_Comparison_Request == 1 || Cell_Info.BatteryStatus.bits.Aging_Comparison_Ready == 1 ||
       Cell_Info.BatteryStatus.bits.Aging_Comparison_Done == 1)
    {
      I2C1_write(Battery_Address, ReadBattery_ManufacturerAccess, Battery_Learning_Low_Disable, Battery_Learning_High);
    }
  }
   
}
