#include "QTBootloader.h"
#include "I2C.h"
#include "QTBootloaderBypass.h"
#include <string.h>

ByPassBootloader_t ByPassBootloader;

/*******************************************************************************
*	brief 	build bypass transmit data from some interface to master i2c
*	para1:	bypass command code
*	para2:	bypass data pointer
*	para3:	bypass data length
*	return: none
*******************************************************************************/
void BuildBypassTxData(u8_t u8Cmd, u8_t* u8DataBuf, u8_t u8DataLen)
{
	//-------------------------------------
	//get bypass command information
	//-------------------------------------
	ByPassBootloader.u8BypassCmdCode = u8Cmd;
	memset(ByPassBootloader.pu8BypassRxBuff, 0xff, MSTR_BYPASS_RX_BUFF);

	//-------------------------------------
	//save data in bypass transmit data buffer
	//-------------------------------------
	memcpy(ByPassBootloader.pu8BypassTxBuff, u8DataBuf, u8DataLen);

	//-------------------------------------
	//assert bypass flag, start bypass task
	//-------------------------------------
	ByPassBootloader.u8BypassFlag = 1;

}
/*******************************************************************************
*	brief 	build bypass receive data from master i2c to some interface
*	para1:	bypass data pointer
*	para2:	bypass data length
*	return: none
*******************************************************************************/
void BuildBypassRxData(u8_t* u8DataBuf, u8_t u8DataLen)
{
	memcpy(u8DataBuf, ByPassBootloader.pu8BypassRxBuff, u8DataLen);
}


