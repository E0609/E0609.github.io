#ifndef __PMBUS_DATA_TRANSFOR_H__
#define __PMBUS_DATA_TRANSFOR_H__

#include "main.h"


unsigned int Real_to_Literal (long real_value, unsigned int gain);
long Literal_to_Real (unsigned int literal_value, unsigned int gain);
unsigned int Real_To_Literal_ForVout(unsigned int value);
unsigned int Literal_To_Real_ForVout(unsigned int value);

#endif

