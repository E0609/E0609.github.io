/********************************************************************************
* file				PMBusApp.c
*
* brief				The file includes the function of PMBus protocol
*					The PMBus app doesn't support extended command. Need to modify
*					the app if wants to support extended command.
* note
*
* author			slade.fang
*
* version			01
*
* section History	2014/09/01	-	1st release
********************************************************************************/

#include "PMBusApp.h"
#include "SI2CDrv.h"
#include "PMBusData.h"
#include "CRC.h"
#include <math.h>
#include "QTBootloader.h"
   



//flag used for modbus application
typedef union
{
	struct
	{
		u16_t u1RxRecived		:1;		//PC request is received, after put the data in the tx buffer, clear the flag.
		u16_t u2CmdSupport		:2;    	//01: read command, 02:write-read or write command, 03:status command, after put the data in the tx buffer, clear the flag.
		u16_t u1MapRxData		:1;		//Need to check if PEC support or not and then map the data. Also used for calculate CRC
		u16_t u1DataNotSup		:1;		//write byte over the variable length, not write to the buffer to avoid code crash
		u16_t u11NA				:11;
	}u16Bit;
	
	u16_t u16All;
}nPMBusFlag_t;

//structure for PMBus application
typedef struct
{
	//modbus general data
	u8_t pu8RxBuff[PMBUSAPP_RX_BUFF];
	u8_t pu8TxBuff[PMBUSAPP_TX_BUFF];
	u8_t u8Cmd;							//this command is used for page plus read/write, SMBAlert and Query command
	u8_t u8CmdType;						//this command is used for page plus read/write, SMBAlert and Query command
	u8_t u8RxIdx;
	u8_t u8RxByteCnt;					//the byte count used for block write
	u8_t u8RxTimeOut;
	u8_t u8TxIdx;
	u8_t u8TxLength;					//include CRC 
	u8_t u8CRCIdx;						//record the index before PEC byte
	u8_t u8CRC8;
	nPMBusFlag_t nPMBusFlag;
	sPMBusCmdStatusStr_t* psCmd;
	
	//error count statistics
	u16_t u16RxTimeOutCnt;
	u16_t u16RxParseErrCnt;
	u16_t u16CmdNotSupCnt;
	u16_t u16DataNotSupCnt;
	u16_t u16CRCFailCnt;
}sPMBusStr_t;

sPMBusStr_t sPMBusStruct;

void UpdateStatusBit(u8_t u8Cmd, u8_t u8Bit, u8_t u8Set);
static void RxSendByteHandler(void);

/*******************************************************************************
*   brief 	Init the PMBus application, used before while(1) in main() and command 
*			transaction finish.
*******************************************************************************/
void PMBusInit(void)
{

	sPMBusStruct.u8RxTimeOut = 0;
	sPMBusStruct.u8TxIdx = 0;
	sPMBusStruct.nPMBusFlag.u16All = 0;
	sPMBusStruct.u8RxByteCnt = 0;
	
}

/*******************************************************************************
*   brief 	Set the variable according to the current page and data length 
*	para1:	The value set to the PMBusData variables
* 	para2:	The variable data length		
*******************************************************************************/
    s16_t s16Rxv, s16Div, s16Mul;
    s32_t s16Real;
static void SetPageVariable(u8_t* pu8Buff, u8_t u8Length, u8_t u8WriteTemp)
{
	s8_t i;
	static u8_t pu8TempBuff[PMBUSAPP_RX_BUFF];
	static u8_t u8TempLeng;
	
	if(u8WriteTemp)
	{
		for(i=0;i<PMBUSAPP_RX_BUFF;i++)							//clear to 0 for EEPROM write
		{
			pu8TempBuff[i] = 0;
		}
		
		for(i=0;i<u8Length;i++) 
		{
			pu8TempBuff[i] = (*(pu8Buff+i));
		}
		
		u8TempLeng = u8Length;
	}
	else
	{
		//check the CRC
		if(sPMBusStruct.u8CRCIdx < sPMBusStruct.u8RxIdx)		//needs to check CRC
		{
			if(sPMBusStruct.u8CRC8 != sPMBusStruct.pu8RxBuff[sPMBusStruct.u8RxIdx])
			{
				UpdateStatusBit(PMBusCmd_StatusCML, 5, 1);
//				UpdateStatusBit(PMBusCmd_StatusByte, 1, 1);
				return;	
			}
		}
		
        //check the value of cmd WRITE_PROTECT to deternime if we can write the current cmd
		if(PMBus_WrProtect == 0x80)
		{
			if((sPMBusStruct.u8Cmd != PMBusCmd_WriteProt) && (sPMBusStruct.u8Cmd != PMBusCmd_MFRSp30) &&
               (sPMBusStruct.u8Cmd != PMBusCmd_UsrData11))
			{
				return;
			}
		}
		else if(PMBus_WrProtect == 0x40)
		{
			if((sPMBusStruct.u8Cmd != PMBusCmd_Page) && (sPMBusStruct.u8Cmd != PMBusCmd_Operation) &&
			   (sPMBusStruct.u8Cmd != PMBusCmd_WriteProt) && (sPMBusStruct.u8Cmd != PMBusCmd_MFRSp30) &&
               (sPMBusStruct.u8Cmd != PMBusCmd_UsrData11))
			{
				return;
			}
		}
		else if(PMBus_WrProtect == 0x20)
		{
			if((sPMBusStruct.u8Cmd != PMBusCmd_Page) && (sPMBusStruct.u8Cmd != PMBusCmd_Operation) &&
			   (sPMBusStruct.u8Cmd != PMBusCmd_OnOffConf) && (sPMBusStruct.u8Cmd != PMBusCmd_WriteProt) &&
			   (sPMBusStruct.u8Cmd != PMBusCmd_VoutCmd) && (sPMBusStruct.u8Cmd != PMBusCmd_MFRSp30) &&
               (sPMBusStruct.u8Cmd != PMBusCmd_UsrData11))
			{
				return;
			}
		}

		//if the value is not in rule, cmd PAGE keep the original value
		if(sPMBusStruct.u8Cmd == PMBusCmd_Page)
		{
			if(*pu8TempBuff > PMBus_MaxPage && *pu8TempBuff != 0xff)
			{
				UpdateStatusBit(PMBusCmd_StatusCML, 6, 1);
				return;
			}
		}

		//if the value is not in rule, cmd WRITE_PROTECT keep the original value
		else if(sPMBusStruct.u8Cmd == PMBusCmd_WriteProt)
		{
			if((*pu8TempBuff != 0x00) && (*pu8TempBuff != 0x20) && (*pu8TempBuff != 0x40) && (*pu8TempBuff != 0x80))
			{
				UpdateStatusBit(PMBusCmd_StatusCML, 6, 1);
				return;
			}
		}

        // if the value is not 0x80 and 0x00 keep the original data and assert unsupport data
        else if(sPMBusStruct.u8Cmd == PMBusCmd_Operation)
        {
           	if((*pu8TempBuff != 0x00) && (*pu8TempBuff != 0x80))
			{
				UpdateStatusBit(PMBusCmd_StatusCML, 6, 1);
				return;
			}

            if(*pu8TempBuff == 0x80)
            {
               Clear_Failure();
            }

        }

        else	//if the value is out of min/max, don't accept the value
		{
			for(i=0;i<USER_PMBUS_WRLIMITNUM;i++)
			{
				if(sPMBusStruct.u8Cmd == sPMBusWrLimit[i].u8Cmd)
				{
					break;
				}
			}
			
			if(i < USER_PMBUS_WRLIMITNUM)		//check the min/max value
			{
				//get the real value
				if((sPMBusWrLimit[i].u8LinearType > 0) && (sPMBusWrLimit[i].u8LinearType <= 16))
				{
					s16Rxv = *(pu8TempBuff) + (*(pu8TempBuff+1)<<8);
                    if(sPMBusWrLimit[i].u8LinearType == 16)
                    {
                      s16Div = 0;
                    }
                    else
                    {
					  s16Div = s16Rxv >> sPMBusWrLimit[i].u8LinearType;
					}
                    s16Mul = (s16_t)((u16_t)s16Rxv << (16-sPMBusWrLimit[i].u8LinearType)) >> (16-sPMBusWrLimit[i].u8LinearType);
					s16Real = pow(2,s16Div) * s16Mul * 1000;
                    asm("NOP");
				}
				else
				{
					s16Real = *(pu8TempBuff) + (*(pu8TempBuff+1)<<8);
				}
				
				//check the min/max
				if((s16Real < (sPMBusWrLimit[i].s32Min)*1000) || (s16Real > (sPMBusWrLimit[i].s32Max*1000)))
				{
                    UpdateStatusBit(PMBusCmd_StatusCML, 6, 1);
					return;
				}
			}
		}

		
		

		
		if(PMBus_CurrPage == 0)
		{
			for(i=0;i<u8TempLeng;i++)
			{
				if(sPMBusStruct.nPMBusFlag.u16Bit.u2CmdSupport == 3)								//write status reg to clear status bit 
				{
                    if(sPMBusStruct.u8Cmd == PMBusCmd_StatusByte)
					{
						if((*(pu8TempBuff+i)) != 0x80)
						{
							UpdateStatusBit(PMBusCmd_StatusCML, 6, 1);
							return;
						}
					}
					else if(sPMBusStruct.u8Cmd == PMBusCmd_StatusWord)
					{
						if(i == 0)
						{
						    if((*(pu8TempBuff+i)) != 0x80)
							{
								UpdateStatusBit(PMBusCmd_StatusCML, 6, 1);
								return;
							}
						}
						else if(i == 1)
						{
							if((*(pu8TempBuff+i)) != 0x01)
							{
								UpdateStatusBit(PMBusCmd_StatusCML, 6, 1);
								return;
							}
						}
					}
					*(u8_t*)(sPMBusStruct.psCmd->pu8P0Buff+i) &= ~(*(pu8TempBuff+i));
				}
				else
				{
					
					if(sPMBusStruct.u8Cmd == PMBusCmd_SMBAlertMask)		//write the mask variable
					{
						*(u8_t*)(sPMBusStruct.psCmd->pu8P0StatusMask+i) = (*(pu8TempBuff+i));
					}
					else
					{
						*(u8_t*)(sPMBusStruct.psCmd->pu8P0Buff+i) = (*(pu8TempBuff+i));
					}
					
					if(sPMBusStruct.u8CmdType != PMBusCmdT_SendByte)		//don't need to store the EEPROM now..	
					{
						if(sPMBusStruct.psCmd->u16E2pP0Index != 0xffff)		//don't support write EEPROM 
						{
							if((i%2) == 0)		//EEPROM need u16_t data type
							{
//								PushE2PWriteData(sPMBusStruct.psCmd->u16E2pP0Index+i/2, (*(u16_t*)(pu8TempBuff+i)));	//write EEPROM
							}
						} 
					}
				}
			}
		}
		else if(PMBus_CurrPage == 1)
		{
			for(i=0;i<u8TempLeng;i++)
			{
				if(sPMBusStruct.nPMBusFlag.u16Bit.u2CmdSupport == 3)								//write status reg to clear status bit 
				{
                    if(sPMBusStruct.u8Cmd == PMBusCmd_StatusByte)
					{
						if((*(pu8TempBuff+i)) != 0x80)
						{
							UpdateStatusBit(PMBusCmd_StatusCML, 6, 1);
							return;
						}
					}
					else if(sPMBusStruct.u8Cmd == PMBusCmd_StatusWord)
					{
						if(i == 0)
						{
						 	if((*(pu8TempBuff+i)) != 0x80)
							{
								UpdateStatusBit(PMBusCmd_StatusCML, 6, 1);
								return;
							}
						}
						else if(i == 1)
						{
							if((*(pu8TempBuff+i)) != 0x01)
							{
								UpdateStatusBit(PMBusCmd_StatusCML, 6, 1);
								return;
							}
						}
					}
					*(u8_t*)(sPMBusStruct.psCmd->pu8P1Buff+i) &= ~(*(pu8TempBuff+i));
				}
				else
				{
					if(sPMBusStruct.u8Cmd == PMBusCmd_SMBAlertMask)		//write the mask variable
					{
						*(u8_t*)(sPMBusStruct.psCmd->pu8P1StatusMask+i) = (*(pu8TempBuff+i));
					}
					else
					{
						*(u8_t*)(sPMBusStruct.psCmd->pu8P1Buff+i) = (*(pu8TempBuff+i));
					}

					if(sPMBusStruct.u8CmdType != PMBusCmdT_SendByte)		//don't need to store the EEPROM now..	
					{
						if(sPMBusStruct.psCmd->u16E2pP0Index != 0xffff)   	//don't support write EEPROM 
						{
							if((i%2) == 0)		//EEPROM need u16_t data type
							{
//								PushE2PWriteData(sPMBusStruct.psCmd->u16E2pP1Index+i/2, (*(u16_t*)(pu8TempBuff+i)));	//write EEPROM
							}
						}
					}
				}
			}
		}
		else
		{
			for(i=0;i<u8TempLeng;i++)
			{
				if(sPMBusStruct.nPMBusFlag.u16Bit.u2CmdSupport == 3)								//write status reg to clear status bit 
				{
                    if(sPMBusStruct.u8Cmd == PMBusCmd_StatusByte)
					{
						if((*(pu8TempBuff+i)) != 0x80)
						{
							UpdateStatusBit(PMBusCmd_StatusCML, 6, 1);
							return;
						}
					}
					else if(sPMBusStruct.u8Cmd == PMBusCmd_StatusWord)
					{
						if(i == 0)
						{
							if((*(pu8TempBuff+i)) != 0x80)
							{
								UpdateStatusBit(PMBusCmd_StatusCML, 6, 1);
								return;
							}
						}
						else if(i == 1)
						{
							if((*(pu8TempBuff+i)) != 0x01)
							{
								UpdateStatusBit(PMBusCmd_StatusCML, 6, 1);
								return;
							}
						}
					}

					*(u8_t*)(sPMBusStruct.psCmd->pu8P0Buff+i) &= ~(*(pu8TempBuff+i));
					*(u8_t*)(sPMBusStruct.psCmd->pu8P1Buff+i) &= ~(*(pu8TempBuff+i));
				}
				else
				{
					if(sPMBusStruct.u8Cmd == PMBusCmd_SMBAlertMask)		//write the mask variable
					{
						*(u8_t*)(sPMBusStruct.psCmd->pu8P0StatusMask+i) = (*(pu8TempBuff+i));
						*(u8_t*)(sPMBusStruct.psCmd->pu8P1StatusMask+i) = (*(pu8TempBuff+i));
					}
					else
					{
						*(u8_t*)(sPMBusStruct.psCmd->pu8P0Buff+i) = (*(pu8TempBuff+i));
						*(u8_t*)(sPMBusStruct.psCmd->pu8P1Buff+i) = (*(pu8TempBuff+i));
					}

					if(sPMBusStruct.u8CmdType != PMBusCmdT_SendByte)		//don't need to store the EEPROM now..	
					{
						if(sPMBusStruct.psCmd->u16E2pP0Index != 0xffff)		//don't support write EEPROM
						{
							if((i%2) == 0)		//EEPROM need u16_t data type
							{
//								PushE2PWriteData(sPMBusStruct.psCmd->u16E2pP0Index+i/2, (*(u16_t*)(pu8TempBuff+i)));	//write EEPROM
//								PushE2PWriteData(sPMBusStruct.psCmd->u16E2pP1Index+i/2, (*(u16_t*)(pu8TempBuff+i)));	//write EEPROM
							}
						}
					}
				}
			}
		}

	}
}

/*******************************************************************************
*   brief 	Set the value to the corresponding variables after the PEC check 
*			correct or the address read.  
*	note	used in main loop	
*******************************************************************************/
void PMBusMapRxData(void)
{
	u8_t* pu8Tmp;
	
	if(CheckBusStatus())		//stop
	{
		if(sPMBusStruct.nPMBusFlag.u16Bit.u1MapRxData)
		{
			sPMBusStruct.nPMBusFlag.u16Bit.u1MapRxData = 0;	
			SetPageVariable(pu8Tmp, 0, 0);

 			if(sPMBusStruct.u8CmdType == PMBusCmdT_SendByte)		//send byte command need special handle	
			{
				RxSendByteHandler();
			}
		}
	}
}

/*******************************************************************************
*	brief 	Fill the tx buffer for driver tranmsmit. 
*			used in interrupt service routine
*	para1:	the buffer needs to be filled
*	para2: 	the length to fill the tx buffer
*	return: 0:success, 1:error, the length is over the limit of the tx buffer
*******************************************************************************/
static u8_t FillTxBuff(u8_t* pu8Source, u8_t* pu8TxBuff, u8_t u8Length)
{
	s16_t i;
	
	if(u8Length > PMBUSAPP_TX_BUFF)
	{
		return 1;
	}
	else
	{
		for(i=0;i<u8Length;i++)
		{
			*(pu8TxBuff+i) = *(pu8Source+i);
		}
		
		return 0;
	}
}

/*******************************************************************************
*	brief 	Check the command support or not of the product. 
*
*			used in interrupt service routine
*	para1:	the command index needs to check
*	para2: 	the pointer to store the support command data structure
*	return: 1:read command, 2:read-write/write command, 3:status command
*******************************************************************************/
static u16_t RxParseCmdSup(u8_t u8Cmd, sPMBusCmdStatusStr_t** psCmdStr)
{
	s16_t i;		
			
	for(i=0;i<USER_PMBUS_RDNUM;i++)
	{
		if(u8Cmd == sPMBusRdCmd[i].u8Cmd)
		{
			*psCmdStr = (sPMBusCmdStatusStr_t*)&sPMBusRdCmd[i];
			return 1;									//read command support
		}
	}
	
	for(i=0;i<USER_PMBUS_WRNUM;i++)
	{
		if(u8Cmd == sPMBusWrCmd[i].u8Cmd)
		{
			*psCmdStr = (sPMBusCmdStatusStr_t*)&sPMBusWrCmd[i];
			return 2;									//write command support
		}
	}
    
	for(i=0;i<USER_PMBUS_STNUM;i++)
	{
		if(u8Cmd == sPMBusStatusCmd[i].u8Cmd)
		{
			*psCmdStr = (sPMBusCmdStatusStr_t*)&sPMBusStatusCmd[i];
			return 3;									//Status command support
		}
	}
	
//	UpdateStatusBit(PMBusCmd_StatusCML, 7, 1);
//	UpdateStatusBit(PMBusCmd_StatusByte, 1, 1);
	
	if(sPMBusStruct.u16CmdNotSupCnt < 0xffff)
	{
		sPMBusStruct.u16CmdNotSupCnt++;
	}

	return 0;
}

/*******************************************************************************
*	brief 	Parse the send byte command respectively. Only support clear fault 
*			command currently.
*			used in interrupt service routine
*******************************************************************************/  
static void RxSendByteHandler(void)
{

	if(sPMBusStruct.u8Cmd == PMBusCmd_ClrFault)
	{
        PMBus_Clear_Fault();
/*
		if(*sPMBusStruct.psCmd->pu8P0Buff)
		{
			for(i=0;i<USER_PMBUS_STNUM;i++)
			{
			    if(sPMBusStatusCmd[i].u8Cmd == PMBusCmd_StatusByte)
					*(u16_t*)sPMBusStatusCmd[i].pu8P0Buff &= 0xff7f;
				else if(sPMBusStatusCmd[i].u8Cmd == PMBusCmd_StatusWord)
					*(u16_t*)sPMBusStatusCmd[i].pu8P0Buff &= 0xfe7f;
                else
					*sPMBusStatusCmd[i].pu8P0Buff = 0;
			}
			
			*sPMBusStruct.psCmd->pu8P0Buff = 0;
		}
		
		if(*sPMBusStruct.psCmd->pu8P1Buff)
		{
			for(i=0;i<USER_PMBUS_STNUM;i++)
			{
			    if(sPMBusStatusCmd[i].u8Cmd == PMBusCmd_StatusByte)
					*(u16_t*)sPMBusStatusCmd[i].pu8P1Buff &= 0xfe7f;
				else if(sPMBusStatusCmd[i].u8Cmd == PMBusCmd_StatusWord)
					*(u16_t*)sPMBusStatusCmd[i].pu8P1Buff &= 0xfe7f;
                else
					*sPMBusStatusCmd[i].pu8P1Buff = 0;
			}

			*sPMBusStruct.psCmd->pu8P1Buff = 0;
		}
*/
	}
	else if(sPMBusStruct.u8Cmd == PMBusCmd_StoreDftAll)
	{
		;		//not implement
	}
	else if(sPMBusStruct.u8Cmd == PMBusCmd_RStoreDftAll)
	{
		;		//not implement
	}
	else if(sPMBusStruct.u8Cmd == PMBusCmd_StoreUserAll)
	{
		;		//not implement
	}
	else if(sPMBusStruct.u8Cmd == PMBusCmd_RStoreUserAll)
	{
		;		//not implement
	}
}

static void RxParseSendByte(void)
{
	u8_t u8TempData;
	
    sPMBusStruct.nPMBusFlag.u16Bit.u1MapRxData = 0;
	SetPageVariable(&u8TempData, 1, 0);
	RxSendByteHandler();
}

/******************************************
*************************************
*	brief 	Parse the write byte command. 
*			
*			used in interrupt service routine
*******************************************************************************/
static void RxParseWriteByte(void)
{
	if(sPMBusStruct.u8RxIdx == 2)		//without PEC
	{
		sPMBusStruct.nPMBusFlag.u16Bit.u1MapRxData = 1;
		SetPageVariable(&sPMBusStruct.pu8RxBuff[2], 1, 1);
	}
	else if(sPMBusStruct.u8RxIdx == 3)	//with PEC
	{
		sPMBusStruct.nPMBusFlag.u16Bit.u1MapRxData = 0;
		SetPageVariable(&sPMBusStruct.pu8RxBuff[2], 1, 0);
	}
}

/*******************************************************************************
*	brief 	Parse the write word command. 
*			
*			used in interrupt service routine
*******************************************************************************/
static void RxParseWriteWord(void)
{
//	sPMBusCmdWrStr_t* psTmpCmdStr;
//	u16_t u16TmpFlag;

	if(sPMBusStruct.u8Cmd == PMBusCmd_SMBAlertMask) 		//SMBAlert mask is different from other write word command
	{
		if(sPMBusStruct.u8RxIdx == 3)		//without PEC
		{
			sPMBusStruct.nPMBusFlag.u16Bit.u2CmdSupport = RxParseCmdSup(sPMBusStruct.pu8RxBuff[2], &sPMBusStruct.psCmd);
			
	 		if(sPMBusStruct.nPMBusFlag.u16Bit.u2CmdSupport == 3)						//support the status command
	 		{
				sPMBusStruct.nPMBusFlag.u16Bit.u1MapRxData = 1;
				SetPageVariable(&sPMBusStruct.pu8RxBuff[3], 1, 1);
			}
		}
		else if(sPMBusStruct.u8RxIdx == 4)	//with PEC
		{
			if(sPMBusStruct.nPMBusFlag.u16Bit.u1MapRxData == 1)
			{
				sPMBusStruct.nPMBusFlag.u16Bit.u1MapRxData = 0;
				SetPageVariable(&sPMBusStruct.pu8RxBuff[3], 1, 0);
			}
		}
	}
	else
	{
		if(sPMBusStruct.u8RxIdx == 3)		//without PEC
		{
			sPMBusStruct.nPMBusFlag.u16Bit.u1MapRxData = 1;
			SetPageVariable(&sPMBusStruct.pu8RxBuff[2], 2, 1);
		}
		else if(sPMBusStruct.u8RxIdx == 4)	//with PEC
		{
			sPMBusStruct.nPMBusFlag.u16Bit.u1MapRxData = 0;
			SetPageVariable(&sPMBusStruct.pu8RxBuff[2], 2, 0);
		}
	}
}

/*******************************************************************************
*	brief 	Parse the write block command. 
*			The index handling of Page_PlusWrite command is different from others
*			used in interrupt service routine
*******************************************************************************/
static void RxParseWriteBlock(void)
{
//	sPMBusCmdStatusStr_t* psTmpCmdStr;
//	u16_t u16TmpFlag;

	if(sPMBusStruct.nPMBusFlag.u16Bit.u1DataNotSup == 0)
	{
		if(sPMBusStruct.u8Cmd == PMBusCmd_PagePlusWr)	//page write is different from other block write
		{
			if(sPMBusStruct.u8RxIdx == 3)			//set the current page and page0 variable of sPMBusWrCmd
			{
				if((sPMBusStruct.pu8RxBuff[3] >= PMBus_MinPage) && (sPMBusStruct.pu8RxBuff[3] <= PMBus_MaxPage))
				{
					PMBus_CurrPage = sPMBusStruct.pu8RxBuff[3];
				}
				
				if(sPMBusWrCmd[0].u8Cmd == 0)		//page command support
				{
					*sPMBusWrCmd[0].pu8P0Buff = PMBus_CurrPage;
				}
			}
			else if(sPMBusStruct.u8RxIdx == 4)		//mapping the read buffer to the page_plus_write pointer and set the rx length
			{
				sPMBusStruct.nPMBusFlag.u16Bit.u2CmdSupport = RxParseCmdSup(sPMBusStruct.pu8RxBuff[4], &sPMBusStruct.psCmd);
				
				if(sPMBusStruct.nPMBusFlag.u16Bit.u2CmdSupport)						//command support
				{
					sPMBusStruct.u8RxByteCnt = sPMBusStruct.pu8RxBuff[2];
				}
                else
                {
                   UpdateStatusBit(PMBusCmd_StatusCML, 6, 1);
                }
				
				if(sPMBusStruct.u8RxByteCnt > (sPMBusStruct.psCmd->u8WrLength+2))		//the write byte count is larger than the variable buffer, not write to the buffer to avoid code crash
				{
					sPMBusStruct.nPMBusFlag.u16Bit.u1DataNotSup = 1;
					UpdateStatusBit(PMBusCmd_StatusCML, 6, 1);
//					UpdateStatusBit(PMBusCmd_StatusByte, 1, 1);
					if(sPMBusStruct.u16DataNotSupCnt < 0xffff)
					{
						sPMBusStruct.u16DataNotSupCnt++;
					}
				}
			}
			else
			{
				if(sPMBusStruct.u8RxByteCnt)
				{
					if(sPMBusStruct.u8RxIdx == (sPMBusStruct.u8RxByteCnt+2))			//finish block write without PEC
					{
						sPMBusStruct.nPMBusFlag.u16Bit.u1MapRxData = 1;
						SetPageVariable(&sPMBusStruct.pu8RxBuff[5], sPMBusStruct.u8RxByteCnt-2, 1);
					}
					else if(sPMBusStruct.u8RxIdx == (sPMBusStruct.u8RxByteCnt+3))			//finish block write with PEC
					{
						sPMBusStruct.nPMBusFlag.u16Bit.u1MapRxData = 0;
						SetPageVariable(&sPMBusStruct.pu8RxBuff[5], sPMBusStruct.u8RxByteCnt-2, 0);
					}
				}
			}
		}
		else
		{
			if(sPMBusStruct.u8RxIdx == 2)
			{
				sPMBusStruct.u8RxByteCnt = sPMBusStruct.pu8RxBuff[2];    
				
				if(sPMBusStruct.u8RxByteCnt > (sPMBusStruct.psCmd->u8WrLength-2))	//the write byte count is larger than the variable buffer, not write to the buffer to avoid code crash
				{
					sPMBusStruct.nPMBusFlag.u16Bit.u1DataNotSup = 1;
					UpdateStatusBit(PMBusCmd_StatusCML, 6, 1);
//					UpdateStatusBit(PMBusCmd_StatusByte, 1, 1);
					if(sPMBusStruct.u16DataNotSupCnt < 0xffff)
					{
						sPMBusStruct.u16DataNotSupCnt++;
					}
				}
			}
			else if(sPMBusStruct.u8RxIdx == (sPMBusStruct.u8RxByteCnt+2))			//finish block write without PEC
			{
				sPMBusStruct.nPMBusFlag.u16Bit.u1MapRxData = 1;
				SetPageVariable(&sPMBusStruct.pu8RxBuff[3], sPMBusStruct.u8RxByteCnt, 1);
			}
			else if(sPMBusStruct.u8RxIdx == (sPMBusStruct.u8RxByteCnt+3))			//finish block write with PEC
			{
				sPMBusStruct.nPMBusFlag.u16Bit.u1MapRxData = 0;
				SetPageVariable(&sPMBusStruct.pu8RxBuff[3], sPMBusStruct.u8RxByteCnt, 0);
			 
            }
		} 
	}
}

/*******************************************************************************
*	brief 	Stuff the query buffer for the Query command 
*			
*			used in interrupt service routine
*	para1: 	The buffer needs to be filled
*	para2:	The data structure of the command in the Query protocol
*******************************************************************************/
static void StuffQueryBuff(u8_t* pu8QBuff, sPMBusCmdStatusStr_t* psCmdStr)
{
	*pu8QBuff = (psCmdStr->u8DataType<<2) | 0x80;
	
	if(psCmdStr->u8CmdType < PMBusCmdT_ReadEnd)
	{
		*pu8QBuff |= 0x20;
	}
	else if(psCmdStr->u8CmdType < PMBusCmdT_WrEnd)
	{
		*pu8QBuff |= 0x40;
	}
	else if(psCmdStr->u8CmdType < PMBusCmdT_RdWrEnd)
	{
		*pu8QBuff |= 0x60;
	}
}

/*******************************************************************************
*	brief 	Parse the block write block read command. 
*			Four commands support supported of the PMBus protocol. Parse the 
*			commands respectively. The coefficiency command is not supported currently.
*			Need to add if support VID data format.
*			used in interrupt service routine
*******************************************************************************/
static void RxParseBWBR(void)
{
	sPMBusCmdStatusStr_t* psTmpCmdStr;
    u16_t u16QueryCmdSupport;
    u16_t u16PagePlusRdCmdSupport;
//  sPMBusStruct.nPMBusFlag.u16Bit.u2CmdSupport
//	u16_t u16TmpFlag;
//	s16_t i;
	
	if(sPMBusStruct.u8Cmd == PMBusCmd_PagePlusRd)
	{
		if(sPMBusStruct.u8RxIdx == 3)			//set the current page and page0 variable of sPMBusWrCmd
		{
			PMBus_CurrPage = sPMBusStruct.pu8RxBuff[3];
			
			if(sPMBusWrCmd[0].u8Cmd == 0)		//page command support
			{
				*sPMBusWrCmd[0].pu8P0Buff = PMBus_CurrPage;
			}
		}
		else if(sPMBusStruct.u8RxIdx == 4)		//mapping the read buffer to the page_plus_read pointer and set the tx length
		{
			u16PagePlusRdCmdSupport = RxParseCmdSup(sPMBusStruct.pu8RxBuff[4], &sPMBusStruct.psCmd);
			
			if(u16PagePlusRdCmdSupport)						//command support
			{
				sPMBusStruct.u8TxLength = sPMBusStruct.psCmd->u8RdLength + 1;		//block read needs additional byte count item
			}
			else
			{
                UpdateStatusBit(PMBusCmd_StatusCML, 6, 1);
				*sPMBusStruct.psCmd->pu8P0Buff = 0xff;		//byte count = 0
				*sPMBusStruct.psCmd->pu8P1Buff = 0xff;		//byte count = 0
				sPMBusStruct.u8TxLength = 3;			//byte count + PEC
			}
		}
	}
	else if(sPMBusStruct.u8Cmd == PMBusCmd_Query)
	{
		if(sPMBusStruct.u8RxIdx == 3)
		{
			u16QueryCmdSupport = RxParseCmdSup(sPMBusStruct.pu8RxBuff[3], &psTmpCmdStr);
			
			if(u16QueryCmdSupport)						// Query command support
			{
				if(PMBus_CurrPage == 0)
				{
					StuffQueryBuff(sPMBusStruct.psCmd->pu8P0Buff, psTmpCmdStr);
				}
				else if(PMBus_CurrPage == 1)
				{
					StuffQueryBuff(sPMBusStruct.psCmd->pu8P1Buff, psTmpCmdStr);
				}
				else
				{
					StuffQueryBuff(sPMBusStruct.psCmd->pu8P0Buff, psTmpCmdStr);
					StuffQueryBuff(sPMBusStruct.psCmd->pu8P1Buff, psTmpCmdStr);
				}
				
				sPMBusStruct.u8TxLength = 3;			//block read needs additional byte count item, fix at 4
			}
			else
			{
				*sPMBusStruct.psCmd->pu8P0Buff = 0x08;
				*sPMBusStruct.psCmd->pu8P1Buff = 0x08;
				sPMBusStruct.u8TxLength = 3;			//byte count(0) + PEC
			}
		}
	}
	else if(sPMBusStruct.u8Cmd == PMBusCmd_SMBAlertMask)
	{
		if(sPMBusStruct.u8RxIdx == 3)
		{
			sPMBusStruct.nPMBusFlag.u16Bit.u2CmdSupport = RxParseCmdSup(sPMBusStruct.pu8RxBuff[3], &sPMBusStruct.psCmd);

			if(sPMBusStruct.nPMBusFlag.u16Bit.u2CmdSupport)							//command support
			{
				sPMBusStruct.u8TxLength = sPMBusStruct.psCmd->u8RdLength + 1;		//block read needs additional byte count item
			}
			else
			{
				sPMBusStruct.u8TxLength = 2;			//byte count(0) + PEC
			} 
		}
	}
	else if(sPMBusStruct.u8Cmd == PMBusCmd_Coef)
	{
		//not support
	}

}

/*******************************************************************************
*	brief 	Check if the PMBus driver receives enough data for the application
*			and parse the raw data for the PMBus protocol
*			used in interrupt service routine
*******************************************************************************/
void PMBusRxParse(void)
{
	s16_t i;
	u8_t u8TempData;

	
	sPMBusStruct.u8RxIdx = GetSI2CRxIdx(sPMBusStruct.pu8RxBuff, PMBUSAPP_RX_BUFF);
	
	//if command is too fast before main loop to store the value, store the value in interrupt before next transaction begins.
	if(sPMBusStruct.u8CRCIdx > sPMBusStruct.u8RxIdx)
	{
		if(sPMBusStruct.nPMBusFlag.u16Bit.u1MapRxData)		
		{
			sPMBusStruct.nPMBusFlag.u16Bit.u1MapRxData = 0;	
			SetPageVariable(&u8TempData, 0, 0);		
		}
	}
	
	if(sPMBusStruct.u8RxIdx == 0xff)		//driver/app rx buffer overwrite
	{
		PMBusInit();
		ResetSI2CDrv();
	}
	else
	{
		if(sPMBusStruct.u8RxIdx == 0)		//something wrong
		{
			PMBusInit();
			ResetSI2CDrv();
			
			if(sPMBusStruct.u16RxParseErrCnt < 0xffff)
			{
				sPMBusStruct.u16RxParseErrCnt++;
			}
		}
		else if(sPMBusStruct.u8RxIdx == 1)	//check if the command support and mapping to the send data
		{
			//parse support command
			sPMBusStruct.nPMBusFlag.u16Bit.u2CmdSupport = RxParseCmdSup(sPMBusStruct.pu8RxBuff[sPMBusStruct.u8RxIdx], &sPMBusStruct.psCmd);
			
			//send byte parse without PEC
			if(sPMBusStruct.nPMBusFlag.u16Bit.u2CmdSupport)
			{
				sPMBusStruct.u8Cmd = sPMBusStruct.psCmd->u8Cmd;
				sPMBusStruct.u8CmdType = sPMBusStruct.psCmd->u8CmdType;
				
				if(sPMBusStruct.u8CmdType == PMBusCmdT_SendByte)
				{
					sPMBusStruct.nPMBusFlag.u16Bit.u1MapRxData = 1;
					u8TempData = 1;		//set clear fault variable 1 to indicate the command is set.
					SetPageVariable(&u8TempData, 1, 1);
				}
			}
            else
            {
               UpdateStatusBit(PMBusCmd_StatusCML, 7, 1);
            }
		}
		else
		{
			if(sPMBusStruct.nPMBusFlag.u16Bit.u2CmdSupport)
			{
				if((sPMBusStruct.u8CmdType == PMBusCmdT_WrByte) || (sPMBusStruct.u8CmdType == PMBusCmdT_RdWrByte))
				{
					RxParseWriteByte();
				}
				else if((sPMBusStruct.u8CmdType == PMBusCmdT_WrWord) || (sPMBusStruct.u8CmdType == PMBusCmdT_RdWrWord))
				{
					RxParseWriteWord();
				}
				else if((sPMBusStruct.u8CmdType == PMBusCmdT_WrBlock) || (sPMBusStruct.u8CmdType == PMBusCmdT_RdWrBlock))
				{
					RxParseWriteBlock();
				}
				else if(sPMBusStruct.u8CmdType == PMBusCmdT_BWBRRd_WordWr)		//used for SMBAlert_mask only
				{
					if((sPMBusStruct.pu8RxBuff[2] == 1)	|| (sPMBusStruct.pu8RxBuff[2] == 2))	//block write block read command
					{
						RxParseBWBR();	
					}
					else																//write word command
					{
						RxParseWriteWord();
					}
				}
				else if(sPMBusStruct.u8CmdType == PMBusCmdT_BWBRProcCall)
				{
					RxParseBWBR();
				}
				else if(sPMBusStruct.u8CmdType == PMBusCmdT_SendByte)			//send byte with PEC
				{
					RxParseSendByte();	
				}
                else
                {
                    UpdateStatusBit(PMBusCmd_StatusCML, 6, 1);
                }
			}
		}
	}
	
	//calculate rx CRC, slave address read not included
	if(sPMBusStruct.nPMBusFlag.u16Bit.u1MapRxData)			//means receive the last byte of write, not include the	PEC byte
	{
		sPMBusStruct.u8CRC8 = 0;
		for(i=0;i<=sPMBusStruct.u8RxIdx;i++)
		{
			CalCRC8(&sPMBusStruct.u8CRC8, sPMBusStruct.pu8RxBuff[i]);
		}
		
		sPMBusStruct.u8CRCIdx = sPMBusStruct.u8RxIdx;
	}
	
}

/*******************************************************************************
*	brief 	Check if the PMBus driver receives enough data for the application
*			and parse the raw data for the PMBus protocol.
*	note	Process call and receive command type not support...
*			used in interrupt service routine
*******************************************************************************/
void PMBusTxParse(void)
{
	s16_t i;
	
	if(sPMBusStruct.nPMBusFlag.u16Bit.u2CmdSupport == 0)		//command not support
	{
		sPMBusStruct.u8TxIdx = 1;
		sPMBusStruct.u8TxLength = 0;							

	}
	else
	{
		if((sPMBusStruct.u8CmdType <= PMBusCmdT_RdWord) || (sPMBusStruct.u8CmdType == PMBusCmdT_ProcCall) || 			//read byte/word/block, read-write command
		  ((sPMBusStruct.u8CmdType < PMBusCmdT_RdWrBlock) &&(sPMBusStruct.u8CmdType >= PMBusCmdT_RdWrByte)))		
		{
			sPMBusStruct.u8TxLength = sPMBusStruct.psCmd->u8RdLength;
			sPMBusStruct.u8TxIdx = sPMBusStruct.u8TxLength - 1;
			
			if(PMBus_CurrPage == 1)
			{
				FillTxBuff(sPMBusStruct.psCmd->pu8P1Buff, sPMBusStruct.pu8TxBuff, sPMBusStruct.u8TxLength-1);
			}
			else		//default page
			{
				FillTxBuff(sPMBusStruct.psCmd->pu8P0Buff, sPMBusStruct.pu8TxBuff, sPMBusStruct.u8TxLength-1);
			}
		}
		else if((sPMBusStruct.u8CmdType == PMBusCmdT_RdBlock) || (sPMBusStruct.u8CmdType == PMBusCmdT_RdWrBlock) ||	//block write block read command
               (sPMBusStruct.u8CmdType == PMBusCmdT_BWBRProcCall) || (sPMBusStruct.u8CmdType == PMBusCmdT_BWBRRd_WordWr))
		{

            if((sPMBusStruct.u8CmdType == PMBusCmdT_RdBlock) || (sPMBusStruct.u8CmdType == PMBusCmdT_RdWrBlock))
			{
				sPMBusStruct.u8TxLength = sPMBusStruct.psCmd->u8RdLength;
			}


			sPMBusStruct.u8TxIdx = sPMBusStruct.u8TxLength - 1;				
			sPMBusStruct.pu8TxBuff[0] = sPMBusStruct.u8TxLength - 2;

			if(PMBus_CurrPage == 1)
			{
				FillTxBuff(sPMBusStruct.psCmd->pu8P1Buff, sPMBusStruct.pu8TxBuff+1, sPMBusStruct.u8TxLength-2);
			}
			else
			{             
			    FillTxBuff(sPMBusStruct.psCmd->pu8P0Buff, sPMBusStruct.pu8TxBuff+1, sPMBusStruct.u8TxLength-2);
			}
		}
		else
		{
			sPMBusStruct.u8TxIdx = 1;
			sPMBusStruct.u8TxLength = 0;							//
		}
	}
	
	//CRC to tx buffer
	sPMBusStruct.u8CRC8 = 0;
	for(i=0;i<=sPMBusStruct.u8RxIdx;i++)
	{
		CalCRC8(&sPMBusStruct.u8CRC8, sPMBusStruct.pu8RxBuff[i]);
	}
	
	CalCRC8(&sPMBusStruct.u8CRC8, sPMBusStruct.pu8RxBuff[0]+1);		//read slave address
	
	for(i=0;i<sPMBusStruct.u8TxIdx;i++)
	{
		CalCRC8(&sPMBusStruct.u8CRC8, sPMBusStruct.pu8TxBuff[i]);
	}
	
	sPMBusStruct.pu8TxBuff[sPMBusStruct.u8TxIdx] = sPMBusStruct.u8CRC8;
		
	SI2CTxWrite(sPMBusStruct.pu8TxBuff, sPMBusStruct.u8TxLength);
}

/*******************************************************************************
*	brief 	update status bit for page plus write command and communication fault
*			
*	para1: 	the command needs to update
*	para2:	the bit of the variable corresponding to the command needs to update	
*	para3:	1: set, 0: clear
*******************************************************************************/
void UpdateStatusBit(u8_t u8Cmd, u8_t u8Bit, u8_t u8Set)
{
	s16_t i;
	u8_t* pu8Tmp;
	
	
	for(i=0;i<USER_PMBUS_STNUM;i++)
	{
		if(u8Cmd == sPMBusStatusCmd[i].u8Cmd)
		{
			if(PMBus_CurrPage == 0)
			{
				pu8Tmp = sPMBusStatusCmd[i].pu8P0Buff;
			}
			else if(PMBus_CurrPage == 1)
			{
				pu8Tmp = sPMBusStatusCmd[i].pu8P1Buff;
			}
            break;
		}
	}
	
	if(i < USER_PMBUS_STNUM)			//command support
	{
		if(u8Set)
		{
			*pu8Tmp |= (1<<u8Bit);
		}
		else
		{
			*pu8Tmp &= ~(1<<u8Bit);
		}
	}
}

/*******************************************************************************
*	brief 	update the value of STATUS_BYTE/STATUS_WORD
*	para1: 	none
*	para2:	none
*	para3:	none
*   note:   this function should be put under some time tick
*******************************************************************************/
void UpdateSTATUS_WORD(void)
{
	//-------------------------------------
	//update STATUS_BYTE/STATUS_WORD for page0
	//-------------------------------------
	if(u8StatusP0CML != 0) u16StatusP0Word |= 0x0002;
	else u16StatusP0Word &= (~0x0002);

	if(u8StatusP0Temp != 0) u16StatusP0Word |= 0x0004;
	else u16StatusP0Word &= (~0x0004);

	if((u8StatusP0Input & 0x10) != 0) 
     u16StatusP0Word |= 0x0008;
	else 
     u16StatusP0Word &= (~0x0008);

	if((u8StatusP0Iout & 0x80) != 0) u16StatusP0Word |= 0x0010;
	else u16StatusP0Word &= (~0x0010);

	if((u8StatusP0Vout & 0x80) != 0) u16StatusP0Word |= 0x0020;
	else u16StatusP0Word &= (~0x0020);
	//

	if(u8StatusP0Input != 0) u16StatusP0Word |= 0x2000;
	else u16StatusP0Word &= (~0x2000);

	if(u8StatusP0Iout != 0) u16StatusP0Word |= 0x4000;
	else u16StatusP0Word &= (~0x4000);

	if(u8StatusP0Vout != 0) u16StatusP0Word |= 0x8000;
	else u16StatusP0Word &= (~0x8000);

	//-------------------------------------
	//update STATUS_BYTE/STATUS_WORD for page1
	//-------------------------------------
	if(u8StatusP1CML != 0) u16StatusP1Word |= 0x0002;
	else u16StatusP1Word &= (~0x0002);

	if(u8StatusP1Temp != 0) u16StatusP1Word |= 0x0004;
	else u16StatusP1Word &= (~0x0004);

	if((u8StatusP1Input & 0x10) != 0) u16StatusP1Word |= 0x0008;
	else u16StatusP1Word &= (~0x0008);

	if((u8StatusP1Iout & 0x80) != 0) u16StatusP1Word |= 0x0010;
	else u16StatusP1Word &= (~0x0010);

	if((u8StatusP1Vout & 0x80) != 0) u16StatusP1Word |= 0x0020;
	else u16StatusP1Word &= (~0x0020);
	//

	if(u8StatusP1Input != 0) u16StatusP1Word |= 0x2000;
	else u16StatusP1Word &= (~0x2000);

	if(u8StatusP1Iout != 0) u16StatusP1Word |= 0x4000;
	else u16StatusP1Word &= (~0x4000);

	if(u8StatusP1Vout != 0) u16StatusP1Word |= 0x8000;
	else u16StatusP1Word &= (~0x8000);
}
/*******************************************************************************
* end of file
*******************************************************************************/

