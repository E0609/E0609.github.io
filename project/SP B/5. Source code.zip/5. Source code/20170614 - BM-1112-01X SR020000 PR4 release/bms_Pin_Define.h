#ifndef BMS_PIN__DEFINE_H__
#define BMS_PIN__DEFINE_H__


//*****************************************************//
//                          I/O                        //
//*****************************************************//

//-------------------Connect System signal-------------------
#define BBS_AC_GOOD       PORTDbits.RD8             // Pin42   System indicate AC is good(charge) or not(discharge)
#define d_BBS_AC_GOOD     TRISDbits.TRISD8          // Pin42

#define BBS_PS_KILL       PORTBbits.RB15            // Pin30   System enable BBU 
#define d_BBS_PS_KILL     TRISBbits.TRISB15         // Pin30

#define BBS_ON            PORTBbits.RB14            // Pin29   System choose BBU mode (on-line or off_line) 
#define d_BBS_ON          TRISBbits.TRISB14         // Pin29

#define BBS_A0            PORTBbits.RB12            // Pin27   BBU address A0
#define d_BBS_A0          TRISBbits.TRISB12         // Pin27

#define BBS_A1            PORTBbits.RB13            // Pin28   BBU address A1
#define d_BBS_A1          TRISBbits.TRISB13         // Pin28

#define BBS_A2            PORTFbits.RF3             // Pin33   BBU address A2
#define d_BBS_A2          TRISFbits.TRISF3          // Pin33 

#define BBS_A3            PORTGbits.RG7             // Pin5    BBU address A3
#define d_BBS_A3          TRISGbits.TRISG7          // Pin5  

#define BBS_A4            PORTGbits.RG8             // Pin6    BBU address A4
#define d_BBS_A4          TRISGbits.TRISG8          // Pin6

#define BBS_SDA           PORTFbits.RF4             // Pin31   I2C communication with system (slade)
#define d_BBS_SDA         TRISFbits.TRISF4          // Pin31

#define BBS_SCL 		  PORTFbits.RF5             // Pin32   I2C communication with system (slade)
#define d_BBS_SCL         TRISFbits.TRISF5          // Pin32

//-------------------Connect Discharger board----------------
#define DISCHG_EN1        LATDbits.LATD7            // Pin55   Enable BUCK modual 1
#define d_DISCHG_EN1      TRISDbits.TRISD7          // Pin55

#define DISCHG_EN2        LATDbits.LATD6            // Pin54   Enable BUCK modual 2
#define d_DISCHG_EN2      TRISDbits.TRISD6          // Pin54

#define ORFET_EN          LATFbits.LATF0            // Pin58   Enable ORingFET
#define d_ORFET_EN        TRISFbits.TRISF0          // Pin58

#define VREF              LATDbits.LATD1            // Pin49   PWM Discharger(BUCK) reference voltage
#define d_VREF            TRISDbits.TRISD1          // Pin49

#define ORING_STATUS      PORTGbits.RG9             // Pin8    ORING status
#define d_ORING_STATUS    TRISGbits.TRISG9          // Pin8
//-------------------Connect Charger board-------------------
#define CHG_CONTROL       LATDbits.LATD0            // Pin46   PWM  Charge constant current Vref
#define d_CHG_CONTROL     TRISDbits.TRISD0          // Pin46

#define CHG_EN            LATCbits.LATC14           // Pin48   Enable Charger(BOOST)
#define d_CHG_EN          TRISCbits.TRISC14         // Pin48

#define CHG_MOS_IN        LATEbits.LATE1            // Pin61   Turn on the MOSFET whitch between BUS and charger
#define d_CHG_MOS_IN      TRISEbits.TRISE1          // Pin61

#define CHG_MOS_OUT       LATCbits.LATC13           // Pin47   Turn on the MOSFET whitch between charger and Battery
#define d_CHG_MOS_OUT     TRISCbits.TRISC13         // Pin47

#define CHG_V_ref         LATDbits.LATD4            // Pin52   PWM Vref
#define d_CHG_V_ref       TRISDbits.TRISD4          // Pin52

//-------------------Connect BMS-----------------------------
#define SYS_PRES          LATFbits.LATF2            // Pin34   Wake up BMS escape ship mode
#define d_SYS_PRES        TRISFbits.TRISF2          // Pin34

#define ICELL_TOTAL       PORTFbits.RF6             // Pin35   Indicate Battery short protect
#define d_ICELL_TOTAL     TRISFbits.TRISF6          // Pin35

#define BMS_SDA           PORTGbits.RG3             // Pin36   I2C communication with BMS (master)
#define d_BMS_SDA         TRISGbits.TRISG3          // Pin36

#define BMS_SCL           PORTGbits.RG2             // Pin37   I2C communication with BMS (master)
#define d_BMS_SCL         TRISGbits.TRISG2          // Pin37

//-------------------Current sharing-------------------------
#define TRIM_CS           LATDbits.LATD2            // Pin50   PWM factory
#define d_TRIM_CS         TRISDbits.TRISD2          // Pin50

#define SHUTDOWN          LATFbits.LATF1            // Pin59   Shutdown the BUCK
#define d_SHUTDOWN        TRISFbits.TRISF1          // Pin59

#define VOUT_HIGH         LATEbits.LATE0            // Pin60   When System choose on-line mode parallel the R
#define d_VOUT_HIGH       TRISEbits.TRISE0          // Pin60

#define CS_EN             LATEbits.LATE2            // Pin62   Enable current sharing
#define d_CS_EN           TRISEbits.TRISE2          // Pin62

//------------------A/D converter----------------------------
#define BBU_TEMP          PORTBbits.RB5             // Pin11(AN5) BBU ambient temperature
#define d_BBU_TEMP        TRISBbits.TRISB5          // Pin11

#define VOUT_12V          PORTBbits.RB4             // Pin12(AN4) Sense the volatge before ORingFET
#define d_VOUT_12V        TRISBbits.TRISB4          // Pin12

#define IOUT_DET          PORTBbits.RB3             // Pin13(AN3) BBU out current detection
#define d_IOUT_DET        TRISBbits.TRISB3          // Pin13

#define VOUT_BUS          PORTBbits.RB2             // Pin14(AN2) Sense the BUS voltage
#define d_VOUT_BUS        TRISBbits.TRISB2          // Pin14

#define BUCK_TEMP1        PORTBbits.RB6             // Pin17(AN6) BUCK Modual 1 temperature
#define d_BUCK_TEMP1      TRISBbits.TRISB6          // Pin17

#define BUCK_TEMP2        PORTBbits.RB7             // Pin18(AN7) BUCK Modual 2 temperature
#define d_BUCK_TEMP2      TRISBbits.TRISB7          // Pin18

#define VIN_CHG           PORTBbits.RB8             // Pin21(AN8) BUCK Modual 3 temperature
#define d_VIN_CHG         TRISBbits.TRISB8          // Pin21

#define BOOST_TEMP        PORTBbits.RB9             // Pin22(AN9) BOOST temperature
#define d_BOOST_TEMP      TRISBbits.TRISB9          // Pin22


//-------------------protect------------------------
#define POWER_FAULT       PORTDbits.RD11            // Pin45 Indicate charger or dischager have protection
#define d_POWER_FAULT     TRISDbits.TRISD11         // Pin45

//------------------- Test Pin ---------------------
#define TEST1             LATEbits.LATE5            // Pin1 For Test
#define d_TEST1           TRISEbits.TRISE5          // Pin1

//#define TEST2             LATEbits.LATE6            // Pin2 For Test
//#define d_TEST2           TRISEbits.TRISE6          // Pin2

#define TEST3             LATEbits.LATE7            // Pin3 For Test
#define d_TEST3           TRISEbits.TRISE7          // Pin3

#define TEST4             LATGbits.LATG6            // Pin4 For test
#define d_TEST4           TRISGbits.TRISG6          // Pin4


//****************************************************//
//                   event flag                       //
//****************************************************//

enum
{
    AD_VOUT_BUS = 2,
    AD_IOUT_DET,
    AD_VOUT_12V,
    AD_BBU_TEMP,
    AD_BUCK1_TEMP,
    AD_BUCK2_TEMP,
    AD_VIN_CHG,
    AD_BOOST_TEMP,
};


typedef union 
{
   struct
     {
       unsigned  Event_INTR0:1;
       unsigned  Event_INTR1:1;
       unsigned  Event_INTR2:1;
       unsigned  Event_INTR3:1;
       unsigned  Event_INTR4:1;
       unsigned  Event_INTR5:1;
       unsigned  Event_INTR6:1;
       unsigned  Event_INTR7:1;
       unsigned  Event_INTR8:1;
       unsigned  Event_INTR9:1;
       unsigned  Event_INTRA:1;
       unsigned  Event_INTRB:1;
       unsigned  Event_INTRC:1;     
       unsigned  Event_INTRD:1;
       unsigned  Event_INTRE:1;
       unsigned  Event_INTRF:1;
	 }bits;  
}Flag_t;

typedef union
{
   struct
     {
       unsigned  AC_GOOD:1;           			// AC_GOOD INTR
//       unsigned  Flag_Charge:1;       			// Indicate at Charge mode status
//       unsigned  Flag_Discharge:1;    			// Indicate at Discharge mode status
       unsigned  Flag_Failure:1;      			// Indicate at Failure mode
       unsigned  Flag_Failclear:1;    			// Indicate Failure clear back to Idle mode
       unsigned  Flag_Online_Mode:1;  			// Indicate BBU at Online mode
       unsigned  Flag_Offline_Mode:1; 			// Indicate BBU at Offline mode
       unsigned  Flag_Idle_Mode:1;              // Indicate BBU at Idle mode
       unsigned  Flag_Online_Charge:1;			// Indicate BBU at Online mode sub state at Charge mode
       unsigned  Flag_Online_Discharge:1;       // Indicate BBU at Online mode sub state at Discharge mode
       unsigned  Flag_Offline_Charge:1;         // Indicate BBU at Offline mode sub state at Charge mode
       unsigned  Flag_Offline_Discharge:1;      // Indicate BBU at Offline mode sub state at Discharge mode 
       unsigned  Flag_Charge_to_Discharge:1;    // Indicate BBU Change Charge mode to Discharge mode
       unsigned  Flag_Discharge_to_Charge:1;    // Indicate BBU Change Dischrge mode to Charge mode
       unsigned  Flag_PS_KILL_Debounce:1;       // Indicate BBS_PS_KILL signal debounce ready
       unsigned  Flag_BBS_ON_Debounce:1;        // Indicate BBS_ON signal debounce ready
       unsigned  Flag_Not_Reset_Failure:1;
       unsigned  Flag_PMBus_loss:1;             // Indicate PMBus loss communication 30 sec need go to online mode      

     }bits;
}SystemControl_t;

typedef enum
{
  BBU_state_Idle_mode,
  BBU_state_Online_mode,
  BBU_state_Offline_mode,
  BBU_state_Failure_mode
  

}eBBU_STATE_t;

extern Flag_t  Flag;
extern SystemControl_t  SystemControl;

#endif
