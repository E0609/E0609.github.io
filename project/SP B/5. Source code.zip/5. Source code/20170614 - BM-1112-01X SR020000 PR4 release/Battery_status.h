#ifndef __Battery_status_H__
#define __Battery_status_H__

#include <p24FJ64GA006.h>
#include "bms_Pin_Define.h"
#include "GenericTypeDefs.h"
#include "I2C.h"
#include "main.h"
#include "Discharge_control.h"
#include "Charge_control.h"
#include "Failure.h"

void Battery_diagnostic(void);
void Battery_MOS_control(void);
void Read_Battery_data(void);
void battery_mos_control(void);
void Battery_status(void);
void Status_BBU_update(void);
extern void Battery_SelfDetect(void);

extern u8_t Battery_Current_Read_Flag;
extern u8_t Read_Battery_Process_Flag;
extern u8_t RSOC_update_Flag;
extern u8_t Remaining_Capacity_update_Flag;

#define Battery_Address                           0x16          //1.1kw battery address
#define ReadBattery_ManufacturerAccess            0x00
#define ReadBattery_AtRate                        0x04          // unit 8mA
#define ReadBattery_AtRateTimeToEmpty             0x06          // unit sec
#define ReadBattery_AtRateOk                      0x07          // unit Bool
#define ReadBattery_Temperature                   0x08          // unit 0.1C
#define ReadBattery_Voltage                       0x09          // unit 2mV
#define ReadBattery_Current                       0x0A          // unit 8mA
#define ReadBattery_RelativeStateOfCharge         0x0D          // unit %
#define ReadBattery_AbsoluteStateOfCharge         0x0E          // unit %  
#define ReadBattery_RemainingCapacity             0x0F          // unit mAh 
#define ReadBattery_FullChargeCapacity            0x10          // unit mAh
#define ReadBattery_ChargingCurrent               0x14          // unit 8mA
#define ReadBattery_ChargingVoltage               0x15          // unit 2mV
#define ReadBattery_BatteryStatus                 0x16          // unit bits field
#define ReadBattery_CycleCount                    0x17          
#define ReadBattery_DesignCapacity                0x18          // unit mAh
#define ReadBattery_DesignVoltage                 0x19          // unit 2mV
#define ReadBattery_ManufactureDate               0x1B
#define ReadBattery_SerialNumber                  0x1C
#define ReadBattery_ManufactureName               0x20
#define ReadBattery_DeviceName                    0x21
#define ReadBattery_ManufactureData               0x23
#define ReadBattery_MoreData                      0x28          // have 40byte
#define ReadBattery_Thermistor3                   0x39          // unit 0.1C
#define ReadBattery_Thermistor2                   0x3A          // unit 0.1C
#define ReadBattery_Thermistor1                   0x3B          // unit 0.1C
#define ReadBattery_Cell1Voltage                  0x3C          // unit mV
#define ReadBattery_Cell2Voltage                  0x3D          // unit mV
#define ReadBattery_Cell3Voltage                  0x3E          // unit mV
#define ReadBattery_Cell4Voltage                  0x3F          // unit mV
#define ReadBattery_Cell5Voltage                  0x40          // unit mV
#define ReadBattery_Cell6Voltage                  0x41          // unit mV
#define ReadBattery_Cell7Voltage                  0x42          // unit mV
#define ReadBattery_Cell8Voltage                  0x43          // unit mV
#define ReadBattery_Cell9Voltage				  0x44          // unit mV
#define ReadBattery_Cell10Voltage				  0x45          // unit mV
#define ReadBattery_Cell11Voltage				  0x46          // unit mV
#define ReadBattery_Cell12Voltage				  0x47          // unit mV
#define ReadBattery_Cell13Voltage				  0x48          // unit mV

#define ReadBattery_MaxCellVoltageHistory         0xB0
#define ReadBattery_MinCellVoltageHistory         0xB1
#define ReadBattery_MaxChargeCurrentHistory       0xB2
#define ReadBattery_MaxDischargeCurrentHistory    0xB3
#define ReadBattery_MaxTemperatureHistory         0xB4
#define ReadBattery_MinTemperatureHistory         0xB5
#define ReadBattery_12Vloss                       0xB7

#define ReadBattery_FirmwareVersion               0xF0

#define ReadBattery_ProtectionStatus              0x51
#define ReadBattery_PFStatus                      0x53
#define Battery_LED_Status                        0x54 
#define ReadBattery_StateOfHealth                 0x55
#define ReadBattery_DischargeTime                 0x56
#define ReadBattery_CellManufacturer              0x58
#define ReadBattery_CellModel                     0x59
#define ReadBattery_CellDate                      0x5A   

//--------------- BBU LED Display -----------------------
#define Battery_LED_data_high                     0x00
#define Battery_LED_off_data_low                  0x88
#define Battery_LED_Solid_Green_data_low          0x89
#define Battery_LED_Blink_Green_data_low          0x8A
#define Battery_LED_Solid_Amber_data_low          0x99
#define Battery_LED_Blink_Amber_data_low          0xAA
#define Battery_LED_Solid_Red_data_low            0x98
#define Battery_LED_Blink_Red_data_low            0xA8
#define Battery_LED_Capacity_Test_High            0x20
#define Battery_LED_Capacity_Test_Low             0x88

//---------------- Learning ----------------
#define Battery_Learning_High                     0xAC
#define Battery_Learning_Low_Enable               0x01
#define Battery_Learning_Low_Disable              0x00   
 
//---------------- Battery Status ------------------------
typedef union
{
  u16_t Val;
   struct
   {
      u8_t Reserved                           :4;
      u8_t Fully_Discharged       			  :1;
      u8_t Fully_Charged         			  :1;
      u8_t Discharging           			  :1;
      u8_t Initialized           			  :1;
      u8_t Aging_Comparison_Done              :1;
      u8_t Aging_Comparison_Ready             :1;
      u8_t Aging_Comparison_Request           :1;
      u8_t Terminate_Discharge_Alarm          :1;
      u8_t Charge_Over_Temp_Alarm             :1;
      u8_t Discharge_Over_Temp_Alarm          :1;
      u8_t Terminate_Charge_Alarm             :1;
      u8_t Over_Charge_Alarm                  :1;
         
   }bits;
}Battery_Status_T;

//--------------- Protection Status ----------------
typedef union
{
  u16_t Val;
   struct
   {
      u8_t  HLOCK            :1;     // 1 = Hardware is locked
      u8_t  SLOCK            :1;     // 1 = Software is locked
      u8_t  DFET             :1;     // 1 = DFET is ON
      u8_t  CFET             :1;     // 1 = CFET is ON
      u8_t  PF               :1;     // 1 = Battery is in permanent failure protection
      u8_t  DOTP             :1;     // 1 = During Discharging over temperature protection
      u8_t  COTP             :1;     // 1 = During Charging over temperature protection
      u8_t  SCOTP            :1;     // 1 = Start charge over temperature protection
      u8_t  COC              :1;     // 1 = Software over charge current protection
      u8_t  DOC              :1;     // 1 = Software over discharge current protection
      u8_t  OCCP             :1;     // 1 = Hardware over charge current protection 
      u8_t  ODSCP            :1;     // 1 = Hardware over discharge current od short circuit protection
      u8_t  Reserved         :1;
      u8_t  SLPEN            :1;     // 1 = Sleep mode is enable
      u8_t  UVP              :1;     // 1 = UVP Protection 
      u8_t  FOVP             :1;     // 1 = 1st level OVP protection

   }bits; 
}Protection_Status_T;

//----------------- PF Status --------------
typedef union
{
   u16_t Val;
    struct
    { 
       u8_t  CUF             :1;      // 1 = Cu. Deposition failure
       u8_t  CFETF           :1;      // 1 = CFET failure
       u8_t  Reserved        :2;       
       u8_t  CIMF            :1;      // 1 = Cell Imbalance failure
       u8_t  Reserved_1      :3;
       u8_t  DFETF           :1;      // 1 = DFET failure
       u8_t  DFF             :1;      // 1 = Data flash verify error failure
       u8_t  SOVF            :1;      // 1 = 2nd level OVP failure
       u8_t  COTPF           :1;      // 1 = 2nd level Cell OTP failure
       u8_t  Reserved_2      :1;  
       u8_t  PFIN            :1;      // 1 = Detect 2nd OVP IC active
       u8_t  CO_H            :1;      // 1 = Detect 2nd OVP IC output is high and cell voltage is normal
       u8_t  Reserved_3      :1;    
    }bits;
}PF_Status_T;


typedef struct
{
	s16_t Temp;
    u16_t Voltage;
	s32_t Current;
    u16_t RSOC;
    u16_t ASOC;
	u16_t RemainingCapacity;
    u16_t FullChargeCapacity;
    u16_t CycleCount;
	u16_t DesignCapacity;
    u16_t DesignVoltage;
    u16_t SerialNumber;
    u16_t Cell1Voltage;
    u16_t Cell2Voltage;
    u16_t Cell3Voltage;
    u16_t Cell4Voltage;
    u16_t Cell5Voltage;
	u16_t Cell6Voltage;
	u16_t Cell7Voltage;
	u16_t Cell8Voltage;
	u16_t Cell9Voltage;
	u16_t Cell10Voltage;
    u16_t Cell11Voltage;
	u16_t Cell12Voltage;
    u16_t Cell13Voltage;
	u16_t CellMinVoltageHis;
    u8_t  Temp_C;
	PF_Status_T PermanentFailureStatus;
	Battery_Status_T BatteryStatus;
	Protection_Status_T ProtectionStatus;
    u16_t LED_Status_Red;
    u16_t LED_Status_Green;
    u16_t LED_Status_Amber;
    u16_t FWRev;
    u16_t Voltage_Loss;
    u16_t SOH;
    s32_t Discharge_Remain_Time;

//	unsigned int minCellVoltage;
//	unsigned char RetryTimes;
	

}Cell_Info_T;

extern Cell_Info_T Cell_Info;
extern Battery_Status_T Battery_Status;


#endif
