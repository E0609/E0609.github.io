/*******************************************************************************
* file				SI2CMiddle.h
* brief				The file is the header file of slave I2C middle function.
* note
* author			vincent.liu
* version			01
* section History	2016/03/ - 1st release
*******************************************************************************/
#ifndef SI2CMIDDLE_H
#define	SI2CMIDDLE_H

#include "GenericTypeDefs.h"
/*******************************************************************************
* declare compile condition
*******************************************************************************/
#define QUANTA_BOOTLOADER			0x01										// 0x00:old, 0x01:new, 0xff:no support
#define SM_RXBUFF_LEN				40											// 40 bytes
/*******************************************************************************
* declare compile structure
*******************************************************************************/
//=====================================
//enum of the communication protocol
//=====================================
typedef enum
{
	Protocol_None,
	Protocol_PMBus,
	Protocol_QuantaBootloader,
}eSI2CCommProtocol_t;
//=====================================
//structure of uart middle application
//=====================================
typedef struct
{
	u8_t u8Protocol;
	u8_t u8RxIdx;
	u8_t pu8RxBuff[SM_RXBUFF_LEN];
}sSI2CMiddleStr_t;
/*******************************************************************************
* declare extern function
*******************************************************************************/
extern void SI2CMiddleInit(void);
extern void SI2CMiddleRxProcess(void);
extern void SI2CMiddleTxProcess(void);
extern void SI2CMiddleMapRxData(void);
/*******************************************************************************
* end of file
*******************************************************************************/

#endif
