/*******************************************************************************
* file				FlashDriver.c
* brief				The file includes the function of flash operation.
*					Include erase/read/write flash.
* note
* author			vincent.liu
* version			01
* section History	2014/10/22 - 1st release
*******************************************************************************/
#include "FlashDriver.h"
#include <p24FJ64GA006.h> 
/*******************************************************************************
*   brief: 	Enable write/erase operation sequence
*	para1:	write/erase operation code
* 	para2:	none
*******************************************************************************/
void WriteNVMCON(u16_t u16Cmd)
{
	NVMCON = u16Cmd;			// set write/erase operation code
	asm("DISI #5");				// disable interrupt 5 cycles
	__builtin_write_NVM();		// enable write/erase sequence
	while(NVMCONbits.WR == 1);	// wait for write/erase operation finished
}
/*******************************************************************************
*   brief: 	Erase flash latch in page mode
*	para1:	flash address in the page which will be erased
* 	para2:	none
*******************************************************************************/
void EraseFlashPage(u32_t u32StartAddr)
{
	u16_t u16AddrLow;

	TBLPAG = (u32StartAddr & 0x00ff0000) >> 16;
	u16AddrLow = u32StartAddr & 0x0000ffff;

	__builtin_tblwtl(u16AddrLow, 0xffff);

	WriteNVMCON(ERASE_PAGE_CMD);
}
/*******************************************************************************
*   brief: 	Write ram data to flash,
*           one instruction has two bytes data.
*	para1:	flash start address
* 	para2:	pointer to data buffer, data type is char
*	para3:	data length, length is calculated by "byte", should be even number
*******************************************************************************/
void WriteRam2Flash(u32_t u32StartAddr, u8_t* pu8Buff, u16_t u16Length)
{
	u16_t i;
	u16_t u16AddrLow;
	u16_t u16DataLow, u16DataHigh;

	TBLPAG = (u32StartAddr & 0x00ff0000) >> 16;
	u16AddrLow = u32StartAddr & 0x0000ffff;

	for(i = 0;i < (u16Length >> 1);i++)
	{
		u16DataLow = *pu8Buff + (*(pu8Buff + 1) << 8);
		u16DataHigh = 0x0000;
		pu8Buff += 2;

		__builtin_tblwtl(u16AddrLow, u16DataLow);
		__builtin_tblwth(u16AddrLow, u16DataHigh);
		WriteNVMCON(WRITE_WORD_CMD);

		u16AddrLow += 2;
	}
}
/*******************************************************************************
*   brief: 	Write flash latch in one instruction(word) mode,
*           one instruction has four bytes data.
*	para1:	flash start address
* 	para2:	pointer to data buffer, data type is char
*   para3:	data length, length is calculated by "byte", should be the "4" miltiple
*******************************************************************************/
void WriteFlashIns(u32_t u32StartAddr, u8_t* pu8Buff, u16_t u16Length)
{
	u16_t i;
	u16_t u16AddrLow;
	u16_t u16DataLow, u16DataHigh;

	TBLPAG = (u32StartAddr & 0x00ff0000) >> 16;
	u16AddrLow = u32StartAddr & 0x0000ffff;

	for(i = 0;i < (u16Length >> 2);i++)
	{
		u16DataLow = *pu8Buff + (*(pu8Buff + 1) << 8);
		u16DataHigh = *(pu8Buff + 2)+ (*(pu8Buff + 3) << 8);
		pu8Buff += 4;

		__builtin_tblwtl(u16AddrLow, u16DataLow);
		__builtin_tblwth(u16AddrLow, u16DataHigh);
		WriteNVMCON(WRITE_WORD_CMD);
		
		u16AddrLow += 2;
	}
}
/*******************************************************************************
*   brief: 	Write flash latch in row mode
*	para1:	flash start address
* 	para2:	pointer to data buffer
*******************************************************************************/
void WriteFlashRow(u32_t u32StartAddr, u8_t* pu8Buff)
{
	u16_t i;
	u16_t u16AddrLow;
	u16_t u16DataLow, u16DataHigh;

	TBLPAG = (u32StartAddr & 0x00ff0000) >> 16;
	u16AddrLow = u32StartAddr & 0x0000ffff;

	for(i = 0;i < (WRITE_ROW_SIZE >> 1);i++)
	{
		u16DataLow = *(pu8Buff+0) + (*(pu8Buff+1) << 8);
		u16DataHigh = *(pu8Buff+2) + (*(pu8Buff+3) << 8);
		pu8Buff += 4;
		__builtin_tblwtl(u16AddrLow, u16DataLow);
		__builtin_tblwth(u16AddrLow, u16DataHigh);
		u16AddrLow += 2;
	}
	
	WriteNVMCON(WRITE_ROW_CMD);
}
/*******************************************************************************
*   brief: 	Read flash data to ram,
*           one instruction has two bytes data.
*	para1:	flash start address
* 	para2:	pointer to data buffer, data type is char
*	para3:	data length, length is calculated by "byte", should be even number
*******************************************************************************/
void ReadFlash2Ram(u32_t u32StartAddr, u8_t* pu8Buff, u16_t u16Length)
{
	u16_t i;
	u16_t u16AddrLow, u16DummyData;

	TBLPAG = (u32StartAddr & 0x00ff0000) >> 16;
	u16AddrLow = u32StartAddr & 0x0000ffff;

	for(i = 0;i < (u16Length >> 1);i++)
	{
		u16DummyData = __builtin_tblrdl(u16AddrLow);
		*pu8Buff++ = u16DummyData & 0x00ff;
		*pu8Buff++ = u16DummyData >> 8;
		u16AddrLow += 2;
	}
}
/*******************************************************************************
*   brief: 	Read flash instruction data to ram,
*           one instruction has four bytes data.
*	para1:	flash start address
* 	para2:	pointer to data buffer, data type is char
*	para3:	data length, length is calculated by "byte", should be the "4" miltiple
*******************************************************************************/
void ReadFlashIns(u32_t u32StartAddr, u8_t* pu8Buff, u16_t u16Length)
{
	u16_t i;
	u16_t u16AddrLow, u16DummyData;

	TBLPAG = (u32StartAddr & 0x00ff0000) >> 16;
	u16AddrLow = u32StartAddr & 0x0000ffff;

	for(i = 0;i < (u16Length >> 2);i++)
	{
		u16DummyData = __builtin_tblrdl(u16AddrLow);
		*pu8Buff++ = u16DummyData & 0x00ff;
		*pu8Buff++ = u16DummyData >> 8;
		u16DummyData = __builtin_tblrdh(u16AddrLow);
		*pu8Buff++ = u16DummyData & 0x00ff;
		*pu8Buff++ = u16DummyData >> 8;
		
		u16AddrLow += 2;
	}
}
/*******************************************************************************
*   brief: 	Verify a instruction flash
*	para1:	flash start address
* 	para2:	pointer to data buffer
*	para3:	data length, length is calculated by "byte", should be the "4" miltiple
*   return: 0:success, 1:error
*******************************************************************************/
u8_t VerifyFlashIns(u32_t u32StartAddr, u8_t* pu8Buff, u16_t u16Length)
{
	u16_t i;
	u16_t u16AddrLow;
	u16_t u16DataLow, u16DataHigh;

	TBLPAG = (u32StartAddr & 0x00ff0000) >> 16;
	u16AddrLow = u32StartAddr & 0x0000ffff;

	for(i = 0;i < (u16Length >> 2);i++)
	{
		u16DataLow = __builtin_tblrdl(u16AddrLow);
		u16DataHigh = __builtin_tblrdh(u16AddrLow);

		if(*(pu8Buff + 0) != (u16DataLow & 0xff)) return 1;
		if(*(pu8Buff + 1) != (u16DataLow >> 8)) return 1;
		if(*(pu8Buff + 2) != (u16DataHigh & 0xff)) return 1;
		//if(*(pu8Buff + 3) != (u16DataHigh >> 8)) return 1;
		
		pu8Buff += 4;
		u16AddrLow += 2;
	}

	return 0;
}
/*******************************************************************************
*   brief: 	Verify a row flash
*	para1:	flash start address
* 	para2:	pointer to data buffer
*   return: 0:success, 1:error
*******************************************************************************/
u8_t VerifyFlashRow(u32_t u32StartAddr, u8_t* pu8Buff)
{
	u16_t i;
	u16_t u16AddrLow;
	u16_t u16DataLow, u16DataHigh;

	TBLPAG = (u32StartAddr & 0x00ff0000) >> 16;
	u16AddrLow = u32StartAddr & 0x0000ffff;

	for(i = 0;i < (WRITE_ROW_SIZE >> 1);i++)
	{
		u16DataLow = __builtin_tblrdl(u16AddrLow);
		u16DataHigh = __builtin_tblrdh(u16AddrLow);

		if(*(pu8Buff + 0) != (u16DataLow & 0xff)) return 1;
		if(*(pu8Buff + 1) != (u16DataLow >> 8)) return 1;
		if(*(pu8Buff + 2) != (u16DataHigh & 0xff)) return 1;
		//if(*(pu8Buff + 3) != (u16DataHigh >> 8)) return 1;

		pu8Buff += 4;
		u16AddrLow += 2;
	}

	return 0;
}
/*******************************************************************************
* end of file
*******************************************************************************/
