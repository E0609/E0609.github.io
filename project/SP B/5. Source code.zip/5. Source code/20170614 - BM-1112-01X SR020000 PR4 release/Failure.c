#include <p24FJ64GA006.h>
#include "bms_Pin_Define.h"
#include "GenericTypeDefs.h"
#include "I2C.h"
#include "Battery_status.h"
#include "Charge_control.h"
#include "Discharge_control.h"
#include "Failure.h"
#include "FW_Config.h"
#include "main.h"
#include "PMBusData.h"
#include "PMBus_status.h"
#include <string.h>
#include "Battery_status.h"
#include "EEPROM.h"

void Clear_Charger_Fault_Delay(void);
void Clear_Charger_Warning_Delay(void);
void Clear_Status_Bit(void);
void Clear_Warning_Status_Bit(void);
void Clear_Discharger_Fault_Delay(void);
void Clear_Discharger_Warning_Delay(void);
void PMBus_Clear_Fault(void);

u32_t LastProtect_type[4];
u32_t LastProtect_type1[4];
u32_t LastProtect_type2[4];
u32_t LastProtect_type3[4];
u8_t  AmbientOT_Delay_Flag = 0;
u16_t AmbientOT_Delay_Cnt = 0;


void Failure_detect(void)
{

    if(BBU_Info.Ambient_Temp > Expect_Ambient_OT_Warning)
    {
       if(SystemControl.bits.Flag_Idle_Mode == 1)
       {
         Warning_type.bits.Ambient_OT_Warning = 1;
         u8StatusP0Temp = (u8StatusP0Temp | Status_Temperature_bits_OT_Warning);
         u8StatusP1Temp = (u8StatusP1Temp | Status_Temperature_bits_OT_Warning); 
         u16StatusP0Word = (u16StatusP0Word | Status_Word_bits_Temperature);
         u16StatusP1Word = (u16StatusP1Word | Status_Word_bits_Temperature);
       }
    }
    else if(BBU_Info.Ambient_Temp < Ambient_OT_Recover_Threshold)
    {
       Warning_type.bits.Ambient_OT_Warning = 0;
       Failure_type.bits.Ambient_OTP = 0;  
       AmbientOT_Delay_Flag = 0;
       AmbientOT_Delay_Cnt = 0;            
    }

    if(BBU_Info.Ambient_Temp > Expect_Ambient_OT_Protection)
    {
      if(SystemControl.bits.Flag_Idle_Mode == 1)
      {
        AmbientOT_Delay_Flag = 1;
        if(AmbientOT_Delay_Cnt >= 99)
        {
         Failure_type.bits.Ambient_OTP = 1;
         u8StatusP0Temp = (u8StatusP0Temp | Status_Temperature_bits_OT_Fault);
         u8StatusP1Temp = (u8StatusP1Temp | Status_Temperature_bits_OT_Fault);
        }
      }
              
    }
    

}




void Failure_Control(void)
{
  
}

void PMBus_Clear_Fault(void)
{
  memset(&Warning_type, 0, sizeof(Warning_type)); 
  Clear_Charger_Warning_Delay();
  Clear_Discharger_Warning_Delay();
  Clear_Warning_Status_Bit();
}

void Clear_Failure(void)
{
  memset(&Failure_type, 0, sizeof(Failure_type));
  memset(&Warning_type, 0, sizeof(Warning_type));
  SystemControl.bits.Flag_Failure = 0;
  I2C_State.Communication_Fail_Count = 0;
  EEPROM_Failure_count = 0;
  Clear_Charger_Fault_Delay();
  Clear_Charger_Warning_Delay();
  Clear_Status_Bit();
  Clear_Discharger_Fault_Delay();
  Clear_Discharger_Warning_Delay();
  Discharger.UVP_Delay_Cnt = 0;
  Discharger_12V_Flag = 0;
  AmbientOT_Delay_Flag = 0;
  AmbientOT_Delay_Cnt = 0;
  SHUTDOWN = 0;

}

void Clear_Charger_Fault_Delay(void)
{
  Charger_Delay.UV_Fault_Flag = 0;
  Charger_Delay.UV_Fault_Cnt = 0;
  Charger_Delay.OV_Fault_Flag = 0;
  Charger_Delay.OV_Fault_Cnt = 0;
  Charger_Delay.Cell_OT_Fault_Flag = 0;
  Charger_Delay.Cell_OT_Fault_Cnt = 0;
  Charger_Delay.OC_Fault_Flag = 0;
  Charger_Delay.OC_Fault_Cnt = 0;
  Charger_Delay.Boost_OT_Fault_Flag = 0;
  Charger_Delay.Boost_OT_Fault_Cnt = 0;
  Charger_Fuse_Broke_Flag = 0;               // clear Charger_Fuse_Broke
  Charger_Fuse_Broke_cnt = 0;
  
}

void Clear_Charger_Warning_Delay(void)
{
  Charger_Delay.UV_Warning_Flag = 0;
  Charger_Delay.UV_Warning_Cnt = 0;
  Charger_Delay.OV_Warning_Flag = 0;
  Charger_Delay.OV_Warning_Cnt = 0;
  Charger_Delay.Cell_OT_Warning_Flag = 0;
  Charger_Delay.Cell_OT_Warning_Cnt = 0;
  Charger_Delay.OC_Warning_Flag = 0;
  Charger_Delay.OC_Warning_Cnt = 0;
  Charger_Delay.Boost_OT_Warning_Flag = 0;
  Charger_Delay.Boost_OT_Warning_Cnt = 0;  
  Charger_Delay.OP_Warning_Flag = 0;
  Charger_Delay.OP_Warning_Cnt = 0;
}

void Clear_Status_Bit(void)
{
   u8StatusP0CML = 0x00;
   u8StatusP0Temp = 0x00;
   u8StatusP0Input = 0x00;
   u8StatusP0Iout = 0x00;
   u8StatusP0Vout = 0x00;
   u8StatusP0BBU = 0x00;  
}

void Clear_Warning_Status_Bit(void)
{
   u8StatusP0Temp &= (~Status_Temperature_bits_OT_Warning);
   u8StatusP0Input &= (~(Status_Input_bits_Vin_OV_Warning | Status_Input_bits_Vin_UV_Warning |
                        Status_Input_bits_Iin_OC_Warning | Status_Input_bits_Pin_OP_Warning));
   u8StatusP0Iout &= (~(Status_Iout_bits_Iout_OC_Warning | Status_Iout_bits_Pout_OP_Warning));
   u8StatusP0Vout &= (~(Status_Vout_bits_Vout_OV_Warning | Status_Vout_bits_Vout_UV_Warning));
   u8StatusP0BBU &= (~(Status_BBU_bits_Battery_SOH_Low_Warning | Status_BBU_bits_Battery_Low_Warning |
                       Status_BBU_bits_Battery_Cycle_Cnt_Warning));
   u8StatusP0CML = 0x00;   

}

void Clear_Discharger_Fault_Delay(void)
{
   Discharger_Delay.UV_Fault_Flag = 0;
   Discharger_Delay.UV_Fault_Cnt = 0;
   Discharger_Delay.OC_Fault_Flag = 0;
   Discharger_Delay.OC_Fault_Cnt = 0;
   Discharger_Delay.OP_Fault_Flag = 0;
   Discharger_Delay.OP_Fault_Cnt = 0;
   Discharger_Delay.Buck_OT_Fault_Flag = 0;
   Discharger_Delay.Buck_OT_Fault_Cnt = 0;
   Discharger_Delay.Cell_OT_Fault_Flag = 0;
   Discharger_Delay.Cell_OT_Fault_Cnt = 0;
   Discharger_Delay.Cell_UV_Fault_Cnt = 0;
   Discharger_Delay.DFET_Notopen_Flag = 0;
   Discharger_Delay.DFET_Notopen_Cnt = 0;
}

void Clear_Discharger_Warning_Delay(void)
{
   Discharger_Delay.UV_Warning_Flag = 0;
   Discharger_Delay.UV_Warning_Cnt = 0;
   Discharger_Delay.OC_Warning_Flag = 0;
   Discharger_Delay.OC_Warning_Cnt = 0;
   Discharger_Delay.OP_Warning_Flag = 0;
   Discharger_Delay.OP_Warning_Cnt = 0;
   Discharger_Delay.Buck_OT_Warning_Flag = 0;
   Discharger_Delay.Buck_OT_Warning_Cnt = 0;
   Discharger_Delay.Cell_OT_Warning_Flag = 0;
   Discharger_Delay.Cell_OT_Warning_Cnt = 0;
}

