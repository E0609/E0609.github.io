#ifndef __BBU_CONTENT_H__
#define __BBU_CONTENT_H__


#include <p24FJ64GA006.h>
#include "bms_Pin_Define.h"
#include "PMBus_data_transfor.h"
#include "main.h"

void PMBus_data_update(void);
void PMBus_need_update_data(void);

#define BusVoltage_gain 1000 
#define CellCurrent_gain 1000
#define Iout_gain 1000
#define Iin_gain 1000
#define BusPower_gain 1000
#define CellVoltage_gain 1000
#define Charge_Current_Zero 0
#define Charge_Current_Standard 2900           // 1.5A charge
#define Charge_Current_Fast 4000               // 2A charge 
#define Charge_Current_Slow 1400               // 0.6A charge
#define Charge_Current_Medium 2350             // 1A charge
#define Charge_Current_Medium_Fast 3800        // 1.8A charge
#define Charge_Current_0A  0
#define Charge_Current_600mA 600
#define Charge_Current_1000mA 1000
#define Charge_Current_1500mA 1500
#define Charge_Current_1800mA 1800
#define Charge_Current_2000mA 2000

 
 

extern u8_t Charge_Current_Zero_Flag;
extern u8_t Charge_Current_Standard_Flag;
extern u8_t Charge_Current_Slow_Flag;
extern u8_t Charge_Current_Fast_Flag;
extern u8_t Charge_Current_Medium_Flag;
extern u8_t Charge_Cuurent_Medium_Fast_Flag;




typedef struct
{
  u8_t flag;

}BBU_content_T;

extern BBU_content_T BBU_content;


#endif


