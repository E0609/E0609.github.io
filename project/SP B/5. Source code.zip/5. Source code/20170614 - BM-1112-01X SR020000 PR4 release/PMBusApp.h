/********************************************************************************
* file				PMBusApp.h
*
* brief				The file includes the definition of PMBus protocol and the user
*					defined sections.
*
* note
*
* author			slade.fang
*
* version			01
*
* section History	2014/09/01	-	1st release
********************************************************************************/
#ifndef __PMBUSAPP_H__
#define __PMBUSAPP_H__


//#include "bms_Pin_Define.h"
#include "GenericTypeDefs.h"
//#include "I2C.h"
//#include "main.h"
//#include <p24FJ64GA006.h>
//#include "PMBusData.h"
//#include "SI2CDrv.h"

//define PMBus application macro
#define PMBUSAPP_RX_BUFF					30			//the buffer length is the same as the driver, must check the driver buffer!
#define PMBUSAPP_TX_BUFF					50			//the buffer begins from byte number(block read), not include slave address(read)
#define PMBus_CurrPage						u8CurrPage	//0xff: all pages, the current page is not store in EEPROM of the design currently...
#define PMBus_WrProtect						u8WriteProtect
#define PMBus_MinPage						0
#define PMBus_MaxPage						0

#define PMBusCmd_RdCodeID					PMBusCmd_MFRSp32 //f0
#define PMBusCmd_RdMcuType					PMBusCmd_MFRSp33 //f1
#define PMBusCmd_EnterBootMode				PMBusCmd_MFRSp34 //f2
#define PMBusCmd_EraseFlash					PMBusCmd_MFRSp35 //f3
#define PMBusCmd_WriteFlash					PMBusCmd_MFRSp36 //f4
#define PMBusCmd_McuReset					PMBusCmd_MFRSp37 //f5
#define PMBusCmd_RdStatus					PMBusCmd_MFRSp38 //f6
#define PMBusCmd_RdFileCrc					PMBusCmd_MFRSp39 //f7

//define the enum of commands of the PMBus protocol
typedef enum
{
	PMBusCmd_Page = 0x00,
	PMBusCmd_Operation,
	PMBusCmd_OnOffConf,
	PMBusCmd_ClrFault,
	PMBusCmd_Phase,
	PMBusCmd_PagePlusWr,
	PMBusCmd_PagePlusRd,
	PMBusCmd_Reserved1,
	PMBusCmd_Reserved2,
	PMBusCmd_Reserved3,
	PMBusCmd_Reserved4,
	PMBusCmd_Reserved5,
	PMBusCmd_Reserved6,
	PMBusCmd_Reserved7,
	PMBusCmd_Reserved8,
	PMBusCmd_Reserved9,
	PMBusCmd_WriteProt = 0x10,
	PMBusCmd_StoreDftAll,
	PMBusCmd_RStoreDftAll,
	PMBusCmd_StoreDftCode,
	PMBusCmd_RStoreDftCode,
	PMBusCmd_StoreUserAll,
	PMBusCmd_RStoreUserAll,
	PMBusCmd_StoreUserCode,
	PMBusCmd_RStoreUserCode,
	PMBusCmd_Capability,
	PMBusCmd_Query,
	PMBusCmd_SMBAlertMask,
	PMBusCmd_Reserved10,
	PMBusCmd_Reserved11,
	PMBusCmd_Reserved12,
	PMBusCmd_Reserved13,
	PMBusCmd_VoutMode = 0x20,
	PMBusCmd_VoutCmd,
	PMBusCmd_VoutTrim,
	PMBusCmd_VoutCalOffset,
	PMBusCmd_VoutMax,
	PMBusCmd_VoutMarginHi,
	PMBusCmd_VoutMarginLow,
	PMBusCmd_VoutTranRate,
	PMBusCmd_VoutDroop,
	PMBusCmd_VoutScaleLoop,
	PMBusCmd_VoutScaleMon,
	PMBusCmd_Reserved14,
	PMBusCmd_Reserved15,
	PMBusCmd_Reserved16,
	PMBusCmd_Reserved17,
	PMBusCmd_Reserved18,
	PMBusCmd_Coef = 0x30,
	PMBusCmd_POutMax,
	PMBusCmd_MaxDuty,
	PMBusCmd_FreqSwitch,
	PMBusCmd_Reserved19,
	PMBusCmd_VinOn,
	PMBusCmd_VinOff,
	PMBusCmd_Interleave,
	PMBusCmd_IoutCalGain,
	PMBusCmd_IoutCalOff,
	PMBusCmd_FanConf12,
	PMBusCmd_FanCmd1,
	PMBusCmd_FanCmd2,
	PMBusCmd_FanConf34,
	PMBusCmd_FanCmd3,
	PMBusCmd_FanCmd4,
	PMBusCmd_VoutOVFaultLimit = 0x40,
	PMBusCmd_VoutOVFaultResp,
	PMBusCmd_VoutOVWarnLimit,
	PMBusCmd_VoutUVWarnLimit,
	PMBusCmd_VoutUVFaultLimit,
	PMBusCmd_VoutUVFaultResp,
	PMBusCmd_IoutOCFaultLimit,
	PMBusCmd_IoutOCFaultResp,
	PMBusCmd_IoutOCLVFaultLimit,
	PMBusCmd_IoutOCLVFaultResp,
	PMBusCmd_IoutOCWarnLimit,
	PMBusCmd_IoutUCFaultLimit,
	PMBusCmd_IoutUCFaultResp,
	PMBusCmd_Reserved20,
	PMBusCmd_Reserved21,
	PMBusCmd_OTFaultLimit,
	PMBusCmd_OTFaultResp = 0x50,
	PMBusCmd_OTWarnLimit,
	PMBusCmd_UTWarnLimit,
	PMBusCmd_UTFaultLimit,
	PMBusCmd_UTFaultResp,
	PMBusCmd_VinOVFaultLimit,
	PMBusCmd_VinOVFaultResp,
	PMBusCmd_VinOVWarnLimit,
	PMBusCmd_VinUVWarnLimit,
	PMBusCmd_VinUVFaultLimit,
	PMBusCmd_VinUVFaultResp,
	PMBusCmd_IinOCFaultLimit,
	PMBusCmd_IinOCFaultResp,
	PMBusCmd_IinOCWarnLimit,
	PMBusCmd_PwrGoodOn,
	PMBusCmd_PwrGoodOff,
	PMBusCmd_TonDelay = 0x60,
	PMBusCmd_TonRise,
	PMBusCmd_TonMaxFaultLimit,
	PMBusCmd_TonMaxFaultResp,
	PMBusCmd_ToffDelay,
	PMBusCmd_ToffFail,
	PMBusCmd_ToffMaxWarnLimit,
	PMBusCmd_Reserved22,
	PMBusCmd_PoutOPFaultLimit,
	PMBusCmd_PoutOPFaultResp,
	PMBusCmd_PoutOPWarnLimit,
	PMBusCmd_PinOPWarnLimit,
	PMBusCmd_Reserved23,
	PMBusCmd_Reserved24,
	PMBusCmd_Reserved25,
	PMBusCmd_Reserved26,
	PMBusCmd_Reserved27 = 0x70,
	PMBusCmd_Reserved28,
	PMBusCmd_Reserved29,
	PMBusCmd_Reserved30,
	PMBusCmd_Reserved31,
	PMBusCmd_Reserved32,
	PMBusCmd_Reserved33,
	PMBusCmd_Reserved34,
	PMBusCmd_StatusByte,
	PMBusCmd_StatusWord,
	PMBusCmd_StatusVout,
	PMBusCmd_StatusIout,
	PMBusCmd_StatusInput,
	PMBusCmd_StatusTemp,
	PMBusCmd_StatusCML,
	PMBusCmd_StatusOther,
	PMBusCmd_StatusMFRSp = 0x80,
	PMBusCmd_StatusFan12,
	PMBusCmd_StatusFan34,
	PMBusCmd_Reserved35,
	PMBusCmd_Reserved36,
	PMBusCmd_Reserved37,
	PMBusCmd_RdEin,
	PMBusCmd_RdEout,
	PMBusCmd_RdVin,
	PMBusCmd_RdIin,
	PMBusCmd_RdVcap,
	PMBusCmd_RdVout,
	PMBusCmd_RdIout,
	PMBusCmd_RdTemp1,
	PMBusCmd_RdTemp2,
	PMBusCmd_RdTemp3,
	PMBusCmd_RdFanSpeed1 = 0x90,
	PMBusCmd_RdFanSpeed2,
	PMBusCmd_RdFanSpeed3,
	PMBusCmd_RdFanSpeed4,
	PMBusCmd_RdDutyCycle,
	PMBusCmd_RdFreq,
	PMBusCmd_RdPout,
	PMBusCmd_RdPin,
	PMBusCmd_RMBusRev,
	PMBusCmd_MFRID,
	PMBusCmd_MFRModel,
	PMBusCmd_MFRRev,
	PMBusCmd_MFRLocation,
	PMBusCmd_MFRDate,
	PMBusCmd_MFRSerial,
	PMBusCmd_AppProfileSup,
	PMBusCmd_MFRVinMin = 0xa0,
	PMBusCmd_MFRVinMax,
	PMBusCmd_MFRIinMax,
	PMBusCmd_MFRPinMax,
	PMBusCmd_MFRVoutMin,
	PMBusCmd_MFRVoutMax,
	PMBusCmd_MFRIoutMax,
	PMBusCmd_MFRPoutMax,
	PMBusCmd_MFRAmbTMax,
	PMBusCmd_MFRAmbTMin,
	PMBusCmd_MFREffLL,
	PMBusCmd_MFREffHL,
	PMBusCmd_MFRPinAccuracy,
	PMBusCmd_ICDevID,
	PMBusCmd_ICDevRev,
	PMBusCmd_Reserved38,
	PMBusCmd_UsrData0 = 0xb0,
	PMBusCmd_UsrData1,
	PMBusCmd_UsrData2,
	PMBusCmd_UsrData3,
	PMBusCmd_UsrData4,
	PMBusCmd_UsrData5,
	PMBusCmd_UsrData6,
	PMBusCmd_UsrData7,
	PMBusCmd_UsrData8,
	PMBusCmd_UsrData9,
	PMBusCmd_UsrData10,
	PMBusCmd_UsrData11,
	PMBusCmd_UsrData12,
	PMBusCmd_UsrData13,
	PMBusCmd_UsrData14,
	PMBusCmd_UsrData15,
	PMBusCmd_MFRMaxTemp1 = 0xc0,
	PMBusCmd_MFRMaxTemp2,
	PMBusCmd_MFRMaxTemp3,
	PMBusCmd_Reserved39,
	PMBusCmd_Reserved40,
	PMBusCmd_Reserved41,
	PMBusCmd_Reserved42,
	PMBusCmd_Reserved43,
	PMBusCmd_Reserved44,
	PMBusCmd_Reserved45,
	PMBusCmd_Reserved46,
	PMBusCmd_Reserved47,
	PMBusCmd_Reserved48,
	PMBusCmd_Reserved49,
	PMBusCmd_Reserved50,
	PMBusCmd_Reserved51,
	PMBusCmd_MFRSp0 = 0xd0,
	PMBusCmd_MFRSp1,
	PMBusCmd_MFRSp2,
	PMBusCmd_MFRSp3,
	PMBusCmd_MFRSp4,
	PMBusCmd_MFRSp5,
	PMBusCmd_MFRSp6,
	PMBusCmd_MFRSp7,
	PMBusCmd_MFRSp8,
	PMBusCmd_MFRSp9,
	PMBusCmd_MFRSp10,
	PMBusCmd_MFRSp11,
	PMBusCmd_MFRSp12,
	PMBusCmd_MFRSp13,
	PMBusCmd_MFRSp14,
	PMBusCmd_MFRSp15,
	PMBusCmd_MFRSp16 = 0xe0,
	PMBusCmd_MFRSp17,
	PMBusCmd_MFRSp18,
	PMBusCmd_MFRSp19,
	PMBusCmd_MFRSp20,
	PMBusCmd_MFRSp21,
	PMBusCmd_MFRSp22,
	PMBusCmd_MFRSp23,
	PMBusCmd_MFRSp24,
	PMBusCmd_MFRSp25,
	PMBusCmd_MFRSp26,
	PMBusCmd_MFRSp27,
	PMBusCmd_MFRSp28,
	PMBusCmd_MFRSp29,
	PMBusCmd_MFRSp30,
	PMBusCmd_MFRSp31,
	PMBusCmd_MFRSp32 = 0xf0,
	PMBusCmd_MFRSp33,
	PMBusCmd_MFRSp34,
	PMBusCmd_MFRSp35,
	PMBusCmd_MFRSp36,
	PMBusCmd_MFRSp37,
	PMBusCmd_MFRSp38,
	PMBusCmd_MFRSp39,
	PMBusCmd_MFRSp40,
	PMBusCmd_MFRSp41,
	PMBusCmd_MFRSp42,
	PMBusCmd_MFRSp43,
	PMBusCmd_MFRSp44,
	PMBusCmd_MFRSp45,
	PMBusCmd_MFRSpCmdExt,
	PMBusCmd_PMBusCmdExt
}ePMBusCmd_t;

//define enum of command type
typedef enum
{
	//read command
	PMBusCmdT_RcByte = 0x00,
	PMBusCmdT_RdByte,
	PMBusCmdT_RdWord,
	PMBusCmdT_RdBlock,
	PMBusCmdT_ProcCall,
	PMBusCmdT_BWBRProcCall,
	PMBusCmdT_ReadEnd,
	//write command
	PMBusCmdT_Quick = 0x10,
	PMBusCmdT_SendByte,
	PMBusCmdT_WrByte,
	PMBusCmdT_WrWord,
	PMBusCmdT_WrBlock,
	PMBusCmdT_WrEnd,
	//read/write command
	PMBusCmdT_RdWrByte = 0x20,
	PMBusCmdT_RdWrWord,
	PMBusCmdT_RdWrBlock,
	PMBusCmdT_BWBRRd_WordWr,
	PMBusCmdT_RdWrEnd
}ePMBusCmdType_t;

//============================//
//    enum of data type       //
//============================//

//define enum of data type, this is the same as Query data byte format bit 2~4 of PMBus spec
typedef enum
{
	PMBusDataT_Linear = 0x00,
	PMBusDataT_s16,
	PMBusDataT_Reserved,
	PMBusDataT_Direct,
	PMBusDataT_u8,
	PMBusDataT_VID,
	PMBusDataT_MFR,
	PMBusDataT_NN_Block			//non numeric data or block data
}ePMBusDataType_t;

//===========================//
// Read only command struct  // 
//===========================//

typedef struct
{
	u8_t u8Cmd;
	u8_t u8CmdType;
	u8_t u8DataType;
	u8_t u8RdLength;   	//without slave address and command code, with PEC
	u8_t u8WrLength;	//without slave address and command code, with PEC
	u8_t* pu8P0Buff;	//the address of the variable used for the command in page0
	u8_t* pu8P1Buff;	//the address of the variable used for the command in page1
}sPMBusCmdRdStr_t;

//===========================//
// Read/Write command struct //
//===========================//

typedef struct
{
	u8_t u8Cmd;
	u8_t u8CmdType;
	u8_t u8DataType;
	u8_t u8RdLength;   	//without slave address and command code, with PEC 
	u8_t u8WrLength;	//without slave address and command code, with PEC
	u8_t* pu8P0Buff;	//the address of the variable used for the command in page0
	u8_t* pu8P1Buff;	//the address of the variable used for the command in page1
	
	u16_t u16E2pP0Index;	//the index of the EEPROM used to store the P0 variable
	u16_t u16E2pP1Index;	//the index of the EEPROM used to store the P1 variable
}sPMBusCmdWrStr_t;


typedef struct				//only support 16bits range
{
	u8_t u8Cmd;
	u8_t u8LinearType;		//1~16 is legal, others would assume as linear16
	s32_t s32Min;			//
	s32_t s32Max;			//	
}sPMBusCmdWrLimitStr_t;

typedef struct
{
	u8_t u8Cmd;
	u8_t u8CmdType;
	u8_t u8DataType;
	u8_t u8RdLength;    //without slave address and command code, with PEC
	u8_t u8WrLength;	//without slave address and command code, with PEC
	u8_t* pu8P0Buff;	//the address of the variable used for the command in page0
	u8_t* pu8P1Buff;	//the address of the variable used for the command in page1
	
	u16_t u16E2pP0Index;	//the index of the EEPROM used to store the P0 variable
	u16_t u16E2pP1Index;	//the index of the EEPROM used to store the P1 variable

	u8_t* pu8P0StatusMask;	//the address of the status mask variable used for page0
	u8_t* pu8P1StatusMask;	//the address of the status mask variable used for page1
}sPMBusCmdStatusStr_t;





extern void PMBusInit(void);
extern void PMBusRxParse(void);
extern void PMBusTxParse(void);
extern void PMBusMapRxData(void);
extern void UpdateStatusBit(u8_t u8Cmd, u8_t u8Bit, u8_t u8Set);
extern void UpdateSTATUS_WORD(void);



#endif

