/********************************************************************************
* file				PMBusData.c
*
* brief				The file includes the function and data structure/variables
*					for the PMBus protocol
*
* note
*
* author			slade.fang
*
* version			01
*
* section History	2014/09/01	-	1st release
********************************************************************************/

#include "PMBusApp.h"
#include "PMBusData.h"
#include "QTBootloader.h"
#include "SI2CDrv.h"
#include <string.h>



//Test data for PMBus protocol
u8_t PMBus_CurrPage;
u8_t u8ClrFaultP0;
u8_t u8ClrFaultP1;
u8_t u8Operation;
u8_t u8OnOffConfig;
u8_t PMBus_WrProtect;
u8_t u8StoreDefaultAll;     
u8_t u8Capability;
u8_t u8PMBusQuerry;
u8_t u8VoutMode;
u16_t u16VoutOVFaultL;
u8_t  u8VoutOVResponse;
u16_t u16VoutOVWarnL;
u16_t u16VoutUVFaultL;
u8_t  u8VoutUVResponse;
u16_t u16VoutUVWarnL;
u16_t u16IoutOCFaultL;
u8_t  u8IoutOCResponse;
u16_t u16IoutOCWarnL;
u16_t u16BuckOTFaultL;
u16_t u16BuckOTWarnL;
u8_t  u8BuckOTResponse;
u16_t u16VinOVFaultL;
u8_t  u8VinOVResponse;
u16_t u16VinOVWarnL;
u16_t u16VinUVFaultL;
u8_t  u8VinUVResponse;
u16_t u16VinUVWarnL;
u16_t u16IinOCFaultL;
u8_t  u8IinOCResponse;
u16_t u16IinOCWarnL;
u16_t u16PoutOPWarnL;
u16_t u16PoutOPFaultL;
u16_t u16PinOPWarnL;
u16_t u16StatusP0Word;
u8_t u8StatusP0Vout;
u8_t u8StatusP0Iout;
u8_t u8StatusP0Input;
u8_t u8StatusP0Temp;
u8_t u8StatusP0CML;
u16_t u16StatusP1Word;
u8_t u8StatusP1Vout;
u8_t u8StatusP1Iout;
u8_t u8StatusP1Input;
u8_t u8StatusP1Temp;
u8_t u8StatusP1CML;
u8_t u8StatusMP0Byte;
u16_t u16StatusMP0Word;
u8_t u8StatusMP0Vout;
u8_t u8StatusMP0Iout;
u8_t u8StatusMP0Input;
u8_t u8StatusMP0Temp;
u8_t u8StatusMP0CML;
u8_t u8StatusMP1Byte;
u16_t u16StatusMP1Word;
u8_t u8StatusMP1Vout;
u8_t u8StatusMP1Iout;
u8_t u8StatusMP1Input;
u8_t u8StatusMP1Temp;
u8_t u8StatusMP1CML;
u16_t u16ReadVin;
u16_t u16ReadIin;
u16_t u16ReadVout;
u16_t u16ReadIout;
u16_t u16ReadTemp1;
u16_t u16ReadTemp2;
u16_t u16ReadTemp3;
u16_t u16ReadPout;
u16_t u16ReadPin;
u8_t u8PMBusRev;
u8_t pu8MFRID[10];
u8_t pu8MFRModel[12];
u8_t pu8MFRRev[10];
u8_t pu8MFRLoc[10];
u8_t pu8MFRDate[10];
u8_t pu8MFRSerial[16];
u16_t u16MFRVinMin;
u16_t u16MFRVinMax;
u16_t u16MFRIinMax;
u16_t u16MFRPinMax;
u16_t u16MFRVoutMin;
u16_t u16MFRVoutMax;
u16_t u16MFRIoutMax;
u16_t u16MFRPoutMax;
u16_t u16MFRAmbTMax;
u16_t u16MFRAmbTMin;
u16_t u16MFRMaxT1;
u16_t u16MFRMaxT2;
u8_t u8StatusP0BBU;
u8_t u8StatusP1BBU;
u8_t u8StatusMP0BBU;
u8_t u8StatusMP1BBU;
u16_t u16StateBBU;
u8_t u8ChargeCurrSelect;
u16_t u16BattSN;
u16_t u16BattVolt;
u8_t  pu8MFRBMSCompatible[11];
u16_t u16BattCurr;
u16_t u16BattASOC;
u16_t u16BattRSOC;
u16_t u16BattCapacity;
u16_t u16BattCycleCnt;
u32_t u32BBURunTime;
u16_t u16BatteryStatus;
u16_t u16BattProtecStatus;
u16_t u16BattPFStatus;
u16_t u16VrefOffline;
u16_t u16VrefOnline;
u16_t u16BattTemp;
u8_t  u8Calibration;
u32_t u32Protection_type;
u16_t u16LastProtect_Index;
u32_t u32LastProtect;
u16_t u16TrimDuty;
u16_t u16BattSOH; 
u16_t u16DischargeRemainTime;
u8_t  pu8CellVoltage[28];
u16_t u16BMSFWRev;
u16_t u16FCC;
u16_t u16DischargeCellOTFaultL;
u16_t u16DischargeCellOTWarnL;
u16_t u16ChargeCellOTFaultL;
u16_t u16ChargeCellOTWarnL;
u16_t u16CycleCntLimit;
u16_t u16BoostOTFaultL;
u16_t u16BoostOTWarnL;
u16_t u16AmbientOTFaultL;
u16_t u16AmbientOTWarnL;
u16_t u16Cycle_Cnt_Offset;
u8_t  pu8BatteryName[16];
u8_t  pu8CellModel[16];
u8_t  pu8CellMFR[16];
u8_t  pu8ProtocolVersion[16];
u16_t u16BBS_Control;
u8_t  pu8BBUCompatible[11];
u16_t u16Modechange;
u16_t u16DischargeLimit;


 




//The data structures are used for PMBusApp.c, User must define for the application.
//The example is for BBU 600Watt product
//define the read only command structure
sPMBusCmdRdStr_t sPMBusRdCmd[USER_PMBUS_RDNUM] = 
{
	{PMBusCmd_Capability,	PMBusCmdT_RdByte,		PMBusDataT_NN_Block,2,	0,	&u8Capability,			&u8Capability},
    {PMBusCmd_OnOffConf,	PMBusCmdT_RdByte,		PMBusDataT_NN_Block,2,	0,	&u8OnOffConfig,			&u8OnOffConfig},
	{PMBusCmd_Query, 		PMBusCmdT_BWBRProcCall,	PMBusDataT_NN_Block,3, 	0,	&u8PMBusQuerry,			&u8PMBusQuerry},
    {PMBusCmd_VoutMode,     PMBusCmdT_RdByte,	    PMBusDataT_NN_Block,2, 	0,	&u8VoutMode,			&u8VoutMode},
    {PMBusCmd_VoutOVFaultResp,     PMBusCmdT_RdByte,	    PMBusDataT_NN_Block,2, 	0,	&u8VoutOVResponse,			&u8VoutOVResponse},
    {PMBusCmd_VoutUVFaultResp,     PMBusCmdT_RdByte,	    PMBusDataT_NN_Block,2, 	0,	&u8VoutUVResponse,			&u8VoutUVResponse},
    {PMBusCmd_IoutOCFaultResp,     PMBusCmdT_RdByte,	    PMBusDataT_NN_Block,2, 	0,	&u8IoutOCResponse,			&u8IoutOCResponse},
    {PMBusCmd_OTFaultResp,         PMBusCmdT_RdByte,	    PMBusDataT_NN_Block,2, 	0,	&u8BuckOTResponse,			&u8BuckOTResponse},
    {PMBusCmd_VinOVFaultResp,      PMBusCmdT_RdByte,	    PMBusDataT_NN_Block,2, 	0,	&u8VinOVResponse,			&u8VinOVResponse},
    {PMBusCmd_VinUVFaultResp,      PMBusCmdT_RdByte,	    PMBusDataT_NN_Block,2, 	0,	&u8VinUVResponse,			&u8VinUVResponse},
    {PMBusCmd_IinOCFaultResp,      PMBusCmdT_RdByte,	    PMBusDataT_NN_Block,2, 	0,	&u8IinOCResponse,			&u8IinOCResponse},	
    {PMBusCmd_RdVin, 		PMBusCmdT_RdWord,		PMBusDataT_Linear,	3,	0,	(u8_t*)&u16ReadVin,		(u8_t*)&u16ReadVin},
	{PMBusCmd_RdIin, 		PMBusCmdT_RdWord,		PMBusDataT_Linear,	3,	0,	(u8_t*)&u16ReadIin,		(u8_t*)&u16ReadIin},
	{PMBusCmd_RdVout, 		PMBusCmdT_RdWord,		PMBusDataT_Linear,	3,	0,	(u8_t*)&u16ReadVout,	(u8_t*)&u16ReadVout},
	{PMBusCmd_RdIout, 		PMBusCmdT_RdWord,		PMBusDataT_Linear,	3,	0,	(u8_t*)&u16ReadIout,	(u8_t*)&u16ReadIout},
	{PMBusCmd_RdTemp1, 		PMBusCmdT_RdWord,		PMBusDataT_Linear,	3,	0,	(u8_t*)&u16ReadTemp1,	(u8_t*)&u16ReadTemp1},
	{PMBusCmd_RdTemp2, 		PMBusCmdT_RdWord,		PMBusDataT_Linear,	3,	0,	(u8_t*)&u16ReadTemp2,	(u8_t*)&u16ReadTemp2},
	{PMBusCmd_RdTemp3, 		PMBusCmdT_RdWord,		PMBusDataT_Linear,	3,	0,	(u8_t*)&u16ReadTemp3,	(u8_t*)&u16ReadTemp3},
	{PMBusCmd_RdPout, 		PMBusCmdT_RdWord,		PMBusDataT_Linear,	3,	0,	(u8_t*)&u16ReadPout,	(u8_t*)&u16ReadPout},
	{PMBusCmd_RdPin, 		PMBusCmdT_RdWord,		PMBusDataT_Linear,	3,	0,	(u8_t*)&u16ReadPin,		(u8_t*)&u16ReadPin},
	{PMBusCmd_RMBusRev, 	PMBusCmdT_RdByte,		PMBusDataT_NN_Block,2,	0,	&u8PMBusRev,			&u8PMBusRev},
	{PMBusCmd_MFRVinMin, 	PMBusCmdT_RdWord,		PMBusDataT_Linear,	3,	0,	(u8_t*)&u16MFRVinMin,	(u8_t*)&u16MFRVinMin},
	{PMBusCmd_MFRVinMax, 	PMBusCmdT_RdWord,		PMBusDataT_Linear,	3,	0,	(u8_t*)&u16MFRVinMax,	(u8_t*)&u16MFRVinMax},
	{PMBusCmd_MFRIinMax, 	PMBusCmdT_RdWord,		PMBusDataT_Linear,	3,	0,	(u8_t*)&u16MFRIinMax,	(u8_t*)&u16MFRIinMax},
	{PMBusCmd_MFRPinMax, 	PMBusCmdT_RdWord,		PMBusDataT_Linear,	3,	0,	(u8_t*)&u16MFRPinMax,	(u8_t*)&u16MFRPinMax},
	{PMBusCmd_MFRVoutMin, 	PMBusCmdT_RdWord,		PMBusDataT_Linear,	3,	0,	(u8_t*)&u16MFRVoutMin,	(u8_t*)&u16MFRVoutMin},
	{PMBusCmd_MFRVoutMax, 	PMBusCmdT_RdWord,		PMBusDataT_Linear,	3,	0,	(u8_t*)&u16MFRVoutMax,	(u8_t*)&u16MFRVoutMax},
	{PMBusCmd_MFRIoutMax, 	PMBusCmdT_RdWord,		PMBusDataT_Linear,	3,	0,	(u8_t*)&u16MFRIoutMax,	(u8_t*)&u16MFRIoutMax},
	{PMBusCmd_MFRPoutMax, 	PMBusCmdT_RdWord,		PMBusDataT_Linear,	3,	0,	(u8_t*)&u16MFRPoutMax,	(u8_t*)&u16MFRPoutMax},
	{PMBusCmd_MFRAmbTMax, 	PMBusCmdT_RdWord,		PMBusDataT_Linear,	3,	0,	(u8_t*)&u16MFRAmbTMax,	(u8_t*)&u16MFRAmbTMax},
	{PMBusCmd_MFRAmbTMin, 	PMBusCmdT_RdWord,		PMBusDataT_Linear,	3,	0,	(u8_t*)&u16MFRAmbTMin,	(u8_t*)&u16MFRAmbTMin},
	{PMBusCmd_MFRMaxTemp1, 	PMBusCmdT_RdWord,		PMBusDataT_Linear,	3,	0,	(u8_t*)&u16MFRMaxT1,	(u8_t*)&u16MFRMaxT1},
	{PMBusCmd_MFRMaxTemp2, 	PMBusCmdT_RdWord,		PMBusDataT_Linear,	3,	0,	(u8_t*)&u16MFRMaxT2,	(u8_t*)&u16MFRMaxT2},
	{PMBusCmd_UsrData12, 	PMBusCmdT_RdBlock,	    PMBusDataT_NN_Block,17,	0,	pu8BatteryName,			   pu8BatteryName},
    {PMBusCmd_UsrData13, 	PMBusCmdT_RdBlock,	    PMBusDataT_NN_Block,17,	0,	pu8CellMFR,			       pu8CellMFR},
    {PMBusCmd_UsrData14, 	PMBusCmdT_RdBlock,	    PMBusDataT_NN_Block,17,	0,	pu8CellModel,			   pu8CellModel},
    {PMBusCmd_MFRSp1,		PMBusCmdT_RdWord,		PMBusDataT_NN_Block,3,	0,	(u8_t*)&u16StateBBU,	(u8_t*)&u16StateBBU},
	{PMBusCmd_MFRSp3, 		PMBusCmdT_RdWord,		PMBusDataT_NN_Block,3,	0,	(u8_t*)&u16BattSN,		(u8_t*)&u16BattSN},
	{PMBusCmd_MFRSp4, 		PMBusCmdT_RdWord,		PMBusDataT_Linear,	3,	0,	(u8_t*)&u16BattVolt,	(u8_t*)&u16BattVolt},
	{PMBusCmd_MFRSp5, 		PMBusCmdT_RdBlock,		PMBusDataT_NN_Block,13,	0,	pu8MFRBMSCompatible,	 pu8MFRBMSCompatible},
	{PMBusCmd_MFRSp6, 		PMBusCmdT_RdWord,		PMBusDataT_Linear,	3,	0,	(u8_t*)&u16BattCurr,	(u8_t*)&u16BattCurr},
	{PMBusCmd_MFRSp7, 		PMBusCmdT_RdWord,		PMBusDataT_Linear,	3,	0,	(u8_t*)&u16BattASOC,	(u8_t*)&u16BattASOC},
	{PMBusCmd_MFRSp9, 		PMBusCmdT_RdWord,		PMBusDataT_Linear,	3,	0,	(u8_t*)&u16BattRSOC,	(u8_t*)&u16BattRSOC},
	{PMBusCmd_MFRSp10, 		PMBusCmdT_RdWord,		PMBusDataT_Linear,	3,	0,	(u8_t*)&u16BattCapacity,(u8_t*)&u16BattCapacity},
	{PMBusCmd_MFRSp11, 		PMBusCmdT_RdWord,		PMBusDataT_Linear,	3,	0,	(u8_t*)&u16BattCycleCnt,(u8_t*)&u16BattCycleCnt},
	{PMBusCmd_MFRSp12, 		PMBusCmdT_RdBlock,		PMBusDataT_NN_Block,	6,	0,	(u8_t*)&u32BBURunTime,	(u8_t*)&u32BBURunTime},
    {PMBusCmd_MFRSp13, 		PMBusCmdT_RdWord,		PMBusDataT_NN_Block,	3,	0,	(u8_t*)&u16BatteryStatus,	(u8_t*)&u16BatteryStatus},
    {PMBusCmd_MFRSp14, 		PMBusCmdT_RdWord,		PMBusDataT_NN_Block,	3,	0,	(u8_t*)&u16BattProtecStatus,	(u8_t*)&u16BattProtecStatus},
    {PMBusCmd_MFRSp15, 		PMBusCmdT_RdWord,		PMBusDataT_NN_Block,	3,	0,	(u8_t*)&u16BattPFStatus,	(u8_t*)&u16BattPFStatus},
    {PMBusCmd_MFRSp19, 		PMBusCmdT_RdWord,		PMBusDataT_Linear,	3,	0,	(u8_t*)&u16BattTemp,	(u8_t*)&u16BattTemp},
    {PMBusCmd_MFRSp21,      PMBusCmdT_RdBlock,      PMBusDataT_NN_Block,6,  0,  (u8_t*)&u32Protection_type, (u8_t*)&u32Protection_type},
    {PMBusCmd_MFRSp23, 		PMBusCmdT_RdBlock,		PMBusDataT_NN_Block,	6,	0,	(u8_t*)&u32LastProtect,	(u8_t*)&u32LastProtect},
    {PMBusCmd_MFRSp26, 		PMBusCmdT_RdBlock,		PMBusDataT_NN_Block,	30,	0,	pu8CellVoltage,	pu8CellVoltage},
    {PMBusCmd_MFRSp27, 		PMBusCmdT_RdWord,		PMBusDataT_NN_Block,	3,	0,	(u8_t*)&u16BMSFWRev,	(u8_t*)&u16BMSFWRev}, 
    {PMBusCmd_MFRSp28, 		PMBusCmdT_RdWord,		PMBusDataT_Linear,	3,	0,	(u8_t*)&u16FCC,	(u8_t*)&u16FCC},
    {PMBusCmd_MFRSp8, 		PMBusCmdT_RdWord,		PMBusDataT_Linear,	3,	0,	(u8_t*)&u16Cycle_Cnt_Offset,	(u8_t*)&u16Cycle_Cnt_Offset},
    {PMBusCmd_MFRSp24,      PMBusCmdT_RdWord,       PMBusDataT_Linear,  3,  0,  (u8_t*)&u16BattSOH,         (u8_t*)&u16BattSOH},
    {PMBusCmd_MFRSp25,      PMBusCmdT_RdWord,       PMBusDataT_Linear,  3,  0,  (u8_t*)&u16DischargeRemainTime,     (u8_t*)&u16DischargeRemainTime},
    {PMBusCmd_MFRSp44, 		PMBusCmdT_RdBlock,		PMBusDataT_NN_Block,13,	0,	pu8BBUCompatible,			pu8BBUCompatible},
    {PMBusCmd_MFRSp45, 		PMBusCmdT_RdBlock,		PMBusDataT_NN_Block,18,	0,	pu8ProtocolVersion,			pu8ProtocolVersion}, 
	 
};

//define the write(write or write-read) command structure
sPMBusCmdWrStr_t sPMBusWrCmd[USER_PMBUS_WRNUM] =
{
	{PMBusCmd_Page, 		PMBusCmdT_RdWrByte,		PMBusDataT_u8,		2,	2,	&u8CurrPage,			&u8CurrPage,			0,		0},
	{PMBusCmd_Operation, 	PMBusCmdT_RdWrByte,		PMBusDataT_NN_Block,2,	2,	&u8Operation,			&u8Operation,			0x01,		0x01},
    {PMBusCmd_ClrFault, 	PMBusCmdT_SendByte,		PMBusDataT_NN_Block,0,	2,	&u8ClrFaultP0,			&u8ClrFaultP1,			3,		3},
    {PMBusCmd_StoreDftAll, 	PMBusCmdT_SendByte,		PMBusDataT_NN_Block,0,	2,	&u8StoreDefaultAll,			&u8StoreDefaultAll,			0x11,		0x11},
    {PMBusCmd_WriteProt,    PMBusCmdT_RdWrByte,		PMBusDataT_NN_Block,2,	2,	&u8WriteProtect,	    &u8WriteProtect,				0x10,	0x10},
    {PMBusCmd_VoutOVFaultLimit, 	PMBusCmdT_RdWrWord,	PMBusDataT_Linear,	3,	3,	(u8_t*)&u16VoutOVFaultL,	(u8_t*)&u16VoutOVFaultL, 0x40,	0x40},
    {PMBusCmd_VoutOVWarnLimit, 	PMBusCmdT_RdWrWord,	PMBusDataT_Linear,	3,	3,	(u8_t*)&u16VoutOVWarnL,	(u8_t*)&u16VoutOVWarnL, 0x42,	0x42},
    {PMBusCmd_VoutUVWarnLimit, 	PMBusCmdT_RdWrWord,	PMBusDataT_Linear,	3,	3,	(u8_t*)&u16VoutUVWarnL,	(u8_t*)&u16VoutUVWarnL, 0x43,	0x43},
    {PMBusCmd_VoutUVFaultLimit, 	PMBusCmdT_RdWrWord,	PMBusDataT_Linear,	3,	3,	(u8_t*)&u16VoutUVFaultL,	(u8_t*)&u16VoutUVFaultL, 0x44,	0x44},
    {PMBusCmd_IoutOCFaultLimit, 	PMBusCmdT_RdWrWord,	PMBusDataT_Linear,	3,	3,	(u8_t*)&u16IoutOCFaultL,	(u8_t*)&u16IoutOCFaultL, 0x46,	0x46},
	{PMBusCmd_IoutOCWarnLimit, 	PMBusCmdT_RdWrWord,	PMBusDataT_Linear,	3,	3,	(u8_t*)&u16IoutOCWarnL,	(u8_t*)&u16IoutOCWarnL, 0x4a,	0x4a},
    {PMBusCmd_OTFaultLimit, 	PMBusCmdT_RdWrWord,		PMBusDataT_Linear,	3,	3,	(u8_t*)&u16BuckOTFaultL,		(u8_t*)&u16BuckOTFaultL, 	0x4F,	0x4F},
	{PMBusCmd_OTWarnLimit, 	PMBusCmdT_RdWrWord,		PMBusDataT_Linear,	3,	3,	(u8_t*)&u16BuckOTWarnL,		(u8_t*)&u16BuckOTWarnL, 	0x51,	0x51},
    {PMBusCmd_VinOVFaultLimit, 	PMBusCmdT_RdWrWord,		PMBusDataT_Linear,	3,	3,	(u8_t*)&u16VinOVFaultL,		(u8_t*)&u16VinOVFaultL, 	0x55,	0x55},
    {PMBusCmd_VinOVWarnLimit, 	PMBusCmdT_RdWrWord,		PMBusDataT_Linear,	3,	3,	(u8_t*)&u16VinOVWarnL,		(u8_t*)&u16VinOVWarnL, 	0x57,	0x57},
    {PMBusCmd_VinUVWarnLimit, 	PMBusCmdT_RdWrWord,		PMBusDataT_Linear,	3,	3,	(u8_t*)&u16VinUVWarnL,		(u8_t*)&u16VinUVWarnL, 	0x58,	0x58},
    {PMBusCmd_VinUVFaultLimit, 	PMBusCmdT_RdWrWord,		PMBusDataT_Linear,	3,	3,	(u8_t*)&u16VinUVFaultL,		(u8_t*)&u16VinUVFaultL, 	0x59,	0x59},
    {PMBusCmd_IinOCFaultLimit, 	PMBusCmdT_RdWrWord,	PMBusDataT_Linear,	3,	3,	(u8_t*)&u16IinOCFaultL,	(u8_t*)&u16IinOCFaultL, 	0x5b,	0x5b},
	{PMBusCmd_IinOCWarnLimit, 	PMBusCmdT_RdWrWord,	PMBusDataT_Linear,	3,	3,	(u8_t*)&u16IinOCWarnL,	(u8_t*)&u16IinOCWarnL, 	0x5d,	0x5d},
	{PMBusCmd_PoutOPFaultLimit, PMBusCmdT_RdWrWord,	PMBusDataT_Linear,	3,	3,	(u8_t*)&u16PoutOPFaultL,	(u8_t*)&u16PoutOPFaultL, 0x68,	0x68},	
    {PMBusCmd_PoutOPWarnLimit, 	PMBusCmdT_RdWrWord,	PMBusDataT_Linear,	3,	3,	(u8_t*)&u16PoutOPWarnL,	(u8_t*)&u16PoutOPWarnL, 0x6a,	0x6a},
	{PMBusCmd_PinOPWarnLimit, 	PMBusCmdT_RdWrWord,	PMBusDataT_Linear,	3,	3,	(u8_t*)&u16PinOPWarnL,	(u8_t*)&u16PinOPWarnL, 	0x6b,	0x6b},
	{PMBusCmd_MFRID, 		PMBusCmdT_RdWrBlock,	PMBusDataT_NN_Block,12,	12,	pu8MFRID,				pu8MFRID,				0x99,	0x99},
	{PMBusCmd_MFRModel, 	PMBusCmdT_RdWrBlock,	PMBusDataT_NN_Block,13,	13,	pu8MFRModel,			pu8MFRModel,			0x9a,	0x9a},
	{PMBusCmd_MFRRev, 		PMBusCmdT_RdWrBlock,	PMBusDataT_NN_Block,12,	12,	pu8MFRRev,				pu8MFRRev,				0x9b,	0x9b},
	{PMBusCmd_MFRLocation, 	PMBusCmdT_RdWrBlock,	PMBusDataT_NN_Block,12,	12,	pu8MFRLoc,				pu8MFRLoc,				0x9c,	0x9c},
	{PMBusCmd_MFRDate, 		PMBusCmdT_RdWrBlock,	PMBusDataT_NN_Block,12,	12,	pu8MFRDate,				pu8MFRDate,				0x9d,	0x9d},
	{PMBusCmd_MFRSerial, 	PMBusCmdT_RdWrBlock,	PMBusDataT_NN_Block,17,	17,	pu8MFRSerial,			pu8MFRSerial,			0x9e,	0x9e},
	{PMBusCmd_MFRSp2,		PMBusCmdT_RdWrByte,		PMBusDataT_NN_Block,2,	2,	&u8ChargeCurrSelect,	&u8ChargeCurrSelect,	0xd2,	0xd2},
    {PMBusCmd_MFRSp16,		PMBusCmdT_RdWrWord,     PMBusDataT_NN_Block,3,	3,  (u8_t*)&u16VrefOffline,	    (u8_t*)&u16VrefOffline,	0xe0,	0xe0},
    {PMBusCmd_MFRSp17,		PMBusCmdT_RdWrWord,	    PMBusDataT_NN_Block,3,	3,	(u8_t*)&u16VrefOnline,	    (u8_t*)&u16VrefOnline,	0xe1,	0xe1},
    {PMBusCmd_MFRSp20,      PMBusCmdT_RdWrByte,     PMBusDataT_NN_Block,2,  2,  &u8Calibration,             &u8Calibration,         0xe4,   0xe4},
    {PMBusCmd_MFRSp18,		PMBusCmdT_RdWrWord,	    PMBusDataT_NN_Block,3,	3,	(u8_t*)&u16TrimDuty,	    (u8_t*)&u16TrimDuty,	0xe2,	0xe2},
    {PMBusCmd_MFRSp29,      PMBusCmdT_RdWrWord,     PMBusDataT_NN_Block,3,  3,  (u8_t*)&u16CycleCntLimit,     (u8_t*)&u16CycleCntLimit,     0xed,   0xed},
    {PMBusCmd_UsrData0,     PMBusCmdT_RdWrWord,     PMBusDataT_Linear,3,  3,  (u8_t*)&u16BoostOTFaultL,     (u8_t*)&u16BoostOTFaultL,     0xb0,   0xb0},
    {PMBusCmd_UsrData1,     PMBusCmdT_RdWrWord,     PMBusDataT_Linear,3,  3,  (u8_t*)&u16BoostOTWarnL,      (u8_t*)&u16BoostOTWarnL,      0xb1,   0xb1},
    {PMBusCmd_UsrData2,     PMBusCmdT_RdWrWord,     PMBusDataT_Linear,3,  3,  (u8_t*)&u16AmbientOTFaultL,   (u8_t*)&u16AmbientOTFaultL,   0xb2,   0xb2},
    {PMBusCmd_UsrData3,     PMBusCmdT_RdWrWord,     PMBusDataT_Linear,3,  3,  (u8_t*)&u16AmbientOTWarnL,    (u8_t*)&u16AmbientOTWarnL,    0xb3,   0xb3},
    {PMBusCmd_UsrData4,     PMBusCmdT_RdWrWord,     PMBusDataT_Linear,3,  3,  (u8_t*)&u16DischargeCellOTFaultL,  (u8_t*)&u16DischargeCellOTFaultL,    0xb4,   0xb4},
    {PMBusCmd_UsrData5,     PMBusCmdT_RdWrWord,     PMBusDataT_Linear,3,  3,  (u8_t*)&u16DischargeCellOTWarnL,   (u8_t*)&u16DischargeCellOTWarnL,    0xb5,   0xb5},
    {PMBusCmd_UsrData6,     PMBusCmdT_RdWrWord,     PMBusDataT_Linear,3,  3,  (u8_t*)&u16ChargeCellOTFaultL,     (u8_t*)&u16ChargeCellOTFaultL,    0xb6,   0xb6},     
    {PMBusCmd_UsrData7,     PMBusCmdT_RdWrWord,     PMBusDataT_Linear,3,  3,  (u8_t*)&u16ChargeCellOTWarnL,      (u8_t*)&u16ChargeCellOTWarnL,     0xb7,   0xb7},
    {PMBusCmd_UsrData11, 	PMBusCmdT_RdWrWord,	    PMBusDataT_NN_Block,3,	3,	(u8_t*)&u16Modechange,			   (u8_t*)&u16Modechange,			0xbb,	0xbb},
    {PMBusCmd_MFRSp22, 		PMBusCmdT_RdWrWord,		PMBusDataT_NN_Block,	3,	3,	(u8_t*)&u16LastProtect_Index,	(u8_t*)&u16LastProtect_Index, 0xe6,  0xe6},
    {PMBusCmd_MFRSp30,		PMBusCmdT_RdWrWord,     PMBusDataT_NN_Block,3,	3,  (u8_t*)&u16BBS_Control,	    (u8_t*)&u16BBS_Control,	0xee,	0xee},
    {PMBusCmd_MFRSp40,		PMBusCmdT_RdWrWord,     PMBusDataT_NN_Block,3,	3,  (u8_t*)&u16DischargeLimit,	    (u8_t*)&u16DischargeLimit,	0xf8,	0xf8},
         
};
//define the status command structure
sPMBusCmdStatusStr_t sPMBusStatusCmd[USER_PMBUS_STNUM] =
{
	{PMBusCmd_StatusByte, 	PMBusCmdT_RdByte,		PMBusDataT_NN_Block,2,	0,	(u8_t*)&u16StatusP0Word,	(u8_t*)&u16StatusP0Word,0x78, 0x78,	(u8_t*)&u16StatusMP0Word,	(u8_t*)&u16StatusMP1Word},
	{PMBusCmd_StatusWord, 	PMBusCmdT_RdWord,		PMBusDataT_NN_Block,3,	0,	(u8_t*)&u16StatusP0Word,	(u8_t*)&u16StatusP0Word,0x79, 0x79,	(u8_t*)&u16StatusMP0Word,	(u8_t*)&u16StatusMP1Word},
	{PMBusCmd_StatusVout, 	PMBusCmdT_RdByte,		PMBusDataT_NN_Block,2,	0,	&u8StatusP0Vout,			&u8StatusP1Vout,		0x7a, 0x7a,	&u8StatusMP0Vout,			&u8StatusMP1Vout	},
	{PMBusCmd_StatusIout, 	PMBusCmdT_RdByte,		PMBusDataT_NN_Block,2,	0,	&u8StatusP0Iout,			&u8StatusP1Iout,		0x7b, 0x7b,	&u8StatusMP0Iout,			&u8StatusMP1Iout	},
	{PMBusCmd_StatusInput, 	PMBusCmdT_RdByte,		PMBusDataT_NN_Block,2,	0,	&u8StatusP0Input,			&u8StatusP1Input,		0x7c, 0x7c,	&u8StatusMP0Input,			&u8StatusMP1Input	},
	{PMBusCmd_StatusTemp, 	PMBusCmdT_RdByte,		PMBusDataT_NN_Block,2,	0,	&u8StatusP0Temp,			&u8StatusP1Temp,		0x7d, 0x7d,	&u8StatusMP0Temp,			&u8StatusMP1Temp	},
	{PMBusCmd_StatusCML, 	PMBusCmdT_RdByte,		PMBusDataT_NN_Block,2,	0,	&u8StatusP0CML,				&u8StatusP1CML,			0x7e, 0x7e,	&u8StatusMP0CML,			&u8StatusMP1CML		},
	{PMBusCmd_MFRSp0,		PMBusCmdT_RdByte,		PMBusDataT_NN_Block,2,	0,	&u8StatusP0BBU,				&u8StatusP1BBU,			0xd0, 0xd0,	&u8StatusMP0BBU,			&u8StatusMP1BBU		},
};

sPMBusCmdWrLimitStr_t sPMBusWrLimit[USER_PMBUS_WRLIMITNUM] =
{
	{PMBusCmd_VoutOVFaultLimit, 16,		5120, 	  7373},	//linear11, min 10v, max 14.4v
    {PMBusCmd_VoutOVWarnLimit,  16,		5120, 	  7373},	//linear11, min 10v, max 14.4v
    {PMBusCmd_VoutUVWarnLimit,  16,		5120, 	  7373},	//linear11, min 10v, max 14.4v
    {PMBusCmd_VoutUVFaultLimit, 16,		5120, 	  7373},	//linear11, min 10v, max 14.4v
    {PMBusCmd_IoutOCFaultLimit, 11,		50, 	200},	//linear11, min 50A, max 200A
    {PMBusCmd_IoutOCWarnLimit,  11,		50, 	200},	//linear11, min 50A, max 200A
    {PMBusCmd_OTFaultLimit,     11,		0, 	    250},	//linear11, min 0C,  max 150C  BUCK
    {PMBusCmd_OTWarnLimit,      11,		0, 	    250},	//linear11, min 0C,  max 150C  BUCK
    {PMBusCmd_VinOVFaultLimit,  11,		10, 	15},    //linear11, min 10v, max 15v
	{PMBusCmd_VinOVWarnLimit,   11,		10, 	15},	//linear11, min 10v, max 15v
	{PMBusCmd_VinUVWarnLimit, 	11,		8, 	    15},	//linear11, min 8v,  max 15v
    {PMBusCmd_VinUVFaultLimit, 	11,		8, 	    15},    //linear11, min 8v,  max 15v
    {PMBusCmd_IinOCFaultLimit, 	11,		0, 	   15},     //linear11, min 0A,  max 15A
	{PMBusCmd_IinOCWarnLimit, 	11,		0, 	   15},     //linear11, min 0A,  max 15A
    {PMBusCmd_PoutOPFaultLimit, 11,		0, 	   1600},   //linear11, min 0W,  max 1400W
    {PMBusCmd_PoutOPWarnLimit, 	11,		0, 	   1600},   //linear11, min 0W,  max 1400W
    {PMBusCmd_PinOPWarnLimit, 	11,		0, 	   140},    //linear11, min 0W,  max 140W
    {PMBusCmd_UsrData0, 	    11,		0, 	   150},    //linear11, min 0C,  max 150C  BOOST fault
    {PMBusCmd_UsrData1, 	    11,		0, 	   150},    //linear11, min 0C,  max 150C  BOOST warning
    {PMBusCmd_UsrData2,     	11,		0, 	   70},     //linear11, min 0C,  max 70C   Ambient fault
    {PMBusCmd_UsrData3, 	    11,		0, 	   70},     //linear11, min 0C,  max 70C   Ambient warning
    {PMBusCmd_UsrData4,     	11,		0, 	   80},     //linear11, min 0, max 70      Discharge cell fault 
    {PMBusCmd_UsrData5, 	    11,		0, 	   80},     //linear11, min 0, max 70      Discharge cell warning
    {PMBusCmd_UsrData6, 	    11,		0, 	   70},     //linear11, min 0, max 70      Charge cell fault
    {PMBusCmd_UsrData7, 	    11,		0, 	   70},     //linear11, min 0, max 70      Charge cell warning
    
    
};

//init the variables used in PMBus module before while(1) in main().
void PMBusTstInit(void)
{
	u8ClrFaultP0 = 0;
	u8ClrFaultP1 = 0;
    u8StoreDefaultAll = 0;;
    u8WriteProtect = 0x00;
    u8Operation = 0x80;              // 0x00 off, 0x80 0n
    u8OnOffConfig = 0x1f;
	u8Capability = 0x80;
	u8PMBusQuerry = 0;
    u8VoutMode = 0x17;
    u16VoutOVFaultL = 0x1b33;        // 13.6V  Linear 16 1b33
    u8VoutOVResponse = 0xC0;
	u16VoutOVWarnL = 0x1a66;         // 13.2V  Linear 16
	u16VoutUVFaultL = 0x16cc;        // 11.4V  Linear 16
    u8VoutUVResponse = 0xC0;
	u16VoutUVWarnL = 0x1733;         // 11.6V  Linear 16
	u16IoutOCFaultL = 0xeb70;        // 110A eb70
    u8IoutOCResponse = 0xC0;
	u16IoutOCWarnL = 0xeb20;         // 100A
    u16BuckOTFaultL = 0xf208;        // 130C
    u8BuckOTResponse = 0xC0;
	u16BuckOTWarnL = 0xf1cc;         // 115C
    u16VinOVFaultL = 0xD366;         // 13.6V
    u8VinOVResponse = 0xC0;
	u16VinOVWarnL = 0xd34c;          // 13.2V
	u16VinUVFaultL = 0xd2d9;         // 11.4V
    u8VinUVResponse = 0xC0;
	u16VinUVWarnL = 0xd2e6;          // 11.6V
	u16IinOCFaultL = 0xd280;         // 10A
    u8IinOCResponse = 0xC0;
	u16IinOCWarnL = 0xd260;          // 9.5A
	u16PoutOPWarnL = 0x0a58;         // 1200W
    u16PoutOPFaultL = 0x0a8a;        // 1300W
	u16PinOPWarnL = 0xebc0;          // 120W
	u16StatusP0Word = 0x0840;
	u8StatusP0Vout = 0x00;
	u8StatusP0Iout = 0x00;
	u8StatusP0Input = 0x00;
	u8StatusP0Temp = 0x00;
	u8StatusP0CML = 0x00;
	u16StatusP1Word = 0x0840;
	u8StatusP1Vout = 0x00;
	u8StatusP1Iout = 0x00;
	u8StatusP1Input = 0x00;
	u8StatusP1Temp = 0x00;
	u8StatusP1CML = 0x00;
	u8StatusMP0Byte = 11;
	u16StatusMP0Word = 0x55aa;
	u8StatusMP0Vout = 0xc3;
	u8StatusMP0Iout = 0x3c;
	u8StatusMP0Input = 0x1e;
	u8StatusMP0Temp = 0xe1;
	u8StatusMP0CML = 0x78;
	u8StatusMP1Byte = 22;
	u16StatusMP1Word = 0x6699;
	u8StatusMP1Vout = 0xd2;
	u8StatusMP1Iout = 0x2d;
	u8StatusMP1Input = 0xab;
	u8StatusMP1Temp = 0x23;
	u8StatusMP1CML = 0xa1;
	u16ReadVin = 58416;                // need update
	u16ReadIin = 2233;                 // need update
	u16ReadVout = 1250;                // need update
	u16ReadIout = 3388;                // need update
	u16ReadTemp1 = 779;                // need update
	u16ReadTemp2 = 836;                // need update
	u16ReadTemp3 = 3584;               // need update
	u16ReadPout = 23321;               // need update
	u16ReadPin = 25579;                // need update
	u8PMBusRev = 0x22;
	pu8MFRID[0] = 'L';
	pu8MFRID[1] = 'i';
	pu8MFRID[2] = 't';
	pu8MFRID[3] = 'e';
	pu8MFRID[4] = '-';
	pu8MFRID[5] = 'O';
    pu8MFRID[6] = 'n';
	pu8MFRModel[0] = 'B';
	pu8MFRModel[1] = 'M';
	pu8MFRModel[2] = '-';
	pu8MFRModel[3] = '1';
	pu8MFRModel[4] = '1';
	pu8MFRModel[5] = '1';
	pu8MFRModel[6] = '2';
    pu8MFRModel[7] = '-';
    pu8MFRModel[8] = '0';
    pu8MFRModel[9] = '1';
    pu8MFRModel[10] = 'X';
    pu8MFRRev[0] = 'S';
	pu8MFRRev[1] = 'R';
	pu8MFRRev[2] = '0';
	pu8MFRRev[3] = '2';
	pu8MFRRev[4] = '0';
	pu8MFRRev[5] = '0';
	pu8MFRRev[6] = '0';
	pu8MFRRev[7] = '0';
	pu8MFRLoc[0] = 'T';
	pu8MFRLoc[1] = 'a';
	pu8MFRLoc[2] = 'i';
	pu8MFRLoc[3] = 'p';
	pu8MFRLoc[4] = 'e';
    pu8MFRLoc[5] = 'i';
	pu8MFRDate[0] = '1';
	pu8MFRDate[1] = '7';
	pu8MFRDate[2] = '0';
	pu8MFRDate[3] = '6';
	pu8MFRDate[4] = '1';
	pu8MFRDate[5] = '4';
	pu8MFRSerial[0] ='1';
	pu8MFRSerial[1] ='2';
	pu8MFRSerial[2] ='3';
	pu8MFRSerial[3] ='4';
	pu8MFRSerial[4] ='5';
	pu8MFRSerial[5] ='6';
	pu8MFRSerial[6] ='7';
	pu8MFRSerial[7] ='8';
	pu8MFRSerial[8] ='9';
	pu8MFRSerial[9] ='0';
    pu8MFRSerial[10] ='0';
    pu8MFRSerial[11] ='0';
    pu8MFRSerial[12] ='0';
    pu8MFRSerial[13] ='0';
    pu8MFRSerial[14] ='0';
    pu8MFRSerial[15] ='0';
   	u16MFRVinMin = 0xd310;
	u16MFRVinMax = 0xd32e;
	u16MFRIinMax = 0xd280;
	u16MFRPinMax = 0xebf8;
	u16MFRVoutMin = 0x1747;
	u16MFRVoutMax = 0x1973;
	u16MFRIoutMax = 0xeae0;
	u16MFRPoutMax = 0x0a49;
	u16MFRAmbTMax = 0xe370;
	u16MFRAmbTMin = 0x0000;
	u16MFRMaxT1 = 0xf208;
	u16MFRMaxT2 = 0xeb20;
	u8StatusP0BBU = 0x00;
	u8StatusP1BBU = 0x00;
	u8StatusMP0BBU = 0x00;
	u8StatusMP1BBU = 0x00;
	u16StateBBU = 0x0000;                 // need update
	u8ChargeCurrSelect = 0x02;
	u16BattSN = 0x3738;                // need update
	u16BattVolt = 1325;                // need update
	pu8MFRBMSCompatible[0] = '-';
	pu8MFRBMSCompatible[1] = '-';
	pu8MFRBMSCompatible[2] = '-';
	pu8MFRBMSCompatible[3] = '-';
	pu8MFRBMSCompatible[4] = '-';
	pu8MFRBMSCompatible[5] = '-';
    pu8MFRBMSCompatible[6] = '-';
    pu8MFRBMSCompatible[7] = '-';
    pu8MFRBMSCompatible[8] = '-';
    pu8MFRBMSCompatible[9] = '-';
    pu8MFRBMSCompatible[10] = 0x00;
	u16BattCurr = 588;                 // need update
	u16BattASOC = 111;                 // need update
	u16BattRSOC = 777;                 // need update
	u16BattCapacity = 999;             // need update
	u16BattCycleCnt = 4098;            // need update
	u32BBURunTime = 0;             // need update
    u16BatteryStatus = 0x0000;         // need update
    u16BattProtecStatus = 0x0000;      // need update
    u16BattPFStatus = 0x0000;          // need update
    u16VrefOffline = 4200;             // 0x1068
    u16VrefOnline = 4105;              // 0x1009
    u16BattTemp = 0x0000;
    u8Calibration = 0x00;
    u32Protection_type = 0;
    u16LastProtect_Index = 0;
    u32LastProtect = 0;
    u16TrimDuty = 250;
    u16BattSOH = 0;
    u16DischargeRemainTime = 1500; 
    memset(pu8CellVoltage, 0x00, sizeof(pu8CellVoltage));
    u16BMSFWRev = 0;
    u16FCC = 0;
    u16DischargeCellOTFaultL = 0xea30;       // 70c
    u16DischargeCellOTWarnL = 0xea08;        // 65c
	u16ChargeCellOTFaultL = 0xe320;          // 50c
    u16ChargeCellOTWarnL = 0xe2d0;           // 45c
    u16CycleCntLimit = 300;
    u16BoostOTFaultL = 0xeb20;               // 100c
	u16BoostOTWarnL = 0xead0;                // 90c
	u16AmbientOTFaultL = 0xe370;             // 55c
	u16AmbientOTWarnL = 0xe320;              // 50c
    u16Cycle_Cnt_Offset = 0;
    pu8BatteryName[0] = 0;
    pu8BatteryName[1] = 0;
    pu8BatteryName[2] = 0;
    pu8BatteryName[3] = 0;
    pu8BatteryName[4] = 0;
    pu8BatteryName[5] = 0;
    pu8BatteryName[6] = 0;
    pu8BatteryName[7] = 0;
    pu8BatteryName[8] = 0;
    pu8BatteryName[9] = 0;
    pu8BatteryName[10] = 0;
    pu8BatteryName[11] = 0;
    pu8BatteryName[12] = 0;
    pu8BatteryName[13] = 0;
    pu8BatteryName[14] = 0;
    pu8BatteryName[15] = 0;
    pu8CellMFR[0] = 'S';
    pu8CellMFR[1] = 'A';
    pu8CellMFR[2] = 'M';
    pu8CellMFR[3] = 'S';
    pu8CellMFR[4] = 'U';
    pu8CellMFR[5] = 'N';
    pu8CellMFR[6] = 'G';
    pu8CellMFR[7] = '-';
    pu8CellMFR[8] = 'S';
    pu8CellMFR[9] = 'D';
    pu8CellMFR[10] = 'I';
    pu8CellModel[0] = 'I';
    pu8CellModel[1] = 'N';
    pu8CellModel[2] = 'R';
    pu8CellModel[3] = '1';
    pu8CellModel[4] = '8';
    pu8CellModel[5] = '6';
    pu8CellModel[6] = '5';
    pu8CellModel[7] = '0';
    pu8CellModel[8] = '-';
    pu8CellModel[9] = '2';
    pu8CellModel[10] = '0';
    pu8CellModel[11] = 'R';
    pu8CellModel[12] = 'M';
    pu8ProtocolVersion[0] = '0';
    pu8ProtocolVersion[1] = '0';
    pu8ProtocolVersion[2] = '0';
    pu8ProtocolVersion[3] = '0';
    pu8ProtocolVersion[4] = '0';
    pu8ProtocolVersion[5] = '0';
    pu8ProtocolVersion[6] = '0';
    pu8ProtocolVersion[7] = '0';
    pu8ProtocolVersion[8] = '0';
    pu8ProtocolVersion[9] = '0';
    pu8ProtocolVersion[10] = '0';
    pu8ProtocolVersion[11] = '0';
    pu8ProtocolVersion[12] = '0';
    pu8ProtocolVersion[13] = '0';
    pu8ProtocolVersion[14] = '0';
    pu8ProtocolVersion[15] = 'M'; 
    u16BBS_Control = 0;
    pu8BBUCompatible[0] = '0';
    pu8BBUCompatible[1] = '1';
    pu8BBUCompatible[2] = 0x00;
    pu8BBUCompatible[3] = 0x00;
    pu8BBUCompatible[4] = 0x00;
    pu8BBUCompatible[5] = 0x00;
    pu8BBUCompatible[6] = 0x00;
    pu8BBUCompatible[7] = 0x00;
    pu8BBUCompatible[8] = '0';
    pu8BBUCompatible[9] = '1';
    pu8BBUCompatible[10] = 0x00;
    u16Modechange = 0x0000;
    u16DischargeLimit = 70;
    
}

