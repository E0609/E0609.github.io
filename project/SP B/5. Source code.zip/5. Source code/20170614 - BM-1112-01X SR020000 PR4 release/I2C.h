#ifndef __I2C_H__
#define __I2C_H__

#include <p24FJ64GA006.h>
#include "bms_Pin_Define.h"
#include "GenericTypeDefs.h"

extern void I2C1_INIT(void);
void I2C1_Start(void);
void I2C1_Stop(void);
void I2C1_protect(void);
void I2C1_Reset(void);
char I2C1_deliver( unsigned char W_data);
unsigned char I2C1_receive(void);
void I2C1_ACK(void);
void I2C1_NACK(void);
extern void I2C1_Read (unsigned char ADDR, unsigned char COMMAND);
extern void I2C1_write(unsigned char ADDR, unsigned char COMMAND2, unsigned char DATA_low, unsigned char DATA_high);
extern void I2C1_Block_Read(unsigned char ADDR, unsigned char COMMAND, unsigned char COUNT);
extern void I2C1_Block_Write(unsigned char ADDR, unsigned char COMMAND, unsigned char COUNT);
extern void I2C2_INIT(void);
void I2C_slave_handler(void);
void I2C1_Restart(void);
void I2C1_Idle(void);
extern void I2C_Delay(unsigned int I2C_Delay_CNT);
extern void I2C1_EEPROM_Read(unsigned char ADDR, unsigned char COMMAND);
extern void I2C1_EEPROM_Write(unsigned char ADDR, unsigned char COMMAND, unsigned char DATA_low, unsigned char DATA_high);
extern void I2C1_EEPROM_Barcode_Block_Write(unsigned char ADDR, unsigned char COMMAND, unsigned char COUNT);
extern void I2C1_EEPROM_Barcode_Block_Read(unsigned char ADDR, unsigned char COMMAND, unsigned char COUNT);
extern void I2C1_EEPROM_Block_Write(unsigned char ADDR,unsigned char COMMAND, unsigned char COUNT);
extern void I2C1_EEPROM_Block_Read(unsigned char ADDR, unsigned char COMMAND, unsigned char COUNT);
extern void Initial_Block_Buff(void);

extern unsigned char data_low,data_high;

enum
{
	I2CWriteAddressState = 0x00,
	I2CReadAddressState = 0x04,
	I2CWriteDataState = 0x20,
	I2CReadDataState = 0x24
};

typedef struct
{
  unsigned Communication_Fail;
  unsigned New_Communication;
  unsigned Old_Communication;
  u16_t Communication_Fail_Count;
  u16_t PEC_error;


}I2C_State_t;

extern I2C_State_t I2C_State;

extern u8_t TempBlockBuff[16];
extern u8_t BatteryBlockBuff[40];

 
#endif
