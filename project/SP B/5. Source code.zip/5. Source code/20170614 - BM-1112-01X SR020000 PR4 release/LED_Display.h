#ifndef __LED_DISPLAY_H__
#define __LED_DISPLAY_H__

#include <p24FJ64GA006.h>
#include "bms_Pin_Define.h"
#include "Battery_status.h"	
#include "Charge_control.h"
#include "Discharge_control.h"
#include "Failure.h"
#include "FW_config.h"
#include "GenericTypeDefs.h"
#include "I2C.h"
#include "main.h"


void LED_Display_Red(void);
void LED_Display_Green(void);
void LED_Display_Amber(void);
void LED_Display_BlinkGreen(void);
void LED_Display_BlinkAmber(void);
void LED_Display_BlinkRed(void);
void LED_Display_off(void);
void LED_Test(void);
void LED_Factory_Test(void);

typedef struct
{
  u8_t count;
  u8_t flag;
  u16_t Test_count;
  u8_t Test_Flag;

}LED_Status_T;

extern LED_Status_T LED_Status;
#endif
