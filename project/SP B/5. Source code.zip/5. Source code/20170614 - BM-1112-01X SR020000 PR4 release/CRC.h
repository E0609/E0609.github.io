/********************************************************************************
* file				CRC.h
*
* brief				The file includes CRC8 checksum of the PMBus.
*
* note
*
* author			slade.fang
*
* version			01
*
* section History	2014/09/01	-	1st release
********************************************************************************/
#ifndef __CRC_H__
#define __CRC_H__


#include "GenericTypeDefs.h"

//extern void InitCRC8(void);
extern void CalCRC8(u8_t *pu8CRC, u8_t u8Data);
extern u16_t CalCRC16(u16_t u16seed, u8_t *pu8Msg, u16_t u16DataLen, u8_t u8SwapValue);

#endif 

