#include <p24FJ64GA006.h>
#include "bms_Pin_Define.h"
#include "GenericTypeDefs.h"
#include "I2C.h"
#include "Battery_status.h"
#include "Charge_control.h"
#include "Discharge_control.h"
#include "Failure.h"
#include "FW_Config.h"
#include "main.h"
#include "PMBus_status.h"
#include "PMBusData.h"
#include "BBU_content.h"



Charger_t Charger;

u8_t Charger_Test = 0;
u8_t Repeat = 15;
u8_t Repeat1 = 15;
u8_t Repeat2 = 15;
u8_t Repeat3 = 0;
u8_t Charger_Cell_OVP_cnt;
u8_t Charger_Fuse_Broke_Flag;
u16_t Charger_Fuse_Broke_cnt;
u8_t  Charger_Softstart_Finish_Flag = 0;
u8_t  Charger_First_state_Flag = 0;
u16_t Charger_First_state_Cnt = 0;


void Initial_Charger(void)
{
  if(SystemControl.bits.Flag_Online_Mode == 1)
  {
    SystemControl.bits.Flag_Online_Discharge = 0;                         // Online mode�U ��q�X���k�s
    SystemControl.bits.Flag_Online_Charge = 1;                            // Online mode�U �R�q�X�Х߰_
  }
  else if(SystemControl.bits.Flag_Offline_Mode == 1) 
  {
    SystemControl.bits.Flag_Offline_Discharge = 0;                        // Offline mode�U ��q�X���k�s
    SystemControl.bits.Flag_Offline_Charge = 1;                           // Offline mode�U �R�q�X�Х߰_
  }
//  Charger.Condition_state = Charger_state_Initial;		                  // ��l���A�� state_Initial
  Charger.FullyCapacity_Setpoint = Battery_FullyCharge_Capacity;          // �R���e�q�]�w���q���R���e�q
  Charger.FullyVoltage_Setpoint = Battery_FullyCharge_Voltage;            // �R���q���]�w���q���R���q��
  Charger.BackCapacity_Setpoint = Battery_BackCharge_Capacity;
  Charger.BackVoltage_Setpoint = Battery_BackCharge_Voltage;
  Charger.FullyRSOC_Setpoint = Battery_FullyCharge_RSOC;
  Charger.BackRSOC_Setpoint = Battery_BackCharge_RSOC;
 
}


void Enable_Charger(void)
{
  Charger_Test = 1;                                      // Start step count to charge cap
  CHG_MOS_IN = 1;
  System_Delay(9);
  CHG_MOS_IN = 0;
  System_Delay(31);
 
}

void Disable_Charger(void)
{
  Charger_Test = 0;
  CHG_MOS_IN = 0;
  asm("NOP");
  CHG_EN = 1;                                             // disable charger IC
  asm("NOP");
//  CHG_MOS_OUT = 0;
  Charger_Start_cnt = 0;                                  // when charge off reset step count
  Charger_Softstart_Finish_Flag = 0;                      // Clear Softsart Finish flag
  Charger_Fuse_Broke_cnt = 0;
}

//******************** Charger state app **********************

void Charger_state_set(u8_t state)                             // �i�J��Charge_control�ҧP�_��state 
{
   if(Charger.Condition_state == state)                    // If the state is same with last state return
       return;
   switch(state)
   {
     case Charger_state_Initial:

          Charger.state_Initial = 1;
          Charger.state_FullyCharge = 0;
          Charger.state_Charging = 0;
          Charger.state_Inhibit = 0;
          Charger.state_First = 0;
       break;

     case Charger_state_FullyCharge:

          Disable_Charger();        
          Charger.state_Initial = 0;
          Charger.state_FullyCharge = 1;
          Charger.state_Charging = 0;
          Charger.state_Inhibit = 0;
          Charger.state_First = 0;

       break;

     case Charger_state_Charging:

          Enable_Charger();                                     // Enable Charger

          Charger.state_Initial = 0;
          Charger.state_FullyCharge = 0;
          Charger.state_Charging = 1;
          Charger.state_Inhibit = 0;
          Charger.state_First = 0;
       break;

     case Charger_state_Inhibit:

          I_ref_Duty = 0;                                      // Not turn off Charger IC just adjust Duty
          Charger.state_Initial = 0;
          Charger.state_FullyCharge = 0;
          Charger.state_Charging = 0;
          Charger.state_Inhibit = 1;
          Charger.state_First = 0;
          System_Delay(20000);                                 // Delay time avoid Charging and Inhibit state change quickly
          System_Delay(20000);
          System_Delay(10000);
          System_Delay(10000);
  
       break;

     case Charger_state_Failure:

          Disable_Charger();
          
          SystemControl.bits.Flag_Failure = 1;

       break;

     case Charger_state_First:

          Charger_First_state_Flag = 1;
          Charger.state_Initial = 0;
          Charger.state_FullyCharge = 0;
          Charger.state_Charging = 0;
          Charger.state_Inhibit = 0;
          Charger.state_First = 1;
          Enable_Charger();                                     // Enable Charger          

       break;

     default:

       break;
   }
   
   Charger.Condition_state = state;
}

//******************* Charger state choose *******************//                 // �P�_Charger�i�J���ؼҦ�
void Charge_control(void)
{
   switch(Charger.Condition_state)
  {
//--------------------------------------------------------------------------------------------------------------------     
     case Charger_state_Initial:
       
       Charger_Failure_type_Detect();
       Charger_Warning_type_Detect();

       if(Warning_type.bits.Charger_out_regulation == 1 || Failure_type.bits.Ambient_OTP == 1)
       {
         Charger_state_set(Charger_state_Inhibit);
         SYS_PRES = 1;
         break;
       }
       
       if(Failure_type.bits.Charger_Input_UVP == 1 || Failure_type.bits.Charger_Input_OVP == 1 ||
          Failure_type.bits.Charger_Input_OCP == 1 || Failure_type.bits.Charger_Hardware_Fault == 1 ||
          Failure_type.bits.Charger_OverCharge == 1)
       {
         Charger_state_set(Charger_state_Failure);
         break;
       }

       if(SYS_PRES == 0)
       {
         Charger_state_set(Charger_state_First);
         break;
       }       
  
       if(Cell_Info.RSOC >= Charger.BackRSOC_Setpoint)      
       {
         Charger_state_set(Charger_state_FullyCharge);                           // �q���Ѿl�e�q > �q���R���e�q �i�R���q�Ҧ�
         break;
       }

       if(Cell_Info.RSOC < Charger.BackRSOC_Setpoint)     
       {
         Charger_state_set(Charger_state_Charging);								 // �q���Ѿl�e�q < �q���R���e�q �i�R�q�Ҧ�
       } 
 

       break;
//-----------------------------------------------------------------------------------------------------------
     case Charger_state_FullyCharge:

       Charger_Failure_type_Detect();
       Charger_Warning_type_Detect();

       if(Failure_type.bits.Charger_Input_UVP == 1 || Failure_type.bits.Charger_Input_OVP == 1 ||
          Failure_type.bits.Charger_Input_OCP == 1 || Failure_type.bits.Charger_Hardware_Fault == 1 ||
          Failure_type.bits.Charger_OverCharge == 1)
       {
          Charger_state_set(Charger_state_Failure);
           break;
       }

       else if(Failure_type.bits.Charger_Cell_OTP == 1 || Failure_type.bits.Charger_BOOST_OTP == 1 || 
               Warning_type.bits.Charger_out_regulation == 1 || Charge_Current_Zero_Flag == 1)
       {
          Charger_state_set(Charger_state_Inhibit);
           break;
       }

       else if(Cell_Info.RSOC < Charger.BackRSOC_Setpoint)
       {
          Charger_state_set(Charger_state_Charging);                             // �q���Ѿl�e�q < �q���R���e�q �i�R�q�Ҧ�
       }
       else if(Cell_Info.RSOC >= Charger.BackRSOC_Setpoint)
       {
          Charger_state_set(Charger_state_FullyCharge);                          // �q���Ѿl�e�q > �q���R���e�q �i�R���q�Ҧ�
       }

       break;
//-----------------------------------------------------------------------------------------------------------
     case Charger_state_Charging:
      
       Charger_Failure_type_Detect();
       Charger_Warning_type_Detect();

     if(Charge_Current_Calibration_Delay_Cnt > 100)
     {    
         if(Battery_Current_Read_Flag == 1)
         {
           if(Cell_Info.Current < Expect_Charge_Current)
           {
             Expect_I_ref_Duty = Expect_I_ref_Duty + ((Expect_Charge_Current - Cell_Info.Current) >> 1); 
           }
           else if(Cell_Info.Current > Expect_Charge_Current)
           {
             Expect_I_ref_Duty = Expect_I_ref_Duty - ((Cell_Info.Current - Expect_Charge_Current) >> 1);
           }
/*
           if(Cell_Info.Current < (Expect_Charge_Current - 200))
           {
             Expect_I_ref_Duty = Expect_I_ref_Duty + 20;
           }
           else if(Cell_Info.Current > (Expect_Charge_Current + 200))
           {
             Expect_I_ref_Duty = Expect_I_ref_Duty - 20;
           }
           else if(Cell_Info.Current < (Expect_Charge_Current - 100))
           {
             Expect_I_ref_Duty = Expect_I_ref_Duty + 10;
           }
           else if(Cell_Info.Current > (Expect_Charge_Current + 100))
           {
             Expect_I_ref_Duty = Expect_I_ref_Duty - 10;
           }
*/
           if(Cell_Info.Current < (Expect_Charge_Current - 50))
           {
             Expect_I_ref_Duty = Expect_I_ref_Duty + 5;
           }
           else if(Cell_Info.Current > (Expect_Charge_Current + 50))
           {
             Expect_I_ref_Duty = Expect_I_ref_Duty - 5;
           }		
           else if(Cell_Info.Current < (Expect_Charge_Current - 10))
           {
             Expect_I_ref_Duty = Expect_I_ref_Duty + 1;
           }
           else if(Cell_Info.Current > (Expect_Charge_Current + 10)) 
           {
             Expect_I_ref_Duty = Expect_I_ref_Duty - 1;
           }
           else if(Cell_Info.Current < (Expect_Charge_Current - 8))
           {
             asm("NOP");
           }
           else if(Cell_Info.Current > (Expect_Charge_Current + 8)) 
           {   
             asm("NOP");          
           }
 
           if(Expect_I_ref_Duty >= 4300)
           {
             Expect_I_ref_Duty = 4300;
           }
         
           Battery_Current_Read_Flag = 0;
         }
     } 


  
       Charger_Failure_type_Detect();
       Charger_Warning_type_Detect();
       if(Failure_type.bits.Charger_Input_UVP == 1 || Failure_type.bits.Charger_Input_OVP == 1 ||
          Failure_type.bits.Charger_Input_OCP == 1 || Failure_type.bits.Charger_Hardware_Fault == 1 ||
          Failure_type.bits.Charger_OverCharge == 1)
       {
          Charger_state_set(Charger_state_Failure);
           break;
       }

       else if(Failure_type.bits.Charger_Cell_OTP == 1 || Failure_type.bits.Charger_BOOST_OTP == 1 || 
               Warning_type.bits.Charger_out_regulation == 1 || Charge_Current_Zero_Flag == 1)
       {
          Charger_state_set(Charger_state_Inhibit);
           break;
       }

       else if(Cell_Info.RSOC >= Charger.FullyRSOC_Setpoint)
       {
          Charger_state_set(Charger_state_FullyCharge);                          // �q���Ѿl�e�q > �q���R���e�q �i�R���q�Ҧ�
           break;
       }
     
       else if(Failure_type.bits.Charger_Input_UVP == 0 && Failure_type.bits.Charger_Input_OVP == 0 && Failure_type.bits.Charger_Input_OCP == 0 &&
          Failure_type.bits.Charger_BOOST_OTP == 0 && Failure_type.bits.Charger_Cell_OTP == 0 && Warning_type.bits.Charger_out_regulation == 0 &&
          Failure_type.bits.Charger_Hardware_Fault == 0 && Failure_type.bits.Charger_OverCharge == 0)
       {
          Charger_state_set(Charger_state_Charging);
           break;
       }
           
       
       break;
//------------------------------------------------------------------------------------------------------------------------------

     case Charger_state_Inhibit:

       Charger_Failure_type_Detect();
       Charger_Warning_type_Detect();

       if(Failure_type.bits.Charger_Input_UVP == 1 || Failure_type.bits.Charger_Input_OVP == 1
          || Failure_type.bits.Charger_Hardware_Fault == 1 || Failure_type.bits.Charger_OverCharge == 1)
       {
          Charger_state_set(Charger_state_Failure);
           break;
       }
 
       if(BBU_Info.BusVoltage >= Charging_Regulation_Low && BBU_Info.BusVoltage <= Charging_Regulation_High)
       {
          Warning_type.bits.Charger_out_regulation = 0;
       }
       else
       {
          Warning_type.bits.Charger_out_regulation = 1;
       }
       
       
       if(Cell_Info.Temp < Charging_Cell_OT_Recover_Threshold)
       {
          Failure_type.bits.Charger_Cell_OTP = 0;
       }

       if(BBU_Info.BOOST_Temp < Charging_BOOST_OT_Recover_Threshold)
       {
          Failure_type.bits.Charger_BOOST_OTP = 0;
       }
        
       if(Failure_type.bits.Charger_Cell_OTP == 0 && Failure_type.bits.Charger_BOOST_OTP == 0 && Warning_type.bits.Charger_out_regulation == 0 &&
          Failure_type.bits.Charger_Input_UVP == 0 && Failure_type.bits.Charger_Input_OVP == 0 && Charge_Current_Zero_Flag == 0 && Failure_type.bits.Ambient_OTP == 0
          && Failure_type.bits.Charger_Hardware_Fault == 0 && Failure_type.bits.Charger_OverCharge == 0)
       {
 		  Charger_state_set(Charger_state_Initial);
       }
       else
       {
          Charger_state_set(Charger_state_Inhibit);
       }

      
       break;
//------------------------------------------------------------------------------------------------------------------------------
     
     case Charger_state_First:

       Charger_Failure_type_Detect();
       Charger_Warning_type_Detect();

       if(Failure_type.bits.Charger_Input_UVP == 1 || Failure_type.bits.Charger_Input_OVP == 1
          || Failure_type.bits.Charger_Hardware_Fault == 1 || Failure_type.bits.Charger_OverCharge == 1)
       {
          Charger_state_set(Charger_state_Failure);
           break;
       }
       else if(Charger_First_state_Cnt >= 400)
       {
          Charger_First_state_Flag = 0;
          Charger_state_set(Charger_state_Initial);
           break;
       }
       else
       {
          Charger_state_set(Charger_state_First);
       }
        

       break;

//------------------------------------------------------------------------------------------------------------------------------
     default:

       break;   
  }   

}


/****************************************************************/
void Charger_Failure_type_Detect(void)
{

      if(BBU_Info.BusVoltage < Expect_Input_UV_Protection)                   // Bus�q���C���J�q��UV�O�@�I �i�J�T��R�q�Ҧ�
      {
        Charger_Delay.UV_Fault_Flag = 1;        
        if(Charger_Delay.UV_Fault_Cnt >= 10)
        { 
          Failure_type.bits.Charger_Input_UVP = 1;        
          u8StatusP0Input = (u8StatusP0Input | Status_Input_bits_Vin_UV_Fault);
          u8StatusP1Input = (u8StatusP1Input | Status_Input_bits_Vin_UV_Fault);
          u8StatusP0Input = (u8StatusP0Input | Status_Input_bits_Unit_Off_For_Low_Input_Voltage);
          u8StatusP1Input = (u8StatusP1Input | Status_Input_bits_Unit_Off_For_Low_Input_Voltage);
          u16StatusP0Word = (u16StatusP0Word | Status_Word_bits_Input);
          u16StatusP1Word = (u16StatusP1Word | Status_Word_bits_Input);
          u16StatusP0Word = (u16StatusP0Word | Status_Word_bits_Vin_UV_Fault);
          u16StatusP1Word = (u16StatusP1Word | Status_Word_bits_Vin_UV_Fault); 
        }                    
      }
      else
      {
        Charger_Delay.UV_Fault_Flag = 0;
        Charger_Delay.UV_Fault_Cnt = 0;
      } 

      if(BBU_Info.BusVoltage > Expect_Input_OV_Protection)              // Bus�q�������J�q��OV�O�@�I �i�J�T��R�q�Ҧ�
      {
         Charger_Delay.OV_Fault_Flag = 1;
         if(Charger_Delay.OV_Fault_Cnt >= 10) 
         {
           Failure_type.bits.Charger_Input_OVP = 1;
           u8StatusP0Input = (u8StatusP0Input | Status_Input_bits_Vin_OV_Fault);
           u8StatusP1Input = (u8StatusP1Input | Status_Input_bits_Vin_OV_Fault);
           u16StatusP0Word = (u16StatusP0Word | Status_Word_bits_Input);
           u16StatusP1Word = (u16StatusP1Word | Status_Word_bits_Input);
         }
      }
      else
      {
         Charger_Delay.OV_Fault_Flag = 0;
         Charger_Delay.OV_Fault_Cnt = 0;
      }
    
      if(Cell_Info.Temp > Expect_Charger_Cell_OT_Protection)                // �b�R�q�ɹq���ūװ���q���R�q����ū�
      {
        Charger_Delay.Cell_OT_Fault_Flag = 1;
        if(Charger_Delay.Cell_OT_Fault_Cnt >= 100)
        {
          Failure_type.bits.Charger_Cell_OTP = 1;
          u8StatusP0Temp = (u8StatusP0Temp | Status_Temperature_bits_OT_Fault);
          u8StatusP1Temp = (u8StatusP1Temp | Status_Temperature_bits_OT_Fault); 
        }                                 
      }
      else
      {
        Charger_Delay.Cell_OT_Fault_Flag = 0;
        Charger_Delay.Cell_OT_Fault_Cnt = 0;
      }

      if(BBU_Info.Iin >= Expect_Input_OC_Protection)
      {
         Charger_Delay.OC_Fault_Flag = 1;
         if(Charger_Delay.OC_Fault_Cnt >= 10)
         {
            Failure_type.bits.Charger_Input_OCP = 1;
            u8StatusP0Input = (u8StatusP0Input | Status_Input_bits_Iin_OC_Fault);
            u8StatusP1Input = (u8StatusP1Input | Status_Input_bits_Iin_OC_Fault);
            u16StatusP0Word = (u16StatusP0Word | Status_Word_bits_Input);
            u16StatusP1Word = (u16StatusP1Word | Status_Word_bits_Input);
         }       
      }
      else
      {
         Charger_Delay.OC_Fault_Flag = 0;
         Charger_Delay.OC_Fault_Cnt = 0;
      }
      

      if(BBU_Info.BOOST_Temp > Expect_Charging_BOOST_OT_Protection)     // �b�R�q��BOOST�ū׹L��
      {
        Charger_Delay.Boost_OT_Fault_Flag = 1;
        if(Charger_Delay.Boost_OT_Fault_Cnt >= 100)
        {
          Failure_type.bits.Charger_BOOST_OTP = 1;
          u8StatusP0Temp = (u8StatusP0Temp | Status_Temperature_bits_OT_Fault);
          u8StatusP1Temp = (u8StatusP1Temp | Status_Temperature_bits_OT_Fault);								 
        }
      }
      else
      {
        Charger_Delay.Boost_OT_Fault_Flag = 0;
        Charger_Delay.Boost_OT_Fault_Cnt = 0;
      }

      if(Charger_Cell_OVP_cnt >= 10)
      {
        Failure_type.bits.Charger_OverCharge = 1;
        u8StatusP0BBU = u8StatusP0BBU | Status_BBU_bits_Battery_Over_Charge;
        u8StatusP1BBU = u8StatusP1BBU | Status_BBU_bits_Battery_Over_Charge;
        
      }

      if(CHG_EN == 0 && I_ref_Duty > 0 && Charger_Softstart_Finish_Flag == 1 && Charger.state_Charging == 1)
      {
        if(Cell_Info.Current >= -1000 && Cell_Info.Current <= 0)
        {
          Charger_Fuse_Broke_Flag = 1;
        }
        else
        {
          Charger_Fuse_Broke_Flag = 0;
        }

        if(Charger_Fuse_Broke_cnt >= 10000)
        {
          Failure_type.bits.Charger_Hardware_Fault = 1;
          Charger_Fuse_Broke_cnt = 10000;         
        }       
      }
      else
      {
         Charger_Fuse_Broke_Flag = 0;
      } 

}


/****************************************************************/
void Charger_Warning_type_Detect(void)
{
    u8_t i;

    i = Charger.Condition_state;

    if(i == Charger_state_Charging)
    {
      if(BBU_Info.BusVoltage <= Charging_Regulation_Hys_High && BBU_Info.BusVoltage >= Charging_Regulation_Hys_Low)
      { 
         Warning_type.bits.Charger_out_regulation = 0;
      }
      else
      {
         Warning_type.bits.Charger_out_regulation = 1;
      }
    }
    else
    {
      if(BBU_Info.BusVoltage <= Charging_Regulation_High && BBU_Info.BusVoltage >= Charging_Regulation_Low)
      { 
         Warning_type.bits.Charger_out_regulation = 0;
      }
      else
      {
         Warning_type.bits.Charger_out_regulation = 1;
      }

    }        
  
//---------------------------------------------------------------------------------------------//
     if(BBU_Info.BusVoltage <= Expect_Input_UV_Warning)
     {
        Charger_Delay.UV_Warning_Flag = 1;
        if(Charger_Delay.UV_Warning_Cnt >= 10)
        {
          Warning_type.bits.Vin_UV_Warning = 1;
          u8StatusP0Input = (u8StatusP0Input | Status_Input_bits_Vin_UV_Warning);
          u8StatusP1Input = (u8StatusP1Input | Status_Input_bits_Vin_UV_Warning);
        }
     }
     else
     {
       Charger_Delay.UV_Warning_Flag = 0;
       Charger_Delay.UV_Warning_Cnt = 0;
     }

     if(BBU_Info.BusVoltage >= Expect_Input_OV_Warning)
     {
       Charger_Delay.OV_Warning_Flag = 1;
       if(Charger_Delay.OV_Warning_Cnt >= 10)
       {
         Warning_type.bits.Vin_OV_Warning = 1;
         u8StatusP0Input = (u8StatusP0Input | Status_Input_bits_Vin_OV_Warning);
         u8StatusP1Input = (u8StatusP1Input | Status_Input_bits_Vin_OV_Warning);
       }  
     }
     else
     {
       Charger_Delay.OV_Warning_Flag = 0;
       Charger_Delay.OV_Warning_Cnt = 0;
     }


     if(Cell_Info.Temp >= Expect_Charger_Cell_OT_Warning)
     {
        Charger_Delay.Cell_OT_Warning_Flag = 1;
        if(Charger_Delay.Cell_OT_Warning_Cnt >= 100)
        {
          Warning_type.bits.Charger_Cell_OT_Warning = 1;       
        }
     }
     else
     {
        Charger_Delay.Cell_OT_Warning_Flag = 0;
        Charger_Delay.Cell_OT_Warning_Cnt = 0;
     }

     if(BBU_Info.BOOST_Temp >= Expect_Charging_BOOST_OT_Warning)
     {
        Charger_Delay.Boost_OT_Warning_Flag = 1;
        if(Charger_Delay.Boost_OT_Warning_Cnt >= 100)
        {
          Warning_type.bits.Charger_BOOST_OT_Warning = 1;            
        }
     }
     else
     {
        Charger_Delay.Boost_OT_Warning_Flag = 0;
        Charger_Delay.Boost_OT_Warning_Cnt = 0;
     }

     if(BBU_Info.Iin >= Expect_Input_OC_Warning )
     {
        Charger_Delay.OC_Warning_Flag = 1;
        if(Charger_Delay.OC_Warning_Cnt >= 100)
        {
          Warning_type.bits.Iin_OC_Warning = 1;
          u8StatusP0Input = (u8StatusP0Input | Status_Input_bits_Iin_OC_Warning);
          u8StatusP1Input = (u8StatusP1Input | Status_Input_bits_Iin_OC_Warning);
        }
     }
     else 
     {
        Charger_Delay.OC_Warning_Flag = 0;
        Charger_Delay.OC_Warning_Cnt = 0;
     }

     if(BBU_Info.Pin >= Expect_Input_OP_Warning)
     {
        Charger_Delay.OP_Warning_Flag = 1;
        if(Charger_Delay.OP_Warning_Cnt >= 100)
        {
          Warning_type.bits.Pin_OP_Warning = 1;
          u8StatusP0Input = (u8StatusP0Input | Status_Input_bits_Pin_OP_Warning);
          u8StatusP1Input = (u8StatusP1Input | Status_Input_bits_Pin_OP_Warning);
        }
     }
     else
     {
        Charger_Delay.OP_Warning_Flag = 0;
        Charger_Delay.OP_Warning_Cnt = 0;
     }


    if(Warning_type.bits.Vin_UV_Warning == 1 || Warning_type.bits.Iin_OC_Warning == 1 || Warning_type.bits.Pin_OP_Warning == 1 || Warning_type.bits.Vin_OV_Warning == 1)
    {
      u16StatusP0Word = (u16StatusP0Word | Status_Word_bits_Input);
      u16StatusP1Word = (u16StatusP1Word | Status_Word_bits_Input);
    }

    if(Warning_type.bits.Charger_Cell_OT_Warning == 1 || Warning_type.bits.Charger_BOOST_OT_Warning == 1)
    { 
      u8StatusP0Temp = (u8StatusP0Temp | Status_Temperature_bits_OT_Warning);
      u8StatusP1Temp = (u8StatusP1Temp | Status_Temperature_bits_OT_Warning);
    }    
         
}

