#include <stdio.h>
#include <math.h>
#include "bms_Pin_Define.h"
#include <p24FJ64GA006.h>


int a;
int b;
int c;
int d;

unsigned int Real_to_Literal (long real_value, unsigned int gain)  
{
// TEST3 = 0;
  int exponent = 0;
  int literal;
  int complex;
  float n;
  unsigned long abs_real_value;
  unsigned int mantissa;
  long rule;
  

    if(real_value < 0)
    {
      abs_real_value = -real_value;
    }
    else 
    {
      abs_real_value = real_value;
    } 
   
    if(real_value == 0)
    {
       n = 0;
    }
   
    else
    {
       n = 1023;
	   n *= gain;
	   n/=abs_real_value;
    } 
    
    if(n >= 1)
    {
      while(n >= 2)
      {
        n = n/2;      
        exponent++;
      }
        if(exponent != 0)
        {
         complex = (16 - exponent) | 16;
        }
        else
        {
         complex = 0;
        }
        if(real_value > 0)
        {
           rule = abs_real_value * pow(2,exponent);
           mantissa = rule / gain;
        }

        else
        {
           rule = abs_real_value * pow(2,exponent);
           mantissa = (1024 -(rule/gain)) + 1024;          //mantissa is nagative need use 2 compent
      
        }
           literal = (complex << 11)+ mantissa;

     }

    else if(n < 1 && n != 0)
    {
      while(n <= 1)
      {
        n = n*2;
        exponent++;
      }
       

 
        if(real_value > 0)
        {
           mantissa = (abs_real_value * pow(2,-exponent))/gain;
        }

        else
        {
          mantissa = (1024 -((abs_real_value/gain) * pow(2,-exponent))) + 1024;    // mantissa is nagative need use 2 compent  
        } 

      literal = (exponent << 11)+ mantissa;


    }

    else if(n == 0)
    {
      
      literal =  0;
    }

//  TEST3 = 1;  
  return literal;
} 



long Literal_to_Real (unsigned int literal_value, unsigned int gain)
{
  int exponent;
  int mantissa;
  long real_value;
  int n;
  int Y;
   exponent = (literal_value & 0xF800) >> 11;
   Y = (literal_value & 0x7FF);

  if(exponent & 0x10)
  {
     n = -(16 - (exponent - 0x10));
  }
  else
  {
     n = exponent;
  }

  if(Y & 0x0400)
  {
     mantissa = -(1024 - (Y - 0x0400));

  }
  else
  {
     mantissa = Y;
  }

  real_value = pow(2,n) * mantissa * gain; 
 

  return real_value;
}

unsigned int Real_To_Literal_ForVout(unsigned int value)
{
	unsigned long tmp = value;

	tmp = tmp << 9;
	tmp /= 1000;

	return tmp;
}

unsigned int Literal_To_Real_ForVout(unsigned int value)
{
    float tmp1 = 0;
    unsigned long tmp = value;
    tmp1 = tmp*1000;
    tmp1 /= 512;
  
    return tmp1;
} 
 




