/********************************************************************************
* file				SI2CDrv.h
*
* brief				The file includes the setting of the I2C peripheral. The driver
*					is created for Microchip PIC32MX series and use interrupt. 
*					Other MCU needs to modify the source code.
*
* note
*
* author			slade.fang
*
* version			01
*
* section History	2014/09/01	-	1st release
********************************************************************************/
#ifndef SI2CDRV_H
#define SI2CDRV_H

#include "bms_Pin_Define.h"
#include "GenericTypeDefs.h"
#include "I2C.h"
#include "main.h"
#include <p24FJ64GA006.h>
#include "PMBusData.h"
#include "PMBusAPP.h"

extern u16_t RAB;

//the enum is used to get error count, the error is difference from MCUs
typedef enum
{
	RxOverflow,				//registers indicate the status, not fault, the PMBus master would re-transmit the byte
	TxOverflow,				//registers indicate the status, not fault, the PMBus slave would re-transmit the byte
	ClockHold,				//if the clock hold over 25ms, the driver would record the error count and re-set the driver module
	RxBuffOver,				//The master transmit too many bytes of the transcation.
	ErrItems
}eSI2CErr_t;

//define the UART configuration  
#define SI2C_RX_BUFF		40							//define the SI2C rx buffer used in the driver, it is the user's(application) reponsibilit to allocate the rx buffer according to the application.
#define SI2cCLKHold1ms			System_Run.Time_10ms                               							//the driver is used for PM bus.

extern void SI2CDrvInit(void);
extern u16_t GetSI2CErrCnt(eSI2CErr_t);
extern void ClearSI2CErr(eSI2CErr_t);
extern void SI2CTxWrite(u8_t* pu8Buff, u16_t u16Length);
extern u8_t GetSI2CRxIdx(u8_t* pu8Buff, u16_t u16BuffLimit);
extern void CheckClockHold(void);
extern void ResetSI2CDrv(void);
extern u8_t CheckBusStatus(void);

extern void SI2C2_ISR2(void);
extern void SI2CISR(void);

#endif
