#ifndef __CHARGE_CONTROL_H__
#define __CHARGE_CONTROL_H__

#include <p24FJ64GA006.h>
#include "bms_Pin_Define.h"
#include "GenericTypeDefs.h"
#include "I2C.h"
#include "Battery_status.h"
#include "Discharge_control.h"
#include "Failure.h"
#include "FW_Config.h"

void Charge_control(void);
void Enable_Charger(void);
void Disable_Charger(void);
void Charger_state_set(u8_t state);
void Stop_I_ref_PWM(void);
void Start_I_ref_PWM(void);
void Initial_Charger(void);
void Charger_Failure_type_Detect(void);
void Charger_Warning_type_Detect(void);

extern u8_t Repeat;
extern u8_t Repeat1;
extern u8_t Repeat2;
extern u8_t Repeat3;
extern u8_t Charger_Test;
extern u8_t Charger_Cell_OVP_cnt;
extern u8_t Charger_Fuse_Broke_Flag;
extern u16_t Charger_Fuse_Broke_cnt;
extern u8_t  Charger_Softstart_Finish_Flag;
extern u8_t  Charger_First_state_Flag;
extern u16_t Charger_First_state_Cnt;


enum
{
  Charger_state_Initial,
  Charger_state_FullyCharge,
  Charger_state_Charging,
  Charger_state_Inhibit,
  Charger_state_Failure,
  Charger_state_First

};

typedef struct 
{
  u8_t  Condition_state;
  u16_t FullyCapacity_Setpoint;
  u32_t Current_Setpoint;
  u16_t FullyVoltage_Setpoint;
  u8_t  state_Initial;
  u8_t  state_FullyCharge;
  u8_t  state_Charging;
  u8_t  state_Inhibit;
  u8_t  state_First;
  u16_t BackCapacity_Setpoint;
  u16_t BackVoltage_Setpoint;
  u8_t  FullyRSOC_Setpoint;
  u8_t  BackRSOC_Setpoint;
  
}Charger_t;

extern Charger_t Charger;



#endif
