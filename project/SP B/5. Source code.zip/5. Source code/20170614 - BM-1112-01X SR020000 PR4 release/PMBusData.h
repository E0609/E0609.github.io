/********************************************************************************
* file				PMBusData.h
*
* brief				The file includes the function and data structure/variables
*					for the PMBus protocol
* note
*
* author			slade.fang
*
* version			01
*
* section History	2014/09/01	-	1st release
********************************************************************************/
#ifndef __PMBUS_DATA_H__
#define __PMBUS_DATA_H__  

#include "PMBusApp.h"

#define USER_PMBUS_RDNUM 	60
#define USER_PMBUS_WRNUM	46
#define USER_PMBUS_WRLIMITNUM	26
#define USER_PMBUS_STNUM	8



//The data structures are used for PMBusApp.c, User must define for the application individually.
extern sPMBusCmdRdStr_t sPMBusRdCmd[USER_PMBUS_RDNUM];
extern sPMBusCmdWrStr_t sPMBusWrCmd[USER_PMBUS_WRNUM];
extern sPMBusCmdStatusStr_t sPMBusStatusCmd[USER_PMBUS_STNUM];
extern sPMBusCmdWrLimitStr_t sPMBusWrLimit[USER_PMBUS_WRLIMITNUM];

extern void PMBusTstInit(void);

extern u8_t PMBus_CurrPage;
extern u8_t PMBus_WrProtect;
extern u8_t u8ClrFaultP0;
extern u8_t u8ClrFaultP1;
extern u8_t u8Operation;
extern u8_t u8OnOffConfig;     
extern u8_t u8Capability;
extern u8_t u8PMBusQuerry;
extern u8_t u8VoutMode;
extern u16_t u16VoutOVFaultL;
extern u8_t  u8VoutOVResponse;
extern u16_t u16VoutOVWarnL;
extern u16_t u16VoutUVFaultL;
extern u8_t  u8VoutUVResponse;
extern u16_t u16VoutUVWarnL;
extern u16_t u16IoutOCFaultL;
extern u8_t  u8IoutOCResponse;
extern u16_t u16IoutOCWarnL;
extern u16_t u16BuckOTFaultL;
extern u8_t  u8BuckOTResponse;
extern u16_t u16BuckOTWarnL;
extern u16_t u16VinOVFaultL;
extern u8_t  u8VinOVResponse;
extern u16_t u16VinOVWarnL;
extern u16_t u16VinUVFaultL;
extern u8_t  u8VinUVResponse;
extern u16_t u16VinUVWarnL;
extern u16_t u16IinOCFaultL;
extern u8_t  u8IinOCResponse;
extern u16_t u16IinOCWarnL;
extern u16_t u16PoutOPFaultL;
extern u16_t u16PoutOPWarnL;
extern u16_t u16PinOPWarnL;
extern u16_t u16StatusP0Word;
extern u8_t u8StatusP0Vout;
extern u8_t u8StatusP0Iout;
extern u8_t u8StatusP0Input;
extern u8_t u8StatusP0Temp;
extern u8_t u8StatusP0CML;
extern u16_t u16StatusP1Word;
extern u8_t u8StatusP1Vout;
extern u8_t u8StatusP1Iout;
extern u8_t u8StatusP1Input;
extern u8_t u8StatusP1Temp;
extern u8_t u8StatusP1CML;
extern u8_t u8StatusMP0Byte;
extern u16_t u16StatusMP0Word;
extern u8_t u8StatusMP0Vout;
extern u8_t u8StatusMP0Iout;
extern u8_t u8StatusMP0Input;
extern u8_t u8StatusMP0Temp;
extern u8_t u8StatusMP0CML;
extern u8_t u8StatusMP1Byte;
extern u16_t u16StatusMP1Word;
extern u8_t u8StatusMP1Vout;
extern u8_t u8StatusMP1Iout;
extern u8_t u8StatusMP1Input;
extern u8_t u8StatusMP1Temp;
extern u8_t u8StatusMP1CML;
extern u16_t u16ReadVin;
extern u16_t u16ReadIin;
extern u16_t u16ReadVout;
extern u16_t u16ReadIout;
extern u16_t u16ReadTemp1;
extern u16_t u16ReadTemp2;
extern u16_t u16ReadTemp3;
extern u16_t u16ReadPout;
extern u16_t u16ReadPin;
extern u8_t u8PMBusRev;
extern u8_t pu8MFRID[10];
extern u8_t pu8MFRModel[12];
extern u8_t pu8MFRRev[10];
extern u8_t pu8MFRLoc[10];
extern u8_t pu8MFRDate[10];
extern u8_t pu8MFRSerial[16];
extern u16_t u16MFRVinMin;
extern u16_t u16MFRVinMax;
extern u16_t u16MFRIinMax;
extern u16_t u16MFRPinMax;
extern u16_t u16MFRVoutMin;
extern u16_t u16MFRVoutMax;
extern u16_t u16MFRIoutMax;
extern u16_t u16MFRPoutMax;
extern u16_t u16MFRAmbTMax;
extern u16_t u16MFRAmbTMin;
extern u16_t u16MFRMaxT1;
extern u16_t u16MFRMaxT2;
extern u8_t u8StatusP0BBU;
extern u8_t u8StatusP1BBU;
extern u8_t u8StatusMP0BBU;
extern u8_t u8StatusMP1BBU;
extern u16_t u16StateBBU;
extern u8_t u8ChargeCurrSelect;
extern u16_t u16BattSN;
extern u16_t u16BattVolt;
extern u8_t  pu8MFRBMSCompatible[11];
extern u16_t u16BattCurr;
extern u16_t u16BattASOC;
extern u16_t u16BattRSOC;
extern u16_t u16BattCapacity;
extern u16_t u16BattCycleCnt;
extern u32_t u32BBURunTime;
extern u16_t u16BatteryStatus;
extern u16_t u16BattProtecStatus;
extern u16_t u16BattPFStatus;
extern u16_t u16VrefOffline;
extern u16_t u16VrefOnline;
extern u16_t u16BattTemp;
extern u8_t  u8Calibration;
extern u32_t u32Protection_type;
extern u16_t u16LastProtect_Index;
extern u32_t u32LastProtect;
extern u16_t u16TrimDuty;
extern u16_t  u16BattSOH; 
extern u16_t u16DischargeRemainTime;
extern u8_t  pu8CellVoltage[28];
extern u16_t u16BMSFWRev;
extern u16_t u16FCC;
extern u16_t u16DischargeCellOTFaultL;
extern u16_t u16DischargeCellOTWarnL;
extern u16_t u16ChargeCellOTFaultL;
extern u16_t u16ChargeCellOTWarnL;
extern u16_t u16CycleCntLimit;
extern u16_t u16BoostOTFaultL;
extern u16_t u16BoostOTWarnL;
extern u16_t u16AmbientOTFaultL;
extern u16_t u16AmbientOTWarnL;
extern u16_t u16Cycle_Cnt_Offset;
extern u8_t  pu8BatteryName[16];
extern u8_t  pu8CellModel[16];
extern u8_t  pu8CellMFR[16];
extern u8_t  pu8ProtocolVersion[16];
extern u16_t u16BBS_Control;
extern u8_t  u8ModeChange;
extern u8_t  pu8BBUCompatible[11];
extern u16_t u16Modechange;
extern u8_t  u8DischargeLimit;


#endif

