/*********************************************************************** 
 *    Author:         Jeff JH Hsiao                                    *
 *    Company:            Liteon                                       * 
 *    Filename:         BBU 1.1KW                                      *	
 *    Date:           6/23/2014                                        *
 *    File Version:   1.0                                              *
 *    Other Files Required: p24FJ64GA006.gld			               *
 *    Tools Used: MPLAB IDE    -> 8.92 up                              *
 *                C30 Compiler -> 3.01 up                              *
 *                                                                     *
 **********************************************************************/

//Include the appropriate header (.h) file, depending on device used
//Example (for PIC24FJ128GA010): #include <p24FJ128GA010.h>          

#include <p24FJ64GA006.h>
#include "bms_Pin_Define.h"	
#include "I2C.h"
#include "GenericTypeDefs.h"
#include "Battery_status.h"	
#include "Charge_control.h"
#include "Discharge_control.h"
#include "Failure.h"
#include "main.h"
#include <string.h>
#include "LED_Display.h"
#include "PMBusAPP.h"
#include "PMBusData.h"
#include "SI2CDrv.h"
#include "PMBus_data_transfor.h"
#include "BBU_content.h"	
#include "PMBus_status.h"	
#include "EEPROM.h"	
#include "FW_config.h"	
#include "QTBootloader.h"
#include "RevisionBlock.h"


//Configuration Bit Macros to define device config registers.
//Device header file contains usage details

_CONFIG1(JTAGEN_OFF & GCP_OFF & GWRP_OFF & BKBUG_OFF & COE_OFF & ICS_PGx1 & FWDTEN_OFF & WINDIS_OFF & FWPSA_PR32 & WDTPS_PS32768)
_CONFIG2(IESO_OFF & FNOSC_FRCPLL & FCKSM_CSDCMD & OSCIOFNC_OFF & POSCMOD_NONE) 


// Define constants here                            			     

#define CONSTANT1 10
#define CONSTANT2 20


/************* START OF GLOBAL DEFINITIONS ****************************/					

//Define global variables without attributes       									

int Int0_CNT = 0;
int i;
u16_t ADCH = 0;
volatile u8_t BBU_mode;
u8_t BBU_old_state; 
u8_t count_10ms = 0;
u8_t BBS_PS_KILL_Debounce_Count = 13;
u8_t BBS_ON_Debounce_Count = 11;
u8_t New_BBS_PS_KILL = 0;                       // Now BBS_PS_KILL state
u8_t Old_BBS_PS_KILL = 0;                       // Old BBS_PS_KILL state
u8_t New_BBS_ON = 0;                            // New BBS_ON state
u8_t Old_BBS_ON = 0;                            // Old BBS_ON state
u8_t LED_count = 0;                             // Blink LED 0.5s Freq 1Hz
u8_t PMBus_update_10ms = 0;                     // PMBus update data 10ms once
s16_t BUCK1_AD_Temp = 0;                        // ADC read BUCK temp buffer
s16_t BOOST_AD_Temp = 0;                        // ADC read BOOST temp buffer
s16_t Ambient_AD_Temp = 0;                      // ADC read Ambient temp buffer
u16_t PMBus_loss_count = 0;                     // PMBus loss count 10ms once
u8_t  EEPROM_count = 0;                         // EEPROM switch storage command
u8_t  EEPROM_10ms_Write  = 0;                   // 10ms can write EEPROM
u8_t  EEPROM_Write_count = 0;                   // 1ms count if equal 10 return zero
u8_t  Power_Decay_Flag = 0;                     // offline mode after delay 5sec will insert 1 to start power decay
u16_t Power_Decay_cnt = 0;                      // count to 80 return zero when finish power decay
u8_t  Discharger_Delay_Flag = 0;                // When AC_Good High to low AC back delay 5 sec insert
u16_t Discharger_Delay_cnt = 0;                 // Discharge delay count++ 
u8_t  Power_Decay_10s_cnt = 0;                  // Power decay count, ++at 10msec Interrupt
u16_t Expect_I_ref_Duty = 0;                    // expect Iref Duty compare to Iref                 
u16_t Expect_Charge_Current = 0;                
u16_t Voltage_ADC_Gain = 0;
u16_t Iout_ADC_Gain = 0;
u8_t  Charger_Start_cnt = 0;
u8_t  Online_Mode_Iout_Delay = 0;
u32_t abs_Iout = 0;
u8_t  Average_Iout_count = 0;
u8_t  Average_BUCK_Temp_count = 0;
u8_t  Average_BOOST_Temp_count = 0;
u8_t  State_Processing = 0;
u8_t  State_Change_Request = 0;
u8_t  Time100ms_count = 0;
u8_t  Time100ms_Flag = 0; 
u8_t  EEPROM_Failure_count = 0;
u8_t  Delay_2s_Flag = 0;                        // Program start First 2sec will at idle mode
u8_t  Delay_5s_Flag = 0;                        // Program start after 5sec detect AC_GOOD signal level(not interrupt)
u8_t  Finish_Power_Decay_Flag = 0;
u8_t  CS_EN_Flag = 0;                           
u8_t  CS_EN_cnt = 0;
u8_t  HW_Not_Compatible_Flag = 0;
u8_t  Online_Mode_Discharge_Delay_Flag = 0;
u16_t Online_Mode_Discharge_Delay_cnt = 0;
u16_t Charge_Current_Calibration_Delay_Cnt = 0; 
u8_t  Battery_Learning_Start = 0;               // If BBS ask Battery_learning and AC_GOOD low
u8_t  Vout_AD_Calibrate_Already = 0;
u8_t  Iout_AD_Calibrate_Already = 0;
//*************************************************************






//Function prototype
  
void Initial_system(void);
void AD_Delay(unsigned int AD_Delay_conter);
void AD_start(void);
void Read_Battery_data(void);
void AD_initial(void);
void Read_AD(unsigned ADCH);
void Debounce(void);
void AD_data_type_transfor(void);
void Current_Sharing(void);
void Limit_Vref(void);
void Power_Decay(void);
void Time100ms(void);
void GetAddr(void);
void Protect_Delay(void);
void Finish_Power_Decay(void);
void Time1sec(void);
void AC_GOOD_Function(void);
void EEPROM_Write_Protect(void);
void Compatible_Code_Compare(void);


Flag_t Flag;
SystemControl_t  SystemControl;
Failure_type_t Failure_type;
Warning_type_t Warning_type;
Not_Reset_Failure_type_t Not_Reset_Failure_type;
BBU_Info_T BBU_Info;
System_Run_T  System_Run;
Average_Iout_T Average_Iout;
Average_Temp_T Average_Temp;
Online_Mode_T Online_Mode;
BBS_Control_T BBS_Control;
Charger_Delay_t Charger_Delay;
Discharger_Delay_t Discharger_Delay;
//BBU_mode_t BBU_mode;

/************** END OF GLOBAL DEFINITIONS *****************************/

/************** Function describe**************/
void Idle_state_handler(void)                     // All Flag clear
{
   SystemControl.bits.Flag_Online_Mode = 0;          
   SystemControl.bits.Flag_Offline_Mode = 0;         
   SystemControl.bits.Flag_Online_Charge = 0;
   SystemControl.bits.Flag_Online_Discharge = 0;
   SystemControl.bits.Flag_Offline_Charge = 0;
   SystemControl.bits.Flag_Offline_Discharge = 0;
   SystemControl.bits.Flag_Idle_Mode = 1;  
}

void Online_state_handler(void)
{ 
     if(SystemControl.bits.AC_GOOD == 1)
     {
        if(SYS_PRES == 0)                                   // if SYS_PRES not send to BMS need charger soft start
        {
          if(SystemControl.bits.Flag_Online_Charge == 0)
          {
             Initial_Charger();                             // First into online_Charger or discharger goto charger
             Charger.Condition_state = Charger_state_Initial;
             Charge_control();         
          }
          else
          {
             Charge_control();
          }
        }
        else
        {
          Disable_Charger();
          SystemControl.bits.Flag_Online_Charge = 0;
          if(Cell_Info.ProtectionStatus.bits.DFET == 1)
          {
            Online_Discharge_control();
          }
        }
         
        if(Power_Decay_Flag == 0)                          // not at power_decay process output is 12.7V
        {
          V_ref_Duty = u16VrefOffline;
        }
     }
     else
     {
       V_ref_Duty = u16VrefOnline;
       if(ORING_STATUS == 1)                              // Oring FET not turn on =>charging
       {
         Online_Mode_Iout_Delay = 0;
         if(SystemControl.bits.Flag_Online_Charge == 1)  
         {
           Charge_control();                              // online mode if not need discharging, charger enable discharger enable 
           
           if(EEPROM_Info.Read_Battery == 1)                 // BBU read battery status can detect DFET open or not
           {
             if(Cell_Info.ProtectionStatus.bits.DFET == 1)   // If DFET is open go to discharge state
             {
               Online_Discharge_control();
               Discharger_Delay.DFET_Notopen_Flag = 0;
               Discharger_Delay.DFET_Notopen_Cnt = 0;
             }
             else
             {
               if(SYS_PRES == 1)
               {
                 Discharger_Delay.DFET_Notopen_Flag = 1;
                 if(Discharger_Delay.DFET_Notopen_Cnt >= 1000)      // Time base 1msec
                 {
                   Online_Discharge_control();
                 }
               }
             }
             
           }
           else                                           // if not read battery delay 1sec to discharge state
           {
             if(Online_Mode_Discharge_Delay_cnt >= 100)            // Time base 10msec
             { 
               Online_Discharge_control();
             }
           }
           Discharger.state_Discharging = 0;
         }
     
         if(SystemControl.bits.Flag_Online_Charge == 0)
         {
             Initial_Charger();                             // First into online_Charger or discharger goto charger
             Charger.Condition_state = Charger_state_Initial;
             Charge_control();
           
         }
        }
        else                       // ORING FET turn on go discharge
        {
          Online_Mode_Iout_Delay ++;
          if(Online_Mode_Iout_Delay >= 10)
          { 
           Online_Mode_Iout_Delay = 10;
           Disable_Charger();
           SystemControl.bits.Flag_Online_Charge = 0;       // let online_charge flag reset
           Online_Discharge_control();
          } 
         }
       }   
  
}
	
void Offline_state_handler(void)
{
   if(Power_Decay_Flag == 0)
   {
     V_ref_Duty = u16VrefOffline;                        // if not at power decay time 
   }
   if(SystemControl.bits.AC_GOOD == 1)                   //need discharge go to discharge control. if AC_GOOD is 0 but SystemControl.bits.AC_GOOD = 0 cant discharge
   {
      if(SYS_PRES == 0)
      {
        if(SystemControl.bits.Flag_Offline_Charge == 0)
        {  
          Initial_Charger();                               // First in Offline state Charge control
          Charger.Condition_state = Charger_state_Initial;
          Charge_control();
        }
        else
        {
          Charge_control();
        }
      }
      else
      {
        Disable_Charger();
        SystemControl.bits.Flag_Offline_Charge = 0;
        if(Cell_Info.ProtectionStatus.bits.DFET == 1)
        {
          Offline_Discharge_control();
        }
      } 
   }
   else
   {
      Disable_Discharger();
      if(SystemControl.bits.Flag_Offline_Charge == 1)
      {
        Charge_control();                                // Already Initial Charger 
      }  
      else
      {
        Initial_Charger();                               // First in Offline state Charge control
        Charger.Condition_state = Charger_state_Initial;
        Charge_control();
      }    
   }      
}

void Failure_state_handler(void)
{
   SystemControl.bits.Flag_Online_Mode = 0;          
   SystemControl.bits.Flag_Offline_Mode = 0;         
   SystemControl.bits.Flag_Online_Charge = 0;
   SystemControl.bits.Flag_Online_Discharge = 0;
   SystemControl.bits.Flag_Offline_Charge = 0;
   SystemControl.bits.Flag_Offline_Discharge = 0;
   
//   EEPROM_Write_Protect();          // If any fault write 32 byte(4 protect type) to EEPROM
   Failure_Control();
}
//*************************************************  state application sub function
void Idle_state(void)
{
   Idle_state_handler();
}

void Online_state(void)
{
   Online_state_handler();
}

void Offline_state(void)
{
   Offline_state_handler();
}

void Failure_state(void)
{
   Failure_state_handler();
}

//***************************************************  When the mode first change need to do something

void BBU_state(void)                                     // Mode switch
{
   switch(BBU_mode)
   {
	  case BBU_state_Idle_mode:
      
           SYS_PRES = 0;
           Online_Mode_Discharge_Delay_Flag = 0;
           SystemControl.bits.AC_GOOD = 0;
           Disable_Discharger();                         // Disable Discharger and Charger turn off ORFET
           Disable_Charger();
           SystemControl.bits.Flag_Idle_Mode = 1;
           Idle_state();
           Charger.state_Charging = 0;
           Charger.state_FullyCharge = 0;
           Charger.state_Inhibit = 0;
           Discharger.state_Discharging = 0;
           Discharger.state_Failure = 0;
           Discharger.state_Inhibit = 0;
        
            

        break;

      case BBU_state_Online_mode:

//           SYS_PRES = 1;
           SystemControl.bits.Flag_Offline_Mode = 0;     // Clean Offline_mode and Idle_mode Flag
           SystemControl.bits.Flag_Online_Mode = 1;      // Stand Online_mode Flag
           SystemControl.bits.Flag_Offline_Charge = 0;   // First into this state clean Charge and Discharge Flag 
           SystemControl.bits.Flag_Offline_Discharge = 0;
           SystemControl.bits.Flag_Idle_Mode = 0;
//  		   VOUT_HIGH = 1;                                // parallel resistance Vout is 12V (Online mode)
           Online_Mode_Discharge_Delay_Flag = 1;
//           Enable_Discharger();
			asm("NOP");          
			asm("NOP");
           Online_state();

        break;

      case BBU_state_Offline_mode:
         
//           SYS_PRES = 1; 
		   SystemControl.bits.Flag_Online_Mode = 0;
		   SystemControl.bits.Flag_Offline_Mode = 1;
           SystemControl.bits.Flag_Online_Charge = 0;
           SystemControl.bits.Flag_Online_Discharge = 0;
           SystemControl.bits.Flag_Idle_Mode = 0;
           Online_Mode_Discharge_Delay_Flag = 0;
//           VOUT_HIGH = 0;                                // not parallel resistance Vout is 12.6V (Offline mode)
//           V_ref_Duty = u16VrefOnline;
           if(SystemControl.bits.AC_GOOD == 0)             // if online_mode change to offline_mode the Flag SystemControl.AC_GOOD is Low. BBU status is Charge mode so need disable Discharger
           {
             Disable_Discharger();
           }
		   Offline_state();

        break;

      case BBU_state_Failure_mode:

           
           SYS_PRES = 0;                                   // Battery cant charge and discharge 
           Disable_Discharger();
           Disable_Charger();
           SHUTDOWN = 1;

           for(i=3; i>-1; i--)
           {
             memcpy(&LastProtect_type[i+1], &LastProtect_type[i], sizeof LastProtect_type[0]);
           }
 
           LastProtect_type[0] =  Failure_type.val;
 
           Charger.state_Charging = 0;
           Charger.state_FullyCharge = 0;
           Charger.state_Inhibit = 0;
           Discharger.state_Discharging = 0;
           Discharger.state_Failure = 0;
           Discharger.state_Inhibit = 0;  
           Online_Mode_Discharge_Delay_Flag = 0;        

		   Failure_state();

        break;

      default:

        break;
 
     }
}

//********************************************** This choose mode same than last mode  

void BBU_same_state(void)                   //If this mode same than last mode not do first into mode to do thing 
{
   switch(BBU_mode)
     {
		case BBU_state_Idle_mode:
 
            Idle_state_handler(); 

          break;

        case BBU_state_Online_mode:
            
            Online_state_handler();

          break;

        case BBU_state_Offline_mode:
		    
			Offline_state_handler();

          break;

        case BBU_state_Failure_mode:

			Failure_state_handler();

          break;

        default:

          break;
 
     }
}

//****************************************************** Choose BBU this status go to which mode

void BBU_state_set()
{
      if(HW_Not_Compatible_Flag == 1)
      {
        BBU_mode = BBU_state_Idle_mode;
      }
//----------------- Failure mode ---------------//
      else if(SystemControl.bits.Flag_Failure == 1 || SystemControl.bits.Flag_Not_Reset_Failure == 1)
      {
        BBU_mode = BBU_state_Failure_mode;
      }
//----------------- First 2 sec at ilde mode ---------------//

      else if(Delay_2s_Flag == 0)
      {
        BBU_mode = BBU_state_Idle_mode;
      }

//---------------- IDLE mode -------------------// 
      else if(SystemControl.bits.Flag_PS_KILL_Debounce == 1 && SystemControl.bits.Flag_Failure == 0 && SystemControl.bits.Flag_Not_Reset_Failure == 0)
      {
        BBU_mode = BBU_state_Idle_mode;
      }
//---------------- Operation -------------------//
      else if(u8Operation == 0x00 && SystemControl.bits.Flag_Failure == 0 && SystemControl.bits.Flag_Not_Reset_Failure == 0)
      {
        BBU_mode = BBU_state_Idle_mode;
      }

//---------------- PMBus loss communication --------------//
      else if(SystemControl.bits.Flag_PS_KILL_Debounce == 0 && SystemControl.bits.Flag_PMBus_loss == 1 && u8Calibration != 9)
      {
        BBU_mode = BBU_state_Online_mode;
        u16BBS_Control = 0;
      }

//----------------- Idle mode --------------------//
      else if(u16Modechange == 2 && SystemControl.bits.Flag_Failure == 0 && SystemControl.bits.Flag_Not_Reset_Failure == 0)
      {
        BBU_mode = BBU_state_Idle_mode;
      }
      
//---------------- ON_line mode ---------------//
      else if(u16Modechange == 0 && SystemControl.bits.Flag_PS_KILL_Debounce == 0 && SystemControl.bits.Flag_Failure == 0 && 
              SystemControl.bits.Flag_Not_Reset_Failure == 0)   //&& SystemControl.bits.Flag_PMBus_loss == 0
      { 
        BBU_mode = BBU_state_Online_mode;
      }
//---------------- OFF_line mode --------------//
      else if(u16Modechange == 1 && SystemControl.bits.Flag_PS_KILL_Debounce == 0 && SystemControl.bits.Flag_Failure == 0 &&
              SystemControl.bits.Flag_Not_Reset_Failure == 0)   //&& SystemControl.bits.Flag_PMBus_loss == 0
      {
        BBU_mode = BBU_state_Offline_mode;
      }

      if(BBU_mode != BBU_old_state)
      {
        if(State_Processing == 1)
        {
          State_Change_Request = 1;
        }
        else
        {
           BBU_old_state = BBU_mode;
           State_Change_Request = 0;
           BBU_state();
        }
      }
       
}



/************* START OF MAIN FUNCTION *********************************/

int main ( void )
{
	Initial_system();
    V_ref_Duty = 4080;

    IEC0bits.T1IE = 1;                   // Enable Timer 1 interrupt
    T1CONbits.TON = 1;                   // Timer 1 start count

    while(System_Run.Time_10ms <= 10)    // delay 100ms to start BBU
    {
       asm("NOP");
       asm("NOP");
    }
   
    I2C1_write(Battery_Address,Battery_LED_Status,Battery_LED_off_data_low,Battery_LED_data_high);
    asm("NOP");
    asm("NOP");
    I2C1_write(Battery_Address,Battery_LED_Status,Battery_LED_off_data_low,Battery_LED_data_high);
    asm("NOP");
    asm("NOP");
    I2C1_write(Battery_Address,Battery_LED_Status,Battery_LED_off_data_low,Battery_LED_data_high);    

    PMBusInit();
    PMBusTstInit();
    
    IEC1bits.T4IE = 1;                   // Enable Timer 4 interrupt
    T4CONbits.TON = 1;                   // Timer 4 start count
    IEC1bits.T5IE = 1;                   // Enable Timer 5 interrupt
    T5CONbits.TON = 1;                   // Timer 5 start count
    T2CONbits.TON = 1;                   // Timer 2 start count
    T3CONbits.TON = 1;                   // Timer 3 start count
    IEC3bits.SI2C2IE = 1;                // Enable I2C2 slave interrupt

     
    if(BBS_PS_KILL == 0)
    {
      SystemControl.bits.Flag_PS_KILL_Debounce = 0;
    }
    else
    {
      SystemControl.bits.Flag_PS_KILL_Debounce = 1;
    }

    if(BBS_ON == 0)
    {
      SystemControl.bits.Flag_BBS_ON_Debounce = 0;
    }
    else
    {
      SystemControl.bits.Flag_BBS_ON_Debounce = 1; 
    }

    IEC1bits.INT1IE = 1;                 // Enable external interrupt INT1
	IEC3bits.INT4IE = 1;                 // Enable external interrupt INT4

    SI2CDrvInit();                       // Initial SI2CDrv
    QTBootloaderInit();
 
//    I_ref_Duty = 0;                    // I_ref_Duty fix in 3232 2A, if need soft start see 20140815 code
    Trim_CS_Duty = 250;                  
    Battery_diagnostic();                //Battery status detect
   
//------------------ Test -------------------
     Cell_Info.RemainingCapacity = 2400;
     Cell_Info.Voltage = 38000;          //Test
     Cell_Info.Current = 2000; 
     Cell_Info.Temp = 30;
//--------------------------------------------
     CHG_EN = 1;                         // Charger Disable                        

     CS_EN = 1;                          // current sharing disable
     ORFET_EN = 0;                       // disable ORING FET driver
     
     Cell_Info.PermanentFailureStatus.Val = 0; // Before read BMS data initial value 0

     Cell_Info.Discharge_Remain_Time = 1500;  // Discharge remain time default value 0

     Cell_Info.SOH = 100;                // Before read BMS data default 100
    
     EEPROM_Read();                      // Read EEPROM parameters 

     RevCtrlBlockFun();                  // RCB table ROM to RAM

     Compatible_Code_Compare();          // Compare EEPROM HWCC and APP HWCC

     Initial_Block_Buff();
     memcpy(TempBlockBuff, &Failure_type.val, sizeof(Failure_type.val));
     I2C1_EEPROM_Block_Write(EEPROM_Address, EEPROM_Protect_type_Cmd, 4);                       

     SystemControl.bits.AC_GOOD = 0;

     V_ref_Duty = u16VrefOnline;
     
     CHG_MOS_OUT = 1;                    // Back to back mos turn on avoid inrush current

     I2C1_Read(Battery_Address,ReadBattery_FirmwareVersion);
     if(I2C_State.PEC_error == 0 && I2C_State.Communication_Fail == 0)
     {
	   Cell_Info.FWRev = (data_high<< 8 ) + data_low;    // Let PSC can read it when BBU ON
     }
     asm("NOP");
     asm("NOP");

     u16StateBBU = 0x80;

     TEST1 = 0;
          
    while(1)
    { 	

        Trim_CS_Duty = u16TrimDuty;
              
        State_Processing = 1;              // Run BBU state machine 
     
        BBU_same_state();

        State_Processing = 0;              // Finish BBU state machine 

        if(State_Change_Request == 1)      // If change mode at BBU state machine function will do here
        {
           BBU_old_state = BBU_mode;
           State_Change_Request = 0;
           BBU_state();
        }
        
        if(EEPROM_Info.Read_Battery == 1)
        {
            Battery_status();              //Communicate with Battery if not marked it       
        }
             

        Failure_detect();                // Failure detect
   
        LED_Test();                      // Decided the LED
 
        AD_data_type_transfor();         // AD data transfor to real value
              
        PMBusMapRxData();

//        CheckClockHold();

        PMBus_need_update_data();        // decide should be updata or not
 
        Status_BBU_update();             // update Battery status

        EEPROM_Control();

        Limit_Vref();                    // Vref up and low limit

        QTBootloaderProcess();

        EEPROM_Time_Minute_Write();      // Write Total run minute per one minute

        Time100ms();                     // 100ms system tik

        Battery_SelfDetect();            // Battery learning

        if(Cell_Info.BatteryStatus.bits.Aging_Comparison_Request == 1)
        {
          Charger.BackRSOC_Setpoint = Battery_FullyCharge_RSOC;   // If need battery learning BackRSOC = 100
        }
        else
        {
          Charger.BackRSOC_Setpoint = Battery_BackCharge_RSOC;    // If don't need learning backRSOC = 95
        }

 //----------- power decay --------------------//
        if(Finish_Power_Decay_Flag == 1)
        {
          Finish_Power_Decay();
        }     

        BBS_Control.Val = u16BBS_Control;

        EEPROM_Write_Protect();          // If any fault write 32 byte(4 protect type) to EEPROM
       
 	}
	
     
	//Add Code Here

}
/************* END OF MAIN FUNCTION ***********************************/

//**************** Time tick ******************//
void Time100ms(void)
{
   if(Time100ms_Flag == 1)
   {
     Time100ms_Flag = 0;
   }

}



/****** START OF INTERRUPT SERVICE ROUTINES ***************************/
   	

/********************** Timer 1 Interrupt 10ms *************************/
void __attribute__((__interrupt__, no_auto_psv)) _T1Interrupt(void)
{
   Time100ms_count ++;   

   if(Time100ms_count == 10)
   {
      Time100ms_Flag = 1;
      Time100ms_count = 0;
   }

 /******* For I2C Communication with BMS Counting per 40ms goto read battery status*******/
   if(count_10ms == 4)
   {
     System_Run.I2C_Time_40ms = 1;                       // For I2C Communication with BMS (per 20ms)
     count_10ms = 0;
   }
   else 
   {  
     count_10ms++;
   }
 
/*********For test board display LED*******/   
   if(LED_count == 49)                          // 0.5sec light         
   {
     LED_count = 0;
     if(LED_Status.flag == 0)
     {
       LED_Status.flag = 1;         
     }
     else
     {
       LED_Status.flag = 0;
     }
   }
   else
   {
     LED_count++;
   }

   if(LED_Status.Test_Flag == 1)
   {
     LED_Status.Test_count ++;

   }


//***************** Discharger Delay *************//
    if(Discharger_Delay_Flag == 1)                     // delay when AC_GOOD back 5sec
    {
      Discharger_Delay_cnt ++;
      if(Discharger_Delay_cnt >= 510)
      {
        Discharger_Delay_cnt = 0;
        Discharger_Delay_Flag = 0;
        Power_Decay_Flag = 1;
      }
    }   

//***************** Power Decay **************//
    if(Power_Decay_Flag == 1)
    {
      if(Power_Decay_10s_cnt == 28)               // full load 13  haif 17
      {
        Power_Decay();
        Power_Decay_10s_cnt = 0;
      }
      else
      {
        Power_Decay_10s_cnt ++;
      }
    }

//***************** Online_Mode_Discharge_Delay_Flag ************************//
    if(Online_Mode_Discharge_Delay_Flag == 1)
    {
      if(Online_Mode_Discharge_Delay_cnt <= 100)
      {
        Online_Mode_Discharge_Delay_cnt ++;
      }
    }
    else
    {
      Online_Mode_Discharge_Delay_cnt = 0; 
    }

//***************** I_ref_Duty soft start  ***************//
    
    if(Charger_Test == 1)
    {
      if(Charger_Start_cnt <= 13)
      {
          Charger_Start_cnt ++;
          if(Charger_Start_cnt <= 8)
          {
            Repeat = 20;
            while(Repeat--)
            {
             CHG_MOS_IN = 1;
             System_Delay(5);
             CHG_MOS_IN = 0;
             System_Delay(35);
            }
            Repeat1 = 20;       
            while(Repeat1--)
            {
             CHG_MOS_IN = 1;
             System_Delay(5);
             CHG_MOS_IN = 0;
             System_Delay(35);
            }
            Repeat2 = 35; 
            while(Repeat2--)
            { 
             CHG_MOS_IN = 1;
             System_Delay(5);
             CHG_MOS_IN = 0;
             System_Delay(35);
            }
          }
          else
          {
            Repeat = 20;
            while(Repeat--)
            {
             CHG_MOS_IN = 1;
             System_Delay(7);
             CHG_MOS_IN = 0;
             System_Delay(33);
            }
            Repeat1 = 20;       
            while(Repeat1--)
            {
             CHG_MOS_IN = 1;
             System_Delay(7);
             CHG_MOS_IN = 0;
             System_Delay(33);
            }
            Repeat2 = 45; 
            while(Repeat2--)
            { 
             CHG_MOS_IN = 1;
             System_Delay(7);
             CHG_MOS_IN = 0;
             System_Delay(33);
            }
          }
                      
      }
      else
      {
        Charger_Start_cnt = 14;
        if(CHG_MOS_IN == 0)
        {
         CHG_MOS_IN = 1;
        }
        if(CHG_EN == 1)
        {
         CHG_EN = 0;
         SYS_PRES = 1;
        } 
        asm("NOP");
        if(I_ref_Duty < Expect_I_ref_Duty - 50 && Charger.state_Inhibit == 0)
        {
          I_ref_Duty = I_ref_Duty + 50;
        }
        else if(I_ref_Duty == (Expect_I_ref_Duty - 50))
        {
          I_ref_Duty =  Expect_I_ref_Duty;                // finish soft start
        
          if(CHG_MOS_OUT == 0)
          {
             CHG_MOS_OUT = 1;
             Charger_Softstart_Finish_Flag = 1;      
          }
        }
        else if(Charger.state_Inhibit == 0) 
        { 
          I_ref_Duty = Expect_I_ref_Duty;                // dont need soft start
          Charger_Softstart_Finish_Flag = 1;
        }

          
       }
       
     }  
     else
     {
       I_ref_Duty = 0;
     } 

//*************** Charge Current calibration delay *************
    if(Charger_Softstart_Finish_Flag == 1)  
    {
       if(Charge_Current_Calibration_Delay_Cnt <= 100)
       {
         Charge_Current_Calibration_Delay_Cnt ++;
       }
    }
    else
    {
       Charge_Current_Calibration_Delay_Cnt = 0;
    } 
 
  
//********* PMBus loss communication ********//
    PMBus_loss_count ++;                            //If system use PMBus to request data or command PMBus_Loss_count => 0
    if(PMBus_loss_count >= 3000)
    {
       SystemControl.bits.Flag_PMBus_loss = 1;      //System not communication with BBU more than 30 Sec Change to operate at online mode
    }
    else
    {
       SystemControl.bits.Flag_PMBus_loss = 0;
    }
   
  
/*****************************************/
   System_Run.Time_10ms++;
    if(System_Run.Time_10ms == 100)
    {
      System_Run.Time_10ms = 0;
      System_Run.Time_1s++;
      if(System_Run.Time_1s == 2)
      {
        Delay_2s_Flag = 1;                           // First initial delay 2 sec
      }
      if(System_Run.Time_1s == 5)
      {
        Delay_5s_Flag = 1;
      }
      if(System_Run.Time_1s == 60)
      {
        System_Run.Flag_1minute = 1;
        System_Run.Time_1s = 0;
        System_Run.Time_1min++;
        System_Run.Time_Minute++;
        if(System_Run.Time_1min == 60)
        {
          System_Run.Time_1min = 0;
          System_Run.Time_1hour++;
          if(System_Run.Time_1hour == 24)
          {
            System_Run.Time_1hour = 0;
            System_Run.Time_1day++;
          }
        }
      }
    }    
    
	IFS0bits.T1IF = 0;     // Clear timer1 interrupt flag	
    return;
       
}
/********************** Timer 2 Interrupt 0.33ms **********************/
void __attribute__((__interrupt__, no_auto_psv)) _T2Interrupt(void)
{

	IFS0bits.T2IF = 0;     // Clear timer2 interrupt flag	
    return;
       
}

/*********************** Timer 4 Interrupt 1ms ************************/
void __attribute__((__interrupt__, no_auto_psv)) _T4Interrupt(void)
{
    BBU_state_set();

    GotoBoot();

    if(Delay_5s_Flag == 1)                            // First 5sec when BBU on will detect AC_GOOD
    {
      AC_GOOD_Function();
    }

    u32_t tmp = 0;
        
    Read_AD(AD_VOUT_BUS);                             // AN2(pin 14)   Vout_BUS
    if(u8Calibration == 2)
    {
     if(Vout_AD_Calibrate_Already == 0)
     {
       Voltage_ADC_Gain = ADC1BUF0;
       Vout_AD_Calibrate_Already = 1;
     }
    }
 
    if(Voltage_ADC_Gain != 0 && Voltage_ADC_Gain < 1024)
    {
	 tmp = ADC1BUF0;
	 tmp = tmp *12750 / Voltage_ADC_Gain;              // 12750
     BBU_Info.BusVoltage = tmp;                        // Gain = 1000*4.92*3.3/1024  15.8854 16.0554
    }
    else
    {
     tmp = ADC1BUF0;
     tmp = (tmp *15855)/1000;
     BBU_Info.BusVoltage = tmp;
    }
    asm("NOP");     

    
    Read_AD(AD_IOUT_DET);                             // AN3(pin 13)   Iout_Det   
    if(u8Calibration == 11)
    {
      if(Iout_AD_Calibrate_Already == 0)
      {
        Iout_ADC_Gain = ADC1BUF0;
        Iout_AD_Calibrate_Already = 1;
      }
    }  
  
    if(Iout_ADC_Gain != 0 && Iout_ADC_Gain < 1024)
    {
      tmp = ADC1BUF0;
	  tmp = (tmp * 89500) / Iout_ADC_Gain;
      BBU_Info.Iout = tmp;

    }
    else
    {
      tmp = ADC1BUF0;
      tmp = (tmp * 1377)/ 10;                       
      BBU_Info.Iout = tmp;
      asm("NOP");
    }
    
 
    Read_AD(AD_VOUT_12V);							  // AN4(pin 12)   Voltage before ORing FET
    if(Voltage_ADC_Gain != 0 && Voltage_ADC_Gain < 1024)
    {
	 tmp = ADC1BUF0;
	 tmp = tmp *12750 / Voltage_ADC_Gain;            // 12750
     BBU_Info.Vout_12V = tmp;                        // Gain = 1000*4.92*3.3/1024  15.8854 16.0554
    }
    else
    {
     tmp = ADC1BUF0;
     tmp = (tmp *15855)/1000;
     BBU_Info.Vout_12V = tmp;
    }
    asm("NOP");
    

    Read_AD(AD_BUCK1_TEMP);							  // AN6(pin 17)   Buck modual 1 Temperature
    BUCK1_AD_Temp = ADC1BUF0;;
    asm("NOP");
    Average_BUCK_Temp_count ++;
    if(Average_BUCK_Temp_count == 5)
    {
      Average_BUCK_Temp_count = 0;
    }

    Read_AD(AD_BBU_TEMP);
    Ambient_AD_Temp = ADC1BUF0;;
    asm("NOP");

    Read_AD(AD_BOOST_TEMP);                           // AN9(pin 22)   Boost Temperature
    BOOST_AD_Temp = ADC1BUF0;
    asm("NOP");
    Average_BOOST_Temp_count ++;
    if(Average_BOOST_Temp_count == 5)
    {
      Average_BOOST_Temp_count = 0;
    }

    Debounce();                                      // debounce time base is 1ms


/***********For PMBus data update 10ms once***********/
    if(PMBus_update_10ms == 9)
    {
      BBU_content.flag = 1;                          // 10ms updata PMBus status and data
      PMBus_update_10ms = 0;
    }
    else
    {
      BBU_content.flag = 0;
      PMBus_update_10ms++;
    }
/******************************************************/
//******** EEPROM Write ***********/
    if(EEPROM_Write_count == 10)
    {
      if(EEPROM_10ms_Write == 1)
      {
        EEPROM_10ms_Write = 0;
      }
      else
      {
        EEPROM_10ms_Write = 1;
      }
      EEPROM_Write_count = 0;
    }
    else
    {
      EEPROM_Write_count ++;
    }

//********* protect delay ***********//
    Protect_Delay();

//********* Current sharing **********//
    Current_Sharing();

/*
    if(CS_EN_Flag == 1)
    {
      CS_EN_cnt ++;
      if(CS_EN_cnt == 5)    // delay 5ms avoid current share unblance
      {
        CS_EN = 0;
      }
    }
    else
    {
      CS_EN_cnt = 0;
      CS_EN = 1;
    }

*/  


//*********** Charger_First_Delay *******************
   if(Charger_First_state_Flag == 1)
   {
      if(Charger_First_state_Cnt <= 400)
      {
         Charger_First_state_Cnt ++;
      }
   }
   else
   {
      Charger_First_state_Cnt = 0;
   }    



	IFS1bits.T4IF = 0;                                // Clear timer4 interrupt flag	
    return;
       
}

/********************** Timer 5 Interrupt 10us **********************/
void __attribute__((__interrupt__, no_auto_psv)) _T5Interrupt(void)
{
    CheckClockHold();
	IFS1bits.T5IF = 0;     // Clear timer2 interrupt flag	
    return;      
}

 

/******************* INT1 (BBS_AC_GOOD) ********************/
void __attribute__((interrupt,no_auto_psv)) _INT1Interrupt(void) // Pin 42 BBS_AC_GOOD
{
  if(BBS_AC_GOOD == 0)                                           // BBS_AC_GOOD High to Low
  {
    if(SystemControl.bits.Flag_PS_KILL_Debounce == 1)
    {
      IFS1bits.INT1IF = 0;
      return;
    }
  
    if(SystemControl.bits.Flag_Failure == 1)                    // If System have somthing wrong cant discharger
    {
      Failure_state_handler();                                   // Go to Failure state
    }
    else if(SystemControl.bits.Flag_Offline_Mode == 1)
    {
       Disable_Charger();                                               
       Enable_Discharger();
    }    
    else if(SystemControl.bits.Flag_Online_Mode == 1)
    {
       Disable_Charger();     
       SystemControl.bits.Flag_Online_Charge = 0;       
       V_ref_Duty = u16VrefOffline;  
        
    }

    if(Cell_Info.BatteryStatus.bits.Aging_Comparison_Ready == 1)
    {
       Battery_Learning_Start = 1;
    }

    Charger.state_Initial = 1;
    Charger.state_FullyCharge = 0;
    Charger.state_Charging = 0;
    Charger.state_Inhibit = 0;
  
    SystemControl.bits.AC_GOOD = 1;
    u16StatusP0Word = (u16StatusP0Word & ~(Status_Word_bits_Power_Good));
    u16StatusP1Word = (u16StatusP1Word & ~(Status_Word_bits_Power_Good));

    Discharger_Delay_Flag = 0;
    Discharger_Delay_cnt = 0;
    Power_Decay_Flag = 0;
    Power_Decay_cnt = 0; 
    Finish_Power_Decay_Flag = 0;
    SystemControl.bits.Flag_Charge_to_Discharge = 1;             // need goto Discharger 
    SystemControl.bits.Flag_Discharge_to_Charge = 0;

   
   

    INTCON2bits.INT1EP = 0;       // 0 -> Interrupt on pastive edge, turn Low to High goto interrupt   
    IFS1bits.INT1IF = 0;
    return;
  }

  if(BBS_AC_GOOD == 1)
  {
      Discharger_Delay_Flag = 1;
      SystemControl.bits.Flag_Charge_to_Discharge = 0;
      SystemControl.bits.Flag_Discharge_to_Charge = 1;
      u16StatusP0Word = (u16StatusP0Word | Status_Word_bits_Power_Good);
      u16StatusP1Word = (u16StatusP1Word | Status_Word_bits_Power_Good);
   
   
    INTCON2bits.INT1EP = 1;       // 1 -> Interrupt on negative edge    

      
	IFS1bits.INT1IF = 0;
    return;
  }
//Interrupt Service Routine code goes here
}

/******************* INT2 (BMS_INTR) **********************/
void __attribute__((interrupt,no_auto_psv)) _INT2Interrupt(void) // Pin 
{
 	
      
	IFS1bits.INT2IF = 0;
    return;
//Interrupt Service Routine code goes here
}

/******************* INT4 (POWER_FAULT) **********************/
void __attribute__((interrupt,no_auto_psv)) _INT4Interrupt(void) // Pin 45 POWER_FAULT
{
    SYS_PRES = 0;
    Int0_CNT++;
//   SystemControl.bits.Flag_Not_Reset_Failure = 1;
    Failure_type.bits.Power_Fault = 1;
   
    Disable_Discharger();                    // Disable Discharger
    Disable_Charger();                       // Disable Charger
            
    SystemControl.bits.Flag_Failure = 1;
      
	IFS3bits.INT4IF = 0;
//    IEC3bits.INT4IE = 0;                     // Disable external interrupt because the bounce, when fault clear th idle mode enable the INT4
    return;
//Interrupt Service Routine code goes here
}

/******************* SI2C2 Interrupt **********************/
void __attribute__((interrupt,no_auto_psv)) _SI2C2Interrupt(void)
{
     
	SI2CISR();
    PMBus_loss_count = 0;
    IFS3bits.SI2C2IF = 0;

   return;
}


/********* END OF INTERRUPT SERVICE ROUTINES **************************/
void Initial_system(void)
{ 
   
//--------------------- System signal I/O direction -----------------
   d_BBS_AC_GOOD = 1;
   d_BBS_PS_KILL = 1;
   d_BBS_ON = 1;
   d_BBS_A0 = 1;
   d_BBS_A1 = 1;
   d_BBS_A2 = 1;
   d_BBS_A3 = 1;
   d_BBS_A4 = 1;
   d_BBS_SDA = 1;
   d_BBS_SCL = 1;
//---------------------- Discharger I/O direction -----------------------------
   d_DISCHG_EN1 = 0;
   d_DISCHG_EN2 = 0;
   d_ORFET_EN = 0;
   d_ORING_STATUS = 1;
//---------------------- Charger I/O direction --------------------------------
   d_CHG_CONTROL = 0;
   d_CHG_EN = 0;
   d_CHG_MOS_IN = 0;
   d_CHG_MOS_OUT = 0;
   d_CHG_V_ref = 0;
//---------------------- BMS signal I/O direction ------------------------------
   d_SYS_PRES = 0;
//   d_ICELL_TOTAL = 1;
   d_BMS_SDA = 1;
   d_BMS_SCL = 1;
//---------------------- Current sharing signal I/O direction-------------------
   d_VREF = 0;
   d_TRIM_CS = 0;
   d_SHUTDOWN = 0;
   d_VOUT_HIGH = 0;
//   VOUT_HIGH = 0;
   d_CS_EN = 0;
//---------------------- Test signal I/O direction ---------------------
   d_TEST1 = 0;
//   d_TEST2 = 0;
   d_TEST3 = 0;
   d_TEST4 = 0;
  //---------------------- A/D signal I/O direction ----------------------
   d_BBU_TEMP = 1;           // AN5
   AD1PCFGbits.PCFG5 = 0;

   d_VOUT_12V = 1;           // AN4
   AD1PCFGbits.PCFG4 = 0;

   d_IOUT_DET = 1;           // AN3
   AD1PCFGbits.PCFG3 = 0;

   d_VOUT_BUS = 1;			 // AN2
   AD1PCFGbits.PCFG2 = 0;

   d_BUCK_TEMP1 = 1;         // AN6
   AD1PCFGbits.PCFG6 = 0;

   d_BUCK_TEMP2 = 1;         // AN7
   AD1PCFGbits.PCFG7 = 0;

   d_VIN_CHG = 1;            // AN8
   AD1PCFGbits.PCFG8 = 0;

   d_BOOST_TEMP = 1;         // AN9
   AD1PCFGbits.PCFG9 = 0;
  
//----------------------I2C_initial--------------------------
   I2C1_INIT();

//----------------------AD_initial----------------------------
   AD_initial();
//----------------------------------------------------------
  OSCCONbits.COSC = 0;          // FRCPLL
  CLKDIVbits.DOZE = 0;          // Clock ratio -> 1:1
 

//----------CLKDIV-----------	

  CLKDIVbits.RCDIV0 = 0;	    // Fosc = 4Mhz*4 -> PLL = 16MHz -> Fcy = Fosc/2 = 8MHz   
  CLKDIVbits.RCDIV1 = 0;
  CLKDIVbits.RCDIV2 = 0;   


//  RCONbits.SWDTEN = 1;        // Enable Watch Dog

//-------------Interrupt INT1 (BBS_AC_GOOD)- PIN 42 ---------------

  INTCON2bits.INT1EP = 1;       // 1 -> Interrupt on negative edge

  IEC1bits.INT1IE = 0;          // Disable INT1
  IFS1bits.INT1IF = 0;          // clear the interrupt flag
  IPC5bits.INT1IP = 6;          // Set the INT1 priority -> 7 is the highest

//  RPINR0bits.INT1R = 2;         // mapping

//-------------Interrupt INT4 (POWER_FAULT)- PIN 45----------------
  
  INTCON2bits.INT4EP = 1;       // 1 -> Interrupt on negative edge

  IEC3bits.INT4IE = 0;          // Disable INT4
  IFS3bits.INT4IF = 0;          // clear the interrupt flag
  IPC13bits.INT4IP = 7;         // Set the INT4 priority -> 7 is the highest

//  RPINR2bits.INT4R = 12;

//------------Timer 1---------------------
  
  IEC0bits.T1IE = 0;            // disable Timer1 interrupt
  IFS0bits.T1IF = 1;            // Clear Timer1 Interrupt Flag 
  IPC0bits.T1IP = 4;            // priority = 4


  T1CONbits.TCS = 0;            // Internal clock (Fosc/2)

  T1CONbits.TCKPS1 = 0;         // Clock prescale -> 01=8:1  10=64:1  11=264:1
  T1CONbits.TCKPS0 = 1;
  
  PR1 = 20000;                  // 1/16MHz*8*20000 = 10ms(12.5)

//------------Timer 2---------------------

  T2CONbits.TCS = 0;            // Fosc/2 
  T2CONbits.TCKPS1 = 0;         // clock prescale -> 1:1  
  T2CONbits.TCKPS0 = 0;
  T2CONbits.T32 = 0;

  IEC0bits.T2IE = 0;            // disable Timer2 interrupt
  IFS0bits.T2IF = 1;            // Clear Timer2 Interrupt Flag 
  IPC1bits.T2IP = 3;            // priority = 3

//------------Timer 3---------------------
  T3CONbits.TCS = 0;            // Fosc/2 
  T3CONbits.TCKPS1 = 0;         // clock prescale -> 1:1  
  T3CONbits.TCKPS0 = 0;
  

  IEC0bits.T3IE = 0;            // disable Timer3 interrupt
  IFS0bits.T3IF = 1;            // Clear Timer3 Interrupt Flag 
  IPC2bits.T3IP = 2;            // priority = 3

//---------------- OC1 PWM  CHG_CONTROL (I_ref) ----------------------(For GB106 if use GA006 need change)

  OC1CONbits.OCTSEL = 0;        // Timer select : Timer2
  OC1CONbits.OCFLT = 0;
  OC1CONbits.OCSIDL = 0;
  OC1CONbits.OCM = 6;           // Edge_aligned PWM Mode on OC2

 // RPOR9bits.RP18R = 18;       // RP18 Output Pin Mapping bits check table 10-3   (GA006 dont need mapping)

  d_CHG_CONTROL = 1;
  PR2 = 5333;                   // 3kHz   fcy=16MHz   5333*1/16M = 3k
  TMR2 = 0;
  OC1RS = 0;                    // 3232 = 2V
//---------------- OC2 PWM  V_ref ---------------------(For GB106 if use GA006 need change)
  
  OC2CONbits.OCTSEL = 0;        // Timer select : Timer2                   
  OC2CONbits.OCFLT = 0;
  OC2CONbits.OCSIDL = 0;  
  OC2CONbits.OCM = 6;           // Edge-aligned PWM Mode on OC2
 
//  RPOR9bits.RP18R = 18;       // RP18 Output Pin Mapping bits check table 10-3   (GA006 dont need mapping)

  d_VREF = 1;
  PR2 = 5333;                   // 3kHz   fcy=16MHz   5333*1/16M = 3k 
  TMR2 = 0;               
  OC2RS = 0;                    // duty = 30%    4040 = 2.5V

//---------------- OC3 PWM TRIM_CS ------------------------

  OC3CONbits.OCTSEL = 1;       // Timer select : Timer3
  OC3CONbits.OCFLT = 0;
  OC3CONbits.OCSIDL = 0;
  OC3CONbits.OCM = 6;          // Edge_aligned PWM Mode on OC3

//  RPOR

  d_TRIM_CS = 1;
  PR3 = 640;                   // 50kHz   fcy=16MHz   640*1/16M = 25k 
  TMR2 = 0;               
  OC3RS = 0;                  // duty = 30%

//----------------- OC5 PWM V_ref -----------------------//

  OC5CONbits.OCTSEL = 0;
  OC5CONbits.OCFLT = 0;
  OC5CONbits.OCSIDL = 0;
  OC5CONbits.OCM = 6;          // Edge_aligned PWM Mode on OC5

  d_CHG_V_ref = 1;
  PR2 = 5333;                   // 50kHz   fcy=16MHz   320*1/16M = 50k 
  TMR2 = 0;               
  OC5RS = 0;                  // duty = 30%
   
//----------------Timer 4----------------------

  IEC1bits.T4IE = 0;            // disable Timer1 interrupt
  IFS1bits.T4IF = 1;            // Clear Timer1 Interrupt Flag 
  IPC6bits.T4IP = 4;            //  priority = 4

  T4CONbits.TCS = 0;            // Internal clock (Fosc/2)

  T4CONbits.TCKPS1 = 0;         // Clock prescale -> 01=8:1  10=64:1  11=264:1
  T4CONbits.TCKPS0 = 1;
  
  PR4 = 2000;                   // 1/16MHz*8*2000 = 1ms(12.5)

//----------------Timer 5----------------------

  IEC1bits.T5IE = 0;            // disable Timer1 interrupt
  IFS1bits.T5IF = 1;            // Clear Timer1 Interrupt Flag 
  IPC7bits.T5IP = 5;            //  priority = 4

  T5CONbits.TCS = 0;            // Internal clock (Fosc/2)

  T5CONbits.TCKPS1 = 0;         // Clock prescale -> 01=8:1  10=64:1  11=264:1
  T5CONbits.TCKPS0 = 1;
  
  PR5 = 40;                   // 1/16MHz*8*20 = 10us(12.5)


//---------------SI2C BBS_Communication--------

  IEC3bits.SI2C2IE = 0;         // Disable SI2C2 interrupt
  IFS3bits.SI2C2IF = 0;         // Clear SI2C2 Interrupt Flag
  IPC12bits.SI2C2IP = 5;         // Priority = 4
  
     
}  // end Initial_system()

//---------------------delay--------------------------
void AD_Delay(unsigned int AD_Delay_conter)
{
  unsigned int AD_Delay = 0;
  for(AD_Delay = 0;AD_Delay < AD_Delay_conter;AD_Delay++);     // Wait for stable
}


void System_Delay(unsigned int delay_conter)
{
  unsigned int delay = 0;
  for(delay = 0;delay < delay_conter;delay++);     // Wait for stable
}

//--------------------AD-----------------------
void AD_initial(void)
{
  AD1CON1bits.ADON = 0;
  AD1CON1bits.ADSIDL = 1;
  AD1CON1bits.FORM = 0;
  AD1CON1bits.SSRC = 0;
  AD1CON1bits.ASAM = 0;
  AD1CON1bits.SAMP = 0;
  AD1CON1bits.DONE = 0;
  
  AD1CON2bits.VCFG = 0;         //refernce voltage Vdd Vss
  AD1CON2bits.CSCNA = 0;
  AD1CON2bits.BUFS = 0;
  AD1CON2bits.SMPI = 0;
  AD1CON2bits.BUFM = 0;
  AD1CON2bits.ALTS = 0;

  AD1CON3bits.ADRC = 1;
  AD1CON3bits.SAMC = 31;        // 31 TAD  dont need fast
  AD1CON3bits.ADCS = 128;       // 63Tcy

  AD1PCFG = 0xFC03;             // chose which GPIO is for Analog

 // AD1CHS = 1;                 // CH0+ input is AN1, CH0- input is Vr-(AVss)
  AD1CSSL = 0;                  // No inputs scanned

  AD1CON1bits.ADON = 1;         // AD On
  AD1CON1bits.SAMP = 1;         // AD is sampling 

  AD_Delay(100);                // wait for stable

  AD1CON1bits.ADON = 0;         // AD Off
}


void Read_AD(unsigned int ADCH)
{
  AD1CON1bits.ADON = 1;         // AD On
  AD1CHSbits.CH0SA = ADCH;      // Select AN channal is the CH0 input
  AD1CON1bits.SAMP = 1;         // AD Sample On   start sample
  AD_Delay(10);
  AD1CON1bits.SAMP = 0;         // AD Sample Off  finish sample wait conversion
  while(AD1CON1bits.DONE == 0);     // Wait for conversion done, Done == 1 conversion ok

}

void Debounce(void)
{
   New_BBS_PS_KILL = BBS_PS_KILL;
     
   if(New_BBS_PS_KILL != Old_BBS_PS_KILL)
   {
     BBS_PS_KILL_Debounce_Count = BBS_PS_KILL_Debounce_Count - 1 ;
       
         if(BBS_PS_KILL_Debounce_Count == 0)
         {
             SystemControl.bits.Flag_PS_KILL_Debounce = New_BBS_PS_KILL;
             Old_BBS_PS_KILL = New_BBS_PS_KILL;
             if(New_BBS_PS_KILL == 1)
             {
               Clear_Failure();
             }
             BBS_PS_KILL_Debounce_Count = 13;
         }
    
   }
   else
     BBS_PS_KILL_Debounce_Count = 13;
//---------------------------------------------------------  
/*   
   New_BBS_ON = BBS_ON;

   if(New_BBS_ON != Old_BBS_ON)
   {
     BBS_ON_Debounce_Count = BBS_ON_Debounce_Count -1;
      
       if(BBS_ON_Debounce_Count == 0)
       {
         SystemControl.bits.Flag_BBS_ON_Debounce = New_BBS_ON;
         Old_BBS_ON = New_BBS_ON;
         BBS_ON_Debounce_Count = 11;
       }
   }
   else
     BBS_ON_Debounce_Count = 11;
*/
}

//-----------------   

void AD_data_type_transfor (void)
{
     u32_t tmp;

     tmp = BUCK1_AD_Temp;
 
     BBU_Info.BUCK1_Temp = (2637000 - (tmp*3223))/13600;

     tmp = BOOST_AD_Temp; 
        
     BBU_Info.BOOST_Temp = (2637000 - (tmp*3223))/13600;

     tmp = Ambient_AD_Temp;

     BBU_Info.Ambient_Temp = (2637000 - (tmp*3223))/13600;

     if(Cell_Info.Current > 0)
     {
       BBU_Info.Iin = (Cell_Info.Voltage * Cell_Info.Current / BBU_Info.BusVoltage)*100 /efficiency ;
     }
     else
     {
       BBU_Info.Iin = 0;
     } 
     BBU_Info.Pout = BBU_Info.BusVoltage * BBU_Info.Iout/1000;       //  Output Power

     BBU_Info.Pin =  BBU_Info.BusVoltage * BBU_Info.Iin/1000;        //  Input Power

     tmp = Cell_Info.RemainingCapacity;

     if(Remaining_Capacity_update_Flag == 1 && Cell_Info.Voltage >= 38000)
     {
    
       if(DISCHG_EN1 == 1 && Cell_Info.Current <= 0)
       {
          if(Cell_Info.Current < 0)
          {
            abs_Iout = -(Cell_Info.Current);
          }
          else
          {
            abs_Iout = Cell_Info.Current;
          }
         
          if(abs_Iout <= 1000)
          {
            Cell_Info.Discharge_Remain_Time = (tmp * 3600)/ ((1100000 / Cell_Info.Voltage)*1000);
          }
          else
          {
            Cell_Info.Discharge_Remain_Time = (tmp * 3600) / abs_Iout;
          }
       }
       else if(Cell_Info.Current >= 0)
       {
          Cell_Info.Discharge_Remain_Time = (tmp * 3600)/ ((1100000 / Cell_Info.Voltage)*1000);
       }

     } 

//--------------- Iout ---------------------//
     Average_Iout_count ++;
     if(Average_Iout_count == 10)
     {
       Average_Iout_count = 0;
     }

     if(Average_Iout_count == 0)
     {
       Average_Iout.Iout1 = BBU_Info.Iout;
     }
     else if(Average_Iout_count == 1)
     {
       Average_Iout.Iout2 = BBU_Info.Iout;
     }
     else if(Average_Iout_count == 2)
     {
       Average_Iout.Iout3 = BBU_Info.Iout;
     }
     else if(Average_Iout_count == 3)
     {
       Average_Iout.Iout4 = BBU_Info.Iout;
     }
     else if(Average_Iout_count == 4)
     {
       Average_Iout.Iout5 = BBU_Info.Iout;
     }
     else if(Average_Iout_count == 5)
     {
       Average_Iout.Iout6 = BBU_Info.Iout;
     }
     else if(Average_Iout_count == 6)
     {
       Average_Iout.Iout7 = BBU_Info.Iout;
     }
     else if(Average_Iout_count == 7)
     {
       Average_Iout.Iout8 = BBU_Info.Iout;
     }
     else if(Average_Iout_count == 8)
     {
       Average_Iout.Iout9 = BBU_Info.Iout;
     }
     else if(Average_Iout_count == 9)
     {
       Average_Iout.Iout10 = BBU_Info.Iout;
     }     

     BBU_Info.Average_Iout = (Average_Iout.Iout1 + Average_Iout.Iout2 + Average_Iout.Iout3 + Average_Iout.Iout4 + Average_Iout.Iout5
                              + Average_Iout.Iout6 + Average_Iout.Iout7 + Average_Iout.Iout8 + Average_Iout.Iout9 + Average_Iout.Iout10)/10;

//------------------ Buck Temp --------------------//
     if(Average_BUCK_Temp_count == 0)
     {
        Average_Temp.BUCK1 = BBU_Info.BUCK1_Temp;
     }
     else if(Average_BUCK_Temp_count == 1)
     {
        Average_Temp.BUCK2 = BBU_Info.BUCK1_Temp;
     }
     else if(Average_BUCK_Temp_count == 2)
     {
        Average_Temp.BUCK3 = BBU_Info.BUCK1_Temp;
     }
     else if(Average_BUCK_Temp_count == 3)
     {
        Average_Temp.BUCK4 = BBU_Info.BUCK1_Temp;
     }
     else if(Average_BUCK_Temp_count == 4)
     {
        Average_Temp.BUCK5 = BBU_Info.BUCK1_Temp;
     }

     BBU_Info.Average_BUCK_Temp = (Average_Temp.BUCK1 + Average_Temp.BUCK2 + Average_Temp.BUCK3
                                  + Average_Temp.BUCK4 + Average_Temp.BUCK5)/5;
      
//--------------- BOOST Temp ----------------//
     if(Average_BOOST_Temp_count == 0)
     {
       Average_Temp.BOOST1 = BBU_Info.BOOST_Temp;
     }
     else if(Average_BOOST_Temp_count == 1)
     {
       Average_Temp.BOOST2 = BBU_Info.BOOST_Temp;
     }
     else if(Average_BOOST_Temp_count == 2)
     {
       Average_Temp.BOOST3 = BBU_Info.BOOST_Temp;
     }
     else if(Average_BOOST_Temp_count == 3)
     {
       Average_Temp.BOOST4 = BBU_Info.BOOST_Temp;
     }
     else if(Average_BOOST_Temp_count == 4)
     {
       Average_Temp.BOOST5 = BBU_Info.BOOST_Temp;
     }
    
     BBU_Info.Average_BOOST_Temp = (Average_Temp.BOOST1 + Average_Temp.BOOST2 + Average_Temp.BOOST3
                                   + Average_Temp.BOOST4 + Average_Temp.BOOST5)/5;

}

//********************** Current Sharing *********************//

void Current_Sharing (void)
{
  if(Battery_Learning_Start == 1)
  {
    CS_EN = 0; 
  }
  else
  {
    if(ORING_STATUS == 0)               // confirm ORing is on 
    { 
      CS_EN = 0; 
    }
    else
    {
      CS_EN = 1;
    }
  } 
}


//****************** limit Vref(Online & Offline mode) ******************//

void Limit_Vref(void)
{
  if(u8Calibration != 5)
  {
    if(u16VrefOffline >= 4500 || u16VrefOffline <= 3900)
    {
      u16VrefOffline = 4200;
    }
     

    if(u16VrefOnline >= 4300 || u16VrefOnline <= 3700)
    {
      u16VrefOnline = 4105;
    }
    
  }
  
  
}
void Power_Decay(void)
{  
   if(Power_Decay_cnt <= 80)
   {
      Power_Decay_cnt ++;
      V_ref_Duty = V_ref_Duty - 1;
      Finish_Power_Decay_Flag = 0;
   }
   else
   {
      Finish_Power_Decay_Flag = 1;
        
   }     
}


void GetAddr(void)
{
    u8_t tmp;
    tmp = 0x50;
    if(BBS_A0 == 1) tmp |= 0x02;
	if(BBS_A1 == 1) tmp |= 0x01;
	if(BBS_A2 == 0) tmp |= 0x08;

    I2C2ADD = tmp;

}



void Protect_Delay(void)   // funtion in 1ms interrupt
{
//----------------- Input UVP delay ---------------//
  if(Charger_Delay.UV_Fault_Flag == 1)
  {
    Charger_Delay.UV_Fault_Cnt ++;
  }

  if(Charger_Delay.UV_Warning_Flag == 1)
  {
    Charger_Delay.UV_Warning_Cnt ++;
  }

//----------------- Input OVP delay ---------------//
  if(Charger_Delay.OV_Fault_Flag == 1)
  {
    Charger_Delay.OV_Fault_Cnt ++;
  }
  
  if(Charger_Delay.OV_Warning_Flag == 1)
  {
    Charger_Delay.OV_Warning_Cnt ++;
  } 

//----------------- Charger Cell OT delay -----------//
  if(Charger_Delay.Cell_OT_Fault_Flag == 1)
  {
    Charger_Delay.Cell_OT_Fault_Cnt ++;
  }

  if(Charger_Delay.Cell_OT_Warning_Flag == 1)
  {
    Charger_Delay.Cell_OT_Warning_Cnt ++;
  }

//----------------- Input OCP delay -----------------//
  if(Charger_Delay.OC_Fault_Flag == 1)
  {
    Charger_Delay.OC_Fault_Cnt ++;
  }

  if(Charger_Delay.OC_Warning_Flag == 1)
  {
    Charger_Delay.OC_Warning_Cnt ++;
  }

//----------------- Charger BOOST OT delay ------------//
  if(Charger_Delay.Boost_OT_Fault_Flag == 1)
  {
    Charger_Delay.Boost_OT_Fault_Cnt ++;
  }

  if(Charger_Delay.Boost_OT_Warning_Flag == 1)
  {
    Charger_Delay.Boost_OT_Warning_Cnt ++;
  }

//----------------- Charger OP delay ----------------//
  if(Charger_Delay.OP_Warning_Flag == 1)
  {
    Charger_Delay.OP_Warning_Cnt ++;
  }

//----------------- Output OCP delay ----------------//
  if(Discharger_Delay.OC_Fault_Flag == 1)
  {
    Discharger_Delay.OC_Fault_Cnt ++;
  }

  if(Discharger_Delay.OC_Warning_Flag == 1)
  {
    Discharger_Delay.OC_Warning_Cnt ++;
  }

//----------------- Output UVP delay ----------------//
  if(Discharger_Delay.UV_Fault_Flag == 1)
  {
    Discharger_Delay.UV_Fault_Cnt ++;
  }

  if(Discharger_Delay.UV_Warning_Flag == 1)
  {
    Discharger_Delay.UV_Warning_Cnt ++;
  }

//----------------- Output OPP delay ----------------//
  if(Discharger_Delay.OP_Fault_Flag == 1)
  {
    Discharger_Delay.OP_Fault_Cnt ++;
  }

  if(Discharger_Delay.OP_Warning_Flag == 1)
  {
    Discharger_Delay.OP_Warning_Cnt ++;
  }

//----------------- Buck OTP delay ------------------//
  if(Discharger_Delay.Buck_OT_Fault_Flag == 1)
  {
    Discharger_Delay.Buck_OT_Fault_Cnt ++;
  }

  if(Discharger_Delay.Buck_OT_Warning_Flag == 1)
  {
    Discharger_Delay.Buck_OT_Warning_Cnt ++;
  }

//----------------- Discharge Cell OT delay -----------------//
  if(Discharger_Delay.Cell_OT_Fault_Flag == 1)
  {
    Discharger_Delay.Cell_OT_Fault_Cnt ++;
  }

  if(Discharger_Delay.Cell_OT_Warning_Flag == 1)
  {
    Discharger_Delay.Cell_OT_Warning_Cnt ++;
  }

//----------------- Let Battery turn on DFET but battery flag not insert -------//
  if(Discharger_Delay.DFET_Notopen_Flag == 1)
  {
    Discharger_Delay.DFET_Notopen_Cnt ++;
  }
  


//************* Discharger detect UVP delay ***********//
  if(Discharger.UVP_Delay_Flag == 1)
  {
    Discharger.UVP_Delay_Cnt ++;
    if(Discharger.UVP_Delay_Cnt == 3000)
    {
      Discharger.UVP_Delay_Cnt = 0;
      Discharger_12V_Flag = 1;
    }
  }
  else
  {
    Discharger.UVP_Delay_Cnt = 0;
    Discharger_12V_Flag = 0;
  }

//************* Charger Fuse detect delay ************//
   if(Charger_Fuse_Broke_Flag == 1)
   {
     Charger_Fuse_Broke_cnt ++;
   }
   else
   {
     Charger_Fuse_Broke_cnt = 0;
   }

//**************** Ambient OTP delay *****************//
   if(AmbientOT_Delay_Flag == 1)
   {
     AmbientOT_Delay_Cnt ++;
   }

}

void Finish_Power_Decay(void)
{
   if(SystemControl.bits.Flag_Offline_Mode == 1)
   {
     Disable_Discharger();
     
   }
   else if(SystemControl.bits.Flag_Online_Mode == 1)
   {
//     Enable_Charger(); 
   }
     SystemControl.bits.AC_GOOD = 0;
     Discharger.state_Discharging = 0;
     asm("NOP");
     asm("NOP");
     asm("NOP");
     V_ref_Duty = u16VrefOnline;
     Finish_Power_Decay_Flag = 0;
     Power_Decay_Flag = 0;
     Power_Decay_cnt = 0;

     Battery_Learning_Start = 0;
           


   
}

/*******************************************************
*
* When BBU start up will detect AC_GOOD to decide discharge or not
* # function call at 1msec interrupt
*
*******************************************************/

void AC_GOOD_Function(void)
{
   if(BBS_AC_GOOD == 0 && SystemControl.bits.Flag_Idle_Mode == 0 && SystemControl.bits.Flag_Failure == 0)
   {
     if(SystemControl.bits.AC_GOOD == 0)
     {
       if(SystemControl.bits.Flag_Offline_Mode == 1)
       {
          Disable_Charger();                                               
          Enable_Discharger();
       }    
       else if(SystemControl.bits.Flag_Online_Mode == 1)
       {
          Disable_Charger();     
          SystemControl.bits.Flag_Online_Charge = 0;       
          V_ref_Duty = u16VrefOffline;  
        
       }

       Charger.state_Initial = 1;
       Charger.state_FullyCharge = 0;
       Charger.state_Charging = 0;
       Charger.state_Inhibit = 0;
  
       SystemControl.bits.AC_GOOD = 1;
       u16StatusP0Word = (u16StatusP0Word & ~(Status_Word_bits_Power_Good));
       u16StatusP1Word = (u16StatusP1Word & ~(Status_Word_bits_Power_Good));

       Discharger_Delay_Flag = 0;
       Discharger_Delay_cnt = 0;
       Power_Decay_Flag = 0;
       Power_Decay_cnt = 0; 
       Finish_Power_Decay_Flag = 0;
       SystemControl.bits.Flag_Charge_to_Discharge = 1;             // need goto Discharger 
       SystemControl.bits.Flag_Discharge_to_Charge = 0;

     
     


        INTCON2bits.INT1EP = 0;       // 0 -> Interrupt on pastive edge, turn Low to High goto interrupt   
        IFS1bits.INT1IF = 0;
        return;
       
     }
   }
}

/*******************************************************************
*
* If have any protection need to write to EEPROM for last protect
* used in Failure state
*
********************************************************************/

void EEPROM_Write_Protect(void)
{
           //-------------- if have any protection write EEPROM -------------//
   if(SystemControl.bits.Flag_Failure == 1 || SystemControl.bits.Flag_Not_Reset_Failure == 1)
   {
     EEPROM_Failure_count ++;

     if(EEPROM_Failure_count <= 5)
     {
      EEPROM_Failure_Write();
     }
     else
     {
      EEPROM_Failure_count = 6;
     } 
   }
   else
   {
     EEPROM_Failure_count = 0;
   }
}


void Compatible_Code_Compare(void)
{
   if(EEPROM_Info.HW_Compatible_Code != ((tsRevCtrlBlock.pu8HwCompCode[0] << 8) + tsRevCtrlBlock.pu8HwCompCode[1]) && EEPROM_Info.HW_Compatible_Code != 0xFFFF)
   {
      pu8BBUCompatible[10] = 0x01;
      HW_Not_Compatible_Flag = 1;
   }
}



