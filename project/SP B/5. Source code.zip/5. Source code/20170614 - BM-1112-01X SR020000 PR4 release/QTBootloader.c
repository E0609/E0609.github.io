/*******************************************************************************
* file				QTBootLoader.c
* brief				The file includes the function of Quanta bootloader.
* note
* author			vincent.liu
* version			01
* section History	2016/03/ - 1st release
*******************************************************************************/
#include "QTBootLoader.h"
#include "SI2CDrv.h"
#include "PMBusApp.h"
#include "PMBusData.h"
#include "CRC.h"
#include <string.h>
#include "LED_Display.h"
#ifndef BOOT_AREA
#ifdef BYPASS_SUPPORT
//#include "MstrPMBusApp.h"
#endif
#endif
/*******************************************************************************
* declare variable
*******************************************************************************/
//=====================================
//Quanta bootloader data structure in ram
//=====================================
sQTBtldrStr_t sQTBtldr;
sQTBtldrCmdStr_t sQTBtldrCmd;
u16_t u16BootPassword __attribute__((address(BOOT_PASSWORD_STARTADDR)));
u16_t u16BootPassword __attribute__((persistent));
//=====================================
//Quanta bootloader data structure in flash
//=====================================
#ifndef BOOT_AREA
u8_t pu8AppPassword[2] __attribute__(( space(prog), address(APP_PASSWORD_STARTADDR))) = {0x55,0xaa};
#endif
/*******************************************************************************
*	brief 	Quanta bootloader commands initial
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
void QTBootloaderCommInit(void)
{
	sQTBtldr.u8RxIdx = 0;
	sQTBtldr.u8RxLen = 0xff;
	sQTBtldr.u8TxIdx = 0;
	sQTBtldr.u8TxLen = 0;
	sQTBtldr.pu8RxDataPtr = NULL;
	sQTBtldr.pu8TxDataPtr = NULL;
}
/*******************************************************************************
*   brief 	set the variable according to data length for write operation
*	para1:	the data pointer of write operation
* 	para2:	the data length of write operation
* 	para3:	1 -> save data in temp; 0 -> move data to target variable
*******************************************************************************/
static void SetRxVariable(u8_t* pu8Buff, u8_t u8Length, u8_t u8WriteTemp)
{
	static u8_t pu8TempBuff[BOOT_RXBUFF_LEN];
	static u8_t u8TempLeng;

	if(u8WriteTemp)
	{
		memcpy(pu8TempBuff, pu8Buff, u8Length);
		u8TempLeng = u8Length;
	}
	else
	{
		memcpy(sQTBtldr.pu8RxDataPtr, pu8TempBuff, u8TempLeng);
	}
}
/*******************************************************************************
*	brief 	determine the state of Quanta bootloader
*	para1:	none
*	para2:	none
*	return: none
*	note  : this function should put in uart interrupt service routine
*******************************************************************************/
static void QTBootloaderState(u8_t u8Command)
{
	switch (u8Command)
	{
		case BTLDR_KEY:
			sQTBtldr.u8State = Task_VerifyBootKey;
			break;
		case BTLDR_CMD_STATUS:
			if(sQTBtldrCmd.u8Command == CMD_CLEARSTAT)
			{
				sQTBtldr.u8State = Task_ClearStatus;
			}
			else if(sQTBtldrCmd.u8Command == CMD_RESETSEQ)
			{
				sQTBtldr.u8State = Task_RestartBoot;
			}
			else if(sQTBtldrCmd.u8Command == CMD_BOOTISP)
			{
				sQTBtldr.nQTBtldrFlag.u16Bit.u1BypassMode = 0;
				sQTBtldr.u8State = Task_EnterBootMode;
			}
			else if(sQTBtldrCmd.u8Command == CMD_BOOTISPBYPASS)
			{
				sQTBtldr.nQTBtldrFlag.u16Bit.u1BypassMode = 1;
				sQTBtldr.u8State = Task_EnterBootMode;
			}
			else if(sQTBtldrCmd.u8Command == CMD_BOOTPM)
			{
				sQTBtldr.u8State = Task_EnterAppMode;
			}
			break;
		case BTLDR_MEMORYBLOCK:
			sQTBtldr.u8State = Task_WriteMemoryBlock;
			break;
		case BTLDR_PRODUCTKEY:
			sQTBtldr.u8State = Task_VerifyProductKey;
			break;
		case BTLDR_IMAGECKECKSUM:
			sQTBtldr.u8State = Task_VerifyImageSum;
			break;
		default:
			break;
	}
}
/*******************************************************************************
*	brief 	execute Quanta bootloader commands received task
*	para1:	none
*	para2:	none
*	return: none
*	note  : this function should put in uart interrupt service routine
*******************************************************************************/
void QTBootloaderRxParse(void)
{
	u8_t i;
	u8_t u8PEC = 0;

	// receive command from system, reset key lock timer
	sQTBtldr.u16KeyLockTimer = KEYLOCK_DELAY;

	// get received data from driver
	sQTBtldr.u8RxIdx = GetSI2CRxIdx(sQTBtldr.pu8RxBuff, BOOT_RXBUFF_LEN);

	// determine the received data length of write operation
	// u8RxLen:include addr, cmd, data, and PEC for write operation
	// u8TxLen:include data, and PEC for read operation
	// u8TxIdx:include data for read operation
	if(sQTBtldr.u8RxIdx == 1)
	{
		switch (sQTBtldr.pu8RxBuff[1])
		{
			case BTLDR_KEY:
				// for write operation
				sQTBtldr.u8RxLen = 7;
				sQTBtldr.pu8RxDataPtr = &sQTBtldrCmd.pu8Key[0];
				break;
			case BTLDR_CMD_STATUS:
				// for write operation
				sQTBtldr.u8RxLen = 4;
				sQTBtldr.pu8RxDataPtr = &sQTBtldrCmd.u8Command;
				// for read operation
				sQTBtldr.u8TxLen = 2;
				sQTBtldr.u8TxIdx = 1;
				sQTBtldr.pu8TxDataPtr = &sQTBtldrCmd.u8Status;
				break;
			case BTLDR_MEMORYBLOCK:
				// for write operation
				sQTBtldr.u8RxLen = 35;
				sQTBtldr.pu8RxDataPtr = &sQTBtldrCmd.pu8MemoryBlock[0];
				// for read operation
				sQTBtldr.u8TxLen = 33;
				sQTBtldr.u8TxIdx = 32;
				sQTBtldr.pu8TxDataPtr = &sQTBtldrCmd.pu8MemoryBlock[0];
				break;
			case BTLDR_PRODUCTKEY:
				// for write operation
				sQTBtldr.u8RxLen = 19;
				sQTBtldr.pu8RxDataPtr = &sQTBtldrCmd.pu8ProductKey[0];
				break;
			case BTLDR_IMAGECKECKSUM:
				// for write operation
				sQTBtldr.u8RxLen = 5;
				sQTBtldr.pu8RxDataPtr = (u8_t*)&sQTBtldrCmd.u16ImageChecksum;
				// for read operation
				sQTBtldr.u8TxLen = 3;
				sQTBtldr.u8TxIdx = 2;
				sQTBtldr.pu8TxDataPtr = (u8_t*)&sQTBtldrCmd.u16ImageChecksum;
				break;
			default:
				break;
		}
	}
	// save the received data without PEC in temp buffer
	else if(sQTBtldr.u8RxIdx == sQTBtldr.u8RxLen - 2)
	{
		SetRxVariable(&sQTBtldr.pu8RxBuff[2], sQTBtldr.u8RxLen - 3, 1);
		sQTBtldr.nQTBtldrFlag.u16Bit.u1MapRxData = 1;
	}
	// check & save the received data with PEC
	else if(sQTBtldr.u8RxIdx == sQTBtldr.u8RxLen - 1)
	{
		// calculate PEC
		for(i = 0;i < sQTBtldr.u8RxIdx;i++)
		{
			CalCRC8(&u8PEC, sQTBtldr.pu8RxBuff[i]);
		}

		// store data if the PEC is correct
		if(sQTBtldr.pu8RxBuff[sQTBtldr.u8RxIdx] == u8PEC)
		{
			SetRxVariable(&sQTBtldr.pu8RxBuff[2], sQTBtldr.u8RxLen - 3, 0);
			QTBootloaderState(sQTBtldr.pu8RxBuff[1]);
		}
		else
		{
			UpdateStatusBit(PMBusCmd_StatusCML, 5, 1);
		}

		sQTBtldr.nQTBtldrFlag.u16Bit.u1MapRxData = 0;
	}
}
/*******************************************************************************
*	brief 	execute Quanta bootloader commands response task
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
void QTBootloaderTxParse(void)
{
	u8_t i;
	u8_t u8PEC = 0;

	if(sQTBtldr.pu8TxDataPtr != NULL)
	{
		memcpy(&sQTBtldr.pu8TxBuff[0], sQTBtldr.pu8TxDataPtr, sQTBtldr.u8TxIdx);

		for(i = 0;i <= sQTBtldr.u8RxIdx;i++)
		{
			CalCRC8(&u8PEC, sQTBtldr.pu8RxBuff[i]);
		}

		CalCRC8(&u8PEC, sQTBtldr.pu8RxBuff[0]+1);

		for(i = 0;i < sQTBtldr.u8TxIdx;i++)
		{
			CalCRC8(&u8PEC, sQTBtldr.pu8TxBuff[i]);
		}

		sQTBtldr.pu8TxBuff[sQTBtldr.u8TxIdx] = u8PEC;
	}

	SI2CTxWrite(&sQTBtldr.pu8TxBuff[0], sQTBtldr.u8TxLen);
}
/*******************************************************************************
*	brief 	save the received data without PEC
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
void QTBootloaderMapRxData(void)
{
	u8_t* pu8Tmp;

	// check if I2C stop condition finished
	if(CheckBusStatus())
	{
		if(sQTBtldr.nQTBtldrFlag.u16Bit.u1MapRxData)
		{
			SetRxVariable(pu8Tmp, 0, 0);
			QTBootloaderState(sQTBtldr.pu8RxBuff[1]);
			sQTBtldr.nQTBtldrFlag.u16Bit.u1MapRxData = 0;
		}
	}
}
/*******************************************************************************
*	brief 	check the boot password if exist or not
*	para1:	none
*	para2:	none
*	return: 1:exist;0:not exist
*******************************************************************************/
#ifdef BOOT_AREA
static u8_t BootPasswordCheck(void)
{
	if(u16BootPassword == BOOT_PASSWORD)
		return 1;
	else
		return 0;
}
#endif
/*******************************************************************************
*	brief 	write the boot password to flash
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
#ifndef BOOT_AREA
static void WriteBootPassword(void)
{
	u16BootPassword = BOOT_PASSWORD;
}
#endif
/*******************************************************************************
*	brief 	check the app password if exist or not
*	para1:	none
*	para2:	none
*	return: 1:exist;0:not exist
*******************************************************************************/
#ifdef BOOT_AREA
static u8_t AppPasswordCheck(void)
{
	u8_t pu8Buffer[2];

	ReadFlash2Ram(APP_PASSWORD_STARTADDR, pu8Buffer, 2);

	if((pu8Buffer[0] == (APP_PASSWORD & 0xff)) && (pu8Buffer[1] == (APP_PASSWORD >> 8)))
		return 1;
	else
		return 0;
}
#endif
/*******************************************************************************
*	brief 	write the app password to flash
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
#ifdef BOOT_AREA
static void WriteAppPassword(void)
{
	u8_t pu8Buffer[2];

	pu8Buffer[0] = APP_PASSWORD & 0xff;
	pu8Buffer[1] = APP_PASSWORD >> 8;

	WriteRam2Flash(APP_PASSWORD_STARTADDR, pu8Buffer, 2);
}
#endif
/*******************************************************************************
*	brief 	initial Quanta bootloader parameters
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
void QTBootloaderInit(void)
{
	sQTBtldr.u8State = Task_Idle;
	sQTBtldrCmd.u8Status |= (STATUS_KEYERR | STATUS_PRODUCTKEYERR);

	#ifdef BOOT_AREA
	// indicate program run in boot mode
	sQTBtldrCmd.u8Status |= STATUS_BOOTMODE;
	sQTBtldrCmd.u8Status |= STATUS_STARTERR;

	// check boot password
	if(BootPasswordCheck())
	{
		u16BootPassword = 0;
		sQTBtldr.nQTBtldrFlag.u16Bit.u1BootStay = 1;
		sQTBtldr.nQTBtldrFlag.u16Bit.u2ISPUnlock = 2;
		sQTBtldrCmd.u8Status &= (~(STATUS_KEYERR | STATUS_PRODUCTKEYERR));
		sQTBtldr.u16KeyLockTimer = KEYLOCK_DELAY;
	}

	// check app password
	if(AppPasswordCheck())
	{
		sQTBtldr.nQTBtldrFlag.u16Bit.u1AppExist = 1;
		sQTBtldrCmd.u8Status &= (~STATUS_STARTERR);
	}
	#else
	u16BootPassword = 0;
	#endif
}
/*******************************************************************************
*	brief 	verify the bootloader key
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
static void VerifyBootKey(void)
{
	if(u8WriteProtect == 0x00)
	{
		if((strncmp((char*)QUANTA_BTLDR_KEY, (char*)sQTBtldrCmd.pu8Key, 4)) == 0)
		{
			sQTBtldr.nQTBtldrFlag.u16Bit.u2ISPUnlock = 1;
			sQTBtldrCmd.u8Status &= (~STATUS_KEYERR);
		}
	}
}
/*******************************************************************************
*	brief 	verify the product key
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
static void VerifyProductKey(void)
{
	if(sQTBtldr.nQTBtldrFlag.u16Bit.u2ISPUnlock == 1)
	{
		if((strncmp((char*)LITEON_BTLDR_KEY, (char*)sQTBtldrCmd.pu8ProductKey, 16)) == 0)
		{
			sQTBtldr.nQTBtldrFlag.u16Bit.u2ISPUnlock = 2;
			sQTBtldrCmd.u8Status &= (~STATUS_PRODUCTKEYERR);
		}
	}
}
/*******************************************************************************
*	brief 	reset MFR_ISP_STATUS to initial value
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
static void ClearStatus(void)
{
	sQTBtldrCmd.u8Status = (sQTBtldrCmd.u8Status & (STATUS_BOOTMODE | STATUS_STARTERR)) | (STATUS_KEYERR | STATUS_PRODUCTKEYERR);
}
/*******************************************************************************
*	brief 	re-initial bootloader parameters
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
#ifdef BOOT_AREA
static void RestartBoot(void)
{
	if(sQTBtldr.nQTBtldrFlag.u16Bit.u2ISPUnlock == 2)
	{
		sQTBtldr.u8State = Task_Idle;
		sQTBtldr.u8McuResetTimer = 0;
		sQTBtldr.u16CheckSum = 0;
		sQTBtldr.u32AddrIndex = IMAGE_APP_STARTADDR;
		sQTBtldr.nQTBtldrFlag.u16All &= 0x00ff;
        u8StatusP0CML = 0x00;

		sQTBtldrCmd.u8Status = sQTBtldrCmd.u8Status & (STATUS_BOOTMODE | STATUS_KEYERR | STATUS_STARTERR | STATUS_PRODUCTKEYERR);
	}
}
#endif
/*******************************************************************************
*	brief 	jump to boot mode
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
#ifndef BOOT_AREA
static void EnterBootMode(void)
{
	if(sQTBtldr.nQTBtldrFlag.u16Bit.u2ISPUnlock == 2)
	{
		sQTBtldr.u8GoBootTimer = GOBOOT_TIME;
	}
}
#endif
/*******************************************************************************
*	brief 	reset MCU reset timer if App image area is fully updated
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
#ifdef BOOT_AREA
static void McuReset(void)
{
	if(sQTBtldr.nQTBtldrFlag.u16Bit.u2ISPUnlock == 2)
	{
		sQTBtldr.u8McuResetTimer = MCURESET_TIME;
	}
}
#endif
/*******************************************************************************
*	brief 	write new image to App image area
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
#ifdef BOOT_AREA
static void WriteMemoryBlock(void)
{
	u8_t i;
	u32_t u32EraseAddrIndex, u32WriteAddrIndex;

	if(sQTBtldr.nQTBtldrFlag.u16Bit.u2ISPUnlock == 2)
	{
		// calculate the checksum of total received data
		for(i = 0;i < TRANSMIT_BYTENUM;i++)
		{
			sQTBtldr.u16CheckSum += sQTBtldrCmd.pu8MemoryBlock[i];
		}

		// check if need to erase App image area
		if(sQTBtldr.nQTBtldrFlag.u16Bit.u1EraseFlashDone == 0)
		{
			u32EraseAddrIndex = IMAGE_APP_STARTADDR;

			sQTBtldrCmd.u8Status |= STATUS_PRGMBUSY;
			for(i = 0;i < IMAGE_APP_PAGENUMBER;i++)
			{
				EraseFlashPage(u32EraseAddrIndex);
				u32EraseAddrIndex += ERASE_PAGE_SIZE;
			}
			sQTBtldrCmd.u8Status &= (~STATUS_PRGMBUSY);

			sQTBtldr.nQTBtldrFlag.u16Bit.u1EraseFlashDone = 1;
		}

		// write data to App image area

		if(sQTBtldr.u32AddrIndex >= IMAGE_APP_ENDADDR)
		{
			sQTBtldrCmd.u8Status |= STATUS_MEMERR;
		}
		else
		{
			if(sQTBtldr.u32AddrIndex >= IMAGE_APP_STARTADDR)
			{
				// write one memory block data to App image area
				sQTBtldrCmd.u8Status |= STATUS_PRGMBUSY;
				for(i = 0;i < TRANSMIT_INSNUM;i++)
				{
					u32WriteAddrIndex = sQTBtldr.u32AddrIndex + i*2;

					if(u32WriteAddrIndex != APP_PASSWORD_STARTADDR)
					{
						WriteFlashIns(u32WriteAddrIndex, &sQTBtldrCmd.pu8MemoryBlock[i*4], 4);

						if(VerifyFlashIns(u32WriteAddrIndex, &sQTBtldrCmd.pu8MemoryBlock[i*4], 4))
						{
							sQTBtldr.nQTBtldrFlag.u16Bit.u1FlashError = 1;
						}
					}

				}
				sQTBtldrCmd.u8Status &= (~STATUS_PRGMBUSY);
			}
		}

		sQTBtldr.u32AddrIndex += TRANSMIT_WORDNUM;
	}
}
#endif
/*******************************************************************************
*	brief 	verify the image checksum
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
#ifdef BOOT_AREA
static void VerifyImageSum(void)
{
	if(sQTBtldr.nQTBtldrFlag.u16Bit.u2ISPUnlock == 2)
	{
		if((sQTBtldr.u16CheckSum == sQTBtldrCmd.u16ImageChecksum) &&
		   (sQTBtldr.nQTBtldrFlag.u16Bit.u1FlashError == 0))
		{
			sQTBtldr.nQTBtldrFlag.u16Bit.u1WriteFlashDone = 1;
			sQTBtldrCmd.u8Status |= STATUS_CHKSUM_SUCCESSFUL;
			sQTBtldrCmd.u8Status &= (~STATUS_STARTERR);
		}
	}
}
#endif
/*******************************************************************************
*	brief 	execute Quanta bootloader task
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
void QTBootloaderProcess(void)
{
	switch (sQTBtldr.u8State)
	{
		case Task_Idle:
			Nop();
			break;
		//----------------------------------------------------------------------
		case Task_VerifyBootKey:
			VerifyBootKey();
			#ifndef BOOT_AREA
			#ifdef BYPASS_SUPPORT
			BuildBypassTxData(BTLDR_KEY, sQTBtldrCmd.pu8Key, 4);
			#endif
			#endif
			sQTBtldr.u8State = Task_Idle;
			break;
		//----------------------------------------------------------------------
		case Task_VerifyProductKey:
			VerifyProductKey();
			#ifndef BOOT_AREA
			#ifdef BYPASS_SUPPORT
			BuildBypassTxData(BTLDR_PRODUCTKEY, sQTBtldrCmd.pu8ProductKey, 16);
			#endif
			#endif
			sQTBtldr.u8State = Task_Idle;
			break;
		//----------------------------------------------------------------------
		case Task_ClearStatus:
			if(sQTBtldr.nQTBtldrFlag.u16Bit.u1BypassMode == 0)
			{
				ClearStatus();
			}
			else
			{
				#ifndef BOOT_AREA
				#ifdef BYPASS_SUPPORT
				BuildBypassTxData(BTLDR_CMD_STATUS, &sQTBtldrCmd.u8Command, 1);
				#endif
				#endif
			}
			sQTBtldr.u8State = Task_Idle;
			break;
		//----------------------------------------------------------------------
		case Task_RestartBoot:
			if(sQTBtldr.nQTBtldrFlag.u16Bit.u1BypassMode == 0)
			{
				#ifdef BOOT_AREA
				RestartBoot();
				#endif
			}
			else
			{
				#ifndef BOOT_AREA
				#ifdef BYPASS_SUPPORT
				BuildBypassTxData(BTLDR_CMD_STATUS, &sQTBtldrCmd.u8Command, 1);
				#endif
				#endif
			}
			sQTBtldr.u8State = Task_Idle;
			break;
		//----------------------------------------------------------------------
		case Task_EnterBootMode:
			if(sQTBtldr.nQTBtldrFlag.u16Bit.u1BypassMode == 0)
			{
				#ifndef BOOT_AREA
                VerifyBootKey();
                VerifyProductKey();
				EnterBootMode();
				#endif
			}
			else
			{
				#ifndef BOOT_AREA
				#ifdef BYPASS_SUPPORT
				BuildBypassTxData(BTLDR_CMD_STATUS, &sQTBtldrCmd.u8Command, 1);
				sQTBtldr.u16ReadStatusTimer = ENTERBOOTMODE_RDBACK_DELAY;
				#endif
				#endif
			}
			sQTBtldr.u8State = Task_Idle;
			break;
		//----------------------------------------------------------------------
		case Task_EnterAppMode:
			if(sQTBtldr.nQTBtldrFlag.u16Bit.u1BypassMode == 0)
			{
				#ifdef BOOT_AREA
				McuReset();
				#endif
			}
			else
			{
				#ifndef BOOT_AREA
				#ifdef BYPASS_SUPPORT
				BuildBypassTxData(BTLDR_CMD_STATUS, &sQTBtldrCmd.u8Command, 1);
				sQTBtldr.u16ReadStatusTimer = ENTERAPPMODE_RDBACK_DELAY;
				#endif
				#endif
			}
			sQTBtldr.u8State = Task_Idle;
			break;
		//----------------------------------------------------------------------
		case Task_WriteMemoryBlock:
			if(sQTBtldr.nQTBtldrFlag.u16Bit.u1BypassMode == 0)
			{
				#ifdef BOOT_AREA
				WriteMemoryBlock();
				#endif
			}
			else
			{
				#ifndef BOOT_AREA
				#ifdef BYPASS_SUPPORT
				BuildBypassTxData(BTLDR_MEMORYBLOCK, sQTBtldrCmd.pu8MemoryBlock, 32);
				#endif
				#endif
			}
			sQTBtldr.u8State = Task_Idle;
			break;
		//----------------------------------------------------------------------
		case Task_VerifyImageSum:
			if(sQTBtldr.nQTBtldrFlag.u16Bit.u1BypassMode == 0)
			{
				#ifdef BOOT_AREA
				VerifyImageSum();
				#endif
			}
			else
			{
				#ifndef BOOT_AREA
				#ifdef BYPASS_SUPPORT
				BuildBypassTxData(BTLDR_IMAGECKECKSUM, &sQTBtldrCmd.u16ImageChecksum, 2);
				sQTBtldr.u16ReadStatusTimer = VERIFYIMAGESUM_RDBACK_DELAY;
				#endif
				#endif
			}
			sQTBtldr.u8State = Task_Idle;
			break;
		//----------------------------------------------------------------------
		default:
			Nop();
			break;
	}
}
/*******************************************************************************
*	brief 	force device to go to a specific flash address
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
#ifdef BOOT_AREA
static void GotoFlashAddr(u32_t u32FlashAddr)
{
	asm("goto %0" : : "r"(u32FlashAddr));
}
#endif
/*******************************************************************************
*	brief 	after bootloader finished, delay to reset device
*	para1:	none
*	para2:	none
*	return: none
*   note:   this function is only used in boot project
*******************************************************************************/
#ifdef BOOT_AREA
void BootDoneReset(void)
{
	if(sQTBtldr.u8McuResetTimer != 0)
	{
		sQTBtldr.u8McuResetTimer--;
		if(sQTBtldr.u8McuResetTimer == 0)
		{
			if(sQTBtldr.nQTBtldrFlag.u16Bit.u1EraseFlashDone == 0)
			{
				asm("RESET");
			}
			else
			{
				if((sQTBtldr.nQTBtldrFlag.u16Bit.u1EraseFlashDone == 1) &&
				   (sQTBtldr.nQTBtldrFlag.u16Bit.u1WriteFlashDone == 1))
				{
					WriteAppPassword();
					asm("RESET");
				}
			}
		}
	}
}
#endif
/*******************************************************************************
*	brief 	delay to go to app area
*	para1:	none
*	para2:	none
*	return: none
*   note:   this function is only used in boot project
*******************************************************************************/
#ifdef BOOT_AREA
void GotoApp(void)
{
	if((sQTBtldr.nQTBtldrFlag.u16Bit.u1BootStay == 0) && (sQTBtldr.nQTBtldrFlag.u16Bit.u1AppExist == 1))
	{
		sQTBtldr.u8GoAppTimer++;
		if(sQTBtldr.u8GoAppTimer == GOAPP_TIME)
		{
			//-----------------------------------------
			// user should turn off all the peripherals
			// and INTs here, need to be modified
			//-----------------------------------------
			T1CONbits.TON = 0;
			IFS0bits.T1IF = 0;
            T4CONbits.TON = 0;
            IEC1bits.T4IE = 0;
            IFS1bits.T4IF = 0;
			IEC3bits.SI2C2IE = 0;
			I2C2CONbits.I2CEN = 0;
			IFS3bits.SI2C2IF = 0;
			INTCON2bits.ALTIVT = 0;
			//-----------------------------------------
			GotoFlashAddr(IMAGE_APP_RESETADDR);
		}
	}
}
#endif
/*******************************************************************************
*	brief 	delay to go to boot area
*	para1:	none
*	para2:	none
*	return: none
*   note:   this function is only used in app project
*******************************************************************************/
#ifndef BOOT_AREA
void GotoBoot(void)
{
	if(sQTBtldr.u8GoBootTimer != 0)
	{
		sQTBtldr.u8GoBootTimer--;
		if(sQTBtldr.u8GoBootTimer == 0)
		{
            LED_Display_off();
            CS_EN = 1;
            LED_Display_off();
			WriteBootPassword();
			asm("RESET");
		}
	}
}
#endif
/*******************************************************************************
*	brief 	delay to read back status command
*	para1:	none
*	para2:	none
*	return: none
*   note:   this function is only used for bypass mode & in app project
*******************************************************************************/
#ifndef BOOT_AREA
#ifdef BYPASS_SUPPORT
void ReadBackStatus(void)
{
	if(sQTBtldr.u16ReadStatusTimer != 0)
	{
		sQTBtldr.u16ReadStatusTimer--;
		if(sQTBtldr.u16ReadStatusTimer == 0)
		{
			MstrPMBusExternalCmd(BTLDR_CMD_STATUS);
		}
	}
}
#endif
#endif
/*******************************************************************************
*	brief 	delay to lock boot key & product key
*	para1:	none
*	para2:	none
*	return: none
*   note:   none
*******************************************************************************/
void KeyLock(void)
{
	if(sQTBtldr.u16KeyLockTimer != 0)
	{
		sQTBtldr.u16KeyLockTimer--;
		if(sQTBtldr.u16KeyLockTimer == 0)
		{
			sQTBtldr.nQTBtldrFlag.u16Bit.u2ISPUnlock = 0;
			sQTBtldrCmd.u8Status |= (STATUS_KEYERR | STATUS_PRODUCTKEYERR);
		}
	}
}
/*******************************************************************************
* end of file
*******************************************************************************/
