#ifndef __Discharge_control_H__
#define __Discharge_control_H__

#include <p24FJ64GA006.h>
#include "bms_Pin_Define.h"
#include "GenericTypeDefs.h"
#include "I2C.h"
#include "Battery_status.h"
#include "Charge_control.h"
#include "FW_Config.h"
#include "main.h"


void Online_Discharge_control(void);
void Offline_Discharge_control(void);
void Enable_Discharger(void);
void Disable_Discharger(void);
void Discharger_State_set(u8_t state);
void Discharger_Control(void);
void Discharger_Run_Time(void);
void Discharger_Power_Decay(void);
void Discharger_Failure_type_Detect(void);
void Discharger_Warning_type_Detect(void);


extern u8_t  Discharger_12V_Flag;

          
enum
{
  Discharger_state_Initial,
  Discharger_state_Discharging,
  Discharger_state_Failure,
  Discharger_state_Inhibit1
};



typedef struct
{
  u8_t  Run_Time_10ms;
  u8_t  Run_Time_1s;
  u8_t  Run_Time_Warning:1;
  u8_t  Run_Time_Limit:1;
  u8_t  Condition_state;
  u8_t  Decay_state;
  u8_t  state_Discharging;
  u8_t  state_Failure;
  u8_t  state_Inhibit;
  u8_t  UVP_Delay_Flag;
  u16_t  UVP_Delay_Cnt;

}Discharger_T;



extern Discharger_T  Discharger;

#endif
