#include <p24FJ64GA006.h>
#include "bms_Pin_Define.h"
#include "Battery_status.h"	
#include "Charge_control.h"
#include "Discharge_control.h"
#include "Failure.h"
#include "FW_config.h"
#include "GenericTypeDefs.h"
#include "I2C.h"
#include "LED_Display.h"
#include "main.h"
#include "PMBusData.h"

u8_t LED_WriteRed_count = 0;
u8_t LED_WriteGreen_count = 0;
u8_t LED_WriteAmber_count = 0;
u8_t LED_Green_Status = 0;
u8_t LED_Red_Status = 0;
u8_t LED_Amber_Status = 0;
u8_t LED_Off_Status = 0;
u8_t LED_BlinkGreen_Status = 0;
u8_t LED_BlinkAmber_Status = 0;
u8_t LED_BlinkRed_Status = 0;

LED_Status_T LED_Status;

void LED_Display_Red(void)
{
    if(TEST3 == 1 && TEST4 == 0 && LED_Red_Status == 1)
    {
    }
    else
    { 
     I2C1_write(Battery_Address,Battery_LED_Status,Battery_LED_Solid_Red_data_low,Battery_LED_data_high);
     TEST3 = 1;
     TEST4 = 0;
     LED_Green_Status = 0;
     LED_Red_Status = 1;
     LED_Amber_Status = 0;
     LED_Off_Status = 0;
     LED_BlinkGreen_Status = 0;
     LED_BlinkAmber_Status = 0;
     LED_BlinkRed_Status = 0;
     
    }
}

void LED_Display_Green(void)
{
    if(TEST3 == 0 && TEST4 == 1 && LED_Green_Status == 1)
    {
    }
    else
    { 
     I2C1_write(Battery_Address,Battery_LED_Status,Battery_LED_Solid_Green_data_low,Battery_LED_data_high);
     TEST3 = 0;
     TEST4 = 1;
     LED_Green_Status = 1;
     LED_Red_Status = 0;
     LED_Amber_Status = 0;
     LED_Off_Status = 0;
     LED_BlinkGreen_Status = 0;
     LED_BlinkAmber_Status = 0;
     LED_BlinkRed_Status = 0;
    }
}

void LED_Display_Amber(void)
{
    if(TEST3 == 1 && TEST4 == 1 && LED_Amber_Status == 1)
    {
    }
    else
    {
     I2C1_write(Battery_Address,Battery_LED_Status,Battery_LED_Solid_Amber_data_low,Battery_LED_data_high);
     TEST3 = 1;
     TEST4 = 1;
     LED_Green_Status = 0;
     LED_Red_Status = 0;
     LED_Amber_Status = 1;
     LED_Off_Status = 0;
     LED_BlinkGreen_Status = 0;
     LED_BlinkAmber_Status = 0;
     LED_BlinkRed_Status = 0;
    }
}

void LED_Display_BlinkGreen(void)
{  
   if(LED_BlinkGreen_Status == 1)
   {
   }
   else
   {
     I2C1_write(Battery_Address,Battery_LED_Status,Battery_LED_Blink_Green_data_low,Battery_LED_data_high);
     LED_Green_Status = 0;
     LED_Red_Status = 0;
     LED_Amber_Status = 0;
     LED_Off_Status = 0;
     LED_BlinkGreen_Status = 1;
     LED_BlinkAmber_Status = 0;
     LED_BlinkRed_Status = 0;
   }
   if(LED_Status.flag == 1)
   {
     TEST3 = 0;
     TEST4 = 1;      
   }
   else
   {
     TEST3 = 0;
     TEST4 = 0;
   }
}

void LED_Display_BlinkAmber(void)
{
   if(LED_BlinkAmber_Status == 1)
   {
   }
   else
   {
     I2C1_write(Battery_Address,Battery_LED_Status,Battery_LED_Blink_Amber_data_low,Battery_LED_data_high);
     LED_Green_Status = 0;
     LED_Red_Status = 0;
     LED_Amber_Status = 0;
     LED_Off_Status = 0;
     LED_BlinkGreen_Status = 0;
     LED_BlinkAmber_Status = 1;
     LED_BlinkRed_Status = 0;
   }
   if(LED_Status.flag == 1)
   {
     TEST3 = 1;
     TEST4 = 1;
   }
   else
   {
     TEST3 = 0;
     TEST4 = 0;
   }
}

void LED_Display_BlinkRed(void)
{
   if(LED_BlinkRed_Status == 1)
   {
   }
   else
   {
     I2C1_write(Battery_Address,Battery_LED_Status,Battery_LED_Blink_Red_data_low,Battery_LED_data_high);
     LED_Green_Status = 0;
     LED_Red_Status = 0;
     LED_Amber_Status = 0;
     LED_Off_Status = 0;
     LED_BlinkGreen_Status = 0;
     LED_BlinkAmber_Status = 0;
     LED_BlinkRed_Status = 1;
   }
   if(LED_Status.flag == 1)
   {
     TEST3 = 1;
     TEST4 = 0;
   }
   else
   {
     TEST3 = 0;
     TEST4 = 0;
   }
}

void LED_Display_off(void)
{
  if(TEST3 == 0 && TEST4 == 0 && LED_Off_Status == 1)
  {
  }
  else
  {
    I2C1_write(Battery_Address,Battery_LED_Status,Battery_LED_off_data_low,Battery_LED_data_high);
    TEST3 = 0;
    TEST4 = 0;
    LED_Green_Status = 0;
    LED_Red_Status = 0;
    LED_Amber_Status = 0;
    LED_Off_Status = 1;
    LED_BlinkGreen_Status = 0;
    LED_BlinkAmber_Status = 0;
    LED_BlinkRed_Status = 0;
  }
}


void LED_Test(void)
{
  if(SystemControl.bits.Flag_Failure == 1)
  {
     LED_Display_Red();
  }
  else if(Failure_type.bits.Cell_PF == 1)
  {
    LED_Display_BlinkRed();
  }
  else if(Failure_type.bits.Ambient_OTP == 1 || Failure_type.bits.Charger_BOOST_OTP == 1
          || Failure_type.bits.Discharger_BUCK1_OTP == 1 || Failure_type.bits.Discharger_Cell_OTP == 1)
  {
    LED_Display_Red();
  }
  else if(SystemControl.bits.Flag_Not_Reset_Failure == 1 || SystemControl.bits.Flag_Idle_Mode == 1)
  {
    LED_Display_off();
  }
  else if(Battery_Learning_Start == 1)
  {
    LED_Display_BlinkAmber();
  }
  else
  {
    if(SystemControl.bits.Flag_Online_Mode == 1 && SystemControl.bits.Flag_Failure == 0 && SystemControl.bits.Flag_Not_Reset_Failure == 0)
    {
       if(ORING_STATUS == 1)
       {
         LED_Display_Green();
       }
       else
       {
         LED_Display_BlinkGreen();  
       }
    }

    else if(SystemControl.bits.Flag_Offline_Mode == 1 && SystemControl.bits.Flag_Failure == 0 && SystemControl.bits.Flag_Not_Reset_Failure == 0)
    { 
       if(ORING_STATUS == 1)
       {
         LED_Display_Amber();
       }
       else
       {
         LED_Display_BlinkAmber();
       }
    }
  
  }

}


void LED_Factory_Test(void)
{
  if(SystemControl.bits.Flag_PS_KILL_Debounce == 1 && u8Calibration == 12)
  {
    LED_Status.Test_Flag = 1;            // 10ms Timer flag 

    I2C1_write(Battery_Address,Battery_LED_Status,Battery_LED_Capacity_Test_Low,Battery_LED_Capacity_Test_High);
    asm("NOP");
    asm("NOP");
    
    if(LED_Status.Test_count <= 300)
    {
      LED_Display_Red();
    }
    else if(LED_Status.Test_count > 300 && LED_Status.Test_count <= 600)
    {
      LED_Display_Green();
    }
    else if(LED_Status.Test_count > 600 && LED_Status.Test_count <= 900)
    {
      LED_Display_Amber(); 
    }
    else if(LED_Status.Test_count > 900)
    {
      LED_Display_off();
      u8Calibration = 0;
      LED_Status.Test_count = 0;
      LED_Status.Test_Flag = 0;
    }
    

  }


}






