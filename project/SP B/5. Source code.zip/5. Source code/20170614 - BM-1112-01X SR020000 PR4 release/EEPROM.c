#include <p24FJ64GA006.h>
#include "bms_Pin_Define.h"
#include "GenericTypeDefs.h"
#include "I2C.h"
#include "Battery_status.h"
#include "PMBusData.h"
#include "PMBus_status.h"
#include "Failure.h"
#include "EEPROM.h"
#include <string.h>
#include "RevisionBlock.h"

//u8_t EEPROM_Failure_count = 0;



u16_t EEPROM_demo = 0;
    

EEPROM_Info_T EEPROM_Info;

void EEPROM_Write(void)
{
  I2C1_EEPROM_Write(EEPROM_Address, EEPROM_Flag_Cmd, 0x01, 0x00);
  asm("NOP");
  asm("NOP");
  asm("NOP");
}
void EEPROM_Read(void)
{
  I2C1_EEPROM_Read(EEPROM_Address,EEPROM_Flag_Cmd);
  EEPROM_Info.Flag = (data_high<< 8 ) + data_low;
  asm("NOP");
  asm("NOP");

  I2C1_EEPROM_Read(EEPROM_Address,EEPROM_Failure_Flag_Cmd);
  EEPROM_Info.Failure_Flag = (data_high << 8) + data_low;
  asm("NOP");
  asm("NOP");

  I2C1_EEPROM_Read(EEPROM_Address,EEPROM_Read_Battery_Cmd);
  EEPROM_Info.Read_Battery = (data_high << 8) + data_low;
  asm("NOP");
  asm("NOP");

  I2C1_EEPROM_Read(EEPROM_Address, EEPROM_Ambient_OTP_Cmd);
  EEPROM_Info.Ambient_OTP_Flag = (data_high << 8) + data_low;
  asm("NOP");
  asm("NOP");

  I2C1_EEPROM_Read(EEPROM_Address,EEPROM_Cycle_Cnt_Cmd);
  EEPROM_Info.Cycle_Cnt_Offset = (data_high << 8) + data_low;
  asm("NOP");
  asm("NOP");

  I2C1_EEPROM_Barcode_Block_Read(EEPROM_Address, EEPROM_SerialNumber_Cmd, 15);
  asm("NOP");
  asm("NOP");

//--------------- HW Compatible Code ---------------//
  I2C1_EEPROM_Read(EEPROM_Address, EEPROM_Compatible_Cmd);
  EEPROM_Info.HW_Compatible_Code = (data_high<< 8) + data_low;
  pu8BBUCompatible[8] = data_high;
  pu8BBUCompatible[9] = data_low;
  asm("NOP");
  asm("NOP");        

  EEPROM_Time_Minute_Read();

  if(EEPROM_Info.Flag == 1)
  {
//-------------- Offline Vref Duty ----------//
    I2C1_EEPROM_Read(EEPROM_Address, EEPROM_Offline_Duty_Cmd);
    EEPROM_Info.Offline_Duty = (data_high<< 8 ) + data_low ;
    asm("NOP");
    asm("NOP");
  
    u16VrefOffline = EEPROM_Info.Offline_Duty;

//-------------- Online Vref Duty ------------//

    I2C1_EEPROM_Read(EEPROM_Address, EEPROM_Online_Duty_Cmd);
    EEPROM_Info.Online_Duty = (data_high<< 8) + data_low;
    asm("NOP");
    asm("NOP");

    u16VrefOnline = EEPROM_Info.Online_Duty;

//-------------- Trim Duty -----------------//

    I2C1_EEPROM_Read(EEPROM_Address, EEPROM_Trim_Duty_Cmd);
    EEPROM_Info.Trim_Duty = (data_high<< 8) + data_low;
    asm("NOP");
    asm("NOP");

    u16TrimDuty = EEPROM_Info.Trim_Duty;

//-------------- Voltage ADC Gain ------------//

    I2C1_EEPROM_Read(EEPROM_Address, EEPROM_Voltage_ADC_Cmd);
    EEPROM_Info.Voltage_ADC_Gain = (data_high<< 8) + data_low;
    asm("NOP");
    asm("NOP");
    Voltage_ADC_Gain = EEPROM_Info.Voltage_ADC_Gain;

//-------------- Iout ADC Gain ------------//

    I2C1_EEPROM_Read(EEPROM_Address, EEPROM_IoutADGain_Cmd);
    EEPROM_Info.Iout_AD_Gain = (data_high<< 8) + data_low;
    asm("NOP");
    asm("NOP");
    Iout_ADC_Gain = EEPROM_Info.Iout_AD_Gain;
  
  }

//-------------- last Protection Type -------------// 

  if(EEPROM_Info.Failure_Flag == 1)
  {
    I2C1_EEPROM_Block_Read(EEPROM_Address, EEPROM_Protect_type_A, 4);
    memcpy(&LastProtect_type[0], TempBlockBuff, sizeof(LastProtect_type[0]));
    asm("NOP");
    asm("NOP");
    
    I2C1_EEPROM_Block_Read(EEPROM_Address, EEPROM_Protect_type_B, 4);
    memcpy(&LastProtect_type[1], TempBlockBuff, sizeof(LastProtect_type[1]));
    asm("NOP");
    asm("NOP");

    I2C1_EEPROM_Block_Read(EEPROM_Address, EEPROM_Protect_type_C, 4);
    memcpy(&LastProtect_type[2], TempBlockBuff, sizeof(LastProtect_type[2]));
    asm("NOP");
    asm("NOP");

    I2C1_EEPROM_Block_Read(EEPROM_Address, EEPROM_Protect_type_D, 4);
    memcpy(&LastProtect_type[3], TempBlockBuff, sizeof(LastProtect_type[3]));
    asm("NOP");
    asm("NOP");
   
   } 

 
}

void EEPROM_Control(void)
{
  if(EEPROM_10ms_Write == 1)
  {

    if(u8Calibration == 1)
    {
      EEPROM_Calibration_Write();
      EEPROM_10ms_Write = 0;
    }
    
    if(u8Calibration == 3)
    {
      EEPROM_Battery_Write();
      EEPROM_10ms_Write = 0;
    }

    if(u8Calibration == 4)
    {
      EEPROM_Cycle_Cnt_Write();
      EEPROM_10ms_Write = 0;
    }

    if(u8Calibration == 6)
    {
      EEPROM_SerialNumber_Write();
      EEPROM_10ms_Write = 0;
    }

    if(u8Calibration == 7)
    {
      EEPROM_Failure_Write();
      EEPROM_10ms_Write = 0;

    }

    if(u8Calibration == 8)
    {
      EEPROM_BatteryNot_Write();
      EEPROM_10ms_Write = 0;

    }

    if(u8Calibration == 10)
    {
      EEPROM_Compatible_Write();
      EEPROM_10ms_Write = 0;
    }

  }

  

}

void EEPROM_Failure_Write(void)
{
   Initial_Block_Buff();

   memcpy(TempBlockBuff, &LastProtect_type, sizeof(TempBlockBuff));
   I2C1_EEPROM_Block_Write(EEPROM_Address,EEPROM_Protect_type_A, 16);
   asm("NOP");
   asm("NOP");
   asm("NOP");

      
   I2C1_EEPROM_Write(EEPROM_Address, EEPROM_Failure_Flag_Cmd, 0x01, 0x00);
   asm("NOP");
   asm("NOP");
   asm("NOP");
    
}

void EEPROM_Calibration_Write(void)
{
    if(EEPROM_count != 7)
    {
      EEPROM_count ++;
    } 
  
    switch(EEPROM_count)
    {
     case 1:
       Initial_Block_Buff();
       memcpy(TempBlockBuff, &u16VrefOffline, sizeof(u16VrefOffline));
       I2C1_EEPROM_Block_Write(EEPROM_Address, EEPROM_Offline_Duty_Cmd, 2);
       asm("NOP");
       asm("NOP");
       asm("NOP");
     
        break;
    

     case 2:
       Initial_Block_Buff();
       memcpy(TempBlockBuff, &u16VrefOnline, sizeof(u16VrefOnline));
       I2C1_EEPROM_Block_Write(EEPROM_Address, EEPROM_Online_Duty_Cmd, 2);
       asm("NOP");
       asm("NOP");
       asm("NOP");
     
        break;

     case 3:
       Initial_Block_Buff();
       memcpy(TempBlockBuff, &u16TrimDuty, sizeof(u16TrimDuty));
       I2C1_EEPROM_Block_Write(EEPROM_Address, EEPROM_Trim_Duty_Cmd, 2);
       asm("NOP");
       asm("NOP");
       asm("NOP");
  
        break;

     case 4:
       Initial_Block_Buff();
       memcpy(TempBlockBuff, &Voltage_ADC_Gain, sizeof(u16TrimDuty));
       I2C1_EEPROM_Block_Write(EEPROM_Address, EEPROM_Voltage_ADC_Cmd, 2);
       asm("NOP");
       asm("NOP");
       asm("NOP");
     
     case 5:
       EEPROM_Write();

     case 6:
       Initial_Block_Buff();
       memcpy(TempBlockBuff, &Iout_ADC_Gain, sizeof(Iout_ADC_Gain));
       I2C1_EEPROM_Block_Write(EEPROM_Address, EEPROM_IoutADGain_Cmd, 2);
       asm("NOP");
       asm("NOP");
       asm("NOP");

     default:

        break; 
     
    }

   
}

void EEPROM_Battery_Write(void)
{
   I2C1_EEPROM_Write(EEPROM_Address, EEPROM_Read_Battery_Cmd, 0x01, 0x00);
   asm("NOP");
   asm("NOP");
   asm("NOP");

}


void EEPROM_Cycle_Cnt_Write(void)
{
   EEPROM_Info.Cycle_Cnt_Offset_L = Cell_Info.CycleCount;
   EEPROM_Info.Cycle_Cnt_Offset_H = (Cell_Info.CycleCount >> 8);
   I2C1_EEPROM_Write(EEPROM_Address, EEPROM_Cycle_Cnt_Cmd, EEPROM_Info.Cycle_Cnt_Offset_L, EEPROM_Info.Cycle_Cnt_Offset_H);
   asm("NOP");
   asm("NOP");
   asm("NOP");

}


void EEPROM_SerialNumber_Write(void)
{
  I2C1_EEPROM_Barcode_Block_Write(EEPROM_Address, EEPROM_SerialNumber_Cmd, 15);
  asm("NOP");
  asm("NOP");
  asm("NOP");
}

void EEPROM_BatteryNot_Write(void)
{
  I2C1_EEPROM_Write(EEPROM_Address, EEPROM_Read_Battery_Cmd, 0x00, 0x00);
  asm("NOP");
  asm("NOP");
  asm("NOP");

}

void EEPROM_Time_Minute_Write(void)
{
    if(System_Run.Flag_1minute == 1)
    {
       System_Run.Time_Total_Minute = System_Run.Time_Minute + EEPROM_Info.Time_Minute;
       Initial_Block_Buff();
       memcpy(TempBlockBuff, &System_Run.Time_Total_Minute, sizeof(System_Run.Time_Total_Minute));

       I2C1_EEPROM_Block_Write(EEPROM_Address, EEPROM_Time_Minute_Cmd, 4); 
    
       System_Run.Flag_1minute = 0;    

       u32BBURunTime = System_Run.Time_Total_Minute;
    }
    
}

void EEPROM_Time_Minute_Read(void)
{
   I2C1_EEPROM_Block_Read(EEPROM_Address, EEPROM_Time_Minute_Cmd, 4);
   memcpy(&EEPROM_Info.Time_Minute, TempBlockBuff, sizeof(EEPROM_Info.Time_Minute));
   
   if(EEPROM_Info.Time_Minute == 0xFFFFFFFF)
   {
      EEPROM_Info.Time_Minute = 0;
      u32BBURunTime = 0;
   }
   else
   {
       u32BBURunTime = EEPROM_Info.Time_Minute;
   }

}

//void EEPROM_Time_Minute

void EEPROM_Compatible_Write(void)
{
  I2C1_EEPROM_Write(EEPROM_Address, EEPROM_Compatible_Cmd, Stage_HW_CC_Low, Stage_HW_CC_High);
  asm("NOP");
  asm("NOP");
  asm("NOP");

}



