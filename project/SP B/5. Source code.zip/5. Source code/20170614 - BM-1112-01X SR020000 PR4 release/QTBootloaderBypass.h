#include "QTBootloader.h"
#include "I2C.h"

#define MSTR_BYPASS_TX_BUFF 				40
#define MSTR_BYPASS_RX_BUFF					40


typedef struct
{
  u8_t pu8BypassTxBuff[MSTR_BYPASS_TX_BUFF];
  u8_t pu8BypassRxBuff[MSTR_BYPASS_RX_BUFF];
  u8_t u8BypassCmdCode;
  u8_t u8BypassFlag;

}ByPassBootloader_t;

typedef struct
{
	u8_t pu8Key[4];
	u8_t u8Command;
	u8_t u8Status;
	u8_t pu8MemoryBlock[32];
	u8_t pu8ProductKey[16];
	u16_t u16ImageChecksum;
}sQTBtldrBypassCmdStr_t;

extern sQTBtldrBypassCmdStr_t sQTBtldrBypassCmd;
