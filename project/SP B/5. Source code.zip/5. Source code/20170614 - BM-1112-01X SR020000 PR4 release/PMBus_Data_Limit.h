#ifndef __PMBus_Data_Limit_H__
#define __PMBus_Data_Limit_H__

#include <p24FJ64GA006.h>
#include "bms_Pin_Define.h"	
#include "I2C.h"
#include "GenericTypeDefs.h"
#include "Battery_status.h"	
#include "Charge_control.h"
#include "Discharge_control.h"
#include "Failure.h"
#include "main.h"
#include <string.h>
#include "LED_Display.h"
#include "PMBusAPP.h"
#include "PMBusData.h"
#include "SI2CDrv.h"
#include "PMBus_data_transfor.h"
#include "BBU_content.h"	
#include "PMBus_status.h"	
#include "EEPROM.h"

void PMBus_Data_Range(void);


#endif

