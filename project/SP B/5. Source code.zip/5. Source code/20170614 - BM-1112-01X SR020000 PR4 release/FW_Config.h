#ifndef __FW_CONFIG_H__
#define __FW_CONFIG_H__

//----------------- Charger set ----------------------------
#define Battery_FullyCharge_Capacity                        6718    // mAH     �q���R���e�q
#define Battery_FullyCharge_Voltage                         53000   // mV      �q���R���q��
#define Charging_Current_2A                                 2000    // mA      �q���R�q�q�y�]�w 
#define Discharging_Cell_Cutoff_Voltage                     37050   // mV      �q����qCutoff�q��
#define Battery_BackCharge_Capacity                         6382
#define Battery_BackCharge_Voltage                          52000 
#define Charging_Regulation_Low                             12070
#define Charging_Regulation_High                            12795
#define Charging_Regulation_Hys_Low                         12000
#define Charging_Regulation_Hys_High                        12865
#define Battery_FullyCharge_RSOC                            100      // %
#define Battery_BackCharge_RSOC                             95       // %
#define Battery_SOH_Warning_Threshold                       60       // %
#define Discharge_Remaining_Time_warning_Threshold          180      // Sec  
#define Battery_RSOC_Warning_Threshold                      20       // %
#define Battery_RSOC_Recover_Threshold                      30

//----------------- Discharger set -------------------------
#define Discharger_Run_Time_Threshold                       180     // s       BBU��q�ɶ���3���� 180��
#define Discharger_Run_Time_Warning                         150     // s       ��150����ĵ�i�t��


//----------------- Vout Regulation Threshold ---------------------
#define Vout_Regulation_Threshold_H	13125
#define Vout_Regulation_Threshold_L	11450
#define Vout_Low_Protection         11000


//--------- Charging ,Discharging ,Ambient over Temperature protection ----------
#define Charging_BOOST_OT_Warning_Threshold         90      // degreeC      47
#define Charging_BOOST_OT_Protection_Threshold      100     // degreeC      50
#define Charging_BOOST_OT_Recover_Threshold         80      // degreeC      45
 
#define Discharging_BUCK1_OT_Warning_Threshold      115      // degreeC    120
#define Discharging_BUCK1_OT_Protection_Threshold   130      // degreeC    130
#define Discharging_BUCK1_OT_Recover_Threshold      80      // degreeC    115

#define Discharging_BUCK2_OT_Warning_Threshold      450     // degreeC
#define Discharging_BUCK2_OT_Protection_Threshold   500     // degreeC
#define Discharging_BUCK2_OT_Recover_Threshold              // degreeC

#define Discharging_BUCK3_OT_Warning_Threshold      450     // degreeC
#define Discharging_BUCK3_OT_Protection_Threshold   500     // degreeC
#define Discharging_BUCK3_OT_Recover_Threshold              // degreeC

#define Ambient_OT_Warning_Threshold                50     // degreeC
#define Ambient_OT_Protection_Threshold             55     // degreeC   45
#define Ambient_OT_Recover_Threshold                45     // degreeC



//--------------------- Input Protect --------------------------

#define Input_UV_Recover_Threshold					11800	// mV
#define Input_UV_Warning_Threshold					11600	// mV
#define	Input_UV_Protection_Threshold				11400	// mV     10500   DC source cant 
				
#define Input_OV_Protection_Threshold				13600	// mV
#define Input_OV_Warning_Threshold                  13200   // mV
#define Input_OV_Recover_Threshold					12800	// mV
#define Input_OC_Warning_Threshold					9500	// mA
#define Input_OC_Recover_Threshold					9000	// mA
#define Input_OC_Protection_Threshold               10000   // mA
#define Input_OP_Warning_Threshold					120000	// mW
#define Input_OP_Recover_Threshold					110000	// mW	// 16.4*4

//--------------------- Output Protect --------------------------

#define Output_OV_Protection_First_Threshold		13600	// mV
#define Output_OV_Protection_Second_Threshold       14000   // mV
#define Output_OV_Warning_Threshold                 13200   // mV
#define Output_OV_Recover_Threshold                 12600   // mV

#define Output_UV_Protection_Threshold				11400	// mV            10400
#define Output_UV_Warning_Threshold                 11600   // mV
#define Output_UV_Recover_Threshold                 12000   // mV

#define Output_OC_Warning_Threshold				    95000	// mA
#define Output_OC_Protection_Threshold				110000	// mA
#define Output_OC_Recover_Threshold                 92000   // mA

#define Output_OP_Warning_Threshold				    1200000	// mW
#define Output_OP_Protection_Threshold				1300000	// mW
#define Output_OP_Recover_Threshold                 1150000 // mW



//------------- Discharging Battery Protect ----------------

#define Discharging_Cell_OV_Recover_Threshold               // mV
#define Discharging_Cell_OV_Warning_Threshold               // mV
#define Discharging_Cell_OV_Protection_Threshold    54500   // mV

#define Discharging_Cell_UV_Recover_Threshold               // mV
#define Discharging_Cell_UV_Warning_Threshold               // mV
#define Discharging_Cell_UV_Protection_Threshold    30000      // mV

#define Discharging_Cell_OC_Recover_Threshold               // mA
#define Discharging_Cell_OC_Warning_Threshold               // mA  
#define Discharging_Cell_OC_Protection_Threshold    35000   // mA

#define Discharging_Cell_OT_Warning_Threshold		65		// degreeC
#define Discharging_Cell_OT_Protection_Threshold	70		// degreeC
#define Discharging_Cell_OT_Recover_Threshold		60		// degreeC


//--------- Charging Battery Protection ----------- 
#define Charging_Cell_OT_Warning_Threshold          45      // degreeC
#define Charging_Cell_OT_Protection_Threshold		50		// degreeC
#define Charging_Cell_OT_Recover_Threshold			48		// degreeC

#define Charging_Cell_OV_Warning_Threshold          53600
#define Charging_Cell_OV_Protection_Threshold       53800
#define Charging_Cell_OV_Recover_Threshold

//--------- Cell Protection --------------------
#define Cell_low_Capacity_Warning_Threshold         1000     // mAH
#define Cell_low_Capacity_Recover_Threshold         1200     // mAH
#define Cell_low_Capacity_Protection_Threshold       0      // mAH


//***********************************************************//
//*            Expect warning and protect point              //
//***********************************************************//

//---------------------  Temperature  -----------------------//

extern u16_t Expect_Charging_BOOST_OT_Warning;
extern u16_t Expect_Charging_BOOST_OT_Protection;
extern u16_t Expect_Charging_BOOST_OT_Recover;

extern u16_t Expect_Discharging_BUCK1_OT_Warning;
extern u16_t Expect_Discharging_BUCK1_OT_Protection;
extern u16_t Expect_Discharging_BUCK1_OT_Recover;

extern u16_t Expect_Ambient_OT_Warning;
extern u16_t Expect_Ambient_OT_Protection;
extern u16_t Expect_Ambient_OT_Recover;

//-------------------- Input Protection --------------------//

extern u16_t Expect_Input_UV_Warning;
extern u16_t Expect_Input_UV_Protection;
extern u16_t Expect_Input_UV_Recover;

extern u16_t Expect_Input_OV_Warning;
extern u16_t Expect_Input_OV_Protection;
extern u16_t Expect_Input_OV_Recover;

extern u16_t Expect_Input_OC_Warning;
extern u16_t Expect_Input_OC_Protection;
extern u16_t Expect_Input_OC_Recover;

extern u32_t Expect_Input_OP_Warning;
extern u32_t Expect_Input_OP_Protection;
extern u32_t Expect_Input_OP_Recover;

//--------------------- output Protection ------------------//

extern u16_t Expect_Output_OV_Warning;
extern u16_t Expect_Output_OV_Protection;
extern u16_t Expect_Output_OV_Recover;

extern u16_t Expect_Output_UV_Warning;
extern u16_t Expect_Output_UV_Protection;
extern u16_t Expect_Output_UV_Recover;

extern s32_t Expect_Output_OC_Warning;
extern s32_t Expect_Output_OC_Protection;
extern s32_t Expect_Output_OC_Recover;

extern s32_t Expect_Output_OP_Warning;
extern s32_t Expect_Output_OP_Protection;
extern s32_t Expect_Output_OP_Recover;

//--------------------- Cell Discharger -------------------//

extern u16_t Expect_Discharger_Cell_OV_Warning;
extern u16_t Expect_Discharger_Cell_OV_Protection;
extern u16_t Expect_Discharger_Cell_OV_Recover;

extern u16_t Expect_Discharger_Cell_UV_Warning;
extern u16_t Expect_Discharger_Cell_UV_Protection;
extern u16_t Expect_Discharger_Cell_UV_Recover;

extern u32_t Expect_Discharger_Cell_OC_Warning;
extern u32_t Expect_Discharger_Cell_OC_Protection;
extern u32_t Expect_Discharger_Cell_OC_Recover;

extern u16_t Expect_Discharger_Cell_OT_Warning;
extern u16_t Expect_Discharger_Cell_OT_Protection;
extern u16_t Expect_Discharger_Cell_OT_Recover;

//---------------------- Cell Charger ----------------------//

extern u16_t Expect_Charger_Cell_OT_Warning;
extern u16_t Expect_Charger_Cell_OT_Protection;
extern u16_t Expect_Charger_Cell_OT_Recover;



#endif
