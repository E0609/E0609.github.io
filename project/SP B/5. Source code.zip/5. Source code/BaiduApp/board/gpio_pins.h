/*
 * Copyright (c) 2013, Freescale Semiconductor, Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of Freescale Semiconductor, Inc. nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#ifndef __FSL_GPIO_PINS_H__
#define __FSL_GPIO_PINS_H__

#include "fsl_gpio_driver.h"

#define  BSC_EEPROM_HYPO (0)
/*! @file */
/*!*/
/*! This file contains gpio pin definitions used by gpio peripheral driver.*/
/*! The enums in _gpio_pins map to the real gpio pin numbers defined in*/
/*! gpioPinLookupTable. And this might be different in different board.*/

/*******************************************************************************
 * Definitions
 ******************************************************************************/

/*! @brief gpio pin names.*/
/*!*/ 
/*! This should be defined according to board setting.*/
enum _gpio_pins
{
	kGpioEeprom_Scl		= GPIO_MAKE_PIN(HW_GPIOB, 16),   /* eeprom scl */
	kGpioEeprom_Sda		= GPIO_MAKE_PIN(HW_GPIOB, 17),   /* eeprom sda */

	kGpioTestPTC0		= GPIO_MAKE_PIN(HW_GPIOC, 0),   /* reserved */
    kIntGpioVinOk       	= GPIO_MAKE_PIN(HW_GPIOC, 1),   /* vin ok */
    kIntGpioPscBBS_AcGood	= GPIO_MAKE_PIN(HW_GPIOC, 2),   /* psc bbs ac good */
    kGpioBBS_A2			= GPIO_MAKE_PIN(HW_GPIOC, 5),   /* bbs a2 */
    kGpioBBS_A3			= GPIO_MAKE_PIN(HW_GPIOC, 6),   /* bbs a3 */
    kGpioBBS_A4			= GPIO_MAKE_PIN(HW_GPIOC, 7),   /* bbs a4 */
    kGpioBSC_Present	= GPIO_MAKE_PIN(HW_GPIOC, 8),   /* bsc present */
    kGpioKey_SW1	    = GPIO_MAKE_PIN(HW_GPIOC, 9),   /* batt selftest button */
    kGpioLed_Green       = GPIO_MAKE_PIN(HW_GPIOC, 10U),   /* led green */
    kGpioTestPTC11       = GPIO_MAKE_PIN(HW_GPIOC, 11U),   /* reserved */

    kGpioTestPTD0    	= GPIO_MAKE_PIN(HW_GPIOD, 0),   /* reserved */
    kGpioBBS_Present	= GPIO_MAKE_PIN(HW_GPIOD, 1),   /* bbs present */
    kGpioBBS_AcGood 	= GPIO_MAKE_PIN(HW_GPIOD, 2),   /* bbs ac good */
    kGpioBBS_PsKill 	= GPIO_MAKE_PIN(HW_GPIOD, 3),   /* bbs ps kill */
    kGpioBBS_On			= GPIO_MAKE_PIN(HW_GPIOD, 4),   /* bbs on */
    kGpioMTestPTD5		= GPIO_MAKE_PIN(HW_GPIOD, 5),   /* test1 */
    kGpioMTestPTD6      = GPIO_MAKE_PIN(HW_GPIOD, 6),   /* reserved */
    kGpioMTestPTD7      = GPIO_MAKE_PIN(HW_GPIOD, 7),   /* reserved */

    kGpioBBS_SDA      	= GPIO_MAKE_PIN(HW_GPIOE, 0),   /* bbs sda sensing */
    kGpioBBS_SCL      	= GPIO_MAKE_PIN(HW_GPIOE, 1),   /* bbs scl sensing */
    kGpioVout33      	= GPIO_MAKE_PIN(HW_GPIOE, 20),   /* vbus sensing */
};

extern gpio_input_pin_user_config_t switchPins[];
extern gpio_input_pin_user_config_t accelIntPins[];
extern gpio_input_pin_user_config_t i2cAddrPins[];
extern gpio_output_pin_user_config_t ledPins[];
extern gpio_output_pin_user_config_t gpioUartDemoTxPin[];
extern gpio_input_pin_user_config_t  gpioUartDemoRxPin[];

extern gpio_input_pin_user_config_t bscIntPins[];
extern gpio_output_pin_user_config_t bscOutPins[];
extern gpio_input_pin_user_config_t bbuIntPins[];
extern gpio_output_pin_user_config_t bbuOutPins[];

extern gpio_output_pin_user_config_t i2cgpioSclOutPins[];
extern gpio_input_pin_user_config_t i2cgpioSclIntPins[];
extern gpio_output_pin_user_config_t i2cgpioSdaOutPins[];
extern gpio_input_pin_user_config_t i2cgpioSdaIntPins[];

extern gpio_input_pin_user_config_t bscConfirmingModeIntPins[];
extern gpio_output_pin_user_config_t bscConfirmingModeOutPins[];

extern gpio_input_pin_user_config_t bscInStandbyIntPins[];
extern gpio_output_pin_user_config_t bscInStandbyOutPins[];

extern gpio_input_pin_user_config_t bscInReOperationIntPins[];
extern gpio_output_pin_user_config_t bscAcGoodHighOutPins[];
extern gpio_output_pin_user_config_t bscAcGoodLowOutPins[];

#endif /* __FSL_GPIO_PINS_H__ */
