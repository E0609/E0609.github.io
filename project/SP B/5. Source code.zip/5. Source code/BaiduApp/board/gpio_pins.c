/*
 * Copyright (c) 2013-2014, Freescale Semiconductor, Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of Freescale Semiconductor, Inc. nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <stdint.h>
#include <stdlib.h>
#include "gpio_pins.h"
#include "device/fsl_device_registers.h"


/*******************************************************************************
 * Definitions
 ******************************************************************************/

/* Declare BSC inputPins */
gpio_input_pin_user_config_t bscIntPins[] = {
	{
		.pinName = kIntGpioVinOk,	//PTC1
		.config.isPullEnable = true,
		.config.pullSelect = kPortPullUp,
		.config.isPassiveFilterEnabled = false,
		.config.interrupt = kPortIntDisabled,
	},
	{
		.pinName = kIntGpioPscBBS_AcGood,	//PTC2
		.config.isPullEnable = true,
		.config.pullSelect = kPortPullUp,
		.config.isPassiveFilterEnabled = false,
		.config.interrupt = kPortIntDisabled,
		//.config.interrupt = kPortIntRisingEdge,
	},

	{
        .pinName = kGpioBBS_A2,	//PTC5
        .config.isPullEnable = false,
        .config.pullSelect = kPortPullUp,
        .config.isPassiveFilterEnabled = false,
        .config.interrupt = kPortIntDisabled,
    },
	{
        .pinName = kGpioBBS_A3,	//PTC6
        .config.isPullEnable = false,
        .config.pullSelect = kPortPullUp,
        .config.isPassiveFilterEnabled = false,
        .config.interrupt = kPortIntDisabled,
    },
	{
        .pinName = kGpioBBS_A4,	//PTC7
        .config.isPullEnable = false,
        .config.pullSelect = kPortPullUp,
        .config.isPassiveFilterEnabled = false,
        .config.interrupt = kPortIntDisabled,
    },
	{
        .pinName = kGpioBSC_Present,	//PTC8
        .config.isPullEnable = false,
        .config.pullSelect = kPortPullUp,
        .config.isPassiveFilterEnabled = false,
        .config.interrupt = kPortIntDisabled,
    },
	{
        .pinName = kGpioKey_SW1,	//PTC9
        .config.isPullEnable = false,
        .config.pullSelect = kPortPullUp,
        .config.isPassiveFilterEnabled = false,
        .config.interrupt = kPortIntDisabled,
    },

	{
        .pinName = kGpioBBS_Present,	//PTD1
        .config.isPullEnable = false,
        .config.pullSelect = kPortPullUp,
        .config.isPassiveFilterEnabled = false,
        .config.interrupt = kPortIntDisabled,
    },
	{
        .pinName = kGpioBBS_AcGood,	//PTD2
        .config.isPullEnable = false,
        .config.pullSelect = kPortPullUp,
        .config.isPassiveFilterEnabled = false,
        .config.interrupt = kPortIntDisabled,
    },

    {
        .pinName = kGpioBBS_SDA,	//PTE0
        .config.isPullEnable = false,
        .config.pullSelect = kPortPullUp,
        .config.isPassiveFilterEnabled = false,
        .config.interrupt = kPortIntDisabled,
    },
    {
        .pinName = kGpioBBS_SCL,	//PTE1
        .config.isPullEnable = false,
        .config.pullSelect = kPortPullUp,
        .config.isPassiveFilterEnabled = false,
        .config.interrupt = kPortIntDisabled,
    },

    {
        .pinName = kGpioVout33,	//PTE20
        .config.isPullEnable = false,
        .config.pullSelect = kPortPullUp,
        .config.isPassiveFilterEnabled = false,
        .config.interrupt = kPortIntDisabled,
    },
    {
        .pinName = GPIO_PINS_OUT_OF_RANGE,
    }
};

/* Declare BSC outputPins */
gpio_output_pin_user_config_t bscOutPins[] = {
	{
		.pinName = kGpioTestPTC0,	//PTC0
		.config.outputLogic = 1,
		.config.slewRate = kPortSlowSlewRate,
		.config.driveStrength = kPortLowDriveStrength,
	},
	{
		.pinName = kGpioLed_Green,	//PTC10
		.config.outputLogic = 0,
		.config.slewRate = kPortSlowSlewRate,
		.config.driveStrength = kPortLowDriveStrength,
	},
	{
		.pinName = kGpioTestPTC11,	//PTC11
		.config.outputLogic = 1,
		.config.slewRate = kPortSlowSlewRate,
		.config.driveStrength = kPortLowDriveStrength,
	},
	{
		.pinName = kGpioTestPTD0,	//PTD0
		.config.outputLogic = 1,
		.config.slewRate = kPortSlowSlewRate,
		.config.driveStrength = kPortLowDriveStrength,
	},

    {
        .pinName = kGpioBBS_PsKill,	//PTD3
        .config.outputLogic = 0,
        .config.slewRate = kPortSlowSlewRate,
        .config.driveStrength = kPortLowDriveStrength,
    },
    {
        .pinName = kGpioBBS_On,	//PTD4
        .config.outputLogic = 1,
        .config.slewRate = kPortSlowSlewRate,
        .config.driveStrength = kPortLowDriveStrength,
    },
    {
        .pinName = kGpioMTestPTD5,	//PTD5
        .config.outputLogic = 1,
        .config.slewRate = kPortSlowSlewRate,
        .config.driveStrength = kPortLowDriveStrength,
    },
    {
        .pinName = kGpioMTestPTD6,	//PTD6
        .config.outputLogic = 1,
        .config.slewRate = kPortSlowSlewRate,
        .config.driveStrength = kPortLowDriveStrength,
    },
    {
        .pinName = kGpioMTestPTD7,	//PTD7
        .config.outputLogic = 1,
        .config.slewRate = kPortSlowSlewRate,
        .config.driveStrength = kPortLowDriveStrength,
    },
    {
        .pinName = GPIO_PINS_OUT_OF_RANGE,
    }
};

/* Declare BBU inputPins */
gpio_input_pin_user_config_t bbuIntPins[] = {
	{
		.pinName = kIntGpioVinOk,	//PTC1
		.config.isPullEnable = true,
		.config.pullSelect = kPortPullUp,
		.config.isPassiveFilterEnabled = false,
		.config.interrupt = kPortIntEitherEdge,
	},
	{
		.pinName = kIntGpioPscBBS_AcGood,	//PTC2
		.config.isPullEnable = true,
		.config.pullSelect = kPortPullUp,
		.config.isPassiveFilterEnabled = false,
		.config.interrupt = kPortIntDisabled,
		//.config.interrupt = kPortIntRisingEdge,
	},
	{
        .pinName = kGpioBBS_A2,	//PTC5
        .config.isPullEnable = false,
        .config.pullSelect = kPortPullUp,
        .config.isPassiveFilterEnabled = false,
        .config.interrupt = kPortIntDisabled,
    },
	{
        .pinName = kGpioBBS_A3,	//PTC6
        .config.isPullEnable = false,
        .config.pullSelect = kPortPullUp,
        .config.isPassiveFilterEnabled = false,
        .config.interrupt = kPortIntDisabled,
    },
	{
        .pinName = kGpioBBS_A4,	//PTC7
        .config.isPullEnable = false,
        .config.pullSelect = kPortPullUp,
        .config.isPassiveFilterEnabled = false,
        .config.interrupt = kPortIntDisabled,
    },
	{
        .pinName = kGpioBSC_Present,	//PTC8
        .config.isPullEnable = false,
        .config.pullSelect = kPortPullUp,
        .config.isPassiveFilterEnabled = false,
        .config.interrupt = kPortIntDisabled,
    },
	{
        .pinName = kGpioKey_SW1,	//PTC9
        .config.isPullEnable = false,
        .config.pullSelect = kPortPullUp,
        .config.isPassiveFilterEnabled = false,
        .config.interrupt = kPortIntDisabled,
    },

	{
        .pinName = kGpioBBS_Present,	//PTD1
        .config.isPullEnable = false,
        .config.pullSelect = kPortPullUp,
        .config.isPassiveFilterEnabled = false,
        .config.interrupt = kPortIntDisabled,
    },

    {
        .pinName = kGpioVout33,	//PTE20
        .config.isPullEnable = false,
        .config.pullSelect = kPortPullUp,
        .config.isPassiveFilterEnabled = false,
        .config.interrupt = kPortIntDisabled,
    },

    {
        .pinName = GPIO_PINS_OUT_OF_RANGE,
    }
};

/* Declare BBU outputPins */
gpio_output_pin_user_config_t bbuOutPins[] = {
	{
		.pinName = kGpioTestPTC0,	//PTC0
		.config.outputLogic = 1,
		.config.slewRate = kPortSlowSlewRate,
		.config.driveStrength = kPortLowDriveStrength,
	},
	{
		.pinName = kGpioLed_Green,	//PTC10
		.config.outputLogic = 1,
		.config.slewRate = kPortSlowSlewRate,
		.config.driveStrength = kPortLowDriveStrength,
	},
	{
		.pinName = kGpioTestPTC11,	//PTC11
		.config.outputLogic = 1,
		.config.slewRate = kPortSlowSlewRate,
		.config.driveStrength = kPortLowDriveStrength,
	},
	{
		.pinName = kGpioTestPTD0,	//PTD0
		.config.outputLogic = 1,
		.config.slewRate = kPortSlowSlewRate,
		.config.driveStrength = kPortLowDriveStrength,
	},
    {
        .pinName = kGpioBBS_AcGood,	//PTD2
        .config.outputLogic = 1,
        .config.slewRate = kPortSlowSlewRate,
        .config.driveStrength = kPortLowDriveStrength,
    },
    {
        .pinName = kGpioBBS_PsKill,	//PTD3
        .config.outputLogic = 0,
        .config.slewRate = kPortSlowSlewRate,
        .config.driveStrength = kPortLowDriveStrength,
    },
    {
        .pinName = kGpioBBS_On,	//PTD4
        .config.outputLogic = 1,
        .config.slewRate = kPortSlowSlewRate,
        .config.driveStrength = kPortLowDriveStrength,
    },

    /*{
        .pinName = kGpioMTestPTD5,	//PTD5
        .config.outputLogic = 1,
        .config.slewRate = kPortSlowSlewRate,
        .config.driveStrength = kPortLowDriveStrength,
    },
    {
        .pinName = kGpioMTestPTD6,	//PTD6
        .config.outputLogic = 1,
        .config.slewRate = kPortSlowSlewRate,
        .config.driveStrength = kPortLowDriveStrength,
    },
    {
        .pinName = kGpioMTestPTD7,	//PTD7
        .config.outputLogic = 1,
        .config.slewRate = kPortSlowSlewRate,
        .config.driveStrength = kPortLowDriveStrength,
    },*/
    {
        .pinName = GPIO_PINS_OUT_OF_RANGE,
    }
};

/* Declare BSC gpioI2cScl outputPins */
gpio_output_pin_user_config_t i2cgpioSclOutPins[] = {
    {
        .pinName = kGpioEeprom_Scl,	//PTB16, scl
        .config.outputLogic = 0,
        .config.slewRate = kPortSlowSlewRate,
        .config.driveStrength = kPortLowDriveStrength,
    },
    {
        .pinName = GPIO_PINS_OUT_OF_RANGE,
    }
};
/* Declare BSC gpioI2cScl inputPins */
gpio_input_pin_user_config_t i2cgpioSclIntPins[] = {
	{
		.pinName = kGpioEeprom_Scl,	//PTB16, scl
		.config.isPullEnable = false,
		.config.pullSelect = kPortPullUp,
		.config.isPassiveFilterEnabled = false,
		.config.interrupt = kPortIntDisabled,
	},
	{
		.pinName = GPIO_PINS_OUT_OF_RANGE,
	}
};
/* Declare BSC gpioI2cSda outputPins */
gpio_output_pin_user_config_t i2cgpioSdaOutPins[] = {
    {
        .pinName = kGpioEeprom_Sda,	//PTB17, sda
        .config.outputLogic = 0,
        .config.slewRate = kPortSlowSlewRate,
        .config.driveStrength = kPortLowDriveStrength,
    },
    {
        .pinName = GPIO_PINS_OUT_OF_RANGE,
    }
};
/* Declare BSC gpioI2cSda inputPins */
gpio_input_pin_user_config_t i2cgpioSdaIntPins[] = {
	{
		.pinName = kGpioEeprom_Sda,	//PTB17, sda
		.config.isPullEnable = false,
		.config.pullSelect = kPortPullUp,
		.config.isPassiveFilterEnabled = false,
		.config.interrupt = kPortIntDisabled,
	},
	{
		.pinName = GPIO_PINS_OUT_OF_RANGE,
	}
};

/* Declare BSC bscConfirmingModeIntPins inputPins */
gpio_input_pin_user_config_t bscConfirmingModeIntPins[] = {
    {
        .pinName = kGpioBBS_SDA,	//PTE0
        .config.isPullEnable = false,
        .config.pullSelect = kPortPullUp,
        .config.isPassiveFilterEnabled = false,
        .config.interrupt = kPortIntDisabled,
    },
    {
        .pinName = kGpioBBS_SCL,	//PTE1
        .config.isPullEnable = false,
        .config.pullSelect = kPortPullUp,
        .config.isPassiveFilterEnabled = false,
        .config.interrupt = kPortIntDisabled,
    },

    {
        .pinName = GPIO_PINS_OUT_OF_RANGE,
    }
};

/* Declare BSC bscConfirmingModeOutPins outputPins */
gpio_output_pin_user_config_t bscConfirmingModeOutPins[] = {
    {
        .pinName = GPIO_PINS_OUT_OF_RANGE,
    }
};

/* Declare BSC bscInStandbyIntPins inputPins */
gpio_input_pin_user_config_t bscInStandbyIntPins[] = {
	{
		.pinName = kGpioBBS_AcGood,	//PTD2
		.config.isPullEnable = false,
		.config.pullSelect = kPortPullUp,
		.config.isPassiveFilterEnabled = false,
		.config.interrupt = kPortIntDisabled,
	},
    {
        .pinName = kGpioBBS_SDA,	//PTE0
        .config.isPullEnable = false,
        .config.pullSelect = kPortPullUp,
        .config.isPassiveFilterEnabled = false,
        .config.interrupt = kPortIntDisabled,
    },
    {
        .pinName = kGpioBBS_SCL,	//PTE1
        .config.isPullEnable = false,
        .config.pullSelect = kPortPullUp,
        .config.isPassiveFilterEnabled = false,
        .config.interrupt = kPortIntDisabled,
    },

    {
        .pinName = GPIO_PINS_OUT_OF_RANGE,
    }
};

/* Declare BSC bscInStandbyOutPins outputPins */
gpio_output_pin_user_config_t bscInStandbyOutPins[] = {
    {
        .pinName = GPIO_PINS_OUT_OF_RANGE,
    }
};

/* Declare BSC bscInStandbyIntPins inputPins */
gpio_input_pin_user_config_t bscInReOperationIntPins[] = {


    {
        .pinName = GPIO_PINS_OUT_OF_RANGE,
    }
};

/* Declare BSC bscInStandbyOutPins outputPins */
gpio_output_pin_user_config_t bscAcGoodHighOutPins[] = {
	{
		.pinName = kGpioBBS_AcGood,	//PTD2
		.config.outputLogic = 1,
		.config.slewRate = kPortSlowSlewRate,
		.config.driveStrength = kPortLowDriveStrength,
	},
	{
        .pinName = GPIO_PINS_OUT_OF_RANGE,
    }
};
/* Declare BSC bscInStandbyOutPins outputPins */
gpio_output_pin_user_config_t bscAcGoodLowOutPins[] = {
	{
		.pinName = kGpioBBS_AcGood,	//PTD2
		.config.outputLogic = 0,
		.config.slewRate = kPortSlowSlewRate,
		.config.driveStrength = kPortLowDriveStrength,
	},
	{
        .pinName = GPIO_PINS_OUT_OF_RANGE,
    }
};
