/****************************************************************************
*	file	ProgramBlock.c
*	brief	pib table
*
*	author allen.lee
* 	version 1.0
*		-	2015/10/01: initial version by allen lee
*
****************************************************************************/
#include "fsl_device_registers.h"
#include "ProgramBlock.h"
#include "bsc_btloader.h"
#include "macro_define.h"

/****************************************************************************
*   Declared Structures & Variables
****************************************************************************/
#if (LITEON_BT)
__attribute__((section(".commram_data"))) sCommonRam_t	tsCommonRam;
#endif /* LITEON_BT */

sProgamInfoBlock_t   tsProgamInfoBlock;

// must be set at 0x00014100 - 0x0001410F (16 bytes)
__attribute__((section(".my_apppwd")))
#if (BAIDU_BT)
//                              [APP KEY1, APP KEY2], [APP SUM16, APP SUM LEN], [APP RVD1, APP RVD2], [APP RVD3, APP RVD4]
const u16_t pu16App_Stamp[8] = {MAGIC_APP_KEY, 0xFFFF, MAGIC_APP_SUM16, MAGIC_APP_SUM16_LEN, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF};

#else
const u16_t pu16App_Stamp[8] = {MAGIC_APP_KEY, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF};

#endif
// must be set at 0x00014110 - 0x0001414B (60 bytes)
__attribute__((section(".my_apppib")))
const u8_t 	pu8ProgrammerInfoBlock[PIB_SIZE] = {
    0xC0, 0x6C, 0x3A, 0x7B, 0xB2, 0x2F, 0x5D, 0x92,				// Start Pattern. FIXED
    (PIB_REV & 0x00FF),((PIB_REV & 0xFF00)>>0x08),       // PIB Revision
    (DEVICE_TYPE),
    (PROCESSOR_TYPE),
    (CODE_ID_NN & 0x00FF), ((CODE_ID_NN & 0xFF00)>>0x08),
    (CODE_ID_DDEE & 0x000000FF), ((CODE_ID_DDEE & 0x0000FF00)>>0x08), ((CODE_ID_DDEE & 0x00FF0000)>>0x10), ((CODE_ID_DDEE & 0xFF000000)>>0x18),
    (CODE_ID_BCCC & 0x000000FF), ((CODE_ID_BCCC & 0x0000FF00)>>0x08), ((CODE_ID_BCCC & 0x00FF0000)>>0x10), ((CODE_ID_BCCC & 0xFF000000)>>0x18),
    (CODE_ID_AA & 0x00FF), ((CODE_ID_AA & 0xFF00)>>0x08),
    (START_ADDRES & 0x000000FF), ((START_ADDRES & 0x0000FF00)>>0x08), ((START_ADDRES & 0x00FF0000)>>0x10), ((START_ADDRES & 0xFF000000)>>0x18),
    (STOP_ADDRES & 0x000000FF), ((STOP_ADDRES & 0x0000FF00)>>0x08), ((STOP_ADDRES & 0x00FF0000)>>0x10), ((STOP_ADDRES & 0xFF000000)>>0x18),
    (ERASE_TIME & 0x00FF), ((ERASE_TIME & 0xFF00)>>0x08),   //
    (PROGRAM_TIME & 0x00FF), ((PROGRAM_TIME & 0xFF00)>>0x08),  //
    (PROGRAM_BYTE & 0x00FF),((PROGRAM_BYTE & 0xFF00)>>0x08),
    (FILL_VALUE),
    (RVD_1BYTE),
    (RVD_4BYTE_1 & 0x000000FF), ((RVD_4BYTE_1 & 0x0000FF00)>>0x08), ((RVD_4BYTE_1 & 0x00FF0000)>>0x10), ((RVD_4BYTE_1 & 0xFF000000)>>0x18),
    (RVD_4BYTE_2 & 0x000000FF), ((RVD_4BYTE_2 & 0x0000FF00)>>0x08), ((RVD_4BYTE_2 & 0x00FF0000)>>0x10), ((RVD_4BYTE_2 & 0xFF000000)>>0x18),
    (RVD_2BYTE & 0x00FF), ((RVD_2BYTE & 0xFF00)>>0x08),

    (0x00FF &
     (  (PIB_REV & 0x00FF) + ((PIB_REV & 0xFF00)>>0x08)
      + (DEVICE_TYPE)
      + (PROCESSOR_TYPE)
      + (CODE_ID_NN & 0x00FF) + ((CODE_ID_NN & 0xFF00)>>0x08)
      + (CODE_ID_DDEE & 0x000000FF) + ((CODE_ID_DDEE & 0x0000FF00)>>0x08) + ((CODE_ID_DDEE & 0x00FF0000)>>0x10) + ((CODE_ID_DDEE & 0xFF000000)>>0x18)
      + (CODE_ID_BCCC & 0x000000FF) + ((CODE_ID_BCCC & 0x0000FF00)>>0x08) + ((CODE_ID_BCCC & 0x00FF0000)>>0x10) + ((CODE_ID_BCCC & 0xFF000000)>>0x18)
      + (CODE_ID_AA & 0x00FF) + ((CODE_ID_AA & 0xFF00)>>0x08)
      + (START_ADDRES & 0x000000FF) + ((START_ADDRES & 0x0000FF00)>>0x08) + ((START_ADDRES & 0x00FF0000)>>0x10) + ((START_ADDRES & 0xFF000000)>>0x18)
      + (STOP_ADDRES & 0x000000FF) + ((STOP_ADDRES & 0x0000FF00)>>0x08) + ((STOP_ADDRES & 0x00FF0000)>>0x10) + ((STOP_ADDRES & 0xFF000000)>>0x18)
      + (ERASE_TIME & 0x00FF) + ((ERASE_TIME & 0xFF00)>>0x08)
      + (PROGRAM_TIME & 0x00FF) + ((PROGRAM_TIME & 0xFF00)>>0x08)
      + (PROGRAM_BYTE & 0x00FF) + ((PROGRAM_BYTE & 0xFF00)>>0x08)
      + (FILL_VALUE)
      + (RVD_1BYTE)
      + (RVD_4BYTE_1 & 0x000000FF) + ((RVD_4BYTE_1 & 0x0000FF00)>>0x08) + ((RVD_4BYTE_1 & 0x00FF0000)>>0x10) + ((RVD_4BYTE_1 & 0xFF000000)>>0x18)
      + (RVD_4BYTE_2 & 0x000000FF) + ((RVD_4BYTE_2 & 0x0000FF00)>>0x08) + ((RVD_4BYTE_2 & 0x00FF0000)>>0x10) + ((RVD_4BYTE_2 & 0xFF000000)>>0x18)
      + (RVD_2BYTE & 0x00FF) + ((RVD_2BYTE & 0xFF00)>>0x08)
     )
    ),
    ((0xFF00 &
     (  (PIB_REV & 0x00FF) + ((PIB_REV & 0xFF00)>>0x08)
      + (DEVICE_TYPE)
      + (PROCESSOR_TYPE)
      + (CODE_ID_NN & 0x00FF) + ((CODE_ID_NN & 0xFF00)>>0x08)
      + (CODE_ID_DDEE & 0x000000FF) + ((CODE_ID_DDEE & 0x0000FF00)>>0x08) + ((CODE_ID_DDEE & 0x00FF0000)>>0x10) + ((CODE_ID_DDEE & 0xFF000000)>>0x18)
      + (CODE_ID_BCCC & 0x000000FF) + ((CODE_ID_BCCC & 0x0000FF00)>>0x08) + ((CODE_ID_BCCC & 0x00FF0000)>>0x10) + ((CODE_ID_BCCC & 0xFF000000)>>0x18)
      + (CODE_ID_AA & 0x00FF) + ((CODE_ID_AA & 0xFF00)>>0x08)
      + (START_ADDRES & 0x000000FF) + ((START_ADDRES & 0x0000FF00)>>0x08) + ((START_ADDRES & 0x00FF0000)>>0x10) + ((START_ADDRES & 0xFF000000)>>0x18)
      + (STOP_ADDRES & 0x000000FF) + ((STOP_ADDRES & 0x0000FF00)>>0x08) + ((STOP_ADDRES & 0x00FF0000)>>0x10) + ((STOP_ADDRES & 0xFF000000)>>0x18)
      + (ERASE_TIME & 0x00FF) + ((ERASE_TIME & 0xFF00)>>0x08)
      + (PROGRAM_TIME & 0x00FF) + ((PROGRAM_TIME & 0xFF00)>>0x08)
      + (PROGRAM_BYTE & 0x00FF) + ((PROGRAM_BYTE & 0xFF00)>>0x08)
      + (FILL_VALUE)
      + (RVD_1BYTE)
      + (RVD_4BYTE_1 & 0x000000FF) + ((RVD_4BYTE_1 & 0x0000FF00)>>0x08) + ((RVD_4BYTE_1 & 0x00FF0000)>>0x10) + ((RVD_4BYTE_1 & 0xFF000000)>>0x18)
      + (RVD_4BYTE_2 & 0x000000FF) + ((RVD_4BYTE_2 & 0x0000FF00)>>0x08) + ((RVD_4BYTE_2 & 0x00FF0000)>>0x10) + ((RVD_4BYTE_2 & 0xFF000000)>>0x18)
      + (RVD_2BYTE & 0x00FF) + ((RVD_2BYTE & 0xFF00)>>0x08)
     )
    )>>0x08),

    0x40, 0x0E, 0x75, 0x1F, 0x71, 0x5E, 0x3A, 0x29
};

// must be set at 0x0001414C - 0x0001414F (4 bytes)
__attribute__((section(".my_apppib_rvd")))
const u8_t pu8AppPib_Rvd1[4] = {0xFF, 0xFF, 0xFF, 0xFF};
/****************************************************************************
*	name        : ProgramInfoBlockFun
*	description :
*	return      : none
****************************************************************************/
void ProgramInfoBlockFun(void)
{
	__I u16_t  *pu16App_StampRom = &(pu16App_Stamp[0]);
	__I u8_t   *pu8ProgrammerInfoBlockRom = &(pu8ProgrammerInfoBlock[0]);
	u8_t    i, *pu8ProgrammerInfoBlockRam = &(tsProgamInfoBlock.pu8StartPattern[0]);

    if ((*pu16App_StampRom) == MAGIC_APP_KEY)
    {
        for(i=0;i<PIB_SIZE;i++)
        {
            *(pu8ProgrammerInfoBlockRam) = *(pu8ProgrammerInfoBlockRom);
            pu8ProgrammerInfoBlockRom++;
            pu8ProgrammerInfoBlockRam++;
        }
    }
}


/****************************************************************************
*	name        : Init_CommomRam
*	description :
*	return      : none
****************************************************************************/
#if (LITEON_BT)
void Init_CommomRam(void)
{
	u16_t i;

	tsCommonRam.u16EntryBootKey = 0;

	for(i=0; i<7; i++)
	{
		tsCommonRam.NA[i] = 0;
	}

    u16_t *myData = (u16_t *)0x20002FF0;
    //tsCommonRam.EntryBoot = 0x1234;
    if(*myData==0x1234)
    {
   // 	while(1);
    }
    else
    {
   // 	tsCommonRam.u16EntryBoot = 0x1234;
    }

}
#endif /* LITEON_BT */

/****************************************************************************
*	name        : SetEnteryBootKeytoRam
*	description :
*	return      : none
****************************************************************************/
#if (LITEON_BT)
void SetEnteryBootKeytoRam(u16_t u16Key)
{
	tsCommonRam.u16EntryBootKey = u16Key;

}
#endif /* LITEON_BT */



