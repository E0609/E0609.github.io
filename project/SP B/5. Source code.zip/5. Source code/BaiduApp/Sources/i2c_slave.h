/****************************************************************************
*	file	I2C.h
*	brief	include I2C master driver
*
*	author allen.lee
* 	version 1.0
*		-	2014/05/05: initial version by allen lee
*
****************************************************************************/

#ifndef I2C_SLAVE_H_
#define I2C_SLAVE_H_

#include "define.h"
#include "fsl_i2c_hal.h"
#include "bsc.h"
#include "macro_define.h"

/****************************************************************************
*   Declared Macro
****************************************************************************/

#define	I2C_SLAVE_SSIE_ENABLE		(0)
#define	I2C_SLAVE_SLTF_ENABLE	    (1)
#define	I2C_SLAVE_SHTF2IE_ENABLE	(0)
//---------------------------------------------------------------------
#if(INSPUR_BBS_ID)
#define SI2C_ADDR_A1 			0xb0
#define SI2C_ADDR_RA 			0xce
#else
#define SI2C_ADDR_A1 			0xa0
#define SI2C_ADDR_RA 			0xde
#endif

#define SI2C_ADDR_A2 			tsBSC_Infor.u8Address//0xa0>>1
//---------------------------------------------------------------------
#define SI2C0_CLK_HZ            (24000000U)	//bus clock
#define SI2C1_CLK_HZ            (48000000U)	//system clock

#define SI2C_CLK_DIVIDER_VALUE  (64)          //TCKSEL = 0
#define SI2C_SCL_TIMEOUT        (50)          //unit: msec

/****************************************************************************
 * Global Variables
 ****************************************************************************/

/****************************************************************************
* Declare structure
****************************************************************************/
#pragma pack(1)
typedef struct _si2c_slave_t {
	i2c_status_t status;                 /*!< The slave I2C status. */

    bool i2cIdle;
    bool i2cFail;
    u32_t u32timeout_ms;

#if (I2C_SLAVE_DEBUG)
    volatile uint32_t txSize;            /*!< Size of the TX buffer.*/
    volatile uint32_t rxSize;            /*!< Size of the RX buffer.*/
    const uint8_t *txBuff;               /*!< Pointer to Tx Buffer.*/
    uint8_t *rxBuff;                     /*!< Pointer to Rx Buffer.*/

    bool isTxBusy;                       /*!< True if the driver is sending data.*/
    bool isRxBusy;                       /*!< True if the driver is receiving data.*/
#endif

} si2c_slave_t;
#pragma pack()
/****************************************************************************
*   Declared Export functions
****************************************************************************/
extern void i2c_slave_irq_handler(u32_t u32instance);
extern bool GetSlaveI2cIdleFlage(u32_t u32instance);
extern bool IsBscI2cAddr2(u8_t u8SlvAddr);
extern i2c_status_t SlaveI2cBustimeout(uint32_t u32instance, uint32_t u32timeout_ms);
extern i2c_status_t SlaveI2cBusSCLtimeout(uint32_t u32instance);
extern void SlaveI2cBusCompletetransfer(uint32_t u32instance);
extern void Init_SlaveI2c(u32_t instance, u8_t rangeaddr_enable);
extern void DeInit_SlaveI2c(u32_t instance);

#if (I2C_SLAVE_DEBUG)
extern void Proc_I2C_Slave_Test(u32_t instance);
#endif

#endif /* I2C_SLAVE_H_ */
