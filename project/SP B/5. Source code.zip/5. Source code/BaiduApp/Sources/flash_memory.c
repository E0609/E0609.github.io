/****************************************************************************
*	file	flash_memory.c
*	brief	flash driver
*
*	author allen.lee
* 	version 1.0
*		-	2015/10/01: initial version by allen lee
*
****************************************************************************/
#include <string.h>
#include <stdio.h>
#include "board.h"
#include "flash_memory.h"
#include "flash_driver.h"


/****************************************************************************
 * Global Variables
 ****************************************************************************/


static sflash_memory_t tsflash_memory;



/****************************************************************************
*	name        : flash_mem_init
*	description : Init Flash memory
*	return      : none
****************************************************************************/
flash_status_t flash_mem_init(void)
{
	flash_init(&tsflash_memory);

}
/****************************************************************************
*	name        : flash_mem_erase
*	description : Erase Flash memory.
*	return      : none
****************************************************************************/
flash_status_t flash_mem_erase(u32_t u32address, u32_t u32length)
{
	flash_status_t status = kStatus_FLASH_Success;

	__disable_irq();
	//TURN_TGL_PTD6();
	status = flash_erase(u32address, u32length);
	//TURN_TGL_PTD6();
	__enable_irq();

    if (status != kStatus_FLASH_Success)
    {
        return status;
    }


	__disable_irq();

	//TURN_TGL_PTD6();
	status = flash_verify_erase(u32address, u32length);
	//TURN_TGL_PTD6();
	__enable_irq();


    return status;
}
/****************************************************************************
*	name        : flash_mem_read
*	description : Read memory
*	return      : none
****************************************************************************/
flash_status_t flash_mem_read(u32_t u32address, u32_t u32length, u8_t * pu8buffer)
{

	return flash_read(u32address, u32length, pu8buffer);
}

/****************************************************************************
*	name        : flash_mem_write
*	description : write memory
*	return      : none
****************************************************************************/
flash_status_t flash_mem_write(u32_t u32address, u32_t u32length, u8_t * pu8buffer)
{
    // Note: the check for "length != 0" and "range not in reserved region" is done in mem_write().
    assert(u32length);
    assert(pu8buffer);

    // Align length to whole words.
    uint32_t alignedLength = ALIGN_DOWN(u32length, sizeof(uint8_t)*PFLASH_ALIGMENT);
    uint32_t extraBytes = u32length - alignedLength;
    assert(extraBytes < sizeof(uint8_t)*PFLASH_ALIGMENT);

    uint8_t extraData[4] = {0xff, 0xff, 0xff, 0xff};

    if (extraBytes)
    {
        // Copy extra bytes to word buffer.
        memcpy(&extraData[0], &pu8buffer[alignedLength], extraBytes);
    }

    flash_status_t status = kStatus_FLASH_Success;

    __disable_irq();
    //TURN_TGL_PTD6();
    // Program whole words from the user's buffer.
    if (alignedLength)
    {
        status = flash_program(u32address, pu8buffer, alignedLength);
    }
    if ((status == kStatus_FLASH_Success) && extraBytes)
    {
        // Program trailing word.
        status = flash_program(u32address + alignedLength, extraData, sizeof(extraData));
    }
    //TURN_TGL_PTD6();
    __enable_irq();

    if (status != kStatus_FLASH_Success)
    {
        return status;
    }


    uint32_t failedAddress;
    uint32_t  failedData;

    __disable_irq();
    //TURN_TGL_PTD6();
    if (alignedLength)
    {
        status = flash_verify_program(u32address, alignedLength, (uint8_t *)pu8buffer, &failedAddress, &failedData);
    }

    if ((status == kStatus_FLASH_Success) && extraBytes)
    {
        status = flash_verify_program(u32address + alignedLength, sizeof(extraData), (uint8_t *)&extraData, &failedAddress, &failedData);
    }
    //TURN_TGL_PTD6();
    __enable_irq();

    if (status != kStatus_FLASH_Success)
    {
    	return status;
    }

    return kStatus_FLASH_Success;
}

/****************************************************************************
*	name        : Proc_Flash_memory_Test
*	description : test function
*	return      : none
****************************************************************************/
#if (FLASH_DEBUG)
u8_t pu8wrflash[1024];
void Proc_Flash_memory_Test(void)
{
	flash_status_t status;
	u32_t u32address, u32length, i;
	u8_t pu8rdflash[1024];
	static u8_t step = 1;

	u32_t u32failedAddress, u32failedData;


	u32address = 0x1FC00;
	u32length = 1024;

	flash_mem_init();

	switch(step)
	{
		case 0:
			status = flash_mem_erase(u32address, u32length);
			if(status == kStatus_FLASH_Success)
			{
				step = 1;
			}
			else
			{
				printf("Failure when flash erase .\n");
			}
			break;

		case 1:
			i=0;
			while(i<u32length)
			{
				pu8wrflash[i] = i;
				i++;
			}
			status = flash_mem_write(u32address, u32length, pu8wrflash);
			if(status == kStatus_FLASH_Success)
			{
				step = 2;
			}
			else
			{
				printf("Failure when flash program .\n");
			}
			break;

		case 2:
			for(i=0; i<u32length; i++)
			{
				pu8rdflash[i] = 0xff;
			}
			u32failedAddress = 0;
			u32failedData = 0xff;

			status = flash_mem_read(u32address, u32length, pu8rdflash);

			for(i=0; i<u32length; i++)
			{
				if (pu8rdflash[i] !=  pu8wrflash[i])
				{
					u32failedAddress = u32address+i;
					u32failedData = pu8rdflash[i];
					printf("Failure when flash Verified .\n");
					break;
				}
			}

			step = 3;

			break;

		default:

			break;


	}


}
#endif

