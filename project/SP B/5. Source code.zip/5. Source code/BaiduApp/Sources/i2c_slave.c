/****************************************************************************
*	file	I2C.c
*	brief	I2C master driver
*
*	author allen.lee
* 	version 1.0
*		-	2014/05/05: initial version by allen lee
*
****************************************************************************/
#include <string.h>
#include <stdio.h>
#include "board.h"
#include "fsl_clock_manager.h"
#include "fsl_interrupt_manager.h"
#include "i2c_slave.h"
#include "i2c_irq.h"
#include "fsl_debug_console.h"
#include "SlvPMBusApp.h"
#include "macro_define.h"

/****************************************************************************
 * Global Variables
 ****************************************************************************/
#define BSC_I2C0_PRIOR_LEVEL                (3)

static si2c_slave_t tsi2c_slave;

#if (I2C_SLAVE_DEBUG)
uint8_t slave_count = 0;
uint8_t slave_dataBuff[64];
#endif
/*FUNCTION**********************************************************************
 *
 * Function Name : i2c_hal_setRangeAddress7bit
 * Description   : Sets the range 7-bit slave address.
 *
 *END**************************************************************************/
void i2c_hal_setRangeAddress7bit(uint32_t u32baseAddr, uint8_t u8address)
{
    /* Set 7-bit slave range address.*/
	HW_I2C_RA_WR(u32baseAddr, u8address << 1U);
}
/*FUNCTION**********************************************************************
 *
 * Function Name : i2c_hal_setSMbusAddress7bit
 * Description   : Sets the range 7-bit slave address.
 *
 *END**************************************************************************/
void i2c_hal_setSMbusAddress7bit(uint32_t u32baseAddr, uint8_t u8address)
{
	/* Enable second i2c address.*/
	BW_I2C_SMB_SIICAEN(u32baseAddr, (uint8_t)true);

    /* Set 7-bit smbus address.*/
	HW_I2C_A2_WR(u32baseAddr, u8address << 1U);
}
/*FUNCTION**********************************************************************
 *
 * Function Name : i2c_hal_SetSecI2cAddressCmd
 * Description   : Sets the SHTF2IE value.
 *
 *END**************************************************************************/
void i2c_hal_SetSecI2cAddressCmd(uint32_t baseAddr, bool enable)
{
	BW_I2C_SMB_SIICAEN(baseAddr, (uint8_t)enable);

}
/*FUNCTION**********************************************************************
 *
 * Function Name : i2c_hal_setSclLowTimeout
 * Description   : Sets the SCL low timeout value.
 *
 *END**************************************************************************/
void i2c_hal_setSclLowTimeout(uint32_t u32baseAddr, uint16_t u16msec)
{
	u16_t u16vlaue;

	u16vlaue = (SI2C0_CLK_HZ/SI2C_CLK_DIVIDER_VALUE)/1000*u16msec;

	BW_I2C_SLTH_SSLT(u32baseAddr, (uint8_t)(u16vlaue>>8U));
	BW_I2C_SLTL_SSLT(u32baseAddr, (uint8_t)u16vlaue);
}

/*FUNCTION**********************************************************************
 *
 * Function Name : I2C_HAL_SetSclHighSdaLowIntCmd
 * Description   : Sets the SHTF2IE value.
 *
 *END**************************************************************************/
void I2C_HAL_SetSclHighSdaLowIntCmd(uint32_t baseAddr, bool enable)
{
	BW_I2C_SMB_SHTF2IE(baseAddr, (uint8_t)enable);
}
/*FUNCTION**********************************************************************
 *
 * Function Name : I2C_HAL_SetFackCmd
 * Description   : Sets the SHTF2IE value.
 *
 *END**************************************************************************/
void I2C_HAL_SetFackCmd(uint32_t baseAddr, bool enable)
{
	BW_I2C_SMB_FACK(baseAddr, (uint8_t)enable);
}
/*FUNCTION**********************************************************************
 *
 * Function Name : i2c_hal_getSMBusStatusFlag
 * Description   : Gets the I2C smbus status flag state.
 *
 *END**************************************************************************/
bool i2c_hal_getSMBusStatusFlag(uint32_t u32baseAddr, uint8_t u8statusFlag)
{
	return (bool)((HW_I2C_SMB_RD(u32baseAddr) >> u8statusFlag) & 0x1U);
}
/*FUNCTION**********************************************************************
 *
 * Function Name : i2c_hal_clearSclLowTimeout
 * Description   : Clears the SCL Low Timeout flag.
 *
 *END**************************************************************************/
void i2c_hal_clearSclLowTimeout(uint32_t baseAddr)
{
	BW_I2C_SMB_SLTF(baseAddr, 0x1U);
}
/*FUNCTION**********************************************************************
 *
 * Function Name : i2c_hal_clearSclHigh2Timeout
 * Description   : Clears the SCL High Timeout flag 2.
 *
 *END**************************************************************************/
void i2c_hal_clearSclHigh2Timeout(uint32_t baseAddr)
{
	BW_I2C_SMB_SHTF2(baseAddr, 0x1U);
}

/****************************************************************************
*	name        : i2c_slave_irq_handler
*	description : I2C Slave Generic ISR.
*	return      : none
****************************************************************************/
void i2c_slave_irq_handler(u32_t u32instance)
{
	assert(u32instance < HW_I2C_INSTANCE_COUNT);

	u32_t u32baseAddr = gl_i2cBaseAddr[u32instance];

    u8_t  u8i2cData  = 0x00, u8sendData;
    bool  doTransmit = false;
    bool  wasArbLost = I2C_HAL_GetStatusFlag(u32baseAddr, kI2CArbitrationLost);
    bool  addressed = I2C_HAL_GetStatusFlag(u32baseAddr, kI2CAddressAsSlave);
    bool  wasRam = I2C_HAL_GetStatusFlag(u32baseAddr, kI2CAddressMatch);

    bool  stopIntEnabled = true;

#if (I2C_SLAVE_SLTF_ENABLE)
    bool  wasSclLow = i2c_hal_getSMBusStatusFlag(u32baseAddr, BP_I2C_SMB_SLTF);
#endif

#if (I2C_SLAVE_SHTF2IE_ENABLE)
    bool  wasSclHigh2 = i2c_hal_getSMBusStatusFlag(u32baseAddr, BP_I2C_SMB_SHTF2);
#endif


#if (I2C_SLAVE_SSIE_ENABLE)
    bool     startDetected = I2C_HAL_GetStartFlag(u32baseAddr);
    bool     startIntEnabled = I2C_HAL_GetStartStopIntCmd(u32baseAddr);
    bool     stopDetected = I2C_HAL_GetStopFlag(u32baseAddr);
    stopIntEnabled = startIntEnabled;
#endif

#if (I2C_SLAVE_DEBUG)
    TURN_TGL_PTD6();
#endif
//    TURN_TGL_PTD6();

    /* Get current runtime structure */
    si2c_slave_t * tsslave = (si2c_slave_t *)gl_i2cStatePtr[u32instance];

    /* Get current master transfer direction */
    i2c_direction_t direction = I2C_HAL_GetDirMode(u32baseAddr);

#if (I2C_SLAVE_SSIE_ENABLE)
    /*--------------- Handle START ------------------*/
    if (startIntEnabled && startDetected)
    {
        I2C_HAL_ClearStartFlag(u32baseAddr);
        I2C_HAL_ClearInt(u32baseAddr);

        return;
    }
    /*--------------- Handle STOP ------------------*/
    if (stopIntEnabled && stopDetected)
    {
        I2C_HAL_ClearStopFlag(u32baseAddr);
        I2C_HAL_ClearInt(u32baseAddr);

        tsslave->status = kStatus_I2C_Idle;

        return;
    }
#endif

#if (I2C_SLAVE_SLTF_ENABLE)
    if(wasSclLow)
    {
    	i2c_hal_clearSclLowTimeout(u32baseAddr);
    	I2C_HAL_ClearInt(u32baseAddr);
    	tsslave->i2cFail = true;
    	return;
    }
#endif
#if (I2C_SLAVE_SHTF2IE_ENABLE)
	if (wasSclHigh2)
	{
		i2c_hal_clearSclHigh2Timeout(u32baseAddr);
    	I2C_HAL_ClearInt(u32baseAddr);
    	tsslave->i2cFail = true;
		return;
	}
#endif

    /* Clear the interrupt flag */
    I2C_HAL_ClearInt(u32baseAddr);

    if (wasArbLost)
    {
    	I2C_HAL_ClearArbitrationLost(u32baseAddr);

    	if (!addressed)
    	{
    		tsslave->status = kStatus_I2C_AribtrationLost;

    		/* Switch to RX mode.*/
    		//I2C_HAL_SetDirMode(baseAddr, kI2CReceive);
    		return;
    	}
    }

    /*--------------- Handle Address ------------------*/
    /* Addressed only happens when receiving address. */
    if (addressed) /* Slave is addressed. */
    {
    	tsslave->i2cIdle = false;
        /* Master read from Slave. Slave transmit.*/
        if (I2C_HAL_GetStatusFlag(u32baseAddr, kI2CSlaveTransmit))
        {
            /* Switch to TX mode*/
            I2C_HAL_SetDirMode(u32baseAddr, kI2CSend);

            //
            u8i2cData = I2C_HAL_ReadByte(u32baseAddr);
            SlvPMBusTxInit(u8i2cData);

        	if(SlvPMBusTxPase(&u8sendData))
        	{
        		/* The Txbuff is empty --> set kStatus_I2C_SlaveTxUnderrun*/
        	  	//tsslave->status = kStatus_I2C_SlaveTxUnderrun ;
        	}
        	I2C_HAL_WriteByte(u32baseAddr, u8sendData);

#if (I2C_SLAVE_DEBUG)
            //write data to data reg.............................
            doTransmit = true;
#endif
        }
        else /* Master write to Slave. Slave receive.*/
        {
            I2C_HAL_SendAck(u32baseAddr);

            /* Switch to RX mode.*/
            I2C_HAL_SetDirMode(u32baseAddr, kI2CReceive);

            /* Read dummy character.*/
            u8i2cData = I2C_HAL_ReadByte(u32baseAddr);

            SlvPMBusRxInit(u8i2cData);

        }
    }
    /*--------------- Handle Transfer ------------------*/
    else
    {
        /* Handle transmit */
        if (direction == kI2CSend)
        {
            if (I2C_HAL_GetStatusFlag(u32baseAddr, kI2CReceivedNak))
            {
                /* Switch to RX mode.*/
                I2C_HAL_SetDirMode(u32baseAddr, kI2CReceive);

                /* Read dummy character to release bus */
                I2C_HAL_ReadByte(u32baseAddr);

                if (!stopIntEnabled)
                {
                    /* Disable I2C interrupt in the peripheral.*/
                    I2C_HAL_SetIntCmd(u32baseAddr, false);
                }
#if (I2C_SLAVE_DEBUG)
                tsslave->txSize = 0;
                tsslave->txBuff = NULL;
                tsslave->isTxBusy = false;
#endif
            }
            else /* ACK from receiver.*/
            {
#if (I2C_SLAVE_DEBUG)
            	doTransmit = true;
#else
            	if(SlvPMBusTxPase(&u8sendData))
            	{
            		/* The Txbuff is empty --> set kStatus_I2C_SlaveTxUnderrun*/
            	  	//tsslave->status = kStatus_I2C_SlaveTxUnderrun ;
            	}
            	I2C_HAL_WriteByte(u32baseAddr, u8sendData);
#endif
            }

        }
        /* Handle receive */
        else
        {
            /* Get byte from data register */
        	u8i2cData = I2C_HAL_ReadByte(u32baseAddr);

#if (I2C_SLAVE_DEBUG)
            if (tsslave->rxSize)
            {
                *(tsslave->rxBuff) = u8i2cData;
                ++ tsslave->rxBuff;
                -- tsslave->rxSize;

                if (!tsslave->rxSize)
                {
                	tsslave->isRxBusy = false;
                	tsslave->rxBuff = NULL;
                }
            }
            else
            {
            	tsslave->isRxBusy = false;
            	tsslave->rxBuff = NULL;

                /* The Rxbuff is full --> Set kStatus_I2C_SlaveRxOverrun*/
            	tsslave->status = kStatus_I2C_SlaveRxOverrun;
            }
#else

            if(SlvPMBusRxPase(u8i2cData))
            {
                /* The Rxbuff is full --> Set kStatus_I2C_SlaveRxOverrun*/
            //	tsslave->status = kStatus_I2C_SlaveRxOverrun;
            	//when error detected, set NACK
            //	I2C_HAL_SendNak(u32instance);
            }
#endif
        }
    }

    /* DO TRANSMIT*/
#if (I2C_SLAVE_DEBUG)
    if (doTransmit)
    {
        if (tsslave->txSize)
        {
            u8i2cData = *(tsslave->txBuff);
            I2C_HAL_WriteByte(u32baseAddr, u8i2cData);
            ++ tsslave->txBuff;
            -- tsslave->txSize;
            if (!tsslave->txSize)
            {
                /* All bytes are received, so we're done with this transfer */
            	tsslave->txBuff = NULL;
            	tsslave->isTxBusy = false;

            }
        }
        else
        {
        	u8i2cData = 0xff;
        	I2C_HAL_WriteByte(u32baseAddr, u8i2cData);
            /* All bytes are received, so we're done with this transfer */
        	tsslave->txBuff = NULL;
        	tsslave->isTxBusy = false;

            /* The Txbuff is empty --> set kStatus_I2C_SlaveTxUnderrun*/
        	tsslave->status = kStatus_I2C_SlaveTxUnderrun ;
        }


    }
#endif
}

/****************************************************************************
*	name        : GetSlaveI2cIdleFlage
*	description :
*	return      : none
****************************************************************************/
bool GetSlaveI2cIdleFlage(u32_t u32instance)
{
	assert(u32instance < HW_I2C_INSTANCE_COUNT);

	si2c_slave_t * tsslave = (si2c_slave_t *)gl_i2cStatePtr[u32instance];

	return(tsslave->i2cIdle);
}
/****************************************************************************
*	name        : IsBscI2cAddr2
*	description :
*	return      : none
****************************************************************************/
bool IsBscI2cAddr2(u8_t u8SlvAddr)
{
	if(SI2C_ADDR_A2 == u8SlvAddr)
	{
		return(true);
	}

	return(false);
}
/****************************************************************************
*	name        : SlaveI2cBustimeout
*	description :
*	return      : none
****************************************************************************/
i2c_status_t SlaveI2cBustimeout(uint32_t u32instance, uint32_t u32timeout_ms)
{
	assert(u32instance < HW_I2C_INSTANCE_COUNT);

	u32_t u32baseAddr = gl_i2cBaseAddr[u32instance];
	si2c_slave_t * tsslave = (si2c_slave_t *)gl_i2cStatePtr[u32instance];


	/*if current instance is used */
	if (!tsslave->i2cIdle)
	{
		tsslave->u32timeout_ms += 1;

		if ((tsslave->u32timeout_ms) > u32timeout_ms)
		{
			tsslave->status = kStatus_I2C_Timeout;
		}
	}

	return tsslave->status;
}
/****************************************************************************
*	name        : SlaveI2cBusSCLtimeout
*	description :
*	return      : none
****************************************************************************/
i2c_status_t SlaveI2cBusSCLtimeout(uint32_t u32instance)
{
	assert(u32instance < HW_I2C_INSTANCE_COUNT);

	u32_t u32baseAddr = gl_i2cBaseAddr[u32instance];
	si2c_slave_t * tsslave = (si2c_slave_t *)gl_i2cStatePtr[u32instance];

	/*if current instance is scl low or high timeout */
	if (tsslave->i2cFail)
	{
		tsslave->status = kStatus_I2C_Fail;
	}

	return tsslave->status;
}

/****************************************************************************
*	name        : SlaveI2cBusStop
*	description :
*	return      : none
****************************************************************************/
void SlaveI2cBusCompletetransfer(uint32_t u32instance)
{
	assert(u32instance < HW_I2C_INSTANCE_COUNT);

	u32_t u32baseAddr = gl_i2cBaseAddr[u32instance];
	si2c_slave_t * tsslave = (si2c_slave_t *)gl_i2cStatePtr[u32instance];

    /* Init driver instance structure */
    memset(tsslave, 0, sizeof(si2c_slave_t));

    //tssavle->status = kStatus_I2C_Success;
    /* Indicate I2C bus is idle. */
    tsslave->i2cIdle = true;
//    TURN_TGL_MTEST();

}
/****************************************************************************
*	name        : configure_i2c_slave_bps
*	description : Initial I2Cx function
*	return      : none
****************************************************************************/
void configure_i2c_slave_bps(u32_t u32instance)
{
	u32_t u32baudRate_kbps = 100;

	assert(u32instance < HW_I2C_INSTANCE_COUNT);
    u32_t u32baseAddr = gl_i2cBaseAddr[u32instance];

    u32_t u32i2cClockFreq;

    /* Get the current bus clock.*/
    u32i2cClockFreq = CLOCK_SYS_GetI2cFreq(u32instance);

    I2C_HAL_SetBaudRate(u32baseAddr, u32i2cClockFreq, u32baudRate_kbps, NULL);
}
/****************************************************************************
*	name        : configure_i2c_master
*	description : Initial I2Cx function
*	return      : none
****************************************************************************/
i2c_status_t configure_i2c_slave(uint32_t u32instance, si2c_slave_t *tssavle, u8_t rangeaddrEnabled)
{
	assert(u32instance < HW_I2C_INSTANCE_COUNT);

	uint32_t u32baseAddr = gl_i2cBaseAddr[u32instance];

    /* Exit if current instance is already initialized */
    if (gl_i2cStatePtr[u32instance])
    {
        return kStatus_I2C_Initialized;
    }

    /* Init driver instance structure */
    memset(tssavle, 0, sizeof(si2c_slave_t));

    /* Enable clock for I2C.*/
    CLOCK_SYS_EnableI2cClock(u32instance);

    /* Initialize peripheral to known state.*/
    I2C_HAL_Init(u32baseAddr);

#if(SLAVE_GFILTER)
    BW_I2C_FLT_FLT(u32baseAddr, 15);
#endif

	if(rangeaddrEnabled)
	{
	    /* Set slave address.*/
	    I2C_HAL_SetAddress7bit(u32baseAddr, SI2C_ADDR_A1>>1U);

	    /* Set slave range address.*/
	    i2c_hal_setRangeAddress7bit(u32baseAddr, SI2C_ADDR_RA>>1U);
	    I2C_HAL_SetRangeMatchCmd(u32baseAddr, true);

	    I2C_HAL_SetGeneralCallCmd(u32baseAddr, false);

	    /* Set SMBus address.*/
	    i2c_hal_setSMbusAddress7bit(u32baseAddr, SI2C_ADDR_A2>>1U);
	}
	else
	{
	    /* Set slave address.*/
	    I2C_HAL_SetAddress7bit(u32baseAddr, SI2C_ADDR_A2>>1U);
	    I2C_HAL_SetRangeMatchCmd(u32baseAddr, false);

	    I2C_HAL_SetGeneralCallCmd(u32baseAddr, false);
	    /* Set SMBus address.*/
	    i2c_hal_SetSecI2cAddressCmd(u32baseAddr, false);
	}

	#if (I2C_SLAVE_CLOCKRATE)
	configure_i2c_slave_bps(u32instance);
	#endif

 //   I2C_HAL_SetSlaveBaudCtrlCmd(baseAddr, true);

    /* Set slave scl low timeout.*/
	#if (I2C_SLAVE_SLTF_ENABLE)
    i2c_hal_setSclLowTimeout(u32baseAddr, SI2C_SCL_TIMEOUT);
	#endif

    /* Save runtime structure pointer */
    gl_i2cStatePtr[u32instance] = tssavle;

	#if (I2C_SLAVE_SSIE_ENABLE)
	I2C_HAL_SetStartStopIntCmd(u32baseAddr,true);
	#endif

	#if (I2C_SLAVE_SHTF2IE_ENABLE)
	I2C_HAL_SetSclHighSdaLowIntCmd(u32baseAddr,true);
	#endif

    /* Enable I2C interrupt */
    I2C_HAL_SetIntCmd(u32baseAddr, true);

    /* Indicate I2C bus is idle. */
    tssavle->i2cIdle = true;

    /* Set interrupt priority */
    NVIC_SetPriority(gl_i2cIrqId[u32instance], BSC_I2C0_PRIOR_LEVEL);

    /* Enable I2C interrupt in NVIC level.*/
    INT_SYS_EnableIRQ(gl_i2cIrqId[u32instance]);

    /* Enable module.*/
    I2C_HAL_Enable(u32baseAddr);

    return kStatus_I2C_Success;
}
/****************************************************************************
*	name        : Init_SlaveI2c
*	description : Initial I2Cx function
*	return      : none
****************************************************************************/
void Init_SlaveI2c(u32_t u32instance, u8_t rangeaddrEnabled)
{
	assert(u32instance < HW_I2C_INSTANCE_COUNT);

    // Configure I2C pins
    configure_i2c_pins(u32instance);

    // Init I2C module
    configure_i2c_slave(u32instance, &tsi2c_slave, rangeaddrEnabled);
}
/****************************************************************************
*	name        : DeInit_SlaveI2c
*	description : DeInitial I2Cx function
*	return      : none
****************************************************************************/
void DeInit_SlaveI2c(u32_t u32instance)
{
	assert(u32instance < HW_I2C_INSTANCE_COUNT);

	uint32_t u32baseAddr = gl_i2cBaseAddr[u32instance];
	si2c_slave_t * slave = (si2c_slave_t *)gl_i2cStatePtr[u32instance];

    /* Exit if current instance is not already initialized */
    if (gl_i2cStatePtr[u32instance] == NULL)
    {
        return;
    }

	#if (I2C_SLAVE_SSIE_ENABLE)
	I2C_HAL_SetStartStopIntCmd(u32baseAddr,false);
	#endif

    /* Disable I2C interrupt. */
	I2C_HAL_SetIntCmd(u32baseAddr, false);

    /* Disable module.*/
    I2C_HAL_Disable(u32baseAddr);

    /* Disable clock for I2C.*/
    CLOCK_SYS_DisableI2cClock(u32instance);

    /* Disable I2C NVIC interrupt*/
    INT_SYS_DisableIRQ(gl_i2cIrqId[u32instance]);

    /* Cleared state pointer. */
    gl_i2cStatePtr[u32instance] = NULL;
}

/****************************************************************************
*	name        : SlaveI2cReceiveData
*	description : Private function to handle restart receive.
*	return      : none
****************************************************************************/
#if (I2C_SLAVE_DEBUG)
void SlaveI2cReceiveData(uint32_t instance, uint8_t * rxBuff, uint32_t rxSize)
{
    assert(rxBuff);
    assert(instance < HW_I2C_INSTANCE_COUNT);

    si2c_slave_t * slave = (si2c_slave_t *)gl_i2cStatePtr[instance];

    slave->rxBuff = rxBuff;
    slave->rxSize = rxSize;
    slave->isRxBusy = true;
}
#endif
/****************************************************************************
*	name        : SlaveI2cSendData
*	description : Private function to handle restart receive.
*	return      : none
****************************************************************************/
#if (I2C_SLAVE_DEBUG)
void SlaveI2cSendData(uint32_t instance, uint8_t * txBuff, uint32_t txSize)
{
    assert(txBuff);
    assert(instance < HW_I2C_INSTANCE_COUNT);

    si2c_slave_t * slave = (si2c_slave_t *)gl_i2cStatePtr[instance];

    slave->txBuff = txBuff;
    slave->txSize = txSize;
    slave->isTxBusy = true;
}
#endif
/****************************************************************************
*	name        : Proc_I2C_Slave_Test
*	description : test function
*	return      : none
****************************************************************************/
#if (I2C_SLAVE_DEBUG)
void Proc_I2C_Slave_Test(u32_t instance)
{
	si2c_slave_t * slave = (si2c_slave_t *)gl_i2cStatePtr[instance];

	static uint8_t slave_step = 0;
	uint8_t i;

	OSA_TimeDelay(10);

	switch(slave_step)
	{
		case 0:
			// Slave receive 1 byte from master
			SlaveI2cReceiveData(instance, (uint8_t*)&slave_count, 1);
			slave_step = 1;
			break;

		case 1:
			if (!slave->isRxBusy)
			{
		        // Clear receive buffer
		        for(i = 0; i < slave_count; i++)
		        {
		        	slave_dataBuff[i] = 0;
		        }
		        SlaveI2cReceiveData(instance, slave_dataBuff, slave_count);
				slave_step = 2;
			}
			break;

		case 2:
			if (!slave->isRxBusy)
			{
				SlaveI2cSendData(instance, slave_dataBuff, slave_count);
				slave_step = 3;
			}
			break;

		case 3:
			if (!slave->isTxBusy)
			{
				slave_step = 0;
			}
			break;
	}

}
#endif
