/****************************************************************************
*	file	MstPMBusData.h
*	brief	The file includes subroutines for 24LCxxx
*
*	author allen.lee
* 	version 1.0
*		-	2014/04/21: initial version by allen lee
*
****************************************************************************/

#ifndef PMBUSDATA_H_
#define PMBUSDATA_H_

#include "define.h"
#include "MstPMBusApp.h"
#include "macro_define.h"

/****************************************************************************
*   Declared Macro
****************************************************************************/
#if(BAIDU_BT)
#define BBU_PMBUS_RO_STA_NUM	14
#else
#define BBU_PMBUS_RO_STA_NUM	13
#endif
#define BBU_PMBUS_RO_MST_NUM    16
#define BBU_PMBUS_RO_INF_NUM    31
#define BBU_PMBUS_RO_MFC_NUM    8
#define BBU_PMBUS_RW_CFG_NUM    44
#if(BAIDU_BT)
#define BBU_PMBUS_WO_CTR_NUM    6
#else
#define BBU_PMBUS_WO_CTR_NUM    2
#endif

#define BBU_PMBUS_RO_NUM		68
#define BBU_PMBUS_WO_NUM		2
#define BBU_PMBUS_RW_NUM		43

#if (BAIDU_BT)
#define BBS_PMBUS_RO_NUM		6
#define BBS_PMBUS_WO_NUM		3
#define BBS_PMBUS_RW_NUM		12

#define BBS_BT_PMBUS_RO_NUM		0
#define BBS_BT_PMBUS_WO_NUM		2
#define BBS_BT_PMBUS_RW_NUM		1
#else
#define BBS_PMBUS_RO_NUM		6
#define BBS_PMBUS_WO_NUM		1
#define BBS_PMBUS_RW_NUM		11
#endif

#if(LITEON_BT)
#define BBU_BL_PMBUS_RO_NUM			0
#define BBU_BL_PMBUS_WO_NUM			2
#define BBU_BL_PMBUS_RW_NUM			6
#define BBU_BL_PMBUS_RW_DUMMY_NUM	1
#endif

#if (BAIDU_BT)
#define BBU_PMBUS_RO_BT_STA_NUM		2
#define BBU_BL_PMBUS_RO_DUMMY_NUM   1
#endif

#if(INSPUR_BBS_ID)
#define BBU_DEV_NUM			8
#else
#define BBU_DEV_NUM			16
#endif

//----------------------------------------------------------------------------
#define ADDR_0xA0	(0xA0)
#define ADDR_0xA2	(0xA2)
#define ADDR_0xA4	(0xA4)
#define ADDR_0xA6	(0xA6)

#define ADDR_0xB0	(0xB0)
#define ADDR_0xB2	(0xB2)
#define ADDR_0xB4	(0xB4)
#define ADDR_0xB6	(0xB6)

#define ADDR_0xC0	(0xC0)
#define ADDR_0xC2	(0xC2)
#define ADDR_0xC4	(0xC4)
#define ADDR_0xC6	(0xC6)

#define ADDR_0xD0	(0xD0)
#define ADDR_0xD2	(0xD2)
#define ADDR_0xD4	(0xD4)
#define ADDR_0xD6	(0xD6)

#define ADDR_0xEF	(0xEE)
//----------------------------------------------------------------------------
//enum of the PMBus commands
typedef enum
{
	PMBusCmd_Page = 0x00,
	PMBusCmd_Operation,
	PMBusCmd_OnOffConf,
	PMBusCmd_ClrFault,
	PMBusCmd_Phase,
	PMBusCmd_PagePlusWr,
	PMBusCmd_PagePlusRd,
	PMBusCmd_Reserved1,
	PMBusCmd_Reserved2,
	PMBusCmd_Reserved3,
	PMBusCmd_Reserved4,
	PMBusCmd_Reserved5,
	PMBusCmd_Reserved6,
	PMBusCmd_Reserved7,
	PMBusCmd_Reserved8,
	PMBusCmd_Reserved9,
	PMBusCmd_WriteProt = 0x10,
	PMBusCmd_StoreDftAll,
	PMBusCmd_RStoreDftAll,
	PMBusCmd_StoreDftCode,
	PMBusCmd_RStoreDftCode,
	PMBusCmd_StoreUserAll,
	PMBusCmd_RStoreUserAll,
	PMBusCmd_StoreUserCode,
	PMBusCmd_RStoreUserCode,
	PMBusCmd_Capability,
	PMBusCmd_Query,
	PMBusCmd_SMBAlertMask,
	PMBusCmd_Reserved10,
	PMBusCmd_Reserved11,
	PMBusCmd_Reserved12,
	PMBusCmd_Reserved13,
	PMBusCmd_VoutMode = 0x20,
	PMBusCmd_VoutCmd,
	PMBusCmd_VoutTrim,
	PMBusCmd_VoutCalOffset,
	PMBusCmd_VoutMax,
	PMBusCmd_VoutMarginHi,
	PMBusCmd_VoutMarginLow,
	PMBusCmd_VoutTranRate,
	PMBusCmd_VoutDroop,
	PMBusCmd_VoutScaleLoop,
	PMBusCmd_VoutScaleMon,
	PMBusCmd_Reserved14,
	PMBusCmd_Reserved15,
	PMBusCmd_Reserved16,
	PMBusCmd_Reserved17,
	PMBusCmd_Reserved18,
	PMBusCmd_Coef = 0x30,
	PMBusCmd_POutMax,
	PMBusCmd_MaxDuty,
	PMBusCmd_FreqSwitch,
	PMBusCmd_Reserved19,
	PMBusCmd_VinOn,
	PMBusCmd_VinOff,
	PMBusCmd_Interleave,
	PMBusCmd_IoutCalGain,
	PMBusCmd_IoutCalOff,
	PMBusCmd_FanConf12,
	PMBusCmd_FanCmd1,
	PMBusCmd_FanCmd2,
	PMBusCmd_FanConf34,
	PMBusCmd_FanCmd3,
	PMBusCmd_FanCmd4,
	PMBusCmd_VoutOVFaultLimit = 0x40,
	PMBusCmd_VoutOVFaultResp,
	PMBusCmd_VoutOVWarnLimit,
	PMBusCmd_VoutUVWarnLimit,
	PMBusCmd_VoutUVFaultLimit,
	PMBusCmd_VoutUVFaultResp,
	PMBusCmd_IoutOCFaultLimit,
	PMBusCmd_IoutOCFaultResp,
	PMBusCmd_IoutOCLVFaultLimit,
	PMBusCmd_IoutOCLVFaultResp,
	PMBusCmd_IoutOCWarnLimit,
	PMBusCmd_IoutUCFaultLimit,
	PMBusCmd_IoutUCFaultResp,
	PMBusCmd_Reserved20,
	PMBusCmd_Reserved21,
	PMBusCmd_OTFaultLimit,
	PMBusCmd_OTFaultResp = 0x50,
	PMBusCmd_OTWarnLimit,
	PMBusCmd_UTWarnLimit,
	PMBusCmd_UTFaultLimit,
	PMBusCmd_UTFaultResp,
	PMBusCmd_VinOVFaultLimit,
	PMBusCmd_VinOVFaultResp,
	PMBusCmd_VinOVWarnLimit,
	PMBusCmd_VinUVWarnLimit,
	PMBusCmd_VinUVFaultLimit,
	PMBusCmd_VinUVFaultResp,
	PMBusCmd_IinOCFaultLimit,
	PMBusCmd_IinOCFaultResp,
	PMBusCmd_IinOCWarnLimit,
	PMBusCmd_PwrGoodOn,
	PMBusCmd_PwrGoodOff,
	PMBusCmd_TonDelay = 0x60,
	PMBusCmd_TonRise,
	PMBusCmd_TonMaxFaultLimit,
	PMBusCmd_TonMaxFaultResp,
	PMBusCmd_ToffDelay,
	PMBusCmd_ToffFail,
	PMBusCmd_ToffMaxWarnLimit,
	PMBusCmd_Reserved22,
	PMBusCmd_POutOPFaultLimit,
	PMBusCmd_POutOPFaultResp,
	PMBusCmd_POutOPWarnLimit,
	PMBusCmd_PInOPWarnLimit,
	PMBusCmd_Reserved23,
	PMBusCmd_Reserved24,
	PMBusCmd_Reserved25,
	PMBusCmd_Reserved26,
	PMBusCmd_Reserved27 = 0x70,
	PMBusCmd_Reserved28,
	PMBusCmd_Reserved29,
	PMBusCmd_Reserved30,
	PMBusCmd_Reserved31,
	PMBusCmd_Reserved32,
	PMBusCmd_Reserved33,
	PMBusCmd_Reserved34,
	PMBusCmd_StatusByte,
	PMBusCmd_StatusWord,
	PMBusCmd_StatusVout,
	PMBusCmd_StatusIout,
	PMBusCmd_StatusInput,
	PMBusCmd_StatusTemp,
	PMBusCmd_StatusCML,
	PMBusCmd_StatusOther,
	PMBusCmd_StatusMFRSp = 0x80,
	PMBusCmd_StatusFan12,
	PMBusCmd_StatusFan34,
	PMBusCmd_Reserved35,
	PMBusCmd_Reserved36,
	PMBusCmd_Reserved37,
	PMBusCmd_RdEin,
	PMBusCmd_RdEout,
	PMBusCmd_RdVin,
	PMBusCmd_RdIin,
	PMBusCmd_RdVcap,
	PMBusCmd_RdVout,
	PMBusCmd_RdIout,
	PMBusCmd_RdTemp1,
	PMBusCmd_RdTemp2,
	PMBusCmd_RdTemp3,
	PMBusCmd_RdFanSpeed1 = 0x90,
	PMBusCmd_RdFanSpeed2,
	PMBusCmd_RdFanSpeed3,
	PMBusCmd_RdFanSpeed4,
	PMBusCmd_RdDutyCycle,
	PMBusCmd_RdFreq,
	PMBusCmd_RdPout,
	PMBusCmd_RdPin,
	PMBusCmd_RMBusRev,
	PMBusCmd_MFRID,
	PMBusCmd_MFRModel,
	PMBusCmd_MFRRev,
	PMBusCmd_MFRLocation,
	PMBusCmd_MFRDate,
	PMBusCmd_MFRSerial,
	PMBusCmd_AppProfileSup,
	PMBusCmd_MFRVinMin = 0xa0,
	PMBusCmd_MFRVinMax,
	PMBusCmd_MFRIinMax,
	PMBusCmd_MFRPinMax,
	PMBusCmd_MFRVoutMin,
	PMBusCmd_MFRVoutMax,
	PMBusCmd_MFRIoutMax,
	PMBusCmd_MFRPoutMax,
	PMBusCmd_MFRAmbTMax,
	PMBusCmd_MFRAmbTMin,
	PMBusCmd_MFREffLL,
	PMBusCmd_MFREffHL,
	PMBusCmd_MFRPinAccuracy,
	PMBusCmd_ICDevID,
	PMBusCmd_ICDevRev,
	PMBusCmd_Reserved38,
	PMBusCmd_UsrData0 = 0xb0,
	PMBusCmd_UsrData1,
	PMBusCmd_UsrData2,
	PMBusCmd_UsrData3,
	PMBusCmd_UsrData4,
	PMBusCmd_UsrData5,
	PMBusCmd_UsrData6,
	PMBusCmd_UsrData7,
	PMBusCmd_UsrData8,
	PMBusCmd_UsrData9,
	PMBusCmd_UsrData10,
	PMBusCmd_UsrData11,
	PMBusCmd_UsrData12,
	PMBusCmd_UsrData13,
	PMBusCmd_UsrData14,
	PMBusCmd_UsrData15,
	PMBusCmd_MFRMaxTemp1 = 0xc0,
	PMBusCmd_MFRMaxTemp2,
	PMBusCmd_MFRMaxTemp3,
	PMBusCmd_Reserved39,
	PMBusCmd_Reserved40,
	PMBusCmd_Reserved41,
	PMBusCmd_Reserved42,
	PMBusCmd_Reserved43,
	PMBusCmd_Reserved44,
	PMBusCmd_Reserved45,
	PMBusCmd_Reserved46,
	PMBusCmd_Reserved47,
	PMBusCmd_Reserved48,
	PMBusCmd_Reserved49,
	PMBusCmd_Reserved50,
	PMBusCmd_Reserved51,
	PMBusCmd_MFRSp0 = 0xd0,
	PMBusCmd_MFRSp1,
	PMBusCmd_MFRSp2,
	PMBusCmd_MFRSp3,
	PMBusCmd_MFRSp4,
	PMBusCmd_MFRSp5,
	PMBusCmd_MFRSp6,
	PMBusCmd_MFRSp7,
	PMBusCmd_MFRSp8,
	PMBusCmd_MFRSp9,
	PMBusCmd_MFRSp10,
	PMBusCmd_MFRSp11,
	PMBusCmd_MFRSp12,
	PMBusCmd_MFRSp13,
	PMBusCmd_MFRSp14,
	PMBusCmd_MFRSp15,
	PMBusCmd_MFRSp16 = 0xe0,
	PMBusCmd_MFRSp17,
	PMBusCmd_MFRSp18,
	PMBusCmd_MFRSp19,
	PMBusCmd_MFRSp20,
	PMBusCmd_MFRSp21,
	PMBusCmd_MFRSp22,
	PMBusCmd_MFRSp23,
	PMBusCmd_MFRSp24,
	PMBusCmd_MFRSp25,
	PMBusCmd_MFRSp26,
	PMBusCmd_MFRSp27,
	PMBusCmd_MFRSp28,
	PMBusCmd_MFRSp29,
	PMBusCmd_MFRSp30,
	PMBusCmd_MFRSp31,
	PMBusCmd_MFRSp32 = 0xf0,	//Boot loader Key
	PMBusCmd_MFRSp33,			//Boot loader Status/Cmd
	PMBusCmd_MFRSp34,			//Boot loader Memory Block
	PMBusCmd_MFRSp35,			//Boot loader Product Key
	PMBusCmd_MFRSp36,			//Image Checksum
	PMBusCmd_MFRSp37,			//
	PMBusCmd_MFRSp38,			//
	PMBusCmd_MFRSp39,			//
	PMBusCmd_MFRSp40,
	PMBusCmd_MFRSp41,
	PMBusCmd_MFRSp42,
	PMBusCmd_MFRSp43,
	PMBusCmd_MFRSp44,
	PMBusCmd_MFRSp45,
	PMBusCmd_MFRSpCmdExt,
	PMBusCmd_PMBusCmdExt
}ePMBusCmd_t;
//----------------------------------------------------------------------------
//enum of command type
typedef enum
{
	//not support command
	PMBusCT_NoSupp = 0x00,
	//read command
	PMBusCT_RdnBytes = 0x01,
	PMBusCT_BlockRd = 0x02,
	PMBusCT_ProCall = 0x03,
	PMBusCT_BWrBRdProCall = 0x04,
    //write command
    PMBusCT_WrnBytes = 0x10,
    PMBusCT_BlockWr = 0x11,
    PMBusCT_SendByte = 0x12,
    //read-write command
    PMBusCT_RdWrnBytes = 0x20,
    PMBusCT_BlockRdWr = 0x21,
    PMBusCT_BRdBWr_Wrnbytes = 0x22,

}ePMBusCmdType_t;
//----------------------------------------------------------------------------
//enum of data type
typedef enum
{
	PMBusDT_Linear = 0x00,
	PMBusDT_s16,
	PMBusDT_Reserved,
	PMBusDT_Direct,
	PMBusDT_u8,
	PMBusDT_VID,
	PMBusDT_MFR,
	PMBusDT_NN_Block			//non numeric data or block data
}ePMBusDataType_t;
//----------------------------------------------------------------------------
//enum of command property
typedef enum
{
	PMBusCP_NoSupp = 0x00,
	PMBusCP_RdOnly = 0x01,
	PMBusCP_WrOnly = 0x02,
    PMBusCP_RdWr = 0x03,

}ePMBusCmdProperty_t;
/****************************************************************************
*   Declared Structures & Variables
****************************************************************************/
typedef struct
{
	u8_t    u8CmdCode;
	u8_t    u8CmdType;
	u8_t    u8DataType;
	u8_t    u8Len;	    //without slave address, byte count and PEC
    u8_t*   pu8Buff;      //the address of the variable used for the command
    void (*FuncPtr)(u8_t* pu8TgtBuf, u8_t* pu8SrcBuf, u16_t u16WrLen);
}sPMBusCmdStr_t;
extern sPMBusCmdStr_t sPMBusCmdStruct;
//sPMBusAppStruct
//----------------------------------------------------------------------------
typedef union _nPMCmd19hStatus_t
{
    struct
    {
        u8_t u1Bit0    :1; //
	    u8_t u1Bit1	   :1;
	    u8_t u1Bit2	   :1;
	    u8_t u1Bit3    :1;
	    u8_t u1Bit4    :1;
	    u8_t u1Bit5    :1;
	    u8_t u1Bit6    :1;
	    u8_t u1Bit7    :1;

    } u8Bit;

    u8_t u8All;
} nPMCmd19hStatus_t;
//----------------------------------------------
typedef union _nPMCmd1AhStatus_t
{
    struct
    {
        u8_t u1Bit0    :1; //
	    u8_t u1Bit1	   :1;
	    u8_t u1Bit2	   :1;
	    u8_t u1Bit3    :1;
	    u8_t u1Bit4    :1;
	    u8_t u1Bit5    :1;
	    u8_t u1Bit6    :1;
	    u8_t u1Bit7    :1;

    } u8Bit;

    u8_t u8All;
} nPMCmd1AhStatus_t;
//----------------------------------------------
typedef union _nPMCmd78hStatus_t
{
    struct
    {
        u8_t u1Bit0    :1; //
	    u8_t u1Bit1	   :1;
	    u8_t u1Bit2	   :1;
	    u8_t u1Bit3    :1;
	    u8_t u1Bit4    :1;
	    u8_t u1Bit5    :1;
	    u8_t u1Bit6    :1;
	    u8_t u1Bit7    :1;

    } u8Bit;

    u8_t u8All;
} nPMCmd78hStatus_t;
//----------------------------------------------
typedef union _nPMCmd79hStatus_t
{
    struct
    {
	    u16_t u1Bit0    :1; //
		u16_t u1Bit1	:1;
		u16_t u1Bit2	:1;
		u16_t u1Bit3    :1;
		u16_t u1Bit4    :1;
		u16_t u1Bit5    :1;
		u16_t u1Bit6    :1;
		u16_t u1Bit7    :1;

		u16_t u1Bit8    :1; //
		u16_t u1Bit9	:1;
		u16_t u1Bit10	:1;
		u16_t u1Bit11    :1;
		u16_t u1Bit12    :1;
		u16_t u1Bit13    :1;
		u16_t u1Bit14    :1;
		u16_t u1Bit15    :1;
    } u16Bit;

    u16_t u16All;
} nPMCmd79hStatus_t;
//----------------------------------------------
typedef union _nPMCmd7AhStatus_t
{
    struct
    {
        u8_t u1Bit0    :1; //
	    u8_t u1Bit1	   :1;
	    u8_t u1Bit2	   :1;
	    u8_t u1Bit3    :1;
	    u8_t u1Bit4    :1;
	    u8_t u1Bit5    :1;
	    u8_t u1Bit6    :1;
	    u8_t u1Bit7    :1;

    } u8Bit;

    u8_t u8All;
} nPMCmd7AhStatus_t;
//----------------------------------------------
typedef union _nPMCmd7BhStatus_t
{
    struct
    {
        u8_t u1Bit0    :1; //
	    u8_t u1Bit1	   :1;
	    u8_t u1Bit2	   :1;
	    u8_t u1Bit3    :1;
	    u8_t u1Bit4    :1;
	    u8_t u1Bit5    :1;
	    u8_t u1Bit6    :1;
	    u8_t u1Bit7    :1;

    } u8Bit;

    u8_t u8All;
} nPMCmd7BhStatus_t;
//----------------------------------------------
typedef union _nPMCmd7ChStatus_t
{
    struct
    {
        u8_t u1Bit0    :1; //
	    u8_t u1Bit1	   :1;
	    u8_t u1Bit2	   :1;
	    u8_t u1Bit3    :1;
	    u8_t u1Bit4    :1;
	    u8_t u1Bit5    :1;
	    u8_t u1Bit6    :1;
	    u8_t u1Bit7    :1;

    } u8Bit;

    u8_t u8All;
} nPMCmd7ChStatus_t;
//----------------------------------------------
typedef union _nPMCmd7DhStatus_t
{
    struct
    {
        u8_t u1Bit0    :1; //
	    u8_t u1Bit1	   :1;
	    u8_t u1Bit2	   :1;
	    u8_t u1Bit3    :1;
	    u8_t u1Bit4    :1;
	    u8_t u1Bit5    :1;
	    u8_t u1Bit6    :1;
	    u8_t u1Bit7    :1;

    } u8Bit;

    u8_t u8All;
} nPMCmd7DhStatus_t;
//----------------------------------------------
typedef union _nPMCmd7EhStatus_t
{
    struct
    {
        u8_t u1Bit0    :1; //
	    u8_t u1Bit1	   :1;
	    u8_t u1Bit2	   :1;
	    u8_t u1Bit3    :1;
	    u8_t u1Bit4    :1;
	    u8_t u1Bit5    :1;
	    u8_t u1Bit6    :1;
	    u8_t u1Bit7    :1;

    } u8Bit;

    u8_t u8All;
} nPMCmd7EhStatus_t;
//----------------------------------------------
typedef union _nPMCmd81hStatus_t
{
    struct
    {
        u8_t u1Bit0    :1; //
	    u8_t u1Bit1	   :1;
	    u8_t u1Bit2	   :1;
	    u8_t u1Bit3    :1;
	    u8_t u1Bit4    :1;
	    u8_t u1Bit5    :1;
	    u8_t u1Bit6    :1;
	    u8_t u1Bit7    :1;

    } u8Bit;

    u8_t u8All;
} nPMCmd81hStatus_t;
//----------------------------------------------
typedef union _nPMCmd98hStatus_t
{
    struct
    {
        u8_t u1Bit0    :1; //
	    u8_t u1Bit1	   :1;
	    u8_t u1Bit2	   :1;
	    u8_t u1Bit3    :1;
	    u8_t u1Bit4    :1;
	    u8_t u1Bit5    :1;
	    u8_t u1Bit6    :1;
	    u8_t u1Bit7    :1;

    } u8Bit;

    u8_t u8All;
} nPMCmd98hStatus_t;
//----------------------------------------------
typedef union _nPMCmdD0hStatus_t
{
    struct
    {
        u8_t u1Bit0    :1; //
	    u8_t u1Bit1	   :1;
	    u8_t u1Bit2	   :1;
	    u8_t u1Bit3    :1;
	    u8_t u1Bit4    :1;
	    u8_t u1Bit5    :1;
	    u8_t u1Bit6    :1;
	    u8_t u1Bit7    :1;

    } u8Bit;

    u8_t u8All;
} nPMCmdD0hStatus_t;
//----------------------------------------------
typedef union _nPMCmdD1hStatus_t
{
    struct
    {
	    u16_t u1Bit0    :1; //
		u16_t u1Bit1	:1;
		u16_t u1Bit2	:1;
		u16_t u1Bit3    :1;
		u16_t u1Bit4    :1;
		u16_t u1Bit5    :1;
		u16_t u1Bit6    :1;
		u16_t u1Bit7    :1;

		u16_t u1Bit8    :1; //
		u16_t u1Bit9	:1;
		u16_t u1Bit10	:1;
		u16_t u1Bit11    :1;
		u16_t u1Bit12    :1;
		u16_t u1Bit13    :1;
		u16_t u1Bit14    :1;
		u16_t u1Bit15    :1;
    } u16Bit;

    u16_t u16All;
} nPMCmdD1hStatus_t;
//----------------------------------------------
typedef union _nPMCmdD2hStatus_t
{
    struct
    {
        u8_t u1Bit0    :1; //
	    u8_t u1Bit1	   :1;
	    u8_t u1Bit2	   :1;
	    u8_t u1Bit3    :1;
	    u8_t u1Bit4    :1;
	    u8_t u1Bit5    :1;
	    u8_t u1Bit6    :1;
	    u8_t u1Bit7    :1;

    } u8Bit;

    u8_t u8All;
} nPMCmdD2hStatus_t;
//----------------------------------------------
typedef union _nPMCmdD5hStatus_t
{
    struct
    {
        u8_t u1Bit0    :1; //
	    u8_t u1Bit1	   :1;
	    u8_t u1Bit2	   :1;
	    u8_t u1Bit3    :1;
	    u8_t u1Bit4    :1;
	    u8_t u1Bit5    :1;
	    u8_t u1Bit6    :1;
	    u8_t u1Bit7    :1;

    } u8Bit;

    u8_t u8All;
} nPMCmdD5hStatus_t;
//----------------------------------------------------------------------------
#pragma pack(1)
typedef struct _sBBUCmd_t
{
	u8_t u8CurrPage;				//command 00h
	u8_t u8Operation;				//command 01h
	u8_t u8OnOffConfig;				//command 02h
	u8_t u8ClrFault;				//command 03h
	u8_t pu8PgPlusWr[1];			//command 05h
	u8_t pu8PgPlusRd[1];			//command 06h
	u8_t u8WriteProtect;			//command 10h
	u8_t u8StoreDefaultAll;			//command 11h
	nPMCmd19hStatus_t tnCapability;	//command 19h
	nPMCmd1AhStatus_t tnPMBusQuerry;//command 1Ah
	u8_t u8VoutMode;				//command 20h
	u16_t u16VoutCmd;				//command 21h
	u16_t u16VoutOVFaultL;	//command 40h
	u8_t u8VoutOVFaultResp;			//command 41h
	u16_t u16VoutOVWarnL;	//command 42h
	u16_t u16VoutUVWarnL;	//command 43h
	u16_t u16VoutUVFaultL;	//command 44h
	u8_t u8VoutUVFaultResp;		//command 45h
	u16_t u16IoutOCFaultL;	//command 46h
	u8_t u8IoutOCFaultResp;			//command 47h
	u16_t u16IoutOCWarnL;	//command 4Ah
	u16_t u16OTFaultL;		//command 4Fh
	u8_t u8OTFaultResp;			//command 50h
	u16_t u16OTWarnL;		//command 51h
	u16_t u16VinOVFaultL;	//command 55h
	u8_t u8VinOVFaultResp;			//command 56h
	u16_t u16VinOVWarnL;	//command 57h
	u16_t u16VinUVWarnL;	//command 58h
	u16_t u16VinUVFaultL;	//command 59h
	u8_t u8VinUVFaultResp;			//command 5Ah
	u16_t u16IinOCFaultL;	//command 5Bh
	u8_t u8IinOCFaultResp;	//command 5Ch
	u16_t u16IinOCWarnL;	//command 5Dh
	u16_t u16POutOPFaultL;	//command 68h
	u16_t u16PoutOPWarnL;	//command 6Ah
	u16_t u16PinOPWarnL;	//command 6Bh
	nPMCmd78hStatus_t tnStatusByte;	//command 78h
	nPMCmd79hStatus_t tnStatusWord;	//command 79h
	nPMCmd7AhStatus_t tnStatusVout;	//command 7Ah
	nPMCmd7BhStatus_t tnStatusIout;	//command 7Bh
	nPMCmd7ChStatus_t tnStatusInput;//command 7Ch
	nPMCmd7DhStatus_t tnStatusTemp;	//command 7Dh
	nPMCmd7EhStatus_t tnStatusCML;	//command 7Eh
	u16_t u16ReadVin;				//command 88h
	u16_t u16ReadIin;				//command 89h
	u16_t u16ReadVout;				//command 8Bh
	u16_t u16ReadIout;				//command 8Ch
	u16_t u16ReadTemp1;				//command 8Dh
	u16_t u16ReadTemp2;				//command 8Eh
	u16_t u16ReadTemp3;				//command 8Fh
	u16_t u16ReadPout;				//command 96h
	u16_t u16ReadPin;				//command 97h
	nPMCmd98hStatus_t tnPMBusRev;	//command 98h
	u8_t pu8MFRID[10];				//command 99h
	u8_t pu8MFRModel[11];			//command 9Ah
	u8_t pu8MFRRev[10];				//command 9Bh
	u8_t pu8MFRLoc[10];				//command 9Ch
	u8_t pu8MFRDate[10];			//command 9Dh
	u8_t pu8MFRSerial[19];			//command 9Eh
	u16_t u16MFRVinMin;				//command A0h
	u16_t u16MFRVinMax;				//command A1h
	u16_t u16MFRIinMax;				//command A2h
	u16_t u16MFRPinMax;				//command A3h
	u16_t u16MFRVoutMin;			//command A4h
	u16_t u16MFRVoutMax;			//command A5h
	u16_t u16MFRIoutMax;			//command A6h
	u16_t u16MFRPoutMax;			//command A7h
	u16_t u16MFRAmbTMax;			//command A8h
	u16_t u16MFRAmbTMin;			//command A9h
	u16_t u16ChgrTempFalutL;			//command B0h
	u16_t u16ChrgTempWarnL;				//command B1h
	u16_t u16AmbTempFalutL;				//command B2h
	u16_t u16AmbTempWarnL;				//command B3h
	u16_t u16DisChgrCellTempFalutL;		//command B4h
	u16_t u16DisChrgCellTempWarnL;		//command B5h
	u16_t u16ChrgCellTempFalutL;		//command B6h
	u16_t u16ChrgCellTempWarnL;			//command B7h
	u16_t u16ModeChange;				//command BBh
	u8_t pu8PackMFT[15];				//command BCh
	u8_t pu8CellMFT[15];				//command BDh
	u8_t pu8CellModel[15];				//command BEh
	u16_t u16MFRMaxTemp1;				//command C0h
	u16_t u16MFRMaxTemp2;				//command C1h
	nPMCmdD0hStatus_t tnStatusBBU;		//command D0h
	nPMCmdD1hStatus_t tnStateBBU;		//command D1h
	nPMCmdD2hStatus_t tnChrgCurrStatus;	//command D2h
	u8_t pu8BattPackSN[2];				//command D3h
	u16_t u16BattVolt;					//command D4h
	//u8_t pu8FWRevision[10];				//command D5h
	u8_t pu8BmsHwFwCompCode[11];		//command D5h
	u16_t u16BattCurr;					//command D6h
	u16_t u16BattASOC;					//command D7h
	u16_t u16BattCycCntOffset;			//command D8h
	u16_t u16BattRSOC;			//command D9h
	u16_t u16BattCapacity;		//command DAh
	u16_t u16BattCycCnt;		//command DBh
	u32_t u32BattRunTime;		//command DCh
	u16_t u16BattStatus;		//command DDh
	u16_t u16BattProcStatus;	//command DEh
	u16_t u16BattPfStatus;		//command DFh
	u16_t u16VrefOffLine;	//command E0h
	u16_t u16VrefOnLine;	//command E1h
	u16_t u16TrimCsDuty;	//command E2h
	u16_t u16BattTemp;		//command E3h
	u8_t u8Calibration;		//command E4h
	u32_t pu32BBUProtectType;	//command E5h
	u16_t u16LastProtectIndex;	//command E6h
	u8_t u8LastProtect[4];	    //command E7h
	u16_t u16BattSOH;			//command E8h
	u16_t u16DischrgRemainTime;	//command E9h
	u8_t u8CellVoltMinHistory[28];	//command EAh
	u16_t u16BMSFWRevision;		//command EBh
	u16_t u16FullyChrgCapacity;	//command ECh
	u16_t u16BattCycL;			//command EDh
	u16_t u16BbuIntCtrl;			//command EEh

#if(BAIDU_BT)
	u8_t  pu8PBtKey[4];			//command F0h
	u8_t  u8BtStatus;			//command F1h
	u8_t  u8BtCmd;				//command F1h
	u8_t  pu8BtMemBlock[32];	//command F2h
	u8_t  pu8ProductKey[16];	//command F3h
	u16_t u16ImageChk;			//command F4h
#endif

	u8_t pu8BbuHwFwCompCode[11];		//command FCh
	u8_t pu8Protocol[16];		//command FDh
} sBBUCmd_t;
#pragma pack( )

extern sBBUCmd_t tsBBU_Dev[BBU_DEV_NUM];
//----------------------------------------------------------------------------
typedef union _nPMCmdB8hStatus_t
{
    struct
    {
    	u16_t u2ShelfQty 	: 2; //0-1 unit, 1-2 unit(default), 2-3 unit, 3-4 unit
    	u16_t u6Rsvd1    	: 6;
    	u16_t u2CtrlDischrg	: 2; //0-default, 1-manual, 2-stop
    	u16_t u6Rsvd2    	: 6;
    } u16Bit;

    u16_t u16All;
} nPMCmdB8hStatus_t;
//----------------------------------------------
typedef union _nPMCmdB9hStatus_t
{
    struct
    {
    	u16_t u2LearnState 	: 2;
    	u16_t u3LearnResult	: 3;
    	u16_t u5LearnCondition 	: 5;
    	u16_t u5Rsvd1 		: 5;
    	u16_t u1ManDischrg	: 1;
    } u16Bit;

    u16_t u16All;
} nPMCmdB9hStatus_t;
//----------------------------------------------

//----------------------------------------------
#pragma pack(1)
typedef struct _sBSCCmd_t
{
	//u8_t pu8MFRID[15];				//command 99h,15
	//u8_t pu8MFRModel[15];			//command 9Ah,15
	//u8_t pu8MFRRev[15];				//command 9Bh,15
	//u8_t pu8MFRLoc[15];				//command 9Ch,15
	//u8_t pu8MFRDate[15];			//command 9Dh,15
	//u8_t pu8MFRSerial[15];			//command 9Eh,15
	u8_t u8ClrFault;				//command 03h
	nPMCmd7EhStatus_t tnStatusCML;	//command 7Eh,1

	u8_t pu8MFRID[10];//command 99h
	u8_t pu8MFRModel[11];//command 9Ah,15
	u8_t pu8MFRRev[10];//command 9Bh
	u8_t pu8MFRLoc[10];//command 9Ch
	u8_t pu8MFRDate[10];//command 9Dh
	u8_t pu8MFRSerial[15];//command 9Eh

	nPMCmdB8hStatus_t tnLearningCtrl;	//command B8h,2
	nPMCmdB9hStatus_t tnStatusWord;	//command B9h,2
	u8_t pu8BbuAddress[16];			//command BAh,16
	u16_t u16ModeChange;			//command BBh,2
	u8_t u8Calibration;				//command E4h
	u16_t u16BattSelfCycleTime;		//command EFh,2

#if (BAIDU_BT)
	u8_t  pu8PBtKey[4];			//command F0h
	u8_t  u8BtStatus;			//command F1h
	u8_t  u8BtCmd;				//command F1h
	u8_t  pu8BtMemBlock[32];	//command F2h
	u8_t  pu8ProductKey[16];	//command F3h
	u16_t u16ImageChk;			//command F4h
#endif

	u16_t u16BattSelfDischrgRate;	//command F8h
	u16_t u16BattSelfCycleCnt;		//command F9h
	u8_t  pu8BbsHwFwCompCode[11];	//command FCh
	u8_t pu8Protocol[16];			//command FDh
} sBSCCmd_t;
#pragma pack( )

extern sBSCCmd_t tsBSC_Dev;
//----------------------------------------------------------------------------
typedef union _nBtPMCmdStatus_t
{
    struct
    {
    	u16_t u1CodeIdErr 	: 1;
    	u16_t u1EntBtPwdErr : 1;
    	u16_t u1CrcErr		: 1;
    	u16_t u1RvdBit3 	: 1;
    	u16_t u1AddressErr 	: 1;
    	u16_t u1EraseErr 	: 1;
    	u16_t u1ProgramErr 	: 1;
    	u16_t u1RvdBit7Err 	: 1;

    	u16_t u1CmdErr 		: 1;
    	u16_t u1RvdBit9Err 	: 1;
    	u16_t u1RvdBit10Err : 1;
    	u16_t u1RvdBit11Err : 1;
    	u16_t u1RvdBit12Err : 1;
    	u16_t u1RvdBit13Err : 1;
    	u16_t u1ProcessFlag : 1;
    	u16_t u1ModeFlag 	: 1;
    } u16Bit;

    u16_t u16All;
} nBtPMCmdStatus_t;
//----------------------------------------------
#pragma pack(1)
typedef struct _sBtCmdF0h_t
{
	nBtPMCmdStatus_t tnBtStatus;
	u8_t pu8CodeID[12];

} sBtCmdF0h_t;
#pragma pack( )
//----------------------------------------------
#pragma pack(1)
typedef struct _sBtCmdF1h_t
{
	u16_t u16ModuleWord;
	nBtPMCmdStatus_t tnBtStatus;
} sBtCmdF1h_t;
#pragma pack( )
//----------------------------------------------
#pragma pack(1)
typedef struct _sBtCmdF2h_t
{
	nBtPMCmdStatus_t tnBtStatus;
	u8_t u8CntdownTimer;
} sBtCmdF2h_t;
#pragma pack( )
//----------------------------------------------
#pragma pack(1)
typedef struct _sBtCmdF3h_t
{
	u32_t u32StartAddr;
	u32_t u32EndAddr;
} sBtCmdF3h_t;
#pragma pack( )
//----------------------------------------------
#pragma pack(1)
typedef struct _sBtCmdF4h_t
{
	u32_t u32StartAddr;
	u8_t pu8Data[64];
} sBtCmdF4h_t;
#pragma pack( )
//----------------------------------------------
#pragma pack(1)
typedef struct _sBtCmdF5h_t
{
	nBtPMCmdStatus_t tnBtStatus;
} sBtCmdF5h_t;
#pragma pack( )
//----------------------------------------------
#pragma pack(1)
typedef struct _sBtCmdF6h_t
{
	nBtPMCmdStatus_t tnBtStatus;
} sBtCmdF6h_t;
#pragma pack( )
//----------------------------------------------
#pragma pack(1)
typedef struct _sBtCmdF7h_t
{
	nBtPMCmdStatus_t tnBtStatus;
	u32_t u32TotalBytes;
	u16_t u16FileCrc16;
} sBtCmdF7h_t;
#pragma pack( )
//----------------------------------------------
typedef struct _sBbuBtCmd_t
{
	u8_t u8DummyCurrPage;
	sBtCmdF0h_t tsBtCmdF0h;	//command F0h
	sBtCmdF1h_t tsBtCmdF1h;	//command F1h
	sBtCmdF2h_t tsBtCmdF2h;	//command F2h
	sBtCmdF3h_t tsBtCmdF3h;	//command F3h
	sBtCmdF4h_t tsBtCmdF4h;	//command F4h
	sBtCmdF5h_t tsBtCmdF5h;	//command F5h
	sBtCmdF6h_t tsBtCmdF6h;	//command F6h
	sBtCmdF7h_t tsBtCmdF7h;	//command F7h


} sBbuBtCmd_t;
extern sBbuBtCmd_t tsBbuBt_Dev;

#if (BAIDU_BT)
extern u8_t u8DummyRdBtStatus;
#endif

/****************************************************************************
*   Declared Export functions
****************************************************************************/
extern sPMBusCmdStr_t sBbuPMBusROCmd_STA[BBU_PMBUS_RO_STA_NUM];
extern sPMBusCmdStr_t sBbuPMBusROCmd_MST[BBU_PMBUS_RO_MST_NUM];
extern sPMBusCmdStr_t sBbuPMBusROCmd_INF[BBU_PMBUS_RO_INF_NUM];
extern sPMBusCmdStr_t sBbuPMBusROCmd_MFC[BBU_PMBUS_RO_MFC_NUM];
extern sPMBusCmdStr_t sBbuPMBusRWCmd_CFG[BBU_PMBUS_RW_CFG_NUM];
extern sPMBusCmdStr_t sBbuPMBusWOCmd_CTR[BBU_PMBUS_WO_CTR_NUM];

extern sPMBusCmdStr_t sBbuPMBusROCmd[BBU_PMBUS_RO_NUM];
extern sPMBusCmdStr_t sBbuPMBusWOCmd[BBU_PMBUS_WO_NUM];
extern sPMBusCmdStr_t sBbuPMBusRWCmd[BBU_PMBUS_RW_NUM];

extern sPMBusCmdStr_t sBbsPMBusROCmd[BBS_PMBUS_RO_NUM];
extern sPMBusCmdStr_t sBbsPMBusWOCmd[BBS_PMBUS_WO_NUM];
extern sPMBusCmdStr_t sBbsPMBusRWCmd[BBS_PMBUS_RW_NUM];

#if (BAIDU_BT)
extern sPMBusCmdStr_t sBbsBtPMBusROCmd[BBS_BT_PMBUS_RO_NUM];
extern sPMBusCmdStr_t sBbsBtPMBusWOCmd[BBS_BT_PMBUS_WO_NUM];
extern sPMBusCmdStr_t sBbsBtPMBusRWCmd[BBS_BT_PMBUS_RW_NUM];
#endif

#if(LITEON_BT)
extern sPMBusCmdStr_t sBbuBLPMBusROCmd[BBU_BL_PMBUS_RO_NUM];
extern sPMBusCmdStr_t sBbuBLPMBusWOCmd[BBU_BL_PMBUS_WO_NUM];
extern sPMBusCmdStr_t sBbuBLPMBusRWCmd[BBU_BL_PMBUS_RW_NUM];
extern sPMBusCmdStr_t sBbuBLPMBusRWDummyCmd[BBU_BL_PMBUS_RW_DUMMY_NUM];
#endif

#if (BAIDU_BT)
extern sPMBusCmdStr_t sBbuPMBusROCmd_BT_STA[BBU_PMBUS_RO_BT_STA_NUM];
extern sPMBusCmdStr_t sBbuPMBusROCmd_BT_DUMMY[BBU_BL_PMBUS_RO_DUMMY_NUM];
#endif
#endif /* PMBUSDATA_H_ */
