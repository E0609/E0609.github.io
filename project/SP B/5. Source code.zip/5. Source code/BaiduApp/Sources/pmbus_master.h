/****************************************************************************
*	file	pmbus_master.h
*	brief	The file includes subroutines for 24LCxxx
*
*	author allen.lee
* 	version 1.0
*		-	2014/04/21: initial version by allen lee
*
****************************************************************************/

#ifndef PMBUS_MASTER_H_
#define PMBUS_MASTER_H_

#include "SysTime.h"
/****************************************************************************
*   Declared Macro
****************************************************************************/
#define PMBUS_MAX_PAYLOAD		(64)//(250)
#define MASTER_PMBUS_TIMEOUT    (4)	//10msx4

#define MasterPMBusTimeOut10ms          gtMcuTimer.u8Sys10ms
/****************************************************************************
*   Declared Export functions
****************************************************************************/
extern bool MstPMBusTimeout(uint32_t u32instance);

extern bool MstPMBusWriteNbyte(u32_t instance, u16_t u16Addr, u8_t * pu8cmdBuff, u8_t * pu8txBuff, u8_t u32txSize);

extern bool MstPMBusBlockWrite(u32_t instance, u16_t u16Addr, u8_t * pu8cmdBuff, u8_t * pu8txBuff, u8_t* pu8txSize);

extern bool MstPMBusReadNbyte(u32_t instance, u16_t u16Addr, u8_t * pu8cmdBuff, u8_t * pu8rxBuff, u8_t u8rxSize);

extern bool MstPMBusBlockRead(u32_t instance, u16_t u16Addr, u8_t * pu8cmdBuff, u8_t * pu8rxBuff, u8_t u8rxSize);

extern bool MstPMBusProcessCall(u32_t instance, u16_t u16Addr, u8_t * pu8cmdBuff,
		u8_t * pu8txBuff, u8_t u8txSize, u8_t * pu8rxBuff, u8_t u8rxSize);

extern bool MstPMBusBlockProcessCall(u32_t instance, u16_t u16Addr, u8_t * pu8cmdBuff,
		u8_t * pu8txBuff, u8_t* u8txSize, u8_t * pu8rxBuff, u8_t u8rxSize);

#endif /* PMBUS_MASTER_H_ */
