/*******************************************************************************
* file				define.h
* brief				The file includes the function and data structure/variables
*					for this model
* note
* author			vincent.liu
* version
* section History
*******************************************************************************/
#ifndef DEFINE_H_
#define DEFINE_H_


/*******************************************************************************
* declare compile condition
*******************************************************************************/

/*******************************************************************************
* declare macro
*******************************************************************************/
//=====================================
// nop
//=====================================
#define Nop()\
	__asm( "NOP");
/*******************************************************************************
* re-define data format
*******************************************************************************/
typedef unsigned char		u8_t;			/* 8  bit unsigned data */
typedef unsigned short int  u16_t;			/* 16 bit unsigned data */
typedef unsigned long int   u32_t;			/* 32 bit unsigned data */
typedef unsigned long long  u64_t;			/* 64 bit unsigned data */
typedef signed char			i8_t;			/* 8  bit signed data */
typedef signed short int    i16_t;			/* 16 bit signed data */
typedef signed long int	    i32_t;			/* 32 bit signed data */
typedef signed long long  	i64_t;			/* 64 bit signed data */
typedef void            	(*funcPtr)();
/*******************************************************************************
* end of file
*******************************************************************************/


#endif /* DEFINE_H_ */


