/****************************************************************************
*	file	pit_timer.c
*	brief
*
*	author allen.lee
* 	version 1.0
*		-	2014/05/05: initial version by allen lee
*
****************************************************************************/
#include "board.h"
#include "fsl_device_registers.h"
#include "fsl_clock_manager.h"
#include "fsl_interrupt_manager.h"
#include "fsl_pit_hal.h"
#include "pit.h"
#include "E2pI2cPitApp.h"

/****************************************************************************
*   Declared Macro
****************************************************************************/
#define BSC_PIT0_PRIOR_LEVEL		(3)

/****************************************************************************
 * Global Variables
 ****************************************************************************/
/* Table of base addresses for pit instances. */
const uint32_t g_pitBaseAddr[] = PIT_BASE_ADDRS;

/* Table to save PIT IRQ enum numbers defined in CMSIS files. */
const IRQn_Type g_pitIrqId[] = PIT_IRQS;

uint64_t g_pitSourceClock;


/****************************************************************************
*	name        : pit0_irq_handler
*	description :
*	return      : none
****************************************************************************/
void pit0_irq_handler(uint32_t instance)
{
	assert(instance < HW_PIT_INSTANCE_COUNT);

	uint32_t baseAddr = g_pitBaseAddr[instance];

//	if (PIT_HAL_IsIntPending(baseAddr, instance))
//	{
	//Clear interrupt flag
	PIT_HAL_ClearIntFlag(baseAddr, instance);
	if (i2cbb_master_Ismode() == kbbmode_write)
	{
		i2cbb_wr_irq_statemachine();
	}
	else if (i2cbb_master_Ismode() == kbbmode_read)
	{
		i2cbb_rd_irq_statemachine();
	}
	else
	{

	}
	//TURN_TGL_MTEST();


//	}
	/*if (PIT_HAL_IsIntPending(baseAddr, instance))
	{
		//Clear interrupt flag
		PIT_HAL_ClearIntFlag(baseAddr, instance);
	}*/
}
/****************************************************************************
*	name        : PIT_IRQHandler
*	description : Implementation of PIT handler named in startup code
*	return      : none
****************************************************************************/
void PIT_IRQHandler(void)
{
	pit0_irq_handler(HW_PIT);
}

/****************************************************************************
*	name        : Start_PitTimer
*	description :
*	return      : none
****************************************************************************/
void Start_PitTimer(uint32_t instance)
{
	assert(instance < HW_PIT_INSTANCE_COUNT);

	uint32_t baseAddr = g_pitBaseAddr[instance];

	PIT_HAL_StartTimer(baseAddr, instance);
}
/****************************************************************************
*	name        : Stop_PitTimer
*	description :
*	return      : none
****************************************************************************/
void Stop_PitTimer(uint32_t instance)
{
	assert(instance < HW_PIT_INSTANCE_COUNT);

	uint32_t baseAddr = g_pitBaseAddr[instance];

	PIT_HAL_StopTimer(baseAddr, instance);
}
/****************************************************************************
*	name        : Init_PitTimer
*	description :
*	return      : none
****************************************************************************/
void Init_PitTimer(uint32_t instance)
{
    // Structure of initialize PIT channel No.0
	/*pit_user_config_t chn0Confg = {
        .isInterruptEnabled = true,
        .isTimerChained = false,
        .periodUs = 500
    };*/

    // Structure of initialize PIT channel No.1
 /*   pit_user_config_t chn1Confg = {
        .isInterruptEnabled = true,
        .isTimerChained = false,
        .periodUs = 2000000u
    };
    */
	assert(instance < HW_PIT_INSTANCE_COUNT);

	uint32_t baseAddr = g_pitBaseAddr[instance];

	/* Un-gate pit clock*/
	CLOCK_SYS_EnablePitClock(instance);

    /* Enable PIT module clock*/
    PIT_HAL_Enable(baseAddr);

    /* Set timer run or stop in debug mode*/
    PIT_HAL_SetTimerRunInDebugCmd(baseAddr, true);

    /* Finally, update pit source clock frequency.*/
    g_pitSourceClock = CLOCK_SYS_GetPitFreq(instance);

    /* Set timer period.*/
    uint32_t us = E2P_PIT0_PERIOD_T;	//periodUs
    uint32_t count = (uint32_t)(us * g_pitSourceClock / 1000000U - 1U);
	PIT_HAL_SetTimerPeriodByCount(baseAddr, instance, count);
	/* Configure timer chained or not.*/
	PIT_HAL_SetTimerChainCmd(baseAddr, instance, 0);	//isTimerChained

    /* Enable interrupt.*/
    PIT_HAL_SetIntCmd(baseAddr, instance, true);

    /* Set interrupt priority */
    NVIC_SetPriority(g_pitIrqId[instance], BSC_PIT0_PRIOR_LEVEL);

    /* Enable PIT interrupt.*/
    INT_SYS_EnableIRQ(g_pitIrqId[instance]);

    //PIT_HAL_StartTimer(baseAddr, instance);


}

