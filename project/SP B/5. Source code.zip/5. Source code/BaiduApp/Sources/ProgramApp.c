/****************************************************************************
*	file        : ProgramApp.c
*   description : bootloader program
*   author      : Allen Lee
*   version     : 1.0
                  -   2014/03/31: initial version by Allen Lee
****************************************************************************/
#include "fsl_device_registers.h"
#include "hwtimer.h"
#include "ProgramApp.h"
#include "ProgramBlock.h"
#include "board.h"
#include "i2c_master.h"
#include "i2c_slave.h"
#include "usb_hid_device.h"
#include "pmbus_linearformat.h"
#include "macro_define.h"

#if (LITEON_BT)
//----------------------------------------------------------------------------
typedef union _nEntryBoot
{
   struct
   {
        u8_t   u1jumptoboot	:1;
        u8_t   u7NA			:7;
   } u8Bit;

   u8_t u8All;
} nEntryBoot_t;

nEntryBoot_t nEntryBoot;
//----------------------------------------------
static u8_t u8EntryBootTime10ms;
static u8_t u8BootEntryWaitCnt;
//----------------------------------------------------------------------------
typedef union _nbtstatus_t
{
	struct
	{
		u16_t u1CodeIdError		:1;
		u16_t u1EntBootPWDError	:1;
		u16_t u1FileCRCError	:1;
		u16_t u1NA1             :1;
		u16_t u1AddressError	:1;
		u16_t u1EraseError		:1;
		u16_t u1ProgramError	:1;
		u16_t u1NA2				:1;

		u16_t u6NA3				:6;
		u16_t u1Busy			:1;
		u16_t u1OperationMode	:1; // App-0;, Boot-1

	}u16Bit;

	u16_t u16All;
}nbtstatus_t;
//----------------------------------------------
#pragma pack(1)
typedef struct _sbt_packet_t {
	u8_t u8RecCmd;
	u8_t u8RecBytecnt;
	u8_t u8DevType;
	u8_t u8McuType;
	u8_t u8ModuleId;

	nbtstatus_t status;


	u16_t u16ExistModule;
	u32_t u32EnterBtPwd;
	u8_t u8CntdownTimer;

} sbt_packet_t;
#pragma pack()
sbt_packet_t tsbt_packet;

/****************************************************************************
*	name        : check_packeterror_flag
*	description :
*	return      :
****************************************************************************/
bool check_packeterror_flag(void)
{
	if(tsbt_packet.status.u16All & 0x00ff)
	{
		return false;
	}

    return true;
}
/****************************************************************************
*	name        : init_interrupts
*	description :
*	return      :
****************************************************************************/
void init_interrupts(void)
{
    // Clear any IRQs that may be enabled, we only want the IRQs we enable to be active
    NVIC_ClearEnabledIRQs();

    // Clear any pending IRQs that may have been set
    NVIC_ClearAllPendingIRQs();
}
/****************************************************************************
*	name        : jump_to_user_address_handler
*	description :
*	return      :
****************************************************************************/
void jump_to_user_address_handler(u32_t u32address, u32_t u32spointer)
{
	//disable all interrupt
	__disable_irq();

	init_interrupts();

	// De-initialize hardware such as disabling port clock gate
	DeInit_Usb();
	hardware_deinit();
	DeInit_SysTick();
	DeInit_MasterI2c(HW_I2C1);
#if (I2C_SLAVE_MASK)
	DeInit_SlaveI2c(HW_I2C0);
#endif

	static u32_t u32stackPointer = 0;
	u32stackPointer = u32spointer;
	static void (*farewellpresentmode)(void) = 0;
	farewellpresentmode = (void (*)(void))u32address;

    // Set stack pointers to the application stack pointer.
    __set_MSP(u32stackPointer);
    // Jump to the application.
    farewellpresentmode();

}
/****************************************************************************
*	name        : jump_to_bootloader_handler
*	description :
*	return      :
****************************************************************************/
#if 0
void jump_to_bootloader_handler(void)
{
	//disable all interrupt
	__disable_irq();

	init_interrupts();

	// De-initialize hardware such as disabling port clock gate
	DeInit_Usb();
	hardware_deinit();
	DeInit_SysTick();
	DeInit_MasterI2c(HW_I2C1);
#if (I2C_SLAVE_MASK)
	DeInit_SlaveI2c(HW_I2C0);
#endif

    // Set stack pointers to the application stack pointer.
    __set_MSP(*(__IO u32_t *)BOOT_FLASH_START_ADDRESS);
    // Jump to the application.
    __IO u32_t  *pu32StartVector;
    pu32StartVector = (__IO u32_t *)(BOOT_FLASH_START_VECTOR);
    ((void (*)(void)) (*(pu32StartVector)))();
    //((void (*)(void)) (BOOT_FLASH_ENTRY_ADDRESS))();


#if 0
    static uint32_t s_stackPointer = 0;
    static void (*farewellUserApplication)(void) = 0;
    s_stackPointer = *(u32_t *)BOOT_FLASH_START_ADDRESS;
    farewellUserApplication = (void (*)(void))BOOT_FLASH_START_VECTOR;
    // Set stack pointers to the application stack pointer.
    __set_MSP(s_stackPointer);
    // Jump to the application.
    farewellUserApplication();
#endif
}
#endif
/****************************************************************************
*	name        : EntryBootloaderProcess
*	description :
*	return      :
****************************************************************************/
void EntryBootloaderProcess(void)
{
	if(u8EntryBootTime10ms != EntryBoot_Time10ms)
	{
		u8EntryBootTime10ms = EntryBoot_Time10ms;

		if(nEntryBoot.u8Bit.u1jumptoboot)
		{
			if (u8BootEntryWaitCnt < 10)    // wait 100msec entry boot mode
			{
				u8BootEntryWaitCnt += 1;
			}
			else
			{
				//TURN_TGL_MTEST();
				SetEnteryBootKeytoRam(MAGIC_APP_KEY);

				u32_t u32bootEntry = 0;
				u32_t u32bootStack = 0;

				u32bootStack = *(u32_t *)BOOT_FLASH_START_ADDRESS;
				u32bootEntry = *(u32_t *)(BOOT_FLASH_START_VECTOR);
				jump_to_user_address_handler(u32bootEntry, u32bootStack);
			}
		}

	}
}
/****************************************************************************
*	name        : Init_Bootloader
*	description :
*	return      :
****************************************************************************/
void Init_Bootloader(void)
{
	nEntryBoot.u8All = 0;
	u8BootEntryWaitCnt = 0;

	tsbt_packet.status.u16All = 0x0001;
	tsbt_packet.u16ExistModule = 0x0001;
	tsbt_packet.u32EnterBtPwd = 0x7B3A6CC0;
	tsbt_packet.u8CntdownTimer = 5;
}
/****************************************************************************
*	name        : UsbBootComRxProcess
*	description :
*	return      :
****************************************************************************/
u8_t UsbBootBWrBrdProcCallComRxProcess(u8_t* pu8buff, u8_t* pu8len)
{
	tsbt_packet.u8RecCmd = pu8buff[2];
	tsbt_packet.u8RecBytecnt = pu8buff[3];
	tsbt_packet.u8DevType = pu8buff[5];
	tsbt_packet.u8McuType = pu8buff[6];
	tsbt_packet.u8ModuleId = pu8buff[7];

	if ((tsbt_packet.u8DevType != DEVICE_TYPE) || (tsbt_packet.u8McuType != PROCESSOR_TYPE))
	{
		*pu8len = 0;
		return(UsbPkt_Status_Fail);
	}

	switch(tsbt_packet.u8RecCmd)
	{
		case PMBusCmd_RdCodeID:
			if(tsbt_packet.u8RecBytecnt == 15)
			{
				if(memcmp(&pu8buff[8], &tsProgamInfoBlock.pu8CodeID[0], 12) == 0)
				{
					tsbt_packet.status.u16Bit.u1CodeIdError = 0;
				}
				else
				{
					tsbt_packet.status.u16Bit.u1CodeIdError = 1;
				}
				memcpy(&pu8buff[3], (u8_t*)&tsbt_packet.status.u16All, 2);
				memcpy(&pu8buff[5], &tsProgamInfoBlock.pu8CodeID[0], 12);
				*pu8len = 14;
				return(UsbPkt_Status_Success);
			}
			break;
		case PMBusCmd_RdMcuType:
			if(tsbt_packet.u8RecBytecnt == 3)
			{
				memcpy(&pu8buff[3], (u8_t*)&tsbt_packet.u16ExistModule, 2);
				memcpy(&pu8buff[5], (u8_t*)&tsbt_packet.status.u16All, 2);
				*pu8len = 4;
				return(UsbPkt_Status_Success);
			}
			break;
		case PMBusCmd_EnterBootMode:
			if((tsbt_packet.u8RecBytecnt == 7) && (tsbt_packet.u8ModuleId == 1))
			{
				if(check_packeterror_flag() == true)
				{
					if(memcmp(&pu8buff[8], (u8_t*)&tsbt_packet.u32EnterBtPwd, 4) == 0)
					{
						tsbt_packet.status.u16Bit.u1EntBootPWDError = 0;
						nEntryBoot.u8Bit.u1jumptoboot = 1;
						u8BootEntryWaitCnt = 0;
					}
					else
					{
						tsbt_packet.status.u16Bit.u1EntBootPWDError = 1;
					}
				}

				memcpy(&pu8buff[3], (u8_t*)&tsbt_packet.status.u16All, 2);
				memcpy(&pu8buff[5], (u8_t*)&tsbt_packet.u8CntdownTimer, 1);

				*pu8len = 3;
				return(UsbPkt_Status_Success);
			}
			break;
		case PMBusCmd_RdStatus:
			if((tsbt_packet.u8RecBytecnt == 3) && (tsbt_packet.u8ModuleId == 1))
			{
				memcpy(&pu8buff[3], (u8_t*)&tsbt_packet.status.u16All, 2);
				*pu8len = 2;
				return(UsbPkt_Status_Success);
			}
			break;
		default:

			break;

	}
	*pu8len = 0;
	return(UsbPkt_Status_Fail);
}
#endif /* LITEON_BT */
