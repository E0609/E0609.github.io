/****************************************************************************
*	file	I2C.c
*	brief	I2C master driver
*
*	author allen.lee
* 	version 1.0
*		-	2014/05/05: initial version by allen lee
*
****************************************************************************/
#include <string.h>
#include <stdio.h>
#include "board.h"
#include "fsl_clock_manager.h"
#include "fsl_interrupt_manager.h"
#include "i2c_master.h"
#include "i2c_irq.h"
#include "fsl_debug_console.h"
#include "bbu_ctrl.h"
#include "crc8.h"
/****************************************************************************
 * Global Variables
 ****************************************************************************/
#define BSC_I2C1_PRIOR_LEVEL                (3)

static si2c_master_t tsi2c_master;

#ifdef I2C_MASTER_DEBUG
u8_t master_cmdBuff[2] = {0x10, 0x20};
u16_t master_sendaddress = 0xa6>>1U;
u8_t master_sendBuff[64];
u8_t master_senddata[8];
u8_t master_receiveBuff[64];

u8_t addrBuff[2] = {0};
u32_t master_dataerror = 0;
u32_t master_crcerror = 0;
#endif
/*FUNCTION**********************************************************************
 *
 * Function Name : i2c_hal_setGlitchWidth
 * Description   :
 *
 *END**************************************************************************/
static void i2c_hal_setGlitchWidth(uint32_t u32baseAddr, uint8_t u8glitchWidth)
{
    assert(u8glitchWidth < 16);
    BW_I2C_FLT_FLT(u32baseAddr, u8glitchWidth);
}

/****************************************************************************
*	name        : i2c_completetransfer
*	description : Send STOP and disable interrupt when error happens or finish
*                 I2C transfers
*	return      : none
****************************************************************************/
static void i2c_completetransfer(u32_t u32instance)
{
	assert(u32instance < HW_I2C_INSTANCE_COUNT);

    u32_t u32baseAddr = gl_i2cBaseAddr[u32instance];
    si2c_master_t * tsmaster = (si2c_master_t *)gl_i2cStatePtr[u32instance];

	/* Disable interrupt. */
#ifndef I2C_MASTER_SSIE_ENABLE
    I2C_HAL_SetIntCmd(u32baseAddr, false);
#endif
	/* Generate stop signal. */
    if(I2C_HAL_SendStop(u32baseAddr) == kStatus_I2C_Success)
    {
    	/* Indicate I2C bus is idle. */
    	tsmaster->i2cIdle = true;
    	tsmaster->u32timeout_ms = 0;
    }
    else
    {
    	//TURN_TGL_BBS_ON();//test
    }
}
/****************************************************************************
*	name        : i2c_master_irq_handler
*	description : Implementation of I2C2 handler named in startup code
*	return      : none
****************************************************************************/
void i2c_master_irq_handler(u32_t u32instance)
{
	assert(u32instance < HW_I2C_INSTANCE_COUNT);

	u8_t u8dummy_read, u8data_read, u8saddr_index;
	u32_t u32baseAddr = gl_i2cBaseAddr[u32instance];

    /* Get current runtime structure */
    si2c_master_t * tsmaster = (si2c_master_t *)gl_i2cStatePtr[u32instance];

    /* Get current master transfer direction */
    i2c_direction_t direction = I2C_HAL_GetDirMode(u32baseAddr);

#ifdef I2C_MASTER_SSIE_ENABLE
	bool     stopIntEnabled = false;
    bool     startDetected = I2C_HAL_GetStartFlag(u32baseAddr);
    bool     startIntEnabled = I2C_HAL_GetStartStopIntCmd(u32baseAddr);
    bool     stopDetected = I2C_HAL_GetStopFlag(u32baseAddr);
    stopIntEnabled = startIntEnabled;
#endif

#ifdef I2C_MASTER_DEBUG
    //GPIO_DRV_TogglePinOutput(kGpioLED1);
#endif
    /*--------------- Handle START ------------------*/
#ifdef I2C_MASTER_SSIE_ENABLE
    if (startIntEnabled && startDetected)
    {
        I2C_HAL_ClearStartFlag(u32baseAddr);
        I2C_HAL_ClearInt(u32baseAddr);

        return;
    }
    /*--------------- Handle STOP ------------------*/
    if (stopIntEnabled && stopDetected)
    {
        I2C_HAL_ClearStopFlag(u32baseAddr);
        I2C_HAL_ClearInt(u32baseAddr);

    	/* Disable interrupt. */
        I2C_HAL_SetIntCmd(u32baseAddr, false);

        return;
    }
#endif

    /*------ Handle ARBL flag in master mode--------*/
#ifdef I2C_MASTER_ARBL
    bool  wasArbLost = I2C_HAL_GetStatusFlag(u32baseAddr, kI2CArbitrationLost);

    if (wasArbLost)
    {
    	tsmaster->status = kStatus_I2C_AribtrationLost;

    	I2C_HAL_ClearArbitrationLost(u32baseAddr);
    	I2C_HAL_ClearInt(u32baseAddr);

    	/* Disable interrupt. */
        //I2C_HAL_SetIntCmd(u32baseAddr, false);
        return;
    }
#endif

    /* Clear the interrupt flag*/
    I2C_HAL_ClearInt(u32baseAddr);

    /* Exit immediately if there is no transfer in progress OR not in master mode */
    if ((!I2C_HAL_GetStatusFlag(u32baseAddr, kI2CBusBusy)) ||
        (!I2C_HAL_IsMaster(u32baseAddr)))
    {
        return;
    }

    /* Handle send */
    if (direction == kI2CSend)
    {
        /* Check whether we got an ACK or NAK from the former byte we sent */
        if (I2C_HAL_GetStatusFlag(u32baseAddr, kI2CReceivedNak))
        {

            /* Got a NAK, so we're done with this transfer */
        	i2c_completetransfer(u32instance);

            /* Record that we got a NAK */
        	tsmaster->status = kStatus_I2C_ReceivedNak;
        }
        else
        {
        	if (tsmaster->u8Mode != MASTER_I2C_RX)
        	{
				if (tsmaster->u32SaddrSize > 0)
				{
					tsmaster->u32SaddrSize -= 1;
					u8saddr_index = (I2C_ADDRESS_SIZE - 1) - (tsmaster->u32SaddrSize);
					I2C_HAL_WriteByte(u32baseAddr, tsmaster->pu8SaddrBuff[u8saddr_index]);
				}
				else if (tsmaster->u32CmdSize > 0)
				{
					tsmaster->u32CmdSize -= 1;
					I2C_HAL_WriteByte(u32baseAddr, *(tsmaster->pu8CmdBuff));
					tsmaster->pu8CmdBuff ++;
				}
				else if (tsmaster->u32TxSize > 0)
				{
					tsmaster->u32TxSize -= 1;
					I2C_HAL_WriteByte(u32baseAddr, *(tsmaster->pu8TxBuff));
					tsmaster->pu8TxBuff++;
				}
				else
				{
					if (tsmaster->u8Mode == MASTER_I2C_TXRX)
					{
						/* Need to generate a repeat start before changing to receive. */
						tsmaster->u8Mode = MASTER_I2C_RX;
						I2C_HAL_SendStart(u32baseAddr);

						/* Send address byte 1 again. */
						I2C_HAL_WriteByte(u32baseAddr, (tsmaster->pu8SaddrBuff[0] | 1U));
					}
					else
					{
						/* Finish send data, send STOP, disable interrupt */
						i2c_completetransfer(u32instance);
					}
				}
        	}
        	else
        	{

        		I2C_HAL_SetDirMode(u32baseAddr, kI2CReceive);

        		u8dummy_read = I2C_HAL_ReadByte(u32baseAddr);
        		I2C_HAL_GetDirMode(u32baseAddr);
        		//__asm("nop");
        		//__asm("nop");
        		if (tsmaster->rxSize == 1)
        		{
        			I2C_HAL_SendNak(u32baseAddr);
        		}
        		else
        		{
        			I2C_HAL_SendAck(u32baseAddr);
        		}
        	}
        }
    }
    else /* Handle receive */
    {
        if ((tsmaster->rxSize) == 1)
        {
        	//Master RX mode: All data received, send STOP
        	i2c_completetransfer(u32instance);
        }
        else
        {
        	//Master RX mode: Second-to-last byte received, set TXAK.
        	if ((tsmaster->rxSize) == 2)
        	{
        		I2C_HAL_SendNak(u32baseAddr);
        	}
        }

        /* Read recently received byte into buffer and update buffer index */
        tsmaster->rxSize -= 1;
        u8data_read = I2C_HAL_ReadByte(u32baseAddr);

        if ((tsmaster->ePMBusProtcol == Block_ReadNbyte) ||  (tsmaster->ePMBusProtcol == Block_ProcessCall))
		{
            if (tsmaster->tnPMBusSt.u8Bit.u1ReadByteCnt == 0)
            {
            	tsmaster->tnPMBusSt.u8Bit.u1ReadByteCnt = 1;
            	if ((u8data_read == 0) || (u8data_read >= tsmaster->rxSize))
            	{
            		u8data_read = 2;
            		tsmaster->rxSize = u8data_read;

            	}
            	else
            	{
            		tsmaster->rxSize = u8data_read;
            		if (tsmaster->tnPMBusSt.u8Bit.u1PECSupport)
            		{
            			tsmaster->rxSize += 1;
            		}
            	}
            }

		}
        *(tsmaster->rxBuff++) = u8data_read;
    }
}



/****************************************************************************
*	name        : i2c_master_sendaddress
*	description : Prepare and send out address buffer with interrupt.
*	return      : none
****************************************************************************/
static void i2c_master_sendaddress(uint32_t u32instance, uint16_t u16address, i2c_direction_t direction)

{
	assert(u32instance < HW_I2C_INSTANCE_COUNT);

	u32_t u32baseAddr = gl_i2cBaseAddr[u32instance];
    /* Get current runtime structure. */
	si2c_master_t * master = (si2c_master_t *)gl_i2cStatePtr[u32instance];

    u8_t addrByte1, addrByte2, directionBit;
    bool is10bitAddr;
    u8_t addrSize = 0;

    /*--------------- Prepare Address Buffer ------------------*/
    /* Get r/w bit according to required direction.
     * read is 1, write is 0. */
    directionBit = (direction == kI2CReceive) ? 0x1U : 0x0U;

    /* Check to see if slave address is 10 bits or not. */
    is10bitAddr = ((u16address >> 10U) == 0x1EU) ? true : false;

    /* Get address byte 1 and byte 2 according address bit number. */
    if (is10bitAddr)
    {
        addrByte1 = (uint8_t)(u16address >> 8U);
        addrByte2 = (uint8_t)u16address;
    }
    else
    {
        addrByte1 = (uint8_t)u16address;
    }

    /* Get the device address with r/w direction. If we have a sub-address,
      then that is always done as a write transfer prior to transferring
      the actual data.*/
    addrByte1 = addrByte1 << 1U;

    /* First need to write if 10-bit address or has cmd buffer. */
    addrByte1 |= (uint8_t)((is10bitAddr) ? 0U : directionBit);

    /* Put slave address byte 1 into address buffer. */
    master->pu8SaddrBuff[addrSize++] = addrByte1;

    if (is10bitAddr)
    {
        /* Put address byte 2 into address buffer. */
    	master->pu8SaddrBuff[addrSize++] = addrByte2;
    }
    /*--------------- Send Address Buffer ------------------*/
    master->u32SaddrSize = addrSize;

    /* Send first byte in address buffer to trigger interrupt.*/
    master->u32SaddrSize -= 1;
    I2C_HAL_WriteByte(u32baseAddr, master->pu8SaddrBuff[0]);
}
/****************************************************************************
*	name        : MasterI2cBustimeout
*	description :
*	return      : none
****************************************************************************/
i2c_status_t MasterI2cBustimeout(uint32_t u32instance, uint32_t u32timeout_ms)
{
	assert(u32instance < HW_I2C_INSTANCE_COUNT);

	u32_t u32baseAddr = gl_i2cBaseAddr[u32instance];
	si2c_master_t * master = (si2c_master_t *)gl_i2cStatePtr[u32instance];

	/*if current instance is used */
	if (!master->i2cIdle)
	{
		master->u32timeout_ms += 1;

		if ((master->u32timeout_ms) > u32timeout_ms)
		{
			master->status = kStatus_I2C_Timeout;
		}
	}

	return master->status;
}
/****************************************************************************
*	name        : MasterI2cSend
*	description : Private function to handle send.
*	return      : none
****************************************************************************/
bool MasterI2cSend(u32_t u32instance, u16_t u16address, u8_t * pu8cmdBuff, u32_t u32cmdSize, u8_t * pu8txBuff, u32_t u32txSize)
{
	assert(u32instance < HW_I2C_INSTANCE_COUNT);
	assert(pu8txBuff);

	u32_t baseAddr = gl_i2cBaseAddr[u32instance];
	si2c_master_t * master = (si2c_master_t *)gl_i2cStatePtr[u32instance];

    /* Return if current instance is used */
    if (!master->i2cIdle)
    {
    	return false;
        //return master->status = kStatus_I2C_Busy;
    }

    //if ((u32cmdSize == 0) && (u32txSize == 0))
    if (u32cmdSize == 0)
    {
    	return false;
    }

  //  master->saddrBuff = NULL;
    master->u32SaddrSize = 0;

    master->pu8CmdBuff = pu8cmdBuff;
    master->u32CmdSize = u32cmdSize;

    master->rxBuff = NULL;
    master->rxSize = 0;

    master->pu8TxBuff = pu8txBuff;
    master->u32TxSize = u32txSize;

    master->status = kStatus_I2C_Success;
    master->i2cIdle = false;
    master->u8Mode = MASTER_I2C_TX;

    /* Set direction to send for sending of address and data. */
    I2C_HAL_SetDirMode(baseAddr, kI2CSend);

    /* Enable i2c interrupt.*/
    I2C_HAL_ClearInt(baseAddr);
    I2C_HAL_SetIntCmd(baseAddr, true);

    /* Generate start signal. */
    I2C_HAL_SendStart(baseAddr);

    /* Send out slave address. */
    i2c_master_sendaddress(u32instance, u16address, kI2CSend);

    return true;
}

/****************************************************************************
*	name        : MasterI2cReStartReceive
*	description : Private function to handle restart receive.
*	return      : none
****************************************************************************/
bool MasterI2cReStartReceive(u32_t u32instance, u16_t u16address, u8_t * pu8cmdBuff, u32_t u32cmdSize,
								    u8_t * pu8txBuff, u32_t u32txSize, u8_t * pu8rxBuff, u32_t u32rxSize)
{
	assert(u32instance < HW_I2C_INSTANCE_COUNT);
	assert(pu8rxBuff);

	u32_t baseAddr = gl_i2cBaseAddr[u32instance];
	si2c_master_t * master = (si2c_master_t *)gl_i2cStatePtr[u32instance];

    /* Return if current instance is used */
    if (!master->i2cIdle)
    {
    	return false;
        //return master->status = kStatus_I2C_Busy;
    }

    if (u32rxSize == 0)
    {
    	return false;
    }

 //   master->saddrBuff = NULL;
    master->u32SaddrSize = 0;

    master->pu8CmdBuff = pu8cmdBuff;
    master->u32CmdSize = u32cmdSize;

    master->rxBuff = pu8rxBuff;
    master->rxSize = u32rxSize;

    master->pu8TxBuff = pu8txBuff;
    master->u32TxSize = u32txSize;

    master->status = kStatus_I2C_Success;
    master->i2cIdle = false;
    master->u8Mode = MASTER_I2C_TXRX;

    /* Set direction to send for sending of address. */
    I2C_HAL_SetDirMode(baseAddr, kI2CSend);

    /* Enable i2c interrupt.*/
    I2C_HAL_ClearInt(baseAddr);
    I2C_HAL_SetIntCmd(baseAddr, true);

    /* Generate start signal. */
    I2C_HAL_SendStart(baseAddr);

    /* Send out slave address. */
    i2c_master_sendaddress(u32instance, u16address, kI2CSend);

    return true;
}
/****************************************************************************
*	name        : GetMasterI2cIdleFlage
*	description :
*	return      : none
****************************************************************************/
bool GetMasterI2cIdleFlage(u32_t u32instance)
{
	assert(u32instance < HW_I2C_INSTANCE_COUNT);

	si2c_master_t * master = (si2c_master_t *)gl_i2cStatePtr[u32instance];

	return(master->i2cIdle);
}
/****************************************************************************
*	name        : GetMasterI2cPECSupportFlage
*	description :
*	return      : none
****************************************************************************/
bool GetMasterI2cPECSupportFlage(u32_t u32instance)
{
	assert(u32instance < HW_I2C_INSTANCE_COUNT);

	si2c_master_t * master = (si2c_master_t *)gl_i2cStatePtr[u32instance];

	if (master->tnPMBusSt.u8Bit.u1PECSupport)
	{
		return true;
	}
	else
	{
		return false;
	}
}
/****************************************************************************
*	name        : GetMasterI2cStatus
*	description :
*	return      : none
****************************************************************************/
i2c_status_t GetMasterI2cStatus(u32_t u32instance)
{
	assert(u32instance < HW_I2C_INSTANCE_COUNT);

	si2c_master_t * master = (si2c_master_t *)gl_i2cStatePtr[u32instance];

	return(master->status);
}
/****************************************************************************
*	name        : configure_i2c_bps
*	description : Initial I2Cx function
*	return      : none
****************************************************************************/
void configure_i2c_bps(u32_t u32instance)
{
	u32_t u32baudRate_kbps = 100;

	assert(u32instance < HW_I2C_INSTANCE_COUNT);
    u32_t u32baseAddr = gl_i2cBaseAddr[u32instance];

    u32_t u32i2cClockFreq;

    /* Get the current bus clock.*/
    u32i2cClockFreq = CLOCK_SYS_GetI2cFreq(u32instance);

    I2C_HAL_SetBaudRate(u32baseAddr, u32i2cClockFreq, u32baudRate_kbps, NULL);
}
/****************************************************************************
*	name        : configure_i2c_master
*	description : Initial I2Cx function
*	return      : none
****************************************************************************/
i2c_status_t configure_i2c_master(u32_t u32instance, si2c_master_t *tsmaster)
{
	assert(u32instance < HW_I2C_INSTANCE_COUNT);

	u32_t u32baseAddr = gl_i2cBaseAddr[u32instance];

    /* Exit if current instance is already initialized */
    if (gl_i2cStatePtr[u32instance])
    {
        return kStatus_I2C_Initialized;
    }

    /* Initialize driver instance struct */
    memset(tsmaster, 0, sizeof(si2c_master_t));

    /* Enable clock for I2C.*/
    CLOCK_SYS_EnableI2cClock(u32instance);

    /* Initialize peripheral to known state.*/
    I2C_HAL_Init(u32baseAddr);

//    I2C_HAL_SetHighDriveCmd(u32baseAddr, true);

    i2c_hal_setGlitchWidth(u32baseAddr, 15);	//    I2C_HAL_SetGlitchWidth(u32baseAddr, 15);

    /* Save runtime structure pointer */
    gl_i2cStatePtr[u32instance] = tsmaster;

    configure_i2c_bps(u32instance);

	#ifdef I2C_MASTER_SSIE_ENABLE
    I2C_HAL_SetStartStopIntCmd(u32baseAddr,true);
	#endif

    /* Indicate I2C bus is idle. */
    tsmaster->i2cIdle = true;

    /* Indicate I2C support PEC. */
    tsmaster->tnPMBusSt.u8Bit.u1PECSupport = PEC_SUPPORT;

    /* Set interrupt priority */
    NVIC_SetPriority(gl_i2cIrqId[u32instance], BSC_I2C1_PRIOR_LEVEL);

    /* Enable I2C interrupt in NVIC level.*/
    INT_SYS_EnableIRQ(gl_i2cIrqId[u32instance]);

    /* Enable module.*/
    I2C_HAL_Enable(u32baseAddr);

    return kStatus_I2C_Success;
}
/****************************************************************************
*	name        : Init_MasterI2c
*	description : Initial I2Cx function
*	return      : none
****************************************************************************/
void Init_MasterI2c(uint32_t u32instance)
{
	assert(u32instance < HW_I2C_INSTANCE_COUNT);

    // Configure I2C pins
    configure_i2c_pins(u32instance);

    // Init I2C module
    configure_i2c_master(u32instance, &tsi2c_master);

}
/****************************************************************************
*	name        : DeInit_MasterI2c
*	description : DeInitial I2Cx function
*	return      : none
****************************************************************************/
void DeInit_MasterI2c(u32_t u32instance)
{
	assert(u32instance < HW_I2C_INSTANCE_COUNT);

	u32_t u32baseAddr = gl_i2cBaseAddr[u32instance];
	si2c_master_t * master = (si2c_master_t *)gl_i2cStatePtr[u32instance];
	//TURN_TGL_MTEST();
    /* Exit if current instance is not already initialized */
    if (gl_i2cStatePtr[u32instance] == NULL)
    {
        return;
    }


	#ifdef I2C_MASTER_SSIE_ENABLE
	I2C_HAL_SetStartStopIntCmd(u32baseAddr,false);
	#endif

    /* Disable I2C interrupt. */
    I2C_HAL_SetIntCmd(u32baseAddr, false);

    /* Disable module.*/
    I2C_HAL_Disable(u32baseAddr);

    /* Disable clock for I2C.*/
    CLOCK_SYS_DisableI2cClock(u32instance);

    /* Disable I2C NVIC interrupt*/
    INT_SYS_DisableIRQ(gl_i2cIrqId[u32instance]);

    /* Cleared state pointer. */
    gl_i2cStatePtr[u32instance] = NULL;
}
/****************************************************************************
*	name        : Proc_I2C_Master_Test
*	description : test function
*	return      : none
****************************************************************************/
#ifdef I2C_MASTER_DEBUG
void Proc_I2C_Master_Test(u32_t instance)
{
	si2c_master_t * master = (si2c_master_t *)gl_i2cStatePtr[instance];

	static u8_t step = 0, half = 0;

	u8_t i, count, crc8;

	count = 3;
	OSA_TimeDelay(10);
	switch(step)
	{
		case 0:
			if (master->i2cIdle)
			{
				master_cmdBuff[0] = 0x10;
				master_sendBuff[0] = 0x00;

				crc8 = 0;
				CalCRC8(&crc8, (u8_t)master_sendaddress<<1U);
				CalCRC8(&crc8, master_cmdBuff[0]);
				CalCRC8(&crc8, master_sendBuff[0]);
				master_sendBuff[1] = crc8;

				MasterI2cSend(instance, master_sendaddress, master_cmdBuff, 1, master_sendBuff, 2);
				//MasterI2cSend(instance, master_sendaddress, master_cmdBuff, 2, master_sendBuff, count);
				step = 1;
			}
			break;
		case 1:
			if (master->i2cIdle)
			{
				master_cmdBuff[0] = 0x40;

				half = (half+1)%2;
				if(half)
				{
					master_senddata[0] = 0x4c;
					master_senddata[1] = 0x1b;
				}
				else
				{
					master_senddata[0] = 0x4F;
					master_senddata[1] = 0x1a;
				}

				crc8 = 0;
				CalCRC8(&crc8, (u8_t)master_sendaddress<<1U);
				CalCRC8(&crc8, master_cmdBuff[0]);
				CalCRC8(&crc8, master_senddata[0]);
				CalCRC8(&crc8, master_senddata[1]);
				master_senddata[2] = crc8;

				MasterI2cSend(instance, master_sendaddress, master_cmdBuff, 1, master_senddata, 3);
				//MasterI2cSend(instance, master_sendaddress, master_cmdBuff, 2, master_sendBuff, count);
				step = 2;
			}
			break;
		case 2:
			if (master->i2cIdle)
			{
				master_cmdBuff[0] = 0x10;
				master_sendBuff[0] = 0x80;

				crc8 = 0;
				CalCRC8(&crc8, (u8_t)master_sendaddress<<1U);
				CalCRC8(&crc8, master_cmdBuff[0]);
				CalCRC8(&crc8, master_sendBuff[0]);
				master_sendBuff[1] = crc8;

				MasterI2cSend(instance, master_sendaddress, master_cmdBuff, 1, master_sendBuff, 2);
				//MasterI2cSend(instance, master_sendaddress, master_cmdBuff, 2, master_sendBuff, count);
				step = 3;
			}
			break;
		case 3:
			if (master->i2cIdle)
			{
				OSA_TimeDelay(100);
				OSA_TimeDelay(100);
				//OSA_TimeDelay(100);
				//OSA_TimeDelay(100);
				//OSA_TimeDelay(100);
				//OSA_TimeDelay(100);
				//OSA_TimeDelay(100);
				//OSA_TimeDelay(100);
				//OSA_TimeDelay(100);
				//OSA_TimeDelay(100);
				//for(i=0;i<64;i++)
				//{
				//	master_receiveBuff[i] = 0;
				//}
				master_cmdBuff[0] = 0x40;
				master_receiveBuff[0] = 0xff;
				master_receiveBuff[1] = 0xff;
				master_receiveBuff[3] = 0xff;

				MasterI2cReStartReceive(instance, master_sendaddress, master_cmdBuff, 1, NULL, 0, master_receiveBuff, 3);
				//MasterI2cReStartReceive(instance, master_sendaddress, master_cmdBuff, 2, NULL, 0, master_receiveBuff, count);
				step = 4;
			}
			break;
		case 4:
			if (master->i2cIdle)
			{
				crc8 = 0;
				CalCRC8(&crc8, (u8_t)master_sendaddress<<1U);
				CalCRC8(&crc8, master_cmdBuff[0]);
				CalCRC8(&crc8, ((u8_t)master_sendaddress<<1U) | 0x01);
				CalCRC8(&crc8, master_receiveBuff[0]);
				CalCRC8(&crc8, master_receiveBuff[1]);

				if(crc8 == master_receiveBuff[2])
				{
					if ((master_senddata[0] == master_receiveBuff[0]) &&
							(master_senddata[1] == master_receiveBuff[1]))
					{
						step = 0;
						//TURN_H_LED_G();
					}
					else
					{
						step = 0;
						if(master_dataerror < 0xffffffff)
						{
							master_dataerror ++;
						}
						TURN_TGL_MTEST();
						TURN_L_LED_G();

					}
				}
				else
				{
					step = 0;
					if(master_crcerror < 0xffffffff)
					{
						master_crcerror ++;
					}
					TURN_TGL_MTEST();
					TURN_L_LED_G();

				}

			}
			break;

		default:
			if (master->i2cIdle)
			{
				//for (i = 0; i < count ; i++)
				//{
				//	if (master_sendBuff[i] != master_receiveBuff[i])
				//	{
				//		printf("Failure when comapre source and sink data .\n");
				//	}
				//}
				step = 0;
			}
			break;

	}
}
#endif	//I2C_MASTER_DEBUG
