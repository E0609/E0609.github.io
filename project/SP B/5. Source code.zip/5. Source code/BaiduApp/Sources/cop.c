/*
 * cop.c
 *
 *  Created on: 2015/6/1
 *      Author: AllenCCLee
 */
#include <stdio.h>
#include "cop.h"

#include "fsl_debug_console.h"



void Init_Cop(void)
{

	cop_user_config_t copInit =
	{
	        .copWindowModeEnable = (uint8_t)false,
	#if FSL_FEATURE_COP_HAS_LONGTIME_MODE
	        .copTimeoutMode      = kCopShortTimeoutMode,
	        .copStopModeEnable   = (uint8_t)false,
	        .copDebugModeEnable  = (uint8_t)false,
	#endif
	        .copClockSource      = kCopLpoClock,
	        // COP reset after about 1s.
	        .copTimeout          = kCopTimeout_short_2to10_or_long_2to18
	};

	// Init COP module.
	COP_DRV_Init(COP_INSTANCE, &copInit);

    // Check if WDOG reset occurred , turn off LED1, wait to press any key to continue.
 /*   if ((RCM->SRS0) & RCM_SRS0_WDOG_MASK)
    {
        PRINTF("\r\n COP reset the chip successfully\r\n");
    }
    // If WDOG reset is not occurred, enables COP.
    else
    {
        //Print a note.
        PRINTF("COP example begin.\r\n");
    }

*/

}
