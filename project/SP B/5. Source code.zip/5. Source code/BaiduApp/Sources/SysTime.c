/****************************************************************************
*	file	SysTime.c
*	brief	used to get the system time
*
*	author allen lee
* 	version 1.0
*		-	2015/05/26: initial version by allen lee
*
****************************************************************************/
#include <stdio.h>
#include "board.h"
#include "SysTime.h"


/****************************************************************************
*   Declared Structures & Variables
****************************************************************************/

sMcuTimerBase_t  gtMcuTimer;
/****************************************************************************
 * Global Variables
 ****************************************************************************/



/****************************************************************************
*	name        : SysTime
*	description : system time base
*	return      : none
****************************************************************************/
void SysTime(void)
{

    if (gtMcuTimer.u16SysTimeBase_PTD >= 1000)
    {
        gtMcuTimer.u16SysTimeBase_PTD -= 1000;
        gtMcuTimer.u8Sys1ms++;
        gtMcuTimer.pfuncSysTime1ms();

        if(gtMcuTimer.u8Sys1ms >= 10)
        {
        	gtMcuTimer.u8Sys1ms -= 10;
        	gtMcuTimer.u8Sys10ms++;
       	 	gtMcuTimer.pfuncSysTime10ms();

        	if(gtMcuTimer.u8Sys10ms >= 2)
        	{
        		gtMcuTimer.u8Sys10ms -= 2;
        		gtMcuTimer.u8Sys20ms++;
       	 		gtMcuTimer.pfuncSysTime20ms();

        		if(gtMcuTimer.u8Sys20ms >= 5)
        		{
        			gtMcuTimer.u8Sys20ms -= 5;
        			gtMcuTimer.u8Sys100ms++;
       	 			gtMcuTimer.pfuncSysTime100ms();

        			if(gtMcuTimer.u8Sys100ms >= 10)
        			{
        				gtMcuTimer.u8Sys100ms -= 10;
        				gtMcuTimer.u8Sys1s ++;
       	 				gtMcuTimer.pfuncSysTime1s();

        				if(gtMcuTimer.u8Sys1s >= 60)
        				{
        					gtMcuTimer.u8Sys1s -= 60;
        					gtMcuTimer.u8Sys1min++;
       	 					gtMcuTimer.pfuncSysTime1min();

        					if(gtMcuTimer.u8Sys1min >= 60)
        					{
        						gtMcuTimer.u8Sys1min -= 60;
        						gtMcuTimer.u8Sys1hour++;
       	 						gtMcuTimer.pfuncSysTime1hour();

        						if(gtMcuTimer.u8Sys1hour >= 24)
        						{
        							gtMcuTimer.u8Sys1hour -= 24;
        						}
        					}
        				}
        			}
        		}
        	}
        }
    }
}


