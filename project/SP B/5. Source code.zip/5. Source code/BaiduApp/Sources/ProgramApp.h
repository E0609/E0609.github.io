/****************************************************************************
*	file	ProgramApp.h
*	brief	include ProgramApp
*
*	author allen.lee
* 	version 1.0
*		-	2014/04/21: initial version by allen lee
*
****************************************************************************/

#ifndef PROGRAMAPP_H_
#define PROGRAMAPP_H_

#include "define.h"
#include "SysTime.h"
#include "PMBusData.h"
#include "macro_define.h"

#if (LITEON_BT)
/****************************************************************************
*   Declared Macro
****************************************************************************/
#define EntryBoot_Time10ms      gtMcuTimer.u8Sys10ms
//----------------------------------------------------------------------------
#define BOOT_FLASH_START_ADDRESS    0x00000000      //boot MSP
#define BOOT_FLASH_START_VECTOR     0x00000004      //boot PC
//----------------------------------------------------------------------------
#define PMBusCmd_RdCodeID					PMBusCmd_MFRSp32 //f0
#define PMBusCmd_RdMcuType					PMBusCmd_MFRSp33 //f1
#define PMBusCmd_EnterBootMode				PMBusCmd_MFRSp34 //f2
#define PMBusCmd_EraseFlash					PMBusCmd_MFRSp35 //f3
#define PMBusCmd_WriteFlash					PMBusCmd_MFRSp36 //f4
#define PMBusCmd_McuReset					PMBusCmd_MFRSp37 //f5
#define PMBusCmd_RdStatus					PMBusCmd_MFRSp38 //f6
#define PMBusCmd_RdFileCrc					PMBusCmd_MFRSp39 //f7
//----------------------------------------------------------------------------
extern void jump_to_user_address_handler(u32_t u32address, u32_t u32stackPointer);
extern void EntryBootloaderProcess(void);
extern void Init_Bootloader(void);

extern u8_t UsbBootBWrBrdProcCallComRxProcess(u8_t* pu8tgtbuff, u8_t* pu8len);

#endif /* LITEON_BT */

#endif /* PROGRAMAPP_H_ */
