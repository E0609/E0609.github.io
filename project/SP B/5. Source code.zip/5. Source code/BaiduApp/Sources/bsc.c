/****************************************************************************
*	file        : bsc.c
*   description : bsc
*   author      : Allen Lee
*   version     : 1.0
                  -   2014/03/31: initial version by Allen Lee
****************************************************************************/
#include <string.h>
#include <stdio.h>
#include "board.h"
#include "bsc.h"
#include "i2c_slave.h"
#include "bbu_ctrl.h"
#include "PMBusData.h"
#include "E2pI2cBitBangData.h"
#include "RevisionBlock.h"
//----------------------------------------------------------------------------
const u8_t pu8UsbProtocolRev[6] = {'S', '1', '.','2', ' ', ' '};

const u8_t pu8MFRRev[10] = {(FWVER_A), (FWVER_B), ((FWVER_CC & 0xFF00)>>0x08), (FWVER_CC & 0x00FF),  \
		                    ((FWVER_DD & 0xFF00)>>0x08),(FWVER_DD & 0x00FF), \
		                    ((FWVER_EE & 0xFF00)>>0x08), (FWVER_EE & 0x00FF), \
                            ' ', ' '};

const u8_t pu8Protocol[16] = {'0', '0', '0', 'M', ' ', ' ', ' ', ' ', ' ', ' ', \
		                              ' ', ' ', ' ', ' ', ' ', ' '};
const u8_t pu8MFRID[10] = {'L', 'i', 't', 'e', '-', 'O', 'n', ' ', ' ', ' '};

const u8_t pu8MFRModel[11] = {'B', 'P', '-', '1', '4', '4', '2', '-', '0', '1', 'X'};

const u8_t pu8HardwareRev[3] = {'0', 'A', ' '};

const u8_t pu8SN[10] = {'Y', 'Y', 'W', 'W', 'S', 'S', 'S', 'S', 'S', 'S'};

//const u8_t pu8MFRSerial[15] = {'6', 'X', 'X', 'X', 'X', '0', '1', 'R', 'R', 'X', 'X', 'X', 'X', 'X', 'X'};

const u8_t pu8MFRLoc[10] = {'T', 'a', 'i', 'p', 'e', 'i', ' ', ' ', ' ', ' '};

const u8_t pu8MFRDate[10] = {'1', '6', '0', '9', '2', '6', ' ', ' ', ' ', ' '};

const u8_t pu8RCB[11] = {'0', '0', 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, \
		                 '0', '0', \
                         0x00};

const u8_t pu8BbsHiNibbleAddr[8] = {0xA0, 0xB0, 0xC0, 0xD0, 0x10, 0x20, 0x30, 0x40};

//const u16_t pu16BbsLitenbusTime_ms[8] = {120, 170, 220, 270, 320, 370, 420, 470};
const u16_t pu16BbsLitenbusSlowTime_ms[8] = {500, 550, 600, 650, 700, 750, 800, 850};
const u16_t pu16BbsLitenbusFastTime_ms[8] = {100, 150, 200, 250, 300, 350, 400, 450};
//----------------------------------------------------------------------------
sBSCInformation_t tsBSC_Infor;
sBSCManufacture_t tsBSC_Manuf;
sBscStr_t tsBsc_Str;

//extern void Init_Task(void);
/****************************************************************************
*	name        : BBS_AddressType
*	description :
*	return      : none
****************************************************************************/
void BBS_AddressType(void)
{
	tsBsc_Str.u8AddrIndex = 0x00;

	if(READ_H_BBS_A2())
	{
		tsBsc_Str.u8AddrIndex |= 0x01;
	}

	if(READ_H_BBS_A3())
	{
		tsBsc_Str.u8AddrIndex |= 0x02;
	}

	if(READ_H_BBS_A4())
	{
		tsBsc_Str.u8AddrIndex |= 0x04;
	}

	if(tsBsc_Str.u8AddrIndex < 8)
	{

	}
	else
	{
		tsBsc_Str.u8AddrIndex = 0;
	}

	tsBSC_Infor.u8Address = pu8BbsHiNibbleAddr[tsBsc_Str.u8AddrIndex]>>1;
	tsBsc_Str.u16litenbustime_ms = pu16BbsLitenbusSlowTime_ms[tsBsc_Str.u8AddrIndex];

	tsBsc_Str.u8TaskSchd = StartupMode,
	tsBsc_Str.u16litenbusCnt = 0;
}

/****************************************************************************
*	name        : Init_BscRam
*	description :
*	return      : none
****************************************************************************/
void Init_BscRam(void)
{
	u8_t i;

	//usb protocol revision
	for(i=0; i<6; i++)
	{
		tsBSC_Infor.pu8UsbProtocolRev[i] = pu8UsbProtocolRev[i];
	}

	//firmware revision
	for(i=0; i<10; i++)
	{
		tsBSC_Dev.pu8MFRRev[i] = pu8MFRRev[i];
	}

	//bbu pmbus protocol revision
	for(i=0; i<16; i++)
	{
		tsBSC_Dev.pu8Protocol[i] = pu8Protocol[i];
	}

	//manufacture id
	for(i=0; i<10; i++)
	{
		//tsBSC_Dev.pu8MFRID[i] = tE2pData.pu8InRam[Manufacture0+i];
		tsBSC_Dev.pu8MFRID[i] = pu8MFRID[i];
	}

	//model name
	for(i=0; i<11; i++)
	{
		//tsBSC_Dev.pu8MFRModel[i] = tE2pData.pu8InRam[ModelName0+i];
		tsBSC_Dev.pu8MFRModel[i] = pu8MFRModel[i];
	}

	//Hardware Revision
	for(i=0; i<3; i++)
	{
		//tsBSC_Manuf.pu8HardwareRev[i] = tE2pData.pu8InRam[HardwareRev0+i];
		tsBSC_Manuf.pu8HardwareRev[i] = pu8HardwareRev[i];
	}

	//SN
	for(i=0; i<10; i++)
	{
		//tsBSC_Manuf.pu8SN[i] = tE2pData.pu8InRam[SeriealNum0+i];
		tsBSC_Manuf.pu8SN[i] = pu8SN[i];
	}

	//BarCode
	for(i=0; i<15; i++)
	{
		tsBSC_Dev.pu8MFRSerial[i] = tE2pData.pu8InRam[BarCode0+i];
	}

	//Location
	for(i=0; i<10; i++)
	{
		//tsBSC_Manuf.pu8SN[i] = tE2pData.pu8InRam[Location0+i];
		tsBSC_Dev.pu8MFRLoc[i] = pu8MFRLoc[i];
	}

	//Date
	for(i=0; i<10; i++)
	{
		//tsBSC_Dev.pu8MFRDate[i] = tE2pData.pu8InRam[Date0+i];
		tsBSC_Dev.pu8MFRDate[i] = pu8MFRDate[i];
	}

	//RCB
	for(i=0; i<11; i++)
	{
		tsBSC_Dev.pu8BbsHwFwCompCode[i] = pu8RCB[i];
	}


	BBS_AddressType();

}

/****************************************************************************
*	name        : Init_BscGpio
*	description : Initial input/output i/o
*	return      : none
****************************************************************************/
void Init_BscGpio(void)
{
	GPIO_DRV_Init(bscIntPins, bscOutPins);
	OnLineMode_Ctrl();
}
/****************************************************************************
*	name        : Init_BscGpio
*	description : Initial input/output i/o
*	return      : none
****************************************************************************/
void Init_BscGpioInConfirmingMode(void)
{
	GPIO_DRV_Init(bscConfirmingModeIntPins, bscConfirmingModeOutPins);

	tsBsc_Str.u16litenbustime_ms = pu16BbsLitenbusFastTime_ms[tsBsc_Str.u8AddrIndex];
}
/****************************************************************************
*	name        : Init_BscGpioInStandby
*	description : Initial input/output i/o
*	return      : none
****************************************************************************/
void Init_BscGpioInStandby(void)
{
	GPIO_DRV_Init(bscInStandbyIntPins, bscInStandbyOutPins);

	tsBsc_Str.u16litenbustime_ms = pu16BbsLitenbusSlowTime_ms[tsBsc_Str.u8AddrIndex];
}
/****************************************************************************
*	name        : Init_BscGpioInReOperation
*	description : Initial input/output i/o
*	return      : none
****************************************************************************/
void Init_BscGpioInReOperation(void)
{
	if (VINOK_ON_BIT == kbitSet)
	{
		GPIO_DRV_Init(bscInReOperationIntPins, bscAcGoodHighOutPins);
	}
	else
	{
		GPIO_DRV_Init(bscInReOperationIntPins, bscAcGoodLowOutPins);
	}
}
/****************************************************************************
*	name        : BscLitenBusProcess_InStartupMode
*	description :
*	return      : none
****************************************************************************/
void BscLitenBusProcess_InStartupMode(void)
{
	if(READ_L_BBS_SCL() || READ_L_BBS_SDA())
	{
		tsBsc_Str.u16litenbusCnt = 0;
	}

	if (tsBsc_Str.u8litenbus1msTimer == BscLitenBus1ms)
	{
		return;
	}
	tsBsc_Str.u8litenbus1msTimer = BscLitenBus1ms;

	tsBsc_Str.u16litenbusCnt += 1;
	if(tsBsc_Str.u16litenbusCnt > tsBsc_Str.u16litenbustime_ms)
	{
		tsBsc_Str.u8TaskSchd = OperatingMode;
		tsBsc_Str.u16litenbusCnt = 0;
	}
}
/****************************************************************************
*	name        : BscLitenBusProcess_InOperatingMode
*	description :
*	return      : none
****************************************************************************/
void BscLitenBusProcess_InOperatingMode(void)
{
	tsBsc_Str.u8litenbus1msTimer = BscLitenBus1ms;
	tsBsc_Str.u16litenbusCnt = 0;
	tsBsc_Str.u16litenbusStandbyCnt = 0;
}
/****************************************************************************
*	name        : BscLitenBusProcess_InConfirmingMode
*	description :
*	return      : none
****************************************************************************/
void BscLitenBusProcess_InConfirmingMode(void)
{
	if(READ_L_BBS_SCL() || READ_L_BBS_SDA())
	{
		tsBsc_Str.u16litenbusCnt = 0;
	}

	if (tsBsc_Str.u8litenbus1msTimer == BscLitenBus1ms)
	{
		return;
	}
	tsBsc_Str.u8litenbus1msTimer = BscLitenBus1ms;

	tsBsc_Str.u16litenbusCnt += 1;
	tsBsc_Str.u16litenbusStandbyCnt += 1;
	if(tsBsc_Str.u16litenbusCnt > tsBsc_Str.u16litenbustime_ms)
	{
		tsBsc_Str.u8TaskSchd = OperatingMode;
		tsBsc_Str.u16litenbusCnt = 0;
	}
	else
	{
		if(tsBsc_Str.u16litenbusStandbyCnt > 4000)
		{
			tsBsc_Str.u8TaskSchd = StandbyMode;
			tsBsc_Str.u16litenbusStandbyCnt = 0;
		}
	}
}
/****************************************************************************
*	name        : BscLitenBusProcess_InStandbyMode
*	description :
*	return      : none
****************************************************************************/
void BscLitenBusProcess_InStandbyMode(void)
{
	if(READ_L_BBS_SCL() || READ_L_BBS_SDA())
	{
		tsBsc_Str.u16litenbusCnt = 0;
	}

	if (tsBsc_Str.u8litenbus1msTimer == BscLitenBus1ms)
	{
		return;
	}
	tsBsc_Str.u8litenbus1msTimer = BscLitenBus1ms;

	tsBsc_Str.u16litenbusCnt += 1;
	if(tsBsc_Str.u16litenbusCnt > tsBsc_Str.u16litenbustime_ms)
	{
		tsBsc_Str.u8TaskSchd = OperatingMode;
		tsBsc_Str.u16litenbusCnt = 0;
	}
}
/****************************************************************************
*	name        : BscLitenBusProcess
*	description :
*	return      : none
****************************************************************************/
void BscLitenBusProcess(void)
{
	if(tsBsc_Str.u8TaskSchd == 0)
	{
		if(READ_L_BBS_SCL() || READ_L_BBS_SDA())
		{
			tsBsc_Str.u16litenbusCnt = 0;
		}
	}

	if (tsBsc_Str.u8litenbus1msTimer == BscLitenBus1ms)
	{
		return;
	}
	tsBsc_Str.u8litenbus1msTimer = BscLitenBus1ms;

	if(tsBsc_Str.u8TaskSchd == 0)
	{
		tsBsc_Str.u16litenbusCnt += 1;
		if(tsBsc_Str.u16litenbusCnt > tsBsc_Str.u16litenbustime_ms)
		{
			tsBsc_Str.u8TaskSchd = 1;
			tsBsc_Str.u16litenbusCnt = 0;
		}

	}

}
/****************************************************************************
*	name        : ParseBscInforRdCmdSup
*	description :
*	return      : none
****************************************************************************/
void ParseBscInforRdCmdSup(u8_t* pu8dstlen, u8_t* pu8dstbuff)
{
	u8_t i = 0;

	//Address
	memcpy(pu8dstbuff+i, &tsBSC_Infor.u8Address, 1);
	i += 1;

	//Protocol version
	memcpy(pu8dstbuff+i, &tsBSC_Infor.pu8UsbProtocolRev[0], 6);
	i += 6;

	//Firmware version
	memcpy(pu8dstbuff+i, &tsBSC_Dev.pu8MFRRev[0], 10);
	i += 10;

	*pu8dstlen = i;

}
/****************************************************************************
*	name        : ParseBscLabelRdCmdSup
*	description :
*	return      : none
****************************************************************************/
void ParseBscLabelRdCmdSup(u8_t* pu8dstlen, u8_t* pu8dstbuff)
{
	u8_t i = 0;

	//Manufacture
	memcpy(pu8dstbuff+i, &tsBSC_Dev.pu8MFRID[0], 10);
	i += 10;

	//Model
	memcpy(pu8dstbuff+i, &tsBSC_Dev.pu8MFRModel[0], 11);
	i += 11;

	//Revsion
	memcpy(pu8dstbuff+i, &tsBSC_Manuf.pu8HardwareRev[0], 3);
	i += 3;

	//SN
	memcpy(pu8dstbuff+i, &tsBSC_Manuf.pu8SN[0], 10);
	i += 10;

	//BarCode
	memcpy(pu8dstbuff+i, &tsBSC_Dev.pu8MFRSerial[0], 15);
	i += 15;

	*pu8dstlen = i;

}
