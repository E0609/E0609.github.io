/****************************************************************************
*	file	bsc_btloader.h
*	brief
*
*	author allen.lee
* 	version 1.0
*		-	2014/04/21: initial version by allen lee
*
****************************************************************************/
#ifndef BSC_BTLOADER_H_
#define BSC_BTLOADER_H_

#include "define.h"
#include "macro_define.h"

#if (BAIDU_BT)
//----------------------------------------------------------------------------
#define BOOT_FLASH_START_ADDRESS    0x00000000      //boot MSP
#define BOOT_FLASH_START_VECTOR     0x00000004      //boot PC
//----------------------------------------------------------------------------
#define MAGIC_APP_KEY     0x55AA
#define MAGIC_APP_SUM16   0x0000
#define MAGIC_APP_SUM16_LEN   (128)	//128K, calculate valid app sum16 size
/****************************************************************************
*   Declared Structures & Variables
****************************************************************************/
typedef struct _sCommonRam_t
{
    u16_t u16EntryBootKey;
    u16_t NA[7];

} sCommonRam_t;

extern __attribute__((section(".commram_data"))) sCommonRam_t	tsCommonRam;

/****************************************************************************
*   Declared Export functions
****************************************************************************/
extern void Init_CommomRam(void);
extern void SetEnteryBootKeytoRam(u16_t u16Key);
extern void GiveFarewellMessage(void);

#endif /* BAIDU_BT */

#endif /* BSC_BTLOADER_H_ */
