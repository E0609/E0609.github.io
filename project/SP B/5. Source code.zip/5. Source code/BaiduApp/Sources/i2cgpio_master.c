/****************************************************************************
*	file	i2cgpio_master.c
*	brief
*
*	author allen.lee
* 	version 1.0
*		-	2014/05/05: initial version by allen lee
*
****************************************************************************/
#include "i2cgpio_master.h"

/****************************************************************************
*	name        : i2c_gpio_set_val
*	description : pinName:kGpioEeprom_Scl, kGpioEeprom_Sda; val:kI2cGpioHi, kI2cGpioLo
*	return      : none
****************************************************************************/
void i2c_gpio_set_val(u32_t u32pinName, i2cgpio_master_logic_t u8val)
{
	if(u8val == kI2cGpioHi)
	{
		GPIO_DRV_SetPinOutput(u32pinName);
	}
	else
	{
		GPIO_DRV_ClearPinOutput(u32pinName);
	}
}

/****************************************************************************
*	name        : i2c_gpio_get_val
*	description :
*	return      : none
****************************************************************************/
i2cgpio_master_logic_t i2c_gpio_get_val(u32_t u32pinName)
{
	if(GPIO_DRV_ReadPinInput(u32pinName))
	{
		return(kI2cGpioHi);
	}
	else
	{
		return(kI2cGpioLo);
	}
}

/****************************************************************************
*	name        : i2c_gpio_setscl_dir
*	description :
*	return      : none
****************************************************************************/
void i2c_gpio_setscl_dir(i2cgpio_master_direction_t u8state)
{
	if(u8state == kI2cGpioOut)
	{
		GPIO_DRV_OutputPinInit(i2cgpioSclOutPins);
	}
	else
	{
		GPIO_DRV_InputPinInit(i2cgpioSclIntPins);
	}
}
/****************************************************************************
*	name        : i2c_gpio_setsda_dir
*	description :
*	return      : none
****************************************************************************/
void i2c_gpio_setsda_dir(i2cgpio_master_direction_t u8state)
{
	if(u8state == kI2cGpioOut)
	{
		GPIO_DRV_OutputPinInit(i2cgpioSdaOutPins);
	}
	else
	{
		GPIO_DRV_InputPinInit(i2cgpioSdaIntPins);
	}
}

/****************************************************************************
*	name        : i2c_gpio_sdalo_bitbang
*	description :
*	return      : none
****************************************************************************/
void i2c_gpio_sdalo_bitbang(void)
{
	i2c_gpio_set_val(kGpioEeprom_Sda, kI2cGpioLo);
	I2C_BITBANG_DELAY();
}
/****************************************************************************
*	name        : i2c_gpio_sdahi_bitbang
*	description :
*	return      : none
****************************************************************************/
void i2c_gpio_sdahi_bitbang(void)
{
	i2c_gpio_set_val(kGpioEeprom_Sda, kI2cGpioHi);
	I2C_BITBANG_DELAY();
}
/****************************************************************************
*	name        : i2c_gpio_scllo_bitbang
*	description :
*	return      : none
****************************************************************************/
void i2c_gpio_scllo_bitbang(void)
{
	i2c_gpio_set_val(kGpioEeprom_Scl, kI2cGpioLo);
	I2C_BITBANG_DELAY();
}
/****************************************************************************
*	name        : i2c_gpio_sclhi_bitbang
*	description :
*	return      : none
****************************************************************************/
i8_t i2c_gpio_sclhi_bitbang(void)
{
	u32_t u32delay;

	i2c_gpio_set_val(kGpioEeprom_Scl, kI2cGpioHi);
	I2C_BITBANG_DELAY();
	if(i2c_gpio_get_val(kGpioEeprom_Scl) == kI2cGpioHi)
	{
		return(1);
	}
	else
	{
		//get clock low timeout
		return(-1);
	}
}
/****************************************************************************
*	name        : i2c_gpio_idle_bitbang
*	description :
*	return      : none
****************************************************************************/
i8_t i2c_gpio_idle_bitbang(void)
{
	i2c_gpio_set_val(kGpioEeprom_Scl, kI2cGpioHi);
	i2c_gpio_set_val(kGpioEeprom_Sda, kI2cGpioHi);
	I2C_BITBANG_DELAY();
}
/****************************************************************************
*	name        : i2c_gpio_start
*	description :
*	return      : none
****************************************************************************/
void i2c_gpio_start(void)
{
	//set scl & sda to high
	i2c_gpio_set_val(kGpioEeprom_Scl, kI2cGpioHi);
	i2c_gpio_set_val(kGpioEeprom_Sda, kI2cGpioHi);
	//start setup time
	I2C_BITBANG_DELAY();

	// scl is high, set sda from 1 to 0, start hold time
	i2c_gpio_set_val(kGpioEeprom_Sda, kI2cGpioLo);
	//start hold time
	I2C_BITBANG_DELAY();

	//make scl low for data transmission
	i2c_gpio_set_val(kGpioEeprom_Scl, kI2cGpioLo);
}
/****************************************************************************
*	name        : i2c_gpio_stop
*	description :
*	return      : none
****************************************************************************/
void i2c_gpio_stop(void)
{
	// set sda to 0
	i2c_gpio_set_val(kGpioEeprom_Sda, kI2cGpioLo);
	I2C_BITBANG_DELAY();

	//set scl to 1, stop hold time
	i2c_gpio_set_val(kGpioEeprom_Scl, kI2cGpioHi);
	//stop hold time
	I2C_BITBANG_DELAY();

	//i2c_gpio_sclhi_bitbang();

	// scl is high, set sda from 0 to 1
	i2c_gpio_set_val(kGpioEeprom_Sda, kI2cGpioHi);

	//bus free time, the bus must be free before a new transmision can start
	//I2C_BITBANG_DELAY();

}
/****************************************************************************
*	name        : i2c_gpio_repstart
*	description :
*	return      : none
****************************************************************************/
void i2c_gpio_repstart(void)
{
	i2c_gpio_set_val(kGpioEeprom_Sda, kI2cGpioHi);
	I2C_BITBANG_DELAY();
	i2c_gpio_set_val(kGpioEeprom_Scl, kI2cGpioHi);
	I2C_BITBANG_DELAY();

	// scl is high, set sda from 1 to 0, start hold time
	i2c_gpio_set_val(kGpioEeprom_Sda, kI2cGpioLo);
	//start hold time
	I2C_BITBANG_DELAY();

	//make scl low for data transmission
	i2c_gpio_set_val(kGpioEeprom_Scl, kI2cGpioLo);
}
/****************************************************************************
*	name        : i2c_gpio_outbyte
*	description :
*	return      : none
****************************************************************************/
i8_t i2c_gpio_outbyte(u8_t u8data)
{
	u8_t c, u8ack;

	for(i8_t i=7; i>=0; i--)
	{
		c = (u8data>>i)&0x01;
		if(c)
		{
			i2c_gpio_set_val(kGpioEeprom_Sda, kI2cGpioHi);
		}
		else
		{
			i2c_gpio_set_val(kGpioEeprom_Sda, kI2cGpioLo);
		}
		I2C_BITBANG_DELAY();

		if(i2c_gpio_sclhi_bitbang() < 0)
		{
			return(kStatus_I2cgpio_SclTimeout);	//timeout
		}
		//do arbitration
		//if(c && !i2c_gpio_get_val(kGpioEeprom_Sda))
		//{
			//
		//}
		i2c_gpio_set_val(kGpioEeprom_Scl, kI2cGpioLo);
	}

	//read ack:sda should be pulled down by slave, or it may NAK
	//make sda as input
	i2c_gpio_setsda_dir(kI2cGpioInt);
	I2C_BITBANG_DELAY();

	if(i2c_gpio_sclhi_bitbang() < 0)
	{
		return(kStatus_I2cgpio_SclTimeout);	//timeout
	}
	//scl is high, now data is valid
	u8ack = i2c_gpio_get_val(kGpioEeprom_Sda);	//ack:sda is pulled low, success

	i2c_gpio_set_val(kGpioEeprom_Scl, kI2cGpioLo);	// assert: scl is low (sda undef)

	//make sda as output
	i2c_gpio_setsda_dir(kI2cGpioOut);

	return(u8ack);

}
/****************************************************************************
*	name        : i2c_gpio_sendbytes
*	description :
*	return      : none
****************************************************************************/
i16_t i2c_gpio_sendbytes(u16_t u16len, u8_t *pu8buff)
{
	u8_t *pu8tempbuff = pu8buff;
	u16_t u16count = u16len, u16wrcount = 0;

	i8_t i8retval;

	while(u16count > 0)
	{
		i8retval = i2c_gpio_outbyte(*pu8tempbuff);
		if(i8retval == 0)	//ack
		{
			u16count -= 1;
			pu8tempbuff += 1;
			u16wrcount += 1;
		}
		else if(i8retval == 1)	//nak
		{
			return(kStatus_I2cgpio_Nack);
		}
		else
		{
			return(kStatus_I2cgpio_SclTimeout);	//timeout
		}
	}

	return(kStatus_I2cgpio_Success);
	//return((i16_t)u8wrcount&0x00ff);

}
/****************************************************************************
*	name        : i2c_gpio_intbyte
*	description :
*	return      : none
****************************************************************************/
i16_t i2c_gpio_intbyte(void)
{
	u8_t i, u8rxdata=0;

	//make sda as input
	i2c_gpio_setsda_dir(kI2cGpioInt);

	for(i=0; i<8; i++)
	{
		I2C_BITBANG_DELAY();

		if(i2c_gpio_sclhi_bitbang() < 0)
		{
			return(kStatus_I2cgpio_SclTimeout);	//timeout
		}
		u8rxdata *= 2;

		if(i2c_gpio_get_val(kGpioEeprom_Sda)==kI2cGpioHi)
		{
			u8rxdata |= 0x01;
		}

		i2c_gpio_set_val(kGpioEeprom_Scl, kI2cGpioLo);
	}

	return((i16_t)u8rxdata&0x00ff);
}
/****************************************************************************
*	name        : i2c_gpio_readbytes
*	description :
*	return      : none
****************************************************************************/
i16_t i2c_gpio_readbytes(u16_t u16len, u8_t *pu8buff)
{
	u8_t *pu8tempbuff = pu8buff;
	u16_t u16count = u16len, u16rdcount = 0;

	i16_t i16retval;

	while(u16count > 0)
	{
		i16retval = i2c_gpio_intbyte();

		//make sda as output
		i2c_gpio_setsda_dir(kI2cGpioOut);

		if(i16retval < 0)
		{
			return(kStatus_I2cgpio_SclTimeout);	//timeout
		}
		else
		{
			 *pu8tempbuff = (u8_t)i16retval;
			 u16rdcount += 1;
		}
		pu8tempbuff += 1;
		u16count -= 1;

	    if (u16count)              /* send ack */
	    {
	    	i2c_gpio_set_val(kGpioEeprom_Sda, kI2cGpioLo);
	    }
	    else
	    {
	    	i2c_gpio_set_val(kGpioEeprom_Sda, kI2cGpioHi);
	    }
	    I2C_BITBANG_DELAY();

		if(i2c_gpio_sclhi_bitbang() < 0)
		{
			return(kStatus_I2cgpio_SclTimeout);	//timeout
		}

		//make scl low for data transmission
		i2c_gpio_set_val(kGpioEeprom_Scl, kI2cGpioLo);

	}

	return(kStatus_I2cgpio_Success);
	//return((i16_t)u8rdcount&0x00ff);
}
/****************************************************************************
*	name        : Init_I2cGpioMaster
*	description : Initial input/output i/o
*	return      : none
****************************************************************************/
void Init_I2cGpioMaster(void)
{
	//enable scl & sda gpio port
	i2c_gpio_setsda_dir(kI2cGpioOut);
	i2c_gpio_setscl_dir(kI2cGpioOut);

	//set scl & sda to high
	i2c_gpio_set_val(kGpioEeprom_Scl, kI2cGpioHi);
	i2c_gpio_set_val(kGpioEeprom_Sda, kI2cGpioHi);

}


