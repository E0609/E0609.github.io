/****************************************************************************
*	file	ProgramBlock.h
*	brief	include ProgramBlock
*
*	author allen.lee
* 	version 1.0
*		-	2014/04/21: initial version by allen lee
*
****************************************************************************/

#ifndef PROGRAMBLOCK_H_
#define PROGRAMBLOCK_H_

#include "define.h"
#include "macro_define.h"

//----------------------------------------------------------------------------
#define PIB_SIZE        (60)
#define PIB_REV         0x0100      // programming information block revision 01.00
#define DEVICE_TYPE     (8)         // 1: AC UPS, 2: DC UPS, 3: VPOC, 4: PDU, 5: PSU, 6: BBU, 7:PSC, 8:BSC
#define PROCESSOR_TYPE  (1)         // BSC :1-sys
#define CODE_ID_AA      0x4250      //BP
#define CODE_ID_BCCC    0x31343432  //1442
#define CODE_ID_DDEE    0x30315800  //01X
#define CODE_ID_NN      0x0000      //
#define START_ADDRES    0x00014000
#define STOP_ADDRES     0x0003FFFF
//#define START_ADDRES    0x0000F000//0x00014000
//#define STOP_ADDRES     0x0001FFFF//0x0003FFFF
#define ERASE_TIME      (210)       // 21.0sec, unit:0.1sec
#define PROGRAM_TIME    (2)         // 200usec, unit:100us
#define PROGRAM_BYTE    (32)
#define FILL_VALUE      0xFF
#define RVD_1BYTE       0x00
#define RVD_4BYTE_1     0x00000000
#define RVD_4BYTE_2     0x00000000
#define RVD_2BYTE       0x0000

//----------------------------------------------------------------------------
#if (LITEON_BT)
#define MAGIC_APP_KEY   0x55AA
#endif /* LITEON_BT */
/****************************************************************************
*   Declared Structures & Variables
****************************************************************************/
#if (LITEON_BT)
typedef struct _sCommonRam_t
{
    u16_t u16EntryBootKey;
    u16_t NA[7];

} sCommonRam_t;

extern __attribute__((section(".commram_data"))) sCommonRam_t	tsCommonRam;
#endif /* LITEON_BT */

//----------------------------------------------------------------------------
#pragma pack(1)
typedef struct {
	u8_t    pu8StartPattern[8];
    u8_t    pu8PIBRev[2];
    u8_t    u8DevType;
    u8_t    u8ProcessorType;
    u8_t    pu8CodeID[12];
    u8_t    pu8StartAddres[4];
    u8_t    pu8StopAddres[4];
    u8_t    p8EraseAllTime[2];
    u8_t	p8ProgramTimePerByte[2];
    u8_t	p8ProgramByteLength[2];
    u8_t	u8FillValue;
    u8_t    p8Reserved[11];
    u8_t	pu8CheckSum[2];
    u8_t    pu8StopPattern[8];
} sProgamInfoBlock_t;
#pragma pack()

extern sProgamInfoBlock_t   tsProgamInfoBlock;
/****************************************************************************
*   Declared Export functions
****************************************************************************/
extern void ProgramInfoBlockFun(void);

#if (LITEON_BT)
extern void Init_CommomRam(void);
extern void SetEnteryBootKeytoRam(u16_t u16Key);
#endif /* LITEON_BT */

#endif /* PROGRAMBLOCK_H_ */
