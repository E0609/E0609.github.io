/****************************************************************************
*	file	pmbus_linearformat.h
*	brief	The file includes subroutines for 24LCxxx
*
*	author allen.lee
* 	version 1.0
*		-	2014/04/21: initial version by allen lee
*
****************************************************************************/

#ifndef PMBUS_LINEARFORMAT_H_
#define PMBUS_LINEARFORMAT_H_

#include "define.h"
#include <math.h>
//----------------------------------------------------------------------------
extern float_t L11_to_float(u16_t u16input_val);
extern float_t L16_to_float(u8_t u8exp, u16_t u16input_val);

#endif /* PMBUS_LINEARFORMAT_H_ */
