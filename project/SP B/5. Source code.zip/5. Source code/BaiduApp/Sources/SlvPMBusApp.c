/****************************************************************************
*	file	SlvPMBusApp.c
*	brief	The file includes the function and data structure/variables
*		    for the PMBus protocol
*	author allen.lee
* 	version 1.0
*		-	2015/05/11: initial version by allen lee
*
****************************************************************************/
#include <string.h>
#include <stdio.h>
#include "i2c_slave.h"
#include "i2c_irq.h"
#include "crc8.h"
#include "SlvPMBusApp.h"
#include "MstPMBusApp.h"
#include "macro_define.h"

/****************************************************************************
*   Declared Structures & Variables
****************************************************************************/
u8_t u8SlavePMBusTimeoutTimer;

static sSlvPMBusAppStr_t sSlvPMBusAppStruct;

extern void ClearSlvDisconnectCount(void);
/****************************************************************************
*	name        : SlvPMBusSetErrorCode
*	description : slave pm bus debug
*	return      : none
****************************************************************************/
void SlvPMBusSetErrorCode(u16_t u16errCode, u16_t u16errFlags)
{
	sSlvPMBusAppStruct.u16errCode = u16errCode;
	sSlvPMBusAppStruct.u16flags |= u16errFlags;
}
/****************************************************************************
*	name        : SlvPBus_PEC_Init
*	description : PEC initialization
*	return      : none
****************************************************************************/
void SlvPBus_PEC_Init(void)
{
	sSlvPMBusAppStruct.u8pec = 0;
}

/****************************************************************************
*	name        : SlvPBus_PEC
*	description : PEC CRC function,this function uses x^8+x^2+x^1+1 polynomial
*	return      : none
****************************************************************************/
void SlvPBus_PEC(u8_t u8Data)
{
	CalCRC8(&sSlvPMBusAppStruct.u8pec, u8Data);
}
/****************************************************************************
*	name        : SlvPBus_GetPEC
*	description : PEC CRC function,this function uses x^8+x^2+x^1+1 polynomial
*	return      : none
****************************************************************************/
u8_t SlvPBus_GetPEC(void)
{
	return(sSlvPMBusAppStruct.u8pec);
}
/****************************************************************************
*	name        : SlvPMBusGetBbuAddr
*	description :
*	return      : none
****************************************************************************/
void SlvPMBusGetBbuAddr(void)
{
	u8_t i, j;
	u16_t u16DevIndex;

	u16DevIndex = GetPresentDeviceIndex();

	memset(tsBSC_Dev.pu8BbuAddress, 0, sizeof(tsBSC_Dev.pu8BbuAddress));
	for(i=0, j=0; i<BBU_DEV_NUM; i++)
	{
		if((u16DevIndex >> i) & 0x0001)
		{
			tsBSC_Dev.pu8BbuAddress[j] = GetPresentDeviceAddress(i)&0xFE;
			j += 1;
		}
	}

}
/****************************************************************************
*	name        : SlvPMBusAddrSup
*	description :
*	return      : none
****************************************************************************/
bool SlvPMBusAddrSup(u8_t u8addr, u8_t* pu8idx)
{
	u8_t i;
	u16_t u16DevIndex;

	u16DevIndex = GetPresentDeviceIndex();
	for(i=0; i<BBU_DEV_NUM; i++)
	{
		//u16DevIndex = 0x0002;//test
		if((u16DevIndex >> i) & 0x0001)
		{
			if ((u8addr&0xFE) == (GetPresentDeviceAddress(i)&0xFE))
			{
				*pu8idx = i;
				return true;
			}
		}
	}

	return false;
}
/****************************************************************************
*	name        : UpdateBscStatusCML
*	description :
*	return      : none
****************************************************************************/
void UpdateBscStatusCML(u8_t u8Value, u8_t u8Set)
{
	if(u8Set)
	{
		tsBSC_Dev.tnStatusCML.u8All |= u8Value;
	}
	else
	{
		tsBSC_Dev.tnStatusCML.u8All &= (~u8Value);
	}
}
/****************************************************************************
*	name        : UpdateBscInVeBtCmd
*	description :
*	return      : none
****************************************************************************/
#if (BAIDU_BT)
void UpdateBscInVeBtCmd(u8_t u8Value)
{
	tsBSC_Dev.u8BtCmd = u8Value;
}
#endif
/****************************************************************************
*	name        : SlvPMBusDecodeCmd
*	description : get command type
*	return      : none
****************************************************************************/
bool SlvPMBusDecodeCmd(u8_t u8CmdCode)
{
	u8_t j;

	sSlvPMBusAppStruct.u8CmdCode = u8CmdCode;

	//BSC PMBus commands(bsc address only)
	if(IsBscI2cAddr2(sSlvPMBusAppStruct.u8wrAddr) == true)
	{
#if (BAIDU_BT)
		if(tsBsc_Str.u8TaskSchd == OperatingMode)
		{
			for(j=0; j<BBS_PMBUS_RW_NUM; j++)
			{
				if (u8CmdCode == sBbsPMBusRWCmd[j].u8CmdCode)
				{
					sSlvPMBusAppStruct.u8CmdType = sBbsPMBusRWCmd[j].u8CmdType;
					sSlvPMBusAppStruct.u8rxpacketSize = sBbsPMBusRWCmd[j].u8Len;
					sSlvPMBusAppStruct.pu8WrTempBuff = sBbsPMBusRWCmd[j].pu8Buff;
					return true;
				}
			}

			for(j=0; j<BBS_PMBUS_WO_NUM; j++)
			{
				if (u8CmdCode == sBbsPMBusWOCmd[j].u8CmdCode)
				{
					sSlvPMBusAppStruct.u8CmdType = sBbsPMBusWOCmd[j].u8CmdType;
					sSlvPMBusAppStruct.u8rxpacketSize = sBbsPMBusWOCmd[j].u8Len;
					sSlvPMBusAppStruct.pu8WrTempBuff = sBbsPMBusWOCmd[j].pu8Buff;
					return true;
				}
			}

			for(j=0; j<BBS_PMBUS_RO_NUM; j++)
			{
				if (u8CmdCode == sBbsPMBusROCmd[j].u8CmdCode)
				{
					sSlvPMBusAppStruct.u8CmdType = sBbsPMBusROCmd[j].u8CmdType;
					sSlvPMBusAppStruct.u8rxpacketSize = sBbsPMBusROCmd[j].u8Len;
					sSlvPMBusAppStruct.pu8WrTempBuff = sBbsPMBusROCmd[j].pu8Buff;
					return true;
				}
			}
		}
		else	//inactive bbs
		{
			for(j=0; j<BBS_BT_PMBUS_RW_NUM; j++)
			{
				if (u8CmdCode == sBbsBtPMBusRWCmd[j].u8CmdCode)
				{
					sSlvPMBusAppStruct.u8CmdType = sBbsBtPMBusRWCmd[j].u8CmdType;
					sSlvPMBusAppStruct.u8rxpacketSize = sBbsBtPMBusRWCmd[j].u8Len;
					sSlvPMBusAppStruct.pu8WrTempBuff = sBbsBtPMBusRWCmd[j].pu8Buff;
					return true;
				}
			}

			for(j=0; j<BBS_BT_PMBUS_WO_NUM; j++)
			{
				if (u8CmdCode == sBbsBtPMBusWOCmd[j].u8CmdCode)
				{
					sSlvPMBusAppStruct.u8CmdType = sBbsBtPMBusWOCmd[j].u8CmdType;
					sSlvPMBusAppStruct.u8rxpacketSize = sBbsBtPMBusWOCmd[j].u8Len;
					sSlvPMBusAppStruct.pu8WrTempBuff = sBbsBtPMBusWOCmd[j].pu8Buff;
					return true;
				}
			}

			for(j=0; j<BBS_BT_PMBUS_RO_NUM; j++)
			{
				if (u8CmdCode == sBbsBtPMBusROCmd[j].u8CmdCode)
				{
					sSlvPMBusAppStruct.u8CmdType = sBbsBtPMBusROCmd[j].u8CmdType;
					sSlvPMBusAppStruct.u8rxpacketSize = sBbsBtPMBusROCmd[j].u8Len;
					sSlvPMBusAppStruct.pu8WrTempBuff = sBbsBtPMBusROCmd[j].pu8Buff;
					return true;
				}
			}
		}
#else
		for(j=0; j<BBS_PMBUS_RW_NUM; j++)
		{
			if (u8CmdCode == sBbsPMBusRWCmd[j].u8CmdCode)
			{
				sSlvPMBusAppStruct.u8CmdType = sBbsPMBusRWCmd[j].u8CmdType;
				sSlvPMBusAppStruct.u8rxpacketSize = sBbsPMBusRWCmd[j].u8Len;
				sSlvPMBusAppStruct.pu8WrTempBuff = sBbsPMBusRWCmd[j].pu8Buff;
				return true;
			}
		}

		for(j=0; j<BBS_PMBUS_WO_NUM; j++)
		{
			if (u8CmdCode == sBbsPMBusWOCmd[j].u8CmdCode)
			{
				sSlvPMBusAppStruct.u8CmdType = sBbsPMBusWOCmd[j].u8CmdType;
				sSlvPMBusAppStruct.u8rxpacketSize = sBbsPMBusWOCmd[j].u8Len;
				sSlvPMBusAppStruct.pu8WrTempBuff = sBbsPMBusWOCmd[j].pu8Buff;
				return true;
			}
		}

		for(j=0; j<BBS_PMBUS_RO_NUM; j++)
		{
			if (u8CmdCode == sBbsPMBusROCmd[j].u8CmdCode)
			{
				sSlvPMBusAppStruct.u8CmdType = sBbsPMBusROCmd[j].u8CmdType;
				sSlvPMBusAppStruct.u8rxpacketSize = sBbsPMBusROCmd[j].u8Len;
				sSlvPMBusAppStruct.pu8WrTempBuff = sBbsPMBusROCmd[j].pu8Buff;
				return true;
			}
		}
#endif

		sSlvPMBusAppStruct.u8CmdType = PMBusCT_NoSupp;
		sSlvPMBusAppStruct.pu8WrTempBuff = NULL;
		return false;
	}

	//BBU PMBus commands
#if (MST_RD_SEQUENCE)
	for(j=0; j<BBU_PMBUS_RW_CFG_NUM; j++)
	{
		if (u8CmdCode == sBbuPMBusRWCmd_CFG[j].u8CmdCode)
		{
			sSlvPMBusAppStruct.u8CmdType = sBbuPMBusRWCmd_CFG[j].u8CmdType;
			sSlvPMBusAppStruct.u8rxpacketSize = sBbuPMBusRWCmd_CFG[j].u8Len;
			sSlvPMBusAppStruct.pu8WrTempBuff = sBbuPMBusRWCmd_CFG[j].pu8Buff;
			return true;
		}
	}
#else
	for(j=0; j<BBU_PMBUS_RW_NUM; j++)
	{
		if (u8CmdCode == sBbuPMBusRWCmd[j].u8CmdCode)
		{
			sSlvPMBusAppStruct.u8CmdType = sBbuPMBusRWCmd[j].u8CmdType;
			sSlvPMBusAppStruct.u8rxpacketSize = sBbuPMBusRWCmd[j].u8Len;
			sSlvPMBusAppStruct.pu8WrTempBuff = sBbuPMBusRWCmd[j].pu8Buff;
			return true;
		}
	}
#endif

#if (MST_RD_SEQUENCE)
	for(j=0; j<BBU_PMBUS_WO_CTR_NUM; j++)
	{
		if (u8CmdCode == sBbuPMBusWOCmd_CTR[j].u8CmdCode)
		{
			sSlvPMBusAppStruct.u8CmdType = sBbuPMBusWOCmd_CTR[j].u8CmdType;
			sSlvPMBusAppStruct.u8rxpacketSize = sBbuPMBusWOCmd_CTR[j].u8Len;
			sSlvPMBusAppStruct.pu8WrTempBuff = sBbuPMBusWOCmd_CTR[j].pu8Buff;
			return true;
		}
	}
#else
	for(j=0; j<BBU_PMBUS_WO_NUM; j++)
	{
		if (u8CmdCode == sBbuPMBusWOCmd[j].u8CmdCode)
		{
			sSlvPMBusAppStruct.u8CmdType = sBbuPMBusWOCmd[j].u8CmdType;
			sSlvPMBusAppStruct.u8rxpacketSize = sBbuPMBusWOCmd[j].u8Len;
			sSlvPMBusAppStruct.pu8WrTempBuff = sBbuPMBusWOCmd[j].pu8Buff;
			return true;
		}
	}
#endif

#if (MST_RD_SEQUENCE)
	for(j=0; j<BBU_PMBUS_RO_STA_NUM; j++)
	{
		if (u8CmdCode == sBbuPMBusROCmd_STA[j].u8CmdCode)
		{
			sSlvPMBusAppStruct.u8CmdType = sBbuPMBusROCmd_STA[j].u8CmdType;
			sSlvPMBusAppStruct.u8rxpacketSize = sBbuPMBusROCmd_STA[j].u8Len;
			sSlvPMBusAppStruct.pu8WrTempBuff = sBbuPMBusROCmd_STA[j].pu8Buff;
			return true;
		}
	}

	for(j=0; j<BBU_PMBUS_RO_MST_NUM; j++)
	{
		if (u8CmdCode == sBbuPMBusROCmd_MST[j].u8CmdCode)
		{
			sSlvPMBusAppStruct.u8CmdType = sBbuPMBusROCmd_MST[j].u8CmdType;
			sSlvPMBusAppStruct.u8rxpacketSize = sBbuPMBusROCmd_MST[j].u8Len;
			sSlvPMBusAppStruct.pu8WrTempBuff = sBbuPMBusROCmd_MST[j].pu8Buff;
			return true;
		}
	}

	for(j=0; j<BBU_PMBUS_RO_INF_NUM; j++)
	{
		if (u8CmdCode == sBbuPMBusROCmd_INF[j].u8CmdCode)
		{
			sSlvPMBusAppStruct.u8CmdType = sBbuPMBusROCmd_INF[j].u8CmdType;
			sSlvPMBusAppStruct.u8rxpacketSize = sBbuPMBusROCmd_INF[j].u8Len;
			sSlvPMBusAppStruct.pu8WrTempBuff = sBbuPMBusROCmd_INF[j].pu8Buff;
			return true;
		}
	}

	for(j=0; j<BBU_PMBUS_RO_MFC_NUM; j++)
	{
		if (u8CmdCode == sBbuPMBusROCmd_MFC[j].u8CmdCode)
		{
			sSlvPMBusAppStruct.u8CmdType = sBbuPMBusROCmd_MFC[j].u8CmdType;
			sSlvPMBusAppStruct.u8rxpacketSize = sBbuPMBusROCmd_MFC[j].u8Len;
			sSlvPMBusAppStruct.pu8WrTempBuff = sBbuPMBusROCmd_MFC[j].pu8Buff;
			return true;
		}
	}
#else
	for(j=0; j<BBU_PMBUS_RO_NUM; j++)
	{
		if (u8CmdCode == sBbuPMBusROCmd[j].u8CmdCode)
		{
			sSlvPMBusAppStruct.u8CmdType = sBbuPMBusROCmd[j].u8CmdType;
			sSlvPMBusAppStruct.u8rxpacketSize = sBbuPMBusROCmd[j].u8Len;
			sSlvPMBusAppStruct.pu8WrTempBuff = sBbuPMBusROCmd[j].pu8Buff;
			return true;
		}
	}
#endif

	sSlvPMBusAppStruct.u8CmdType = PMBusCT_NoSupp;
	sSlvPMBusAppStruct.pu8WrTempBuff = NULL;
	return false;
}
/****************************************************************************
*	name        : SlvGetPagePlusRd
*	description :
*	return      : none
****************************************************************************/
u8_t SlvGetPagePlusRd(u8_t u8CmdCode, u8_t u8DevIndex)
{
	u8_t j;
	u8_t* pu8buff;

#if (MST_RD_SEQUENCE)
	for(j=0; j<BBU_PMBUS_RW_CFG_NUM; j++)
	{
		if (u8CmdCode == sBbuPMBusRWCmd_CFG[j].u8CmdCode)
		{
			sSlvPMBusAppStruct.u8txpacketSize = sBbuPMBusRWCmd_CFG[j].u8Len;
			pu8buff = sBbuPMBusRWCmd[j].pu8Buff + (u8DevIndex*sizeof(tsBBU_Dev[0]));
			memcpy(sSlvPMBusAppStruct.pu8txBuff, pu8buff, sSlvPMBusAppStruct.u8txpacketSize);
			return (PMBusCP_RdWr);
		}
	}
#else
	for(j=0; j<BBU_PMBUS_RW_NUM; j++)
	{
		if (u8CmdCode == sBbuPMBusRWCmd[j].u8CmdCode)
		{
			sSlvPMBusAppStruct.u8txpacketSize = sBbuPMBusRWCmd[j].u8Len;
			pu8buff = sBbuPMBusRWCmd[j].pu8Buff + (u8DevIndex*sizeof(tsBBU_Dev[0]));
			memcpy(sSlvPMBusAppStruct.pu8txBuff, pu8buff, sSlvPMBusAppStruct.u8txpacketSize);
			return (PMBusCP_RdWr);
		}
	}
#endif

#if (MST_RD_SEQUENCE)
	for(j=0; j<BBU_PMBUS_RO_STA_NUM; j++)
	{
		if (u8CmdCode == sBbuPMBusROCmd_STA[j].u8CmdCode)
		{
			sSlvPMBusAppStruct.u8txpacketSize = sBbuPMBusROCmd_STA[j].u8Len;
			pu8buff = sBbuPMBusROCmd_STA[j].pu8Buff + (u8DevIndex*sizeof(tsBBU_Dev[0]));
			memcpy(sSlvPMBusAppStruct.pu8txBuff, pu8buff, sSlvPMBusAppStruct.u8txpacketSize);
			return (PMBusCP_RdOnly);
		}
	}

	for(j=0; j<BBU_PMBUS_RO_MST_NUM; j++)
	{
		if (u8CmdCode == sBbuPMBusROCmd_MST[j].u8CmdCode)
		{
			sSlvPMBusAppStruct.u8txpacketSize = sBbuPMBusROCmd_MST[j].u8Len;
			pu8buff = sBbuPMBusROCmd_MST[j].pu8Buff + (u8DevIndex*sizeof(tsBBU_Dev[0]));
			memcpy(sSlvPMBusAppStruct.pu8txBuff, pu8buff, sSlvPMBusAppStruct.u8txpacketSize);
			return (PMBusCP_RdOnly);
		}
	}

	for(j=0; j<BBU_PMBUS_RO_INF_NUM; j++)
	{
		if (u8CmdCode == sBbuPMBusROCmd_INF[j].u8CmdCode)
		{
			sSlvPMBusAppStruct.u8txpacketSize = sBbuPMBusROCmd_INF[j].u8Len;
			pu8buff = sBbuPMBusROCmd_INF[j].pu8Buff + (u8DevIndex*sizeof(tsBBU_Dev[0]));
			memcpy(sSlvPMBusAppStruct.pu8txBuff, pu8buff, sSlvPMBusAppStruct.u8txpacketSize);
			return (PMBusCP_RdOnly);
		}
	}

	for(j=0; j<BBU_PMBUS_RO_MFC_NUM; j++)
	{
		if (u8CmdCode == sBbuPMBusROCmd_MFC[j].u8CmdCode)
		{
			sSlvPMBusAppStruct.u8txpacketSize = sBbuPMBusROCmd_MFC[j].u8Len;
			pu8buff = sBbuPMBusROCmd_MFC[j].pu8Buff + (u8DevIndex*sizeof(tsBBU_Dev[0]));
			memcpy(sSlvPMBusAppStruct.pu8txBuff, pu8buff, sSlvPMBusAppStruct.u8txpacketSize);
			return (PMBusCP_RdOnly);
		}
	}
#else
	for(j=0; j<BBU_PMBUS_RO_NUM; j++)
	{
		if (u8CmdCode == sBbuPMBusROCmd[j].u8CmdCode)
		{
			sSlvPMBusAppStruct.u8txpacketSize = sBbuPMBusROCmd[j].u8Len;
			pu8buff = sBbuPMBusROCmd[j].pu8Buff + (u8DevIndex*sizeof(tsBBU_Dev[0]));
			memcpy(sSlvPMBusAppStruct.pu8txBuff, pu8buff, sSlvPMBusAppStruct.u8txpacketSize);
			return (PMBusCP_RdOnly);
		}
	}
#endif

	return (PMBusCP_NoSupp);
}
/****************************************************************************
*	name        : SlvParseRdCmdSup
*	description :
*	return      : none
****************************************************************************/
bool SlvParseRdCmdSup(u8_t u8rdaddr, u8_t u8DevIndex)
{
	u8_t j, u8Data;
	u8_t* pu8buff;

	if(IsBscI2cAddr2(u8rdaddr&0xFE) == true)
	{
		for(j=0; j<BBS_PMBUS_RW_NUM; j++)
		{
			if (sSlvPMBusAppStruct.u8CmdCode == sBbsPMBusRWCmd[j].u8CmdCode)
			{
				sSlvPMBusAppStruct.u8txpacketSize = sBbsPMBusRWCmd[j].u8Len;
				pu8buff = sBbsPMBusRWCmd[j].pu8Buff;
				memcpy(sSlvPMBusAppStruct.pu8txBuff, pu8buff, sSlvPMBusAppStruct.u8txpacketSize);
				return true;
			}
		}

		for(j=0; j<BBS_PMBUS_RO_NUM; j++)
		{
			if (sSlvPMBusAppStruct.u8CmdCode == sBbsPMBusROCmd[j].u8CmdCode)
			{
				if (sSlvPMBusAppStruct.u8CmdCode == PMBusCmd_UsrData10)
				{
					SlvPMBusGetBbuAddr();
				}

				sSlvPMBusAppStruct.u8txpacketSize = sBbsPMBusROCmd[j].u8Len;
				pu8buff = sBbsPMBusROCmd[j].pu8Buff;
				memcpy(sSlvPMBusAppStruct.pu8txBuff, pu8buff, sSlvPMBusAppStruct.u8txpacketSize);
				return true;
			}
		}

		return false;
	}

	if (sSlvPMBusAppStruct.u8CmdCode == PMBusCmd_Query)
	{
		GetBscQueryDataFormat(sSlvPMBusAppStruct.pu8rxBuff[1], &u8Data);
		sSlvPMBusAppStruct.u8txpacketSize = 1;
		memcpy(sSlvPMBusAppStruct.pu8txBuff, &u8Data, sSlvPMBusAppStruct.u8txpacketSize);

		return true;
	}

	if (sSlvPMBusAppStruct.u8CmdCode == PMBusCmd_PagePlusRd)
	{
		//sSlvPMBusAppStruct.u8CmdCode = sSlvPMBusAppStruct.pu8rxBuff[2]; //command code
		SlvGetPagePlusRd(sSlvPMBusAppStruct.pu8rxBuff[2], u8DevIndex);

		return true;
	}

#if (MST_RD_SEQUENCE)
	for(j=0; j<BBU_PMBUS_RW_CFG_NUM; j++)
	{
		if (sSlvPMBusAppStruct.u8CmdCode == sBbuPMBusRWCmd_CFG[j].u8CmdCode)
		{
			sSlvPMBusAppStruct.u8txpacketSize = sBbuPMBusRWCmd_CFG[j].u8Len;
			pu8buff = sBbuPMBusRWCmd_CFG[j].pu8Buff + (u8DevIndex*sizeof(tsBBU_Dev[0]));
			memcpy(sSlvPMBusAppStruct.pu8txBuff, pu8buff, sSlvPMBusAppStruct.u8txpacketSize);
			return true;
		}
	}
#else
	for(j=0; j<BBU_PMBUS_RW_NUM; j++)
	{
		if (sSlvPMBusAppStruct.u8CmdCode == sBbuPMBusRWCmd[j].u8CmdCode)
		{
			sSlvPMBusAppStruct.u8txpacketSize = sBbuPMBusRWCmd[j].u8Len;
			pu8buff = sBbuPMBusRWCmd[j].pu8Buff + (u8DevIndex*sizeof(tsBBU_Dev[0]));
			memcpy(sSlvPMBusAppStruct.pu8txBuff, pu8buff, sSlvPMBusAppStruct.u8txpacketSize);
			return true;
		}
	}
#endif

#if (MST_RD_SEQUENCE)
	for(j=0; j<BBU_PMBUS_RO_STA_NUM; j++)
	{
		if (sSlvPMBusAppStruct.u8CmdCode == sBbuPMBusROCmd_STA[j].u8CmdCode)
		{
			sSlvPMBusAppStruct.u8txpacketSize = sBbuPMBusROCmd_STA[j].u8Len;
			pu8buff = sBbuPMBusROCmd_STA[j].pu8Buff + (u8DevIndex*sizeof(tsBBU_Dev[0]));
			memcpy(sSlvPMBusAppStruct.pu8txBuff, pu8buff, sSlvPMBusAppStruct.u8txpacketSize);
			return true;
		}
	}

	for(j=0; j<BBU_PMBUS_RO_MST_NUM; j++)
	{
		if (sSlvPMBusAppStruct.u8CmdCode == sBbuPMBusROCmd_MST[j].u8CmdCode)
		{
			sSlvPMBusAppStruct.u8txpacketSize = sBbuPMBusROCmd_MST[j].u8Len;
			pu8buff = sBbuPMBusROCmd_MST[j].pu8Buff + (u8DevIndex*sizeof(tsBBU_Dev[0]));
			memcpy(sSlvPMBusAppStruct.pu8txBuff, pu8buff, sSlvPMBusAppStruct.u8txpacketSize);
			return true;
		}
	}

	for(j=0; j<BBU_PMBUS_RO_INF_NUM; j++)
	{
		if (sSlvPMBusAppStruct.u8CmdCode == sBbuPMBusROCmd_INF[j].u8CmdCode)
		{
			sSlvPMBusAppStruct.u8txpacketSize = sBbuPMBusROCmd_INF[j].u8Len;
			pu8buff = sBbuPMBusROCmd_INF[j].pu8Buff + (u8DevIndex*sizeof(tsBBU_Dev[0]));
			memcpy(sSlvPMBusAppStruct.pu8txBuff, pu8buff, sSlvPMBusAppStruct.u8txpacketSize);
			return true;
		}
	}

	for(j=0; j<BBU_PMBUS_RO_MFC_NUM; j++)
	{
		if (sSlvPMBusAppStruct.u8CmdCode == sBbuPMBusROCmd_MFC[j].u8CmdCode)
		{
			sSlvPMBusAppStruct.u8txpacketSize = sBbuPMBusROCmd_MFC[j].u8Len;
			pu8buff = sBbuPMBusROCmd_MFC[j].pu8Buff + (u8DevIndex*sizeof(tsBBU_Dev[0]));
			memcpy(sSlvPMBusAppStruct.pu8txBuff, pu8buff, sSlvPMBusAppStruct.u8txpacketSize);
			return true;
		}
	}
#else
	for(j=0; j<BBU_PMBUS_RO_NUM; j++)
	{
		if (sSlvPMBusAppStruct.u8CmdCode == sBbuPMBusROCmd[j].u8CmdCode)
		{
			sSlvPMBusAppStruct.u8txpacketSize = sBbuPMBusROCmd[j].u8Len;
			pu8buff = sBbuPMBusROCmd[j].pu8Buff + (u8DevIndex*sizeof(tsBBU_Dev[0]));
			memcpy(sSlvPMBusAppStruct.pu8txBuff, pu8buff, sSlvPMBusAppStruct.u8txpacketSize);
			return true;
		}
	}
#endif

	return false;
}

/*******************************************************************************
*	brief 	handle the slave PM Bus application
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
void SlvPMBusTxInit(u8_t u8rdaddr)
{
	u8_t u8devIndex = 0;

	sSlvPMBusAppStruct.u8rdAddr = u8rdaddr;

    if(sSlvPMBusAppStruct.u16flags & SI2CPMBUS_CMD_IDLE)
    {
    	SlvPMBusSetErrorCode(SI2CPMBUS_OK, 0);
    	//
    }
    else
    {
    	sSlvPMBusAppStruct.u8txpacketSize = 0;
    	sSlvPMBusAppStruct.u8txpacketLen = 0;

    	sSlvPMBusAppStruct.u16flags &= ~SI2CPMBUS_WRITE_PACKET;

    	/*blret = IsBscI2cAddr2(sSlvPMBusAppStruct.u8rdAddr&0xFE);
    	if(blret == false)
    	{
    		blret = SlvPMBusAddrSup(sSlvPMBusAppStruct.u8rdAddr, &u8devIndex);
    	}

    	if(blret == false)
    	{
    		SlvPMBusSetErrorCode(SI2CPMBUS_ERROR_CMD_NOT_SUPPORTED, SI2CPMBUS_ERROR_CMD | SI2CPMBUS_ERROR_CMD_NOT_SUP);
    	}
    	*/

    	if(((SlvPMBusAddrSup(u8rdaddr, &u8devIndex))==false)&&(IsBscI2cAddr2(u8rdaddr&0xFE)==false))
    	{
    		SlvPMBusSetErrorCode(SI2CPMBUS_ERROR_CMD_NOT_SUPPORTED, SI2CPMBUS_ERROR_CMD | SI2CPMBUS_ERROR_CMD_NOT_SUP);
    	}
    	//if((SlvPMBusAddrSup(sSlvPMBusAppStruct.u8rdAddr, &u8devIndex))==false)
    	//{
    	//	SlvPMBusSetErrorCode(SI2CPMBUS_ERROR_CMD_NOT_SUPPORTED, SI2CPMBUS_ERROR_CMD | SI2CPMBUS_ERROR_CMD_NOT_SUP);
    	//}
    	else
    	{
        	if(sSlvPMBusAppStruct.u8CmdType == PMBusCT_NoSupp)
        	{
        		SlvPMBusSetErrorCode(SI2CPMBUS_ERROR_CMD_NOT_SUPPORTED, SI2CPMBUS_ERROR_CMD | SI2CPMBUS_ERROR_CMD_NOT_SUP);
        	}
            //if cmd does not support read, set error
            else if((sSlvPMBusAppStruct.u8CmdType == PMBusCT_WrnBytes) || (sSlvPMBusAppStruct.u8CmdType == PMBusCT_BlockWr))
            {
            	SlvPMBusSetErrorCode(SI2CPMBUS_ERROR_CMD_NOT_SUPPORTED, SI2CPMBUS_ERROR_CMD | SI2CPMBUS_ERROR_CMD_NOT_SUP);
            }
            else
            {
            	if((SlvParseRdCmdSup(u8rdaddr, u8devIndex))==false)
            	{
            		SlvPMBusSetErrorCode(SI2CPMBUS_ERROR_CMD_NOT_SUPPORTED, SI2CPMBUS_ERROR_CMD | SI2CPMBUS_ERROR_CMD_NOT_SUP);
            	}
            	else
            	{
            		if((sSlvPMBusAppStruct.u8CmdType == PMBusCT_BlockRd) || (sSlvPMBusAppStruct.u8CmdType == PMBusCT_BlockRdWr) ||
            			(sSlvPMBusAppStruct.u8CmdType == PMBusCT_BWrBRdProCall))
            		{
            			memmove(sSlvPMBusAppStruct.pu8txBuff+1,sSlvPMBusAppStruct.pu8txBuff,sSlvPMBusAppStruct.u8txpacketSize);
            			sSlvPMBusAppStruct.pu8txBuff[0] = sSlvPMBusAppStruct.u8txpacketSize;
            			sSlvPMBusAppStruct.u8txpacketSize += 1;
            		}
            		SlvPBus_PEC(u8rdaddr);
            	}
            }
    	}
    }
}
/*******************************************************************************
*	brief 	handle the slave PM Bus application
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
u16_t SlvPMBusTxPase(u8_t* pu8sendData)
{
	if(sSlvPMBusAppStruct.u8txpacketLen < sSlvPMBusAppStruct.u8txpacketSize)
	{
		SlvPBus_PEC(sSlvPMBusAppStruct.pu8txBuff[sSlvPMBusAppStruct.u8txpacketLen]);
		*pu8sendData = sSlvPMBusAppStruct.pu8txBuff[sSlvPMBusAppStruct.u8txpacketLen++];
	}
	else
	{
		if(sSlvPMBusAppStruct.u8txpacketSize == 0)
		{
			*pu8sendData = SI2CPMBUS_BYTE_EOF;
			SlvPMBusSetErrorCode(SI2CPMBUS_ERROR_TRANSMITED_TOO_MANY_BYTES, SI2CPMBUS_ERROR_CMD | SI2CPMBUS_ERROR_DATA);
		}
		else
		{
			if(((sSlvPMBusAppStruct.u16flags & SI2CPMBUS_PEC_SENT) == 0) && (SI2CPMBUS_SUPPORT_PEC))
			{
				*pu8sendData = SlvPBus_GetPEC();
				sSlvPMBusAppStruct.u16flags |= SI2CPMBUS_PEC_SENT;
			}
			else
			{
				//
				*pu8sendData = SI2CPMBUS_BYTE_EOF;
				SlvPMBusSetErrorCode(SI2CPMBUS_ERROR_TRANSMITED_TOO_MANY_BYTES, SI2CPMBUS_ERROR_CMD | SI2CPMBUS_ERROR_DATA);
			}
		}

	}

	return(sSlvPMBusAppStruct.u16flags&SI2CPMBUS_ERROR_CMD);
}
/*******************************************************************************
*	brief 	handle the slave PM Bus application
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
void SlvPMBusRxInit(u8_t u8recByte)
{
	SlvPMBusSetErrorCode(SI2CPMBUS_OK, 0);

	sSlvPMBusAppStruct.u8wrAddr = u8recByte;

    //initialize state machine to receive packet,
	sSlvPMBusAppStruct.u16flags = SI2CPMBUS_CMD_INIT;	//and also clears IDLE flag
	sSlvPMBusAppStruct.u8rxpacketLen = 0;
    SlvPBus_PEC_Init();
    SlvPBus_PEC(u8recByte);

}
/*******************************************************************************
*	brief 	handle the slave PM Bus application
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
u16_t SlvPMBusRxPase(u8_t u8recByte)
{
	u8_t u8SendByteState = 0;

    if(sSlvPMBusAppStruct.u16flags & SI2CPMBUS_CMD_INITIALIZED)
    {
    	//cmd supports block write or block write-block read process call
        if((sSlvPMBusAppStruct.u8CmdType == PMBusCT_BlockWr) || (sSlvPMBusAppStruct.u8CmdType == PMBusCT_BWrBRdProCall) ||
        	(sSlvPMBusAppStruct.u8CmdType == PMBusCT_BlockRdWr))
        {
        	if(sSlvPMBusAppStruct.u8rxpacketSize == 0)
        	{
        		sSlvPMBusAppStruct.u8rxpacketSize = u8recByte + 1;
        	}
        }
        else if(sSlvPMBusAppStruct.u8CmdType == PMBusCT_SendByte)
        {
        	u8SendByteState = 1;	//example Clear_Faults,Store_Default_All
        }

        if((sSlvPMBusAppStruct.u8rxpacketSize == 0)&&(u8SendByteState == 0))
        {
        	SlvPMBusSetErrorCode(SI2CPMBUS_ERROR_RECEIVED_MORE_BYTES, SI2CPMBUS_ERROR_CMD | SI2CPMBUS_ERROR_DATA);
        }
        else
        {
            if(sSlvPMBusAppStruct.u8rxpacketLen < sSlvPMBusAppStruct.u8rxpacketSize)
            {
            	sSlvPMBusAppStruct.pu8rxBuff[sSlvPMBusAppStruct.u8rxpacketLen++] = u8recByte;
            	SlvPBus_PEC(u8recByte);
            }
            else
            {
            	if(((sSlvPMBusAppStruct.u16flags & SI2CPMBUS_PEC_SENT) == 0) && (SI2CPMBUS_SUPPORT_PEC))
            	{
            		sSlvPMBusAppStruct.u16flags |= SI2CPMBUS_PEC_SENT;
            		if(u8recByte != SlvPBus_GetPEC())
            		{
            			SlvPMBusSetErrorCode(SI2CPMBUS_ERROR_RECEIVED_INVALID_PEC, SI2CPMBUS_ERROR_CMD | SI2CPMBUS_ERROR_PEC);
            			UpdateBscStatusCML(0x20, 1);
            		}
            		else
            		{
            			//store data to buffer..
            		}
            	}
            	else
            	{
            		SlvPMBusSetErrorCode(SI2CPMBUS_ERROR_RECEIVED_MORE_BYTES, SI2CPMBUS_ERROR_CMD | SI2CPMBUS_ERROR_DATA);
            	}

            }
        }
    }
    else
    {
    	sSlvPMBusAppStruct.u16flags = SI2CPMBUS_CMD_INIT | SI2CPMBUS_CMD_INITIALIZED | SI2CPMBUS_WRITE_PACKET;
    	SlvPMBusDecodeCmd(u8recByte);

    	if(sSlvPMBusAppStruct.u8CmdType == PMBusCT_NoSupp)
    	{
    		sSlvPMBusAppStruct.u8rxpacketSize = 0;
    	    SlvPMBusSetErrorCode(SI2CPMBUS_ERROR_CMD_NOT_SUPPORTED, SI2CPMBUS_ERROR_CMD | SI2CPMBUS_ERROR_CMD_NOT_SUP);
    	    UpdateBscStatusCML(0x80, 1);
    	}
        //if cmd does not support write, set error
        else if((sSlvPMBusAppStruct.u8CmdType == PMBusCT_RdnBytes) || (sSlvPMBusAppStruct.u8CmdType == PMBusCT_BlockRd))
        {
        	sSlvPMBusAppStruct.u8rxpacketSize = 0;
        	SlvPBus_PEC(u8recByte);
        	//SlvPMBusSetErrorCode(SI2CPMBUS_ERROR_CMD_NOT_SUPPORTED, SI2CPMBUS_ERROR_CMD | SI2CPMBUS_ERROR_CMD_NOT_SUP);
        }
    	else
    	{
    		//only block write does not have packet size initialized
            if((sSlvPMBusAppStruct.u8CmdType == PMBusCT_BlockWr) || (sSlvPMBusAppStruct.u8CmdType == PMBusCT_BWrBRdProCall) ||
            	(sSlvPMBusAppStruct.u8CmdType == PMBusCT_BlockRdWr))
            {
            	sSlvPMBusAppStruct.u8rxpacketSize = 0;
            }

    	    SlvPBus_PEC(u8recByte);
    	}
    }

    return(sSlvPMBusAppStruct.u16flags&SI2CPMBUS_ERROR_CMD);

}
/****************************************************************************
*	name        : Init_SlvPMBus
*	description :
*	return      : none
****************************************************************************/
void Init_SlvPMBus(void)
{
    /* Initialize struct */
    memset(&sSlvPMBusAppStruct, 0, sizeof(sSlvPMBusAppStr_t));

    sSlvPMBusAppStruct.u16flags = SI2CPMBUS_CMD_IDLE;

}
/****************************************************************************
*	name        : SlvPMBusTimeout
*	description :
*	return      : none
****************************************************************************/
bool SlvPMBusTimeout(uint32_t u32instance, u8_t rangeaddrEnabled)
{
	i2c_status_t status;

    if(u8SlavePMBusTimeoutTimer != SI2CPMBusTimeOut10ms)
    {
    	u8SlavePMBusTimeoutTimer = SI2CPMBusTimeOut10ms;

    	status = SlaveI2cBustimeout(u32instance, SI2CPMBUS_TIMEOUT);
    	if (status == kStatus_I2C_Timeout)
    	{
    		DeInit_SlaveI2c(u32instance);
    		if(rangeaddrEnabled)
    		{
    			Init_SlaveI2c(u32instance, true);
    		}
    		else
    		{
    			Init_SlaveI2c(u32instance, false);
    		}
    	    return true;
    	}
    }

    status = SlaveI2cBusSCLtimeout(u32instance);
    if(status == kStatus_I2C_Fail)
    {
		DeInit_SlaveI2c(u32instance);
		if(rangeaddrEnabled)
		{
			Init_SlaveI2c(u32instance, true);
		}
		else
		{
			Init_SlaveI2c(u32instance, false);
		}
	    return true;
    }

    return false;
}
/****************************************************************************
*	name        : SlvPMBusReset
*	description :
*	return      : none
****************************************************************************/
void SlvPMBusReset(u8_t rangeaddrEnabled)
{
    bool bstatus;

    bstatus = SlvPMBusTimeout(HW_I2C0, rangeaddrEnabled);
    if (bstatus == true)
    {
    	//TURN_TGL_MTEST();
    	Init_SlvPMBus();
    }
}
/****************************************************************************
*	name        : SlvPMBusStop
*	description :
*	return      : none
****************************************************************************/
void SlvPMBusStop(void)
{
	u8_t u8devIndex = 0, u8SendByteState = 0;

	if(sSlvPMBusAppStruct.u8CmdType == PMBusCT_SendByte)
	{
		u8SendByteState = 1;
	}

	if(sSlvPMBusAppStruct.u16flags & SI2CPMBUS_CMD_INIT)
	{
		if(sSlvPMBusAppStruct.u8txpacketLen < sSlvPMBusAppStruct.u8txpacketSize)
		{
			SlvPMBusSetErrorCode(SI2CPMBUS_ERROR_TRANSMITED_NOT_ENOUGH_BYTES, SI2CPMBUS_ERROR_CMD | SI2CPMBUS_ERROR_DATA);
		}

		if((sSlvPMBusAppStruct.u16flags & SI2CPMBUS_ERROR_CMD) == 0)
		{
			if((u8SendByteState == 1) || ((sSlvPMBusAppStruct.u8rxpacketSize != 0) && (sSlvPMBusAppStruct.u8rxpacketLen == sSlvPMBusAppStruct.u8rxpacketSize)))
			//if((sSlvPMBusAppStruct.u8rxpacketSize != 0) && (sSlvPMBusAppStruct.u8rxpacketLen == sSlvPMBusAppStruct.u8rxpacketSize))
			{
				if(IsBscWrCmdSup(sSlvPMBusAppStruct.u8wrAddr, sSlvPMBusAppStruct.u8CmdCode) == true)
    			{
					if((sSlvPMBusAppStruct.u8CmdType == PMBusCT_ProCall) || (sSlvPMBusAppStruct.u8CmdType == PMBusCT_RdWrnBytes) ||
					   (sSlvPMBusAppStruct.u8CmdType == PMBusCT_WrnBytes))
					{
						ParseBscWrCmdSup(sSlvPMBusAppStruct.u8wrAddr, sSlvPMBusAppStruct.u8CmdCode, &sSlvPMBusAppStruct.pu8rxBuff[0], sSlvPMBusAppStruct.u8rxpacketLen);
					}
					else if((sSlvPMBusAppStruct.u8CmdType == PMBusCT_BWrBRdProCall) || (sSlvPMBusAppStruct.u8CmdType == PMBusCT_BlockRdWr) ||
							(sSlvPMBusAppStruct.u8CmdType == PMBusCT_BRdBWr_Wrnbytes))
					{
						ParseBscWrCmdSup(sSlvPMBusAppStruct.u8wrAddr, sSlvPMBusAppStruct.u8CmdCode, &sSlvPMBusAppStruct.pu8rxBuff[1], sSlvPMBusAppStruct.u8rxpacketLen-1);
					}
					else if(sSlvPMBusAppStruct.u8CmdType == PMBusCT_SendByte)
					{
						ParseBscWrCmdSup(sSlvPMBusAppStruct.u8wrAddr, sSlvPMBusAppStruct.u8CmdCode, &sSlvPMBusAppStruct.pu8rxBuff[0], 0);
						//ParseBbuWrCmdSup(u8devIndex, sSlvPMBusAppStruct.u8CmdCode, &sSlvPMBusAppStruct.pu8rxBuff[0], 0);
					}

    			}
    			else
    			{
    				if((SlvPMBusAddrSup(sSlvPMBusAppStruct.u8wrAddr, &u8devIndex))==false)
    				{
    					SlvPMBusSetErrorCode(SI2CPMBUS_ERROR_CMD_NOT_SUPPORTED, SI2CPMBUS_ERROR_CMD | SI2CPMBUS_ERROR_CMD_NOT_SUP);
    				}
    				else
    				{
    					if((sSlvPMBusAppStruct.u8CmdType == PMBusCT_ProCall) || (sSlvPMBusAppStruct.u8CmdType == PMBusCT_RdWrnBytes) ||
    					   (sSlvPMBusAppStruct.u8CmdType == PMBusCT_WrnBytes))
    					{
    						ParseBbuWrCmdPushWrData(u8devIndex, sSlvPMBusAppStruct.u8CmdCode, &sSlvPMBusAppStruct.pu8rxBuff[0], sSlvPMBusAppStruct.u8rxpacketLen);
    						//ParseBbuWrCmdSup(u8devIndex, sSlvPMBusAppStruct.u8CmdCode, &sSlvPMBusAppStruct.pu8rxBuff[0], sSlvPMBusAppStruct.u8rxpacketLen);
    					}
    					else if((sSlvPMBusAppStruct.u8CmdType == PMBusCT_BWrBRdProCall) || (sSlvPMBusAppStruct.u8CmdType == PMBusCT_BlockRdWr) ||
    							(sSlvPMBusAppStruct.u8CmdType == PMBusCT_BRdBWr_Wrnbytes))
    					{
    						ParseBbuWrCmdPushWrData(u8devIndex, sSlvPMBusAppStruct.u8CmdCode, &sSlvPMBusAppStruct.pu8rxBuff[1], sSlvPMBusAppStruct.u8rxpacketLen-1);
    						//ParseBbuWrCmdSup(u8devIndex, sSlvPMBusAppStruct.u8CmdCode, &sSlvPMBusAppStruct.pu8rxBuff[1], sSlvPMBusAppStruct.u8rxpacketLen-1);
    					}
    					else if(sSlvPMBusAppStruct.u8CmdType == PMBusCT_SendByte)
    					{
    						ParseBbuWrCmdPushWrData(u8devIndex, sSlvPMBusAppStruct.u8CmdCode, &sSlvPMBusAppStruct.pu8rxBuff[0], 0);
    						//ParseBbuWrCmdSup(u8devIndex, sSlvPMBusAppStruct.u8CmdCode, &sSlvPMBusAppStruct.pu8rxBuff[0], 0);
    					}
    				}
    			}
			}
		}

		if(sSlvPMBusAppStruct.u16flags & SI2CPMBUS_WRITE_PACKET)
		{

			{
				//perform packet....
			}
		}


	}

	//Init_SlvPMBus();
	//clear all packet flag,
	sSlvPMBusAppStruct.u16flags = SI2CPMBUS_CMD_IDLE;
	sSlvPMBusAppStruct.u8rxpacketLen = 0;
	sSlvPMBusAppStruct.u8rxpacketSize = 0;
	sSlvPMBusAppStruct.u8txpacketLen = 0;
	sSlvPMBusAppStruct.u8txpacketSize = 0;
	sSlvPMBusAppStruct.u8CmdType = PMBusCT_NoSupp;
}

/****************************************************************************
*	name        : SlvPMBusProcess
*	description :
*	return      : none
****************************************************************************/
void SlvPMBusProcess(void)
{
	assert(HW_I2C0 < HW_I2C_INSTANCE_COUNT);

	u32_t u32baseAddr = gl_i2cBaseAddr[HW_I2C0];

	bool  busy = I2C_HAL_GetStatusFlag(u32baseAddr, kI2CBusBusy);

	if (GetSlaveI2cIdleFlage(HW_I2C0) == false)
	{
		if (!busy)
		{
			SlvPMBusStop();
			//finish I2C transfers
			SlaveI2cBusCompletetransfer(HW_I2C0);
			//
			ClearSlvDisconnectCount();

		}
	}
}

