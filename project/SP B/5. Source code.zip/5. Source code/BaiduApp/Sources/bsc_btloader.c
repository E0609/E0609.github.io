/****************************************************************************
*	file	bsc_btloader.c
*	brief
*
*	author allen.lee
* 	version 1.0
*		-	2015/10/01: initial version by allen lee
*
****************************************************************************/
#include "fsl_device_registers.h"
#include "hwtimer.h"
#include "board.h"
#include "i2c_master.h"
#include "i2c_slave.h"
#include "usb_hid_device.h"
#include "pmbus_linearformat.h"
#include "bsc_btloader.h"
#include "macro_define.h"

#if (BAIDU_BT)
/****************************************************************************
*   Declared Structures & Variables
****************************************************************************/
__attribute__((section(".commram_data"))) sCommonRam_t	tsCommonRam;

/****************************************************************************
*	name        : init_interrupts
*	description :
*	return      :
****************************************************************************/
void init_interrupts(void)
{
    // Clear any IRQs that may be enabled, we only want the IRQs we enable to be active
    NVIC_ClearEnabledIRQs();

    // Clear any pending IRQs that may have been set
    NVIC_ClearAllPendingIRQs();
}
/****************************************************************************
*	name        : Init_CommomRam
*	description :
*	return      : none
****************************************************************************/
void Init_CommomRam(void)
{
	u16_t i;

	tsCommonRam.u16EntryBootKey = 0;

	for(i=0; i<7; i++)
	{
		tsCommonRam.NA[i] = 0;
	}

/*    u16_t *myData = (u16_t *)0x20002FF0;
    //tsCommonRam.EntryBoot = 0x1234;
    if(*myData==0x1234)
    {
   // 	while(1);
    }
    else
    {
   // 	tsCommonRam.u16EntryBoot = 0x1234;
    }
*/
}
/****************************************************************************
*	name        : SetEnteryBootKeytoRam
*	description :
*	return      : none
****************************************************************************/
void SetEnteryBootKeytoRam(u16_t u16Key)
{
	tsCommonRam.u16EntryBootKey = u16Key;

}

/****************************************************************************
*	name        : jump_to_user_address_handler
*	description :
*	return      :
****************************************************************************/
void jump_to_user_address_handler(u32_t u32address, u32_t u32spointer)
{
	//disable all interrupt
	__disable_irq();

	init_interrupts();

	// De-initialize hardware such as disabling port clock gate
	DeInit_Usb();
	hardware_deinit();
	DeInit_SysTick();
	DeInit_MasterI2c(HW_I2C1);
#if (I2C_SLAVE_MASK)
	DeInit_SlaveI2c(HW_I2C0);
#endif

	static u32_t u32stackPointer = 0;
	u32stackPointer = u32spointer;
	static void (*farewellpresentmode)(void) = 0;
	farewellpresentmode = (void (*)(void))u32address;

    // Set stack pointers to the application stack pointer.
    __set_MSP(u32stackPointer);
    // Jump to the application.
    farewellpresentmode();

}


/****************************************************************************
*	name        : GiveFarewellMessage
*	description :
*	return      : none
****************************************************************************/
void GiveFarewellMessage(void)
{
	u32_t u32bootEntry = 0;
	u32_t u32bootStack = 0;

	SetEnteryBootKeytoRam(MAGIC_APP_KEY);

	NVIC_SystemReset();
	//u32bootStack = *(u32_t *)BOOT_FLASH_START_ADDRESS;
	//u32bootEntry = *(u32_t *)(BOOT_FLASH_START_VECTOR);
	//jump_to_user_address_handler(u32bootEntry, u32bootStack);

}

#endif /* BAIDU_BT */

