/****************************************************************************
*	file	bsc.h
*	brief	include bsc
*
*	author allen.lee
* 	version 1.0
*		-	2014/05/05: initial version by allen lee
*
****************************************************************************/

#ifndef BSC_H_
#define BSC_H_

#include "define.h"
#include "SysTime.h"
/****************************************************************************
*   Declared Macro
****************************************************************************/
#define BscLitenBus1ms		        gtMcuTimer.u8Sys1ms
//----------------------------------------------------------------------------

//----------------------------------------------
#pragma pack(1)
typedef struct _sBSCInformation_t
{
	u8_t u8Address;
	u8_t pu8UsbProtocolRev[6];
	//u8_t pu8FirmwareRev[10];
	//u8_t pu8PMBusProtocol[16];
} sBSCInformation_t;
#pragma pack( )

extern sBSCInformation_t tsBSC_Infor;
//----------------------------------------------------------------------------
#pragma pack(1)
typedef struct _sBSCManufacture_t
{
	//u8_t pu8Manufacture[10];
	//u8_t pu8Model[11];
	u8_t pu8HardwareRev[3];
	u8_t pu8SN[10];
	//u8_t pu8BarCode[15];
	//u8_t pu8Location[10];
	//u8_t pu8Date[10];

} sBSCManufacture_t;
#pragma pack( )

extern sBSCManufacture_t tsBSC_Manuf;
//----------------------------------------------------------------------------
typedef enum
{
	StartupMode = 0,
	OperatingMode,
	ConfirmingMode,
	StandbyMode,

}eTaskSchedule_t;
//----------------------------------------------
typedef union _nBscStr_Status_t
{
   struct
   {
        u8_t   u2TaskSchd	    :2;
        u8_t   u6NA				:6;
   } u8Bit;

   u8_t u8All;
} nBscStr_Status_t;
//----------------------------------------------
#pragma pack(1)
typedef struct _sBscStr_t {
	nBscStr_Status_t tnStatus;
	u8_t u8AddrIndex;
	u8_t u8TaskSchd;
	u8_t u8litenbus1msTimer;
	u16_t u16litenbusCnt;
    u16_t u16litenbustime_ms;
    u16_t u16litenbusStandbyCnt;

} sBscStr_t;
#pragma pack()
extern sBscStr_t tsBsc_Str;
//----------------------------------------------------------------------------
extern void Init_BscGpio(void);
extern void Init_BscGpioInConfirmingMode(void);
extern void Init_BscGpioInStandby(void);
extern void Init_BscRam(void);
extern void BscLitenBusProcess_InStartupMode(void);
extern void BscLitenBusProcess_InOperatingMode(void);
extern void BscLitenBusProcess_InConfirmingMode(void);
extern void BscLitenBusProcess_InStandbyMode(void);
extern void Init_BscGpioInReOperation(void);

extern void BscLitenBusProcess(void);
extern void ParseBscInforRdCmdSup(u8_t* pu8dstlen, u8_t* pu8dstbuff);
extern void ParseBscLabelRdCmdSup(u8_t* pu8dstlen, u8_t* pu8dstbuff);
#endif /* BSC_H_ */
