/****************************************************************************
*	file	i2cbitbang_pit.c
*	brief
*
*	author allen.lee
* 	version 1.0
*		-	2014/05/05: initial version by allen lee
*
****************************************************************************/
#include <string.h>
#include "board.h"
#include "E2pI2cPitApp.h"
#include "pit.h"

/****************************************************************************
 * Global Variables
 ****************************************************************************/
static sE2pi2cpit_master_t ti2cbb_master;
u8_t u8E2pI2cPit10msTimer;
u8_t u8E2pI2cPitTimeoutTimer;

/****************************************************************************
*	name        : i2cbb_master_Ismode
*	description :
*	return      : none
****************************************************************************/
u8_t i2cbb_master_Ismode(void)
{
	return(ti2cbb_master.u8mode);
}
/****************************************************************************
*	name        : i2cbb_master_wr_status
*	description :
*	return      : none
****************************************************************************/
u8_t i2cbb_master_wr_status(void)
{
	if(ti2cbb_master.u16out_count == ti2cbb_master.u16outlen)
	{
		return(kE2p_Free);
	}
	else
	{
		return(kE2p_TransmitedError);
	}

}
/****************************************************************************
*	name        : i2cbb_master_rd_status
*	description :
*	return      : none
****************************************************************************/
u8_t i2cbb_master_rd_status(void)
{
	if(ti2cbb_master.u16out_count == ti2cbb_master.u16outlen)
	{
		if(ti2cbb_master.u16int_count == ti2cbb_master.u16intlen)
		{
			return(kE2p_Free);
		}
		else
		{
			return(kE2p_ReceivedError);
		}
	}
	else
	{
		return(kE2p_TransmitedError);
	}

}
/****************************************************************************
*	name        : i2cbb_rd_irq_statemachine
*	description :
*	return      : none
****************************************************************************/
void i2cbb_rd_irq_statemachine(void)
{
	u8_t u8retval;

	switch(ti2cbb_master.u8status)
	{

		case kBB_irq_WrInit_1:
			I2cGpioSda_SetHi();
			I2cGpioScl_SetHi();
			ti2cbb_master.u8bit_count = 8;
			ti2cbb_master.u8status = kBB_irq_WrInit_2;
			break;

		case kBB_irq_WrInit_2:
			ti2cbb_master.u8status = kBB_irq_WrStart;
			break;

		case kBB_irq_WrStart:
			I2cGpioSda_SetLo();
			ti2cbb_master.u8status = kBB_irq_WrBit;
			break;

		case kBB_irq_WrBit:
			I2cGpioScl_SetLo();
			ti2cbb_master.u8status = kBB_irq_WrLoop;
			break;

		case kBB_irq_WrLoop:
			ti2cbb_master.u8bit_count--;
			if((ti2cbb_master.pu8outbuff[ti2cbb_master.u16out_count]>>ti2cbb_master.u8bit_count)&0x01)
			{
				I2cGpioSda_SetHi();
			}
			else
			{
				I2cGpioSda_SetLo();
			}
			I2cGpioScl_SetHi();
			if(ti2cbb_master.u8bit_count > 0)
			{
				ti2cbb_master.u8status = kBB_irq_WrBit;
			}
			else
			{
				ti2cbb_master.u16out_count += 1;
				ti2cbb_master.u8status = kBB_irq_RdAck_1;
			}
			break;

		case kBB_irq_RdAck_1:
			I2cGpioScl_SetLo();
			I2cGpioSda_SetLo();
			ti2cbb_master.u8status = kBB_irq_RdAck_2;
			break;

		case kBB_irq_RdAck_2:
			I2cGpioSda_SetDirInt();
			I2cGpioScl_SetHi();
			ti2cbb_master.u8status = kBB_irq_RdAck_3;
			break;

		case kBB_irq_RdAck_3:	//~40us
			I2cGpioScl_SetDirInt();
			u8retval = I2cGpioScl_GetLevel();
			if(u8retval)
			{
				u8retval = I2cGpioSda_GetLevel();
				I2cGpioScl_SetDirOut();
				I2cGpioScl_SetLo();
				I2cGpioSda_SetDirOut();
				I2cGpioSda_SetLo();

				if(u8retval == kbitbang_ack)
				{
					if(ti2cbb_master.u16out_count >= ti2cbb_master.u16outlen)
					{
						//read
						ti2cbb_master.u8status = kBB_irq_RdDtStart;
					}
					else if(ti2cbb_master.u16out_count >= (ti2cbb_master.u16outlen-1))
					{
						ti2cbb_master.u8status = kBB_irq_RdInit;
					}
					else
					{
						ti2cbb_master.u8bit_count = 8;
						ti2cbb_master.u8status = kBB_irq_WrBit;
					}
				}
				else	//nack
				{
					ti2cbb_master.u8status = kBB_irq_WrStop_1;
				}
			}
			else
			{
				I2cGpioScl_SetDirOut();
				I2cGpioSda_SetDirOut();
				ti2cbb_master.u8status = kBB_irq_WrStop_1;
			}
			break;


		case kBB_irq_RdInit:
			ti2cbb_master.u8status = kBB_irq_WrInit_1;
			break;

		case kBB_irq_RdDtStart:
			I2cGpioScl_SetLo();
			I2cGpioSda_SetDirInt();
			ti2cbb_master.u8data = 0;
			ti2cbb_master.u8bit_count = 8;
			ti2cbb_master.u8status = kBB_irq_RdDtBit;
			break;

		case kBB_irq_RdDtBit:
			I2cGpioScl_SetHi();
			ti2cbb_master.u8status = kBB_irq_RdDtLoop;
			break;

		case kBB_irq_RdDtLoop:
			I2cGpioScl_SetDirInt();
			u8retval = I2cGpioScl_GetLevel();
			if(u8retval)
			{
				ti2cbb_master.u8data <<= 1;
				u8retval = I2cGpioSda_GetLevel();
				ti2cbb_master.u8bit_count--;
				if(u8retval)
				{
					ti2cbb_master.u8data |= 0x01;
				}

				if(ti2cbb_master.u8bit_count > 0)
				{
					ti2cbb_master.u8status = kBB_irq_RdDtBit;
				}
				else
				{
					ti2cbb_master.pu8intbuff[ti2cbb_master.u16int_count++] = ti2cbb_master.u8data;
					ti2cbb_master.u8status = kBB_irq_WrAckBit_1;
				}

			}
			else
			{
				//error
				ti2cbb_master.u8status = kBB_irq_WrStop_1;
			}
			I2cGpioScl_SetDirOut();
			I2cGpioScl_SetLo();
			break;

		case kBB_irq_WrAckBit_1:
			I2cGpioSda_SetDirOut();
			if(ti2cbb_master.u16int_count >= ti2cbb_master.u16intlen)
			{
				I2cGpioSda_SetHi();
			}
			else
			{
				I2cGpioSda_SetLo();
			}
			I2cGpioScl_SetHi();
			ti2cbb_master.u8status = kBB_irq_WrAckBit_2;
			break;

		case kBB_irq_WrAckBit_2:
			I2cGpioScl_SetLo();
			I2cGpioSda_SetLo();
			if(ti2cbb_master.u16int_count >= ti2cbb_master.u16intlen)
			{
				ti2cbb_master.u8status = kBB_irq_WrStop_1;
			}
			else
			{
				ti2cbb_master.u8status = kBB_irq_RdDtStart;
			}
			break;

		case kBB_irq_WrStop_1:
			I2cGpioSda_SetDirOut();
			I2cGpioScl_SetDirOut();
			I2cGpioSda_SetLo();
			I2cGpioScl_SetLo();
			ti2cbb_master.u8status = kBB_irq_WrStop_2;
			break;

		case kBB_irq_WrStop_2:
			I2cGpioScl_SetHi();
			ti2cbb_master.u8status = kBB_irq_WrStop_3;
			break;

		case kBB_irq_WrStop_3:
			I2cGpioSda_SetHi();
			ti2cbb_master.u8status = kBB_irq_Wrapup;
			break;

		case kBB_irq_Wrapup:
			I2cGpioScl_SetHi();
			I2cGpioSda_SetHi();
			ti2cbb_master.u8status = kBB_irq_Idle;
			ti2cbb_master.u8mode = kbbmode_idle;
			ti2cbb_master.u8timeout_ms = 0;
			Stop_PitTimer(HW_PIT);
			break;

		case kBB_irq_Idle:

			break;

		default:

			break;
	}
}
/****************************************************************************
*	name        : i2cbb_wr_irq_statemachine
*	description :
*	return      : none
****************************************************************************/
void i2cbb_wr_irq_statemachine(void)
{
	u8_t u8retval;

	switch(ti2cbb_master.u8status)
	{

		case kBB_irq_WrInit_1:
			I2cGpioSda_SetHi();
			I2cGpioScl_SetHi();
			ti2cbb_master.u8bit_count = 8;
			ti2cbb_master.u8status = kBB_irq_WrInit_2;
			break;

		case kBB_irq_WrInit_2:
			ti2cbb_master.u8status = kBB_irq_WrStart;
			break;

		case kBB_irq_WrStart:
			I2cGpioSda_SetLo();
			ti2cbb_master.u8status = kBB_irq_WrBit;
			break;

		case kBB_irq_WrBit:
			I2cGpioScl_SetLo();
			ti2cbb_master.u8status = kBB_irq_WrLoop;
			break;

		case kBB_irq_WrLoop:
			ti2cbb_master.u8bit_count--;
			if((ti2cbb_master.pu8outbuff[ti2cbb_master.u16out_count]>>ti2cbb_master.u8bit_count)&0x01)
			{
				I2cGpioSda_SetHi();
			}
			else
			{
				I2cGpioSda_SetLo();
			}
			I2cGpioScl_SetHi();
			if(ti2cbb_master.u8bit_count > 0)
			{
				ti2cbb_master.u8status = kBB_irq_WrBit;
			}
			else
			{
				ti2cbb_master.u16out_count += 1;
				ti2cbb_master.u8status = kBB_irq_RdAck_1;
			}
			break;

		case kBB_irq_RdAck_1:
			I2cGpioScl_SetLo();
			I2cGpioSda_SetLo();
			ti2cbb_master.u8status = kBB_irq_RdAck_2;
			break;

		case kBB_irq_RdAck_2:
			I2cGpioSda_SetDirInt();
			I2cGpioScl_SetHi();
			ti2cbb_master.u8status = kBB_irq_RdAck_3;
			break;

		case kBB_irq_RdAck_3:	//~40us
			I2cGpioScl_SetDirInt();
			u8retval = I2cGpioScl_GetLevel();
			if(u8retval)
			{
				u8retval = I2cGpioSda_GetLevel();
				I2cGpioScl_SetDirOut();
				I2cGpioScl_SetLo();
				I2cGpioSda_SetDirOut();
				I2cGpioSda_SetLo();

				if(u8retval == kbitbang_ack)
				{
					if(ti2cbb_master.u16out_count >= ti2cbb_master.u16outlen)
					{
						ti2cbb_master.u8status = kBB_irq_WrStop_1;
					}
					else
					{
						ti2cbb_master.u8bit_count = 8;
						ti2cbb_master.u8status = kBB_irq_WrBit;
					}
				}
				else	//nack
				{
					ti2cbb_master.u8status = kBB_irq_WrStop_1;
				}
			}
			else
			{
				I2cGpioScl_SetDirOut();
				I2cGpioSda_SetDirOut();
				ti2cbb_master.u8status = kBB_irq_WrStop_1;
			}
			break;

		case kBB_irq_WrStop_1:
			I2cGpioSda_SetDirOut();
			I2cGpioScl_SetDirOut();
			I2cGpioSda_SetLo();
			I2cGpioScl_SetLo();
			ti2cbb_master.u8status = kBB_irq_WrStop_2;
			break;

		case kBB_irq_WrStop_2:
			I2cGpioScl_SetHi();
			ti2cbb_master.u8status = kBB_irq_WrStop_3;
			break;

		case kBB_irq_WrStop_3:
			I2cGpioSda_SetHi();
			ti2cbb_master.u8status = kBB_irq_Wrapup;
			break;

		case kBB_irq_Wrapup:
			I2cGpioScl_SetHi();
			I2cGpioSda_SetHi();
			ti2cbb_master.u8status = kBB_irq_Idle;
			ti2cbb_master.u8mode = kbbmode_idle;
			ti2cbb_master.u8timeout_ms = 0;
			Stop_PitTimer(HW_PIT);
			break;

		case kBB_irq_Idle:

			break;
		default:

			break;
	}
}
/****************************************************************************
*	name        : i2cbb_master_sendbytes
*	description :
*	return      : none
****************************************************************************/
u8_t i2cbb_master_sendbytes(u16_t u16bytelen, u16_t u16byteaddr, u16_t u16len, u8_t *pu8buff)
{
	if((u16bytelen == 0) || (u16len == 0))
	{
		return(kE2p_Transmited_NotEnoughBytes);
	}

	if((u16bytelen > E2P_MAX_BYTEADDR) || (u16len > E2P_MAX_WRITE_BYTES) || ((u16byteaddr+u16len) > E2P_END_ADDRESS))
	{
		return(kE2p_Transmited_TooManyBytes);
	}


	u16_t i=0;
	u8_t *pu8tempByteAddr, *pu8tempAddr;

	ti2cbb_master.pu8outbuff[i] = E2P_DEV_ADDRESS;
	i++;

	pu8tempByteAddr = &ti2cbb_master.pu8outbuff[i];
	pu8tempAddr = (u8_t *)&u16byteaddr;

	i += u16bytelen;
    while(u16bytelen--)
    {
        *pu8tempByteAddr = *pu8tempAddr;
        pu8tempByteAddr++;
        pu8tempAddr--;
    }

	memcpy(&ti2cbb_master.pu8outbuff[i], pu8buff, u16len);
	i += u16len;

	ti2cbb_master.u16outlen = i;
	ti2cbb_master.u16out_count = 0;

	ti2cbb_master.u8status = kBB_irq_WrInit_1;
	ti2cbb_master.u8mode = kbbmode_write;
	Start_PitTimer(HW_PIT);

	return(kE2p_Busy);
}
/****************************************************************************
*	name        : i2cbb_master_readbytes
*	description :
*	return      : none
****************************************************************************/
u8_t i2cbb_master_readbytes(u16_t u16bytelen, u16_t u16byteaddr, u16_t u16len, u8_t *pu8buff)
{
	if((u16bytelen == 0) || (u16len == 0))
	{
		return(kE2p_Received_NotEnoughBytes);
	}

	if((u16bytelen > E2P_MAX_BYTEADDR) || (u16len > E2P_MAX_READ_BYTES) || ((u16byteaddr+u16len) > E2P_END_ADDRESS))
	{
		return(kE2p_Received_TooManyBytes);
	}

	u16_t i=0;
	u8_t *pu8tempByteAddr, *pu8tempAddr;

	ti2cbb_master.pu8outbuff[i] = E2P_DEV_ADDRESS;
	i++;

	pu8tempByteAddr = &ti2cbb_master.pu8outbuff[i];
	pu8tempAddr = (u8_t *)&u16byteaddr;

	i += u16bytelen;
    while(u16bytelen--)
    {
        *pu8tempByteAddr = *pu8tempAddr;
        pu8tempByteAddr++;
        pu8tempAddr--;
    }

	ti2cbb_master.pu8outbuff[i] = E2P_DEV_ADDRESS | 0x01;
	i++;

	ti2cbb_master.u16outlen = i;
	ti2cbb_master.u16out_count = 0;

	ti2cbb_master.u16intlen = u16len;
	ti2cbb_master.u16int_count = 0;
	ti2cbb_master.pu8intbuff = pu8buff;

	ti2cbb_master.u8status = kBB_irq_WrInit_1;
	ti2cbb_master.u8mode = kbbmode_read;
	Start_PitTimer(HW_PIT);

	return(kE2p_Busy);

}
/****************************************************************************
*	name        : Init_E2pI2cBitBang
*	description :
*	return      : none
****************************************************************************/
void Init_E2pI2cBitBang(void)
{
	Stop_PitTimer(HW_PIT);
	ti2cbb_master.u8mode = kbbmode_idle;
	ti2cbb_master.u8status = kBB_irq_Idle;
	ti2cbb_master.u16out_count = 0;
	ti2cbb_master.u16int_count = 0;
	ti2cbb_master.u8timeout_ms = 0;

	//enable scl & sda gpio port
	I2cGpioSda_SetDirOut();
	I2cGpioScl_SetDirOut();

	//set scl & sda to high
	I2cGpioScl_SetHi();
	I2cGpioSda_SetHi();
}
/****************************************************************************
*	name        : E2pI2cBitBangReset
*	description :
*	return      : none
****************************************************************************/
void E2pI2cBitBangReset(void)
{
	if(u8E2pI2cPitTimeoutTimer != E2pI2cPitTimeOut10ms)
	{
		u8E2pI2cPitTimeoutTimer = E2pI2cPitTimeOut10ms;

		if(i2cbb_master_Ismode() != kbbmode_idle)
		{
			ti2cbb_master.u8timeout_ms += 1;
			if(ti2cbb_master.u8timeout_ms > E2PI2CPITTIMEOUT)
			{
				Init_E2pI2cBitBang();
			}
		}

	}
}

/****************************************************************************
*	name        : E2pi2cBitBangProcess
*	description :
*	return      : none
****************************************************************************/
#if 0
u8_t  u8gle2pbb_step = 0;
u8_t  u8gle2pbb_val = 0;
u16_t u16gle2pbb_addrlen = 0;
u16_t u16gle2pbb_addr = 0;
u16_t u16gle2pbb_wrlen = 0;
u16_t u16gle2pbb_rdlen = 0;
u8_t  pu8gle2pbb_wrbuff[10];
u8_t  pu8gle2pbb_rdbuff[10];


void E2pI2cBitBangProcess(void)
{
	if(u8E2pI2cPit10msTimer != E2pI2cPit10ms)
	{
		u8E2pI2cPit10msTimer = E2pI2cPit10ms;

		if(ti2cbb_master.u8mode != kbbmode_idle)
		{
			return;
		}

		switch(u8gle2pbb_step)
		{
			case 0:
				u16gle2pbb_addrlen = 1;
				u16gle2pbb_addr = 0x01;
				u16gle2pbb_wrlen = 1;
				u8gle2pbb_val = (u8gle2pbb_val+1)%255;
				pu8gle2pbb_wrbuff[0] = u8gle2pbb_val;

				i2cbb_master_sendbytes(u16gle2pbb_addrlen, u16gle2pbb_addr, u16gle2pbb_wrlen, pu8gle2pbb_wrbuff);
				u8gle2pbb_step = 1;
				break;

			case 1:
				u8gle2pbb_step = 2;
				break;

			case 2:
				u16gle2pbb_addrlen = 1;
				u16gle2pbb_addr = 0x01;
				u16gle2pbb_rdlen = 2;
				i2cbb_master_readbytes(u16gle2pbb_addrlen, u16gle2pbb_addr, u16gle2pbb_rdlen, pu8gle2pbb_rdbuff);

				u8gle2pbb_step = 3;
				break;
			case 3:
				if(pu8gle2pbb_rdbuff[0] == u8gle2pbb_val)
				{
					u8gle2pbb_step = 0;
				}
				else
				{
					u8gle2pbb_step = 4;
				}
				break;
			default:

				break;

		}
	}
}
#endif
