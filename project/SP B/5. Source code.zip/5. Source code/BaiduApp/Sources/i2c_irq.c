/****************************************************************************
*	file	I2C.c
*	brief	I2C master driver
*
*	author allen.lee
* 	version 1.0
*		-	2014/05/05: initial version by allen lee
*
****************************************************************************/
//#include "board.h"
#include "fsl_device_registers.h"
#include "fsl_i2c_hal.h"
#include "i2c_master.h"
#include "i2c_slave.h"
/****************************************************************************
*   Global Variables
****************************************************************************/
/* Table of base addresses for I2C instances. */
const uint32_t gl_i2cBaseAddr[HW_I2C_INSTANCE_COUNT] = I2C_BASE_ADDRS;

/* Pointer to runtime state structure.*/
void * gl_i2cStatePtr[HW_I2C_INSTANCE_COUNT] = { NULL };

/* Table to save i2c IRQ enum numbers defined in CMSIS header file. */
const IRQn_Type gl_i2cIrqId[HW_I2C_INSTANCE_COUNT] = I2C_IRQS;

/****************************************************************************
*	name        : i2c_irqhandler
*	description : Pass IRQ control to either the master or slave driver
*	return      : none
****************************************************************************/
static void i2c_irq_handler(uint32_t instance)
{
    assert(instance < HW_I2C_INSTANCE_COUNT);
    uint32_t baseAddr = gl_i2cBaseAddr[instance];

    if (I2C_HAL_IsMaster(baseAddr))
    {
        /* Master mode.*/
    	i2c_master_irq_handler(instance);
        //I2C_DRV_MasterIRQHandler(instance);
    }
    else
    {
        /* Slave mode.*/
    	i2c_slave_irq_handler(instance);
    	//i2c_master_irq_handler(instance);
    //    I2C_DRV_SlaveIRQHandler(instance);
    }

}
/****************************************************************************
*	name        : I2Cx_IRQHandler
*	description : Implementation of I2C2 handler named in startup code
*	return      : none
****************************************************************************/
/* Implementation of I2C0 handler named in startup code. */
void I2C0_IRQHandler(void)
{
    //i2c_irq_handler(HW_I2C0);
    i2c_slave_irq_handler(HW_I2C0);
}

/* Implementation of I2C1 handler named in startup code. */
void I2C1_IRQHandler(void)
{
	//i2c_irq_handler(HW_I2C1);
	i2c_master_irq_handler(HW_I2C1);
}


