/*
 * flash_driver.c
 *
 *  Created on: 2015/10/2
 *      Author: AllenCCLee
 */

#include <string.h>
#include <stdio.h>
#include "flash_driver.h"

void * gl_flashPtr = NULL;

/****************************************************************************
*	name        : flash_cache_clear
*	description :
*	return      : none
****************************************************************************/
void flash_cache_clear(sflash_memory_t * tsdriver)
{
	BW_MCM_PLACR_CFCC(MCM, 1);
}
/****************************************************************************
*	name        : flash_init
*	description : Init Flash memory
*	return      : none
****************************************************************************/
flash_status_t flash_init(sflash_memory_t * tsdriver)
{
    /* Exit if current instance is already initialized */
    if (gl_flashPtr)
    {
        return kStatus_FLASH_Success;
    }

	gl_flashPtr = tsdriver;

	tsdriver->u32PFlashBlockBase = PFLASH_BLOCK_BASE;
	tsdriver->u32PFlashTotalSize = PFLASH_TOTAL_SIZE;
	tsdriver->u32PFlashBlockCount = PFLASH_BLOCK_COUNT;
	tsdriver->u32PFlashSectorSize = PFLASH_BLOCK_SECTOR_SIZE;
	tsdriver->u8PFlashMargin = (u8_t)kMargin_FLASH_User;

	return kStatus_FLASH_Success;
}
/****************************************************************************
*	name        : flash_check_range
*	description : Init Flash memory
*	return      : none
****************************************************************************/
//__attribute__ ((section(".myram_func"))) flash_status_t flash_command_sequence(sflash_memory_t * tsdriver)
flash_status_t flash_command_sequence(sflash_memory_t * tsdriver)
{
	u8_t u8regValue;

    // clear RDCOLERR & ACCERR & FPVIOL flag in flash status register. Write 1 to clear
	HW_FTFA_FSTAT_WR(FTFA, BM_FTFA_FSTAT_RDCOLERR | BM_FTFA_FSTAT_ACCERR | BM_FTFA_FSTAT_FPVIOL);

	// clear CCIF bit
	HW_FTFA_FSTAT_WR(FTFA, BM_FTFA_FSTAT_CCIF);

    // Check CCIF bit of the flash status register, wait till it is set.
    // IP team indicates that this loop will always complete.
    while (!(BR_FTFA_FSTAT_CCIF(FTFA)));

    // Check error bits
    // Get flash status register value
    u8regValue = HW_FTFA_FSTAT_RD(FTFA);

    // checking access error
    if (u8regValue & BM_FTFA_FSTAT_ACCERR)
    {
        return kStatus_FLASH_AccessError;
    }
    // checking protection error
    else if (u8regValue & BM_FTFA_FSTAT_FPVIOL)
    {
        return kStatus_FLASH_ProtectionViolation;
    }
    // checking MGSTAT0 non-correctable error
    else if (u8regValue & BM_FTFA_FSTAT_MGSTAT0)
    {
        return kStatus_FLASH_CommandFailure;
    }

    return kStatus_FLASH_Success;
}
/****************************************************************************
*	name        : flash_check_range
*	description :
*	return      : none
****************************************************************************/
flash_status_t flash_check_range(sflash_memory_t * tsdriver, u32_t u32addr, u32_t u32len, u32_t u32align)
{
    if (tsdriver == NULL)
    {
        return kStatus_FLASH_InvalidArgument;
    }

    // Verify the start and length are alignmentBaseline aligned.
    if ((u32addr & (u32align - 1)) || (u32len & (u32align - 1)) || (u32len == 0))
    {
       return kStatus_FLASH_AlignmentError;
    //	return kStatus_FLASH_Success;//test
    }

    // check for valid range of the target addresses
    if ((u32addr < tsdriver->u32PFlashBlockBase) || ((u32addr+u32len) > (tsdriver->u32PFlashBlockBase + tsdriver->u32PFlashTotalSize)))
    {
        return kStatus_FLASH_AddressError;
    }

    return kStatus_FLASH_Success;
}
/****************************************************************************
*	name        : flash_read
*	description :
*	return      : none
****************************************************************************/
flash_status_t flash_read(u32_t u32addr, u32_t u32len, u8_t * pu8buffer)
{
    memcpy((void *)pu8buffer, (void *)u32addr, u32len);

    return kStatus_FLASH_Success;
}
/****************************************************************************
*	name        : flash_erase
*	description :
*	return      : none
****************************************************************************/
flash_status_t flash_erase(u32_t u32startaddr, u32_t u32len)
{
	flash_status_t returnCode = kStatus_FLASH_Success;

    u32_t u32endAddress;      // storing end address
    u32_t u32numberOfSectors;  // number of sectors calculated by endAddress

    sflash_memory_t * tsdriver = (sflash_memory_t *)gl_flashPtr;

	// Check the supplied address range.
	returnCode = flash_check_range(tsdriver, u32startaddr, u32len, PFLASH_ALIGMENT);
    if (returnCode)
    {
    	return(returnCode);
    }

    // calculating Flash end address
    u32endAddress = u32startaddr + u32len - 1;

    // re-calculate the endAddress and align it to the start of the next sector
    // which will be used in the comparison below
    if (u32endAddress % tsdriver->u32PFlashSectorSize)
    {
    	u32numberOfSectors = u32endAddress / tsdriver->u32PFlashSectorSize + 1;
        u32endAddress = u32numberOfSectors * tsdriver->u32PFlashSectorSize - 1;
    }

    while (u32startaddr <= u32endAddress)
    {
    	// preparing passing parameter to erase a flash block
    	HW_FTFA_FCCOB0_WR(FTFA, FTFA_ERASE_SECTOR);
    	HW_FTFA_FCCOB1_WR(FTFA, GET_BIT_16_23(u32startaddr));
    	HW_FTFA_FCCOB2_WR(FTFA, GET_BIT_8_15(u32startaddr));
    	HW_FTFA_FCCOB3_WR(FTFA, GET_BIT_0_7(u32startaddr));

    	/* calling flash command sequence function to execute the command */
    	returnCode = flash_command_sequence(tsdriver);

    	if(returnCode != kStatus_FLASH_Success)
    	{
    		break;
    	}
    	else
    	{
    		//Increment to the next sector
    		u32startaddr += tsdriver->u32PFlashSectorSize;
    	}
    }

    flash_cache_clear(tsdriver);

    return(returnCode);

}
/****************************************************************************
*	name        : flash_verify_erase
*	description :
*	return      : none
****************************************************************************/
flash_status_t flash_verify_erase(u32_t u32startaddr, u32_t u32len)
{
	flash_status_t returnCode = kStatus_FLASH_Success;

	sflash_memory_t * tsdriver = (sflash_memory_t *)gl_flashPtr;

	// Check the supplied address range.
	returnCode = flash_check_range(tsdriver, u32startaddr, u32len, PFLASH_ALIGMENT);
    if (returnCode)
    {
    	return(returnCode);
    }

#if FLASH_VERIFY_LITEON
    u32_t u32patternBuffer = 0;
    u32_t u32lengthInBytes = u32len;

    while (u32patternBuffer)
    {
    	flash_read(u32startaddr, PFLASH_ALIGMENT, (u8_t *)&u32patternBuffer);

    	if(u32patternBuffer != 0xffffffff)
    	{
    		returnCode = kStatus_FLASH_CommandFailure;
    		break;
    	}
    	else
    	{
    		// Increment to the next sector
    		u32patternBuffer = 0;
    		u32patternBuffer -= PFLASH_ALIGMENT;
    		u32startaddr += PFLASH_ALIGMENT;
    	}
    }
    return(returnCode);

#else

    uint32_t u32blockSize = tsdriver->u32PFlashTotalSize / tsdriver->u32PFlashBlockCount;
    uint32_t u32nextBlockStartAddress = u32startaddr + u32blockSize;

    uint32_t u32remainingBytes = u32len;
    while (u32remainingBytes)
    {
    	uint32_t u32verifyLength = u32nextBlockStartAddress - u32startaddr;
        if (u32verifyLength > u32remainingBytes)
        {
        	u32verifyLength = u32remainingBytes;
        }

        uint32_t u32numberOfPhrases = u32verifyLength / PFLASH_ALIGMENT;

        // Fill in verify section command parameters.
    	HW_FTFA_FCCOB0_WR(FTFA, FTFA_VERIFY_SECTION);
    	HW_FTFA_FCCOB1_WR(FTFA, GET_BIT_16_23(u32startaddr));
    	HW_FTFA_FCCOB2_WR(FTFA, GET_BIT_8_15(u32startaddr));
    	HW_FTFA_FCCOB3_WR(FTFA, GET_BIT_0_7(u32startaddr));
    	HW_FTFA_FCCOB4_WR(FTFA, GET_BIT_8_15(u32numberOfPhrases));
    	HW_FTFA_FCCOB5_WR(FTFA, GET_BIT_0_7(u32numberOfPhrases));
    	HW_FTFA_FCCOB6_WR(FTFA, tsdriver->u8PFlashMargin);

        // calling flash command sequence function to execute the command
        returnCode = flash_command_sequence(tsdriver);
        if(returnCode != kStatus_FLASH_Success)
        {
        	break;
        }
    	else
    	{
    		// Increment to the next sector
    		u32remainingBytes -= u32verifyLength;
            u32startaddr += u32verifyLength;
            u32nextBlockStartAddress += u32blockSize;
    	}

    }
    return(returnCode);
#endif
}

/****************************************************************************
*	name        : flash_program
*	description :
*	return      : none
****************************************************************************/
flash_status_t flash_program(uint32_t u32startaddr, uint8_t * pu8src, uint32_t u32lengthInBytes)
{
    if (pu8src == NULL)
    {
        return kStatus_FLASH_InvalidArgument;
    }

    sflash_memory_t * tsdriver = (sflash_memory_t *)gl_flashPtr;

    // Check the supplied address range.
    flash_status_t returnCode = flash_check_range(tsdriver, u32startaddr, u32lengthInBytes, PFLASH_ALIGMENT);
    if (returnCode)
    {
        return returnCode;
    }

    while (u32lengthInBytes > 0)
    {
    	// preparing passing parameter to program the flash block
    	HW_FTFA_FCCOB0_WR(FTFA, FTFA_PROGRAM_LONGWORD);
    	HW_FTFA_FCCOB1_WR(FTFA, GET_BIT_16_23(u32startaddr));
    	HW_FTFA_FCCOB2_WR(FTFA, GET_BIT_8_15(u32startaddr));
    	HW_FTFA_FCCOB3_WR(FTFA, GET_BIT_0_7(u32startaddr));
    	HW_FTFA_FCCOB4_WR(FTFA, *(pu8src+3));
    	HW_FTFA_FCCOB5_WR(FTFA, *(pu8src+2));
    	HW_FTFA_FCCOB6_WR(FTFA, *(pu8src+1));
    	HW_FTFA_FCCOB7_WR(FTFA, *(pu8src));

        // calling flash command sequence function to execute the command
        returnCode = flash_command_sequence(tsdriver);

        // checking for the success of command execution
        if (kStatus_FLASH_Success != returnCode)
        {
            break;
        }
        else
        {
            // update start address for next iteration
        	u32startaddr += PFLASH_ALIGMENT;
            pu8src += PFLASH_ALIGMENT;

            // update lengthInBytes for next iteration
            u32lengthInBytes -= PFLASH_ALIGMENT;
        }
    }

    flash_cache_clear(tsdriver);

    return(returnCode);

}
/****************************************************************************
*	name        : flash_verify_program
*	description :
*	return      : none
****************************************************************************/
flash_status_t flash_verify_program(uint32_t u32startaddr, uint32_t u32lengthInBytes,
		uint8_t * pu8expectedData, uint32_t * u32failedAddress, uint32_t * u32failedData)
{
    if (pu8expectedData == NULL)
    {
        return kStatus_FLASH_InvalidArgument;
    }

    flash_status_t returnCode = kStatus_FLASH_Success;

    sflash_memory_t * tsdriver = (sflash_memory_t *)gl_flashPtr;

    returnCode = flash_check_range(tsdriver, u32startaddr, u32lengthInBytes, PFLASH_ALIGMENT);
    if (returnCode)
    {
        return returnCode;
    }

#if FLASH_VERIFY_LITEON
    u32_t u32patternBuffer;

    while (u32lengthInBytes)
    {
    	flash_read(u32startaddr, PFLASH_ALIGMENT, (u8_t *)&u32patternBuffer);

    	if(u32patternBuffer != (*(uint32_t *)pu8expectedData))
    	{
            if (u32failedAddress)
            {
                *u32failedAddress  =  u32startaddr;
            }
            if (u32failedData)
            {
                *u32failedData = (uint32_t)pu8expectedData;
            }

    		returnCode = kStatus_FLASH_CommandFailure;
    		break;
    	}
    	else
    	{
    		u32startaddr += PFLASH_ALIGMENT;
    		pu8expectedData += PFLASH_ALIGMENT;
            u32lengthInBytes -= PFLASH_ALIGMENT;
    	}
    }

    return(returnCode);
#else

    while (u32lengthInBytes)
    {
    	// preparing passing parameter to program check the flash block
    	HW_FTFA_FCCOB0_WR(FTFA, FTFA_PROGRAM_CHECK);
    	HW_FTFA_FCCOB1_WR(FTFA, GET_BIT_16_23(u32startaddr));
    	HW_FTFA_FCCOB2_WR(FTFA, GET_BIT_8_15(u32startaddr));
    	HW_FTFA_FCCOB3_WR(FTFA, GET_BIT_0_7(u32startaddr));
    	HW_FTFA_FCCOB4_WR(FTFA, tsdriver->u8PFlashMargin);
    	HW_FTFA_FCCOB8_WR(FTFA, *(pu8expectedData+3));
    	HW_FTFA_FCCOB9_WR(FTFA, *(pu8expectedData+2));
    	HW_FTFA_FCCOBA_WR(FTFA, *(pu8expectedData+1));
    	HW_FTFA_FCCOBB_WR(FTFA, *(pu8expectedData));

    	// calling flash command sequence function to execute the command
    	returnCode = flash_command_sequence(tsdriver);

    	// checking for the success of command execution
    	if (kStatus_FLASH_Success != returnCode)
    	{
            if (u32failedAddress)
            {
                *u32failedAddress  =  u32startaddr;
            }
            if (u32failedData)
            {
                *u32failedData = (uint32_t)pu8expectedData;
            }

            break;
    	}

    	u32startaddr += PFLASH_ALIGMENT;
        pu8expectedData += PFLASH_ALIGMENT;
        u32lengthInBytes -= PFLASH_ALIGMENT;

    }

    return(returnCode);
#endif
}
