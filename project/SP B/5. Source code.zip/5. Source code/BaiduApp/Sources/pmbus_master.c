/****************************************************************************
*	file	pmbus_master.c
*	brief	The file includes the function and data structure/variables
*		    for the PMBus protocol
*	author allen.lee
* 	version 1.0
*		-	2015/05/11: initial version by allen lee
*
****************************************************************************/

#include "i2c_master.h"
#include "i2c_irq.h"
#include "crc8.h"
#include "pmbus_master.h"
/****************************************************************************
*   Declared Structures & Variables
****************************************************************************/
u8_t u8MasterPMBusTimeoutTimer;

/****************************************************************************
*	name        : MstPMBusTimeout
*	description :
*	return      : none
****************************************************************************/
bool MstPMBusTimeout(uint32_t u32instance)
{
	i2c_status_t status;

    if(u8MasterPMBusTimeoutTimer != MasterPMBusTimeOut10ms)
    {
    	u8MasterPMBusTimeoutTimer = MasterPMBusTimeOut10ms;

    	status = MasterI2cBustimeout(u32instance, MASTER_PMBUS_TIMEOUT);
    	if (status == kStatus_I2C_Timeout)
    	{
    		DeInit_MasterI2c(u32instance);
    		Init_MasterI2c(u32instance);
    	    return true;
    	}

    }
    return false;
}

/****************************************************************************
*	name        : MstPMBusWriteNbyte
*	description :
*	return      : none
****************************************************************************/
bool MstPMBusWriteNbyte(u32_t instance, u16_t u16Addr, u8_t * pu8cmdBuff, u8_t * pu8txBuff, u8_t u8txSize)
{
	assert(instance < HW_I2C_INSTANCE_COUNT);
	si2c_master_t * master = (si2c_master_t *)gl_i2cStatePtr[instance];

	u8_t i, u8CRC8 = 0;
	u32_t u32BuffSize;

    /* Return if current instance is used */
    if (!master->i2cIdle)
    {
    	return false;
    }

    //if (u8txSize == 0)
    //{
    //	return false;
    //}

    master->ePMBusProtcol = WriteNbyte;
    master->tnPMBusSt.u8All &= 0x01;
    u32BuffSize = (u32_t)u8txSize;

    if (master->tnPMBusSt.u8Bit.u1PECSupport)
    {
    	CalCRC8(&u8CRC8, (u8_t)u16Addr<<1U);
    	CalCRC8(&u8CRC8, pu8cmdBuff[0]);

        for (i=0; i<u8txSize; i++)
        {
            CalCRC8(&u8CRC8, *(pu8txBuff+i));
        }
        *(pu8txBuff + u8txSize) = u8CRC8;

    	u32BuffSize += 1;	//n bytes + pec
    }

	if (MasterI2cSend(instance, u16Addr, pu8cmdBuff, 1, pu8txBuff, u32BuffSize) == true)
	{
		return true;
	}
	else
	{
		return false;
	}

}
/****************************************************************************
*	name        : MstPMBusBlockWrite
*	description :
*	return      : none
****************************************************************************/
bool MstPMBusBlockWrite(u32_t instance, u16_t u16Addr, u8_t * pu8cmdBuff, u8_t * pu8txBuff, u8_t* pu8txSize)
{
	assert(instance < HW_I2C_INSTANCE_COUNT);
	si2c_master_t * master = (si2c_master_t *)gl_i2cStatePtr[instance];

	u8_t i, u8CRC8 = 0;
	u32_t u32BuffSize;
	u8_t * pu8tempBuff;

    /* Return if current instance is used */
    if (!master->i2cIdle)
    {
    	return false;
    }

    if ((*pu8txSize) == 0)
    {
    	return false;
    }

    master->ePMBusProtcol = Block_WriteNbyte;
    master->tnPMBusSt.u8All &= 0x01;


    pu8tempBuff = pu8txBuff + (*pu8txSize);
    for(i=0; i<(*pu8txSize); i++)
    {
        *(pu8tempBuff-i) = *(pu8tempBuff-i-1);
    }
    *pu8txBuff = *pu8txSize;

    (*pu8txSize) += 1;	// n byte + byte count
    u32BuffSize = (u32_t)(*pu8txSize);
    if (master->tnPMBusSt.u8Bit.u1PECSupport)
    {
    	CalCRC8(&u8CRC8, (u8_t)u16Addr<<1U);
    	CalCRC8(&u8CRC8, pu8cmdBuff[0]);

        for (i=0; i<u32BuffSize; i++)	// n byte + byte count
        {
            CalCRC8(&u8CRC8, *(pu8txBuff+i));
        }

        *(pu8txBuff + u32BuffSize) = u8CRC8;

    	u32BuffSize += 1;	//(n bytes + byte count) + pec
    }

	if (MasterI2cSend(instance, u16Addr, pu8cmdBuff, 1, pu8txBuff, u32BuffSize) == true)
	{
		return true;
	}
	else
	{
		return false;
	}

}
/****************************************************************************
*	name        : MstPMBusReadNbyte
*	description :
*	return      : none
****************************************************************************/
bool MstPMBusReadNbyte(u32_t instance, u16_t u16Addr, u8_t * pu8cmdBuff, u8_t * pu8rxBuff, u8_t u8rxSize)
{
	assert(instance < HW_I2C_INSTANCE_COUNT);
	si2c_master_t * master = (si2c_master_t *)gl_i2cStatePtr[instance];
	u32_t u32BuffSize;

    if (!master->i2cIdle)
    {
    	return false;
    }

    if (u8rxSize == 0)
    {
    	return false;
    }

    master->ePMBusProtcol = ReadNbyte;
    master->tnPMBusSt.u8All &= 0x01;
    u32BuffSize = (u32_t)u8rxSize;

    if (master->tnPMBusSt.u8Bit.u1PECSupport)
    {
    	u32BuffSize += 1;	//n bytes + pec
    }

	if (MasterI2cReStartReceive(instance, u16Addr, pu8cmdBuff, 1, NULL, 0, pu8rxBuff, u32BuffSize) == true)
	{
		return true;
	}
	else
	{
		return false;
	}

}

/****************************************************************************
*	name        : MstPMBusBlockRead
*	description :
*	return      : none
****************************************************************************/
bool MstPMBusBlockRead(u32_t instance, u16_t u16Addr, u8_t * pu8cmdBuff, u8_t * pu8rxBuff, u8_t u8rxSize)
{
	assert(instance < HW_I2C_INSTANCE_COUNT);
	si2c_master_t * master = (si2c_master_t *)gl_i2cStatePtr[instance];
	u32_t u32RxSize;

    if (!master->i2cIdle)
    {
    	return false;
    }

    if (u8rxSize == 0)
    {
    	return false;
    }

    master->ePMBusProtcol = Block_ReadNbyte;
    master->tnPMBusSt.u8All &= 0x01;
    u32RxSize = PMBUS_MAX_PAYLOAD;

	if (MasterI2cReStartReceive(instance, u16Addr, pu8cmdBuff, 1, NULL, 0, pu8rxBuff, u32RxSize) == true)
	{
		return true;
	}
	else
	{
		return false;
	}

}
/****************************************************************************
*	name        : MstPMBusProcessCall
*	description :
*	return      : none
****************************************************************************/
bool MstPMBusProcessCall(u32_t instance, u16_t u16Addr, u8_t * pu8cmdBuff, u8_t * pu8txBuff, u8_t u8txSize, u8_t * pu8rxBuff, u8_t u8rxSize)
{
	assert(instance < HW_I2C_INSTANCE_COUNT);
	si2c_master_t * master = (si2c_master_t *)gl_i2cStatePtr[instance];
	u32_t u32BuffSize;

    if (!master->i2cIdle)
    {
    	return false;
    }

    if ((u8txSize == 0) || (u8rxSize == 0))
    {
    	return false;
    }

    master->ePMBusProtcol = ProcessCall;
    master->tnPMBusSt.u8All &= 0x01;
    u32BuffSize = (u32_t)u8rxSize;

    if (master->tnPMBusSt.u8Bit.u1PECSupport)
    {
    	u32BuffSize += 1;	//n bytes + pec
    }

	if (MasterI2cReStartReceive(instance, u16Addr, pu8cmdBuff, 1, pu8txBuff, (u32_t)u8txSize, pu8rxBuff, u32BuffSize) == true)
	{
		return true;
	}
	else
	{
		return false;
	}

}
/****************************************************************************
*	name        : MstPMBusBlockProcessCall
*	description :
*	return      : none
****************************************************************************/
bool MstPMBusBlockProcessCall(u32_t instance, u16_t u16Addr, u8_t * pu8cmdBuff, u8_t * pu8txBuff, u8_t* pu8txSize, u8_t * pu8rxBuff, u8_t u8rxSize)
{
	assert(instance < HW_I2C_INSTANCE_COUNT);
	si2c_master_t * master = (si2c_master_t *)gl_i2cStatePtr[instance];
	u32_t u32TxSize, u32RxSize;
	u8_t * pu8tempBuff;
	u8_t i;

    if (!master->i2cIdle)
    {
    	return false;
    }

    if ((*pu8txSize == 0) || (u8rxSize == 0))
    {
    	return false;
    }

    master->ePMBusProtcol = Block_ProcessCall;
    master->tnPMBusSt.u8All &= 0x01;


    pu8tempBuff = pu8txBuff+(*pu8txSize);
    for(i=0; i<(*pu8txSize); i++)
     {
         *(pu8tempBuff-i) = *(pu8tempBuff-i-1);
     }
    *pu8txBuff = *pu8txSize;

    *pu8txSize += 1;	// n byte + byte count
    u32TxSize = (u32_t)(*pu8txSize);
    u32RxSize = PMBUS_MAX_PAYLOAD;

	if (MasterI2cReStartReceive(instance, u16Addr, pu8cmdBuff, 1, pu8txBuff, u32TxSize, pu8rxBuff, u32RxSize) == true)
	{
		return true;
	}
	else
	{
		return false;
	}

}
