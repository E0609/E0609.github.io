/****************************************************************************
*	file	i2cgpio_master.h
*	brief	include bbu_led
*
*	author allen.lee
* 	version 1.0
*		-	2014/05/05: initial version by allen lee
*
****************************************************************************/

#ifndef I2CGPIO_MASTER_H_
#define I2CGPIO_MASTER_H_

#include "define.h"
#include "board.h"

/****************************************************************************
*   Declared Macro
****************************************************************************/
#define I2CGPIO_FREQUENCY 1000 //unit hz
//5usec while delay
#if (I2CGPIO_FREQUENCY == 10000)
	//50usec while delay
	#define I2C_BITBANG_DELAY() do {u32_t i; for(i=0; i<210; i++){__asm("nop");} } while(0)
#elif(I2CGPIO_FREQUENCY == 1000)
	//500usec while delay
	#define I2C_BITBANG_DELAY() do {u32_t i; for(i=0; i<1860; i++){__asm("nop");} } while(0)

#else

#endif
#define I2C_BITBANG_DELAY_5US() do {u32_t i; for(i=0; i<10; i++){__asm("nop");} } while(0)
#define I2C_BITBANG_DELAY_10US() do {u32_t i; for(i=0; i<35; i++){__asm("nop");} } while(0)
//----------------------------------------------------------------------------
typedef enum _i2cgpio_master_logic {
    kI2cGpioLo = 0U,
    kI2cGpioHi = 1U
} i2cgpio_master_logic_t;
//----------------------------------------------
typedef enum _i2cgpio_master_direction {
    kI2cGpioInt = 0U,
    kI2cGpioOut = 1U
} i2cgpio_master_direction_t;
//----------------------------------------------
typedef enum _i2cgpio_master_retstatus {
	kStatus_I2cgpio_Nack = -2,
	kStatus_I2cgpio_SclTimeout = -1,
	kStatus_I2cgpio_Success = 0,
} i2cgpio_master_retstatus_t;
//----------------------------------------------------------------------------

/****************************************************************************
*   Declared Export functions
****************************************************************************/
extern void i2c_gpio_start(void);
extern void i2c_gpio_stop(void);
extern void i2c_gpio_repstart(void);
extern i16_t i2c_gpio_sendbytes(u16_t u16len, u8_t *pu8buff);
extern i16_t i2c_gpio_readbytes(u16_t u16len, u8_t *pu8buff);
extern void Init_I2cGpioMaster(void);
//extern void Test_I2cGpioMaster(void);

#endif /* I2CGPIO_MASTER_H_ */
