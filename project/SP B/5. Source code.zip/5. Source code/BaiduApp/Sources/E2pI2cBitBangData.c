/****************************************************************************
*	file	E2pI2cBitBangData.c
*	brief
*
*	author allen.lee
* 	version 1.0
*		-	2014/05/05: initial version by allen lee
*
****************************************************************************/
#include <string.h>
#include "board.h"
#include "E2pI2cBitBangData.h"
#include "E2pI2cPitApp.h"
#include "PMBusData.h"

/****************************************************************************
*   Declared Structures & Variables
****************************************************************************/
u8_t u8E2PData10msTimer;
sE2pi2cbb_data_t tE2pData;

//----------------------------------------------
#if (E2PData_Table)
const u8_t pu8E2PDataDefault[E2PDATA_NUM] =
{
    '0', '.', '2',																//E2PDataRev, 3
    'L', 'i', 't', 'e', '-', 'O', 'n', ' ', ' ', ' ', 							//Manufacture, 10
    'B', 'P', '-', '1', '4', '4', '2', '-', '0', '1', 'X', 						//ModelName, 11
    '0', 'A', ' ', 																//HardwareRev, 3
    'Y', 'Y', 'W', 'W', 'S', 'S', 'S', 'S', 'S', 'S',							//SerialNum, 10
    '6', 'X', 'X', 'X', 'X', '0', '1', 'R', 'R', 'X', 'X', 'X', 'X', 'X', 'X',  //BarCode, 19
    ' ', ' ', ' ', ' ',
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00,                           				//Reserved, 6
    '1', '6', '0', '9', '2', '6', ' ', ' ', ' ', ' ', 							//Date, 10
    '0', '0', 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 								//FwCC, 8
    '0', '0', 																	//HwCC, 2
    'T', 'a', 'i', 'p', 'e', 'i', ' ', ' ', ' ', ' ',					        //Location, 10
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,           //Reserved, 11
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, //Reserved, 15
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, //Reserved, 15
    E2P_PWD0, E2P_PWD1,															//E2PPassword, 2

};
/*const u8_t pu8E2PDataDefault[E2PDATA_NUM] =
{
    '0', '.', '1',																//E2PDataRev
    'L', 'i', 't', 'e', '-', 'O', 'n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',	//Manufacture
    'B', 'P', '-', '1', '4', '4', '2', '-', '0', '1', 'X', ' ', ' ', ' ', ' ',	//ModelName
    '0', '3', 																	//HardwareRev
    'Y', 'Y', 'W', 'W', 'S', 'S', 'S', 'S', 'S', 'S',							//SeriealNum
    '6', 'X', 'X', 'X', 'X', '0', '1', 'R', 'R', 'X', 'X', 'X', 'X', 'X', 'X',  //BarCode
    'T', 'a', 'i', 'p', 'e', 'i', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',  //Location
    '1', '6', '0', '1', '2', '0', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',  //Date
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, //Reserved
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, //Reserved
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, //Reserved
    E2P_PWD0, E2P_PWD1,															//E2PPassword

};*/
#else
const u8_t pu8E2PDataDefault[E2PDATA_NUM] =
{
	0x00, 0x00, 0x00,																//E2PDataRev
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,	//Manufacture
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,	//ModelName
	0x00, 0x00, 																	//HardwareRev
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,							//SeriealNum
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  //BarCode
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  //Location
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  //Date
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, //Reserved
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, //Reserved
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, //Reserved
	0x00, 0x00,															//E2PPassword
};
#endif
/****************************************************************************
*	name        : ResetE2PData
*	description :
*	return      : none
****************************************************************************/
void ResetE2PData(void)
{
	tE2pData.tnStatus.u8All = 0;
	tE2pData.u16PushIndex = 0;
	tE2pData.u16WriteIndex = 0;
	u8E2PData10msTimer = 0;
}
/****************************************************************************
*	name        : E2PDataDefault
*	description :
*	return      : none
****************************************************************************/
void E2PDataDefault(void)
{
	u16_t i;

	//update eeprom data to ram buffer
	for(i=0; i<E2PDATA_NUM; i++)
	{
		tE2pData.pu8InRam[i] = pu8E2PDataDefault[i];
	}

	//write to eeprom
	for(i=0; i<=E2PDATA_NUM; i++)
	{
		if(tE2pData.u16PushIndex < E2PDATA_NUM)
		{
			tE2pData.pu16Index[tE2pData.u16PushIndex] = i;
			tE2pData.pu8Buff[tE2pData.u16PushIndex++] = tE2pData.pu8InRam[i];
		}
	}

}
/****************************************************************************
*	name        : ReadE2pData
*	description :
*	return      : none
****************************************************************************/
bool ReadE2PData(void)
{
#if 0
	u8_t u8readchk;
	u32_t i;

	u8readchk = 0;
	//TURN_TGL_MTEST();
	for(i=0; i<E2P_BITBANG_DELAY; i++)
	{
		if(i2cbb_master_Ismode() == kbbmode_idle)
		{
			if(u8readchk == 0)
			{
				i2cbb_master_readbytes(E2P_MAX_BYTEADDR, E2PDATA_START_ADDR, E2PDATA_NUM, tE2pData.pu8InRam);
				u8readchk = 1;
			}
			else
			{
				if(i2cbb_master_rd_status() == kE2p_Free)
				{
					return true;
				}
				else
				{
					return false;
				}

			}
		}
	}
	//TURN_TGL_MTEST();
	return false;
#else
	u8_t u8readchk;
	u32_t i;
	bool blret = false;

	u8readchk = 0;
	//TURN_TGL_MTEST();
	for(i=0; i<E2P_BITBANG_DELAY; i++)
	{
		if(i2cbb_master_Ismode() == kbbmode_idle)
		{
			if(u8readchk == 0)
			{
				if(tE2pData.tnStatus.u8Bit.u1ReadSt == E2pData_Read_Fault)
				{
					i2cbb_master_readbytes(E2P_MAX_BYTEADDR, E2PDATA_START_ADDR, E2PDATA_NUM, tE2pData.pu8InRam);
				}
				u8readchk = 1;
			}
			else
			{
				if(i2cbb_master_rd_status() == kE2p_Free)
				{
					blret = true;
				}
				else
				{

				}

			}
		}
	}
	//TURN_TGL_MTEST();
	return blret;
#endif


}

/****************************************************************************
*	name        : ReadE2pDataToRam
*	description :
*	return      : none
****************************************************************************/
bool ReadE2PDataToRam(void)
{
#if 0
	u8_t i;

    for(i=0;i<E2PDATA_BEGIN_READ;i++)
    {
    	if(ReadE2PData() == true)
    	{
#if (E2PData_Table)
    		if((tE2pData.pu8InRam[E2PPassword0] == E2P_PWD0) && (tE2pData.pu8InRam[E2PPassword1] == E2P_PWD1))
#else
    		if((tE2pData.pu8InRam[E2PPassword0] == 0x00) && (tE2pData.pu8InRam[E2PPassword1] == 0x00))
#endif
    		{
   		    	tE2pData.tnStatus.u8Bit.u1ReadSt = E2pData_Read_Success;
   		    	return true;
    		}
    	}
    }

    tE2pData.tnStatus.u8Bit.u1ReadSt = E2pData_Read_Fault;
    return false;
#else
	u8_t i;
	bool blret = false;
	tE2pData.tnStatus.u8Bit.u1ReadSt = E2pData_Read_Fault;

    for(i=0;i<E2PDATA_BEGIN_READ;i++)
    {
    	if(ReadE2PData() == true)
    	{
    		if (tE2pData.tnStatus.u8Bit.u1ReadSt == E2pData_Read_Fault)
    		{
				#if (E2PData_Table)
				if((tE2pData.pu8InRam[E2PPassword0] == E2P_PWD0) && (tE2pData.pu8InRam[E2PPassword1] == E2P_PWD1))
				#else
				if((tE2pData.pu8InRam[E2PPassword0] == 0x00) && (tE2pData.pu8InRam[E2PPassword1] == 0x00))
				#endif
				{
					tE2pData.tnStatus.u8Bit.u1ReadSt = E2pData_Read_Success;
				}
    		}
    	}
    }

    if(tE2pData.tnStatus.u8Bit.u1ReadSt == E2pData_Read_Success)
    {
    	return true;
    }
    else
    {
    	return false;
    }
    //tE2pData.tnStatus.u8Bit.u1ReadSt = E2pData_Read_Fault;

#endif
}

/****************************************************************************
*	name        : PushE2PWriteData
*	description :
*	return      : none
****************************************************************************/
bool PushE2PWriteData(u16_t u16E2PIndex, u8_t u8E2PData)
{
	if(u16E2PIndex < E2PDataNum)
	{
        if (tE2pData.u16PushIndex < E2PDATA_NUM)
        {
        	tE2pData.pu16Index[tE2pData.u16PushIndex] = u16E2PIndex;
        	tE2pData.pu8Buff[tE2pData.u16PushIndex++] = u8E2PData;
        	tE2pData.tnStatus.u8Bit.u2WriteSt = E2pData_Write_Push;
        	return true;
        }
	}

	return false;
}
/****************************************************************************
*	name        : PushE2PWriteLoop
*	description :
*	return      : none
****************************************************************************/
bool PushE2PWriteLoop(void)
{
	u8_t i, u8len;
	u8_t* pu8buff;
	u16_t u16IndexNum;

	u8len = 0;
	switch(tsBSC_Dev.u8Calibration)
	{
		case 0x06:
			u16IndexNum = BarCode0;
			u8len = sizeof(tsBSC_Dev.pu8MFRSerial);
			pu8buff = &tsBSC_Dev.pu8MFRSerial[0];
			break;

		default:
			u8len = 0;
			break;
	}

	for(i=0; i<u8len; i++)
	{
		if(PushE2PWriteData(u16IndexNum, pu8buff[i])==false)
		{
			return false;
		}
		u16IndexNum += 1;
	}
	return true;
}
/****************************************************************************
*	name        : PushE2PWriteDataLoop
*	description :
*	return      : none
****************************************************************************/
bool PushE2PWriteDataLoop(u8_t u8CmdCode, u8_t u8len, u8_t *pu8buff)
{
	u8_t i;
	u16_t u16IndexNum;

	if(u8CmdCode == PMBusCmd_MFRID)
	{
		u16IndexNum = Manufacture0;
	}
	else if(u8CmdCode == PMBusCmd_MFRModel)
	{
		u16IndexNum = ModelName0;
	}
	else if(u8CmdCode == PMBusCmd_MFRLocation)
	{
		u16IndexNum = Location0;
	}
	else if(u8CmdCode == PMBusCmd_MFRDate)
	{
		u16IndexNum = Date0;
	}
	else if(u8CmdCode == PMBusCmd_MFRSerial)
	{
		u16IndexNum = BarCode0;
	}
	else
	{
		return false;
	}

	for(i=0; i<u8len; i++)
	{
		//if(PushE2PWriteData(u16IndexNum, tsBSC_Manuf.pu8Manufacture[i])==false)
		if(PushE2PWriteData(u16IndexNum, pu8buff[i])==false)
		{
			return false;
		}
		u16IndexNum += 1;
	}
	return true;
	/*
	if(u8CmdCode == PMBusCmd_MFRID)
	{
		u16IndexNum = Manufacture0;
		for(i=0; i<u8len; i++)
		{
			//if(PushE2PWriteData(u16IndexNum, tsBSC_Manuf.pu8Manufacture[i])==false)
			if(PushE2PWriteData(u16IndexNum, pu8buff[i])==false)
			{
				return false;
			}
			u16IndexNum += 1;
		}
		return true;
	}

	if(u8CmdCode == PMBusCmd_MFRModel)
	{
		u16IndexNum = ModelName0;
		for(i=0; i<u8len; i++)
		{
			//if(PushE2PWriteData(u16IndexNum, tsBSC_Manuf.pu8Model[i])==false)
			if(PushE2PWriteData(u16IndexNum, pu8buff[i])==false)
			{
				return false;
			}
			u16IndexNum += 1;
		}
		return true;
	}

	//if(u8CmdCode == PMBusCmd_MFRRev)
	//{
	//	tsBSC_Infor.pu8FirmwareRev[0]
	//}
	if(u8CmdCode == PMBusCmd_MFRLocation)
	{
		u16IndexNum = Location0;
		for(i=0; i<u8len; i++)
		{
			//if(PushE2PWriteData(u16IndexNum, tsBSC_Manuf.pu8Location[i])==false)
			if(PushE2PWriteData(u16IndexNum, pu8buff[i])==false)
			{
				return false;
			}
			u16IndexNum += 1;
		}
		return true;
	}

	if(u8CmdCode == PMBusCmd_MFRDate)
	{
		u16IndexNum = Date0;
		for(i=0; i<u8len; i++)
		{
			//if(PushE2PWriteData(u16IndexNum, tsBSC_Manuf.pu8Date[i])==false)
			if(PushE2PWriteData(u16IndexNum, pu8buff[i])==false)
			{
				return false;
			}
			u16IndexNum += 1;
		}
		return true;
	}

	if(u8CmdCode == PMBusCmd_MFRSerial)
	{
		u16IndexNum = BarCode0;
		for(i=0; i<u8len; i++)
		{
			//if(PushE2PWriteData(u16IndexNum, tsBSC_Manuf.pu8BarCode[i])==false)
			if(PushE2PWriteData(u16IndexNum, pu8buff[i])==false)
			{
				return false;
			}
			u16IndexNum += 1;
		}
		return true;
	}

	return false;

	//if(u8CmdCode == PMBusCmd_MFRSp45)
	//{
	//	tsBSC_Infor.pu8PMBusProtocol[0]
	//}
	 */
}
/****************************************************************************
*	name        : E2PDataWriteProcess
*	description :
*	return      : none
****************************************************************************/
void E2PDataWriteProcess(void)
{
	if(u8E2PData10msTimer != E2PData10ms)
	{
		u8E2PData10msTimer = E2PData10ms;

		if(i2cbb_master_Ismode() == kbbmode_idle)
		{
			if(tE2pData.u16PushIndex != tE2pData.u16WriteIndex)
			{
				tE2pData.tnStatus.u8Bit.u2WriteSt = E2pData_Write_Process;
				i2cbb_master_sendbytes(E2P_MAX_BYTEADDR, tE2pData.pu16Index[tE2pData.u16WriteIndex], 1, &tE2pData.pu8Buff[tE2pData.u16WriteIndex]);

				tE2pData.u16WriteIndex += 1;

				if(tE2pData.u16WriteIndex == tE2pData.u16PushIndex)
				{
					tE2pData.u16WriteIndex = 0;
					tE2pData.u16PushIndex = 0;
					tE2pData.tnStatus.u8Bit.u2WriteSt = E2pData_Write_Done;
				}
			}
		}
	}


}
