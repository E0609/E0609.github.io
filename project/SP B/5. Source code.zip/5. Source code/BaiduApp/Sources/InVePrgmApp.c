/****************************************************************************
*	file        : InVePrgmApp.c
*   description : bootloader program
*   author      : Allen Lee
*   version     : 1.0
                  -   2014/03/31: initial version by Allen Lee
****************************************************************************/
#include <string.h>
#include "fsl_device_registers.h"
#include "hwtimer.h"
#include "InVePrgmApp.h"
#include "ProgramBlock.h"
#include "board.h"
#include "i2c_master.h"
#include "i2c_slave.h"
#include "usb_hid_device.h"
#include "pmbus_linearformat.h"

#include "E2pI2cBitBangData.h"
#include "macro_define.h"
#include "bsc_btloader.h"

#if (BAIDU_BT)

const u8_t pu8InVeBtKey[4] = {'I', 'n', 'V', 'e'};
const u8_t pu8InVeProductKey[16] = {'B', 'P', '-', '1', '4', '4', '2', '-', \
		                            '0', '1', 'X', ' ', ' ', ' ', ' ', ' '};

sInVeBoot_t sInVeBoot;
/****************************************************************************
*	name        : UpdateInVeBtStatus
*	description :
*	return      :
****************************************************************************/
void UpdateInVeBtStatus(u8_t u8Bits, u8_t u8Set)
{
	if(u8Set)
	{
		tsBSC_Dev.u8BtStatus |= u8Bits;
	}
	else
	{
		tsBSC_Dev.u8BtStatus &= ~u8Bits;
	}
}

/****************************************************************************
*	name        : InVeEntryBootloaderProcess
*	description :
*	return      :
****************************************************************************/
void InVeEntryBootloaderProcess(void)
{
	if (sInVeBoot.u8time10ms != InVeEntryBoot_Time10ms)
	{
		sInVeBoot.u8time10ms = InVeEntryBoot_Time10ms;

		if(sInVeBoot.tnStatus.u8Bit.u2BootISP)
		{
			if(sInVeBoot.u8waitCnt<10)	// wait 100msec entry boot mode
			{
				sInVeBoot.u8waitCnt += 1;
			}
			else
			{
				GiveFarewellMessage();
			}
		}
	}
}

/****************************************************************************
*	name        : Init_InVeBtRam
*	description :
*	return      :
****************************************************************************/
void Init_InVeBtRam(void)
{
	u8_t i;

	for(i=0; i<4; i++)
	{
		sInVeBoot.pu8BtKey[i] = pu8InVeBtKey[i];
	}

	//
	for(i=0; i<16; i++)
	{
		sInVeBoot.pu8ProductKey[i] = pu8InVeProductKey[i];
	}

	//clear the status
	UpdateInVeBtStatus(eInVeBtStatus, 0);
	UpdateInVeBtStatus(ebKeyErr|ebProductKeyErr, 1);

	sInVeBoot.tnStatus.u8All = 0;
	sInVeBoot.u8waitCnt = 0;
}
/****************************************************************************
*	name        : CheckInVeUnlockBtKey
*	description :
*	return      :
****************************************************************************/
bool CheckInVeUnlockBtKey(u8_t *pu8PBtKey)
{
	bool blret = true;
	u8_t i;

	for(i=0; i<4; i++)
	{
		if(pu8PBtKey[i] != sInVeBoot.pu8BtKey[i])
		{
			blret = false;
			break;
		}
	}

	return blret;
}
/****************************************************************************
*	name        : CheckInVeBtProductKey
*	description :
*	return      :
****************************************************************************/
bool CheckInVeBtProductKey(u8_t *pu8ProductKey)
{
	bool blret = true;
	u8_t i;

	for(i=0; i<16; i++)
	{
		if(pu8ProductKey[i] != sInVeBoot.pu8ProductKey[i])
		{
			blret = false;
			break;
		}
	}

	return blret;
}
/****************************************************************************
*	name        : clear_InVeBtStatus_App
*	description :
*	return      :
****************************************************************************/
void clear_InVeBtStatus_App(void)
{
	UpdateInVeBtStatus(eInVeBtStatus, 0);
	UpdateInVeBtStatus(ebKeyErr|ebProductKeyErr, 1);

	sInVeBoot.tnStatus.u8All = 0;
}

/****************************************************************************
*	name        : InVeBtWrProcess
*	description :
*	return      :
****************************************************************************/
void InVeBtWrProcess(u8_t u8Cmd)
{
	u8_t  u8Status = ebKeyErr|ebProductKeyErr;

	switch(u8Cmd)
	{
		case PMBusCmd_MFRSp32:	//0xF0, Boot loader key
			if(CheckInVeUnlockBtKey(&tsBSC_Dev.pu8PBtKey[0]) == true)
			{
				UpdateInVeBtStatus(ebKeyErr, 0);
			}
			break;
		case PMBusCmd_MFRSp33:	//0xF1, Boot loader Cmd
			if((tsBSC_Dev.u8BtStatus&u8Status) == 0)
			{
				if(tsBSC_Dev.u8BtCmd == ecmdPriBootISP)
				{
					sInVeBoot.tnStatus.u8All = 0;
					sInVeBoot.tnStatus.u8Bit.u2BootISP = 1;

					sInVeBoot.u8waitCnt = 0;
					//jump to boot loader
					//GiveFarewellMessage();
				}
				else if(tsBSC_Dev.u8BtCmd == ecmdClearStat)
				{
					clear_InVeBtStatus_App();
				}
				else if(tsBSC_Dev.u8BtCmd == ecmdResetSeq)
				{

				}
				else if(tsBSC_Dev.u8BtCmd == ecmdSecBootISP)
				{
					//sInVeBoot.tnStatus.u8Bit.u2BootISP = 2;
				}
				else if(tsBSC_Dev.u8BtCmd == ecmdBootPM)
				{

				}
			}
			break;
		case PMBusCmd_MFRSp35:	//0xF3, Boot loader Product key
			if(CheckInVeBtProductKey(&tsBSC_Dev.pu8ProductKey[0]) == true)
			{
				UpdateInVeBtStatus(ebProductKeyErr, 0);
			}
			break;

		default:

			break;
	}
}



#endif /* BAIDU_BT */

