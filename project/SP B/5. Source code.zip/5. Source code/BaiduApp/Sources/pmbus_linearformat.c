/****************************************************************************
*	file        : pmbus_linearformat.c
*   description : bootloader program
*   author      : Allen Lee
*   version     : 1.0
                  -   2014/03/31: initial version by Allen Lee
****************************************************************************/

#include "hwtimer.h"
#include "pmbus_linearformat.h"

/****************************************************************************
*	name        : L11_to_float
*	description :
*	return      :
****************************************************************************/
float_t L11_to_float(u16_t u16input_val)
{
	// extract exponent as MS 5 bits
	i8_t i8exponent = u16input_val >> 11;
	// extract mantissa as LS 11 bits
	i16_t i16mantissa = u16input_val & 0x7ff;
	// sign extend exponent from 5 to 8 bits
	if( i8exponent > 0x0F ) i8exponent |= 0xE0;
	// sign extend mantissa from 11 to 16 bits
	if( i16mantissa > 0x03FF ) i16mantissa |= 0xF800;
	// compute value as mantissa * 2^(exponent)
	return i16mantissa * pow(2,i8exponent);
}

/****************************************************************************
*	name        : L16_to_float
*	description :
*	return      :
****************************************************************************/
float_t L16_to_float(u8_t u8exp, u16_t u16input_val)
{
	i8_t i8exponent = u8exp;
	i16_t i16mantissa = u16input_val;
	// sign extend exponent
	if( i8exponent > 0x0F ) i8exponent |= 0xE0;
	// sign extend mantissa
	if( i16mantissa > 0x03FF ) i16mantissa |= 0xF800;
	// compute value as mantissa * 2^(exponent)
	return i16mantissa * pow(2,i8exponent);
}

