/*
 * cop.h
 *
 *  Created on: 2015/6/1
 *      Author: AllenCCLee
 */

#ifndef COP_H_
#define COP_H_

#include "fsl_cop_driver.h"

#define COP_INSTANCE        0

extern void Init_Cop(void);

#endif /* COP_H_ */
