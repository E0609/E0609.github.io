/****************************************************************************
*	file	RevisionBlock.h
*	brief	include RevisionBlock
*
*	author allen.lee
* 	version 1.0
*		-	2016/02/26: initial version by allen lee
*
****************************************************************************/

#ifndef REVISIONBLOCK_H_
#define REVISIONBLOCK_H_

#include "define.h"
//----------------------------------------------------------------------------
#define RCB_SIZE	(76)
#define RCB_REV     0x0100  // Revision Control Block revision 01.00
#define FWVER_A     0x53    //S
#define FWVER_B     0x52	//R
//#define FWVER_B     0x54	//T
#define FWVER_CC    0x3033  //03
#define FWVER_DD    0x3036  //06
//#define FWVER_DD    0x3438  //48
#define FWVER_EE    0x3030	//00

#define RVD1_AAAA      0x00000000
#define RVD1_BBBB      0x00000000

#define FWCC_4BYTE_1	0x30300000//----
#define FWCC_4BYTE_2	0x00000000//----

#define HWCC_2BYTE	0x3030	//--

#define RVD2_AAAA	0x00000000
#define RVD2_BB     0x0000

#define DEVHWVER_4BYTE_1	0x30410000	//0A
#define DEVHWVER_4BYTE_2	0x00000000

#define RVD3_AAAA   0x00000000
#define RVD3_BBBB   0x00000000

#define RVD4_AAAA   0x00000000
#define RVD4_BBBB	0x00000000

/****************************************************************************
*   Declared Structures & Variables
****************************************************************************/
#pragma pack(1)
typedef struct {
	u8_t    pu8StartPattern[8];
    u8_t    pu8RCBRev[2];
    u8_t    u8FwVer[8];
    u8_t    u8Rvd1[8];
    u8_t    pu8FwCompCode[8];
    u8_t    pu8HwCompCode[2];
    u8_t    pu8Rvd2[6];
    u8_t    pu8DevHwVer[8];
    u8_t    pu8Rvd3[8];
    u8_t	pu8Rvd4[8];
    u8_t	pu8CheckSum[2];
    u8_t    pu8StopPattern[8];
} sRevisionControlBlock_t;
#pragma pack()

extern sRevisionControlBlock_t   tsRevCtrlBlock;
/****************************************************************************
*   Declared Export functions
****************************************************************************/
extern void RevCtrlBlockFun(void);


#endif /* REVISIONBLOCK_H_ */
