/****************************************************************************
*	file	i2c_irq.h
*	brief	include I2C master driver
*
*	author allen.lee
* 	version 1.0
*		-	2014/05/05: initial version by allen lee
*
****************************************************************************/

#ifndef I2C_IRQ_H_
#define I2C_IRQ_H_

/****************************************************************************
*   Declared Macro
****************************************************************************/

/****************************************************************************
* Declare structure
****************************************************************************/

/****************************************************************************
*   Declared Export Global Variables
****************************************************************************/
/* Table of base addresses for I2C instances. */
extern const uint32_t gl_i2cBaseAddr[HW_I2C_INSTANCE_COUNT];

/* Pointer to runtime state structure.*/
extern void * gl_i2cStatePtr[HW_I2C_INSTANCE_COUNT];

/* Table to save i2c IRQ enum numbers defined in CMSIS header file. */
extern const IRQn_Type gl_i2cIrqId[HW_I2C_INSTANCE_COUNT];


#endif /* I2C_IRQ_H_ */
