/****************************************************************************
*	file	SlvPMBusApp.h
*	brief	The file includes subroutines for 24LCxxx
*
*	author allen.lee
* 	version 1.0
*		-	2014/04/21: initial version by allen lee
*
****************************************************************************/
#ifndef SLVPMBUSAPP_H_
#define SLVPMBUSAPP_H_

#include "define.h"
#include "SysTime.h"
#include "PMBusData.h"
#include "macro_define.h"

/****************************************************************************
*   Declared Macro
****************************************************************************/
#define SI2CPMBUS_TIMEOUT        (5)	//10msx5

#define SI2CPMBusTimeOut10ms      gtMcuTimer.u8Sys10ms
//---------------------------------------------------------------------
#define SI2CPMBUS_SUPPORT_PEC 		(1)
#define SI2CPMBUS_BYTE_EOF 		    0xff
//---------------------------------------------------------------------
#define SI2CPMBUS_TX_BUFF 			64
#define SI2CPMBUS_RX_BUFF 			64
//---------------------------------------------------------------------
#define SI2CPMBUS_CMD_INIT          0x01
#define SI2CPMBUS_CMD_INITIALIZED   0x02
#define SI2CPMBUS_WRITE_PACKET      0x04
#define SI2CPMBUS_CMD_IDLE          0x08
#define SI2CPMBUS_PEC_SENT          0x100
//----------------------------------------------
#define SI2CPMBUS_OK                	0x00            ///< Success
#define SI2CPMBUS_ERROR_CMD         	0x10            ///< Command Error recognized
#define SI2CPMBUS_ERROR_DATA        	0x20            ///< Data Error recognized
#define SI2CPMBUS_ERROR_PEC         	0x40            ///< PEC Error recognized
#define SI2CPMBUS_ERROR_CMD_NOT_SUP 	0x80            ///< Command is not supported
//---------------------------------------------------------------------
#define SI2CPMBUS_ERROR_IIC_ARBITRATION_LOST                1U
#define SI2CPMBUS_ERROR_RECEIVED_INVALID_PEC                2U
#define SI2CPMBUS_ERROR_CMD_NOT_SUPPORTED                   3U
#define SI2CPMBUS_ERROR_PROCCALL_NOT_SUPPORTED              4U
#define SI2CPMBUS_ERROR_PROCCALL_NOT_SUPPORTS_ZERO_PACKET   5U
#define SI2CPMBUS_ERROR_INVALID_RESPONSE_SIZE               6U
#define SI2CPMBUS_ERROR_TRANSMITED_TOO_MANY_BYTES           7U
#define SI2CPMBUS_ERROR_TRANSMITED_NOT_ENOUGH_BYTES         8U
#define SI2CPMBUS_ERROR_RECEIVED_MORE_BYTES                 9U
#define SI2CPMBUS_ERROR_RECEIVED_NOT_ENOUGH_BYTES           10U
#define SI2CPMBUS_ERROR_ALERT_FAILED                        11U
/****************************************************************************
* Declare structure
****************************************************************************/
//----------------------------------------------
#pragma pack(1)
typedef struct _sSlvPMBusAppStr_t {

	u16_t u16flags, u16errCode;
    u8_t  pu8txBuff[SI2CPMBUS_TX_BUFF];                     /*!< Pointer to Tx Buffer.*/
    u8_t  pu8rxBuff[SI2CPMBUS_RX_BUFF];                     /*!< Pointer to Rx Buffer.*/
    u16_t u16txIndex, u16txCount, u16rxIndex, u16rxCount;

    u8_t  u8wrAddr, u8rdAddr, u8devIndex;
    u8_t  u8rxpacketLen, u8rxpacketSize;
    u8_t  u8txpacketLen, u8txpacketSize;
    u8_t  u8CmdCode, u8CmdType;
    u8_t  u8pec;
    u8_t* pu8WrTempBuff;


} sSlvPMBusAppStr_t;
#pragma pack()
/****************************************************************************
*   Declared Export functions
****************************************************************************/
extern void UpdateBscStatusCML(u8_t u8Value, u8_t u8Set);

#if (BAIDU_BT)
extern void UpdateBscInVeBtCmd(u8_t u8Value);
#endif

extern void SlvPMBusTxInit(u8_t u8i2cData);
extern u16_t SlvPMBusTxPase(u8_t* pu8sendData);

extern void SlvPMBusRxInit(u8_t u8recByte);
extern u16_t SlvPMBusRxPase(u8_t u8recByte);

extern void Init_SlvPMBus(void);
extern void SlvPMBusReset(u8_t rangeaddrEnabled);

extern void SlvPMBusProcess(void);



#endif /* SLVPMBUSAPP_H_ */
