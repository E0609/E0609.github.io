/****************************************************************************
*	file	SysTime.h
*	brief	used to get the system time
*
*	author allen lee
* 	version 1.0
*		-	2015/05/26: initial version by allen lee
*
****************************************************************************/

#ifndef SYSTIME_H_
#define SYSTIME_H_

#include "board.h"
#include "define.h"


/****************************************************************************
*   Declared Structures & Variables
****************************************************************************/
typedef struct
{
    __IO u16_t u16SysTimeBase_PTD;		//unit us.
    u8_t u8Sys1ms;
    u8_t u8Sys10ms;
    u8_t u8Sys20ms;
    u8_t u8Sys100ms;
    u8_t u8Sys500ms;
    u8_t u8Sys1s;
    u8_t u8Sys1min;
    u8_t u8Sys1hour;
    funcPtr pfuncSysTime1ms;
    funcPtr pfuncSysTime10ms;
    funcPtr pfuncSysTime20ms;
    funcPtr pfuncSysTime100ms;
    funcPtr pfuncSysTime1s;
    funcPtr pfuncSysTime1min;
    funcPtr pfuncSysTime1hour;
} sMcuTimerBase_t;

extern sMcuTimerBase_t  gtMcuTimer;

/****************************************************************************
*   Declared all functions
****************************************************************************/
extern void SysTime(void);

#endif /* SYSTIME_H_ */
