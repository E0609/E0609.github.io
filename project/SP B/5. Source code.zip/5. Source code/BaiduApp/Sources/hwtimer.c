/****************************************************************************
*	file	hwtimer.c
*	brief	used to get the system tick
*
*	author allen lee
* 	version 1.0
*		-	2015/05/26: initial version by allen lee
*
****************************************************************************/

#include <stdio.h>
#include "board.h"
#include "fsl_hwtimer.h"
#include "SysTime.h"

/****************************************************************************
*   Declared define & typedef
****************************************************************************/
#define HWTIMER_LL_DEVIF    kSystickDevif
#define HWTIMER_LL_SRCCLK   kCoreClock
#define HWTIMER_LL_ID       0

#define HWTIMER_PERIOD          100//100000
#define HWTIMER_DOTS_PER_LINE   40
#define HWTIMER_LINES_COUNT     2

/****************************************************************************
 * Global Variables
 ****************************************************************************/
extern const hwtimer_devif_t kSystickDevif;
extern const hwtimer_devif_t kPitDevif;
hwtimer_t hwtimer;

/****************************************************************************
*	name        : hwtimer_callback
*	description : This function handles SysTick Handler.
*	return      : none
****************************************************************************/
static void hwtimer_callback(void* data)
{
    gtMcuTimer.u16SysTimeBase_PTD += 100;

//    GPIO_DRV_TogglePinOutput(kGpioLED1);

    /*
	printf(".");
	if ((HWTIMER_SYS_GetTicks(&hwtimer) % HWTIMER_DOTS_PER_LINE) == 0)
	{
		printf("\r\n");

	}
	if ((HWTIMER_SYS_GetTicks(&hwtimer) % (HWTIMER_LINES_COUNT * HWTIMER_DOTS_PER_LINE)) == 0)
	{
		if (kHwtimerSuccess != HWTIMER_SYS_Stop(&hwtimer))
		{
			printf("\r\nError: hwtimer stop.\r\n");
		}
		printf("End\r\n");
	}
	*/
}
/****************************************************************************
*	name        : Init_SysTick
*	description : Initializes the hwtimer_t structure and Sets 100usec ISR
*	return      : none
****************************************************************************/
void Init_SysTick(void)
{
	// Print the initial banner
	//printf("\r\nHwtimer Example \r\n");

	// Hwtimer initialization
	if (kHwtimerSuccess != HWTIMER_SYS_Init(&hwtimer, &HWTIMER_LL_DEVIF, HWTIMER_LL_ID, 5, NULL))
	{
		//printf("\r\nError: hwtimer initialization.\r\n");
	}
	if (kHwtimerSuccess != HWTIMER_SYS_SetPeriod(&hwtimer, HWTIMER_LL_SRCCLK, HWTIMER_PERIOD))
	{
		//printf("\r\nError: hwtimer set period.\r\n");
	}
	if (kHwtimerSuccess != HWTIMER_SYS_RegisterCallback(&hwtimer, hwtimer_callback, NULL))
	{
		//printf("\r\nError: hwtimer callback registration.\r\n");
	}
	if (kHwtimerSuccess != HWTIMER_SYS_Start(&hwtimer))
	{
		//printf("\r\nError: hwtimer start.\r\n");
	}

	/*
	// Print the initial banner
	printf("\r\nHwtimer Example \r\n");

	// Hwtimer initialization
	if (kHwtimerSuccess != HWTIMER_SYS_Init(&hwtimer, &HWTIMER_LL_DEVIF, HWTIMER_LL_ID, 5, NULL))
	{
		printf("\r\nError: hwtimer initialization.\r\n");
	}
	if (kHwtimerSuccess != HWTIMER_SYS_SetPeriod(&hwtimer, HWTIMER_LL_SRCCLK, HWTIMER_PERIOD))
	{
		printf("\r\nError: hwtimer set period.\r\n");
	}
	if (kHwtimerSuccess != HWTIMER_SYS_RegisterCallback(&hwtimer, hwtimer_callback, NULL))
	{
		printf("\r\nError: hwtimer callback registration.\r\n");
	}
	if (kHwtimerSuccess != HWTIMER_SYS_Start(&hwtimer))
	{
		printf("\r\nError: hwtimer start.\r\n");
	}
	*/
}
/****************************************************************************
*	name        : DeInit_SysTick
*	description :
*	return      : none
****************************************************************************/
void DeInit_SysTick(void)
{
	// Hwtimer initialization
	if (kHwtimerSuccess != HWTIMER_SYS_Deinit(&hwtimer))
	{

	}

}

