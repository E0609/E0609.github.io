/****************************************************************************
*	file	InVePrgmApp.h
*	brief	include ProgramApp
*
*	author allen.lee
* 	version 1.0
*		-	2014/04/21: initial version by allen lee
*
****************************************************************************/
#ifndef INVEPRGMAPP_H_
#define INVEPRGMAPP_H_

#include "define.h"
#include "SysTime.h"
#include "PMBusData.h"
#include "macro_define.h"

#if (BAIDU_BT)
/****************************************************************************
*   Declared Macro
****************************************************************************/
#define InVeEntryBoot_Time10ms      gtMcuTimer.u8Sys10ms
//----------------------------------------------
/* commands of InVeBtStatus 0xF1 */
//----------------------------------------------
typedef enum _eInVeBtStatus_t {
	ebChksum_Successful = 1U << 0, // bit 0, 0-NG, 1-OK
	ebMemErr 	= 1U << 1, // bit 1, 0-OK, 1-NG
	ebAlignErr	= 1U << 2, // bit 2, 0-OK, 1-NG
	ebKeyErr	= 1U << 3, // bit 3, 0-OK, 1-NG
	ebStartErr 	= 1U << 4, // bit 4, 0-OK, 1-NG
	ebProductKeyErr = 1U << 5, // bit 5, 0-OK, 1-NG
	ebMode		= 1U << 6, // bit 6, 0-APP, 1-BOOT
	ebPrgmBusy	= 1U << 7, // bit 7, 0-FINISHED, 1-PROGRESS

	eInVeBtStatus = 255U,

} eInVeBtStatus_t;

//---------------------------------------------------------------------
/* commands of InVeBtCmd 0xF1 */
//----------------------------------------------
typedef enum _eInVeBtCmd_t {
	ecmdClearStat  = 0x00,
	ecmdResetSeq   = 0x01,
	ecmdSecBootISP = 0x02,
	ecmdBootPM	   = 0x03,

	ecmdPriBootISP	= 0x12,
} eInVeBtCmd_t;

/****************************************************************************
*   Declared Structures & Variables
****************************************************************************/

//----------------------------------------------------------------------------
typedef union _nInVeBoot_t
{
   struct
   {
        u8_t   u2BootISP	:2;// 1-primary, 2-second
        u8_t   u1WrRestart	:1;
        u8_t   u1Reboot	    :1;
        u8_t   u4NA			:4;
   } u8Bit;

   u8_t u8All;
} nInVeBoot_t;
//----------------------------------------------
#pragma pack(1)
typedef struct _sInVeBoot_t {

	u8_t  pu8BtKey[4];
    u8_t  pu8ProductKey[16];

	nInVeBoot_t      tnStatus;
    u8_t  u8time10ms;
    u8_t  u8waitCnt;

    u16_t u16Checksum;


    u32_t u32StartAddress, u32nextStartAddress;
    u32_t u32WrByteSize;
    u32_t u32WrFlashSize;

} sInVeBoot_t;
#pragma pack()

extern sInVeBoot_t sInVeBoot;
/****************************************************************************
*   Declared Export functions
****************************************************************************/
extern void UpdateInVeBtStatus(u8_t u8Bits, u8_t u8Set);
extern bool CheckInVeUnlockBtKey(u8_t *pu8PBtKey);
extern bool CheckInVeBtProductKey(u8_t *pu8ProductKey);

extern void InVeBtWrProcess(u8_t u8Cmd);
extern void InVeEntryBootloaderProcess(void);
extern void Init_InVeBtRam(void);

#endif /* BAIDU_BT */



#endif /* INVEPRGMAPP_H_ */
