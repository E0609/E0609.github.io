/****************************************************************************
*	file	MstPMBusData.h
*	brief	The file includes subroutines for 24LCxxx
*
*	author allen.lee
* 	version 1.0
*		-	2014/04/21: initial version by allen lee
*
****************************************************************************/

#ifndef USB_HID_DEVICE_H_
#define USB_HID_DEVICE_H_
/******************************************************************************
 * Includes
 *****************************************************************************/
#include "usb_device_config.h"
#include "usb.h"
#include "usb_device_stack_interface.h"
#include "usb_class_hid.h"
#include "usb_descriptor.h"

#if (OS_ADAPTER_ACTIVE_OS == OS_ADAPTER_BM)
#include "user_config.h"
#endif

#if (OS_ADAPTER_ACTIVE_OS == OS_ADAPTER_SDK)
#include "fsl_device_registers.h"
#include "fsl_clock_manager.h"
#include "board.h"
#include "fsl_debug_console.h"
#include "fsl_usb_khci_hal.h"

#include <stdio.h>
#include <stdlib.h>

#endif



/******************************************************************************
 * Constants - None
 *****************************************************************************/

/******************************************************************************
 * Macro's
 *****************************************************************************/
#define  GENERIC_BUFF_SIZE    (64)//allen(8)/* report buffer size */
#define  REQ_DATA_SIZE        (1)

#define COMPLIANCE_TESTING    (0)/*1:TRUE, 0:FALSE*/
#define  HIGH_SPEED           (0)

#if HIGH_SPEED
#define CONTROLLER_ID         USB_CONTROLLER_EHCI_0
#else
#define CONTROLLER_ID         USB_CONTROLLER_KHCI_0
#endif
//---------------------------------------------------------------------
//enum of usb command code
typedef enum
{
	//
	//UsbCmd_Information = 0x00,
	UsbCmd_SendByte = 0x01,
	UsbCmd_ReceiveByte = 0x02,
	UsbCmd_WriteByte = 0x03,
	UsbCmd_WriteWord = 0x04,
	UsbCmd_ReadByte = 0x05,
	UsbCmd_ReadWord = 0x06,
	UsbCmd_ProCall = 0x07,
	UsbCmd_BlockWr = 0x08,
	UsbCmd_BlockRd = 0x09,
	UsbCmd_BWrBRdProCall = 0x0A,

	UsbCmd_GetBbuAddress = 0x1A,
	UsbCmd_GetBbuUrgentPMBus = 0x1B,

	UsbCmd_GetBscInfor = 0x20,
	UsbCmd_GetBscLabel = 0x21,

}eUsbPacketCmdCode_t;
//---------------------------------------------------------------------
//enum of usb status bytes
typedef enum _eUsbPacketStatus_t
{

	UsbPkt_Status_Success = 0x0U,
	UsbPkt_Status_Fail = 0x1U,

}eUsbPacketStatus_t;
/******************************************************************************
 * Types
 *****************************************************************************/
typedef struct hid_generic_struct
{
    hid_handle_t  app_handle;
#if ((OS_ADAPTER_ACTIVE_OS == OS_ADAPTER_BM) || (OS_ADAPTER_ACTIVE_OS == OS_ADAPTER_SDK))
    uint8_t       rpt_buf[GENERIC_BUFF_SIZE];/*report/data buff for hid_generic application*/
#elif (OS_ADAPTER_ACTIVE_OS == OS_ADAPTER_MQX)
    uint8_t*      rpt_buf;/*report/data buff for hid_generic application*/
#endif
    uint8_t       app_request_params[2]; /* for get/set idle and protocol requests*/
    uint8_t       hid_generic_attach;/* flag to check lower layer status*/

}hid_generic_struct_t;

/*****************************************************************************
 * Global variables
 *****************************************************************************/

/*****************************************************************************
 * Global Functions
 *****************************************************************************/

/****************************************************************************
*   Declared Export functions
****************************************************************************/
extern void Init_Usb(void);
extern void DeInit_Usb(void);
extern bool GetSOF_Token(uint8_t u8flage);

#endif /* USB_HID_DEVICE_H_ */
