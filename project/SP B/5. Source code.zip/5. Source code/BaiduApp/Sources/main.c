/**HEADER********************************************************************
* 
* Copyright (c) 2008, 2013- 2014 Freescale Semiconductor;
* All Rights Reserved
*
* Copyright (c) 1989-2008 ARC International;
* All Rights Reserved
*
*************************************************************************** 
*
* THIS SOFTWARE IS PROVIDED BY FREESCALE "AS IS" AND ANY EXPRESSED OR 
* IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES 
* OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  
* IN NO EVENT SHALL FREESCALE OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
* INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
* STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
* IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF 
* THE POSSIBILITY OF SUCH DAMAGE.
*
**************************************************************************
*
* $FileName: hid_generic.c$
* $Version : 
* $Date    : 
*
* Comments:
*
* @brief  The file emulates a hid_generic cursor movements
*         
*****************************************************************************/
 
/******************************************************************************
 * Includes
 *****************************************************************************/

#include "define.h"
#include "SysTime.h"
#include "hwtimer.h"
#include "bbu_ctrl.h"
#include "i2c_master.h"
#include "i2c_slave.h"
#include "usb_hid_device.h"
#include "PMBusData.h"
#include "MstPMBusApp.h"
#include "SlvPMBusApp.h"
#include "cop.h"
#include "flash_memory.h"
#include "ProgramBlock.h"
#include "ProgramApp.h"
#include "bsc.h"
#include "E2pI2cBitBangData.h"
#include "pit.h"
#include "E2pI2cPitApp.h"
#include "RevisionBlock.h"
#include "bsc_btloader.h"
#include "macro_define.h"
#include "InVePrgmApp.h"

/****************************************************************************
*   Declared define & typedef
****************************************************************************/


/*****************************************************************************
 * Global Functions Prototypes
 *****************************************************************************/
static void SysTime1ms(void);
static void SysTime10ms(void);
static void SysTime20ms(void);
static void SysTime100ms(void);
static void SysTime1s(void);
static void SysTime1min(void);
static void SysTime1hour(void);

/****************************************************************************
 * Global Variables
 ****************************************************************************/

/*****************************************************************************
 * Local Types - None
 *****************************************************************************/
 
/*****************************************************************************
 * Local Functions Prototypes
 *****************************************************************************/

/****************************************************************************
*	name        : Init_SysTime
*	description : Setup function pointer for SysTime function
*	return      : none
****************************************************************************/
void Init_SysTime(void)
{
	gtMcuTimer.pfuncSysTime1ms = &SysTime1ms;
	gtMcuTimer.pfuncSysTime10ms = &SysTime10ms;
	gtMcuTimer.pfuncSysTime20ms = &SysTime20ms;
	gtMcuTimer.pfuncSysTime100ms = &SysTime100ms;
	gtMcuTimer.pfuncSysTime1s = &SysTime1s;
	gtMcuTimer.pfuncSysTime1min = &SysTime1min;
	gtMcuTimer.pfuncSysTime1hour = &SysTime1hour;
}

/****************************************************************************
*	name        : Init_SysRam
*	description :
*	return      : none
****************************************************************************/
void Init_SysRam(void)
{
	u8_t i;

	for(i=0; i<BBU_DEV_NUM; i++)
	{
		memset(&tsBBU_Dev[i].u8CurrPage, 0, sizeof(sBBUCmd_t));
	}

	tsBSC_Dev.u16BattSelfCycleTime = 12960; // 90days = 144(10min) * 90 = 12960 (10min)
	sBattSelfTestStr.u32MinuteCnt = (u32_t)tsBSC_Dev.u16BattSelfCycleTime*10;
	tsBSC_Dev.u16BattSelfCycleCnt = tsBSC_Dev.u16BattSelfCycleTime;
	tsBSC_Dev.u16BattSelfDischrgRate = 70;
	tsBSC_Dev.tnLearningCtrl.u16All = 0;
	tsBSC_Dev.tnLearningCtrl.u16Bit.u2ShelfQty = 1;
	tsBSC_Dev.tnStatusCML.u8All = 0;
	tsBSC_Dev.tnStatusWord.u16All = 0;


#if (USB_ZOEY_DEBUG)
	//u8_t *pu8temp;
	//u16_t k, u16len;

	//pu8temp = &tsBBU_Dev[0].u8CurrPage;
	//u16len = sizeof(sBBUCmd_t);


	//for(i=0; i<BBU_DEV_NUM; i++)
	//{
	//	for(k=0; k<u16len; k++)
	//	{
	//		*pu8temp = (u8_t)((k+1)*(i+1));
	//		pu8temp++;
	//	}

	//}
	for(i=0; i<BBU_DEV_NUM; i++)
	{
		tsBBU_Dev[i].u16ReadVin = 10+i;				//command 88h,2
		tsBBU_Dev[i].u16ReadIin = 20+i;				//command 89h,2
		tsBBU_Dev[i].u16ReadVout = (30+i)*512;				//command 8Bh,2
		tsBBU_Dev[i].u16ReadIout = 40+i;				//command 8Ch,2
		tsBBU_Dev[i].u16ReadTemp1 = 50+i;				//command 8Dh,2
		tsBBU_Dev[i].u16ReadTemp2 = 60+i;				//command 8Eh,2
		tsBBU_Dev[i].u16ReadTemp3 = 70+i;				//command 8Fh,2
		tsBBU_Dev[i].tnStatusBBU.u8All = 0xd0+i;		//command D0h,1
		tsBBU_Dev[i].tnStateBBU.u16All = 0x0220;		//command D1h,1
		tsBBU_Dev[i].u16BattVolt = 80+i;					//command D4h,2
		tsBBU_Dev[i].u16BattCurr = 90+i;					//command D6h,2
		tsBBU_Dev[i].u16BattASOC = 100+i;					//command D7h,2
		tsBBU_Dev[i].u16BattRSOC = 110+i;			//command D9h,2
		tsBBU_Dev[i].u16BattCapacity = 120+i;		//command DAh,2
		tsBBU_Dev[i].u16BattCycCnt = 130+i;		//command DBh,2
		tsBBU_Dev[i].u16BattTemp = 140+i;		//command E3h,2
		tsBBU_Dev[i].pu32BBUProtectType = 0xE5+i;	//command E5h,4

		tsBBU_Dev[i].u16BattSOH = 150+i;			//command E8h,2
		tsBBU_Dev[i].u16DischrgRemainTime = 160+i;	//command E9h,2
		tsBBU_Dev[i].u16FullyChrgCapacity = 170+i;	//command ECh,2
	}

#endif


	//memset((u8_t*)&tsBbuBt_Dev.tsBtCmdF0h.tnBtStatus.u16All, 2, sizeof(tsBbuBt_Dev));
	//tsBbuBt_Dev.tsBtCmdF0h.pu8CodeID[0] = 0xaa;
	//tsBbuBt_Dev.tsBtCmdF0h.pu8CodeID[1] = 0xaa;

}
/****************************************************************************
*	name        : Init_task
*	description :
*	return      : none
****************************************************************************/
void Init_Task(void)
{
	Init_BbuGpio();

    Init_MasterI2c(HW_I2C1);
    Init_MstPMBus();

#if (I2C_SLAVE_MASK)
    Init_SlaveI2c(HW_I2C0, true);
    Init_SlvPMBus();
#endif
}

/****************************************************************************
*	name        : main
*	description : main loop
*	return      : none
****************************************************************************/
void main(void)
{
	Init_CommomRam();

    OSA_Init();
    hardware_init();

    ProgramInfoBlockFun();
    RevCtrlBlockFun();

    Init_SysRam();

    Init_Key();

#if (LITEON_BT)
    Init_Bootloader();
#endif /* LITEON_BT */

    Init_BscGpio();

#ifdef I2C_MASTER_DEBUG
    Init_MasterI2c(HW_I2C1);
    Init_MstPMBus();

    TURN_H_LED_G();
#endif

#ifdef E2pI2cPit
    Init_PitTimer(HW_PIT);
    Init_E2pI2cBitBang();

    ResetE2PData();
    if(ReadE2PDataToRam() == false)
    {
    	E2PDataDefault();
    }
#endif

    Init_BscRam();

#if (BAIDU_BT)
    Init_InVeBtRam();
#endif

#if (I2C_SLAVE_INACTIVE)
    Init_SlaveI2c(HW_I2C0, 0);
    Init_SlvPMBus();
#endif

    Init_SysTick();

    Init_SysTime();

    //Init_Cop();

    Init_Usb();

    //-----------------------------------------------------------------
    // Main-Loop
    //-----------------------------------------------------------------
    while (1)
    {
    	// Reset COP counter.
    	//COP_DRV_Refresh(COP_INSTANCE);

    	SysTime();

#if (LITEON_BT)
    	EntryBootloaderProcess();
#endif /* LITEON_BT */

#if (BAIDU_BT)
    	InVeEntryBootloaderProcess();
#endif /* BAIDU_BT */
    	switch(tsBsc_Str.u8TaskSchd)
    	{
    		case StartupMode:
				#if (I2C_SLAVE_INACTIVE)
    			SlvPMBusReset(0);
    			SlvPMBusProcess();
				#endif

    			BscLitenBusProcess_InStartupMode();
    			if(tsBsc_Str.u8TaskSchd == OperatingMode)
    			{
    				Init_BbuGpio();

    			    Init_MasterI2c(HW_I2C1);
    			    Init_MstPMBus();

    			#if (I2C_SLAVE_INACTIVE)
    			    DeInit_SlaveI2c(HW_I2C0);
				#endif

    			#if (I2C_SLAVE_MASK)
    			    Init_SlaveI2c(HW_I2C0, 1);
    			    Init_SlvPMBus();
    			#endif
    			}
    			break;

    		case OperatingMode:
    			BbuRegularWrProcess();
    			KeyCtrlProcess();
   			    BattDischrgSelfTestProcess();
    			DepthOfDischrgProcess();
    			CurrentSharingProcess();
#if(PR_JULDY)
    			ModeChangeProcess();
#endif
    			MstPMBusReset();
    			MstPMBusProcess();

#if (LITEON_BT)
    			BbuBtldLockTimeout();
#endif /* LITEON_BT */

#if (BAIDU_BT)
    			InVeBbuBtLockTimeout();
#endif /* BAIDU_BT */

    			#if (I2C_SLAVE_MASK)
    			SlvPMBusReset(1);
    			SlvPMBusProcess();
    			#endif

    			SlvDisconnectProcess();

    	    #ifdef E2pI2cPit
    			E2pI2cBitBangReset();
    			E2PDataWriteProcess();
    			//E2pI2cBitBangProcess();

    	    #endif

    			BscLitenBusProcess_InOperatingMode();
    	    	if(tsBsc_Str.u8TaskSchd == ConfirmingMode)
    	    	{
    	    		DeInit_MasterI2c(HW_I2C1);
    	    		Init_BscGpioInConfirmingMode();

    	    		//TURN_TGL_MTEST();
    	    	}
    			break;

    		case ConfirmingMode:

    			//20160709
				#if (I2C_SLAVE_MASK)
				SlvPMBusReset(1);
				SlvPMBusProcess();
				#endif

    			BscLitenBusProcess_InConfirmingMode();
    			if(tsBsc_Str.u8TaskSchd == OperatingMode)
    			{
    				Init_MasterI2c(HW_I2C1);
    			}
    			else if(tsBsc_Str.u8TaskSchd == StandbyMode)
    			{
    				DeInit_MasterI2c(HW_I2C1);
#if (I2C_SLAVE_MASK)
    				DeInit_SlaveI2c(HW_I2C0);
#endif
#if (I2C_SLAVE_INACTIVE)
    			    Init_SlaveI2c(HW_I2C0, 0);
    			    Init_SlvPMBus();
#endif
    				Init_BscGpioInStandby();
    				TURN_L_LED_G();

    			}
    			break;

    		case StandbyMode:
				#if (I2C_SLAVE_MASK)
    			SlvPMBusReset(0);
    			SlvPMBusProcess();
				#endif
    			BscLitenBusProcess_InStandbyMode();
    			if(tsBsc_Str.u8TaskSchd == OperatingMode)
    			{
    				//Init_BbuGpio();
    				Init_BscGpioInReOperation();

    			    Init_MasterI2c(HW_I2C1);
    			    Init_MstPMBus();

				#if (I2C_SLAVE_MASK)
    			    DeInit_SlaveI2c(HW_I2C0);
				#endif

    			#if (I2C_SLAVE_MASK)
    			    Init_SlaveI2c(HW_I2C0, true);
    			    Init_SlvPMBus();
    			#endif
    			    TURN_H_LED_G();
    			}
    			break;

    		default:

    			break;

    	}

    }
}







/****************************************************************************
*	name        : SysTime1ms
*	description : Reached 1ms routine
*	return      : none
****************************************************************************/
static void SysTime1ms(void)
{

}
/****************************************************************************
*	name        : SysTime10ms
*	description : Reached 10ms routine
*	return      : none
****************************************************************************/
static void SysTime10ms(void)
{
	//TURN_TGL_BBS_ON();
}
/****************************************************************************
*	name        : SysTime20ms
*	description : Reached 20ms routine
*	return      : none
****************************************************************************/
static void SysTime20ms(void)
{

}
/****************************************************************************
*	name        : SysTime100ms
*	description : Reached 100ms routine
*	return      : none
****************************************************************************/
static void SysTime100ms(void)
{
	//if(tsBsc_Str.tnStatus.u8Bit.u1TaskSchd)
	//{
	//	TURN_TGL_MTEST();
	//}
	//

}
/****************************************************************************
*	name        : SysTime1s
*	description : Reached 1s routine
*	return      : none
****************************************************************************/
static void SysTime1s(void)
{
	//TURN_TGL_LED_G();
	//TURN_TGL_MTEST();

}
/****************************************************************************
*	name        : SysTime1min
*	description : Reached 1min routine
*	return      : none
****************************************************************************/
static void SysTime1min(void)
{

}
/****************************************************************************
*	name        : SysTime1hour
*	description : Reached 1hour routine
*	return      : none
****************************************************************************/
static void SysTime1hour(void)
{

}
/* EOF */
