/****************************************************************************
*	file	hwtimer.h
*	brief	used to get the system tick
*
*	author allen lee
* 	version 1.0
*		-	2015/05/26: initial version by allen lee
*
****************************************************************************/

#ifndef HWTIMER_H_
#define HWTIMER_H_




/****************************************************************************
*   Declared all functions
****************************************************************************/
extern void Init_SysTick(void);
extern void DeInit_SysTick(void);

#endif /* HWTIMER_H_ */
