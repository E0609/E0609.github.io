/****************************************************************************
*	file	bbu_led.c
*	brief
*
*	author allen.lee
* 	version 1.0
*		-	2014/05/05: initial version by allen lee
*
****************************************************************************/
#if (OS_ADAPTER_ACTIVE_OS == OS_ADAPTER_SDK)
#include "board.h"
#include "fsl_debug_console.h"
#include "bbu_ctrl.h"
#include "PMBusData.h"
#include "MstPMBusApp.h"
#include "pmbus_linearformat.h"
#endif

/****************************************************************************
*   Declared Macro
****************************************************************************/

/****************************************************************************
*   Declared Structures & Variables
****************************************************************************/
static u8_t  u8Key100ms = 0;
static u8_t  u8BattSelfTest1min = 0;
static u8_t  u8BattSelfTest1sec = 0;
static u8_t  u8CurrSharing500ms = 0;
static u8_t  u8ModeChange1ms = 0;

nStatusCtrl1_t tnSTA_Ctrl1;
sBattSelfTestStr_t sBattSelfTestStr;
sBatteryControlStr_t sBattCtrlStr;
sKeyStr_t sKeyStr;
sBbuRegularWrPMBusStr_t sBbuRegWrStr;
sRemoteCurrSharingStr_t sRemoteCsStr;
sSlvDisconnectStr_t sSlvDisconnectStr;

/*FUNCTION**********************************************************************
 *
 * Function Name : GPIO_DRV_IsPinIntPending
 * Description   : Read the individual pin-interrupt status flag.
 *
 *END**************************************************************************/
bool GPIO_DRV_IsPinIntPending(uint32_t pinName)
{
    uint32_t portBaseAddr = g_portBaseAddr[GPIO_EXTRACT_PORT(pinName)];
    uint32_t pin = GPIO_EXTRACT_PIN(pinName);

    return PORT_HAL_IsPinIntPending(portBaseAddr, pin);
}

/****************************************************************************
*	name        :
*	description : Interrupt service function
*	return      : none
****************************************************************************/
void PORTA_IRQHandler(void)
{
    /* Clear interrupt flag.*/
    //PORT_HAL_ClearPortIntFlag(PORTA_BASE);

}
/****************************************************************************
*	name        :
*	description : Interrupt service function
*	return      : none
****************************************************************************/
void PORTC_PORTD_IRQHandler(void)
{
    /* Clear interrupt flag.*/
    //PORT_HAL_ClearPortIntFlag(PORTC_BASE);
    //PORT_HAL_ClearPortIntFlag(PORTD_BASE);

#if(PR_JULDY)
    if(GPIO_DRV_IsPinIntPending(kIntGpioVinOk))
    {
    	if (READ_H_VIN_OK())
    	{
    		VINOK_ON_BIT = kbitSet;
    	}
    	else
    	{
    		VINOK_ON_BIT = kbitClr;
    	}
    	//occur offline and vin nok, it should be boost vout immediately
    	if((tsBSC_Dev.u16ModeChange == eOpMode_OffLine) && (VINOK_ON_BIT == kbitClr))
		{
    		TURN_L_BBS_ACLOSS();//vout 12.7v
		}

    	// Clear external interrupt flag.
    	GPIO_DRV_ClearPinIntFlag(kIntGpioVinOk);
    }

#else
    if(GPIO_DRV_IsPinIntPending(kIntGpioVinOk))
    {
    	if (READ_H_VIN_OK())
    	{
    		VINOK_ON_BIT = kbitSet;
    		TURN_H_BBS_ACGOOD();
    	}
    	else
    	{
    		VINOK_ON_BIT = kbitClr;
    		TURN_L_BBS_ACLOSS();
    	}

    	// Clear external interrupt flag.
    	GPIO_DRV_ClearPinIntFlag(kIntGpioVinOk);
    }
#endif
}

/****************************************************************************
*	name        : Init_BbuGpio
*	description : Initial input/output i/o
*	return      : none
****************************************************************************/
void Init_BbuGpio(void)
{
	GPIO_DRV_Init(bbuIntPins, bbuOutPins);

	tsBSC_Dev.u16ModeChange = eOpMode_OnLine;
	OnLineMode_Ctrl();

	VINOK_ON_BIT = kbitSet;
	TURN_H_BBS_ACGOOD();
}
/****************************************************************************
*	name        : Init_Key
*	description : Initial key state
*	return      : none
****************************************************************************/
void Init_Key(void)
{
	sKeyStr.u8keyState = sKeyStr.u8OkeyState = 1;
	sKeyStr.u8KeyCnt_3S = sKeyStr.u8KeyCnt_6S = sKeyStr.u8KeyCnt_9S = 0;
	sKeyStr.u8PressingState = 0;
}

/****************************************************************************
*	name        : OnLineMode_Ctrl
*	description :
*	return      : none
****************************************************************************/
void OnLineMode_Ctrl(void)
{
	// Ps Kill L
	TURN_L_BBS_EN();

	//BBU On H level
    TURN_H_BBS_ONLINE();

    //Ac Good H level
    //TURN_H_BBS_ACGOOD();
}
/****************************************************************************
*	name        : OffLineMode_Ctrl
*	description :
*	return      : none
****************************************************************************/
void OffLineMode_Ctrl(void)
{
	// Ps Kill L
	TURN_L_BBS_EN();

	//BBU On L
	TURN_L_BBS_OFFLINE();

    //Ac Good L
    //TURN_L_BBS_ACLOSS();
}
/****************************************************************************
*	name        : IdleMode_Ctrl
*	description :
*	return      : none
****************************************************************************/
void IdleMode_Ctrl(void)
{
	// Ps Kill H
	TURN_H_BBS_DIS();
}

/****************************************************************************
*	name        : BscOgoWrPMBusCmd
*	description :
*	return      : none
****************************************************************************/
bool BscOgoWrPMBusCmd(u8_t u8DevIndex, u8_t u8Cmd)
{
	bool bstate = true;

	switch(u8Cmd)
	{
		case PMBusCmd_UsrData11:
			//ParseBbuWrCmdSup(u8DevIndex, u8Cmd, (u8_t*)&tsBSC_Dev.u16ModeChange, 2);
			ParseBbuWrCmdPushWrData(u8DevIndex, u8Cmd, (u8_t*)&tsBSC_Dev.u16ModeChange, 2);
			break;

		case PMBusCmd_MFRSp30:
			//ParseBbuWrCmdSup(u8DevIndex, u8Cmd, (u8_t*)&sBattCtrlStr.u16AgingComp, 2);
			ParseBbuWrCmdPushWrData(u8DevIndex, u8Cmd, (u8_t*)&sBattCtrlStr.tnBbuIntCtrl.u16All, 2);
			break;

		default:
			bstate = false;
			break;
	}

	return bstate;

}
/****************************************************************************
*	name        : BbuRegularWrProcess
*	description :
*	return      : none
****************************************************************************/
void BbuRegularWrProcess(void)
{
	//
	//if(GetActivateWrCmd() == 0)
	//{
	//	SlvPushWriteProcess();
	//}

	//
	if (sBbuRegWrStr.u8Timer10ms != BbuRegularWr10ms)
	{
		sBbuRegWrStr.u8Timer10ms = BbuRegularWr10ms;
#if (MST_RESEND)
		if((GetActivateWrCmd() == 0) && (GetMasterWrState() == 0))
		{
			if(GetReSendMasterWrState() == 0)
			{
				SlvPushWriteProcess();
			}
			else
			{
				SlvPushReSendWriteProcess();

			}
		}
#else
		if(GetActivateWrCmd() == 0)
		{
			SlvPushWriteProcess();
		}
#endif
		sBbuRegWrStr.u16TimerCnt += 1;
		if(sBbuRegWrStr.u16TimerCnt > 50)
		{
			sBbuRegWrStr.u16TimerCnt = 0;

			if ((GetActivateWrCmd() == 0) && (sBattCtrlStr.eBattCtrl == BattCtrlClear))
			{
#if (BAIDU_BT)
				if(GetInVeBbuBtLock() == 0)
				{
					BscOgoWrPMBusCmd(0xFF, PMBusCmd_UsrData11);
				}
#else
				BscOgoWrPMBusCmd(0xFF, PMBusCmd_UsrData11);
#endif
				//TURN_TGL_PTD7();
			}

		}

	}
}
/****************************************************************************
*	name        : UpdateCurrSharingStatus
*	description :
*	return      : none
****************************************************************************/
void UpdateCurrSharingStatus(u8_t u8Set)
{
	if(u8Set)
	{
		sBattCtrlStr.tnBbuIntCtrl.u16Bit.u1EnCurrSharing = 1;
	}
	else
	{
		sBattCtrlStr.tnBbuIntCtrl.u16Bit.u1EnCurrSharing = 0;
	}
}
/****************************************************************************
*	name        : UpdateManualDischrgStatus
*	description :
*	return      : none
****************************************************************************/
void UpdateManualDischrgStatus(u8_t u8Set)
{
	if(u8Set)
	{
		tsBSC_Dev.tnStatusWord.u16Bit.u1ManDischrg = 1;
	}
	else
	{
		tsBSC_Dev.tnStatusWord.u16Bit.u1ManDischrg = 0;
	}
}

/****************************************************************************
*	name        : UpdateLearningStart
*	description :
*	return      : none
****************************************************************************/
void UpdateLearningStart(u16_t u16Operate)
{
	tsBSC_Dev.tnStatusWord.u16Bit.u2LearnState = u16Operate;
	tsBSC_Dev.tnStatusWord.u16Bit.u5LearnCondition = eLCond_Normal;
	tsBSC_Dev.tnStatusWord.u16Bit.u3LearnResult = elResult_Default;
}
/****************************************************************************
*	name        : UpdateLearningResult
*	description :
*	return      : none
****************************************************************************/
void UpdateLearningResult(u16_t u16Result, u16_t u16Cond)
{
	tsBSC_Dev.tnStatusWord.u16Bit.u2LearnState = elOperate_Idle;
	tsBSC_Dev.tnStatusWord.u16Bit.u5LearnCondition = u16Cond;
	tsBSC_Dev.tnStatusWord.u16Bit.u3LearnResult = u16Result;
}

/****************************************************************************
*	name        : ReturnBbuQtyCmdB8h
*	description :
*	return      : none
****************************************************************************/
u8_t ReturnBbuQtyCmdB8h(void)
{
	if(tsBSC_Dev.tnLearningCtrl.u16Bit.u2ShelfQty == 0)
	{
		return(4);
	}
	else if(tsBSC_Dev.tnLearningCtrl.u16Bit.u2ShelfQty == 1)
	{
		return(8);
	}
	else if(tsBSC_Dev.tnLearningCtrl.u16Bit.u2ShelfQty == 2)
	{
		return(12);
	}
	else if(tsBSC_Dev.tnLearningCtrl.u16Bit.u2ShelfQty == 3)
	{
		return(16);
	}
	else
	{
		return(8); //default
	}
}

/****************************************************************************
*	name        : IsDischrg
*	description :
*	return      : none
****************************************************************************/
u16_t IsDischrg(void)
{
	u8_t i, u8BbuQty;
	u16_t u16DevPresent, u16BbuPresentBit;

	u16DevPresent = GetPresentDeviceIndex();

	if(VINOK_ON_BIT != kbitSet)
	{
		return eLCond_VinOkAnormal;	//vin ok abnormal
	}

	u8BbuQty = ReturnBbuQtyCmdB8h();
	for(i=0, u16BbuPresentBit = 0; i<u8BbuQty; i++)
	{
		u16BbuPresentBit |= (1<<i);
	}

	//for(i=0; i<BBU_DEV_NUM; i++)
	for(i=0; i<u8BbuQty; i++)

	{
		if((u16DevPresent>>i)&0x0001)
		{
			if((tsBBU_Dev[i].tnStateBBU.u16All>>2)&0x0001)	//bit2-Discharging
			{
				return eLCond_VinOkAnormal;	//vin ok abnormal
			}
		}
	}

	return 0;
}
/****************************************************************************
*	name        : ForceDisacharging
*	description :
*	return      : none
****************************************************************************/
void ForceDisacharging(void)
{
	if(VINOK_ON_BIT == kbitSet)
	{
		TURN_H_BBS_ACGOOD();
	}
	sBattSelfTestStr.u16Step = BSTStep_Idle;
	sBattCtrlStr.eBattCtrl = BattCtrlClear;
	//to clear battery status bit10,9,8.
	sBattCtrlStr.tnBbuIntCtrl.u16Bit.u2AgingComp = eAgingComp_ClrDischgrFlag;
	BscOgoWrPMBusCmd(0xFF, PMBusCmd_MFRSp30);
}
/****************************************************************************
*	name        : BscForceDischrgProcess
*	description :
*	return      : none
****************************************************************************/
void BscForceDischrgProcess(u16_t u16Error)
{
	if(sBattCtrlStr.eBattCtrl == ManualLearning)
	{
		ForceDisacharging();
		UpdateLearningResult(eLResult_ManualFailure,u16Error);
		if(u16Error & eLCond_ForcedStop)
		{
			ReloadBattSelfTestCount(1);
		}
	}
	else if(sBattCtrlStr.eBattCtrl == AutoLearning)
	{
		ForceDisacharging();
		UpdateLearningResult(elResult_AutoFailure,u16Error);
		if(u16Error & eLCond_ForcedStop)
		{
			ReloadBattSelfTestCount(1);
		}
	}


}
/****************************************************************************
*	name        : BattDischrgSelfTest_verify
*	description :
*	return      : none
****************************************************************************/
u16_t BattDischrgSelfTest_verify(void)
{
	u8_t i, u8BbuQty;
	i16_t i16RsocL11;
	u16_t u16BbuPresentBit;

	sBattSelfTestStr.u16DevPresent = GetPresentDeviceIndex();

	u8BbuQty = ReturnBbuQtyCmdB8h();
	for(i=0, u16BbuPresentBit=0; i<u8BbuQty; i++)
	{
		u16BbuPresentBit |= (1<<i);
	}

	if(u16BbuPresentBit != sBattSelfTestStr.u16DevPresent)
	{
		return eLCond_BbuAnormal;	//bbu abnormal
	}

	//for(i=0; i<BBU_DEV_NUM; i++)
	for(i=0; i<u8BbuQty; i++)
	{
		if((sBattSelfTestStr.u16DevPresent>>i)&0x0001)
		{
			if(sBattSelfTestStr.u16Step == BSTStep_Idle)
			{
				i16RsocL11 = L11_to_float(tsBBU_Dev[i].u16BattRSOC);
				if(i16RsocL11 < BATTSELFTEST_BBU_RSOC)
				{
					return eLCond_RsocAnormal;	//RSOC abnormal
				}
			}
			else if(sBattSelfTestStr.u16Step == BSTStep_GetReadyBit9)
			{
				if((tsBBU_Dev[i].tnStateBBU.u16All>>2)&0x0001)	//bit2-Discharging
				{
					//TURN_TGL_MTEST();
					return eLCond_VinOkAnormal;	//vin ok abnormal
				}
			}

#if(BBU_PROTECT)
			if(tsBBU_Dev[i].pu32BBUProtectType != 0)
			{
				return eLCond_BbuProtection;	//bbu protection
			}
#endif

			if((tsBBU_Dev[i].tnStateBBU.u16All>>4)&0x0001) //bit4-Idle
			{
				return eLCond_BbuAnormal;	//bbu abnormal
			}

		}
		else
		{
			return eLCond_BbuAnormal;	//bbu abnormal
		}
	}

	if(VINOK_ON_BIT != kbitSet)
	{
		return eLCond_VinOkAnormal;	//vin ok abnormal
	}

	return 0;
}
/****************************************************************************
*	name        : BattDischrgSelfTest_emergencystate
*	description :
*	return      : none
****************************************************************************/
u16_t BattDischrgSelfTest_emergencystate(void)
{
	u16_t u16Error;

	u16Error = BattDischrgSelfTest_verify();
	if(u16Error)	//emergency state
	{
		BscForceDischrgProcess(u16Error);
	}

	return(u16Error);
}

/****************************************************************************
*	name        : BscManualLearningActiveProcess
*	description :
*	return      : none
****************************************************************************/
void BscManualLearningActiveProcess(void)
{
	u16_t u16Error;

	if(sBattCtrlStr.eBattCtrl == BattCtrlClear)
	{
		u16Error = BattDischrgSelfTest_verify();
		if(u16Error == 0)
		{
			sBattCtrlStr.eBattCtrl = ManualLearning;
			sBattSelfTestStr.u16Step = BSTStep_WrClrCmd;
#if (BATT_SELFTEST_RETRY)
			sBattSelfTestStr.nStatus.u16All = 0;
			sBattSelfTestStr.u8WrClrCmdRetryCnt = 0;
			sBattSelfTestStr.u8WrReqCmdRetryCnt = 0;
			sBattSelfTestStr.u16GetBit9TimeOut = 0; //sec
#endif
			UpdateLearningStart(elOperate_Manual);
		}
		else
		{
			UpdateLearningResult(eLResult_ManualFailure,u16Error);
		}
		ReloadBattSelfTestCount(1);
	}
}
/****************************************************************************
*	name        : BscAutoLearningActiveProcess
*	description :
*	return      : none
****************************************************************************/
void BscAutoLearningActiveProcess(void)
{
	u16_t u16Error;

	if(sBattCtrlStr.eBattCtrl == BattCtrlClear)
	{
		u16Error = BattDischrgSelfTest_verify();
		if(u16Error == 0)
		{
			sBattCtrlStr.eBattCtrl = AutoLearning;
			sBattSelfTestStr.u16Step = BSTStep_WrClrCmd;
			//sBattSelfTestStr.u32MinuteCnt = 0;
#if (BATT_SELFTEST_RETRY)
			sBattSelfTestStr.nStatus.u16All = 0;
			sBattSelfTestStr.u8WrClrCmdRetryCnt = 0;
			sBattSelfTestStr.u8WrReqCmdRetryCnt = 0;
			sBattSelfTestStr.u16GetBit9TimeOut = 0; //sec
#endif
			UpdateLearningStart(elOperate_Auto);
		}
		else
		{
			UpdateLearningResult(elResult_AutoFailure, u16Error);
		}
		ReloadBattSelfTestCount(0);
	}
	//else
	//{
	//	ReloadBattSelfTestCount();
	//}
}
/****************************************************************************
*	name        : KeyCtrlProcess
*	description :
*	return      : none
****************************************************************************/
void KeyCtrlProcess(void)
{
	u16_t u16Error;

	if(u8Key100ms != Key100ms)
	{
		u8Key100ms = Key100ms;

		sKeyStr.u8keyState = GPIO_DRV_ReadPinInput(kGpioKey_SW1);
		if(sKeyStr.u8keyState == 1)
		{
			if(sKeyStr.u8PressingState == 1)
			{
				if(sBattCtrlStr.eBattCtrl == DepthOfDischrg)
				{
					if(VINOK_ON_BIT == kbitSet)
					{
						TURN_H_BBS_ACGOOD();
						sBattCtrlStr.eBattCtrl = BattCtrlClear;

						//to initial
						UpdateManualDischrgStatus(0);
						sBattCtrlStr.tnBbuIntCtrl.u16Bit.u2AgingComp = eAgingComp_Default;
						BscOgoWrPMBusCmd(0xFF, PMBusCmd_MFRSp30);
					}
				}
				else if((sBattCtrlStr.eBattCtrl == ManualLearning) || (sBattCtrlStr.eBattCtrl == AutoLearning))
				{
					BscForceDischrgProcess(eLCond_ForcedStop);
				}
				else
				{
					BscManualLearningActiveProcess();

				}
			}

			if(sKeyStr.u8PressingState == 2)
			{
				u16Error = IsDischrg();
				if(u16Error)
				{
					//error
				}
				else
				{
					TURN_L_BBS_ACLOSS();
					sBattCtrlStr.eBattCtrl = DepthOfDischrg;

					//to enable DOD.
					UpdateManualDischrgStatus(1);
				}
			}

			if(sKeyStr.u8PressingState == 3)
			{
				ReloadBattSelfTestCount(1);
			}

			TURN_H_LED_G();

			//TURN_H_MTEST();

			sKeyStr.u8OkeyState = sKeyStr.u8keyState;
			sKeyStr.u8KeyCnt_3S = sKeyStr.u8KeyCnt_6S = sKeyStr.u8KeyCnt_9S = 0;
			sKeyStr.u8PressingState = 0;
		}
		else if(sKeyStr.u8OkeyState != sKeyStr.u8keyState)
		{
			sKeyStr.u8OkeyState = sKeyStr.u8keyState;
			sKeyStr.u8KeyCnt_3S = sKeyStr.u8KeyCnt_6S = sKeyStr.u8KeyCnt_9S = 0;
			//TURN_TGL_BBS_ON();
		}
		else
		{
			sKeyStr.u8KeyCnt_3S = (sKeyStr.u8KeyCnt_3S+1)%KEY_CONFIRM_TIME_3S;
			sKeyStr.u8KeyCnt_6S = (sKeyStr.u8KeyCnt_6S+1)%KEY_CONFIRM_TIME_6S;
			sKeyStr.u8KeyCnt_9S = (sKeyStr.u8KeyCnt_9S+1)%KEY_CONFIRM_TIME_9S;
			if((sKeyStr.u8KeyCnt_3S%10) == 0)
			{
				TURN_TGL_LED_G();
				//TURN_TGL_MTEST();
			}
			if(sKeyStr.u8KeyCnt_3S == 0)
			{
				sKeyStr.u8PressingState = 1;
			}

			if(sKeyStr.u8KeyCnt_6S == 0)
			{
				sKeyStr.u8PressingState = 2;
			}

			if(sKeyStr.u8KeyCnt_9S == 0)
			{
				sKeyStr.u8PressingState = 3;
			}
		}
	}
}

/****************************************************************************
*	name        : ReloadBattSelfTestCount
*	description :
*	return      : none
****************************************************************************/
void ReloadBattSelfTestCount(u8_t u8Set)
{
	u8BattSelfTest1min = BattSelfTest1min;
	sBattSelfTestStr.u32MinuteCnt = (u32_t)tsBSC_Dev.u16BattSelfCycleTime*10;
	if(u8Set)
	{
		tsBSC_Dev.u16BattSelfCycleCnt = tsBSC_Dev.u16BattSelfCycleTime;
	}
}
/****************************************************************************
*	name        : BattDischrgSelfTest_waittime
*	description :
*	return      : none
****************************************************************************/
void BattDischrgSelfTest_waittime(void)
{
	if(u8BattSelfTest1sec != BattSelfTest1sec)
	{
		u8BattSelfTest1sec = BattSelfTest1sec;

		if (sBattSelfTestStr.u16Step == BSTStep_WrClrCmdWaitTime)
		{
			sBattSelfTestStr.u8WrClrCmdWaitTime += 1;
			if(sBattSelfTestStr.u8WrClrCmdWaitTime > 10)
			{
#if (BATT_SELFTEST_RETRY)
				sBattSelfTestStr.u16Step = BSTStep_GetClrBits;

#else
				sBattSelfTestStr.u16Step = BSTStep_WrReqCmd;
#endif
				sBattSelfTestStr.u8WrClrCmdWaitTime = 0;
			}
		}
#if (BATT_SELFTEST_RETRY)
		else if (sBattSelfTestStr.u16Step == BSTStep_WrReqCmdWaitTime)
		{
			sBattSelfTestStr.u8WrReqCmdWaitTime += 1;
			if(sBattSelfTestStr.u8WrReqCmdWaitTime >= 2)
			{
				sBattSelfTestStr.u16Step = BSTStep_GetReqBit10;
				sBattSelfTestStr.u8WrReqCmdWaitTime = 0;
			}
		}
		else if(sBattSelfTestStr.u16Step == BSTStep_GetReadyBit9)
		{
			sBattSelfTestStr.u16GetBit9TimeOut += 1;

			//if(sBattSelfTestStr.u16GetBit9TimeOut > 1440)	//95%FCC/Icharge = 400mAh/1A
			if(sBattSelfTestStr.u16GetBit9TimeOut > 3000)	//boundary time is 50minutes
			{
				sBattSelfTestStr.nStatus.u16Bit.u1GetBit9Error = 1;
				sBattSelfTestStr.u16GetBit9TimeOut = 0;
			}
		}


#endif
	}
}
/****************************************************************************
*	name        : BattDischrgSelfTestProcess
*	description :
*	return      : none
****************************************************************************/
void BattDischrgSelfTestProcess(void)
{
	u8_t u8BbuQty, u8SelftestConfirm;
	u16_t i, j, u16Error, u16BbuPresentBit;

	if(u8BattSelfTest1min != BattSelfTest1min)
	{
		//TURN_TGL_MTEST();
		u8BattSelfTest1min = BattSelfTest1min;
		if(tsBSC_Dev.u16BattSelfCycleTime == 0)
		{
			ReloadBattSelfTestCount(1);
		}
		else
		{
			if(sBattSelfTestStr.u32MinuteCnt%10)
			{
				tsBSC_Dev.u16BattSelfCycleCnt = (u16_t)(sBattSelfTestStr.u32MinuteCnt/10) + 1;
			}
			else
			{
				tsBSC_Dev.u16BattSelfCycleCnt = (u16_t)(sBattSelfTestStr.u32MinuteCnt/10);
			}

			if(sBattSelfTestStr.u32MinuteCnt)
			{
			    sBattSelfTestStr.u32MinuteCnt -= 1;
			}
			else
			{
				BscAutoLearningActiveProcess();
			}

		}
	}
	BattDischrgSelfTest_waittime();

	if((sBattCtrlStr.eBattCtrl == ManualLearning) || (sBattCtrlStr.eBattCtrl == AutoLearning))
	{

		switch(sBattSelfTestStr.u16Step)
		{
			case BSTStep_Idle:

				break;

			case BSTStep_WrClrCmd:
				if (GetActivateWrCmd() == 0)
				{
					//emergency state
					if(BattDischrgSelfTest_emergencystate() == 0)
					{
						//to clear battery status bit10,9,8.
						sBattCtrlStr.tnBbuIntCtrl.u16Bit.u2AgingComp = eAgingComp_ClrDischgrFlag;
						BscOgoWrPMBusCmd(0xFF, PMBusCmd_MFRSp30);
						sBattSelfTestStr.u16Step = BSTStep_WrClrCmdWaitTime;
						u8BattSelfTest1sec = BattSelfTest1sec;
						sBattSelfTestStr.u8WrClrCmdWaitTime = 0;
					}
				}
				break;

			case BSTStep_WrClrCmdWaitTime:

				break;

#if (BATT_SELFTEST_RETRY)
			case BSTStep_GetClrBits:
				u8BbuQty = ReturnBbuQtyCmdB8h();
				u8SelftestConfirm = 0;

				for(i=0; i<u8BbuQty; i++)
				{
					if((tsBBU_Dev[i].u16BattStatus&0x0700) != 0)
					{
						u8SelftestConfirm = 1;
						break;
					}
				}
				//emergency state
				if(BattDischrgSelfTest_emergencystate() == 0)
				{
					if(u8SelftestConfirm == 0)
					{
						sBattSelfTestStr.u16Step = BSTStep_WrReqCmd;
					}
					else
					{

						if(sBattSelfTestStr.u8WrClrCmdRetryCnt >= 3)
						{
							sBattSelfTestStr.nStatus.u16Bit.u1GetClrBitsError = 1;
							BscForceDischrgProcess(eLCond_ForcedStop);
						}
						else
						{
							sBattSelfTestStr.u8WrClrCmdRetryCnt += 1;
							sBattSelfTestStr.u16Step = BSTStep_WrClrCmd;
						}
					}
				}
				break;
#endif

			case BSTStep_WrReqCmd:
				if (GetActivateWrCmd() == 0)
				{
					//emergency state
					if(BattDischrgSelfTest_emergencystate() == 0)
					{
						//to enable bit10.
						sBattCtrlStr.tnBbuIntCtrl.u16Bit.u2AgingComp = eAgingComp_EnDischgrReq;
						BscOgoWrPMBusCmd(0xFF, PMBusCmd_MFRSp30);

#if (BATT_SELFTEST_RETRY)
						sBattSelfTestStr.u16Step = BSTStep_WrReqCmdWaitTime;
						u8BattSelfTest1sec = BattSelfTest1sec;
						sBattSelfTestStr.u8WrReqCmdWaitTime = 0;
#else
						sBattSelfTestStr.u16Step = BSTStep_GetReqBit10;
#endif
					}
				}
				break;
#if (BATT_SELFTEST_RETRY)
			case BSTStep_WrReqCmdWaitTime:

				break;
#endif
			case BSTStep_GetReqBit10:
				sBattSelfTestStr.u16Bit10 = 0;

				u8BbuQty = ReturnBbuQtyCmdB8h();
				for(i=0, u16BbuPresentBit=0; i<u8BbuQty; i++)
				{
					u16BbuPresentBit |= (1<<i);
				}

				//for(i=0; i<BBU_DEV_NUM; i++)
				for(i=0; i<u8BbuQty; i++)
				{
					if((tsBBU_Dev[i].u16BattStatus>>10)&0x0001)
					{
						sBattSelfTestStr.u16Bit10 |= (0x0001<<i);
					}
				}
				//emergency state
				if(BattDischrgSelfTest_emergencystate() == 0)
				{
					if(sBattSelfTestStr.u16Bit10 >= u16BbuPresentBit)//BATTSELFTEST_BBU_INDEX)
					{
						sBattSelfTestStr.u16Step = BSTStep_GetReadyBit9;
						u8BattSelfTest1sec = BattSelfTest1sec;
						sBattSelfTestStr.u16GetBit9TimeOut = 0;
					}
#if (BATT_SELFTEST_RETRY)
					else
					{
						if(sBattSelfTestStr.u8WrReqCmdRetryCnt >= 3)
						{
							sBattSelfTestStr.nStatus.u16Bit.u1GetBit10Error = 1;
							BscForceDischrgProcess(eLCond_ForcedStop);
						}
						else
						{
							sBattSelfTestStr.u8WrReqCmdRetryCnt += 1;
							sBattSelfTestStr.u16Step = BSTStep_WrReqCmd;
						}
					}
#endif
				}
				break;

			case BSTStep_GetReadyBit9:
				sBattSelfTestStr.u16Bit9 = 0;

				u8BbuQty = ReturnBbuQtyCmdB8h();
				for(i=0, u16BbuPresentBit = 0; i<u8BbuQty; i++)
				{
					u16BbuPresentBit |= (1<<i);
				}
				//for(i=0; i<BBU_DEV_NUM; i++)
				for(i=0; i<u8BbuQty; i++)
				{
					if((tsBBU_Dev[i].u16BattStatus>>9)&0x0001)
					{
						sBattSelfTestStr.u16Bit9 |= (0x0001<<i);
					}
				}
				//emergency state
				if(BattDischrgSelfTest_emergencystate() == 0)
				{
					if(sBattSelfTestStr.u16Bit9 >= u16BbuPresentBit)//BATTSELFTEST_BBU_INDEX)
					{
						//Ac Good L
						TURN_L_BBS_ACLOSS();
						sBattSelfTestStr.u16Step = BSTStep_GetDoneBit8;

					}
#if (BATT_SELFTEST_RETRY)
					else
					{
						if(sBattSelfTestStr.nStatus.u16Bit.u1GetBit9Error)
						{
							BscForceDischrgProcess(eLCond_ForcedStop);
						}
					}
#endif

				}
				break;
            case BSTStep_GetDoneBit8:
                sBattSelfTestStr.u16Bit8 = 0;

				u8BbuQty = ReturnBbuQtyCmdB8h();
				for(i=0, u16BbuPresentBit = 0; i<u8BbuQty; i++)
				{
					u16BbuPresentBit |= (1<<i);
				}
				//for(i=0; i<BBU_DEV_NUM; i++)
				for(i=0; i<u8BbuQty; i++)
				{
					if((tsBBU_Dev[i].u16BattStatus>>8)&0x0001)
					{
						sBattSelfTestStr.u16Bit8 |= (0x0001<<i);
					}
				}
				//emergency state
				if(BattDischrgSelfTest_emergencystate() == 0)
				{
					if(sBattSelfTestStr.u16Bit8 >= u16BbuPresentBit)//BATTSELFTEST_BBU_INDEX)
					{
						TURN_H_BBS_ACGOOD();
						sBattSelfTestStr.u16Step = BSTStep_Idle;

						if (sBattCtrlStr.eBattCtrl == ManualLearning)
						{
							UpdateLearningResult(elResult_ManualSuccess, 0);
						}
						else
						{
							UpdateLearningResult(elResult_AutoSuccess, 0);
						}

						sBattCtrlStr.eBattCtrl = BattCtrlClear;

						//to clear battery status bit10,9,8.
						sBattCtrlStr.tnBbuIntCtrl.u16Bit.u2AgingComp = eAgingComp_ClrDischgrFlag;
						BscOgoWrPMBusCmd(0xFF, PMBusCmd_MFRSp30);
					}
				}
				break;

		}
	}
}
/****************************************************************************
*	name        : DepthOfDischrgProcess
*	description :
*	return      : none
****************************************************************************/
void DepthOfDischrgProcess(void)
{
	if(sBattCtrlStr.eBattCtrl == DepthOfDischrg)
	{
		if(VINOK_ON_BIT != kbitSet)
		{
			sBattCtrlStr.eBattCtrl = BattCtrlClear;

			//to initial
			UpdateManualDischrgStatus(0);
			sBattCtrlStr.tnBbuIntCtrl.u16Bit.u2AgingComp = eAgingComp_Default;
			BscOgoWrPMBusCmd(0xFF, PMBusCmd_MFRSp30);
		}
	}
}
/****************************************************************************
*	name        : CurrentSharingProcess
*	description :
*	return      : none
****************************************************************************/
void CurrentSharingProcess(void)
{
	u16_t i, u16DevPresent;

	if(u8CurrSharing500ms != CurrSharing500ms)
	{
		u8CurrSharing500ms = CurrSharing500ms;

		sRemoteCsStr.u8TimerCnt += 1;
		if(sRemoteCsStr.u8TimerCnt > 4)
		{
			sRemoteCsStr.u8TimerCnt = 0;
			u16DevPresent = GetPresentDeviceIndex();

			if(u16DevPresent == 0)
			{
				sRemoteCsStr.u16BbuPresent = 0;
				sRemoteCsStr.u8State = 0;
				UpdateCurrSharingStatus(0);
				return;
			}

			if(sRemoteCsStr.u16BbuPresent != u16DevPresent)
			{
				sRemoteCsStr.u16BbuPresent = u16DevPresent;
				sRemoteCsStr.u8State = 0;
				UpdateCurrSharingStatus(0);
			}

			//scan current sharing status
			sRemoteCsStr.u16BbuCurrSharing = 0;
			for(i=0; i<BBU_DEV_NUM; i++)
			{
				if((sRemoteCsStr.u16BbuPresent>>i)&0x0001)
				{
					if(tsBBU_Dev[i].tnStateBBU.u16Bit.u1Bit12)
					{
						sRemoteCsStr.u16BbuCurrSharing |= (0x0001<<i);
					}

				}
			}

			if(sRemoteCsStr.u8State == 0)
			{
				if(sRemoteCsStr.u16BbuCurrSharing != 0)
				{
					if(sRemoteCsStr.u16BbuCurrSharing == sRemoteCsStr.u16BbuPresent)
					{
						sRemoteCsStr.u8State = 1;
					}
					else
					{
						UpdateCurrSharingStatus(1);
						BscOgoWrPMBusCmd(0xFF, PMBusCmd_MFRSp30);
					}
				}
			}
			else	// remote cs have enabled
			{

				if(sRemoteCsStr.u16BbuCurrSharing == 0)
				{
					sRemoteCsStr.u8State = 0;
					UpdateCurrSharingStatus(0);
				}

			}
		}

	}
}
/****************************************************************************
*	name        : ModeChangeProcess
*	description :
*	return      : none
****************************************************************************/
#if(PR_JULDY)
void ModeChangeProcess(void)
{
	if(u8ModeChange1ms != ModeChange1ms)
	{
		u8ModeChange1ms = ModeChange1ms;

		if(sBattCtrlStr.eBattCtrl == BattCtrlClear)
		{
			if(tsBSC_Dev.u16ModeChange == eOpMode_OffLine)
			{
				if(VINOK_ON_BIT == kbitSet)
				{
					TURN_H_BBS_ACGOOD();
				}
				else
				{
					TURN_L_BBS_ACLOSS();//vout 12.7v
				}
			}
			else
			{
				TURN_H_BBS_ACGOOD();//vout 12.35
			}
		}
	}

}
#endif

/****************************************************************************
*	name        : ClearSlvDisconnectCount
*	description :
*	return      : none
****************************************************************************/
void ClearSlvDisconnectCount(void)
{
	sSlvDisconnectStr.u16TimerCnt = 0;
}
/****************************************************************************
*	name        : SlvDisconnectProcess
*	description :
*	return      : none
****************************************************************************/
void SlvDisconnectProcess(void)
{
	if(sSlvDisconnectStr.u8Sys100ms != SlvDisconnect100ms)
	{
		sSlvDisconnectStr.u8Sys100ms = SlvDisconnect100ms;
		if(tsBSC_Dev.u16ModeChange == eOpMode_OffLine)
		{
			sSlvDisconnectStr.u16TimerCnt += 1;
			if(sSlvDisconnectStr.u16TimerCnt > 300)	//30sec
			{
				ClearSlvDisconnectCount();
				tsBSC_Dev.u16ModeChange = eOpMode_OnLine;
			}
			else
			{

			}

		}
		else
		{
			ClearSlvDisconnectCount();
		}
	}

}
