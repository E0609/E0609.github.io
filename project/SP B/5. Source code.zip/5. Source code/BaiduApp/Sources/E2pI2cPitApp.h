/****************************************************************************
*	file	i2cbitbang_pit.h
*	brief	include I2C master driver
*
*	author allen.lee
* 	version 1.0
*		-	2014/05/05: initial version by allen lee
*
****************************************************************************/

#ifndef E2PI2CPITAPP_H_
#define E2PI2CPITAPP_H_

#include "define.h"
#include "board.h"
#include "SysTime.h"

#define E2pI2cPit
/****************************************************************************
*   Declared Macro
****************************************************************************/
#define E2pI2cPit10ms          	gtMcuTimer.u8Sys10ms

#define E2pI2cPitTimeOut10ms	gtMcuTimer.u8Sys10ms
#define E2PI2CPITTIMEOUT        (50)			// 50x10msec
//----------------------------------------------------------------------------
#define I2cGpioSda_SetHi() 		GPIO_DRV_SetPinOutput(kGpioEeprom_Sda)
#define I2cGpioSda_SetLo() 		GPIO_DRV_ClearPinOutput(kGpioEeprom_Sda)
#define I2cGpioSda_GetLevel()	(GPIO_DRV_ReadPinInput(kGpioEeprom_Sda))

#define I2cGpioSda_SetDirOut()	GPIO_DRV_OutputPinInit(i2cgpioSdaOutPins)
#define I2cGpioSda_SetDirInt()	GPIO_DRV_InputPinInit(i2cgpioSdaIntPins)

#define I2cGpioScl_SetHi() 		GPIO_DRV_SetPinOutput(kGpioEeprom_Scl)
#define I2cGpioScl_SetLo() 		GPIO_DRV_ClearPinOutput(kGpioEeprom_Scl)
#define I2cGpioScl_GetLevel()	GPIO_DRV_ReadPinInput(kGpioEeprom_Scl)

#define I2cGpioScl_SetDirOut()	GPIO_DRV_OutputPinInit(i2cgpioSclOutPins)
#define I2cGpioScl_SetDirInt()	GPIO_DRV_InputPinInit(i2cgpioSclIntPins)
//----------------------------------------------------------------------------
typedef enum _bitbang_status_t {
	kBB_irq_Idle        = 0x00,
	kBB_irq_WrInit_1,
	kBB_irq_WrInit_2,
	kBB_irq_WrStart,
	kBB_irq_WrBit,
	kBB_irq_WrLoop,
	kBB_irq_RdAck_1,
	kBB_irq_RdAck_2,
	kBB_irq_RdAck_3,
	kBB_irq_WrStop_1,
	kBB_irq_WrStop_2,
	kBB_irq_WrStop_3,
	kBB_irq_Wrapup,

	kBB_irq_RdInit,
	kBB_irq_RdDtStart,
	kBB_irq_RdDtBit,
	kBB_irq_RdDtInit_2,
	kBB_irq_RdDtLoop,
	kBB_irq_WrAckBit_1,
	kBB_irq_WrAckBit_2,

} bitbang_status_t;
//----------------------------------------------------------------------------
typedef enum _bitbang_mode_t {
	kbbmode_idle          	= 0x00,
	kbbmode_write          	= 0x01,
	kbbmode_read			= 0x02,

} bitbang_mode_t;
//----------------------------------------------------------------------------
typedef enum _bitbang_ack_logic_t {
	kbitbang_ack = 0U,
    kbitbang_nack = 1U
} bitbang_ack_logic_t;
//----------------------------------------------------------------------------
#define E2P_FREQUENCY 10000 //unit hz

#if (E2P_FREQUENCY == 10000)
	//#define E2P_BITBANG_DELAY	210000	//~400msec: 1msec(1byte)*400
	#define E2P_BITBANG_DELAY	250000	//~500msec: 1msec(1byte)*500
	#define E2P_PIT0_PERIOD_T	(50)	//us, (1/10000)/2x1000000 (us)

#elif(E2P_FREQUENCY == 1000)
	#define E2P_BITBANG_DELAY  	2000000	//~2sec: 10msec(1byte)*200
	#define E2P_PIT0_PERIOD_T	(500)	//us, (1/1000)/2x1000000 (us)
#else
	//#define E2P_BITBANG_DELAY  	2000000	//~2sec: 10msec(1byte)*200
	//#define E2P_PIT0_PERIOD_T	(500)	//us, (1/1000)/2x1000000 (us)
#endif
//----------------------------------------------------------------------------
#define EEPROM_M24C08
//#define EEPROM_M24C256
//#define EEPROM_AT24C04
//----------------------------------------------
#if defined(EEPROM_M24C08)
	#define E2P_MAX_WRITE_BYTES	16	//page write mode up to 16 bytes.
	#define E2P_MAX_READ_BYTES	1024	//the max read bytes once.
	#define E2P_MAX_BYTEADDR	1
	#define E2P_MAX_OUTE_BYTES	(E2P_MAX_WRITE_BYTES+E2P_MAX_BYTEADDR+1)
	#define E2P_END_ADDRESS		0x03ff

#elif defined (EEPROM_AT24C04)
	#define E2P_MAX_WRITE_BYTES	16	//page write mode up to 16 bytes.
	#define E2P_MAX_READ_BYTES  512	//the max read bytes once.
	#define E2P_MAX_BYTEADDR	1
	#define E2P_MAX_OUTE_BYTES	(E2P_MAX_WRITE_BYTES+E2P_MAX_BYTEADDR+1)
	#define E2P_END_ADDRESS		0x01ff

#elif defined (EEPROM_M24C256)
	#define E2P_MAX_WRITE_BYTES	64	//page write mode up to 64 bytes
	#define E2P_MAX_READ_BYTES	64	//the max read bytes once.
	#define E2P_MAX_BYTEADDR	2
	#define E2P_MAX_OUTE_BYTES	(E2P_MAX_WRITE_BYTES+E2P_MAX_BYTEADDR+1)
	#define E2P_END_ADDRESS		0x7fff
#endif
//----------------------------------------------
#define E2P_DEV_ADDRESS		0xA0
//----------------------------------------------------------------------------
typedef enum _E2p_Result_t {
	kE2p_Free,
	kE2p_Busy,

	kE2p_TransmitedError,
	kE2p_Transmited_TooManyBytes,
	kE2p_Transmited_NotEnoughBytes,

	kE2p_ReceivedError,
	kE2p_Received_TooManyBytes,
	kE2p_Received_NotEnoughBytes,

} E2p_Result_t;
/****************************************************************************
* Declare structure
****************************************************************************/
#pragma pack(1)
typedef struct _sE2pi2cpit_master_t {
	u8_t  u8mode, u8status;
	u8_t  u8bit_count, u8data, u8timeout_ms;
	u8_t  pu8outbuff[E2P_MAX_OUTE_BYTES], *pu8intbuff;
	u16_t u16outlen, u16intlen;
	u16_t u16out_count, u16int_count;

} sE2pi2cpit_master_t;
#pragma pack()
/****************************************************************************
*   Declared Export Global Variables
****************************************************************************/



/****************************************************************************
*   Declared Export functions
****************************************************************************/
extern u8_t i2cbb_master_Ismode(void);
extern u8_t i2cbb_master_wr_status(void);
extern u8_t i2cbb_master_rd_status(void);
extern void i2cbb_wr_irq_statemachine(void);
extern void i2cbb_rd_irq_statemachine(void);
extern u8_t i2cbb_master_sendbytes(u16_t u16bytelen, u16_t u16byteaddr, u16_t u16len, u8_t *pu8buff);
extern u8_t i2cbb_master_readbytes(u16_t u16bytelen, u16_t u16byteaddr, u16_t u16len, u8_t *pu8buff);
extern void Init_E2pI2cBitBang(void);
extern void E2pI2cBitBangReset(void);
extern void E2pI2cBitBangProcess(void);
#endif /* E2PI2CPITAPP_H_ */
