/****************************************************************************
*	file	I2C.h
*	brief	include I2C master driver
*
*	author allen.lee
* 	version 1.0
*		-	2014/05/05: initial version by allen lee
*
****************************************************************************/

#ifndef I2C_H_
#define I2C_H_

#include "define.h"
#include "fsl_i2c_hal.h"
/****************************************************************************
*   Declared Macro
****************************************************************************/
//#define	I2C_MASTER_DEBUG
//#define	I2C_MASTER_SSIE_ENABLE
//#define		I2C_MASTER_ARBL
//----------------------------------------------

//----------------------------------------------
#define MASTER_I2C_TXRX		(2)
#define MASTER_I2C_TX    	(0)
#define MASTER_I2C_RX    	(1)

#define I2C_ADDRESS_SIZE    (2)
//----------------------------------------------
#define PEC_SUPPORT			(1)	//DISABLE-0, ENABLE-1
/****************************************************************************
 * Global Variables
 ****************************************************************************/

/****************************************************************************
* Declare structure
****************************************************************************/

//----------------------------------------------
typedef enum _ePMBus_Protocol_t {
    None              = 0x0U,
    WriteNbyte        = 0x1U,
    Block_WriteNbyte  = 0x2U,
    ReadNbyte         = 0x3U,
    Block_ReadNbyte   = 0x4U,
    ProcessCall       = 0x5U,
    Block_ProcessCall = 0x6U

} ePMBus_Protocol_t;
//----------------------------------------------
typedef union _nPMBus_Status_t
{
   struct
   {
        u8_t   u1PECSupport	    :1;
        u8_t   u6NA				:6;
		u8_t   u1ReadByteCnt  	:1;
   } u8Bit;

   u8_t u8All;
} nPMBus_Status_t;
//----------------------------------------------
#pragma pack(1)
typedef struct _si2c_master_t {
	u8_t u8Mode;
	i2c_status_t status;

	ePMBus_Protocol_t    ePMBusProtcol;
	nPMBus_Status_t      tnPMBusSt;

	u8_t  pu8SaddrBuff[I2C_ADDRESS_SIZE];
    u32_t u32SaddrSize;

    u8_t* pu8CmdBuff;
    u32_t u32CmdSize;

    u8_t* pu8TxBuff;
    u32_t u32TxSize;

    u8_t* rxBuff;
    u32_t rxSize;

    bool i2cIdle;

    u32_t u32timeout_ms;

} si2c_master_t;
#pragma pack()
/****************************************************************************
*   Declared Export functions
****************************************************************************/
/* External for the I2C master driver interrupt handler.*/
extern void i2c_master_irq_handler(u32_t instance);

extern i2c_status_t MasterI2cBustimeout(u32_t instance, u32_t timeout_ms);
extern bool MasterI2cSend(u32_t u32instance, u16_t u16address, u8_t * pu8cmdBuff, u32_t u32cmdSize, u8_t * pu8txBuff, u32_t u32txSize)
;
extern bool MasterI2cReStartReceive(u32_t instance, u16_t address, u8_t * cmdBuff, u32_t cmdSize,
		u8_t * txBuff, u32_t txSize, u8_t * rxBuff, u32_t rxSize);

extern bool GetMasterI2cIdleFlage(u32_t instance);
extern bool GetMasterI2cPECSupportFlage(u32_t u32instance);
extern i2c_status_t GetMasterI2cStatus(u32_t instance);

extern void Init_MasterI2c(u32_t instance);
extern void DeInit_MasterI2c(u32_t instance);

#ifdef I2C_MASTER_DEBUG
extern void Proc_I2C_Master_Test(u32_t instance);
#endif
#endif /* I2C_H_ */
