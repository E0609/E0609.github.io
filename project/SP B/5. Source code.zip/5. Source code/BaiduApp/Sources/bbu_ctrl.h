/****************************************************************************
*	file	bbu_led.h
*	brief	include bbu_led
*
*	author allen.lee
* 	version 1.0
*		-	2014/05/05: initial version by allen lee
*
****************************************************************************/

#ifndef BBU_LED_H_
#define BBU_LED_H_

#include "define.h"
#include "SysTime.h"
#include "macro_define.h"

/****************************************************************************
*   Declared Macro
****************************************************************************/
#if(PR_JULDY)
#define BATTSELFTEST_BBU_RSOC   (95)	// mmet RSOC >= 95%
#else
#define BATTSELFTEST_BBU_RSOC   (98)	// mmet RSOC >= 98%
#endif
//----------------------------------------------
#define	KEY_CONFIRM_TIME_3S	    (30)
#define	KEY_CONFIRM_TIME_6S	    (60)
#define	KEY_CONFIRM_TIME_9S	    (90)

#define Key100ms    			gtMcuTimer.u8Sys100ms

#define BattSelfTest1min		gtMcuTimer.u8Sys1min
#define BattSelfTest1sec		gtMcuTimer.u8Sys1s

#define BbuRegularWr10ms		gtMcuTimer.u8Sys10ms

#define CurrSharing500ms		gtMcuTimer.u8Sys500ms

#define ModeChange1ms		    gtMcuTimer.u8Sys1ms

#define SlvDisconnect100ms		gtMcuTimer.u8Sys100ms
//----------------------------------------------
#define BBS_EN_BIT				tnSTA_Ctrl1.u8Bit.u1BBS_EN
#define BBS_ONLINE_BIT			tnSTA_Ctrl1.u8Bit.u1BBS_ONLINE
#define BBS_ACGOOD_BIT			tnSTA_Ctrl1.u8Bit.u1BBS_ACGOOD
#define VOU33_ON_BIT			tnSTA_Ctrl1.u8Bit.u1VOU33_ON
#define VINOK_ON_BIT			tnSTA_Ctrl1.u8Bit.u1VIN_OK
//----------------------------------------------------------------------------
typedef enum  _bbu_ctrl_bit_t {
	kbitClr = 0U,
	kbitSet = 1U,
} bbu_ctrl_bit_t;

/****************************************************************************
*   Declared Structures & Variables
****************************************************************************/
typedef union _nStatusCtrl1_t
{
    struct
    {
        u8_t u1BBS_EN    	:1; //
	    u8_t u1BBS_ONLINE	:1;
	    u8_t u1BBS_ACGOOD	:1;
	    u8_t u1VOU33_ON     :1;
	    u8_t u1VIN_OK    	:1;
	    u8_t u1Bit5    :1;
	    u8_t u1Bit6    :1;
	    u8_t u1Bit7    :1;

    } u8Bit;

    u8_t u8All;
} nStatusCtrl1_t;
extern nStatusCtrl1_t tnSTA_Ctrl1;
//----------------------------------------------------------------------------
//content of BBh
typedef enum _eBscModeChange_t
{
	eOpMode_OnLine  = 0U,
	eOpMode_OffLine	= 1U,
	eOpMode_Idle 	= 2U,
}eBscModeChange_t;
//----------------------------------------------------------------------------
//content of B9h
typedef enum _eBscLearnOperation_t
{
	elOperate_Idle   = 0U,
	elOperate_Auto   = 1U,
	elOperate_Manual = 2U,
}eBscLearnOperation_t;
//----------------------------------------------
typedef enum _eBscLearnResult_t
{
	elResult_Default     = 0U,
	elResult_AutoSuccess = 1U,
	elResult_AutoFailure = 2U,
	elResult_ManualSuccess = 3U,
	eLResult_ManualFailure = 4U,
}eBscLearnResult_t;
//----------------------------------------------
typedef enum _eBscLearnCondition_t
{
	eLCond_Normal = 0U,
	eLCond_VinOkAnormal = 1U,
	eLCond_RsocAnormal  = 2U,
	eLCond_BbuAnormal   = 4U,
	eLCond_ForcedStop   = 8U,
	eLCond_BbuProtection=16U,

}eBscLearnCondition_t;
//----------------------------------------------
typedef union
{
	struct
	{
#if (BATT_SELFTEST_RETRY)
		unsigned u1GetClrBitsError	:1;
		unsigned u1GetBit10Error	:1;
		unsigned u1GetBit9Error		:1;

		unsigned u13NA	:13;
#else
		unsigned u11NA   :1;
		unsigned u15NA	:15;
#endif
	}u16Bit;

	u16_t u16All;
}sBattSelfTestFlag_t;

//----------------------------------------------
typedef enum _esBattSelfTestStep_t {
#if (BATT_SELFTEST_RETRY)
    BSTStep_Idle     		= 0x0U,
    BSTStep_WrClrCmd 		= 0x1U,
    BSTStep_WrClrCmdWaitTime= 0x2U,
    BSTStep_GetClrBits	    = 0x3U,
    BSTStep_WrReqCmd		= 0x4U,
    BSTStep_WrReqCmdWaitTime= 0x5U,
    BSTStep_GetReqBit10		= 0x6U,
    BSTStep_GetReadyBit9	= 0x7U,
    BSTStep_GetDoneBit8		= 0x8U,

#else
    BSTStep_Idle     		= 0x0U,
    BSTStep_WrClrCmd 		= 0x1U,
    BSTStep_WrClrCmdWaitTime 		= 0x2U,
    BSTStep_WrReqCmd		= 0x3U,
    BSTStep_GetReqBit10		= 0x4U,
    BSTStep_GetReadyBit9	= 0x5U,
    BSTStep_GetDoneBit8		= 0x6U,
#endif

} sBattSelfTestStep_t;
//----------------------------------------------
typedef struct _sBattSelfTestStr_t
{
	sBattSelfTestFlag_t nStatus;
	sBattSelfTestStep_t u16Step;

	u16_t u16DevPresent, u16Bit10, u16Bit9, u16Bit8;
	u16_t u16DevIndex;

	u32_t u32MinuteCnt;

	u8_t u8WrClrCmdWaitTime;
#if (BATT_SELFTEST_RETRY)
	u8_t u8WrClrCmdRetryCnt;
	u8_t u8WrReqCmdWaitTime;
	u8_t u8WrReqCmdRetryCnt;
	u16_t u16GetBit9TimeOut;
#endif

} sBattSelfTestStr_t;

extern sBattSelfTestStr_t sBattSelfTestStr;

//----------------------------------------------------------------------------
typedef enum _eAgingCompCtrl_t {
	eAgingComp_Default = 0U,
	eAgingComp_EnDischgrReq  = 1U,
	eAgingComp_ClrDischgrFlag = 2U,
}eAgingCompCtrl_t;
//----------------------------------------------
typedef enum _eBattCtrlStatus_t {
    BattCtrlClear     = 0x00,
    DepthOfDischrg    = 0x01,
    ManualLearning    = 0x02,
    AutoLearning      = 0x04

} eBattCtrlStatus_t;
//----------------------------------------------
typedef union _nBbuIntControl_t
{
    struct
    {
        u16_t u2AgingComp		:2; //
        u16_t u6Rsvd1			:6;

        u16_t u1EnCurrSharing 	:1;
        u16_t u7Rsvd2			:7;
    } u16Bit;

    u16_t u16All;
} nBbuIntControl_t;
//----------------------------------------------
typedef struct _sBatteryControlStr_t
{
	eBattCtrlStatus_t	eBattCtrl;

	nBbuIntControl_t tnBbuIntCtrl;	//internal EEh

} sBatteryControlStr_t;

extern sBatteryControlStr_t sBattCtrlStr;
//----------------------------------------------------------------------------
typedef struct _sKeyStr_t
{
	u8_t u8OkeyState, u8keyState;
	u8_t u8KeyCnt_3S, u8KeyCnt_6S, u8KeyCnt_9S;
	u8_t u8PressingState;
} sKeyStr_t;

extern sKeyStr_t sKeyStr;
//----------------------------------------------------------------------------
typedef struct _sBbuRegularWrPMBusStr_t
{
	u8_t u8Timer10ms;
	//u8_t u8Timer100ms;
	u16_t u16TimerCnt;
} sBbuRegularWrPMBusStr_t;

extern sBbuRegularWrPMBusStr_t sBbuRegWrStr;
//----------------------------------------------------------------------------
typedef struct _sRemoteCurrSharingStr_t
{
	u8_t u8Sys500ms;
	u8_t u8TimerCnt;

	u8_t u8State;

	u16_t u16BbuPresent;
	u16_t u16BbuCurrSharing;

} sRemoteCurrSharingStr_t;

extern sRemoteCurrSharingStr_t sRemoteCsStr;
//----------------------------------------------------------------------------
typedef struct _sSlvDisconnectStr_t
{
	u8_t u8Sys100ms;
	u16_t u16TimerCnt;

} sSlvDisconnectStr_t;

extern sSlvDisconnectStr_t sSlvDisconnectStr;
/****************************************************************************
*   Declared Export functions
****************************************************************************/
extern void Init_BbuGpio(void);
extern void Init_Key(void);
extern void OnLineMode_Ctrl(void);
extern void OffLineMode_Ctrl(void);
extern void IdleMode_Ctrl(void);
extern void BbuRegularWrProcess(void);
extern void BscForceDischrgProcess(u16_t u16Error);
extern void BscManualLearningActiveProcess(void);
extern void KeyCtrlProcess(void);
extern void ReloadBattSelfTestCount(u8_t u8Set);
extern void BattDischrgSelfTestProcess(void);
extern void DepthOfDischrgProcess(void);
extern void CurrentSharingProcess(void);
#if(PR_JULDY)
extern void ModeChangeProcess(void);
#endif
extern void ClearSlvDisconnectCount(void);
extern void SlvDisconnectProcess(void);
#endif /* BBU_LED_H_ */
