/*******************************************************************************
* file				crc8.h
* brief				The file includes CRC8 checksum of the PMBus.
* note
* author			slade.fang
* version			01
* section History	2014/09/01 - 1st release
*******************************************************************************/

#ifndef CRC8_H_
#define CRC8_H_

#include "define.h"
/*******************************************************************************
* declare extern function
*******************************************************************************/
extern void CalCRC8(u8_t *pu8CRC, u8_t u8Data);




#endif /* CRC8_H_ */
