/****************************************************************************
*	file	flash_memory.h
*	brief	include flash driver
*
*	author allen.lee
* 	version 1.0
*		-	2015/10/01: initial version by allen lee
*
****************************************************************************/

#ifndef FLASH_MEMORY_H_
#define FLASH_MEMORY_H_

#include "define.h"
#include "flash_status.h"

#define	FLASH_DEBUG		(0)
/****************************************************************************
 * Global Variables
 ****************************************************************************/

/****************************************************************************
* Declare structure
****************************************************************************/


/****************************************************************************
*   Declared Export functions
****************************************************************************/
extern flash_status_t flash_mem_init(void);

extern flash_status_t flash_mem_erase(u32_t u32address, u32_t u32length);

extern flash_status_t flash_mem_read(u32_t u32address, u32_t u32length, u8_t * pu8buffer);

extern flash_status_t flash_mem_write(u32_t u32address, u32_t u32length, u8_t * pu8buffer);


#if (FLASH_DEBUG)
extern void Proc_Flash_memory_Test(void);
#endif

#endif /* FLASH_MEMORY_H_ */
