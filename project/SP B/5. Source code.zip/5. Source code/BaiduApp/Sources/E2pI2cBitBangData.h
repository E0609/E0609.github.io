/****************************************************************************
*	file	E2pI2cBitBangData.h
*	brief	include bbu_led
*
*	author allen.lee
* 	version 1.0
*		-	2014/05/05: initial version by allen lee
*
****************************************************************************/

#ifndef E2PI2CBITBANGDATA_H_
#define E2PI2CBITBANGDATA_H_

#include "define.h"
#include "SysTime.h"

#define E2PData_Table (1)
/****************************************************************************
*   Declared Macro
****************************************************************************/
#define E2PData10ms		gtMcuTimer.u8Sys10ms
//---------------------------------------------------------------------
//define the EEPROM data structure
typedef enum
{
	E2PDataRev0 = 0,
	E2PDataRev1,
	E2PDataRev2,

	Manufacture0,
	Manufacture1,
	Manufacture2,
	Manufacture3,
	Manufacture4,
	Manufacture5,
	Manufacture6,
	Manufacture7,
	Manufacture8,
	Manufacture9,

	ModelName0,
	ModelName1,
	ModelName2,
	ModelName3,
	ModelName4,
	ModelName5,
	ModelName6,
	ModelName7,
	ModelName8,
	ModelName9,
	ModelName10,

	HardwareRev0,
	HardwareRev1,
	HardwareRev2,

	SeriealNum0,
	SeriealNum1,
	SeriealNum2,
	SeriealNum3,
	SeriealNum4,
	SeriealNum5,
	SeriealNum6,
	SeriealNum7,
	SeriealNum8,
	SeriealNum9,

	BarCode0,
	BarCode1,
	BarCode2,
	BarCode3,
	BarCode4,
	BarCode5,
	BarCode6,
	BarCode7,
	BarCode8,
	BarCode9,
	BarCode10,
	BarCode11,
	BarCode12,
	BarCode13,
	BarCode14,
	BarCode15,
	BarCode16,
	BarCode17,
	BarCode18,

	Rvd0_0,
	Rvd0_1,
	Rvd0_2,
	Rvd0_3,
	Rvd0_4,
	Rvd0_5,

	Date0,
	Date1,
	Date2,
	Date3,
	Date4,
	Date5,
	Date6,
	Date7,
	Date8,
	Date9,

	FwCompCode0,
	FwCompCode1,
	FwCompCode2,
	FwCompCode3,
	FwCompCode4,
	FwCompCode5,
	FwCompCode6,
	FwCompCode7,

	HwCompCode0,
	HwCompCode1,

	Location0,
	Location1,
	Location2,
	Location3,
	Location4,
	Location5,
	Location6,
	Location7,
	Location8,
	Location9,

	Rvd1_0,
	Rvd1_1,
	Rvd1_2,
	Rvd1_3,
	Rvd1_4,
	Rvd1_5,
	Rvd1_6,
	Rvd1_7,
	Rvd1_8,
	Rvd1_9,
	Rvd1_10,

	Rvd2_0,
	Rvd2_1,
	Rvd2_2,
	Rvd2_3,
	Rvd2_4,
	Rvd2_5,
	Rvd2_6,
	Rvd2_7,
	Rvd2_8,
	Rvd2_9,
	Rvd2_10,
	Rvd2_11,
	Rvd2_12,
	Rvd2_13,
	Rvd2_14,

	Rvd3_0,
	Rvd3_1,
	Rvd3_2,
	Rvd3_3,
	Rvd3_4,
	Rvd3_5,
	Rvd3_6,
	Rvd3_7,
	Rvd3_8,
	Rvd3_9,
	Rvd3_10,
	Rvd3_11,
	Rvd3_12,
	Rvd3_13,
	Rvd3_14,

    E2PPassword0,
    E2PPassword1,

	E2PDataNum
}eE2pDataIndex_t;
//----------------------------------------------
#define E2PDATA_START_ADDR			0x0000					//the start address of EEPROM
#define E2PDATA_NUM					E2PDataNum
#define E2PDATA_BEGIN_READ			2
//----------------------------------------------
#define E2P_PWD0	0x55
#define E2P_PWD1 	0xaa
/****************************************************************************
* Declare structure
****************************************************************************/
//----------------------------------------------
typedef enum _eE2pData_Status_t {
	E2pData_Read_Fault		= 0,
	E2pData_Read_Success    = 1,

	E2pData_Write_Push		= 1,
	E2pData_Write_Process	= 2,
	E2pData_Write_Done		= 3,

} eE2pData_Status_t;
//----------------------------------------------
typedef union _nE2pData_Status_t
{
   struct
   {
        u8_t   u1ReadSt	    :1;
        u8_t   u2WriteSt	:2;
		u8_t   u5NA  		:5;
   } u8Bit;

   u8_t u8All;
} nE2pData_Status_t;
//----------------------------------------------

#pragma pack(1)
typedef struct _sE2pi2cbb_data_t {
	nE2pData_Status_t      tnStatus;

	u8_t pu8InRam[E2PDATA_NUM];			//the read buffer of EEPROM
	u16_t pu16Index[E2PDATA_NUM];			//the write index buffer of EEPROM
	u8_t pu8Buff[E2PDATA_NUM];			//the write buffer of EEPROM
	u16_t u16PushIndex, u16WriteIndex;

} sE2pi2cbb_data_t;
#pragma pack()
extern sE2pi2cbb_data_t tE2pData;
/****************************************************************************
*   Declared Export functions
****************************************************************************/
extern void ResetE2PData(void);
extern void E2PDataDefault(void);
extern bool ReadE2PDataToRam(void);
extern bool PushE2PWriteLoop(void);
extern bool PushE2PWriteDataLoop(u8_t u8CmdCode, u8_t u8len, u8_t *pu8buff);
extern bool PushE2PWriteData(u16_t u16E2PIndex, u8_t u8E2PData);
extern void E2PDataWriteProcess(void);
#endif /* E2PI2CBITBANGDATA_H_ */
