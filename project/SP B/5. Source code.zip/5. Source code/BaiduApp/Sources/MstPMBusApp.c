/****************************************************************************
*	file	MstPMBusApp.c
*	brief	The file includes the function and data structure/variables
*		    for the PMBus protocol
*	author allen.lee
* 	version 1.0
*		-	2015/05/11: initial version by allen lee
*
****************************************************************************/
#include <string.h>
#include <stdio.h>
#include "i2c_master.h"
#include "MstPMBusApp.h"
#include "pmbus_master.h"
#include "crc8.h"
#include "bbu_ctrl.h"
#include "i2c_slave.h"
#include "E2pI2cBitBangData.h"
#include "macro_define.h"
#include "InVePrgmApp.h"
/****************************************************************************
*   Declared Structures & Variables
****************************************************************************/
extern void UpdateBscInVeBtCmd(u8_t u8Value);

static u8_t u8InVeBbuBt1msTimer;
static u8_t u8BbuBtloader100msTimer;
sPMBusPushWrStr_t tPMBusPushWrStr;
//----------------------------------------------------------------------------
const u8_t pu8BBUSlaveAddr[BBU_DEV_NUM] =
{
#if(INSPUR_BBS_ID)
		ADDR_0xB0, ADDR_0xB2, ADDR_0xB4, ADDR_0xB6,
	    ADDR_0xC0, ADDR_0xC2, ADDR_0xC4, ADDR_0xC6,
#else
	ADDR_0xA0, ADDR_0xA2, ADDR_0xA4, ADDR_0xA6,
	ADDR_0xB0, ADDR_0xB2, ADDR_0xB4, ADDR_0xB6,
    ADDR_0xC0, ADDR_0xC2, ADDR_0xC4, ADDR_0xC6,
    ADDR_0xD0, ADDR_0xD2, ADDR_0xD4, ADDR_0xD6
#endif

};
//----------------------------------------------------------------------------
const u8_t pu8DoltSlaveAddr[1] =
{
	ADDR_0xEF
};
/*******************************************************************************
* declare structure
*******************************************************************************/
typedef union
{
	struct
	{
		u16_t   u1MasterWr   	:1;	//1-present, 0-absent
		u16_t   u1MasterRd   	:1;
		u16_t   u1ActivateWrCmd	:1;	//0:not trigger write, 1:trigger write
		u16_t   u1ReSendMasterWr:1;

		u16_t   u13NA           :12;
	}u16Bit;

	u16_t u16All;
}nMstPMBusFlag_t;
//----------------------------------------------
#pragma pack(1)
typedef struct _sPMBusAppStr_t
{
    //master SMBus general data
	u8_t u8DevAddr;
	u8_t pu8CmdBuff[1];
	u8_t u8CmdCode;
	u8_t u8CmdType;
	u8_t u8WrCmdProperty;
	u8_t u8RdCmdProperty, u8RdCmdSequence;
	u8_t u8WrLen, u8TempWrLen;				//without slave address, command code, byte count, and PEC; include byte1,..byteM
	u8_t u8RdLen;				            //without slave address and PEC;include byte count byte1,...byteN
	u8_t pu8WrBuff[MSTR_PMBUSAPP_TX_BUFF];      //include byte1,..byteM
	u8_t pu8RdBuff[MSTR_PMBUSAPP_RX_BUFF];      //include byte count byte1,...byteN
	u8_t u8CRC8;
    u8_t u8PECSupport;	//1:enable, 0:disable
	u16_t u16RdCmdIndex;
    u16_t u16WrCmdIndex;

    nMstPMBusFlag_t   nStat;

#if 0
    sMstPMBusCmdStr_t* psCmd;
#endif
    sPMBusCmdStr_t* psCmd;
    //error count statistics
    u16_t u16BusTimeOutCnt;
    u16_t u16CRCFailCnt;
    u16_t u16ComFailCnt;

} sPMBusAppStr_t;
#pragma pack()

static sPMBusAppStr_t sPMBusAppStruct;
//---------------------------------------------------------------------
#pragma pack(1)
typedef struct _sPMBusAppWrbackupStr_t
{
    u8_t u8TempWrAddrIndex;
    u8_t u8WrCmdProperty;
    u8_t u8TempWrLen;
    u16_t u16WrCmdIndex;
    u8_t pu8WrBuff[MSTR_PMBUSAPP_TX_BUFF];
} sPMBusAppWrbackupStr_t;
#pragma pack()

static sPMBusAppWrbackupStr_t sPMBusAppWrbackupStruct;
//---------------------------------------------------------------------
typedef union
{
	struct
	{
		u16_t   u1PresentDev1   :1;	//1-present, 0-absent
		u16_t   u1PresentDev2   :1;
		u16_t   u1PresentDev3   :1;
		u16_t   u1PresentDev4   :1;
		u16_t   u1PresentDev5   :1;
		u16_t   u1PresentDev6   :1;
		u16_t   u1PresentDev7   :1;
		u16_t   u1PresentDev8   :1;
		u16_t   u1PresentDev9   :1;
		u16_t   u1PresentDev10  :1;
		u16_t   u1PresentDev11  :1;
		u16_t   u1PresentDev12  :1;
		u16_t   u1PresentDev13  :1;
		u16_t   u1PresentDev14  :1;
		u16_t   u1PresentDev15  :1;
		u16_t   u1PresentDev16  :1;

	}u16Bit;

	u16_t u16All;
}nDeviceFlag_t;
//----------------------------------------------
#pragma pack(1)
typedef struct _sDeviceStr_t
{
	u16_t u16Addr;
	u8_t u8AddrIndex;
	u8_t u8WrAddrIndex, u8TempWrAddrIndex;

	u8_t pu8DevNakCnt[BBU_DEV_NUM];
    nDeviceFlag_t   nDevStat;

    //error count statistics
    u16_t u16BusTimeOutCnt;
    u16_t u16CRCFailCnt;
    u16_t u16ComFailCnt;

} sDeviceStr_t;
#pragma pack()

static sDeviceStr_t sDevStruct;
//---------------------------------------------------------------------
#if (LITEON_BT)
typedef union
{
	struct
	{
		u16_t   u1CmdF0 :1;
		u16_t   u1CmdF1 :1;
		u16_t   u1CmdF2 :1;
		u16_t   u1CmdF3 :1;
		u16_t   u1CmdF4 :1;
		u16_t   u1CmdF5 :1;
		u16_t   u1CmdF6 :1;
		u16_t   u1CmdF7 :1;

		u16_t   u1BbuBtWr   	:1;	//1-present, 0-absent
		u16_t   u1BbuBtRd   	:1;
		u16_t   u1ActivateBbuBtWrCmd	:1;	//0:not trigger write, 1:trigger write
		u16_t   u1BbuBtLock   	:1;
		u16_t   u1BbuBtDummyCmd :1;
		u16_t   u3NA   	:3;

	}u16Bit;

	u16_t u16All;
}nBbuBtFlag_t;
//----------------------------------------------
#pragma pack(1)
typedef struct _sBbuBootloaderStr_t
{
	u16_t u16Addr, u16TempAddr;

	u8_t pu8CmdBuff[1];
	u8_t u8CmdCode;
	u8_t u8CmdType;
	u8_t u8WrCmdProperty;
	u8_t u8RdCmdProperty;
	u8_t u8WrLen, u8TempWrLen;				//without slave address, command code, byte count, and PEC; include byte1,..byteM
	u8_t u8RdLen;				            //without slave address and PEC;include byte count byte1,...byteN
	u8_t pu8WrBuff[MSTR_PMBUSAPP_TX_BUFF];      //include byte1,..byteM
	u8_t pu8RdBuff[MSTR_PMBUSAPP_RX_BUFF];      //include byte count byte1,...byteN
	u8_t u8CRC8;
    u8_t u8PECSupport;	//1:enable, 0:disable
	u16_t u16RdCmdIndex;
    u16_t u16WrCmdIndex;

    nBbuBtFlag_t   tnFlag;

    u16_t u16LockTimeOutCnt;

    sPMBusCmdStr_t* psCmd;
} sBbuBootloaderStr_t;
#pragma pack()

static sBbuBootloaderStr_t sBbuBtldStr;
#endif /* LITEON_BT */
//---------------------------------------------------------------------
#if (BAIDU_BT)
typedef union
{
	struct
	{

		u16_t	u1RdBt		:1;
		u16_t   u1RdBtDummy :1;
		u16_t   u2BtLock  :2;//0-unlock,1-DummyRd,2-Rd
		u16_t   u1WrBtLock  :1;

		u16_t   u11NA   	:11;

	}u16Bit;

	u16_t u16All;
}nBbuBaiduBtFlag_t;
//----------------------------------------------
#pragma pack(1)
typedef struct _sBbuBaiduBtStr_t
{
	u16_t u16Addr;
	u8_t u8AddrIndex;

	u8_t pu8CmdBuff[1];
	u8_t u8WrCmdProperty;
	u8_t u8RdCmdProperty;
	u8_t u8WrLen, u8TempWrLen;
	u8_t u8RdLen;
	u8_t pu8WrBuff[MSTR_PMBUSAPP_TX_BUFF];
	u8_t pu8RdBuff[MSTR_PMBUSAPP_RX_BUFF];
	u8_t u8CRC8;
	u16_t u16RdCmdIndex;
    u16_t u16WrCmdIndex;

    nBbuBaiduBtFlag_t   tnFlag;

    u16_t u16LockTimeOutCnt;
    u16_t u16DummyRdLockTime1ms;
    u16_t u16RdLockTime1ms;
    u32_t u32WrPrgmCnt;

    sPMBusCmdStr_t* psCmd;

} sBbuBaiduBtStr_t;

static sBbuBaiduBtStr_t sBbuBaiduBtStr;
#pragma pack()
#endif /* BAIDU_BT */
/*******************************************************************************
*	brief 	GetReSendMasterWrState
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
u8_t GetReSendMasterWrState(void)
{
	if(sPMBusAppStruct.nStat.u16Bit.u1ReSendMasterWr)
	{
		return(1);
	}
	else
	{
		return(0);
	}
}

/*******************************************************************************
*	brief 	GetMasterWrState
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
u8_t GetMasterWrState(void)
{
	if(sPMBusAppStruct.nStat.u16Bit.u1MasterWr)
	{
		return(1);
	}
	else
	{
		return(0);
	}
}
/*******************************************************************************
*	brief 	GetActivateWrCmd
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
u8_t GetActivateWrCmd(void)
{
	if(sPMBusAppStruct.nStat.u16Bit.u1ActivateWrCmd)
	{
		return(1);
	}
	else
	{
		return(0);
	}
}
/*******************************************************************************
*	brief 	GetPresentDeviceIndex
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
u16_t GetPresentDeviceIndex(void)
{
	return (sDevStruct.nDevStat.u16All);
}
/*******************************************************************************
*	brief 	GetPresentDeviceAddress
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
u8_t GetPresentDeviceAddress(u8_t u8Index)
{
	return (pu8BBUSlaveAddr[u8Index]);
}
/*******************************************************************************
*	brief 	GetPresentDeviceAddress
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
u8_t GetDeviceAddressIndex(u8_t u8Address, u8_t u8maskBit)
{
	u8_t i;

	u8maskBit &= 0x01;

	for (i=0; i<BBU_DEV_NUM; i++)
	{
	    if (u8Address == (pu8BBUSlaveAddr[i] | u8maskBit))
	    {
	    	break;
	    }
	}
	return (i);
}

/*******************************************************************************
*	brief 	handle the master PM Bus Reset
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
void MstPMBusReset(void)
{
    bool bstatus;

    bstatus = MstPMBusTimeout(HW_I2C1);
    if (bstatus == true)
    {
    	//TURN_TGL_MTEST();
#if (BAIDU_BT)
    	sPMBusAppStruct.nStat.u16Bit.u1ReSendMasterWr = 1;
    	if(GetInVeBbuBtLock() == 0)
    	{
    		tsBsc_Str.u8TaskSchd = ConfirmingMode;
    	}
    	else
    	{

    	}
#else
    	tsBsc_Str.u8TaskSchd = ConfirmingMode;
#endif

    }
}
/****************************************************************************
*	name        : BuildBbuBtldWrProcess
*	description :
*	return      : none
****************************************************************************/
#if (LITEON_BT)
void BuildBbuBtldWrProcess(void)
{
	if (sBbuBtldStr.u8WrCmdProperty == PMBusCP_RdWr)
	{
		sBbuBtldStr.psCmd = &sBbuBLPMBusRWCmd[sBbuBtldStr.u16WrCmdIndex];
		sBbuBtldStr.pu8CmdBuff[0] = sBbuBtldStr.psCmd->u8CmdCode;
		sBbuBtldStr.u8WrLen = sBbuBtldStr.u8TempWrLen;
		sBbuBtldStr.u16Addr = sBbuBtldStr.u16TempAddr;

	}
	else if (sBbuBtldStr.u8WrCmdProperty == PMBusCP_WrOnly)
	{
		sBbuBtldStr.psCmd = &sBbuBLPMBusWOCmd[sBbuBtldStr.u16WrCmdIndex];
		sBbuBtldStr.pu8CmdBuff[0] =  sBbuBtldStr.psCmd->u8CmdCode;
		sBbuBtldStr.u8WrLen = sBbuBtldStr.u8TempWrLen;
		sBbuBtldStr.u16Addr = sBbuBtldStr.u16TempAddr;
	}
	else
	{
		sBbuBtldStr.u8WrLen = sBbuBtldStr.u8TempWrLen = 0;
		// printf("\r\nI2C write property fail);
		return;
	}

	if ((sBbuBtldStr.psCmd->u8CmdType == PMBusCT_WrnBytes) || (sBbuBtldStr.psCmd->u8CmdType == PMBusCT_RdWrnBytes) ||
		(sBbuBtldStr.psCmd->u8CmdType == PMBusCT_BRdBWr_Wrnbytes))
	{
		if (MstPMBusWriteNbyte(HW_I2C1, sBbuBtldStr.u16Addr, sBbuBtldStr.pu8CmdBuff,
				sBbuBtldStr.pu8WrBuff, sBbuBtldStr.u8WrLen))
		{
			// printf("\r\nI2C write byte-word success);
			sBbuBtldStr.tnFlag.u16Bit.u1BbuBtWr = 1;
		}
	}
	else if ((sBbuBtldStr.psCmd->u8CmdType == PMBusCT_BlockWr) || (sBbuBtldStr.psCmd->u8CmdType == PMBusCT_BlockRdWr))
	{
		if (MstPMBusBlockWrite(HW_I2C1, sBbuBtldStr.u16Addr, sBbuBtldStr.pu8CmdBuff,
				sBbuBtldStr.pu8WrBuff, &sBbuBtldStr.u8WrLen))
		{
			// printf("\r\nI2C block write success);
			sBbuBtldStr.tnFlag.u16Bit.u1BbuBtWr = 1;
		}
	}
	else if (sBbuBtldStr.psCmd->u8CmdType == PMBusCT_ProCall)
	{
		sBbuBtldStr.u8RdLen = sBbuBtldStr.psCmd->u8Len;
		if (MstPMBusProcessCall(HW_I2C1, sBbuBtldStr.u16Addr, sBbuBtldStr.pu8CmdBuff,
				sBbuBtldStr.pu8WrBuff, sBbuBtldStr.u8WrLen,
				sBbuBtldStr.pu8RdBuff, sBbuBtldStr.u8RdLen))
		{
			// printf("\r\nI2C process call success);
			//sPMBusAppStruct.nStat.u16Bit.u1MasterRd = 1;
			sBbuBtldStr.tnFlag.u16Bit.u1BbuBtWr = 1;
		}
	}
	else if (sBbuBtldStr.psCmd->u8CmdType == PMBusCT_BWrBRdProCall)
	{
		//TURN_TGL_MTEST();
		sBbuBtldStr.u8RdLen = sBbuBtldStr.psCmd->u8Len;
		if (MstPMBusBlockProcessCall(HW_I2C1, sBbuBtldStr.u16Addr, sBbuBtldStr.pu8CmdBuff,
				sBbuBtldStr.pu8WrBuff, &sBbuBtldStr.u8WrLen,
				sBbuBtldStr.pu8RdBuff, sBbuBtldStr.u8RdLen))
		{
			// printf("\r\nI2C block write block read process call success);
			//sPMBusAppStruct.nStat.u16Bit.u1MasterRd = 1;
			sBbuBtldStr.tnFlag.u16Bit.u1BbuBtWr = 1;


		}
	}
	else
	{

	}
}
#endif /* LITEON_BT */
/****************************************************************************
*	name        : BuildBbuBtRdProcess
*	description :
*	return      : none
****************************************************************************/
#if (LITEON_BT)
void BuildBbuBtRdProcess(void)
{
	u8_t u8SlvAddr;

	sBbuBtldStr.u8RdCmdProperty = PMBusCP_RdWr;
	sBbuBtldStr.psCmd = &sBbuBLPMBusRWDummyCmd[0];
	u8SlvAddr = pu8DoltSlaveAddr[0];
	sBbuBtldStr.u16Addr = (u16_t)u8SlvAddr>>1;
	sBbuBtldStr.pu8CmdBuff[0] =  sBbuBtldStr.psCmd->u8CmdCode;
	sBbuBtldStr.u8RdLen = sBbuBtldStr.psCmd->u8Len;
	sBbuBtldStr.u8WrLen = 0;
	sBbuBtldStr.u8TempWrLen = 0;

	if ((sBbuBtldStr.psCmd->u8CmdType == PMBusCT_RdnBytes) || (sBbuBtldStr.psCmd->u8CmdType == PMBusCT_RdWrnBytes))
	{
		if (MstPMBusReadNbyte(HW_I2C1, sBbuBtldStr.u16Addr, sBbuBtldStr.pu8CmdBuff,
				sBbuBtldStr.pu8RdBuff, sBbuBtldStr.u8RdLen) == true)
		{
			sBbuBtldStr.tnFlag.u16Bit.u1BbuBtRd = 1;

		}
	}
	else if ((sBbuBtldStr.psCmd->u8CmdType == PMBusCT_BlockRd) || (sBbuBtldStr.psCmd->u8CmdType == PMBusCT_BlockRdWr))
	{
		if (MstPMBusBlockRead(HW_I2C1, sBbuBtldStr.u16Addr, sBbuBtldStr.pu8CmdBuff,
				sBbuBtldStr.pu8RdBuff, sBbuBtldStr.u8RdLen) == true)
		{
			sBbuBtldStr.tnFlag.u16Bit.u1BbuBtRd = 1;
		}
	}
	else
	{
		//
	}
}
#endif /* LITEON_BT */

/****************************************************************************
*	name        : BuildInVeBbuDummyRdProcess
*	description :
*	return      : none
****************************************************************************/
#if (BAIDU_BT)
void BuildInVeBbuDummyRdProcess(void)
{
	u8_t u8SlvAddr;

	sBbuBaiduBtStr.u8RdCmdProperty = PMBusCP_RdOnly;
	sBbuBaiduBtStr.psCmd = &sBbuPMBusROCmd_BT_DUMMY[0];
	u8SlvAddr = pu8DoltSlaveAddr[0];
	sBbuBaiduBtStr.u16Addr = (u16_t)u8SlvAddr>>1;
	sBbuBaiduBtStr.pu8CmdBuff[0] =  sBbuBaiduBtStr.psCmd->u8CmdCode;
	sBbuBaiduBtStr.u8RdLen = sBbuBaiduBtStr.psCmd->u8Len;
	sBbuBaiduBtStr.u8WrLen = 0;
	sBbuBaiduBtStr.u8TempWrLen = 0;

	if ((sBbuBaiduBtStr.psCmd->u8CmdType == PMBusCT_RdnBytes) || (sBbuBaiduBtStr.psCmd->u8CmdType == PMBusCT_RdWrnBytes))
	{
		if (MstPMBusReadNbyte(HW_I2C1, sBbuBaiduBtStr.u16Addr, sBbuBaiduBtStr.pu8CmdBuff,
				sBbuBaiduBtStr.pu8RdBuff, sBbuBaiduBtStr.u8RdLen) == true)
		{
			sBbuBaiduBtStr.tnFlag.u16Bit.u1RdBtDummy = 1;
		}
	}
	else if ((sBbuBaiduBtStr.psCmd->u8CmdType == PMBusCT_BlockRd) || (sBbuBaiduBtStr.psCmd->u8CmdType == PMBusCT_BlockRdWr))
	{
		if (MstPMBusBlockRead(HW_I2C1, sBbuBaiduBtStr.u16Addr, sBbuBaiduBtStr.pu8CmdBuff,
				sBbuBaiduBtStr.pu8RdBuff, sBbuBaiduBtStr.u8RdLen) == true)
		{
			sBbuBaiduBtStr.tnFlag.u16Bit.u1RdBtDummy = 1;
		}
	}
	else
	{

	}
}
#endif
/****************************************************************************
*	name        : BuildInVeBbuRdProcess
*	description :
*	return      : none
****************************************************************************/
#if (BAIDU_BT)
void BuildInVeBbuRdProcess(void)
{
	u8_t u8SlvAddr;

	sBbuBaiduBtStr.u8RdCmdProperty = PMBusCP_RdOnly;
	sBbuBaiduBtStr.psCmd = &sBbuPMBusROCmd_BT_STA[sBbuBaiduBtStr.u16RdCmdIndex];
	u8SlvAddr = pu8BBUSlaveAddr[sBbuBaiduBtStr.u8AddrIndex];
	sBbuBaiduBtStr.u16Addr = (u16_t)u8SlvAddr>>1;
	sBbuBaiduBtStr.pu8CmdBuff[0] =  sBbuBaiduBtStr.psCmd->u8CmdCode;
	sBbuBaiduBtStr.u8RdLen = sBbuBaiduBtStr.psCmd->u8Len;
	sBbuBaiduBtStr.u8WrLen = 0;
	sBbuBaiduBtStr.u8TempWrLen = 0;

	if ((sBbuBaiduBtStr.psCmd->u8CmdType == PMBusCT_RdnBytes) || (sBbuBaiduBtStr.psCmd->u8CmdType == PMBusCT_RdWrnBytes))
	{
		if (MstPMBusReadNbyte(HW_I2C1, sBbuBaiduBtStr.u16Addr, sBbuBaiduBtStr.pu8CmdBuff,
				sBbuBaiduBtStr.pu8RdBuff, sBbuBaiduBtStr.u8RdLen) == true)
		{
			sBbuBaiduBtStr.tnFlag.u16Bit.u1RdBt = 1;
		}
	}
	else if ((sBbuBaiduBtStr.psCmd->u8CmdType == PMBusCT_BlockRd) || (sBbuBaiduBtStr.psCmd->u8CmdType == PMBusCT_BlockRdWr))
	{
		if (MstPMBusBlockRead(HW_I2C1, sBbuBaiduBtStr.u16Addr, sBbuBaiduBtStr.pu8CmdBuff,
				sBbuBaiduBtStr.pu8RdBuff, sBbuBaiduBtStr.u8RdLen) == true)
		{
			sBbuBaiduBtStr.tnFlag.u16Bit.u1RdBt = 1;
		}
	}
	else
	{

	}
}
#endif /* BAIDU_BT */

/****************************************************************************
*	name        : InVeBbuBtWrProcess
*	description :
*	return      : none
****************************************************************************/
#if (BAIDU_BT)
void InVeBbuBtWrProcess(u8_t u8AddrIndex, u8_t u8Cmd, u8_t u8Data)
{
	switch(u8Cmd)
	{
		case PMBusCmd_MFRSp32:	//0xF0, Boot loader key
			//TURN_TGL_MTEST();
			break;
		case PMBusCmd_MFRSp33:	//0xF1, Boot loader Cmd
			sBbuBaiduBtStr.u8AddrIndex = u8AddrIndex;
			sBbuBaiduBtStr.u16RdCmdIndex = 1;		//read F1h cmd
			sBbuBaiduBtStr.u16LockTimeOutCnt = 0;
			sBbuBaiduBtStr.tnFlag.u16Bit.u2BtLock = 1;//dummyRd
			if((u8Data == 0x02) || (u8Data == 0x12))
			{
				sBbuBaiduBtStr.u16DummyRdLockTime1ms = 1200;
				sBbuBaiduBtStr.u16RdLockTime1ms = 1000;
			}
			else if(u8Data == 0x01)
			{
				sBbuBaiduBtStr.u16DummyRdLockTime1ms = 1200;
				sBbuBaiduBtStr.u16RdLockTime1ms = 800;
				sBbuBaiduBtStr.u32WrPrgmCnt = 0;
			}
			else if(u8Data == 0x03)
			{
				sBbuBaiduBtStr.u16DummyRdLockTime1ms = 1200;
				sBbuBaiduBtStr.u16RdLockTime1ms = 1000;
			}
			break;
		case PMBusCmd_MFRSp34:	//0xF2, Boot loader Memory Block
			sBbuBaiduBtStr.u8AddrIndex = u8AddrIndex;
			sBbuBaiduBtStr.u16RdCmdIndex = 0;		//read 7Eh cmd
			sBbuBaiduBtStr.u16LockTimeOutCnt = 0;
			sBbuBaiduBtStr.tnFlag.u16Bit.u2BtLock = 1;//dummyRd
			if(sBbuBaiduBtStr.u32WrPrgmCnt == 0)
			{
				sBbuBaiduBtStr.u16DummyRdLockTime1ms = 1200;
				sBbuBaiduBtStr.u16RdLockTime1ms = 800;
			}
			else
			{
				sBbuBaiduBtStr.u16DummyRdLockTime1ms = 20;
				sBbuBaiduBtStr.u16RdLockTime1ms = 1980;
			}
			if(sBbuBaiduBtStr.u32WrPrgmCnt < 0xffffffff)
			{
				sBbuBaiduBtStr.u32WrPrgmCnt += 1;
			}
			break;
		case PMBusCmd_MFRSp35:	//0xF3, Boot loader Product Key
			//TURN_TGL_MTEST();
			break;
		case PMBusCmd_MFRSp36:	//0xF4, Image Checksum
			sBbuBaiduBtStr.u8AddrIndex = u8AddrIndex;
			sBbuBaiduBtStr.u16RdCmdIndex = 1;	//read F1h cmd
			sBbuBaiduBtStr.u16LockTimeOutCnt = 0;
			sBbuBaiduBtStr.tnFlag.u16Bit.u2BtLock = 1;//dummyRd
			sBbuBaiduBtStr.u16DummyRdLockTime1ms = 30;
			sBbuBaiduBtStr.u16RdLockTime1ms = 1970;
			break;
		default:

			break;
	}
}
#endif
/****************************************************************************
*	name        : BuildWrProcess
*	description :
*	return      : none
****************************************************************************/
void BuildWrProcess(void)
{
	u8_t u8SlvAddr;

	if (sPMBusAppStruct.u8WrCmdProperty == PMBusCP_RdWr)
	{
#if(MST_RD_SEQUENCE)
		sPMBusAppStruct.psCmd = &sBbuPMBusRWCmd_CFG[sPMBusAppStruct.u16WrCmdIndex];
#else
		sPMBusAppStruct.psCmd = &sBbuPMBusRWCmd[sPMBusAppStruct.u16WrCmdIndex];
#endif
		sPMBusAppStruct.pu8CmdBuff[0] = sPMBusAppStruct.psCmd->u8CmdCode;
		sPMBusAppStruct.u8WrLen = sPMBusAppStruct.u8TempWrLen;

	}
	else if (sPMBusAppStruct.u8WrCmdProperty == PMBusCP_WrOnly)
	{
#if(MST_RD_SEQUENCE)
		sPMBusAppStruct.psCmd = &sBbuPMBusWOCmd_CTR[sPMBusAppStruct.u16WrCmdIndex];
#else
		sPMBusAppStruct.psCmd = &sBbuPMBusWOCmd[sPMBusAppStruct.u16WrCmdIndex];
#endif
		sPMBusAppStruct.pu8CmdBuff[0] =  sPMBusAppStruct.psCmd->u8CmdCode;
		sPMBusAppStruct.u8WrLen = sPMBusAppStruct.u8TempWrLen;
	}
	else
	{
		sPMBusAppStruct.u8WrLen = sPMBusAppStruct.u8TempWrLen = 0;
		// printf("\r\nI2C write property fail);
		return;
	}


	sDevStruct.u8WrAddrIndex = sDevStruct.u8TempWrAddrIndex;
#if (BAIDU_BT)
	if(sDevStruct.u8WrAddrIndex < BBU_DEV_NUM)
	{
		InVeBbuBtWrProcess(sDevStruct.u8TempWrAddrIndex, sPMBusAppStruct.pu8CmdBuff[0], sPMBusAppStruct.pu8WrBuff[0]);
	}
#endif

	if(sDevStruct.u8WrAddrIndex < BBU_DEV_NUM)
	{
		u8SlvAddr = pu8BBUSlaveAddr[sDevStruct.u8WrAddrIndex];
		sDevStruct.u16Addr = (u16_t)u8SlvAddr>>1;

		if ((sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_WrnBytes) || (sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_RdWrnBytes) ||
			(sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_BRdBWr_Wrnbytes) || (sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_SendByte))
		{
			if (MstPMBusWriteNbyte(HW_I2C1, sDevStruct.u16Addr, sPMBusAppStruct.pu8CmdBuff,
					sPMBusAppStruct.pu8WrBuff, sPMBusAppStruct.u8WrLen))
			{
				// printf("\r\nI2C write byte-word success);
				sPMBusAppStruct.nStat.u16Bit.u1MasterWr = 1;
				//TURN_TGL_MTEST();
			}
		}
		else if ((sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_BlockWr) || (sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_BlockRdWr))
		{
			if (MstPMBusBlockWrite(HW_I2C1, sDevStruct.u16Addr, sPMBusAppStruct.pu8CmdBuff,
					sPMBusAppStruct.pu8WrBuff, &sPMBusAppStruct.u8WrLen))
			{
				// printf("\r\nI2C block write success);
				sPMBusAppStruct.nStat.u16Bit.u1MasterWr = 1;
				//TURN_TGL_MTEST();
			}
		}
		else if (sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_ProCall)
		{
			sPMBusAppStruct.u8RdLen = sPMBusAppStruct.psCmd->u8Len;
			if (MstPMBusProcessCall(HW_I2C1, sDevStruct.u16Addr, sPMBusAppStruct.pu8CmdBuff,
					sPMBusAppStruct.pu8WrBuff, sPMBusAppStruct.u8WrLen,
					sPMBusAppStruct.pu8RdBuff, sPMBusAppStruct.u8RdLen))
			{
				// printf("\r\nI2C process call success);
				//sPMBusAppStruct.nStat.u16Bit.u1MasterRd = 1;
				sPMBusAppStruct.nStat.u16Bit.u1MasterWr = 1;
			}
		}
		else if (sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_BWrBRdProCall)
		{
			sPMBusAppStruct.u8RdLen = sPMBusAppStruct.psCmd->u8Len;
			if (MstPMBusBlockProcessCall(HW_I2C1, sDevStruct.u16Addr, sPMBusAppStruct.pu8CmdBuff,
					sPMBusAppStruct.pu8WrBuff, &sPMBusAppStruct.u8WrLen,
					sPMBusAppStruct.pu8RdBuff, sPMBusAppStruct.u8RdLen))
			{
				// printf("\r\nI2C block write block read process call success);
				//sPMBusAppStruct.nStat.u16Bit.u1MasterRd = 1;
				sPMBusAppStruct.nStat.u16Bit.u1MasterWr = 1;
			}
		}
		else
		{

		}
	}
	else	// general call address all devices on the bus using the i2c address 0
	{
		u8SlvAddr = 0x0000;
		sDevStruct.u16Addr = (u16_t)u8SlvAddr>>1;
		if ((sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_WrnBytes) || (sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_RdWrnBytes))
		{
			if (MstPMBusWriteNbyte(HW_I2C1, sDevStruct.u16Addr, sPMBusAppStruct.pu8CmdBuff,
					sPMBusAppStruct.pu8WrBuff, sPMBusAppStruct.u8WrLen))
			{
				// printf("\r\nI2C write byte-word success);
				sPMBusAppStruct.nStat.u16Bit.u1MasterWr = 1;
				//TURN_TGL_MTEST();
			}
		}
	}

}
/****************************************************************************
*	name        : update_RdSequence_Index
*	description :
*	return      : none
****************************************************************************/
u8_t update_RdSequence_Index(void)
{
	u8_t u8NextSequ;

	u8NextSequ = (sPMBusAppStruct.u8RdCmdSequence+1)%8;
	sPMBusAppStruct.u8RdCmdSequence = u8NextSequ;

	return(sPMBusAppStruct.u8RdCmdSequence);
}
/****************************************************************************
*	name        : build_RdSTA_Cmd
*	description :
*	return      : none
****************************************************************************/
void build_RdSTA_Cmd(void)
{
	sPMBusAppStruct.psCmd = &sBbuPMBusROCmd_STA[sPMBusAppStruct.u16RdCmdIndex];
	sPMBusAppStruct.u16RdCmdIndex += 1;
	sPMBusAppStruct.u8RdCmdProperty = PMBusCP_RdOnly;
}
/****************************************************************************
*	name        : build_RdMST_Cmd
*	description :
*	return      : none
****************************************************************************/
void build_RdMST_Cmd(void)
{
	sPMBusAppStruct.psCmd = &sBbuPMBusROCmd_MST[sPMBusAppStruct.u16RdCmdIndex];
	sPMBusAppStruct.u16RdCmdIndex += 1;
	sPMBusAppStruct.u8RdCmdProperty = PMBusCP_RdOnly;
}
/****************************************************************************
*	name        : build_RdMFC_Cmd
*	description :
*	return      : none
****************************************************************************/
void build_RdMFC_Cmd(void)
{
	sPMBusAppStruct.psCmd = &sBbuPMBusROCmd_MFC[sPMBusAppStruct.u16RdCmdIndex];
	sPMBusAppStruct.u16RdCmdIndex += 1;
	sPMBusAppStruct.u8RdCmdProperty = PMBusCP_RdOnly;
}
/****************************************************************************
*	name        : build_RdCFG_Cmd
*	description :
*	return      : none
****************************************************************************/
void build_RdINF_Cmd(void)
{
	sPMBusAppStruct.psCmd = &sBbuPMBusROCmd_INF[sPMBusAppStruct.u16RdCmdIndex];
	sPMBusAppStruct.u16RdCmdIndex += 1;
	sPMBusAppStruct.u8RdCmdProperty = PMBusCP_RdOnly;
}
/****************************************************************************
*	name        : build_RdCFG_Cmd
*	description :
*	return      : none
****************************************************************************/
void build_RdCFG_Cmd(void)
{
	sPMBusAppStruct.psCmd = &sBbuPMBusRWCmd_CFG[sPMBusAppStruct.u16RdCmdIndex];
	sPMBusAppStruct.u16RdCmdIndex += 1;
	sPMBusAppStruct.u8RdCmdProperty = PMBusCP_RdWr;
}

/****************************************************************************
*	name        : BuildRdSequenceProcess
*	description :
*	return      : none
****************************************************************************/
bool BuildRdSequenceProcess(void)
{
	u8_t u8SlvAddr;

	switch(sPMBusAppStruct.u8RdCmdSequence)
	{
		case 0:	//STA
			if (sPMBusAppStruct.u16RdCmdIndex < BBU_PMBUS_RO_STA_NUM)
			{
				build_RdSTA_Cmd();
				//TURN_L_MTEST();
			}
			else
			{
				sPMBusAppStruct.u16RdCmdIndex = 0;
				sDevStruct.u8AddrIndex += 1;
				if(sDevStruct.u8AddrIndex < BBU_DEV_NUM)
				{
					build_RdSTA_Cmd();
					//TURN_L_MTEST();
				}
				else
				{
					sDevStruct.u8AddrIndex = 0;
					update_RdSequence_Index();
					build_RdMST_Cmd();
					//TURN_H_MTEST();
				}
			}
			break;

		case 1:	//MST
			if (sPMBusAppStruct.u16RdCmdIndex < BBU_PMBUS_RO_MST_NUM)
			{
				build_RdMST_Cmd();
				//TURN_H_MTEST();
			}
			else
			{
				sPMBusAppStruct.u16RdCmdIndex = 0;
				sDevStruct.u8AddrIndex += 1;
				if(sDevStruct.u8AddrIndex < BBU_DEV_NUM)
				{
					build_RdMST_Cmd();
					//TURN_H_MTEST();
				}
				else
				{
					sDevStruct.u8AddrIndex = 0;
					update_RdSequence_Index();
					build_RdSTA_Cmd();
					//TURN_L_MTEST();
				}
			}
			break;
		case 2:	//STA
			if (sPMBusAppStruct.u16RdCmdIndex < BBU_PMBUS_RO_STA_NUM)
			{
				build_RdSTA_Cmd();
				//TURN_L_MTEST();
			}
			else
			{
				sPMBusAppStruct.u16RdCmdIndex = 0;
				sDevStruct.u8AddrIndex += 1;
				if(sDevStruct.u8AddrIndex < BBU_DEV_NUM)
				{
					build_RdSTA_Cmd();
					//TURN_L_MTEST();
				}
				else
				{
					sDevStruct.u8AddrIndex = 0;
					update_RdSequence_Index();
					build_RdMFC_Cmd();
					//TURN_H_MTEST();
				}
			}
			break;
		case 3:	//MFC
			if (sPMBusAppStruct.u16RdCmdIndex < BBU_PMBUS_RO_MFC_NUM)
			{
				build_RdMFC_Cmd();
				//TURN_H_MTEST();
			}
			else
			{
				sPMBusAppStruct.u16RdCmdIndex = 0;
				sDevStruct.u8AddrIndex += 1;
				if(sDevStruct.u8AddrIndex < BBU_DEV_NUM)
				{
					build_RdMFC_Cmd();
					//TURN_H_MTEST();
				}
				else
				{
					sDevStruct.u8AddrIndex = 0;
					update_RdSequence_Index();
					build_RdSTA_Cmd();
					//TURN_L_MTEST();
				}
			}
			break;
		case 4:	//STA
			if (sPMBusAppStruct.u16RdCmdIndex < BBU_PMBUS_RO_STA_NUM)
			{
				build_RdSTA_Cmd();
				//TURN_L_MTEST();
			}
			else
			{
				sPMBusAppStruct.u16RdCmdIndex = 0;
				sDevStruct.u8AddrIndex += 1;
				if(sDevStruct.u8AddrIndex < BBU_DEV_NUM)
				{
					build_RdSTA_Cmd();
					//TURN_L_MTEST();
				}
				else
				{
					sDevStruct.u8AddrIndex = 0;
					update_RdSequence_Index();
					build_RdCFG_Cmd();
					//TURN_H_MTEST();
				}
			}
			break;
		case 5:	//CFG
			if (sPMBusAppStruct.u16RdCmdIndex < BBU_PMBUS_RW_CFG_NUM)
			{
				build_RdCFG_Cmd();
				//TURN_H_MTEST();
			}
			else
			{
				sPMBusAppStruct.u16RdCmdIndex = 0;
				sDevStruct.u8AddrIndex += 1;
				if(sDevStruct.u8AddrIndex < BBU_DEV_NUM)
				{
					build_RdCFG_Cmd();
					//TURN_H_MTEST();
				}
				else
				{
					sDevStruct.u8AddrIndex = 0;
					update_RdSequence_Index();
					//TURN_L_MTEST();
					build_RdSTA_Cmd();

				}
			}
			break;
		case 6:	//STA
			if (sPMBusAppStruct.u16RdCmdIndex < BBU_PMBUS_RO_STA_NUM)
			{
				build_RdSTA_Cmd();
				//TURN_L_MTEST();
			}
			else
			{
				sPMBusAppStruct.u16RdCmdIndex = 0;
				sDevStruct.u8AddrIndex += 1;
				if(sDevStruct.u8AddrIndex < BBU_DEV_NUM)
				{
					build_RdSTA_Cmd();
					//TURN_L_MTEST();
				}
				else
				{
					sDevStruct.u8AddrIndex = 0;
					update_RdSequence_Index();
					build_RdINF_Cmd();
					//TURN_H_MTEST();
				}
			}
			break;
		case 7:	//INF
			if (sPMBusAppStruct.u16RdCmdIndex < BBU_PMBUS_RW_CFG_NUM)
			{
				build_RdINF_Cmd();
				//TURN_H_MTEST();
			}
			else
			{
				sPMBusAppStruct.u16RdCmdIndex = 0;
				sDevStruct.u8AddrIndex += 1;
				if(sDevStruct.u8AddrIndex < BBU_DEV_NUM)
				{
					build_RdINF_Cmd();
					//TURN_H_MTEST();
				}
				else
				{
					sDevStruct.u8AddrIndex = 0;
					update_RdSequence_Index();
					//TURN_L_MTEST();
					build_RdSTA_Cmd();
				}
			}
			break;
		default:
			sDevStruct.u8AddrIndex = 0;
			sPMBusAppStruct.u8RdCmdSequence = 0;
			sPMBusAppStruct.u16RdCmdIndex = 0;
			build_RdSTA_Cmd();
			break;
	}

	u8SlvAddr = pu8BBUSlaveAddr[sDevStruct.u8AddrIndex];
	sDevStruct.u16Addr = (u16_t)u8SlvAddr>>1;
	sPMBusAppStruct.pu8CmdBuff[0] =  sPMBusAppStruct.psCmd->u8CmdCode;
	sPMBusAppStruct.u8RdLen = sPMBusAppStruct.psCmd->u8Len;
	sPMBusAppStruct.u8WrLen = 0;
	sPMBusAppStruct.u8TempWrLen = 0;

	if ((sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_RdnBytes) || (sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_RdWrnBytes))
	{
		if (MstPMBusReadNbyte(HW_I2C1, sDevStruct.u16Addr, sPMBusAppStruct.pu8CmdBuff,
				sPMBusAppStruct.pu8RdBuff, sPMBusAppStruct.u8RdLen) == true)
		{
			sPMBusAppStruct.nStat.u16Bit.u1MasterRd = 1;
		}
	}
	else if ((sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_BlockRd) || (sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_BlockRdWr))
	{
		if (MstPMBusBlockRead(HW_I2C1, sDevStruct.u16Addr, sPMBusAppStruct.pu8CmdBuff,
				sPMBusAppStruct.pu8RdBuff, sPMBusAppStruct.u8RdLen) == true)
		{
			sPMBusAppStruct.nStat.u16Bit.u1MasterRd = 1;
		}
	}
	else
	{
		//TURN_TGL_PTD6();
	}
}
/****************************************************************************
*	name        : BuildRdProcess
*	description :
*	return      : none
****************************************************************************/
bool BuildRdProcess(void)
{
	u8_t u8SlvAddr;

	if (sPMBusAppStruct.u8RdCmdProperty == PMBusCP_RdWr)	// read-write command
	{
		if (sPMBusAppStruct.u16RdCmdIndex >= BBU_PMBUS_RW_NUM)
		{
			sPMBusAppStruct.u16RdCmdIndex = 0;
			sPMBusAppStruct.psCmd = &sBbuPMBusROCmd[sPMBusAppStruct.u16RdCmdIndex];
			sPMBusAppStruct.u16RdCmdIndex += 1;
			sPMBusAppStruct.u8RdCmdProperty = PMBusCP_RdOnly;
		}
		else
		{
			sPMBusAppStruct.psCmd = &sBbuPMBusRWCmd[sPMBusAppStruct.u16RdCmdIndex];
			sPMBusAppStruct.u16RdCmdIndex += 1;
		}
	}
	else if (sPMBusAppStruct.u8RdCmdProperty == PMBusCP_RdOnly)	// read command
	{
		if (sPMBusAppStruct.u16RdCmdIndex >= BBU_PMBUS_RO_NUM)
		{
			sPMBusAppStruct.u16RdCmdIndex = 0;
			sPMBusAppStruct.psCmd = &sBbuPMBusRWCmd[sPMBusAppStruct.u16RdCmdIndex];
			sPMBusAppStruct.u16RdCmdIndex += 1;
			sPMBusAppStruct.u8RdCmdProperty = PMBusCP_RdWr;

			sDevStruct.u8AddrIndex += 1;
			//TURN_TGL_MTEST();
			if (sDevStruct.u8AddrIndex >= BBU_DEV_NUM)
			{
				sDevStruct.u8AddrIndex = 0;
			}

		}
		else
		{
			sPMBusAppStruct.psCmd = &sBbuPMBusROCmd[sPMBusAppStruct.u16RdCmdIndex];
			sPMBusAppStruct.u16RdCmdIndex += 1;
		}
	}
	else
	{
		sPMBusAppStruct.u16RdCmdIndex = 0;
		sPMBusAppStruct.u8RdCmdProperty = PMBusCP_RdWr;
		sDevStruct.u8AddrIndex = 0;
		sPMBusAppStruct.psCmd = &sBbuPMBusRWCmd[sPMBusAppStruct.u16RdCmdIndex];
		sPMBusAppStruct.u16RdCmdIndex += 1;
	}

	u8SlvAddr = pu8BBUSlaveAddr[sDevStruct.u8AddrIndex];
	sDevStruct.u16Addr = (u16_t)u8SlvAddr>>1;
	sPMBusAppStruct.pu8CmdBuff[0] =  sPMBusAppStruct.psCmd->u8CmdCode;
	sPMBusAppStruct.u8RdLen = sPMBusAppStruct.psCmd->u8Len;
	sPMBusAppStruct.u8WrLen = 0;
	sPMBusAppStruct.u8TempWrLen = 0;

	if ((sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_RdnBytes) || (sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_RdWrnBytes))
	{
		if (MstPMBusReadNbyte(HW_I2C1, sDevStruct.u16Addr, sPMBusAppStruct.pu8CmdBuff,
				sPMBusAppStruct.pu8RdBuff, sPMBusAppStruct.u8RdLen) == true)
		{
			sPMBusAppStruct.nStat.u16Bit.u1MasterRd = 1;
		}
	}
	else if ((sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_BlockRd) || (sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_BlockRdWr))
	{
		if (MstPMBusBlockRead(HW_I2C1, sDevStruct.u16Addr, sPMBusAppStruct.pu8CmdBuff,
				sPMBusAppStruct.pu8RdBuff, sPMBusAppStruct.u8RdLen) == true)
		{
			sPMBusAppStruct.nStat.u16Bit.u1MasterRd = 1;
		}
	}
	else
	{
		//TURN_TGL_PTD6();
	}
}
/****************************************************************************
*	name        : CheckBbuBtldCrc8
*	description :
*	return      : none
****************************************************************************/
#if (LITEON_BT)
bool CheckBbuBtldCrc8(void)
{
	u8_t i, u8SlvAddr;

	u8SlvAddr = (u8_t)(sBbuBtldStr.u16Addr<<1);
	sBbuBtldStr.u8CRC8 = 0;
	CalCRC8(&sBbuBtldStr.u8CRC8, u8SlvAddr);
	CalCRC8(&sBbuBtldStr.u8CRC8, sBbuBtldStr.pu8CmdBuff[0]);
	for (i=0; i<sBbuBtldStr.u8WrLen; i++)
	{
		CalCRC8(&sBbuBtldStr.u8CRC8, sBbuBtldStr.pu8WrBuff[i]);
	}
	CalCRC8(&sBbuBtldStr.u8CRC8, u8SlvAddr|0x01);

	for (i=0; i<sBbuBtldStr.u8RdLen; i++)
	{
		CalCRC8(&sBbuBtldStr.u8CRC8, sBbuBtldStr.pu8RdBuff[i]);
	}

	if(sBbuBtldStr.u8CRC8 == sBbuBtldStr.pu8RdBuff[i])
	{
		return true;
	}
	else
	{
		return false;
	}
}
#endif /* LITEON_BT */

/****************************************************************************
*	name        : CheckInVeBbuBtCrc8
*	description :
*	return      : none
****************************************************************************/
#if (BAIDU_BT)
bool CheckInVeBbuBtCrc8(void)
{
	u8_t i, u8SlvAddr;

	u8SlvAddr = (u8_t)(sBbuBaiduBtStr.u16Addr<<1);
	sBbuBaiduBtStr.u8CRC8 = 0;
	CalCRC8(&sBbuBaiduBtStr.u8CRC8, u8SlvAddr);
	CalCRC8(&sBbuBaiduBtStr.u8CRC8, sBbuBaiduBtStr.pu8CmdBuff[0]);
	for (i=0; i<sBbuBaiduBtStr.u8WrLen; i++)
	{
		CalCRC8(&sBbuBaiduBtStr.u8CRC8, sBbuBaiduBtStr.pu8WrBuff[i]);
	}
	CalCRC8(&sBbuBaiduBtStr.u8CRC8, u8SlvAddr|0x01);

	for (i=0; i<sBbuBaiduBtStr.u8RdLen; i++)
	{
		CalCRC8(&sBbuBaiduBtStr.u8CRC8, sBbuBaiduBtStr.pu8RdBuff[i]);
	}

	if(sBbuBaiduBtStr.u8CRC8 == sBbuBaiduBtStr.pu8RdBuff[i])
	{
		return true;
	}
	else
	{
		return false;
	}
}
#endif /* BAIDU_BT */
/****************************************************************************
*	name        : CheckPMBusCrc8
*	description :
*	return      : none
****************************************************************************/
bool CheckPMBusCrc8(void)
{
	u8_t i, u8SlvAddr;

	u8SlvAddr = (u8_t)(sDevStruct.u16Addr<<1);
	sPMBusAppStruct.u8CRC8 = 0;
	CalCRC8(&sPMBusAppStruct.u8CRC8, u8SlvAddr);
	CalCRC8(&sPMBusAppStruct.u8CRC8, sPMBusAppStruct.pu8CmdBuff[0]);

	for (i=0; i<sPMBusAppStruct.u8WrLen; i++)
	{
		CalCRC8(&sPMBusAppStruct.u8CRC8, sPMBusAppStruct.pu8WrBuff[i]);
	}
	CalCRC8(&sPMBusAppStruct.u8CRC8, u8SlvAddr|0x01);

	for (i=0; i<sPMBusAppStruct.u8RdLen; i++)
	{
		CalCRC8(&sPMBusAppStruct.u8CRC8, sPMBusAppStruct.pu8RdBuff[i]);
	}

	if(sPMBusAppStruct.u8CRC8 == sPMBusAppStruct.pu8RdBuff[i])
	{
		return true;
	}
	else
	{
		return false;
	}
}
/*******************************************************************************
*	brief 	handle the master PM Bus application
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
#if (LITEON_BT)
void MstPMBusProcess(void)
{
	u8_t* pu8RdBuff = NULL;
	u8_t u8SlvAddr, u8RdLen;

	u16_t u16CmdSize, u16CmdOffset;

	if (GetMasterI2cIdleFlage(HW_I2C1) == false)
	{
	    return;
	}

	if(sBbuBtldStr.tnFlag.u16Bit.u1BbuBtWr)
	{
		if (GetMasterI2cStatus(HW_I2C1) == kStatus_I2C_Success)
		{
			if (sBbuBtldStr.psCmd->u8CmdType == PMBusCT_ProCall)
			{
				pu8RdBuff = &sBbuBtldStr.pu8RdBuff[0];
				u8RdLen = sBbuBtldStr.u8RdLen;
			}
			else if (sBbuBtldStr.psCmd->u8CmdType == PMBusCT_BWrBRdProCall)
			{
				pu8RdBuff = &sBbuBtldStr.pu8RdBuff[1];
				u8RdLen = sBbuBtldStr.pu8RdBuff[0];
				sBbuBtldStr.u8RdLen = u8RdLen + 1;
			}
			else
			{
				pu8RdBuff = NULL;
			}

			if (pu8RdBuff != NULL)
			{
				if (GetMasterI2cPECSupportFlage(HW_I2C1) == true)
				{
					if (CheckBbuBtldCrc8() == true)
					{
						(*sBbuBtldStr.psCmd->FuncPtr)(pu8RdBuff, sBbuBtldStr.psCmd->pu8Buff, u8RdLen);

					}
				}
				else
				{
					(*sBbuBtldStr.psCmd->FuncPtr)(pu8RdBuff, sPMBusAppStruct.psCmd->pu8Buff, u8RdLen);
				}
			}
		}
		else if (GetMasterI2cStatus(HW_I2C1) == kStatus_I2C_ReceivedNak)
		{

		}
		else if (GetMasterI2cStatus(HW_I2C1) == kStatus_I2C_Timeout)
		{

		}
		sBbuBtldStr.tnFlag.u16Bit.u1BbuBtWr = 0;
	}
	else if (sBbuBtldStr.tnFlag.u16Bit.u1BbuBtRd)
	{
		sBbuBtldStr.tnFlag.u16Bit.u1BbuBtRd = 0;
		if (GetMasterI2cStatus(HW_I2C1) == kStatus_I2C_Success)
		{

		}
		else if (GetMasterI2cStatus(HW_I2C1) == kStatus_I2C_ReceivedNak)
		{

		}
	    else if (GetMasterI2cStatus(HW_I2C1) == kStatus_I2C_Timeout)
	    {

	    }
	    else
	    {

	    }
	}
	else if (sPMBusAppStruct.nStat.u16Bit.u1MasterRd)
	{
		sPMBusAppStruct.nStat.u16Bit.u1MasterRd = 0;
		//TURN_TGL_MTEST();
		if (GetMasterI2cStatus(HW_I2C1) == kStatus_I2C_Success)
		{
			u16CmdSize = sizeof(tsBBU_Dev[0]);
			u16CmdOffset = u16CmdSize * (u16_t)sDevStruct.u8AddrIndex;
			//if ((sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_RdnBytes) || (sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_ProCall) ||
			//	(sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_RdWrnBytes))
			if ((sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_RdnBytes) || (sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_RdWrnBytes))
			{
				pu8RdBuff = &sPMBusAppStruct.pu8RdBuff[0];
				u8RdLen = sPMBusAppStruct.u8RdLen;
			}
			//else if ((sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_BlockRd) || (sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_BWrBRdProCall) ||
			//		 (sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_BlockRdWr) || (sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_BRdBWr_Wrnbytes))
			else if ((sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_BlockRd) || (sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_BlockRdWr))
			{
				pu8RdBuff = &sPMBusAppStruct.pu8RdBuff[1];
				u8RdLen = sPMBusAppStruct.pu8RdBuff[0];
				sPMBusAppStruct.u8RdLen = u8RdLen + 1;
			}


			if (pu8RdBuff != NULL)
			{
				if (GetMasterI2cPECSupportFlage(HW_I2C1) == true)
				{
					if (CheckPMBusCrc8() == true)
					{
						(*sPMBusAppStruct.psCmd->FuncPtr)(pu8RdBuff, sPMBusAppStruct.psCmd->pu8Buff + u16CmdOffset, u8RdLen);
						sDevStruct.nDevStat.u16All |= (1 << sDevStruct.u8AddrIndex);
						//TURN_TGL_PTD7();
					}

				}
				else
				{
					(*sPMBusAppStruct.psCmd->FuncPtr)(pu8RdBuff, sPMBusAppStruct.psCmd->pu8Buff + u16CmdOffset, u8RdLen);
					sDevStruct.nDevStat.u16All |= (1 << sDevStruct.u8AddrIndex);
				}
			}
			else
			{

			}

		}
		else if (GetMasterI2cStatus(HW_I2C1) == kStatus_I2C_ReceivedNak)
		{
			// printf("\r\nI2C communication failed, error code: %d", returnValue);
        	sDevStruct.nDevStat.u16All &= (~(1 << sDevStruct.u8AddrIndex));

        	//TURN_TGL_PTD6();
#if (MST_RD_SEQUENCE)
        	sDevStruct.u8AddrIndex += 1;
			if (sDevStruct.u8AddrIndex >= BBU_DEV_NUM)
			{
				sDevStruct.u8AddrIndex = 0;
				update_RdSequence_Index();
			}
			sPMBusAppStruct.u16RdCmdIndex = 0;
#else
        	sDevStruct.u8AddrIndex += 1;
			if (sDevStruct.u8AddrIndex >= BBU_DEV_NUM)
			{
				sDevStruct.u8AddrIndex = 0;
			}
			sPMBusAppStruct.u16RdCmdIndex = 0;
#endif

		}
	    else if (GetMasterI2cStatus(HW_I2C1) == kStatus_I2C_Timeout)
	    {

	    }
	    else
	    {

	    }
	}
	else if (sPMBusAppStruct.nStat.u16Bit.u1MasterWr)
	{
		//if(sPMBusAppStruct.pu8CmdBuff[0] == 0x03)
		//{
			//TURN_TGL_MTEST();
		//}
		//TURN_TGL_MTEST();
		if (GetMasterI2cStatus(HW_I2C1) == kStatus_I2C_Success)
		{
			if (sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_ProCall)
			{
				pu8RdBuff = &sPMBusAppStruct.pu8RdBuff[0];
				u8RdLen = sPMBusAppStruct.u8RdLen;
			}
			else if (sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_BWrBRdProCall)
			{
				pu8RdBuff = &sPMBusAppStruct.pu8RdBuff[1];
				u8RdLen = sPMBusAppStruct.pu8RdBuff[0];
				sPMBusAppStruct.u8RdLen = u8RdLen + 1;
			}
			else
			{
				pu8RdBuff = NULL;
			}

			if (pu8RdBuff != NULL)
			{
				u16CmdSize = sizeof(tsBBU_Dev[0]);
				u16CmdOffset = u16CmdSize * (u16_t)sDevStruct.u8WrAddrIndex;
				if (GetMasterI2cPECSupportFlage(HW_I2C1) == true)
				{
					if (CheckPMBusCrc8() == true)
					{
						(*sPMBusAppStruct.psCmd->FuncPtr)(pu8RdBuff, sPMBusAppStruct.psCmd->pu8Buff + u16CmdOffset, u8RdLen);
						//sDevStruct.nDevStat.u16All |= (1 << sDevStruct.u8AddrIndex);
					}
				}
				else
				{
					(*sPMBusAppStruct.psCmd->FuncPtr)(pu8RdBuff, sPMBusAppStruct.psCmd->pu8Buff + u16CmdOffset, u8RdLen);
					//sDevStruct.nDevStat.u16All |= (1 << sDevStruct.u8AddrIndex);
				}
			}
		}
		else if (GetMasterI2cStatus(HW_I2C1) == kStatus_I2C_ReceivedNak)
		{
			//sDevStruct.nDevStat.u16All &= (~(1 << sDevStruct.u8AddrIndex));
		}
		else if (GetMasterI2cStatus(HW_I2C1) == kStatus_I2C_Timeout)
		{

		}
		else
		{

		}
		sPMBusAppStruct.nStat.u16Bit.u1MasterWr = 0;
		//TURN_TGL_BBS_PWM();
	}
	else
	{
		if(sBbuBtldStr.tnFlag.u16Bit.u1ActivateBbuBtWrCmd)
		{
			BuildBbuBtldWrProcess();
			sBbuBtldStr.tnFlag.u16Bit.u1ActivateBbuBtWrCmd = 0;
		}
		else
		{
			if(sBbuBtldStr.tnFlag.u16Bit.u1BbuBtLock)
			{
				if(sBbuBtldStr.tnFlag.u16Bit.u1BbuBtDummyCmd)
				{
					BuildBbuBtRdProcess();
				}
			}
			else
			{
				//--------------------------------------
				// activating write cmd
				//--------------------------------------
				if(sPMBusAppStruct.nStat.u16Bit.u1ActivateWrCmd)
				{
					//TURN_TGL_MTEST();
					BuildWrProcess();
					sPMBusAppStruct.nStat.u16Bit.u1ActivateWrCmd = 0;
				}
				//--------------------------------------
				// polling read command
				//--------------------------------------
				else
				{
#if (MST_RD_SEQUENCE)
					BuildRdSequenceProcess();
#else
					BuildRdProcess();
#endif
					//TURN_TGL_MTEST();
				}
			}
		}
		//--------------------------------------
		// activating write cmd
		//--------------------------------------
		/*if(sPMBusAppStruct.nStat.u16Bit.u1ActivateWrCmd)
		{
			//TURN_TGL_MTEST();
			BuildWrProcess();
			sPMBusAppStruct.nStat.u16Bit.u1ActivateWrCmd = 0;
		}
		//--------------------------------------
		// polling read command
		//--------------------------------------
		else
		{
			BuildRdProcess();
			//TURN_TGL_MTEST();
		}*/
	}
}
#endif /* LITEON_BT */
/*******************************************************************************
*	brief 	handle the master PM Bus application
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
#if (BAIDU_BT)
void MstPMBusProcess(void)
{
	u8_t* pu8RdBuff = NULL;
	u8_t u8SlvAddr, u8RdLen;

	u16_t u16CmdSize, u16CmdOffset;

	if (GetMasterI2cIdleFlage(HW_I2C1) == false)
	{
	    return;
	}

	if (sPMBusAppStruct.nStat.u16Bit.u1MasterRd)
	{
		sPMBusAppStruct.nStat.u16Bit.u1MasterRd = 0;
		//TURN_TGL_MTEST();
		if (GetMasterI2cStatus(HW_I2C1) == kStatus_I2C_Success)
		{
			u16CmdSize = sizeof(tsBBU_Dev[0]);
			u16CmdOffset = u16CmdSize * (u16_t)sDevStruct.u8AddrIndex;
			//if ((sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_RdnBytes) || (sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_ProCall) ||
			//	(sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_RdWrnBytes))
			if ((sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_RdnBytes) || (sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_RdWrnBytes))
			{
				pu8RdBuff = &sPMBusAppStruct.pu8RdBuff[0];
				u8RdLen = sPMBusAppStruct.u8RdLen;
			}
			//else if ((sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_BlockRd) || (sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_BWrBRdProCall) ||
			//		 (sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_BlockRdWr) || (sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_BRdBWr_Wrnbytes))
			else if ((sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_BlockRd) || (sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_BlockRdWr))
			{
				pu8RdBuff = &sPMBusAppStruct.pu8RdBuff[1];
				u8RdLen = sPMBusAppStruct.pu8RdBuff[0];
				sPMBusAppStruct.u8RdLen = u8RdLen + 1;
			}


			if (pu8RdBuff != NULL)
			{
				if (GetMasterI2cPECSupportFlage(HW_I2C1) == true)
				{
					if (CheckPMBusCrc8() == true)
					{
						(*sPMBusAppStruct.psCmd->FuncPtr)(pu8RdBuff, sPMBusAppStruct.psCmd->pu8Buff + u16CmdOffset, u8RdLen);
						sDevStruct.nDevStat.u16All |= (1 << sDevStruct.u8AddrIndex);

						#if (BBU_NACK)
						sDevStruct.pu8DevNakCnt[sDevStruct.u8AddrIndex] = 0;
						#endif
						//TURN_TGL_PTD7();
					}

				}
				else
				{
					(*sPMBusAppStruct.psCmd->FuncPtr)(pu8RdBuff, sPMBusAppStruct.psCmd->pu8Buff + u16CmdOffset, u8RdLen);
					sDevStruct.nDevStat.u16All |= (1 << sDevStruct.u8AddrIndex);

					#if (BBU_NACK)
					sDevStruct.pu8DevNakCnt[sDevStruct.u8AddrIndex] = 0;
					#endif
				}
			}
			else
			{

			}

		}
		else if (GetMasterI2cStatus(HW_I2C1) == kStatus_I2C_ReceivedNak)
		{
			// printf("\r\nI2C communication failed, error code: %d", returnValue);
			#if (BBU_NACK)
			if(sDevStruct.u8AddrIndex == 0)
			{
				//TURN_TGL_PTD7();
			}
			sDevStruct.pu8DevNakCnt[sDevStruct.u8AddrIndex] += 1;
			if(sDevStruct.pu8DevNakCnt[sDevStruct.u8AddrIndex] > 3)
			{
				sDevStruct.nDevStat.u16All &= (~(1 << sDevStruct.u8AddrIndex));
				sDevStruct.pu8DevNakCnt[sDevStruct.u8AddrIndex] = 0;
				/*if(sDevStruct.u8AddrIndex == 0)
				{
					TURN_TGL_MTEST();
				}*/
			}
			#else
			sDevStruct.nDevStat.u16All &= (~(1 << sDevStruct.u8AddrIndex));
			#endif
        	//TURN_TGL_PTD6();
#if (MST_RD_SEQUENCE)
        	sDevStruct.u8AddrIndex += 1;
			if (sDevStruct.u8AddrIndex >= BBU_DEV_NUM)
			{
				sDevStruct.u8AddrIndex = 0;
				update_RdSequence_Index();
			}
			sPMBusAppStruct.u16RdCmdIndex = 0;
#else
        	sDevStruct.u8AddrIndex += 1;
			if (sDevStruct.u8AddrIndex >= BBU_DEV_NUM)
			{
				sDevStruct.u8AddrIndex = 0;
			}
			sPMBusAppStruct.u16RdCmdIndex = 0;
#endif

		}
	    else if (GetMasterI2cStatus(HW_I2C1) == kStatus_I2C_Timeout)
	    {

	    }
	    else
	    {

	    }
	}
	else if (sPMBusAppStruct.nStat.u16Bit.u1MasterWr)
	{
		//if(sPMBusAppStruct.pu8CmdBuff[0] == 0x03)
		//{
			//TURN_TGL_MTEST();
		//}
		//TURN_TGL_MTEST();
		if (GetMasterI2cStatus(HW_I2C1) == kStatus_I2C_Success)
		{
			if (sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_ProCall)
			{
				pu8RdBuff = &sPMBusAppStruct.pu8RdBuff[0];
				u8RdLen = sPMBusAppStruct.u8RdLen;
			}
			else if (sPMBusAppStruct.psCmd->u8CmdType == PMBusCT_BWrBRdProCall)
			{
				pu8RdBuff = &sPMBusAppStruct.pu8RdBuff[1];
				u8RdLen = sPMBusAppStruct.pu8RdBuff[0];
				sPMBusAppStruct.u8RdLen = u8RdLen + 1;
			}
			else
			{
				pu8RdBuff = NULL;
			}

			if (pu8RdBuff != NULL)
			{
				u16CmdSize = sizeof(tsBBU_Dev[0]);
				u16CmdOffset = u16CmdSize * (u16_t)sDevStruct.u8WrAddrIndex;
				if (GetMasterI2cPECSupportFlage(HW_I2C1) == true)
				{
					if (CheckPMBusCrc8() == true)
					{
						(*sPMBusAppStruct.psCmd->FuncPtr)(pu8RdBuff, sPMBusAppStruct.psCmd->pu8Buff + u16CmdOffset, u8RdLen);
						//sDevStruct.nDevStat.u16All |= (1 << sDevStruct.u8AddrIndex);
					}
				}
				else
				{
					(*sPMBusAppStruct.psCmd->FuncPtr)(pu8RdBuff, sPMBusAppStruct.psCmd->pu8Buff + u16CmdOffset, u8RdLen);
					//sDevStruct.nDevStat.u16All |= (1 << sDevStruct.u8AddrIndex);
				}
			}
		}
		else if (GetMasterI2cStatus(HW_I2C1) == kStatus_I2C_ReceivedNak)
		{
			//sDevStruct.nDevStat.u16All &= (~(1 << sDevStruct.u8AddrIndex));
		}
		else if (GetMasterI2cStatus(HW_I2C1) == kStatus_I2C_Timeout)
		{

		}
		else
		{

		}
		sPMBusAppStruct.nStat.u16Bit.u1MasterWr = 0;
		//TURN_TGL_BBS_PWM();
	}
	else if (sBbuBaiduBtStr.tnFlag.u16Bit.u1RdBtDummy)
	{
		sBbuBaiduBtStr.tnFlag.u16Bit.u1RdBtDummy = 0;
		if (GetMasterI2cStatus(HW_I2C1) == kStatus_I2C_Success)
		{

		}
		else if (GetMasterI2cStatus(HW_I2C1) == kStatus_I2C_ReceivedNak)
		{

		}
	    else if (GetMasterI2cStatus(HW_I2C1) == kStatus_I2C_Timeout)
	    {

	    }
	    else
	    {

	    }
	}
	else if(sBbuBaiduBtStr.tnFlag.u16Bit.u1RdBt)
	{
		sBbuBaiduBtStr.tnFlag.u16Bit.u1RdBt = 0;
		if (GetMasterI2cStatus(HW_I2C1) == kStatus_I2C_Success)
		{
			u16CmdSize = sizeof(tsBBU_Dev[0]);
			u16CmdOffset = u16CmdSize * (u16_t)sBbuBaiduBtStr.u8AddrIndex;
			if ((sBbuBaiduBtStr.psCmd->u8CmdType == PMBusCT_RdnBytes) || (sBbuBaiduBtStr.psCmd->u8CmdType == PMBusCT_RdWrnBytes))
			{
				pu8RdBuff = &sBbuBaiduBtStr.pu8RdBuff[0];
				u8RdLen = sBbuBaiduBtStr.u8RdLen;
			}
			else if ((sBbuBaiduBtStr.psCmd->u8CmdType == PMBusCT_BlockRd) || (sBbuBaiduBtStr.psCmd->u8CmdType == PMBusCT_BlockRdWr))
			{
				pu8RdBuff = &sBbuBaiduBtStr.pu8RdBuff[1];
				u8RdLen = sBbuBaiduBtStr.pu8RdBuff[0];
				sBbuBaiduBtStr.u8RdLen = u8RdLen + 1;
			}


			if (pu8RdBuff != NULL)
			{
				if (GetMasterI2cPECSupportFlage(HW_I2C1) == true)
				{
					if (CheckInVeBbuBtCrc8() == true)
					{
						(*sBbuBaiduBtStr.psCmd->FuncPtr)(pu8RdBuff, sBbuBaiduBtStr.psCmd->pu8Buff + u16CmdOffset, u8RdLen);

					}

				}
				else
				{
					(*sBbuBaiduBtStr.psCmd->FuncPtr)(pu8RdBuff, sBbuBaiduBtStr.psCmd->pu8Buff + u16CmdOffset, u8RdLen);
				}
			}
			else
			{

			}
		}
		else if (GetMasterI2cStatus(HW_I2C1) == kStatus_I2C_ReceivedNak)
		{

		}
		else if (GetMasterI2cStatus(HW_I2C1) == kStatus_I2C_Timeout)
		{

		}
		else
		{

		}
	}
	else
	{

		//--------------------------------------
		// activating write cmd
		//--------------------------------------
		if(sPMBusAppStruct.nStat.u16Bit.u1ActivateWrCmd)
		{
#if(MST_RESEND)
			TURN_TGL_MTEST();
#endif
			BuildWrProcess();
			sPMBusAppStruct.nStat.u16Bit.u1ActivateWrCmd = 0;
		}
		//--------------------------------------
		// polling read command
		//--------------------------------------
		else
		{
			if(sBbuBaiduBtStr.tnFlag.u16Bit.u2BtLock == 1)
			{
				BuildInVeBbuDummyRdProcess();
			}
			else if(sBbuBaiduBtStr.tnFlag.u16Bit.u2BtLock == 2)
			{
				//TURN_TGL_MTEST();
				BuildInVeBbuRdProcess();
			}
			else
			{
#if (MST_RD_SEQUENCE)
				BuildRdSequenceProcess();
#else
				BuildRdProcess();
#endif
			}
			//TURN_TGL_MTEST();
		}
	}
}
#endif /* BAIDU_BT */

/*******************************************************************************
*	brief 	handle the master PM Bus application
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
void Init_MstPMBus(void)
{
    /* Initialize struct */
    memset(&sPMBusAppStruct, 0, sizeof(sPMBusAppStr_t));
    sPMBusAppStruct.u8WrCmdProperty = PMBusCP_RdWr;
    sPMBusAppStruct.u8RdCmdProperty = PMBusCP_RdWr;

    memset(&sDevStruct, 0, sizeof(sDevStruct));

#if (LITEON_BT)
    memset(&sBbuBtldStr, 0, sizeof(sBbuBtldStr));
#endif /* LITEON_BT */

    memset(&tsBbuBt_Dev, 0xFF, sizeof(tsBbuBt_Dev));
    tPMBusPushWrStr.u8PushIndex = tPMBusPushWrStr.u8WriteIndex = 0;
}
/****************************************************************************
*	name        : BscClrFaultProcess
*	description :
*	return      : none
****************************************************************************/
void BscClrFaultProcess(void)
{
	tsBSC_Dev.tnStatusCML.u8All = 0;
	tsBSC_Dev.tnStatusWord.u16All = 0;
}
/****************************************************************************
*	name        : BscLearningCtrlCmdProcess
*	description :
*	return      : none
****************************************************************************/
void BscLearningCtrlCmdProcess(void)
{
	if(tsBSC_Dev.tnLearningCtrl.u16Bit.u2CtrlDischrg == 1)
	{
		BscManualLearningActiveProcess();
	}
	else if(tsBSC_Dev.tnLearningCtrl.u16Bit.u2CtrlDischrg == 2)
	{
		BscForceDischrgProcess(eLCond_ForcedStop);
	}
	else
	{

	}
}
/****************************************************************************
*	name        : BscBattSelfTestCmdProcess
*	description :
*	return      : none
****************************************************************************/
void BscBattSelfTestCmdProcess(void)
{
	ReloadBattSelfTestCount(1);
}
/*******************************************************************************
*	brief 	handle the master PM Bus application
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
u8_t GetBscQueryDataFormat(u8_t u8CmdCode, u8_t* pu8buff)
{
	u8_t j, u8Data;

	u8Data = 0;
	*pu8buff = 0;

#if (MST_RD_SEQUENCE)
	for(j=0; j<BBU_PMBUS_RW_CFG_NUM; j++)
	{
		if (u8CmdCode == sBbuPMBusRWCmd_CFG[j].u8CmdCode)
		{
			//command is support
			*pu8buff |= 0x80;
			//command is support for write
			*pu8buff |= 0x40;
			//command is support for read
			*pu8buff |= 0x20;
			// get the format
			*pu8buff |= (sBbuPMBusRWCmd_CFG[j].u8DataType<<2);

			//*pu8buff = u8Data;
			return (PMBusCP_RdWr);
		}
	}
#else
	for(j=0; j<BBU_PMBUS_RW_NUM; j++)
	{
		if (u8CmdCode == sBbuPMBusRWCmd[j].u8CmdCode)
		{
			//command is support
			*pu8buff |= 0x80;
			//command is support for write
			*pu8buff |= 0x40;
			//command is support for read
			*pu8buff |= 0x20;
			// get the format
			*pu8buff |= (sBbuPMBusRWCmd[j].u8DataType<<2);

			//*pu8buff = u8Data;
			return (PMBusCP_RdWr);
		}
	}
#endif

#if (MST_RD_SEQUENCE)
	for(j=0; j<BBU_PMBUS_RO_STA_NUM; j++)
	{
		if (u8CmdCode == sBbuPMBusROCmd_STA[j].u8CmdCode)
		{
			//command is support
			*pu8buff |= 0x80;
			//command is support for write
			//u8Data |= 0x40;
			//command is support for read
			*pu8buff |= 0x20;
			// get the format
			*pu8buff |= (sBbuPMBusROCmd_STA[j].u8DataType<<2);

			//*pu8buff = u8Data;
			return (PMBusCP_RdOnly);
		}
	}

	for(j=0; j<BBU_PMBUS_RO_MST_NUM; j++)
	{
		if (u8CmdCode == sBbuPMBusROCmd_MST[j].u8CmdCode)
		{
			//command is support
			*pu8buff |= 0x80;
			//command is support for write
			//u8Data |= 0x40;
			//command is support for read
			*pu8buff |= 0x20;
			// get the format
			*pu8buff |= (sBbuPMBusROCmd_MST[j].u8DataType<<2);

			//*pu8buff = u8Data;
			return (PMBusCP_RdOnly);
		}
	}

	for(j=0; j<BBU_PMBUS_RO_INF_NUM; j++)
	{
		if (u8CmdCode == sBbuPMBusROCmd_INF[j].u8CmdCode)
		{
			//command is support
			*pu8buff |= 0x80;
			//command is support for write
			//u8Data |= 0x40;
			//command is support for read
			*pu8buff |= 0x20;
			// get the format
			*pu8buff |= (sBbuPMBusROCmd_INF[j].u8DataType<<2);

			//*pu8buff = u8Data;
			return (PMBusCP_RdOnly);
		}
	}

	for(j=0; j<BBU_PMBUS_RO_MFC_NUM; j++)
	{
		if (u8CmdCode == sBbuPMBusROCmd_MFC[j].u8CmdCode)
		{
			//command is support
			*pu8buff |= 0x80;
			//command is support for write
			//u8Data |= 0x40;
			//command is support for read
			*pu8buff |= 0x20;
			// get the format
			*pu8buff |= (sBbuPMBusROCmd_MFC[j].u8DataType<<2);

			//*pu8buff = u8Data;
			return (PMBusCP_RdOnly);
		}
	}
#else
	for(j=0; j<BBU_PMBUS_RO_NUM; j++)
	{
		if (u8CmdCode == sBbuPMBusROCmd[j].u8CmdCode)
		{
			//command is support
			*pu8buff |= 0x80;
			//command is support for write
			//u8Data |= 0x40;
			//command is support for read
			*pu8buff |= 0x20;
			// get the format
			*pu8buff |= (sBbuPMBusROCmd[j].u8DataType<<2);

			//*pu8buff = u8Data;
			return (PMBusCP_RdOnly);
		}
	}
#endif

#if (MST_RD_SEQUENCE)
	for(j=0; j<BBU_PMBUS_WO_CTR_NUM; j++)
	{
		if (u8CmdCode == sBbuPMBusWOCmd_CTR[j].u8CmdCode)
		{
			//command is support
			*pu8buff |= 0x80;
			//command is support for write
			*pu8buff |= 0x40;
			//command is support for read
			//u8Data |= 0x20;
			// get the format
			*pu8buff |= (sBbuPMBusWOCmd_CTR[j].u8DataType<<2);

			//*pu8buff = u8Data;
			return (PMBusCP_WrOnly);
		}
	}
#else
	for(j=0; j<BBU_PMBUS_WO_NUM; j++)
	{
		if (u8CmdCode == sBbuPMBusWOCmd[j].u8CmdCode)
		{
			//command is support
			*pu8buff |= 0x80;
			//command is support for write
			*pu8buff |= 0x40;
			//command is support for read
			//u8Data |= 0x20;
			// get the format
			*pu8buff |= (sBbuPMBusWOCmd[j].u8DataType<<2);

			//*pu8buff = u8Data;
			return (PMBusCP_WrOnly);
		}
	}
#endif

	*pu8buff = 0x08;
	return (PMBusCP_NoSupp);
}

/*******************************************************************************
*	brief 	handle the master PM Bus application
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
u8_t ParseBbuRdCmdSup(u8_t u8DevIndex, u8_t u8CmdCode, u8_t* pu8tgtbuff, u8_t* pu8len)
{
	u8_t j;
	u8_t* pu8buff;

#if (MST_RD_SEQUENCE)
	for(j=0; j<BBU_PMBUS_RW_CFG_NUM; j++)
	{
		if (u8CmdCode == sBbuPMBusRWCmd_CFG[j].u8CmdCode)
		{
			*pu8len = sBbuPMBusRWCmd_CFG[j].u8Len;
			pu8buff = sBbuPMBusRWCmd_CFG[j].pu8Buff + (u8DevIndex*sizeof(tsBBU_Dev[0]));
			memcpy(pu8tgtbuff, pu8buff, *pu8len);
			return (PMBusCP_RdWr);
		}
	}
#else
	for(j=0; j<BBU_PMBUS_RW_NUM; j++)
	{
		if (u8CmdCode == sBbuPMBusRWCmd[j].u8CmdCode)
		{
			*pu8len = sBbuPMBusRWCmd[j].u8Len;
			pu8buff = sBbuPMBusRWCmd[j].pu8Buff + (u8DevIndex*sizeof(tsBBU_Dev[0]));
			memcpy(pu8tgtbuff, pu8buff, *pu8len);
			return (PMBusCP_RdWr);
		}
	}
#endif

#if (MST_RD_SEQUENCE)
	for(j=0; j<BBU_PMBUS_RO_STA_NUM; j++)
	{
		if (u8CmdCode == sBbuPMBusROCmd_STA[j].u8CmdCode)
		{
			*pu8len = sBbuPMBusROCmd_STA[j].u8Len;
			pu8buff = sBbuPMBusROCmd_STA[j].pu8Buff + (u8DevIndex*sizeof(tsBBU_Dev[0]));
			memcpy(pu8tgtbuff, pu8buff, *pu8len);
			return (PMBusCP_RdOnly);
		}
	}

	for(j=0; j<BBU_PMBUS_RO_MST_NUM; j++)
	{
		if (u8CmdCode == sBbuPMBusROCmd_MST[j].u8CmdCode)
		{
			*pu8len = sBbuPMBusROCmd_MST[j].u8Len;
			pu8buff = sBbuPMBusROCmd_MST[j].pu8Buff + (u8DevIndex*sizeof(tsBBU_Dev[0]));
			memcpy(pu8tgtbuff, pu8buff, *pu8len);
			return (PMBusCP_RdOnly);
		}
	}

	for(j=0; j<BBU_PMBUS_RO_INF_NUM; j++)
	{
		if (u8CmdCode == sBbuPMBusROCmd_INF[j].u8CmdCode)
		{
			*pu8len = sBbuPMBusROCmd_INF[j].u8Len;
			pu8buff = sBbuPMBusROCmd_INF[j].pu8Buff + (u8DevIndex*sizeof(tsBBU_Dev[0]));
			memcpy(pu8tgtbuff, pu8buff, *pu8len);
			return (PMBusCP_RdOnly);
		}
	}

	for(j=0; j<BBU_PMBUS_RO_MFC_NUM; j++)
	{
		if (u8CmdCode == sBbuPMBusROCmd_MFC[j].u8CmdCode)
		{
			*pu8len = sBbuPMBusROCmd_MFC[j].u8Len;
			pu8buff = sBbuPMBusROCmd_MFC[j].pu8Buff + (u8DevIndex*sizeof(tsBBU_Dev[0]));
			memcpy(pu8tgtbuff, pu8buff, *pu8len);
			return (PMBusCP_RdOnly);
		}
	}
#else
	for(j=0; j<BBU_PMBUS_RO_NUM; j++)
	{
		if (u8CmdCode == sBbuPMBusROCmd[j].u8CmdCode)
		{
			*pu8len = sBbuPMBusROCmd[j].u8Len;
			pu8buff = sBbuPMBusROCmd[j].pu8Buff + (u8DevIndex*sizeof(tsBBU_Dev[0]));
			memcpy(pu8tgtbuff, pu8buff, *pu8len);
			return (PMBusCP_RdOnly);
		}
	}
#endif

	return (PMBusCP_NoSupp);
}
/*******************************************************************************
*	brief 	handle the master PM Bus application
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
u8_t ParseBbuWrCmdSup(u8_t u8DevIndex, u8_t u8CmdCode, u8_t* pu8buff, u8_t u8len)
{
	u8_t j;

#if (MST_RD_SEQUENCE)
	for(j=0; j<BBU_PMBUS_RW_CFG_NUM; j++)
	{
		if (u8CmdCode == sBbuPMBusRWCmd_CFG[j].u8CmdCode)
		{
			sPMBusAppStruct.u16WrCmdIndex = j;
			sPMBusAppStruct.u8TempWrLen = u8len;
			memcpy(sPMBusAppStruct.pu8WrBuff, pu8buff, u8len);
			sPMBusAppStruct.u8WrCmdProperty = PMBusCP_RdWr;
			sPMBusAppStruct.nStat.u16Bit.u1ActivateWrCmd = 1;

			sDevStruct.u8TempWrAddrIndex = u8DevIndex;
			return (PMBusCP_RdWr);
		}
	}
#else
	for(j=0; j<BBU_PMBUS_RW_NUM; j++)
	{
		if (u8CmdCode == sBbuPMBusRWCmd[j].u8CmdCode)
		{
			sPMBusAppStruct.u16WrCmdIndex = j;
			sPMBusAppStruct.u8TempWrLen = u8len;
			memcpy(sPMBusAppStruct.pu8WrBuff, pu8buff, u8len);
			sPMBusAppStruct.u8WrCmdProperty = PMBusCP_RdWr;
			sPMBusAppStruct.nStat.u16Bit.u1ActivateWrCmd = 1;

			sDevStruct.u8TempWrAddrIndex = u8DevIndex;
			return (PMBusCP_RdWr);
		}
	}
#endif

#if (MST_RD_SEQUENCE)
	for(j=0; j<BBU_PMBUS_WO_CTR_NUM; j++)
	{
		if (u8CmdCode == sBbuPMBusWOCmd_CTR[j].u8CmdCode)
		{
			sPMBusAppStruct.u16WrCmdIndex = j;
			sPMBusAppStruct.u8TempWrLen = u8len;
			memcpy(sPMBusAppStruct.pu8WrBuff, pu8buff, u8len);
			sPMBusAppStruct.u8WrCmdProperty = PMBusCP_WrOnly;
			sPMBusAppStruct.nStat.u16Bit.u1ActivateWrCmd = 1;

			sDevStruct.u8TempWrAddrIndex = u8DevIndex;
			return (PMBusCP_WrOnly);
		}
	}
#else
	for(j=0; j<BBU_PMBUS_WO_NUM; j++)
	{
		if (u8CmdCode == sBbuPMBusWOCmd[j].u8CmdCode)
		{
			sPMBusAppStruct.u16WrCmdIndex = j;
			sPMBusAppStruct.u8TempWrLen = u8len;
			memcpy(sPMBusAppStruct.pu8WrBuff, pu8buff, u8len);
			sPMBusAppStruct.u8WrCmdProperty = PMBusCP_WrOnly;
			sPMBusAppStruct.nStat.u16Bit.u1ActivateWrCmd = 1;

			sDevStruct.u8TempWrAddrIndex = u8DevIndex;
			return (PMBusCP_WrOnly);
		}
	}
#endif

	return (PMBusCP_NoSupp);
}

/****************************************************************************
*	name        : IsBscRdCmdSup
*	description :
*	return      : none
****************************************************************************/
bool IsBscRdCmdSup(u8_t u8CmdCode)
{
	u8_t j;

	for(j=0; j<BBS_PMBUS_RW_NUM; j++)
	{
		if (u8CmdCode == sBbsPMBusRWCmd[j].u8CmdCode)
		{
			return true;
		}
	}

	for(j=0; j<BBS_PMBUS_RO_NUM; j++)
	{
		if (u8CmdCode == sBbsPMBusROCmd[j].u8CmdCode)
		{
			return true;
		}
	}
	return false;
}
/*******************************************************************************
*	brief 	ParseBscRdCmdSup
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
u8_t ParseBscRdCmdSup(u8_t u8CmdCode, u8_t* pu8tgtbuff, u8_t* pu8len)
{
	u8_t j;
	u8_t* pu8buff;

	for(j=0; j<BBS_PMBUS_RW_NUM; j++)
	{
		if (u8CmdCode == sBbsPMBusRWCmd[j].u8CmdCode)
		{
			*pu8len = sBbsPMBusRWCmd[j].u8Len;
			pu8buff = sBbsPMBusRWCmd[j].pu8Buff;
			memcpy(pu8tgtbuff, pu8buff, *pu8len);
			return (PMBusCP_RdWr);
		}
	}

	for(j=0; j<BBS_PMBUS_RO_NUM; j++)
	{
		if (u8CmdCode == sBbsPMBusROCmd[j].u8CmdCode)
		{
			*pu8len = sBbsPMBusROCmd[j].u8Len;
			pu8buff = sBbsPMBusROCmd[j].pu8Buff;
			memcpy(pu8tgtbuff, pu8buff, *pu8len);
			return (PMBusCP_RdOnly);
		}
	}

	return (PMBusCP_NoSupp);
}
/****************************************************************************
*	name        : IsBscWrCmdSup
*	description :
*	return      : none
****************************************************************************/
bool IsBscWrCmdSup(u8_t u8addr, u8_t u8CmdCode)
{
	u8_t j;

	if(IsBscI2cAddr2(u8addr) == true)
	{
		for(j=0; j<BBS_PMBUS_RW_NUM; j++)
		{
			if (u8CmdCode == sBbsPMBusRWCmd[j].u8CmdCode)
			{
				return true;
			}
		}

		for(j=0; j<BBS_PMBUS_WO_NUM; j++)
		{
			if (u8CmdCode == sBbsPMBusWOCmd[j].u8CmdCode)
			{
				return true;
			}
		}
		return false;
	}

	return false;
}
/*******************************************************************************
*	brief 	handle the master PM Bus application
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
u8_t ParseBscWrCmdSup(u8_t u8addr, u8_t u8CmdCode, u8_t* pu8buff, u8_t u8len)
{
	u8_t j;
	u8_t* pu8tgtbuff;

	if(IsBscI2cAddr2(u8addr) == true)
	{
		for(j=0; j<BBS_PMBUS_RW_NUM; j++)
		{
			if (u8CmdCode == sBbsPMBusRWCmd[j].u8CmdCode)
			{
				if(sBbsPMBusRWCmd[j].u8Len == u8len)
				{

#if (BAIDU_BT)
					if(u8CmdCode == PMBusCmd_MFRSp33)
					{
						UpdateBscInVeBtCmd(*pu8buff);
					}
					else
					{
						pu8tgtbuff = sBbsPMBusRWCmd[j].pu8Buff;
						memcpy(pu8tgtbuff, pu8buff, u8len);

						//PushE2PWriteDataLoop(u8CmdCode, u8len, pu8tgtbuff);
						if(u8CmdCode == PMBusCmd_UsrData8)
						{
							BscLearningCtrlCmdProcess();
						}
						else if(u8CmdCode == PMBusCmd_MFRSp20)
						{
							PushE2PWriteLoop();
						}
						else if(u8CmdCode == PMBusCmd_MFRSp31)
						{
							BscBattSelfTestCmdProcess();
						}
					}

					InVeBtWrProcess(u8CmdCode);

#else
					pu8tgtbuff = sBbsPMBusRWCmd[j].pu8Buff;
					memcpy(pu8tgtbuff, pu8buff, u8len);
					//PushE2PWriteDataLoop(u8CmdCode, u8len, pu8tgtbuff);
					if(u8CmdCode == PMBusCmd_UsrData8)
					{
						BscLearningCtrlCmdProcess();
					}
					else if(u8CmdCode == PMBusCmd_MFRSp20)
					{
						PushE2PWriteLoop();
					}
					else if(u8CmdCode == PMBusCmd_MFRSp31)
					{
						BscBattSelfTestCmdProcess();
					}

#endif /* BAIDU_BT */
					return (PMBusCP_RdWr);
				}
			}
		}

		for(j=0; j<BBS_PMBUS_WO_NUM; j++)
		{
			if (u8CmdCode == sBbsPMBusWOCmd[j].u8CmdCode)
			{
				if(sBbsPMBusWOCmd[j].u8Len == u8len)
				{
					if(u8CmdCode == PMBusCmd_ClrFault)
					{
						BscClrFaultProcess();
					}
					else
					{
						pu8tgtbuff = sBbsPMBusWOCmd[j].pu8Buff;
						memcpy(pu8tgtbuff, pu8buff, u8len);
						//PushE2PWriteDataLoop(u8CmdCode, u8len, pu8tgtbuff);

#if (BAIDU_BT)
						InVeBtWrProcess(u8CmdCode);
#endif /* BAIDU_BT */

					}
					return (PMBusCP_WrOnly);
				}
			}
		}

		return (PMBusCP_NoSupp);
	}

	return (PMBusCP_NoSupp);
}

/****************************************************************************
*	name        : ParseBscUrgentRdCmdSup
*	description :
*	return      : none
****************************************************************************/
u8_t ParseBscUrgentRdCmdSup(u8_t u8DevIndex, u8_t* pu8dstlen, u8_t* pu8dstbuff)
{
	u8_t i;

	i = 0;
	memcpy(pu8dstbuff+i, (u8_t*)&tsBBU_Dev[u8DevIndex].u16ReadVin, sizeof(tsBBU_Dev[u8DevIndex].u16ReadVin));
	i += sizeof(tsBBU_Dev[u8DevIndex].u16ReadVin);

	memcpy(pu8dstbuff+i, (u8_t*)&tsBBU_Dev[u8DevIndex].u16ReadIin, sizeof(tsBBU_Dev[u8DevIndex].u16ReadIin));
	i += sizeof(tsBBU_Dev[u8DevIndex].u16ReadIin);

	memcpy(pu8dstbuff+i, (u8_t*)&tsBBU_Dev[u8DevIndex].u16ReadVout, sizeof(tsBBU_Dev[u8DevIndex].u16ReadVout));
	i += sizeof(tsBBU_Dev[u8DevIndex].u16ReadVout);

	memcpy(pu8dstbuff+i, (u8_t*)&tsBBU_Dev[u8DevIndex].u16ReadIout, sizeof(tsBBU_Dev[u8DevIndex].u16ReadIout));
	i += sizeof(tsBBU_Dev[u8DevIndex].u16ReadIout);

	memcpy(pu8dstbuff+i, (u8_t*)&tsBBU_Dev[u8DevIndex].u16ReadTemp1, sizeof(tsBBU_Dev[u8DevIndex].u16ReadTemp1));
	i += sizeof(tsBBU_Dev[u8DevIndex].u16ReadTemp1);

	memcpy(pu8dstbuff+i, (u8_t*)&tsBBU_Dev[u8DevIndex].u16ReadTemp2, sizeof(tsBBU_Dev[u8DevIndex].u16ReadTemp2));
	i += sizeof(tsBBU_Dev[u8DevIndex].u16ReadTemp2);

	memcpy(pu8dstbuff+i, (u8_t*)&tsBBU_Dev[u8DevIndex].u16ReadTemp3, sizeof(tsBBU_Dev[u8DevIndex].u16ReadTemp3));
	i += sizeof(tsBBU_Dev[u8DevIndex].u16ReadTemp3);

	memcpy(pu8dstbuff+i, &tsBBU_Dev[u8DevIndex].tnStatusBBU.u8All, sizeof(tsBBU_Dev[u8DevIndex].tnStatusBBU.u8All));
	i += sizeof(tsBBU_Dev[u8DevIndex].tnStatusBBU.u8All);

	memcpy(pu8dstbuff+i, &tsBBU_Dev[u8DevIndex].tnStateBBU.u16All, sizeof(tsBBU_Dev[u8DevIndex].tnStateBBU.u16All));
	i += sizeof(tsBBU_Dev[u8DevIndex].tnStateBBU.u16All);

	memcpy(pu8dstbuff+i, (u8_t*)&tsBBU_Dev[u8DevIndex].u16BattVolt, sizeof(tsBBU_Dev[u8DevIndex].u16BattVolt));
	i += sizeof(tsBBU_Dev[u8DevIndex].u16BattVolt);

	memcpy(pu8dstbuff+i, (u8_t*)&tsBBU_Dev[u8DevIndex].u16BattCurr, sizeof(tsBBU_Dev[u8DevIndex].u16BattCurr));
	i += sizeof(tsBBU_Dev[u8DevIndex].u16BattCurr);

	memcpy(pu8dstbuff+i, (u8_t*)&tsBBU_Dev[u8DevIndex].u16BattASOC, sizeof(tsBBU_Dev[u8DevIndex].u16BattASOC));
	i += sizeof(tsBBU_Dev[u8DevIndex].u16BattASOC);

	memcpy(pu8dstbuff+i, (u8_t*)&tsBBU_Dev[u8DevIndex].u16BattRSOC, sizeof(tsBBU_Dev[u8DevIndex].u16BattRSOC));
	i += sizeof(tsBBU_Dev[u8DevIndex].u16BattRSOC);

	memcpy(pu8dstbuff+i, (u8_t*)&tsBBU_Dev[u8DevIndex].u16BattCapacity, sizeof(tsBBU_Dev[u8DevIndex].u16BattCapacity));
	i += sizeof(tsBBU_Dev[u8DevIndex].u16BattCapacity);

	memcpy(pu8dstbuff+i, (u8_t*)&tsBBU_Dev[u8DevIndex].u16BattCycCnt, sizeof(tsBBU_Dev[u8DevIndex].u16BattCycCnt));
	i += sizeof(tsBBU_Dev[u8DevIndex].u16BattCycCnt);

	memcpy(pu8dstbuff+i, (u8_t*)&tsBBU_Dev[u8DevIndex].u16BattTemp, sizeof(tsBBU_Dev[u8DevIndex].u16BattTemp));
	i += sizeof(tsBBU_Dev[u8DevIndex].u16BattTemp);

	memcpy(pu8dstbuff+i, (u8_t*)&tsBBU_Dev[u8DevIndex].u16BattSOH, sizeof(tsBBU_Dev[u8DevIndex].u16BattSOH));
	i += sizeof(tsBBU_Dev[u8DevIndex].u16BattSOH);

	memcpy(pu8dstbuff+i, (u8_t*)&tsBBU_Dev[u8DevIndex].u16FullyChrgCapacity, sizeof(tsBBU_Dev[u8DevIndex].u16FullyChrgCapacity));
	i += sizeof(tsBBU_Dev[u8DevIndex].u16FullyChrgCapacity);

	memcpy(pu8dstbuff+i, &tsBBU_Dev[u8DevIndex].pu32BBUProtectType, sizeof(tsBBU_Dev[u8DevIndex].pu32BBUProtectType));
	i += sizeof(tsBBU_Dev[u8DevIndex].pu32BBUProtectType);

	memcpy(pu8dstbuff+i, (u8_t*)&tsBBU_Dev[u8DevIndex].u16DischrgRemainTime, sizeof(tsBBU_Dev[u8DevIndex].u16DischrgRemainTime));
	i += sizeof(tsBBU_Dev[u8DevIndex].u16DischrgRemainTime);

	//........//
	//memcpy(pu8dstbuff+i, (u8_t*)&tsBBU_Dev[u8DevIndex].u16BattStatus, sizeof(tsBBU_Dev[u8DevIndex].u16BattStatus));
	//i += sizeof(tsBBU_Dev[u8DevIndex].u16BattStatus);

	//memcpy(pu8dstbuff+i, (u8_t*)&tsBBU_Dev[u8DevIndex].u16BattProcStatus, sizeof(tsBBU_Dev[u8DevIndex].u16BattProcStatus));
	//i += sizeof(tsBBU_Dev[u8DevIndex].u16BattProcStatus);

	//memcpy(pu8dstbuff+i, (u8_t*)&tsBBU_Dev[u8DevIndex].u16BattPfStatus, sizeof(tsBBU_Dev[u8DevIndex].u16BattPfStatus));
	//i += sizeof(tsBBU_Dev[u8DevIndex].u16BattPfStatus);
	//........//

	*pu8dstlen = i;

	return (PMBusCP_RdOnly);
}
/****************************************************************************
*	name        : IsBbuBtldrBWrBRdProCallCmdSup
*	description :
*	return      : none
****************************************************************************/
#if (LITEON_BT)
bool IsBbuBtldrBWrBRdProCallCmdSup(u8_t u8Cmd, u8_t u8len)
{
	bool blret = false;

	switch(u8Cmd)
	{
		case PMBusCmd_MFRSp32:	//read code id
			if(u8len == 15)
			{
				if(sBbuBtldStr.tnFlag.u16Bit.u1CmdF0 == 0)
				{
					memset((u8_t*)&tsBbuBt_Dev.tsBtCmdF0h.tnBtStatus.u16All, 0xFF, sizeof(sBtCmdF0h_t));
					sBbuBtldStr.tnFlag.u16Bit.u1CmdF0 = 1;
				}
				else if(sBbuBtldStr.tnFlag.u16Bit.u1CmdF0 == 1)
				{
					if(tsBbuBt_Dev.tsBtCmdF0h.tnBtStatus.u16Bit.u1ProcessFlag == 0)
					{
						sBbuBtldStr.tnFlag.u16Bit.u1CmdF0 = 0;
					}
				}
				blret = true;
			}
			break;
		case PMBusCmd_MFRSp33:	//read mcu type status
			if(u8len == 3)
			{
				if(sBbuBtldStr.tnFlag.u16Bit.u1CmdF1 == 0)
				{
					memset((u8_t*)&tsBbuBt_Dev.tsBtCmdF1h.u16ModuleWord, 0xFF, sizeof(sBtCmdF1h_t));
					sBbuBtldStr.tnFlag.u16Bit.u1CmdF1 = 1;
				}
				else if(sBbuBtldStr.tnFlag.u16Bit.u1CmdF1 == 1)
				{
					if(tsBbuBt_Dev.tsBtCmdF1h.tnBtStatus.u16Bit.u1ProcessFlag == 0)
					{
						sBbuBtldStr.tnFlag.u16Bit.u1CmdF1 = 0;
					}
				}
				blret = true;
			}
			break;
		case PMBusCmd_MFRSp34:	//enter boot mode
			if(u8len == 7)
			{
				if(sBbuBtldStr.tnFlag.u16Bit.u1CmdF2 == 0)
				{
					memset((u8_t*)&tsBbuBt_Dev.tsBtCmdF2h.tnBtStatus.u16All, 0xFF, sizeof(sBtCmdF2h_t));
					sBbuBtldStr.tnFlag.u16Bit.u1CmdF2 = 1;
				}
				else if(sBbuBtldStr.tnFlag.u16Bit.u1CmdF2 == 1)
				{
					if(tsBbuBt_Dev.tsBtCmdF2h.tnBtStatus.u16Bit.u1ProcessFlag == 0)
					{
						sBbuBtldStr.tnFlag.u16Bit.u1CmdF2 = 0;
					}
				}
				blret = true;
			}
			break;
		/*case PMBusCmd_MFRSp35:	//write erase flash
			if(u8len == 11)
			{
				blret = true;
			}
			break;
		case PMBusCmd_MFRSp36:	//write program flash
			if(u8len > 7)
			{
				blret = true;
			}
			break;
			*/
		case PMBusCmd_MFRSp37:	//write reset
			if(u8len == 3)
			{
				if(sBbuBtldStr.tnFlag.u16Bit.u1CmdF5 == 0)
				{
					memset((u8_t*)&tsBbuBt_Dev.tsBtCmdF5h.tnBtStatus.u16All, 0xFF, sizeof(sBtCmdF5h_t));
					sBbuBtldStr.tnFlag.u16Bit.u1CmdF5 = 1;
				}
				else if(sBbuBtldStr.tnFlag.u16Bit.u1CmdF5 == 1)
				{
					if(tsBbuBt_Dev.tsBtCmdF5h.tnBtStatus.u16Bit.u1ProcessFlag == 0)
					{
						sBbuBtldStr.tnFlag.u16Bit.u1CmdF5 = 0;
					}
				}
				blret = true;
			}
			break;
		case PMBusCmd_MFRSp38:	//read flash status
			if(u8len == 3)
			{
				if(sBbuBtldStr.tnFlag.u16Bit.u1CmdF6 == 0)
				{
					memset((u8_t*)&tsBbuBt_Dev.tsBtCmdF6h.tnBtStatus.u16All, 0xFF, sizeof(sBtCmdF6h_t));
					sBbuBtldStr.tnFlag.u16Bit.u1CmdF6 = 1;
				}
				else if(sBbuBtldStr.tnFlag.u16Bit.u1CmdF6 == 1)
				{
					if(tsBbuBt_Dev.tsBtCmdF6h.tnBtStatus.u16Bit.u1ProcessFlag == 0)
					{
						sBbuBtldStr.tnFlag.u16Bit.u1CmdF6 = 0;
					}
				}
				blret = true;
			}
			break;
		case PMBusCmd_MFRSp39:	//read file crc
			if(u8len == 9)
			{
				if(sBbuBtldStr.tnFlag.u16Bit.u1CmdF7 == 0)
				{
					memset((u8_t*)&tsBbuBt_Dev.tsBtCmdF7h.tnBtStatus.u16All, 0xFF, sizeof(sBtCmdF7h_t));
					sBbuBtldStr.tnFlag.u16Bit.u1CmdF7 = 1;
				}
				else if(sBbuBtldStr.tnFlag.u16Bit.u1CmdF7 == 1)
				{
					if(tsBbuBt_Dev.tsBtCmdF7h.tnBtStatus.u16Bit.u1ProcessFlag == 0)
					{
						sBbuBtldStr.tnFlag.u16Bit.u1CmdF7 = 0;
					}
				}
				blret = true;
			}
			break;

		default:

			break;
	}

	return blret;
}
#endif /* LITEON_BT */
/****************************************************************************
*	name        : IsBbuBtldBlockWrCmdSup
*	description :
*	return      : none
****************************************************************************/
#if (LITEON_BT)
bool IsBbuBtldBlockWrCmdSup(u8_t u8Cmd, u8_t u8len)
{
	bool blret = false;

	switch(u8Cmd)
	{

		case PMBusCmd_MFRSp35:	//write erase flash
			if(u8len == 11)
			{
				blret = true;
			}
			break;
		case PMBusCmd_MFRSp36:	//write program flash
			if(u8len > 7)
			{
				blret = true;
			}
			break;

		default:

			break;
	}

	return blret;
}
#endif /* LITEON_BT */
/****************************************************************************
*	name        : ParseBbuBtldWrCmdSup
*	description :
*	return      : none
****************************************************************************/
#if (LITEON_BT)
u8_t ParseBbuBtldWrCmdSup(u16_t u16Addr, u8_t u8CmdCode, u8_t* pu8buff, u8_t u8len)
{
	u8_t j;

	for(j=0; j<BBU_BL_PMBUS_RW_NUM; j++)
	{
		if (u8CmdCode == sBbuBLPMBusRWCmd[j].u8CmdCode)
		{
			sBbuBtldStr.u16WrCmdIndex = j;
			sBbuBtldStr.u8TempWrLen = u8len;
			sBbuBtldStr.u16TempAddr = u16Addr>>1;
			memcpy(sBbuBtldStr.pu8WrBuff, pu8buff, u8len);
			sBbuBtldStr.u8WrCmdProperty = PMBusCP_RdWr;
			sBbuBtldStr.tnFlag.u16Bit.u1ActivateBbuBtWrCmd = 1;

			return (PMBusCP_RdWr);
		}
	}

	for(j=0; j<BBU_BL_PMBUS_WO_NUM; j++)
	{
		if (u8CmdCode == sBbuBLPMBusWOCmd[j].u8CmdCode)
		{
			sBbuBtldStr.u16WrCmdIndex = j;
			sBbuBtldStr.u8TempWrLen = u8len;
			sBbuBtldStr.u16TempAddr = u16Addr>>1;
			memcpy(sBbuBtldStr.pu8WrBuff, pu8buff, u8len);
			sBbuBtldStr.u8WrCmdProperty = PMBusCP_WrOnly;
			sBbuBtldStr.tnFlag.u16Bit.u1ActivateBbuBtWrCmd = 1;

			return (PMBusCP_WrOnly);
		}
	}

	return (PMBusCP_NoSupp);
}
#endif /* LITEON_BT */
/****************************************************************************
*	name        : ParseBbuBtldRdCmdSup
*	description :
*	return      : none
****************************************************************************/
#if (LITEON_BT)
u8_t ParseBbuBtldRdCmdSup(u16_t u16Addr, u8_t u8CmdCode, u8_t* pu8tgtbuff, u8_t* pu8len)
{
	u8_t j;
	u8_t* pu8buff;

	for(j=0; j<BBU_BL_PMBUS_RW_NUM; j++)
	{
		if (u8CmdCode == sBbuBLPMBusRWCmd[j].u8CmdCode)
		{
			*pu8len = sBbuBLPMBusRWCmd[j].u8Len;
			pu8buff = sBbuBLPMBusRWCmd[j].pu8Buff;
			memcpy(pu8tgtbuff, pu8buff, *pu8len);
			return (PMBusCP_RdWr);

		}
	}

	return (PMBusCP_NoSupp);
}
#endif /* LITEON_BT */
/****************************************************************************
*	name        : ActivateBbuBtldLock
*	description :
*	return      : none
****************************************************************************/
#if (LITEON_BT)
void ActivateBbuBtldLock(u8_t u8Cmd)
{
	sBbuBtldStr.tnFlag.u16Bit.u1BbuBtLock = 1;
	sBbuBtldStr.u16LockTimeOutCnt = 0;
	if(u8Cmd == PMBusCmd_MFRSp36)
	{
		sBbuBtldStr.tnFlag.u16Bit.u1BbuBtDummyCmd = 0;
	}
	else
	{
		sBbuBtldStr.tnFlag.u16Bit.u1BbuBtDummyCmd = 1;
	}

}
#endif /* LITEON_BT */
/****************************************************************************
*	name        : BbuBtldLockTimeout
*	description :
*	return      : none
****************************************************************************/
#if (LITEON_BT)
void BbuBtldLockTimeout(void)
{
    if(u8BbuBtloader100msTimer != BbuBtloder100ms)
    {
    	u8BbuBtloader100msTimer = BbuBtloder100ms;

    	if(sBbuBtldStr.tnFlag.u16Bit.u1BbuBtLock)
    	{
    		sBbuBtldStr.u16LockTimeOutCnt += 1;
    		if(sBbuBtldStr.u16LockTimeOutCnt > 60)	//6sec
    		{
    			memset(&sBbuBtldStr, 0, sizeof(sBbuBtldStr));
    		}
    	}

    }

}
#endif /* LITEON_BT */

/****************************************************************************
*	name        : GetInVeBbuBtLock
*	description :
*	return      : none
****************************************************************************/
#if (BAIDU_BT)
u8_t  GetInVeBbuBtLock(void)
{
	if(sBbuBaiduBtStr.tnFlag.u16Bit.u2BtLock == 1)
	{
		return(1);
	}
	else if(sBbuBaiduBtStr.tnFlag.u16Bit.u2BtLock == 2)
	{
		return(2);
	}
	else
	{
		return(0);
	}
}
#endif /* BAIDU_BT */
/****************************************************************************
*	name        : InVeBbuBtLockTimeout
*	description :
*	return      : none
****************************************************************************/
#if (BAIDU_BT)
void InVeBbuBtLockTimeout(void)
{
    if(u8InVeBbuBt1msTimer != InVeBbuBt1ms)
    {
    	u8InVeBbuBt1msTimer = InVeBbuBt1ms;


    	if(sBbuBaiduBtStr.tnFlag.u16Bit.u2BtLock == 1)
    	{
    		sBbuBaiduBtStr.u16LockTimeOutCnt += 1;
    		if(sBbuBaiduBtStr.u16LockTimeOutCnt > sBbuBaiduBtStr.u16DummyRdLockTime1ms)	//
    		{
    			sBbuBaiduBtStr.u16LockTimeOutCnt = 0;
    			sBbuBaiduBtStr.tnFlag.u16Bit.u2BtLock = 2;
    		}
    	}
    	else if(sBbuBaiduBtStr.tnFlag.u16Bit.u2BtLock == 2)
    	{
    		sBbuBaiduBtStr.u16LockTimeOutCnt += 1;
    		if(sBbuBaiduBtStr.u16LockTimeOutCnt > sBbuBaiduBtStr.u16RdLockTime1ms)	//
    		{
    			sBbuBaiduBtStr.u16LockTimeOutCnt = 0;
    			sBbuBaiduBtStr.tnFlag.u16Bit.u2BtLock = 0;
    			//memset(&sBbuBaiduBtStr, 0, sizeof(sBbuBaiduBtStr));
    		}
    	}
    }
}
#endif /* BAIDU_BT */
/*******************************************************************************
*	brief 	handle the master PM Bus application
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
u8_t ParseBbuWrCmdPushWrData(u8_t u8DevIndex, u8_t u8CmdCode, u8_t* pu8buff, u8_t u8len)
{
	u8_t j, u8PushIndex;

	if(tPMBusPushWrStr.u8PushIndex < PMBUS_PUSH_WR_NUM)
	{
#if (MST_RD_SEQUENCE)
		for(j=0; j<BBU_PMBUS_RW_CFG_NUM; j++)
		{
			if (u8CmdCode == sBbuPMBusRWCmd_CFG[j].u8CmdCode)
			{
				u8PushIndex = tPMBusPushWrStr.u8PushIndex;

				tPMBusPushWrStr.sWrQueue_t[u8PushIndex].u8CmdCode = u8CmdCode;
				tPMBusPushWrStr.sWrQueue_t[u8PushIndex].u16WrCmdIndex = j;
				tPMBusPushWrStr.sWrQueue_t[u8PushIndex].u8TempWrLen = u8len;
				memcpy(tPMBusPushWrStr.sWrQueue_t[u8PushIndex].pu8WrBuff, pu8buff, u8len);
				tPMBusPushWrStr.sWrQueue_t[u8PushIndex].u8WrCmdProperty = PMBusCP_RdWr;
				tPMBusPushWrStr.sWrQueue_t[u8PushIndex].u8TempWrAddrIndex = u8DevIndex;

				tPMBusPushWrStr.u8PushIndex++;
				//sPMBusAppStruct.nStat.u16Bit.u1ActivateWrCmd = 1;

				//if(u8CmdCode == PMBusCmd_MFRSp30)
				//{
				//	TURN_TGL_MTEST();
				//}

				return (PMBusCP_RdWr);
			}
		}
#else
		for(j=0; j<BBU_PMBUS_RW_NUM; j++)
		{
			if (u8CmdCode == sBbuPMBusRWCmd[j].u8CmdCode)
			{
				u8PushIndex = tPMBusPushWrStr.u8PushIndex;

				tPMBusPushWrStr.sWrQueue_t[u8PushIndex].u8CmdCode = u8CmdCode;
				tPMBusPushWrStr.sWrQueue_t[u8PushIndex].u16WrCmdIndex = j;
				tPMBusPushWrStr.sWrQueue_t[u8PushIndex].u8TempWrLen = u8len;
				memcpy(tPMBusPushWrStr.sWrQueue_t[u8PushIndex].pu8WrBuff, pu8buff, u8len);
				tPMBusPushWrStr.sWrQueue_t[u8PushIndex].u8WrCmdProperty = PMBusCP_RdWr;
				tPMBusPushWrStr.sWrQueue_t[u8PushIndex].u8TempWrAddrIndex = u8DevIndex;

				tPMBusPushWrStr.u8PushIndex++;
				//sPMBusAppStruct.nStat.u16Bit.u1ActivateWrCmd = 1;

			//	TURN_TGL_MTEST();
				return (PMBusCP_RdWr);
			}
		}
#endif

#if (MST_RD_SEQUENCE)
		for(j=0; j<BBU_PMBUS_WO_CTR_NUM; j++)
		{
			if (u8CmdCode == sBbuPMBusWOCmd_CTR[j].u8CmdCode)
			{
				u8PushIndex = tPMBusPushWrStr.u8PushIndex;

				tPMBusPushWrStr.sWrQueue_t[u8PushIndex].u8CmdCode = u8CmdCode;
				tPMBusPushWrStr.sWrQueue_t[u8PushIndex].u16WrCmdIndex = j;
				tPMBusPushWrStr.sWrQueue_t[u8PushIndex].u8TempWrLen = u8len;
				memcpy(tPMBusPushWrStr.sWrQueue_t[u8PushIndex].pu8WrBuff, pu8buff, u8len);
				tPMBusPushWrStr.sWrQueue_t[u8PushIndex].u8WrCmdProperty = PMBusCP_WrOnly;
				tPMBusPushWrStr.sWrQueue_t[u8PushIndex].u8TempWrAddrIndex = u8DevIndex;

				tPMBusPushWrStr.u8PushIndex++;

				return (PMBusCP_WrOnly);
			}
		}
#else
		for(j=0; j<BBU_PMBUS_WO_NUM; j++)
		{
			if (u8CmdCode == sBbuPMBusWOCmd[j].u8CmdCode)
			{
				u8PushIndex = tPMBusPushWrStr.u8PushIndex;

				tPMBusPushWrStr.sWrQueue_t[u8PushIndex].u8CmdCode = u8CmdCode;
				tPMBusPushWrStr.sWrQueue_t[u8PushIndex].u16WrCmdIndex = j;
				tPMBusPushWrStr.sWrQueue_t[u8PushIndex].u8TempWrLen = u8len;
				memcpy(tPMBusPushWrStr.sWrQueue_t[u8PushIndex].pu8WrBuff, pu8buff, u8len);
				tPMBusPushWrStr.sWrQueue_t[u8PushIndex].u8WrCmdProperty = PMBusCP_WrOnly;
				tPMBusPushWrStr.sWrQueue_t[u8PushIndex].u8TempWrAddrIndex = u8DevIndex;

				tPMBusPushWrStr.u8PushIndex++;

				return (PMBusCP_WrOnly);
			}
		}
#endif

		return (PMBusCP_NoSupp);
	}
	else
	{
		return (PMBusCP_NoSupp);
	}


}
/****************************************************************************
*	name        : build_to_wrStruct
*	description :
*	return      : none
****************************************************************************/
void build_to_wrappStruct(void)
{
	sPMBusAppStruct.u16WrCmdIndex = sPMBusAppWrbackupStruct.u16WrCmdIndex;
	sPMBusAppStruct.u8TempWrLen = sPMBusAppWrbackupStruct.u8TempWrLen;
	memcpy(sPMBusAppStruct.pu8WrBuff, sPMBusAppWrbackupStruct.pu8WrBuff, sPMBusAppStruct.u8TempWrLen);
	sPMBusAppStruct.u8WrCmdProperty= sPMBusAppWrbackupStruct.u8WrCmdProperty;
	sDevStruct.u8TempWrAddrIndex = sPMBusAppWrbackupStruct.u8TempWrAddrIndex;
}
/****************************************************************************
*	name        : build_to_wrbackupStruct
*	description :
*	return      : none
****************************************************************************/
void build_to_wrbackupStruct(void)
{
	sPMBusAppWrbackupStruct.u16WrCmdIndex = sPMBusAppStruct.u16WrCmdIndex;
	sPMBusAppWrbackupStruct.u8TempWrLen = sPMBusAppStruct.u8TempWrLen;
	memcpy(sPMBusAppWrbackupStruct.pu8WrBuff, sPMBusAppStruct.pu8WrBuff, sPMBusAppWrbackupStruct.u8TempWrLen);
	sPMBusAppWrbackupStruct.u8WrCmdProperty= sPMBusAppStruct.u8WrCmdProperty;
	sPMBusAppWrbackupStruct.u8TempWrAddrIndex = sDevStruct.u8TempWrAddrIndex;
}
/****************************************************************************
*	name        : SlvPushReSendWriteProcess
*	description :
*	return      : none
****************************************************************************/
void SlvPushReSendWriteProcess(void)
{
	build_to_wrappStruct();
	sPMBusAppStruct.nStat.u16Bit.u1ActivateWrCmd = 1;
	sPMBusAppStruct.nStat.u16Bit.u1ReSendMasterWr = 0;
}
/****************************************************************************
*	name        : SlvPushWriteProcess
*	description :
*	return      : none
****************************************************************************/
void SlvPushWriteProcess(void)
{
	u8_t u8WriteIndex;

	if(tPMBusPushWrStr.u8PushIndex != tPMBusPushWrStr.u8WriteIndex)
	{
		u8WriteIndex = tPMBusPushWrStr.u8WriteIndex;

		sPMBusAppStruct.u16WrCmdIndex = tPMBusPushWrStr.sWrQueue_t[u8WriteIndex].u16WrCmdIndex;
		sPMBusAppStruct.u8TempWrLen = tPMBusPushWrStr.sWrQueue_t[u8WriteIndex].u8TempWrLen;
		memcpy(sPMBusAppStruct.pu8WrBuff, tPMBusPushWrStr.sWrQueue_t[u8WriteIndex].pu8WrBuff, sPMBusAppStruct.u8TempWrLen);
		sPMBusAppStruct.u8WrCmdProperty = tPMBusPushWrStr.sWrQueue_t[u8WriteIndex].u8WrCmdProperty;

		sDevStruct.u8TempWrAddrIndex = tPMBusPushWrStr.sWrQueue_t[u8WriteIndex].u8TempWrAddrIndex;

		build_to_wrbackupStruct();
		sPMBusAppStruct.nStat.u16Bit.u1ActivateWrCmd = 1;

		tPMBusPushWrStr.u8WriteIndex++;
		if(tPMBusPushWrStr.u8WriteIndex == tPMBusPushWrStr.u8PushIndex)
		{
			tPMBusPushWrStr.u8WriteIndex = 0;
			tPMBusPushWrStr.u8PushIndex = 0;

		}
	}
}
