/*
 * flash_driver.h
 *
 *  Created on: 2015/10/2
 *      Author: AllenCCLee
 */

#ifndef FLASH_DRIVER_H_
#define FLASH_DRIVER_H_

#include "fsl_device_registers.h"
#include "flash_status.h"

#define FLASH_VERIFY_LITEON	(0)
/****************************************************************************
*   Declared Macro
****************************************************************************/
/** flash base address */
#define PFLASH_BLOCK_BASE           0x1fc00
#define PFLASH_TOTAL_SIZE			(1*1024)
#define PFLASH_BLOCK_COUNT			(1)
#define PFLASH_BLOCK_SECTOR_SIZE	(1024)

#define PFLASH_ALIGMENT             (4)

//---------------------------------------------------------------------
/* flash commands of FCMD */
#define FTFA_VERIFY_SECTION             0x01U
#define FTFA_PROGRAM_CHECK              0x02U
#define FTFA_READ_RESOURCE              0x03U
#define FTFA_PROGRAM_LONGWORD           0x06U
#define FTFA_ERASE_SECTOR               0x09U
#define FTFA_VERIFY_ALL_BLOCK           0x40U
#define FTFA_READ_ONCE                  0x41U
#define FTFA_PROGRAM_ONCE               0x43U
#define FTFA_ERASE_ALL_BLOCK            0x44U
#define FTFA_SECURITY_BY_PASS           0x45U
//---------------------------------------------------------------------
/* Read/Write/Set/Clear Operation Macros */
#define GET_BIT_0_7(value)              ((uint8_t)((value) & 0xFFU))
#define GET_BIT_8_15(value)             ((uint8_t)(((value)>>8) & 0xFFU))
#define GET_BIT_16_23(value)            ((uint8_t)(((value)>>16) & 0xFFU))
#define GET_BIT_24_31(value)            ((uint8_t)((value)>>24))

#define ALIGN_DOWN(x, a)    ((x) & -(a))
#define ALIGN_UP(x, a)      (-(-(x) & -(a)))

/****************************************************************************
* Declare structure
****************************************************************************/
#pragma pack(1)
typedef struct _sflash_memory_t {
	u32_t u32PFlashBlockBase;           // Base address of the first PFlash block
	u32_t u32PFlashTotalSize;           // Size of all combined PFlash block
	u32_t u32PFlashBlockCount;          // Number of PFlash blocks
	u32_t u32PFlashSectorSize;          // Size in bytes of a sector of PFlash
	u8_t  u8PFlashMargin;              // The margin level setting for flash erase and program Verify CMDs


} sflash_memory_t;
#pragma pack()

/****************************************************************************
*   Declared Export functions
****************************************************************************/
extern void * gl_flashPtr;

extern flash_status_t flash_init(sflash_memory_t * tsdriver);

extern flash_status_t flash_read(u32_t u32addr, u32_t u32len, u8_t * pu8buffer);

extern flash_status_t flash_erase(u32_t u32startaddr, u32_t u32len);

extern flash_status_t flash_verify_erase(u32_t u32startaddr, u32_t u32len);

extern flash_status_t flash_program(uint32_t u32startaddr, uint8_t * pu8src, uint32_t u32lengthInBytes);

extern flash_status_t flash_verify_program(uint32_t u32startaddr, uint32_t u32lengthInBytes,
		uint8_t * pu8expectedData, uint32_t * u32failedAddress, uint32_t * u32failedData);
#endif /* FLASH_DRIVER_H_ */
