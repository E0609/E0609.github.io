/****************************************************************************
*	file	E2pI2cgpioApp.h
*	brief	include bbu_led
*
*	author allen.lee
* 	version 1.0
*		-	2014/05/05: initial version by allen lee
*
****************************************************************************/

#ifndef E2PI2CGPIOAPP_H_
#define E2PI2CGPIOAPP_H_

#include "define.h"
#include "SysTime.h"

/****************************************************************************
*   Declared Macro
****************************************************************************/
#define E2pi2cgpioTimeOut100ms          gtMcuTimer.u8Sys100ms
#define E2PI2CGPIO_TIMEOUT        		(5)	//100msx5
/****************************************************************************
* Declare structure
****************************************************************************/
#define EEPROM_M24C08
//#define EEPROM_M24C256
//#define EEPROM_AT24C04
//----------------------------------------------
#if defined(EEPROM_M24C08)
	#define E2P_MAX_WRITE_BYTES	16	//page write mode up to 16 bytes.
	#define E2P_MAX_READ_BYTES	1024	//the max read bytes once.
	#define E2P_MAX_BYTEADDR	1
	#define E2P_END_ADDRESS		0x03ff

#elif defined (EEPROM_AT24C04)
	#define E2P_MAX_WRITE_BYTES	16	//page write mode up to 16 bytes.
	#define E2P_MAX_READ_BYTES  512	//the max read bytes once.
	#define E2P_MAX_BYTEADDR	1
	#define E2P_END_ADDRESS		0x01ff

#elif defined (EEPROM_M24C256)
	#define E2P_MAX_WRITE_BYTES	64	//page write mode up to 64 bytes
	#define E2P_MAX_READ_BYTES	64	//the max read bytes once.
	#define E2P_MAX_BYTEADDR	2
	#define E2P_END_ADDRESS		0x7fff
#endif
//----------------------------------------------
#define E2P_DEV_ADDRESS		0xA0
//----------------------------------------------
#pragma pack(1)
typedef struct _sE2pi2cgpio_master_t {

	i8_t  i8status;
	u8_t  u8DevAddr;
	u8_t  u8addrlen, pu8ByteAddr[E2P_MAX_BYTEADDR];
	u8_t  *pu8WrBuff, *pu8RdBuff;
	u16_t u16wrlen, u16rdlen;
    u8_t  u8timeout_ms;

} sE2pi2cgpio_master_t;
#pragma pack()
//----------------------------------------------

typedef enum _E2pi2cgpio_retstatus_t {

	E2pi2cgpio_Transmited_TooManyBytes = -8,
	E2pi2cgpio_Transmited_NotEnoughBytes = -7,
	E2pi2cgpio_Transmited_DeviecError = -6,
	E2pi2cgpio_Transmited_DataError = -5,

	E2pi2cgpio_Received_TooManyBytes = -4,
	E2pi2cgpio_Received_NotEnoughBytes = -3,
	E2pi2cgpio_Received_DeviecError = -2,
	E2pi2cgpio_Received_DataError = -1,

	E2pi2cgpio_Idle = 0,

} E2pi2cgpio_retstatus_t;
//----------------------------------------------
/****************************************************************************
*   Declared Export functions
****************************************************************************/
extern i8_t E2pi2cgpio_Status(void);
extern i8_t E2pi2cgpio_writebytes(u16_t u16addr, u8_t u8addrLen, u16_t u16wrLen, u8_t *pu8Buff);
extern i8_t E2pi2cgpio_readbytes(u16_t u16addr, u8_t u8addrLen, u16_t u16rdLen, u8_t *pu8Buff);
extern void Init_E2pi2cgpio(void);
extern void E2pi2cgpio_reset(void);
//extern void E2pi2cgpioProcess(void);

#endif /* E2PI2CGPIOAPP_H_ */
