/****************************************************************************
*	file	flash_status.h
*	brief	include flash driver
*
*	author allen.lee
* 	version 1.0
*		-	2015/10/01: initial version by allen lee
*
****************************************************************************/

#ifndef FLASH_STATUS_H_
#define FLASH_STATUS_H_

#include "define.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/
/*! @brief FLASH status return codes.*/
typedef enum _flash_status {
	kStatus_FLASH_Success         = 0x0U,
	kStatus_FLASH_Fail            = 0x1U,
	kStatus_FLASH_ReadOnly        = 0x2U,
	kStatus_FLASH_OutOfRange      = 0x3U,
	kStatus_FLASH_InvalidArgument = 0x4U,
	kStatus_FLASH_Timeout         = 0x5U,

	kStatus_FLASH_SizeError       = 100,
	kStatus_FLASH_AlignmentError  = 101,
	kStatus_FLASH_AddressError    = 102,
	kStatus_FLASH_AccessError     		= 103,
	kStatus_FLASH_ProtectionViolation	= 104,
	kStatus_FLASH_CommandFailure     	= 105,

} flash_status_t;
//---------------------------------------------------------------------
typedef enum _flash_margin_value {
    kMargin_FLASH_Normal = 0x0U,
    kMargin_FLASH_User,
    kMargin_FLASH_Factory,
    kMargin_FLASH_Invalid

} flash_margin_value_t;


#endif /* FLASH_STATUS_H_ */
