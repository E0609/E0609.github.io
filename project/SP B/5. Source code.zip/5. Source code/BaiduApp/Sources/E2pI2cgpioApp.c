/****************************************************************************
*	file	E2pI2cgpioApp.c
*	brief
*
*	author allen.lee
* 	version 1.0
*		-	2014/05/05: initial version by allen lee
*
****************************************************************************/
#include <string.h>
#include "board.h"
#include "i2cgpio_master.h"
#include "E2pI2cgpioApp.h"

/****************************************************************************
 * Global Variables
 ****************************************************************************/
static sE2pi2cgpio_master_t tE2pi2cgpio;
u8_t u8E2pi2cgpioTimeoutTimer;

/****************************************************************************
*	name        : E2pi2cgpio_Status
*	description :
*	return      : none
****************************************************************************/
i8_t E2pi2cgpio_Status(void)
{
	return(tE2pi2cgpio.i8status);
}
/****************************************************************************
*	name        : E2pi2cgpio_writebytes
*	description :
*	return      : none
****************************************************************************/
i8_t E2pi2cgpio_writebytes(u16_t u16addr, u8_t u8addrLen, u16_t u16wrLen, u8_t *pu8Buff)
{
	u8_t *pu8tempByteAddr, *pu8tempAddr;

	i16_t i16ret;

	if((u8addrLen == 0) || (u16wrLen == 0))
	{
		return(E2pi2cgpio_Transmited_NotEnoughBytes);
	}

	if((u8addrLen > E2P_MAX_BYTEADDR) || (u16wrLen > E2P_MAX_WRITE_BYTES) || ((u16addr+u16wrLen) > E2P_END_ADDRESS))
	{
		return(E2pi2cgpio_Transmited_TooManyBytes);
	}

	tE2pi2cgpio.u8DevAddr = E2P_DEV_ADDRESS;

	pu8tempByteAddr = &tE2pi2cgpio.pu8ByteAddr[0];
	pu8tempAddr = (u8_t *)&u16addr;
	pu8tempAddr = pu8tempAddr + u8addrLen - 1;

	tE2pi2cgpio.u8addrlen = u8addrLen;
    while(u8addrLen--)
    {
        *pu8tempByteAddr = *pu8tempAddr;
        pu8tempByteAddr++;
        pu8tempAddr--;
    }

	tE2pi2cgpio.u16wrlen = u16wrLen;
	tE2pi2cgpio.pu8WrBuff = pu8Buff;

	i2c_gpio_start();

	//device write address
	i16ret = i2c_gpio_sendbytes(1, &tE2pi2cgpio.u8DevAddr);
	if(i16ret < 0)
	{
		i2c_gpio_stop();
		return(E2pi2cgpio_Transmited_DeviecError);
	}

	//word address
	i16ret = i2c_gpio_sendbytes(tE2pi2cgpio.u8addrlen, tE2pi2cgpio.pu8ByteAddr);
	if(i16ret < 0)
	{
		i2c_gpio_stop();
		return(E2pi2cgpio_Transmited_DataError);
	}

	//data
	i16ret = i2c_gpio_sendbytes(tE2pi2cgpio.u16wrlen, tE2pi2cgpio.pu8WrBuff);
	if(i16ret < 0)
	{
		i2c_gpio_stop();
		return(E2pi2cgpio_Transmited_DataError);
	}

	i2c_gpio_stop();
	return(E2pi2cgpio_Idle);

}
/****************************************************************************
*	name        : E2pi2cgpio_readbytes
*	description :
*	return      : none
****************************************************************************/
i8_t E2pi2cgpio_readbytes(u16_t u16addr, u8_t u8addrLen, u16_t u16rdLen, u8_t *pu8Buff)
{
	u8_t *pu8tempByteAddr, *pu8tempAddr;

	i16_t i16ret;

	if((u8addrLen == 0) || (u16rdLen == 0))
	{
		return(E2pi2cgpio_Received_NotEnoughBytes);
	}

	if((u8addrLen > E2P_MAX_BYTEADDR) || (u16rdLen > E2P_MAX_READ_BYTES) || ((u16addr+u16rdLen) > E2P_END_ADDRESS))
	{
		return(E2pi2cgpio_Received_TooManyBytes);
	}

	tE2pi2cgpio.u8DevAddr = E2P_DEV_ADDRESS;

	pu8tempByteAddr = &tE2pi2cgpio.pu8ByteAddr[0];
	pu8tempAddr = (u8_t *)&u16addr;
	pu8tempAddr = pu8tempAddr + u8addrLen - 1;

	tE2pi2cgpio.u8addrlen = u8addrLen;
    while(u8addrLen--)
    {
        *pu8tempByteAddr = *pu8tempAddr;
        pu8tempByteAddr++;
        pu8tempAddr--;
    }

    tE2pi2cgpio.u16rdlen = u16rdLen;
    tE2pi2cgpio.pu8RdBuff = pu8Buff;

	i2c_gpio_start();

	//device write address
	i16ret = i2c_gpio_sendbytes(1, &tE2pi2cgpio.u8DevAddr);
	if(i16ret < 0)
	{
		i2c_gpio_stop();
		return(E2pi2cgpio_Transmited_DeviecError);
	}

	//word address
	i16ret = i2c_gpio_sendbytes(tE2pi2cgpio.u8addrlen, tE2pi2cgpio.pu8ByteAddr);
	if(i16ret < 0)
	{
		i2c_gpio_stop();
		return(E2pi2cgpio_Transmited_DataError);
	}

	i2c_gpio_repstart();

	//device read address
	tE2pi2cgpio.u8DevAddr |= 0x01;
	i16ret = i2c_gpio_sendbytes(1, &tE2pi2cgpio.u8DevAddr);
	if(i16ret < 0)
	{
		i2c_gpio_stop();
		return(E2pi2cgpio_Received_DeviecError);
	}

	i16ret = i2c_gpio_readbytes(u16rdLen, tE2pi2cgpio.pu8RdBuff);
	if(i16ret < 0)
	{
		i2c_gpio_stop();
		return(E2pi2cgpio_Received_DataError);
	}

	i2c_gpio_stop();
	return(E2pi2cgpio_Idle);

}

/****************************************************************************
*	name        : Init_E2pi2cgpio
*	description :
*	return      : none
****************************************************************************/
void Init_E2pi2cgpio(void)
{
	Init_I2cGpioMaster();

	tE2pi2cgpio.i8status = E2pi2cgpio_Idle;
	tE2pi2cgpio.u8timeout_ms = 0;
}
/****************************************************************************
*	name        : E2pi2cgpio_reset
*	description :
*	return      : none
****************************************************************************/
void E2pi2cgpio_reset(void)
{
	if(u8E2pi2cgpioTimeoutTimer != E2pi2cgpioTimeOut100ms)
	{
		u8E2pi2cgpioTimeoutTimer = E2pi2cgpioTimeOut100ms;

		if(E2pi2cgpio_Status() != E2pi2cgpio_Idle)
		{
			tE2pi2cgpio.u8timeout_ms += 1;
			if(tE2pi2cgpio.u8timeout_ms > E2PI2CGPIO_TIMEOUT)
			{
				Init_E2pi2cgpio();
			}
		}
	}
}

/****************************************************************************
*	name        : E2pi2cgpioProcess
*	description :
*	return      : none
****************************************************************************/
/*void E2pi2cgpioProcess(void)
{
	u8_t u8len, u8addrlen;
	u8_t pu8buff[10];
	u16_t u16addr;

	u8addrlen = 1;
	u16addr = 0x00;
	u8len = 2;
	pu8buff[0] = 0x01;
	pu8buff[1] = 0x02;
	E2pi2cgpio_writebytes(u16addr, u8addrlen, u8len, pu8buff);

	I2C_BITBANG_DELAY();
	I2C_BITBANG_DELAY();
	I2C_BITBANG_DELAY();
	I2C_BITBANG_DELAY();
	I2C_BITBANG_DELAY();
	I2C_BITBANG_DELAY();
	I2C_BITBANG_DELAY();
	I2C_BITBANG_DELAY();
	I2C_BITBANG_DELAY();
	I2C_BITBANG_DELAY();
	I2C_BITBANG_DELAY();
	I2C_BITBANG_DELAY();
	pu8buff[0] = 0xff;
	pu8buff[1] = 0xff;

	E2pi2cgpio_readbytes(u16addr, u8addrlen, u8len, pu8buff);

	I2C_BITBANG_DELAY();
	I2C_BITBANG_DELAY();
	I2C_BITBANG_DELAY();
	I2C_BITBANG_DELAY();
	I2C_BITBANG_DELAY();
	I2C_BITBANG_DELAY();
	I2C_BITBANG_DELAY();
	I2C_BITBANG_DELAY();
	I2C_BITBANG_DELAY();
	I2C_BITBANG_DELAY();
	I2C_BITBANG_DELAY();
	I2C_BITBANG_DELAY();

	u8addrlen = 1;
	u16addr = 0x02;
	u8len = 2;
	pu8buff[0] = 0x03;
	pu8buff[1] = 0x04;
	E2pi2cgpio_writebytes(u16addr, u8addrlen, u8len, pu8buff);

	I2C_BITBANG_DELAY();
	I2C_BITBANG_DELAY();
	I2C_BITBANG_DELAY();
	I2C_BITBANG_DELAY();
	I2C_BITBANG_DELAY();
	I2C_BITBANG_DELAY();
	I2C_BITBANG_DELAY();
	I2C_BITBANG_DELAY();
	I2C_BITBANG_DELAY();
	I2C_BITBANG_DELAY();
	I2C_BITBANG_DELAY();
	I2C_BITBANG_DELAY();

	u8addrlen = 1;
	u16addr = 0x00;
	u8len = 4;
	pu8buff[0] = 0xff;
	pu8buff[1] = 0xff;
	pu8buff[2] = 0xff;
	pu8buff[3] = 0xff;
	E2pi2cgpio_readbytes(u16addr, u8addrlen, u8len, pu8buff);
	I2C_BITBANG_DELAY();
	I2C_BITBANG_DELAY();

}
*/
void E2pi2cgpioProcess(void)
{

}


