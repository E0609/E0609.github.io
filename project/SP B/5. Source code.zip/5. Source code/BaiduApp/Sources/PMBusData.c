/****************************************************************************
*	file	MstPMBusData.c
*	brief	The file includes the function and data structure/variables
*		    for the PMBus protocol
*	author allen.lee
* 	version 1.0
*		-	2015/05/11: initial version by allen lee
*
****************************************************************************/
#include <stddef.h>
#include <string.h>
#include "PMBusData.h"
#include "MstPMBusApp.h"
#include "bsc.h"
#include "macro_define.h"

/****************************************************************************
*   Declared Macro
****************************************************************************/
sBBUCmd_t tsBBU_Dev[BBU_DEV_NUM];
sBSCCmd_t tsBSC_Dev;
sBbuBtCmd_t tsBbuBt_Dev;

#if (BAIDU_BT)
u8_t u8DummyRdBtStatus;
#endif

void MstCmdRdCpy(u8_t* pu8SrcBuf, u8_t* pu8TgtBuf, u16_t u16Len);
void MstCmdWrCpy(u8_t* pu8src, u8_t* pu8dset, u16_t u16Len);

/****************************************************************************
* declare the BBU PMBus commands which is modified by user
****************************************************************************/
sPMBusCmdStr_t sBbuPMBusROCmd_STA[BBU_PMBUS_RO_STA_NUM] =
{
  /*|cmd code|      			|cmd type|			|data type|		  |len| 	|pbuff|                     			|funcptr|*/
    {PMBusCmd_StatusByte,	PMBusCT_RdnBytes,	PMBusDT_NN_Block, 	1,	&tsBBU_Dev[0].tnStatusByte.u8All,			&MstCmdRdCpy},
	{PMBusCmd_StatusWord,	PMBusCT_RdnBytes,	PMBusDT_NN_Block, 	2,	(u8_t*)&tsBBU_Dev[0].tnStatusWord.u16All,	&MstCmdRdCpy},
	{PMBusCmd_StatusVout,	PMBusCT_RdnBytes,	PMBusDT_NN_Block, 	1,	&tsBBU_Dev[0].tnStatusVout.u8All,		&MstCmdRdCpy},
	{PMBusCmd_StatusIout,	PMBusCT_RdnBytes,	PMBusDT_NN_Block, 	1,	&tsBBU_Dev[0].tnStatusIout.u8All,		&MstCmdRdCpy},
	{PMBusCmd_StatusInput,	PMBusCT_RdnBytes,	PMBusDT_NN_Block, 	1,	&tsBBU_Dev[0].tnStatusInput.u8All,		&MstCmdRdCpy},
	{PMBusCmd_StatusTemp,	PMBusCT_RdnBytes,	PMBusDT_NN_Block, 	1,	&tsBBU_Dev[0].tnStatusTemp.u8All,		&MstCmdRdCpy},
	{PMBusCmd_StatusCML,	PMBusCT_RdnBytes,	PMBusDT_NN_Block, 	1,	&tsBBU_Dev[0].tnStatusCML.u8All,		&MstCmdRdCpy},
	{PMBusCmd_MFRSp0,		PMBusCT_RdnBytes,	PMBusDT_NN_Block, 	1,	&tsBBU_Dev[0].tnStatusBBU.u8All,		&MstCmdRdCpy},
	{PMBusCmd_MFRSp1,		PMBusCT_RdnBytes,	PMBusDT_NN_Block,	2,	(u8_t*)&tsBBU_Dev[0].tnStateBBU.u16All,		&MstCmdRdCpy},
	{PMBusCmd_MFRSp13,		PMBusCT_RdnBytes,	PMBusDT_NN_Block, 	2,	(u8_t*)&tsBBU_Dev[0].u16BattStatus,			&MstCmdRdCpy},
	{PMBusCmd_MFRSp14,		PMBusCT_RdnBytes,	PMBusDT_NN_Block, 	2,	(u8_t*)&tsBBU_Dev[0].u16BattProcStatus,		&MstCmdRdCpy},
	{PMBusCmd_MFRSp15,		PMBusCT_RdnBytes,	PMBusDT_NN_Block, 	2,	(u8_t*)&tsBBU_Dev[0].u16BattPfStatus,		&MstCmdRdCpy},
	{PMBusCmd_MFRSp21,  	PMBusCT_BlockRd,	PMBusDT_NN_Block, 	4,	(u8_t*)&tsBBU_Dev[0].pu32BBUProtectType,	&MstCmdRdCpy},
#if(BAIDU_BT)
	{PMBusCmd_MFRSp33,		PMBusCT_RdnBytes,	PMBusDT_NN_Block,   1,	&tsBBU_Dev[0].u8BtStatus,		        &MstCmdRdCpy},
#endif
};

sPMBusCmdStr_t sBbuPMBusROCmd_MST[BBU_PMBUS_RO_MST_NUM] =
{
  /*|cmd code|      			|cmd type|			|data type|		  |len| 	|pbuff|                     			|funcptr|*/
    {PMBusCmd_RdVin,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16ReadVin,		&MstCmdRdCpy},
	{PMBusCmd_RdIin,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16ReadIin,		&MstCmdRdCpy},
	{PMBusCmd_RdVout,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16ReadVout,		&MstCmdRdCpy},
	{PMBusCmd_RdIout,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16ReadIout,		&MstCmdRdCpy},
	{PMBusCmd_RdTemp1,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16ReadTemp1,		&MstCmdRdCpy},
	{PMBusCmd_RdTemp2,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16ReadTemp2,		&MstCmdRdCpy},
	{PMBusCmd_RdTemp3,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16ReadTemp3,		&MstCmdRdCpy},
    {PMBusCmd_RdPout,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16ReadPout,		&MstCmdRdCpy},
	{PMBusCmd_RdPin,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16ReadPin,		&MstCmdRdCpy},
	{PMBusCmd_MFRSp4,		PMBusCT_RdnBytes,		PMBusDT_Linear,	   	2,	(u8_t*)&tsBBU_Dev[0].u16BattVolt,	    &MstCmdRdCpy},
    {PMBusCmd_MFRSp6,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16BattCurr,		&MstCmdRdCpy},
    {PMBusCmd_MFRSp7,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16BattASOC,		&MstCmdRdCpy},
	{PMBusCmd_MFRSp9,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16BattRSOC,			&MstCmdRdCpy},
	{PMBusCmd_MFRSp10,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16BattCapacity,		&MstCmdRdCpy},
	{PMBusCmd_MFRSp19,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16BattTemp,			&MstCmdRdCpy},
	{PMBusCmd_MFRSp25,		PMBusCT_RdnBytes,		PMBusDT_Linear, 	2,	(u8_t*)&tsBBU_Dev[0].u16DischrgRemainTime,	&MstCmdRdCpy},
};

sPMBusCmdStr_t sBbuPMBusROCmd_INF[BBU_PMBUS_RO_INF_NUM] =
{
  /*|cmd code|      			|cmd type|			|data type|		  |len| 	|pbuff|                     			|funcptr|*/
    {PMBusCmd_OnOffConf,		PMBusCT_RdnBytes,		PMBusDT_NN_Block,	1,	&tsBBU_Dev[0].u8OnOffConfig,			&MstCmdRdCpy},
    {PMBusCmd_Capability,		PMBusCT_RdnBytes,	    PMBusDT_NN_Block,   1,	&tsBBU_Dev[0].tnCapability.u8All,		&MstCmdRdCpy},
    {PMBusCmd_Query,			PMBusCT_BWrBRdProCall,	PMBusDT_NN_Block,   1,	&tsBBU_Dev[0].tnPMBusQuerry.u8All,	&MstCmdRdCpy},
    {PMBusCmd_VoutMode,			PMBusCT_RdnBytes,		PMBusDT_NN_Block,	1,	&tsBBU_Dev[0].u8VoutMode,				&MstCmdRdCpy},
	{PMBusCmd_VoutOVFaultResp,	PMBusCT_RdnBytes,		PMBusDT_NN_Block,	1,	&tsBBU_Dev[0].u8VoutOVFaultResp,		&MstCmdRdCpy},
	{PMBusCmd_VoutUVFaultResp,	PMBusCT_RdnBytes,		PMBusDT_NN_Block,	1,	&tsBBU_Dev[0].u8VoutUVFaultResp,		&MstCmdRdCpy},
    {PMBusCmd_IoutOCFaultResp,	PMBusCT_RdnBytes,		PMBusDT_NN_Block,	1,	&tsBBU_Dev[0].u8IoutOCFaultResp,		&MstCmdRdCpy},
	{PMBusCmd_OTFaultResp,		PMBusCT_RdnBytes,		PMBusDT_NN_Block,	1,	&tsBBU_Dev[0].u8OTFaultResp,			&MstCmdRdCpy},
	{PMBusCmd_VinOVFaultResp,	PMBusCT_RdnBytes,		PMBusDT_NN_Block,	1,	&tsBBU_Dev[0].u8VinOVFaultResp,			&MstCmdRdCpy},
	{PMBusCmd_VinUVFaultResp,	PMBusCT_RdnBytes,		PMBusDT_NN_Block,	1,	&tsBBU_Dev[0].u8VinUVFaultResp,			&MstCmdRdCpy},
	{PMBusCmd_IinOCFaultResp,	PMBusCT_RdnBytes,		PMBusDT_NN_Block,	1,	&tsBBU_Dev[0].u8IinOCFaultResp,			&MstCmdRdCpy},
	{PMBusCmd_RMBusRev,			PMBusCT_RdnBytes,		PMBusDT_NN_Block,	1,	&tsBBU_Dev[0].tnPMBusRev.u8All,			&MstCmdRdCpy},
	{PMBusCmd_MFRVinMin,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16MFRVinMin,		&MstCmdRdCpy},
	{PMBusCmd_MFRVinMax,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16MFRVinMax,		&MstCmdRdCpy},
	{PMBusCmd_MFRIinMax,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16MFRIinMax,		&MstCmdRdCpy},
	{PMBusCmd_MFRPinMax,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16MFRPinMax,		&MstCmdRdCpy},
	{PMBusCmd_MFRVoutMin,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16MFRVoutMin,		&MstCmdRdCpy},
	{PMBusCmd_MFRVoutMax,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16MFRVoutMax,		&MstCmdRdCpy},
	{PMBusCmd_MFRIoutMax,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16MFRIoutMax,		&MstCmdRdCpy},
	{PMBusCmd_MFRPoutMax,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16MFRPoutMax,		&MstCmdRdCpy},
	{PMBusCmd_MFRAmbTMax,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16MFRAmbTMax,		&MstCmdRdCpy},
	{PMBusCmd_MFRAmbTMin,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16MFRAmbTMin,		&MstCmdRdCpy},
	{PMBusCmd_MFRMaxTemp1,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16MFRMaxTemp1,	&MstCmdRdCpy},
	{PMBusCmd_MFRMaxTemp2,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16MFRMaxTemp2,	&MstCmdRdCpy},
	{PMBusCmd_MFRSp8,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16BattCycCntOffset,	&MstCmdRdCpy},
	{PMBusCmd_MFRSp11,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16BattCycCnt,			&MstCmdRdCpy},
	{PMBusCmd_MFRSp12,		PMBusCT_BlockRd,		PMBusDT_NN_Block,	4,	(u8_t*)&tsBBU_Dev[0].u32BattRunTime,		&MstCmdRdCpy},
	{PMBusCmd_MFRSp23,		PMBusCT_BlockRd,		PMBusDT_NN_Block, 	4,	&tsBBU_Dev[0].u8LastProtect[0],	            &MstCmdRdCpy},
	{PMBusCmd_MFRSp24,		PMBusCT_RdnBytes,		PMBusDT_Linear, 	2,	(u8_t*)&tsBBU_Dev[0].u16BattSOH,			&MstCmdRdCpy},
	{PMBusCmd_MFRSp26,		PMBusCT_BlockRd,		PMBusDT_NN_Block,	28,	&tsBBU_Dev[0].u8CellVoltMinHistory[0],		&MstCmdRdCpy},
	{PMBusCmd_MFRSp28,		PMBusCT_RdnBytes,		PMBusDT_Linear, 	2,	(u8_t*)&tsBBU_Dev[0].u16FullyChrgCapacity,	&MstCmdRdCpy},
	//{PMBusCmd_MFRSp30,		PMBusCT_RdnBytes,		PMBusDT_NN_Block,	2,	(u8_t*)&tsBBU_Dev[0].u16BbuIntCtrl,		    &MstCmdRdCpy}

};

sPMBusCmdStr_t sBbuPMBusROCmd_MFC[BBU_PMBUS_RO_MFC_NUM] =
{
  /*|cmd code|      			|cmd type|			|data type|		  |len| 	|pbuff|                     			|funcptr|*/
    {PMBusCmd_UsrData12,  	PMBusCT_BlockRd,		PMBusDT_NN_Block, 	15,	&tsBBU_Dev[0].pu8PackMFT[0],			&MstCmdRdCpy},
	{PMBusCmd_UsrData13,  	PMBusCT_BlockRd,		PMBusDT_NN_Block, 	15,	&tsBBU_Dev[0].pu8CellMFT[0],			&MstCmdRdCpy},
	{PMBusCmd_UsrData14,  	PMBusCT_BlockRd,		PMBusDT_NN_Block, 	15,	&tsBBU_Dev[0].pu8CellModel[0],			&MstCmdRdCpy},
	{PMBusCmd_MFRSp3,		PMBusCT_RdnBytes,		PMBusDT_NN_Block, 	2,	&tsBBU_Dev[0].pu8BattPackSN[0],			&MstCmdRdCpy},
    {PMBusCmd_MFRSp5,	    PMBusCT_BlockRd,        PMBusDT_NN_Block, 	11,	&tsBBU_Dev[0].pu8BmsHwFwCompCode[0],	&MstCmdRdCpy},
	{PMBusCmd_MFRSp27,		PMBusCT_RdnBytes,		PMBusDT_NN_Block, 	2,	(u8_t*)&tsBBU_Dev[0].u16BMSFWRevision,	&MstCmdRdCpy},
    {PMBusCmd_MFRSp44,	    PMBusCT_BlockRd,        PMBusDT_NN_Block, 	11,	&tsBBU_Dev[0].pu8BbuHwFwCompCode[0],	&MstCmdRdCpy},
	{PMBusCmd_MFRSp45, 		PMBusCT_BlockRd,		PMBusDT_NN_Block, 	16,	&tsBBU_Dev[0].pu8Protocol[0],			&MstCmdRdCpy}

};

sPMBusCmdStr_t sBbuPMBusRWCmd_CFG[BBU_PMBUS_RW_CFG_NUM] =
{
  /*|cmd code|      			|cmd type|			|data type|		  |len| 	|pbuff|                     			|funcptr|*/
    {PMBusCmd_Page,				PMBusCT_RdWrnBytes,		PMBusDT_u8,	  	  	   1,	&tsBBU_Dev[0].u8CurrPage,				&MstCmdRdCpy},
	{PMBusCmd_Operation,		PMBusCT_RdWrnBytes,		PMBusDT_NN_Block,	   1,	&tsBBU_Dev[0].u8Operation,				&MstCmdRdCpy},
	{PMBusCmd_WriteProt,		PMBusCT_RdWrnBytes,		PMBusDT_NN_Block,	   1,	&tsBBU_Dev[0].u8WriteProtect,			&MstCmdRdCpy},
    {PMBusCmd_VoutOVFaultLimit,	PMBusCT_RdWrnBytes,		PMBusDT_Linear,   	   2,	(u8_t*)&tsBBU_Dev[0].u16VoutOVFaultL,	&MstCmdRdCpy},
    {PMBusCmd_VoutOVWarnLimit,	PMBusCT_RdWrnBytes,		PMBusDT_Linear,   	   2,	(u8_t*)&tsBBU_Dev[0].u16VoutOVWarnL,	&MstCmdRdCpy},
    {PMBusCmd_VoutUVWarnLimit,	PMBusCT_RdWrnBytes,		PMBusDT_Linear,   	   2,	(u8_t*)&tsBBU_Dev[0].u16VoutUVWarnL,	&MstCmdRdCpy},
    {PMBusCmd_VoutUVFaultLimit,	PMBusCT_RdWrnBytes,		PMBusDT_Linear,   	   2,	(u8_t*)&tsBBU_Dev[0].u16VoutUVFaultL,	&MstCmdRdCpy},
    {PMBusCmd_IoutOCFaultLimit,	PMBusCT_RdWrnBytes,		PMBusDT_Linear,   	   2,	(u8_t*)&tsBBU_Dev[0].u16IoutOCFaultL,	&MstCmdRdCpy},
    {PMBusCmd_IoutOCWarnLimit,	PMBusCT_RdWrnBytes,		PMBusDT_Linear,   	   2,	(u8_t*)&tsBBU_Dev[0].u16IoutOCWarnL,	&MstCmdRdCpy},
    {PMBusCmd_OTFaultLimit,	    PMBusCT_RdWrnBytes,		PMBusDT_Linear,   	   2,	(u8_t*)&tsBBU_Dev[0].u16OTFaultL,	    &MstCmdRdCpy},
    {PMBusCmd_OTWarnLimit,	    PMBusCT_RdWrnBytes,		PMBusDT_Linear,   	   2,	(u8_t*)&tsBBU_Dev[0].u16OTWarnL,		&MstCmdRdCpy},
    {PMBusCmd_VinOVFaultLimit,	PMBusCT_RdWrnBytes,		PMBusDT_Linear,   	   2,	(u8_t*)&tsBBU_Dev[0].u16VinOVFaultL,	&MstCmdRdCpy},
    {PMBusCmd_VinOVWarnLimit,	PMBusCT_RdWrnBytes,		PMBusDT_Linear,   	   2,	(u8_t*)&tsBBU_Dev[0].u16VinOVWarnL,		&MstCmdRdCpy},
    {PMBusCmd_VinUVWarnLimit,	PMBusCT_RdWrnBytes,		PMBusDT_Linear,   	   2,	(u8_t*)&tsBBU_Dev[0].u16VinUVWarnL,		&MstCmdRdCpy},
    {PMBusCmd_VinUVFaultLimit,	PMBusCT_RdWrnBytes,		PMBusDT_Linear,   	   2,	(u8_t*)&tsBBU_Dev[0].u16VinUVFaultL,	&MstCmdRdCpy},
    {PMBusCmd_IinOCFaultLimit,	PMBusCT_RdWrnBytes,		PMBusDT_Linear,   	   2,	(u8_t*)&tsBBU_Dev[0].u16IinOCFaultL,	&MstCmdRdCpy},
    {PMBusCmd_IinOCWarnLimit,	PMBusCT_RdWrnBytes,		PMBusDT_Linear,   	   2,	(u8_t*)&tsBBU_Dev[0].u16IinOCWarnL,		&MstCmdRdCpy},
    {PMBusCmd_POutOPFaultLimit,	PMBusCT_RdWrnBytes,		PMBusDT_Linear,   	   2,	(u8_t*)&tsBBU_Dev[0].u16POutOPFaultL,	&MstCmdRdCpy},
    {PMBusCmd_POutOPWarnLimit,	PMBusCT_RdWrnBytes,		PMBusDT_Linear,   	   2,	(u8_t*)&tsBBU_Dev[0].u16PoutOPWarnL,	&MstCmdRdCpy},
    {PMBusCmd_PInOPWarnLimit,	PMBusCT_RdWrnBytes,		PMBusDT_Linear,   	   2,	(u8_t*)&tsBBU_Dev[0].u16PinOPWarnL,		&MstCmdRdCpy},
    {PMBusCmd_MFRID,	   		PMBusCT_BlockRdWr,      PMBusDT_NN_Block, 	   10,	&tsBBU_Dev[0].pu8MFRID[0],				&MstCmdRdCpy},
    {PMBusCmd_MFRModel,	   		PMBusCT_BlockRdWr,      PMBusDT_NN_Block, 	   11,	&tsBBU_Dev[0].pu8MFRModel[0],			&MstCmdRdCpy},
    {PMBusCmd_MFRRev,	   		PMBusCT_BlockRdWr,      PMBusDT_NN_Block, 	   10,	&tsBBU_Dev[0].pu8MFRRev[0],				&MstCmdRdCpy},
 	{PMBusCmd_MFRLocation, 		PMBusCT_BlockRdWr,      PMBusDT_NN_Block, 	   10,	&tsBBU_Dev[0].pu8MFRLoc[0],				&MstCmdRdCpy},
    {PMBusCmd_MFRDate,	   		PMBusCT_BlockRdWr,      PMBusDT_NN_Block, 	   10,	&tsBBU_Dev[0].pu8MFRDate[0],			&MstCmdRdCpy},
    {PMBusCmd_MFRSerial,   		PMBusCT_BlockRdWr,      PMBusDT_NN_Block, 	   15,	&tsBBU_Dev[0].pu8MFRSerial[0],			&MstCmdRdCpy},
    {PMBusCmd_UsrData0,			PMBusCT_RdWrnBytes,		PMBusDT_Linear,	  	   2,	(u8_t*)&tsBBU_Dev[0].u16ChgrTempFalutL,	&MstCmdRdCpy},
	{PMBusCmd_UsrData1,			PMBusCT_RdWrnBytes,		PMBusDT_Linear,	  	   2,	(u8_t*)&tsBBU_Dev[0].u16ChrgTempWarnL,	&MstCmdRdCpy},
	{PMBusCmd_UsrData2,			PMBusCT_RdWrnBytes,		PMBusDT_Linear,	  	   2,	(u8_t*)&tsBBU_Dev[0].u16AmbTempFalutL,	&MstCmdRdCpy},
	{PMBusCmd_UsrData3,			PMBusCT_RdWrnBytes,		PMBusDT_Linear,	  	   2,	(u8_t*)&tsBBU_Dev[0].u16AmbTempWarnL,			&MstCmdRdCpy},
	{PMBusCmd_UsrData4,			PMBusCT_RdWrnBytes,		PMBusDT_Linear,	  	   2,	(u8_t*)&tsBBU_Dev[0].u16DisChgrCellTempFalutL,	&MstCmdRdCpy},
	{PMBusCmd_UsrData5,			PMBusCT_RdWrnBytes,		PMBusDT_Linear,	  	   2,	(u8_t*)&tsBBU_Dev[0].u16DisChrgCellTempWarnL,	&MstCmdRdCpy},
	{PMBusCmd_UsrData6,			PMBusCT_RdWrnBytes,		PMBusDT_Linear,	  	   2,	(u8_t*)&tsBBU_Dev[0].u16ChrgCellTempFalutL,		&MstCmdRdCpy},
	{PMBusCmd_UsrData7,			PMBusCT_RdWrnBytes,		PMBusDT_Linear,	  	   2,	(u8_t*)&tsBBU_Dev[0].u16ChrgCellTempWarnL,		&MstCmdRdCpy},
	{PMBusCmd_UsrData11,		PMBusCT_RdWrnBytes,		PMBusDT_NN_Block, 	   2,	(u8_t*)&tsBBU_Dev[0].u16ModeChange,		&MstCmdRdCpy},
	{PMBusCmd_MFRSp2,		    PMBusCT_RdWrnBytes,		PMBusDT_NN_Block, 	   1,	&tsBBU_Dev[0].tnChrgCurrStatus.u8All,	&MstCmdRdCpy},
	{PMBusCmd_MFRSp16,			PMBusCT_RdWrnBytes,		PMBusDT_NN_Block,	   2,	(u8_t*)&tsBBU_Dev[0].u16VrefOffLine,	&MstCmdRdCpy},
	{PMBusCmd_MFRSp17,			PMBusCT_RdWrnBytes,		PMBusDT_NN_Block,	   2,	(u8_t*)&tsBBU_Dev[0].u16VrefOnLine,		&MstCmdRdCpy},
	{PMBusCmd_MFRSp18,			PMBusCT_RdWrnBytes,		PMBusDT_NN_Block,	   2,	(u8_t*)&tsBBU_Dev[0].u16TrimCsDuty,		&MstCmdRdCpy},
	{PMBusCmd_MFRSp20,			PMBusCT_RdWrnBytes,		PMBusDT_NN_Block,	   1,	&tsBBU_Dev[0].u8Calibration,		    &MstCmdRdCpy},
	{PMBusCmd_MFRSp22,			PMBusCT_RdWrnBytes,		PMBusDT_NN_Block, 	   2,	(u8_t*)&tsBBU_Dev[0].u16LastProtectIndex,	&MstCmdRdCpy},
	{PMBusCmd_MFRSp29,		    PMBusCT_RdWrnBytes,		PMBusDT_NN_Block,	   2,	(u8_t*)&tsBBU_Dev[0].u16BattCycL,		&MstCmdRdCpy},
	{PMBusCmd_MFRSp30,			PMBusCT_RdWrnBytes,		PMBusDT_NN_Block,	   2,	(u8_t*)&tsBBU_Dev[0].u16BbuIntCtrl,		&MstCmdRdCpy},
#if(BAIDU_BT)
    {PMBusCmd_MFRSp33,		    PMBusCT_RdWrnBytes,	    PMBusDT_NN_Block,		1,	&tsBBU_Dev[0].u8BtStatus,				&MstCmdRdCpy},
#endif
};

sPMBusCmdStr_t sBbuPMBusWOCmd_CTR[BBU_PMBUS_WO_CTR_NUM] =
{
	/*|cmd code|      			|cmd type|			|data type|		  |len| 	|pbuff|                     			|funcptr|*/
	{PMBusCmd_ClrFault, 	PMBusCT_SendByte,	PMBusDT_NN_Block,		0,	&tsBBU_Dev[0].u8ClrFault,				&MstCmdWrCpy},
	{PMBusCmd_StoreDftAll, 	PMBusCT_SendByte,	PMBusDT_NN_Block,		0,	&tsBBU_Dev[0].u8StoreDefaultAll,		&MstCmdWrCpy},
#if(BAIDU_BT)
	{PMBusCmd_MFRSp32,		PMBusCT_WrnBytes,	PMBusDT_NN_Block,		4,		&tsBBU_Dev[0].pu8PBtKey[0],			&MstCmdWrCpy},
	{PMBusCmd_MFRSp34,		PMBusCT_WrnBytes,	PMBusDT_NN_Block,		32,		&tsBBU_Dev[0].pu8BtMemBlock[0],		&MstCmdWrCpy},
	{PMBusCmd_MFRSp35,		PMBusCT_WrnBytes,	PMBusDT_NN_Block,		16,		&tsBBU_Dev[0].pu8ProductKey[0],		&MstCmdWrCpy},
	{PMBusCmd_MFRSp36,		PMBusCT_WrnBytes,	PMBusDT_NN_Block,		2,		(u8_t*)&tsBBU_Dev[0].u16ImageChk,	&MstCmdWrCpy},
#endif
};
/****************************************************************************
* declare the BBU PMBus commands which is modified by user
****************************************************************************/
sPMBusCmdStr_t sBbuPMBusROCmd[BBU_PMBUS_RO_NUM] =
{
  /*|cmd code|      			|cmd type|			|data type|		  |len| 	|pbuff|                     			|funcptr|*/
	{PMBusCmd_OnOffConf,		PMBusCT_RdnBytes,		PMBusDT_NN_Block,	   1,	&tsBBU_Dev[0].u8OnOffConfig,			&MstCmdRdCpy},
	{PMBusCmd_Capability,		PMBusCT_RdnBytes,	    PMBusDT_NN_Block,     1,	&tsBBU_Dev[0].tnCapability.u8All,		&MstCmdRdCpy},
	{PMBusCmd_Query,			PMBusCT_BWrBRdProCall,	PMBusDT_NN_Block,   1,	&tsBBU_Dev[0].tnPMBusQuerry.u8All,	&MstCmdRdCpy},
	{PMBusCmd_VoutMode,			PMBusCT_RdnBytes,		PMBusDT_NN_Block,	1,	&tsBBU_Dev[0].u8VoutMode,			&MstCmdRdCpy},
	{PMBusCmd_VoutOVFaultResp,	PMBusCT_RdnBytes,		PMBusDT_NN_Block,	1,	&tsBBU_Dev[0].u8VoutOVFaultResp,		&MstCmdRdCpy},
	{PMBusCmd_VoutUVFaultResp,	PMBusCT_RdnBytes,		PMBusDT_NN_Block,	1,	&tsBBU_Dev[0].u8VoutUVFaultResp,		&MstCmdRdCpy},
    {PMBusCmd_IoutOCFaultResp,	PMBusCT_RdnBytes,		PMBusDT_NN_Block,	1,	&tsBBU_Dev[0].u8IoutOCFaultResp,		&MstCmdRdCpy},
	{PMBusCmd_OTFaultResp,		PMBusCT_RdnBytes,		PMBusDT_NN_Block,	1,	&tsBBU_Dev[0].u8OTFaultResp,			&MstCmdRdCpy},
	{PMBusCmd_VinOVFaultResp,	PMBusCT_RdnBytes,		PMBusDT_NN_Block,	1,	&tsBBU_Dev[0].u8VinOVFaultResp,		&MstCmdRdCpy},
	{PMBusCmd_VinUVFaultResp,	PMBusCT_RdnBytes,		PMBusDT_NN_Block,	1,	&tsBBU_Dev[0].u8VinUVFaultResp,		&MstCmdRdCpy},
	{PMBusCmd_IinOCFaultResp,	PMBusCT_RdnBytes,		PMBusDT_NN_Block,	1,	&tsBBU_Dev[0].u8IinOCFaultResp,		&MstCmdRdCpy},
    {PMBusCmd_StatusByte,		PMBusCT_RdnBytes,		PMBusDT_NN_Block, 	   1,	&tsBBU_Dev[0].tnStatusByte.u8All,		&MstCmdRdCpy},
	{PMBusCmd_StatusWord,		PMBusCT_RdnBytes,		PMBusDT_NN_Block, 	   2,	(u8_t*)&tsBBU_Dev[0].tnStatusWord.u16All,	&MstCmdRdCpy},
	{PMBusCmd_StatusVout,		PMBusCT_RdnBytes,		PMBusDT_NN_Block, 	   1,	&tsBBU_Dev[0].tnStatusVout.u8All,		&MstCmdRdCpy},
	{PMBusCmd_StatusIout,		PMBusCT_RdnBytes,		PMBusDT_NN_Block, 	   1,	&tsBBU_Dev[0].tnStatusIout.u8All,		&MstCmdRdCpy},
	{PMBusCmd_StatusInput,	    PMBusCT_RdnBytes,		PMBusDT_NN_Block, 	   1,	&tsBBU_Dev[0].tnStatusInput.u8All,		&MstCmdRdCpy},
	{PMBusCmd_StatusTemp,	    PMBusCT_RdnBytes,		PMBusDT_NN_Block, 	   1,	&tsBBU_Dev[0].tnStatusTemp.u8All,		&MstCmdRdCpy},
	{PMBusCmd_StatusCML,	    PMBusCT_RdnBytes,		PMBusDT_NN_Block, 	   1,	&tsBBU_Dev[0].tnStatusCML.u8All,		&MstCmdRdCpy},
	{PMBusCmd_RdVin,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16ReadVin,			&MstCmdRdCpy},
	{PMBusCmd_RdIin,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16ReadIin,		&MstCmdRdCpy},
	{PMBusCmd_RdVout,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16ReadVout,		&MstCmdRdCpy},
	{PMBusCmd_RdIout,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16ReadIout,		&MstCmdRdCpy},
	{PMBusCmd_RdTemp1,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16ReadTemp1,		&MstCmdRdCpy},
	{PMBusCmd_RdTemp2,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16ReadTemp2,		&MstCmdRdCpy},
	{PMBusCmd_RdTemp3,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16ReadTemp3,		&MstCmdRdCpy},
	{PMBusCmd_RdPout,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16ReadPout,		&MstCmdRdCpy},
	{PMBusCmd_RdPin,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16ReadPin,		&MstCmdRdCpy},
	{PMBusCmd_RMBusRev,		PMBusCT_RdnBytes,		PMBusDT_NN_Block,	1,	&tsBBU_Dev[0].tnPMBusRev.u8All,			&MstCmdRdCpy},
	{PMBusCmd_MFRVinMin,	PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16MFRVinMin,		&MstCmdRdCpy},
	{PMBusCmd_MFRVinMax,	PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16MFRVinMax,		&MstCmdRdCpy},
	{PMBusCmd_MFRIinMax,	PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16MFRIinMax,		&MstCmdRdCpy},
	{PMBusCmd_MFRPinMax,	PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16MFRPinMax,		&MstCmdRdCpy},
	{PMBusCmd_MFRVoutMin,	PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16MFRVoutMin,		&MstCmdRdCpy},
	{PMBusCmd_MFRVoutMax,	PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16MFRVoutMax,		&MstCmdRdCpy},
	{PMBusCmd_MFRIoutMax,	PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16MFRIoutMax,		&MstCmdRdCpy},
	{PMBusCmd_MFRPoutMax,	PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16MFRPoutMax,		&MstCmdRdCpy},
	{PMBusCmd_MFRAmbTMax,	PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16MFRAmbTMax,		&MstCmdRdCpy},
	{PMBusCmd_MFRAmbTMin,	PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16MFRAmbTMin,		&MstCmdRdCpy},
	{PMBusCmd_UsrData12,  	PMBusCT_BlockRd,		PMBusDT_NN_Block, 	   15,	&tsBBU_Dev[0].pu8PackMFT[0],			&MstCmdRdCpy},
    {PMBusCmd_UsrData13,  	PMBusCT_BlockRd,		PMBusDT_NN_Block, 	   15,	&tsBBU_Dev[0].pu8CellMFT[0],			&MstCmdRdCpy},
    {PMBusCmd_UsrData14,  	PMBusCT_BlockRd,		PMBusDT_NN_Block, 	   15,	&tsBBU_Dev[0].pu8CellModel[0],			&MstCmdRdCpy},
	{PMBusCmd_MFRMaxTemp1,	PMBusCT_RdnBytes,		PMBusDT_Linear,	  	   2,	(u8_t*)&tsBBU_Dev[0].u16MFRMaxTemp1,	&MstCmdRdCpy},
	{PMBusCmd_MFRMaxTemp2,	PMBusCT_RdnBytes,		PMBusDT_Linear,	  	   2,	(u8_t*)&tsBBU_Dev[0].u16MFRMaxTemp2,	&MstCmdRdCpy},
	{PMBusCmd_MFRSp0,		PMBusCT_RdnBytes,		PMBusDT_NN_Block, 	   1,	&tsBBU_Dev[0].tnStatusBBU.u8All,		&MstCmdRdCpy},
	{PMBusCmd_MFRSp1,		PMBusCT_RdnBytes,		PMBusDT_NN_Block, 	2,	(u8_t*)&tsBBU_Dev[0].tnStateBBU.u16All,			&MstCmdRdCpy},
	{PMBusCmd_MFRSp3,		PMBusCT_RdnBytes,		PMBusDT_NN_Block, 	2,	&tsBBU_Dev[0].pu8BattPackSN[0],			&MstCmdRdCpy},
	{PMBusCmd_MFRSp4,		PMBusCT_RdnBytes,		PMBusDT_Linear,	   	2,	(u8_t*)&tsBBU_Dev[0].u16BattVolt,	    &MstCmdRdCpy},
    {PMBusCmd_MFRSp5,	    PMBusCT_BlockRd,        PMBusDT_NN_Block, 	11,	&tsBBU_Dev[0].pu8BmsHwFwCompCode[0],			&MstCmdRdCpy},
    {PMBusCmd_MFRSp6,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16BattCurr,		&MstCmdRdCpy},
	{PMBusCmd_MFRSp7,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16BattASOC,		&MstCmdRdCpy},
	{PMBusCmd_MFRSp8,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16BattCycCntOffset,	&MstCmdRdCpy},
	{PMBusCmd_MFRSp9,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16BattRSOC,			&MstCmdRdCpy},
	{PMBusCmd_MFRSp10,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16BattCapacity,		&MstCmdRdCpy},
	{PMBusCmd_MFRSp11,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16BattCycCnt,			&MstCmdRdCpy},
	{PMBusCmd_MFRSp12,		PMBusCT_BlockRd,		PMBusDT_NN_Block,	4,	(u8_t*)&tsBBU_Dev[0].u32BattRunTime,		&MstCmdRdCpy},
	{PMBusCmd_MFRSp13,		PMBusCT_RdnBytes,		PMBusDT_NN_Block, 	2,	(u8_t*)&tsBBU_Dev[0].u16BattStatus,			&MstCmdRdCpy},
	{PMBusCmd_MFRSp14,		PMBusCT_RdnBytes,		PMBusDT_NN_Block, 	2,	(u8_t*)&tsBBU_Dev[0].u16BattProcStatus,		&MstCmdRdCpy},
	{PMBusCmd_MFRSp15,		PMBusCT_RdnBytes,		PMBusDT_NN_Block, 	2,	(u8_t*)&tsBBU_Dev[0].u16BattPfStatus,		&MstCmdRdCpy},
	{PMBusCmd_MFRSp19,		PMBusCT_RdnBytes,		PMBusDT_Linear,	  	2,	(u8_t*)&tsBBU_Dev[0].u16BattTemp,			&MstCmdRdCpy},
	{PMBusCmd_MFRSp21,  	PMBusCT_BlockRd,      PMBusDT_NN_Block, 	4,	(u8_t*)&tsBBU_Dev[0].pu32BBUProtectType,	&MstCmdRdCpy},
	{PMBusCmd_MFRSp23,		PMBusCT_BlockRd,		PMBusDT_NN_Block, 	4,	&tsBBU_Dev[0].u8LastProtect[0],	            &MstCmdRdCpy},
	{PMBusCmd_MFRSp24,		PMBusCT_RdnBytes,		PMBusDT_Linear, 	2,	(u8_t*)&tsBBU_Dev[0].u16BattSOH,			&MstCmdRdCpy},
	{PMBusCmd_MFRSp25,		PMBusCT_RdnBytes,		PMBusDT_Linear, 	2,	(u8_t*)&tsBBU_Dev[0].u16DischrgRemainTime,	&MstCmdRdCpy},
	{PMBusCmd_MFRSp26,		PMBusCT_BlockRd,		PMBusDT_NN_Block,	28,	&tsBBU_Dev[0].u8CellVoltMinHistory[0],	&MstCmdRdCpy},
	{PMBusCmd_MFRSp27,		PMBusCT_RdnBytes,		PMBusDT_NN_Block, 	2,	(u8_t*)&tsBBU_Dev[0].u16BMSFWRevision,		&MstCmdRdCpy},
	{PMBusCmd_MFRSp28,		PMBusCT_RdnBytes,		PMBusDT_Linear, 	2,	(u8_t*)&tsBBU_Dev[0].u16FullyChrgCapacity,	&MstCmdRdCpy},
	{PMBusCmd_MFRSp44,	    PMBusCT_BlockRd,        PMBusDT_NN_Block, 	11,	&tsBBU_Dev[0].pu8BbuHwFwCompCode[0],			&MstCmdRdCpy},
	{PMBusCmd_MFRSp45, 		PMBusCT_BlockRd,		PMBusDT_NN_Block, 	16,	&tsBBU_Dev[0].pu8Protocol[0],				&MstCmdRdCpy}

};

sPMBusCmdStr_t sBbuPMBusWOCmd[BBU_PMBUS_WO_NUM] =
{
	/*|cmd code|      			|cmd type|			|data type|		  |len| 	|pbuff|                     			|funcptr|*/
	{PMBusCmd_ClrFault, 	PMBusCT_SendByte,	PMBusDT_NN_Block,		0,	&tsBBU_Dev[0].u8ClrFault,				&MstCmdWrCpy},
	{PMBusCmd_StoreDftAll, 	PMBusCT_SendByte,	PMBusDT_NN_Block,		0,	&tsBBU_Dev[0].u8StoreDefaultAll,		&MstCmdWrCpy},

};

sPMBusCmdStr_t sBbuPMBusRWCmd[BBU_PMBUS_RW_NUM] =
{
	/*|cmd code|      			|cmd type|			|data type|		  |len| 	|pbuff|                     			|funcptr|*/
    {PMBusCmd_Page,				PMBusCT_RdWrnBytes,		PMBusDT_u8,	  	  	   1,	&tsBBU_Dev[0].u8CurrPage,				&MstCmdRdCpy},
    {PMBusCmd_Operation,		PMBusCT_RdWrnBytes,		PMBusDT_NN_Block,	   1,	&tsBBU_Dev[0].u8Operation,				&MstCmdRdCpy},
    {PMBusCmd_WriteProt,		PMBusCT_RdWrnBytes,		PMBusDT_NN_Block,	   1,	&tsBBU_Dev[0].u8WriteProtect,			&MstCmdRdCpy},
    {PMBusCmd_VoutOVFaultLimit,	PMBusCT_RdWrnBytes,		PMBusDT_Linear,   	   2,	(u8_t*)&tsBBU_Dev[0].u16VoutOVFaultL,	&MstCmdRdCpy},
    {PMBusCmd_VoutOVWarnLimit,	PMBusCT_RdWrnBytes,		PMBusDT_Linear,   	   2,	(u8_t*)&tsBBU_Dev[0].u16VoutOVWarnL,	&MstCmdRdCpy},
    {PMBusCmd_VoutUVWarnLimit,	PMBusCT_RdWrnBytes,		PMBusDT_Linear,   	   2,	(u8_t*)&tsBBU_Dev[0].u16VoutUVWarnL,	&MstCmdRdCpy},
    {PMBusCmd_VoutUVFaultLimit,	PMBusCT_RdWrnBytes,		PMBusDT_Linear,   	   2,	(u8_t*)&tsBBU_Dev[0].u16VoutUVFaultL,	&MstCmdRdCpy},
    {PMBusCmd_IoutOCFaultLimit,	PMBusCT_RdWrnBytes,		PMBusDT_Linear,   	   2,	(u8_t*)&tsBBU_Dev[0].u16IoutOCFaultL,	&MstCmdRdCpy},
    {PMBusCmd_IoutOCWarnLimit,	PMBusCT_RdWrnBytes,		PMBusDT_Linear,   	   2,	(u8_t*)&tsBBU_Dev[0].u16IoutOCWarnL,	&MstCmdRdCpy},
    {PMBusCmd_OTFaultLimit,	    PMBusCT_RdWrnBytes,		PMBusDT_Linear,   	   2,	(u8_t*)&tsBBU_Dev[0].u16OTFaultL,	    &MstCmdRdCpy},
    {PMBusCmd_OTWarnLimit,	    PMBusCT_RdWrnBytes,		PMBusDT_Linear,   	   2,	(u8_t*)&tsBBU_Dev[0].u16OTWarnL,		&MstCmdRdCpy},
    {PMBusCmd_VinOVFaultLimit,	PMBusCT_RdWrnBytes,		PMBusDT_Linear,   	   2,	(u8_t*)&tsBBU_Dev[0].u16VinOVFaultL,	&MstCmdRdCpy},
    {PMBusCmd_VinOVWarnLimit,	PMBusCT_RdWrnBytes,		PMBusDT_Linear,   	   2,	(u8_t*)&tsBBU_Dev[0].u16VinOVWarnL,		&MstCmdRdCpy},
    {PMBusCmd_VinUVWarnLimit,	PMBusCT_RdWrnBytes,		PMBusDT_Linear,   	   2,	(u8_t*)&tsBBU_Dev[0].u16VinUVWarnL,		&MstCmdRdCpy},
    {PMBusCmd_VinUVFaultLimit,	PMBusCT_RdWrnBytes,		PMBusDT_Linear,   	   2,	(u8_t*)&tsBBU_Dev[0].u16VinUVFaultL,	&MstCmdRdCpy},
    {PMBusCmd_IinOCFaultLimit,	PMBusCT_RdWrnBytes,		PMBusDT_Linear,   	   2,	(u8_t*)&tsBBU_Dev[0].u16IinOCFaultL,	&MstCmdRdCpy},
    {PMBusCmd_IinOCWarnLimit,	PMBusCT_RdWrnBytes,		PMBusDT_Linear,   	   2,	(u8_t*)&tsBBU_Dev[0].u16IinOCWarnL,		&MstCmdRdCpy},
    {PMBusCmd_POutOPFaultLimit,	PMBusCT_RdWrnBytes,		PMBusDT_Linear,   	   2,	(u8_t*)&tsBBU_Dev[0].u16POutOPFaultL,	&MstCmdRdCpy},
    {PMBusCmd_POutOPWarnLimit,	PMBusCT_RdWrnBytes,		PMBusDT_Linear,   	   2,	(u8_t*)&tsBBU_Dev[0].u16PoutOPWarnL,	&MstCmdRdCpy},
    {PMBusCmd_PInOPWarnLimit,	PMBusCT_RdWrnBytes,		PMBusDT_Linear,   	   2,	(u8_t*)&tsBBU_Dev[0].u16PinOPWarnL,		&MstCmdRdCpy},
    {PMBusCmd_MFRID,	   		PMBusCT_BlockRdWr,      PMBusDT_NN_Block, 	   10,	&tsBBU_Dev[0].pu8MFRID[0],				&MstCmdRdCpy},
    {PMBusCmd_MFRModel,	   		PMBusCT_BlockRdWr,      PMBusDT_NN_Block, 	   11,	&tsBBU_Dev[0].pu8MFRModel[0],			&MstCmdRdCpy},
    {PMBusCmd_MFRRev,	   		PMBusCT_BlockRdWr,      PMBusDT_NN_Block, 	   10,	&tsBBU_Dev[0].pu8MFRRev[0],				&MstCmdRdCpy},
	{PMBusCmd_MFRLocation, 		PMBusCT_BlockRdWr,      PMBusDT_NN_Block, 	   10,	&tsBBU_Dev[0].pu8MFRLoc[0],				&MstCmdRdCpy},
    {PMBusCmd_MFRDate,	   		PMBusCT_BlockRdWr,      PMBusDT_NN_Block, 	   10,	&tsBBU_Dev[0].pu8MFRDate[0],			&MstCmdRdCpy},
    {PMBusCmd_MFRSerial,   		PMBusCT_BlockRdWr,      PMBusDT_NN_Block, 	   15,	&tsBBU_Dev[0].pu8MFRSerial[0],			&MstCmdRdCpy},
    {PMBusCmd_UsrData0,			PMBusCT_RdWrnBytes,		PMBusDT_Linear,	  	   2,	(u8_t*)&tsBBU_Dev[0].u16ChgrTempFalutL,	&MstCmdRdCpy},
	{PMBusCmd_UsrData1,			PMBusCT_RdWrnBytes,		PMBusDT_Linear,	  	   2,	(u8_t*)&tsBBU_Dev[0].u16ChrgTempWarnL,	&MstCmdRdCpy},
	{PMBusCmd_UsrData2,			PMBusCT_RdWrnBytes,		PMBusDT_Linear,	  	   2,	(u8_t*)&tsBBU_Dev[0].u16AmbTempFalutL,	&MstCmdRdCpy},
	{PMBusCmd_UsrData3,			PMBusCT_RdWrnBytes,		PMBusDT_Linear,	  	   2,	(u8_t*)&tsBBU_Dev[0].u16AmbTempWarnL,			&MstCmdRdCpy},
	{PMBusCmd_UsrData4,			PMBusCT_RdWrnBytes,		PMBusDT_Linear,	  	   2,	(u8_t*)&tsBBU_Dev[0].u16DisChgrCellTempFalutL,	&MstCmdRdCpy},
	{PMBusCmd_UsrData5,			PMBusCT_RdWrnBytes,		PMBusDT_Linear,	  	   2,	(u8_t*)&tsBBU_Dev[0].u16DisChrgCellTempWarnL,	&MstCmdRdCpy},
	{PMBusCmd_UsrData6,			PMBusCT_RdWrnBytes,		PMBusDT_Linear,	  	   2,	(u8_t*)&tsBBU_Dev[0].u16ChrgCellTempFalutL,		&MstCmdRdCpy},
	{PMBusCmd_UsrData7,			PMBusCT_RdWrnBytes,		PMBusDT_Linear,	  	   2,	(u8_t*)&tsBBU_Dev[0].u16ChrgCellTempWarnL,		&MstCmdRdCpy},
	{PMBusCmd_UsrData11,		PMBusCT_RdWrnBytes,		PMBusDT_NN_Block, 	   2,	(u8_t*)&tsBBU_Dev[0].u16ModeChange,		&MstCmdRdCpy},
	{PMBusCmd_MFRSp2,		    PMBusCT_RdWrnBytes,		PMBusDT_NN_Block, 	   1,	&tsBBU_Dev[0].tnChrgCurrStatus.u8All,	&MstCmdRdCpy},
	{PMBusCmd_MFRSp16,			PMBusCT_RdWrnBytes,		PMBusDT_NN_Block,	   2,	(u8_t*)&tsBBU_Dev[0].u16VrefOffLine,	&MstCmdRdCpy},
	{PMBusCmd_MFRSp17,			PMBusCT_RdWrnBytes,		PMBusDT_NN_Block,	   2,	(u8_t*)&tsBBU_Dev[0].u16VrefOnLine,		&MstCmdRdCpy},
	{PMBusCmd_MFRSp18,			PMBusCT_RdWrnBytes,		PMBusDT_NN_Block,	   2,	(u8_t*)&tsBBU_Dev[0].u16TrimCsDuty,		&MstCmdRdCpy},
	{PMBusCmd_MFRSp20,			PMBusCT_RdWrnBytes,		PMBusDT_NN_Block,	   1,	&tsBBU_Dev[0].u8Calibration,		    &MstCmdRdCpy},
	{PMBusCmd_MFRSp22,			PMBusCT_RdWrnBytes,		PMBusDT_NN_Block, 	   2,	(u8_t*)&tsBBU_Dev[0].u16LastProtectIndex,	&MstCmdRdCpy},
	{PMBusCmd_MFRSp29,		    PMBusCT_RdWrnBytes,		PMBusDT_NN_Block,	   2,	(u8_t*)&tsBBU_Dev[0].u16BattCycL,		&MstCmdRdCpy},
	{PMBusCmd_MFRSp30,			PMBusCT_RdWrnBytes,		PMBusDT_NN_Block,	   2,	(u8_t*)&tsBBU_Dev[0].u16BbuIntCtrl,		&MstCmdRdCpy}
};

/****************************************************************************
* declare the BBS PMBus commands which is modified by user
****************************************************************************/
sPMBusCmdStr_t sBbsPMBusROCmd[BBS_PMBUS_RO_NUM] =
{
	/*|cmd code|      			|cmd type|			|data type|		  |len| 	|pbuff|                     			|funcptr|*/
	{PMBusCmd_StatusCML,	    PMBusCT_RdnBytes,	PMBusDT_NN_Block, 	1,	    &tsBSC_Dev.tnStatusCML.u8All,		    &MstCmdRdCpy},
	{PMBusCmd_UsrData9,			PMBusCT_RdnBytes,	PMBusDT_NN_Block, 	2,		(u8_t*)&tsBSC_Dev.tnStatusWord.u16All,	&MstCmdRdCpy},
	{PMBusCmd_UsrData10,	    PMBusCT_BlockRd,    PMBusDT_NN_Block, 	16,		&tsBSC_Dev.pu8BbuAddress[0],			&MstCmdRdCpy},
	{PMBusCmd_MFRSp41,			PMBusCT_RdnBytes,	PMBusDT_NN_Block, 	2,		(u8_t*)&tsBSC_Dev.u16BattSelfCycleCnt,	&MstCmdRdCpy},
	{PMBusCmd_MFRSp44,	        PMBusCT_BlockRd,    PMBusDT_NN_Block, 	11,	    &tsBSC_Dev.pu8BbsHwFwCompCode[0],		&MstCmdRdCpy},
	{PMBusCmd_MFRSp45, 			PMBusCT_BlockRd,	PMBusDT_NN_Block, 	16,		&tsBSC_Dev.pu8Protocol[0],			    &MstCmdRdCpy}

};

sPMBusCmdStr_t sBbsPMBusWOCmd[BBS_PMBUS_WO_NUM] =
{
	/*|cmd code|      			|cmd type|			|data type|		  |len| 	|pbuff|                     			|funcptr|*/
#if (BAIDU_BT)
	{PMBusCmd_MFRSp32,			PMBusCT_WrnBytes,	PMBusDT_NN_Block,		4,	&tsBSC_Dev.pu8PBtKey[0],			&MstCmdWrCpy},
	{PMBusCmd_MFRSp35,			PMBusCT_WrnBytes,	PMBusDT_NN_Block,		16,	&tsBSC_Dev.pu8ProductKey[0],		&MstCmdWrCpy},
#endif
	{PMBusCmd_ClrFault, 	PMBusCT_SendByte,	PMBusDT_NN_Block,		0,	&tsBSC_Dev.u8ClrFault,				&MstCmdWrCpy},
};

sPMBusCmdStr_t sBbsPMBusRWCmd[BBS_PMBUS_RW_NUM] =
{
	/*|cmd code|      			|cmd type|			|data type|		  |len| 	|pbuff|                     			|funcptr|*/
#if (BAIDU_BT)
	{PMBusCmd_MFRSp33,			PMBusCT_RdWrnBytes,	PMBusDT_NN_Block,      1,	&tsBSC_Dev.u8BtStatus,		        &MstCmdRdCpy},
#endif
	{PMBusCmd_MFRID,	   		PMBusCT_BlockRdWr,	PMBusDT_NN_Block, 	   10,	&tsBSC_Dev.pu8MFRID[0],				&MstCmdRdCpy},
	{PMBusCmd_MFRModel,	   		PMBusCT_BlockRdWr,	PMBusDT_NN_Block, 	   11,	&tsBSC_Dev.pu8MFRModel[0],			&MstCmdRdCpy},
	{PMBusCmd_MFRRev,	   		PMBusCT_BlockRdWr,	PMBusDT_NN_Block, 	   10,	&tsBSC_Dev.pu8MFRRev[0],			&MstCmdRdCpy},
	{PMBusCmd_MFRLocation, 		PMBusCT_BlockRdWr,	PMBusDT_NN_Block, 	   10,	&tsBSC_Dev.pu8MFRLoc[0],			&MstCmdRdCpy},
	{PMBusCmd_MFRDate,	   		PMBusCT_BlockRdWr,	PMBusDT_NN_Block, 	   10,	&tsBSC_Dev.pu8MFRDate[0],			&MstCmdRdCpy},
	{PMBusCmd_MFRSerial,   		PMBusCT_BlockRdWr,	PMBusDT_NN_Block, 	   15,	&tsBSC_Dev.pu8MFRSerial[0],			&MstCmdRdCpy},
	{PMBusCmd_UsrData8,			PMBusCT_RdWrnBytes,	PMBusDT_NN_Block, 	   2,	(u8_t*)&tsBSC_Dev.tnLearningCtrl.u16All,	&MstCmdRdCpy},
	{PMBusCmd_UsrData11,		PMBusCT_RdWrnBytes,	PMBusDT_NN_Block, 	   2,	(u8_t*)&tsBSC_Dev.u16ModeChange,	&MstCmdRdCpy},
	{PMBusCmd_MFRSp20,			PMBusCT_RdWrnBytes,	PMBusDT_NN_Block,	   1,	&tsBSC_Dev.u8Calibration,		    &MstCmdRdCpy},
	{PMBusCmd_MFRSp31,			PMBusCT_RdWrnBytes,	PMBusDT_NN_Block,	   2,	(u8_t*)&tsBSC_Dev.u16BattSelfCycleTime,		&MstCmdRdCpy},
	{PMBusCmd_MFRSp40,			PMBusCT_RdWrnBytes,	PMBusDT_NN_Block,	   2,	(u8_t*)&tsBSC_Dev.u16BattSelfDischrgRate,	&MstCmdRdCpy},
};

#if (BAIDU_BT)
sPMBusCmdStr_t sBbsBtPMBusROCmd[BBS_BT_PMBUS_RO_NUM] =
{
	/*|cmd code|      			|cmd type|			|data type|		  |len| 	|pbuff|                     			|funcptr|*/
	//{PMBusCmd_StatusCML,	    PMBusCT_RdnBytes,	PMBusDT_NN_Block, 	1,	    &tsBSC_Dev.tnStatusCML.u8All,		    &MstCmdRdCpy},

};
sPMBusCmdStr_t sBbsBtPMBusWOCmd[BBS_BT_PMBUS_WO_NUM] =
{
	/*|cmd code|      			|cmd type|			|data type|		  |len| 	|pbuff|                     			|funcptr|*/
	{PMBusCmd_MFRSp32,			PMBusCT_WrnBytes,	PMBusDT_NN_Block,		4,	&tsBSC_Dev.pu8PBtKey[0],			&MstCmdWrCpy},
	{PMBusCmd_MFRSp35,			PMBusCT_WrnBytes,	PMBusDT_NN_Block,		16,	&tsBSC_Dev.pu8ProductKey[0],		&MstCmdWrCpy},
};
sPMBusCmdStr_t sBbsBtPMBusRWCmd[BBS_BT_PMBUS_RW_NUM] =
{
	/*|cmd code|      			|cmd type|			|data type|		  |len| 	|pbuff|                     			|funcptr|*/
	{PMBusCmd_MFRSp33,			PMBusCT_RdWrnBytes,	PMBusDT_NN_Block,      1,	&tsBSC_Dev.u8BtStatus,		        &MstCmdRdCpy},
};
#endif
/****************************************************************************
* declare the BBU PMBus Bootloader commands which is modified by user
****************************************************************************/
#if(LITEON_BT)
sPMBusCmdStr_t sBbuBLPMBusROCmd[BBU_BL_PMBUS_RO_NUM] =
{
  /*|cmd code|      			|cmd type|			|data type|		  |len| 	|pbuff|                     			|funcptr|*/


};

sPMBusCmdStr_t sBbuBLPMBusWOCmd[BBU_BL_PMBUS_WO_NUM] =
{
	/*|cmd code|      			|cmd type|			|data type|		  |len| 	|pbuff|                     			|funcptr|*/
	{PMBusCmd_MFRSp35,	PMBusCT_BlockWr,	PMBusDT_NN_Block, 		8,	(u8_t*)&tsBbuBt_Dev.tsBtCmdF3h.u32StartAddr, 			&MstCmdWrCpy},
	{PMBusCmd_MFRSp36,	PMBusCT_BlockWr,	PMBusDT_NN_Block, 		68,	(u8_t*)&tsBbuBt_Dev.tsBtCmdF4h.u32StartAddr, 			&MstCmdWrCpy}

};

sPMBusCmdStr_t sBbuBLPMBusRWCmd[BBU_BL_PMBUS_RW_NUM] =
{
	/*|cmd code|      			|cmd type|			|data type|		  |len| 	|pbuff|                     			|funcptr|*/
	{PMBusCmd_MFRSp32, 	PMBusCT_BWrBRdProCall, 	PMBusDT_NN_Block,	14,	(u8_t*)&tsBbuBt_Dev.tsBtCmdF0h.tnBtStatus.u16All,		&MstCmdRdCpy},
	{PMBusCmd_MFRSp33, 	PMBusCT_BWrBRdProCall, 	PMBusDT_NN_Block,	4,	(u8_t*)&tsBbuBt_Dev.tsBtCmdF1h.u16ModuleWord,			&MstCmdRdCpy},
	{PMBusCmd_MFRSp34, 	PMBusCT_BWrBRdProCall, 	PMBusDT_NN_Block,	3,	(u8_t*)&tsBbuBt_Dev.tsBtCmdF2h.tnBtStatus.u16All,		&MstCmdRdCpy},
	{PMBusCmd_MFRSp37, 	PMBusCT_BWrBRdProCall, 	PMBusDT_NN_Block,	2,	(u8_t*)&tsBbuBt_Dev.tsBtCmdF5h.tnBtStatus.u16All,		&MstCmdRdCpy},
	{PMBusCmd_MFRSp38, 	PMBusCT_BWrBRdProCall, 	PMBusDT_NN_Block,	2,	(u8_t*)&tsBbuBt_Dev.tsBtCmdF6h.tnBtStatus.u16All,		&MstCmdRdCpy},
	{PMBusCmd_MFRSp39, 	PMBusCT_BWrBRdProCall, 	PMBusDT_NN_Block,	8,	(u8_t*)&tsBbuBt_Dev.tsBtCmdF7h.tnBtStatus.u16All,		&MstCmdRdCpy}

};

sPMBusCmdStr_t sBbuBLPMBusRWDummyCmd[BBU_BL_PMBUS_RW_DUMMY_NUM] =
{
  /*|cmd code|      			|cmd type|			|data type|		  |len| 	|pbuff|                     			|funcptr|*/
	{PMBusCmd_Page,	     PMBusCT_RdWrnBytes,	PMBusDT_u8,	  	  1,		&tsBbuBt_Dev.u8DummyCurrPage,			&MstCmdRdCpy},

};
#endif
/****************************************************************************
* declare the BBU PMBus Baidu Bootloader commands which is modified by user
****************************************************************************/
#if (BAIDU_BT)
sPMBusCmdStr_t sBbuPMBusROCmd_BT_STA[BBU_PMBUS_RO_BT_STA_NUM] =
{
	/*|cmd code|      			|cmd type|			|data type|		  |len| 	|pbuff|                     			|funcptr|*/
	{PMBusCmd_StatusCML,	PMBusCT_RdnBytes,	PMBusDT_NN_Block, 	1,	&tsBBU_Dev[0].tnStatusCML.u8All,		&MstCmdRdCpy},
	{PMBusCmd_MFRSp33,		PMBusCT_RdnBytes,	PMBusDT_NN_Block,   1,	&tsBBU_Dev[0].u8BtStatus,		        &MstCmdRdCpy},

};
#endif
#if (BAIDU_BT)
sPMBusCmdStr_t sBbuPMBusROCmd_BT_DUMMY[BBU_BL_PMBUS_RO_DUMMY_NUM] =
{
	/*|cmd code|      			|cmd type|			|data type|		  |len| 	|pbuff|                     			|funcptr|*/
	{PMBusCmd_MFRSp33,	PMBusCT_RdnBytes,	PMBusDT_NN_Block, 	1,	&u8DummyRdBtStatus,		&MstCmdRdCpy},

};
#endif
/****************************************************************************
*	name        : MstCmdRdCpy
*	description :
*	return      : none
****************************************************************************/
void MstCmdRdCpy(u8_t* pu8src, u8_t* pu8dset, u16_t u16Len)
{
    memcpy(pu8dset, pu8src, u16Len);
}

/****************************************************************************
*	name        : MstCmdWrCpy
*	description :
*	return      : none
****************************************************************************/
void MstCmdWrCpy(u8_t* pu8src, u8_t* pu8dset, u16_t u16Len)
{
    memcpy(pu8dset, pu8src, u16Len);
}
