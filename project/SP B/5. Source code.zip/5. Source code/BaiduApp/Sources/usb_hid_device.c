/****************************************************************************
*	file	MstPMBusApp.c
*	brief	The file includes the function and data structure/variables
*		    for the PMBus protocol
*	author allen.lee
* 	version 1.0
*		-	2015/05/11: initial version by allen lee
*
****************************************************************************/
#include "usb_hid_device.h"
#include "PMBusData.h"
#include "MstPMBusApp.h"
#include "ProgramApp.h"
#include "i2c_slave.h"
#include "bsc.h"
#include "macro_define.h"

#if USBCFG_DEV_COMPOSITE
#error This application requires USBCFG_DEV_COMPOSITE defined zero in usb_device_config.h. Please recompile usbd with this option.
#endif
/****************************************************************************
 * Global Variables
 ****************************************************************************/
hid_generic_struct_t                      g_generic;
extern usb_desc_request_notify_struct_t  g_desc_callback;

u8_t u8usb_pmbusCmdByte;

#if (USB_ZOEY_DEBUG)
static u8_t u8gldev_step = 0;
#endif
/*****************************************************************************
 * Local Types - None
 *****************************************************************************/

/*****************************************************************************
 * Local Functions Prototypes
 *****************************************************************************/
void hid_generic_app_callback(uint8_t event_type, void* val,void* arg);
uint8_t hid_generic_app_param_callback(uint8_t request, uint16_t value, uint8_t ** data,
    uint32_t* size,void* arg);

/*****************************************************************************
 * Local Variables
 *****************************************************************************/

/*****************************************************************************
 * Local Functions
 *****************************************************************************/

/****************************************************************************
*	name        : usb_hid_packet_received
*	description :
*	return      : none
****************************************************************************/
void usb_hid_packet_received(void)
{
	u8_t i, j, u8pmbus_status, u8usbCmd, u8bytecnt;
	u16_t u16DevIndex;
	eUsbPacketStatus_t u8status = UsbPkt_Status_Fail;

	u8usbCmd = g_generic.rpt_buf[0];

	switch(u8usbCmd)
	{
		case UsbCmd_SendByte:
			i = GetDeviceAddressIndex(g_generic.rpt_buf[1], 0x00);
			if(i < BBU_DEV_NUM)
			{
				u8usb_pmbusCmdByte = g_generic.rpt_buf[2];
				u8status = UsbPkt_Status_Success;
			}

			break;

		case UsbCmd_ReceiveByte:
			i = GetDeviceAddressIndex(g_generic.rpt_buf[1], 0x01);
			if(i < BBU_DEV_NUM)
			{
				u8pmbus_status = ParseBbuRdCmdSup(i, u8usb_pmbusCmdByte, &g_generic.rpt_buf[2], &u8bytecnt);
				if(u8pmbus_status != PMBusCP_NoSupp)
				{
					u8status = UsbPkt_Status_Success;
				}
			}

			break;

		case UsbCmd_WriteByte:
			if(IsBscI2cAddr2(g_generic.rpt_buf[1]) == true)
			{
#if (BAIDU_BT)
				u8pmbus_status = ParseBscWrCmdSup(g_generic.rpt_buf[1], g_generic.rpt_buf[2], &g_generic.rpt_buf[3], 1);
				if(u8pmbus_status != PMBusCP_NoSupp)
				{
					u8status = UsbPkt_Status_Success;
				}
#endif /* BAIDU_BT */
			}
			else
			{
				i = GetDeviceAddressIndex(g_generic.rpt_buf[1], 0x00);
				if(i < BBU_DEV_NUM)
				{
#if (BAIDU_BT)
					u8pmbus_status = ParseBbuWrCmdPushWrData(i, g_generic.rpt_buf[2], &g_generic.rpt_buf[3], 1);
#else
					u8pmbus_status = ParseBbuWrCmdSup(i, g_generic.rpt_buf[2], &g_generic.rpt_buf[3], 1);
#endif
					if(u8pmbus_status != PMBusCP_NoSupp)
					{
						u8status = UsbPkt_Status_Success;
					}
				}
			}
			break;
		case UsbCmd_WriteWord:
			if(IsBscI2cAddr2(g_generic.rpt_buf[1]) == true)
			{
#if (BAIDU_BT)
				u8pmbus_status = ParseBscWrCmdSup(g_generic.rpt_buf[1], g_generic.rpt_buf[2], &g_generic.rpt_buf[3], 2);
				if(u8pmbus_status != PMBusCP_NoSupp)
				{
					u8status = UsbPkt_Status_Success;
				}
#endif /* BAIDU_BT */
			}
			else
			{
				i = GetDeviceAddressIndex(g_generic.rpt_buf[1], 0x00);
				if(i < BBU_DEV_NUM)
				{
					/*u8pmbus_status = ParseBscWrCmdSup(g_generic.rpt_buf[1], g_generic.rpt_buf[2], &g_generic.rpt_buf[3], 2);
					if(u8pmbus_status == PMBusCP_NoSupp)
					{
						//u8pmbus_status = ParseBbuWrCmdSup(i, g_generic.rpt_buf[2], &g_generic.rpt_buf[3], 2);
						u8pmbus_status = ParseBbuWrCmdPushWrData(i, g_generic.rpt_buf[2], &g_generic.rpt_buf[3], 2);
					}*/
#if (BAIDU_BT)
					u8pmbus_status = ParseBbuWrCmdPushWrData(i, g_generic.rpt_buf[2], &g_generic.rpt_buf[3], 2);
#else
					u8pmbus_status = ParseBbuWrCmdSup(i, g_generic.rpt_buf[2], &g_generic.rpt_buf[3], 2);
#endif
					if(u8pmbus_status != PMBusCP_NoSupp)
					{
						u8status = UsbPkt_Status_Success;
					}
				}
			}
			break;
		case UsbCmd_ReadByte:
			if((IsBscI2cAddr2(g_generic.rpt_buf[1]) == true) &&
				(IsBscI2cAddr2(g_generic.rpt_buf[3]&0xFE) == true))
			{
#if (BAIDU_BT)
				u8pmbus_status = ParseBscRdCmdSup(g_generic.rpt_buf[2], &g_generic.rpt_buf[2], &u8bytecnt);
				if(u8pmbus_status != PMBusCP_NoSupp)
				{
					u8status = UsbPkt_Status_Success;
				}
#endif /* BAIDU_BT */
			}
			else
			{
				i = GetDeviceAddressIndex(g_generic.rpt_buf[1], 0x00);
				j = GetDeviceAddressIndex(g_generic.rpt_buf[3], 0x01);
				if((i < BBU_DEV_NUM) && (i==j))
				{
					u8pmbus_status = ParseBbuRdCmdSup(i, g_generic.rpt_buf[2], &g_generic.rpt_buf[2], &u8bytecnt);
					if(u8pmbus_status != PMBusCP_NoSupp)
					{
						u8status = UsbPkt_Status_Success;
					}
				}
			}
			break;
		case UsbCmd_ReadWord:
			i = GetDeviceAddressIndex(g_generic.rpt_buf[1], 0x00);
			j = GetDeviceAddressIndex(g_generic.rpt_buf[3], 0x01);
			if((i < BBU_DEV_NUM) && (i==j))
			{
				u8pmbus_status = ParseBscRdCmdSup(g_generic.rpt_buf[2], &g_generic.rpt_buf[2], &u8bytecnt);
				if(u8pmbus_status == PMBusCP_NoSupp)
				{
					u8pmbus_status = ParseBbuRdCmdSup(i, g_generic.rpt_buf[2], &g_generic.rpt_buf[2], &u8bytecnt);
				}

				if(u8pmbus_status != PMBusCP_NoSupp)
				{
					u8status = UsbPkt_Status_Success;
				}
			}
			break;
		case UsbCmd_ProCall:

			break;
		case UsbCmd_BlockWr:
			if(IsBscI2cAddr2(g_generic.rpt_buf[1]) == true)
			{
#if (BAIDU_BT)
				u8pmbus_status = ParseBscWrCmdSup(g_generic.rpt_buf[1], g_generic.rpt_buf[2], &g_generic.rpt_buf[4], g_generic.rpt_buf[3]);
				if(u8pmbus_status != PMBusCP_NoSupp)
				{
					u8status = UsbPkt_Status_Success;
				}
#endif /* BAIDU_BT */
			}
			else
			{
				i = GetDeviceAddressIndex(g_generic.rpt_buf[1], 0x00);
				if(i < BBU_DEV_NUM)
				{
#if (BAIDU_BT)
					u8pmbus_status = ParseBbuWrCmdPushWrData(i, g_generic.rpt_buf[2], &g_generic.rpt_buf[4], g_generic.rpt_buf[3]);

#else
					u8pmbus_status = ParseBbuWrCmdSup(i, g_generic.rpt_buf[2], &g_generic.rpt_buf[4], g_generic.rpt_buf[3]);
#endif



					if(u8pmbus_status != PMBusCP_NoSupp)
					{
						u8status = UsbPkt_Status_Success;
					}
				}
				else
				{
#if (LITEON_BT)
					if((g_generic.rpt_buf[1] == 0) && (IsBbuBtldBlockWrCmdSup(g_generic.rpt_buf[2], g_generic.rpt_buf[3]) == true))
					{
						u8pmbus_status = ParseBbuBtldWrCmdSup((u16_t)g_generic.rpt_buf[1], g_generic.rpt_buf[2], &g_generic.rpt_buf[4], g_generic.rpt_buf[3]);
						if(u8pmbus_status != PMBusCP_NoSupp)
						{
							ActivateBbuBtldLock(g_generic.rpt_buf[2]);
							u8status = UsbPkt_Status_Success;
						}
					}
#endif /* LITEON_BT */
				}
			}
			break;
		case UsbCmd_BlockRd:
			i = GetDeviceAddressIndex(g_generic.rpt_buf[1], 0x00);
			j = GetDeviceAddressIndex(g_generic.rpt_buf[3], 0x01);
			if((i < BBU_DEV_NUM) && (i==j))
			{
				u8pmbus_status = ParseBscRdCmdSup(g_generic.rpt_buf[2], &g_generic.rpt_buf[3], &u8bytecnt);
				if(u8pmbus_status == PMBusCP_NoSupp)
				{
					u8pmbus_status = ParseBbuRdCmdSup(i, g_generic.rpt_buf[2], &g_generic.rpt_buf[3], &u8bytecnt);
				}

				if(u8pmbus_status != PMBusCP_NoSupp)
				{
					g_generic.rpt_buf[2] = u8bytecnt;
					u8status = UsbPkt_Status_Success;
				}
			}
			break;
		case UsbCmd_BWrBRdProCall:
			//bsc firmware upgrade
			if((IsBscI2cAddr2(g_generic.rpt_buf[1]) == true) &&
				(IsBscI2cAddr2(g_generic.rpt_buf[4]&0xFE) == true))
			{
#if (LITEON_BT)
				u8status = UsbBootBWrBrdProcCallComRxProcess(&g_generic.rpt_buf[0], &u8bytecnt);
				g_generic.rpt_buf[2] = u8bytecnt;
#endif /* LITEON_BT */
			}
			else
			{
				//bbu pm bus
				i = GetDeviceAddressIndex(g_generic.rpt_buf[1], 0x00);
				j = GetDeviceAddressIndex(g_generic.rpt_buf[4], 0x01);
				if((i < BBU_DEV_NUM) && (i==j))
				{
					if((g_generic.rpt_buf[2] == PMBusCmd_PagePlusRd) && (g_generic.rpt_buf[3] == 2))
					{
						u8pmbus_status = ParseBbuRdCmdSup(i, g_generic.rpt_buf[6], &g_generic.rpt_buf[3], &u8bytecnt);
						if(u8pmbus_status != PMBusCP_NoSupp)
						{
							g_generic.rpt_buf[2] = u8bytecnt;
							u8status = UsbPkt_Status_Success;
						}

					}
					else if((g_generic.rpt_buf[2] == PMBusCmd_Query) && (g_generic.rpt_buf[3] == 1))
					{
						GetBscQueryDataFormat(g_generic.rpt_buf[6], &g_generic.rpt_buf[3]);
						g_generic.rpt_buf[2] = 1;
						u8status = UsbPkt_Status_Success;

					}
#if (LITEON_BT)
					else if(IsBbuBtldrBWrBRdProCallCmdSup(g_generic.rpt_buf[2], g_generic.rpt_buf[3]) == true)
					{
						u8pmbus_status = ParseBbuBtldWrCmdSup((u16_t)g_generic.rpt_buf[1], g_generic.rpt_buf[2], &g_generic.rpt_buf[5], g_generic.rpt_buf[3]);
						u8pmbus_status = ParseBbuBtldRdCmdSup((u16_t)g_generic.rpt_buf[1], g_generic.rpt_buf[2], &g_generic.rpt_buf[3], &u8bytecnt);
						if(u8pmbus_status != PMBusCP_NoSupp)
						{
							ActivateBbuBtldLock(g_generic.rpt_buf[2]);
							g_generic.rpt_buf[2] = u8bytecnt;
							u8status = UsbPkt_Status_Success;
						}
					}
#endif /* LITEON_BT */
					else
					{

					}

				}
			}
			break;

		case UsbCmd_GetBbuAddress:
			u16DevIndex = GetPresentDeviceIndex();

			#if USB_ZOEY_DEBUG
			if (u8gldev_step == 0)
			{
				u16DevIndex = 0x00ff;	//test
				tsBBU_Dev[0].tnStateBBU.u16All = 0x0002;
				tsBBU_Dev[1].tnStateBBU.u16All = 0x0008;
				u8gldev_step = 1;
			}
			else if (u8gldev_step == 1)
			{
				u16DevIndex = 0x00ff;	//test
				tsBBU_Dev[0].tnStateBBU.u16All = 0x0008;
				tsBBU_Dev[1].tnStateBBU.u16All = 0x0002;
				u8gldev_step = 0;
			}
			else if (u8gldev_step == 2)
			{
				u16DevIndex = 0x00ff;	//test
				u8gldev_step = 3;
			}
			else if (u8gldev_step == 3)
			{
				u16DevIndex = 0x00ff;	//test
				u8gldev_step = 4;
			}
			else if (u8gldev_step == 4)
			{
				u16DevIndex = 0x00ff;	//test
				u8gldev_step = 0;
			}
			else if (u8gldev_step == 5)
			{
				u16DevIndex = 0x00ff;	//test
				u8gldev_step = 6;
			}
			else if (u8gldev_step == 6)
			{
				u16DevIndex = 0x00ff;	//test
				u8gldev_step = 0;
			}


			#endif

			for(i=0, j=0; i<BBU_DEV_NUM; i++)
    		{
    		    if((u16DevIndex >> i) & 0x0001)
    		    {
    		    	g_generic.rpt_buf[3+j] = GetPresentDeviceAddress(i);
    		    	j += 1;
    		    }
    		}
			g_generic.rpt_buf[2] = j;
			u8status = UsbPkt_Status_Success;

			break;

		case UsbCmd_GetBbuUrgentPMBus:
			i = GetDeviceAddressIndex(g_generic.rpt_buf[1], 0x00);
			if(i < BBU_DEV_NUM)
			{
				ParseBscUrgentRdCmdSup(i, &g_generic.rpt_buf[2], &g_generic.rpt_buf[3]);
				u8status = UsbPkt_Status_Success;
				//TURN_TGL_MTEST();
			}

			break;

		case UsbCmd_GetBscInfor:
			ParseBscInforRdCmdSup(&g_generic.rpt_buf[2], &g_generic.rpt_buf[3]);
			u8status = UsbPkt_Status_Success;
			break;

		case UsbCmd_GetBscLabel:
			ParseBscLabelRdCmdSup(&g_generic.rpt_buf[2], &g_generic.rpt_buf[3]);
			u8status = UsbPkt_Status_Success;
			break;

		default:

			break;

	}
	g_generic.rpt_buf[0] = u8usbCmd | 0x80;
	g_generic.rpt_buf[1] = u8status;

}

/******************************************************************************
 *
 *    @name        hid_generic_app_callback
 *
 *    @brief       This function handles the callback
 *
 *    @param       handle : handle to Identify the controller
 *    @param       event_type : value of the event
 *    @param       val : gives the configuration value
 *
 *    @return      None
 *
 *****************************************************************************/
void hid_generic_app_callback(uint8_t event_type, void* val,void* arg)
{

	switch(event_type)
    {
        case USB_DEV_EVENT_BUS_RESET:
            g_generic.hid_generic_attach = FALSE;
            break;
        case USB_DEV_EVENT_ENUM_COMPLETE:
            g_generic.hid_generic_attach = TRUE;
            (void)USB_Class_HID_Recv_Data(g_generic.app_handle, HID_GENERIC_ENDPOINT_OUT,
                g_generic.rpt_buf, GENERIC_BUFF_SIZE);
            break;
        case USB_DEV_EVENT_ERROR:
            /* user may add code here for error handling
               NOTE : val has the value of error from h/w*/

            break;
        default:
            break;
    }
    return;
}

/******************************************************************************
 *
 *    @name        hid_generic_app_param_callback
 *
 *    @brief       This function handles the callback for Get/Set report req
 *
 *    @param       request  :  request type
 *    @param       value    :  give report type and id
 *    @param       data     :  pointer to the data
 *    @param       size     :  size of the transfer
 *
 *    @return      status
 *                  USB_OK  :  if successful
 *                  else return error
 *
 *****************************************************************************/
uint8_t hid_generic_app_param_callback
(
    uint8_t request,
    uint16_t value,
    uint8_t ** data,
    uint32_t* size,
    void* arg
)
{
    uint8_t error = USB_OK;
    uint8_t index = (uint8_t)((request - 2) & USB_HID_REQUEST_TYPE_MASK);

    u8_t i, j, u8bytecnt;
    u16_t u16DevIndex;

    if (value == USB_REQ_VAL_INVALID)
    {
        switch(request)
        {
        case USB_DEV_EVENT_SEND_COMPLETE:
            (void)USB_Class_HID_Recv_Data(g_generic.app_handle, HID_GENERIC_ENDPOINT_OUT,
                g_generic.rpt_buf, GENERIC_BUFF_SIZE);
            break;

        case USB_DEV_EVENT_DATA_RECEIVED:
        	usb_hid_packet_received();

            (void)USB_Class_HID_Send_Data(g_generic.app_handle, HID_GENERIC_ENDPOINT_IN,
                g_generic.rpt_buf, GENERIC_BUFF_SIZE);


            break;

        default:
            break;
        }
        return error;
    }
    /* index == 0 for get/set idle, index == 1 for get/set protocol */
    *size = 0;
    /* handle the class request */
    switch(request)
    {
        case USB_HID_GET_REPORT_REQUEST :
            *data = &g_generic.rpt_buf[0]; /* point to the report to send */
            *size = GENERIC_BUFF_SIZE; /* report size */
            break;

        case USB_HID_SET_REPORT_REQUEST :
            for(index = 0; index < GENERIC_BUFF_SIZE ; index++)
            {   /* copy the report sent by the host */
                //g_generic.rpt_buf[index] = *(*data + index);
            }
            break;

        case USB_HID_GET_IDLE_REQUEST :
            /* point to the current idle rate */
            *data = &g_generic.app_request_params[index];
            *size = REQ_DATA_SIZE;
            break;

        case USB_HID_SET_IDLE_REQUEST :
            /* set the idle rate sent by the host */
            g_generic.app_request_params[index] =(uint8_t)((value & MSB_MASK) >>
                HIGH_BYTE_SHIFT);
            break;

        case USB_HID_GET_PROTOCOL_REQUEST :
            /* point to the current protocol code
               0 = Boot Protocol
               1 = Report Protocol*/
            *data = &g_generic.app_request_params[index];
            *size = REQ_DATA_SIZE;
            break;

        case USB_HID_SET_PROTOCOL_REQUEST :
            /* set the protocol sent by the host
               0 = Boot Protocol
               1 = Report Protocol*/
               g_generic.app_request_params[index] = (uint8_t)(value);
               break;
    }
    return error;
}

/****************************************************************************
*	name        : Init_Usb
*	description : Initial usb function
*	return      : none
****************************************************************************/
void Init_Usb(void)
{
	  hid_config_struct_t   config_struct;

	    /* initialize the Global Variable Structure */
	    OS_Mem_zero(&g_generic, sizeof(hid_generic_struct_t));
	    OS_Mem_zero(&config_struct, sizeof(hid_config_struct_t));

	#if (OS_ADAPTER_ACTIVE_OS == OS_ADAPTER_MQX)
	    g_generic.rpt_buf = (uint8_t*)OS_Mem_alloc_uncached_align(GENERIC_BUFF_SIZE, 32);
	    if(NULL == g_generic.rpt_buf)
	    {
	        USB_PRINTF("\nMalloc error in Init_Usb\n");
	        return;
	    }
	    OS_Mem_zero(g_generic.rpt_buf,GENERIC_BUFF_SIZE);
	#endif
	    /* Initialize the USB interface */
	//    USB_PRINTF("begin to test hid generic\r\n");
	//    printf("begin to test hid generic\r\n");
	    config_struct.hid_application_callback.callback = hid_generic_app_callback;
	    config_struct.hid_application_callback.arg = &g_generic.app_handle;
	    config_struct.class_specific_callback.callback = hid_generic_app_param_callback;
	    config_struct.class_specific_callback.arg = &g_generic.app_handle;
	    config_struct.desc_callback_ptr = &g_desc_callback;

	    USB_Class_HID_Init(CONTROLLER_ID, &config_struct, &g_generic.app_handle);

}
/****************************************************************************
*	name        : DeInit_Usb
*	description : DeInitial usb function
*	return      : none
****************************************************************************/
void DeInit_Usb(void)
{
	USB_Class_HID_Deinit(g_generic.app_handle);
}
/****************************************************************************
*	name        : Init_Usb
*	description : Initial usb function
*	return      : none
****************************************************************************/
bool GetSOF_Token(uint8_t u8flage)
{
	uint8_t u8istat;
	bool bitresult;

	u8istat = usb_hal_khci_get_interrupt_status(USB0_BASE);
	if (u8istat & u8flage)
	{
		return true;
	}
	else
	{
		return false;
	}

}

