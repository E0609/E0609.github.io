/****************************************************************************
*	file	MstPMBusApp.h
*	brief	The file includes subroutines for 24LCxxx
*
*	author allen.lee
* 	version 1.0
*		-	2014/04/21: initial version by allen lee
*
****************************************************************************/

#ifndef MSTPMBUSAPP_H_
#define MSTPMBUSAPP_H_

#include "define.h"
#include "SysTime.h"
#include "PMBusData.h"
#include "macro_define.h"

/****************************************************************************
*   Declared Macro
****************************************************************************/
#if (BAIDU_BT)
#define InVeBbuBt1ms			gtMcuTimer.u8Sys1ms
#endif /* BAIDU_BT */

#if (LITEON_BT)
#define BbuBtloder100ms	        gtMcuTimer.u8Sys100ms
#endif /* LITEON_BT */
//----------------------------------------------
#define MSTR_PMBUSAPP_TX_BUFF		64			//the buffer length is the same as the driver, must check the driver buffer!
#define MSTR_PMBUSAPP_RX_BUFF		64			//the buffer begins from byte number(block read), not include slave address(read)
#define PMBUS_PUSH_WR_NUM		    8

//----------------------------------------------------------------------------

/*******************************************************************************
* declare compile structure
*******************************************************************************/
typedef struct _sPMBusWrQueue_t {

    u8_t  u8CmdCode, u8TempWrLen, u8WrCmdProperty, u8TempWrAddrIndex;
    u8_t  pu8WrBuff[MSTR_PMBUSAPP_TX_BUFF];
    u16_t u16WrCmdIndex;

} sPMBusWrQueue_t;
//----------------------------------------------
#pragma pack(1)
typedef struct _sPMBusPushWrStr_t {

	u8_t u8WriteIndex, u8PushIndex;
	sPMBusWrQueue_t sWrQueue_t[PMBUS_PUSH_WR_NUM];

} sPMBusPushWrStr_t;
#pragma pack()
extern sPMBusPushWrStr_t tPMBusPushWrStr;
/****************************************************************************
*   Declared Export functions
****************************************************************************/
extern u8_t GetReSendMasterWrState(void);
extern u8_t GetMasterWrState(void);
extern u8_t GetActivateWrCmd(void);
extern u16_t GetPresentDeviceIndex(void);
extern u8_t GetPresentDeviceAddress(u8_t u8Index);
extern u8_t GetDeviceAddressIndex(u8_t u8Address, u8_t u8maskBit);
extern void MstPMBusReset(void);
extern void MstPMBusProcess(void);
extern void Init_MstPMBus(void);
extern u8_t GetBscQueryDataFormat(u8_t u8CmdCode, u8_t* pu8buff);
extern u8_t ParseBbuRdCmdSup(u8_t u8DevIndex, u8_t u8CmdCode, u8_t* pu8tgtbuff, u8_t* pu8len);
extern u8_t ParseBbuWrCmdSup(u8_t u8DevIndex, u8_t u8CmdCode, u8_t* pu8buff, u8_t u8len);

extern bool IsBscRdCmdSup(u8_t u8CmdCode);
extern u8_t ParseBscRdCmdSup(u8_t u8CmdCode, u8_t* pu8tgtbuff, u8_t* pu8len);
extern bool IsBscWrCmdSup(u8_t u8addr, u8_t u8CmdCode);
extern u8_t ParseBscWrCmdSup(u8_t u8addr, u8_t u8CmdCode, u8_t* pu8buff, u8_t u8len);
extern u8_t ParseBscUrgentRdCmdSup(u8_t u8DevIndex, u8_t* pu8len, u8_t* pu8buff);

#if (LITEON_BT)
extern bool IsBbuBtldrBWrBRdProCallCmdSup(u8_t u8Cmd, u8_t u8len);
extern bool IsBbuBtldBlockWrCmdSup(u8_t u8Cmd, u8_t u8len);
extern u8_t ParseBbuBtldWrCmdSup(u16_t u16Addr, u8_t u8CmdCode, u8_t* pu8buff, u8_t u8len);
extern u8_t ParseBbuBtldRdCmdSup(u16_t u16Addr, u8_t u8CmdCode, u8_t* pu8tgtbuff, u8_t* pu8len);
extern void ActivateBbuBtldLock(u8_t u8Cmd);
extern void BbuBtldLockTimeout(void);
#endif /* LITEON_BT */

#if (BAIDU_BT)
extern u8_t  GetInVeBbuBtLock(void);
extern void InVeBbuBtLockTimeout(void);
#endif /* BAIDU_BT */

extern u8_t ParseBbuWrCmdPushWrData(u8_t u8DevIndex, u8_t u8CmdCode, u8_t* pu8buff, u8_t u8len);
extern void SlvPushReSendWriteProcess(void);
extern void SlvPushWriteProcess(void);
#endif /* MSTPMBUSAPP_H_ */

