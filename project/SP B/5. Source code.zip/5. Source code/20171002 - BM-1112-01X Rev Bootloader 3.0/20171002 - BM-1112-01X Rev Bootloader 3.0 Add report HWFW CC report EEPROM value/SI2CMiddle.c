/*******************************************************************************
* file				SI2CMiddle.c
* brief				The file includes the function of slave I2C middle function.
* note
* author			vincent.liu
* version			01
* section History	2016/03/ - 1st release
*******************************************************************************/
#include "GenericTypeDefs.h"
#include "SI2CMiddle.h"
#include "SI2CDrv.h"
#include "PMBusApp.h"
#if QUANTA_BOOTLOADER < 0xff
#include "QTBootLoader.h"
#endif
/*******************************************************************************
* declare variable
*******************************************************************************/
sSI2CMiddleStr_t sSI2CMiddle;
/*******************************************************************************
*	brief 	initial slave I2C middle layer parameters
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
void SI2CMiddleInit(void)
{
	sSI2CMiddle.u8Protocol = Protocol_None;
	PMBusInit();
	#if QUANTA_BOOTLOADER < 0xff
	QTBootloaderCommInit();
	#endif
}
/*******************************************************************************
*	brief 	slave I2C middle layer receive data process
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
void SI2CMiddleRxProcess(void)
{
	sSI2CMiddle.u8RxIdx = GetSI2CRxIdx(sSI2CMiddle.pu8RxBuff, SM_RXBUFF_LEN);

	// handle unknown or driver/app rx buffer overwrite condition
	if((sSI2CMiddle.u8RxIdx == 0x00) || (sSI2CMiddle.u8RxIdx == 0xff))
	{
		ResetSI2CDrv();
		PMBusInit();
		#if QUANTA_BOOTLOADER < 0xff
		QTBootloaderCommInit();
		#endif
	}
	// check the cmd byte to determine the application protocol
	else if(sSI2CMiddle.u8RxIdx == 1)
	{
		#if QUANTA_BOOTLOADER == 0x00
		if((sSI2CMiddle.pu8RxBuff[sSI2CMiddle.u8RxIdx] == BTLDR_KEY) ||
		   (sSI2CMiddle.pu8RxBuff[sSI2CMiddle.u8RxIdx] == BTLDR_CMD_STATUS) ||
		   (sSI2CMiddle.pu8RxBuff[sSI2CMiddle.u8RxIdx] == BTLDR_MEMORYBLOCK))
		{
			sSI2CMiddle.u8Protocol = Protocol_QuantaBootloader;
			QTBootloaderRxParse();
		}
		else
		{
			sSI2CMiddle.u8Protocol = Protocol_PMBus;
			PMBusRxParse();
		}
		#elif QUANTA_BOOTLOADER == 0x01
		if((sSI2CMiddle.pu8RxBuff[sSI2CMiddle.u8RxIdx] == BTLDR_KEY) ||
		   (sSI2CMiddle.pu8RxBuff[sSI2CMiddle.u8RxIdx] == BTLDR_CMD_STATUS) ||
		   (sSI2CMiddle.pu8RxBuff[sSI2CMiddle.u8RxIdx] == BTLDR_MEMORYBLOCK) ||
		   (sSI2CMiddle.pu8RxBuff[sSI2CMiddle.u8RxIdx] == BTLDR_PRODUCTKEY) ||
		   (sSI2CMiddle.pu8RxBuff[sSI2CMiddle.u8RxIdx] == BTLDR_IMAGECKECKSUM))
		{
			sSI2CMiddle.u8Protocol = Protocol_QuantaBootloader;
			QTBootloaderRxParse();
		}
		else
		{
			sSI2CMiddle.u8Protocol = Protocol_PMBus;
			PMBusRxParse();
		}
		#else
		sSI2CMiddle.u8Protocol = Protocol_PMBus;
		PMBusRxParse();
		#endif
	}
	// handle the data bytes
	else
	{
		#if QUANTA_BOOTLOADER < 0xff
		if(sSI2CMiddle.u8Protocol == Protocol_QuantaBootloader)
		{
			QTBootloaderRxParse();
		}
		else if(sSI2CMiddle.u8Protocol == Protocol_PMBus)
		{
			PMBusRxParse();
		}
		#else
		if(sSI2CMiddle.u8Protocol == Protocol_PMBus)
		{
			PMBusRxParse();
		}
		#endif
	}
}
/*******************************************************************************
*	brief 	slave I2C middle layer transmit data process
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
void SI2CMiddleTxProcess(void)
{
	#if QUANTA_BOOTLOADER < 0xff
	if(sSI2CMiddle.u8Protocol == Protocol_QuantaBootloader)
	{
		QTBootloaderTxParse();
	}
	else if(sSI2CMiddle.u8Protocol == Protocol_PMBus)
	{
		PMBusTxParse();
	}
	#else
	if(sSI2CMiddle.u8Protocol == Protocol_PMBus)
	{
		PMBusTxParse();
	}
	#endif
}
/*******************************************************************************
*	brief 	set the value to the corresponding variables if not support PEC for
*           (block) write operation
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
void SI2CMiddleMapRxData(void)
{
	#if QUANTA_BOOTLOADER < 0xff
		if(sSI2CMiddle.u8Protocol == Protocol_QuantaBootloader)
		{
			QTBootloaderMapRxData();
		}
		else if(sSI2CMiddle.u8Protocol == Protocol_PMBus)
		{
			PMBusMapRxData();
		}
	#else
		if(sSI2CMiddle.u8Protocol == Protocol_PMBus)
		{
			PMBusMapRxData();
		}
	#endif
}
/*******************************************************************************
* end of file
*******************************************************************************/
