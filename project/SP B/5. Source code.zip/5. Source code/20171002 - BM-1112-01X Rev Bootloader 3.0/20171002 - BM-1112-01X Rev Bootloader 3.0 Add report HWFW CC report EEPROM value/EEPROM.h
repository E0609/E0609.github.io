#ifndef __EEPROM_H__
#define __EEPROM_H__

#include <p24FJ64GA006.h>
#include "bms_Pin_Define.h"
#include "GenericTypeDefs.h"
#include "I2C.h"
#include "main.h"
#include "Discharge_control.h"
#include "Charge_control.h"
#include "Failure.h"

void EEPROM_Write(void);
void EEPROM_Read(void);
void EEPROM_Control(void);
void EEPROM_Failure_Write(void);
void EEPROM_Calibration_Write(void);
void EEPROM_Battery_Write(void);
void EEPROM_Cycle_Cnt_Write(void);
void EEPROM_Ambient_OTP_Write(void);
void EEPROM_SerialNumber_Write(void);
void EEPROM_BatteryNot_Write(void);
extern void EEPROM_Time_Minute_Write(void);
extern void EEPROM_Time_Minute_Read(void);



#define EEPROM_Address                    0xA0      // 1010000
#define EEPROM_Flag_Cmd                   0x01
#define EEPROM_Online_Duty_Cmd            0x03
#define EEPROM_Offline_Duty_Cmd           0x05
#define EEPROM_Protect_type_High_Cmd      0x07
#define EEPROM_Protect_type_Low_Cmd       0x09
#define EEPROM_Trim_Duty_Cmd              0x0B
#define EEPROM_Failure_Flag_Cmd           0x0D
#define EEPROM_Voltage_ADC_Cmd            0x11
#define EEPROM_Read_Battery_Cmd           0x13
#define EEPROM_Cycle_Cnt_Cmd              0x15
#define EEPROM_Ambient_OTP_Cmd            0x17
#define EEPROM_SerialNumber_Cmd           0x20
#define EEPROM_Time_Minute_Cmd            0x30      // 4 byte



typedef struct
{
  u16_t Flag;
  u16_t Online_Duty;
  u8_t  Online_Duty_H;
  u8_t  Online_Duty_L;
  u16_t Offline_Duty;
  u8_t  Offline_Duty_H;
  u8_t  Offline_Duty_L;
  u16_t Status_Word;
  u16_t Status_Vout;
  u16_t Status_Iout;
  u16_t Protection_Type_High;
  u8_t  Protection_Type_High_H;
  u8_t  Protection_Type_High_L;
  u16_t Protection_Type_Low;
  u8_t  Protection_Type_Low_H;
  u8_t  Protection_Type_Low_L;
  u16_t Trim_Duty;
  u8_t  Trim_Duty_L;
  u8_t  Trim_Duty_H;  
  u8_t  Failure_Flag; 
  u16_t Voltage_ADC_Gain;
  u8_t  Voltage_ADC_Gain_L;
  u8_t  Voltage_ADC_Gain_H;
  u16_t Read_Battery;
  u16_t Cycle_Cnt_Offset;
  u16_t Cycle_Cnt_Offset_L;
  u16_t Cycle_Cnt_Offset_H;
  u16_t Ambient_OTP_Flag;
  u32_t Time_Minute;
   

}EEPROM_Info_T;


extern EEPROM_Info_T EEPROM_Info;











#endif

