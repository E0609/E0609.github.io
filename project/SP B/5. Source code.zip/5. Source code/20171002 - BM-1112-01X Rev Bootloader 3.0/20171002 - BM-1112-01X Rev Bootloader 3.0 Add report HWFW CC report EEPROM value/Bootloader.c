/*******************************************************************************
* file				BootLoader.c
* brief				The file includes the function of bootloader.
* note
* author			vincent.liu
* version			01
* section History	2014/10/27 - 1st release
*******************************************************************************/
#include "Bootloader.h"
#include "CRC.h"
#include "PMBusApp.h"
#include <string.h>
#include <p24FJ64GA006.h>
/*******************************************************************************
* declare variable
*******************************************************************************/
//=====================================
//bootloader data structure
//=====================================
sBootloaderStr_t gtBootStruct;
u16_t u16BootPassword __attribute__((address(0x27fe)));
u16_t u16BootPassword __attribute__((persistent));
//=====================================
//PIB default data(in ram)
//=====================================
sPIBStr_t tDefaultPIB =
{
	{0xC0, 0x6C, 0x3A, 0x7B, 0xB2, 0x2F, 0x5D, 0x92},	// fixed start pattern
	{0x00, 0x01},										// PIB version
	{0x06},												// device type
	{0x01},												// mcu type
	{0x00, 0x00, 0x00, 0x58, 0x31, 0x30,				// code id
	 0x32, 0x31, 0x31, 0x31, 0x4D, 0x42},
	{0x00, 0x58, 0x00, 0x00},							// start address
	{0xFF, 0x4F, 0x01, 0x00},							// end address
	{0x64, 0x00},										// erase time
	{0x03, 0x00},										// program time
	{0x10, 0x00},										// program length
	{0xFF},												// buffer_fill value
	{0x00, 0x00, 0x00, 0x00, 0x00, 0x00,				// reserved data
	 0x00, 0x00, 0x00, 0x00, 0x00},
	{0x32, 0x05},										// checksum
	{0x40, 0x0E, 0x75, 0x1F, 0x71, 0x5E, 0x3A, 0x29}	// fixed stop pattern
};
//=====================================
//PIB default data(in program memory)
//=====================================
#ifndef BOOT_AREA
u8_t pu8AppPassword[2] __attribute__(( space(prog), address(PASSWORD_APP_STARTADDR))) = {0x55,0xaa};

sPIBStr_t tFlashPIB  __attribute__(( space(prog), address(IMAGE_PIB_STARTADDR))) =
{
	{0xC0, 0x6C, 0x3A, 0x7B, 0xB2, 0x2F, 0x5D, 0x92},	// fixed start pattern
	{0x00, 0x01},										// PIB version
	{0x06},												// device type
	{0x01},												// mcu type
	{0x00, 0x00, 0x00, 0x58, 0x31, 0x30,				// code id
	 0x32, 0x31, 0x31, 0x31, 0x4D, 0x42},
	{0x00, 0x58, 0x00, 0x00},							// start address
	{0xFF, 0x4F, 0x01, 0x00},							// end address
	{0x64, 0x00},										// erase time
	{0x03, 0x00},										// program time
	{0x10, 0x00},										// program length
	{0xFF},												// buffer_fill value
	{0x00, 0x00, 0x00, 0x00, 0x00, 0x00,				// reserved data
	 0x00, 0x00, 0x00, 0x00, 0x00},
	{0x32, 0x05},										// checksum
	{0x40, 0x0E, 0x75, 0x1F, 0x71, 0x5E, 0x3A, 0x29}	// fixed stop pattern
};
#endif
/*******************************************************************************
*	brief 	build primary ID number information
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
u8_t GetPriIDNum(void)
{
	return((u8_t)gtBootStruct.tPriInform.u16ExistIDNum);
}
/*******************************************************************************
*	brief 	build primary ID information
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
void BuildPriIDInform(void)
{
	memcpy(gtBootStruct.pu8TxBuff, (u8_t*) &gtBootStruct.tPriInform, 2 + gtBootStruct.tPriInform.u16ExistIDNum*2);
}
/*******************************************************************************
*	brief 	Build the response data for bootloader PMBus commands F0,F1,F2,F5,
*			F6,F7
*	para1:	source1 data pointer
*	para2:	source2 data pointer
*   para3:	destination data pointer
*	para4: 	the length of source1
*   para5: 	the length of source2
*	return: 0:success, 1:error, the length is over the limit of the tx buffer
*******************************************************************************/
u8_t BuildTxBuff(u8_t* pu8Source1,u8_t* pu8Source2, u8_t* pu8TxBuff, u8_t u8Length1, u8_t u8Length2)
{
	u16_t i, j, k;

	*(pu8TxBuff + 0) = gtBootStruct.tSecInform.u16Status.u16Half.u8LowByte;		// build status in transmit buffer internal
	*(pu8TxBuff + 1) = gtBootStruct.tSecInform.u16Status.u16Half.u8HighByte;
	pu8TxBuff = pu8TxBuff + 2;

	j = u8Length1;																// data length of source1
	k = u8Length1 + u8Length2;													// data length of source1 & source2

	if((k+2) > BOOTAPP_TX_BUFF)
	{
		return 1;
	}
	else
	{
		for(i = 0;i < j;i++)													// build source1 data
		{
			*(pu8TxBuff+i) = *(pu8Source1+i);
		}

		for(i = j;i< k;i++)														// build source2 data
		{
			*(pu8TxBuff+i) = *(pu8Source2+i-j);
		}

		return 0;
	}
}
/*******************************************************************************
*	brief 	communication data receive process
*	para1:	communication command
*	para2:	pointer to data buffer
*	return: none
*******************************************************************************/
void BootComRxProcess(u8_t u8Cmd, u8_t* pu8DataBuff)
{
	gtBootStruct.u8DeviceType = *pu8DataBuff;
	gtBootStruct.u8McuType = *(pu8DataBuff + 1);
	gtBootStruct.u8ModuleID = *(pu8DataBuff + 2);

	switch (u8Cmd)
	{
		case PMBusCmd_RdCodeID:
			memcpy(gtBootStruct.pu8RxBuff, pu8DataBuff, 15);       // copy codeID from PMBus Rxbuffer to boot Rxbuffer
			gtBootStruct.u8State = Task_VerifyCodeID;
			break;
		case PMBusCmd_RdMcuType:
			gtBootStruct.u8State = Task_CheckMcuType;
			break;
		case PMBusCmd_EnterBootMode:
			memcpy(gtBootStruct.pu8RxBuff, pu8DataBuff, 7);       // copy password from PMBus Rxbuffer to boot Rxbuffer
			gtBootStruct.u8State = Task_EnterBootMode;
			break;
		case PMBusCmd_EraseFlash:
			gtBootStruct.u8State = Task_EraseFlash;
			break;
		case PMBusCmd_WriteFlash:
			gtBootStruct.u8State = Task_WriteFlash;
			break;
		case PMBusCmd_McuReset:
			gtBootStruct.u8State = Task_McuReset;
			break;
		case PMBusCmd_RdStatus:
			gtBootStruct.u8State = Task_ReadStatus;
			break;
		case PMBusCmd_RdFileCrc:
			memcpy(gtBootStruct.pu8RxBuff, pu8DataBuff, 9);       // copy file parameter from PMBus Rxbuffer to boot Rxbuffer
			gtBootStruct.u8State = Task_VerifyFile;
			break;
		default:
			Nop();
			break;
	}
}
/*******************************************************************************
*	brief 	communication data transmit process
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
void BootComTxProcess(u8_t u8Cmd)
{
	if(u8Cmd == PMBusCmd_RdCodeID)
		BuildTxBuff(gtBootStruct.tPIBData.pu8CodeID, NULL, gtBootStruct.pu8TxBuff, 12, 0);
	else if(u8Cmd == PMBusCmd_RdMcuType)
		memcpy(gtBootStruct.pu8TxBuff, (u8_t*) &gtBootStruct.tSecInform, 4);
	else if(u8Cmd == PMBusCmd_EnterBootMode)
		BuildTxBuff((u8_t*) &gtBootStruct.u8CountdownTimer, NULL, gtBootStruct.pu8TxBuff, 1, 0);
	else if(u8Cmd == PMBusCmd_McuReset)
		BuildTxBuff(NULL, NULL, gtBootStruct.pu8TxBuff, 0, 0);
	else if(u8Cmd == PMBusCmd_RdStatus)
		BuildTxBuff(NULL, NULL, gtBootStruct.pu8TxBuff, 0, 0);
	else if(u8Cmd == PMBusCmd_RdFileCrc)
		BuildTxBuff((u8_t*) &gtBootStruct.u32ProgramBytes, (u8_t*) &gtBootStruct.u16FileCrc, gtBootStruct.pu8TxBuff, 4, 2);
}
/*******************************************************************************
*	brief 	re-count GoApp timer to stay in boot area
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
void ClrGoAppTimer(void)
{
	gtBootStruct.u8GoAppTimer = 0;
}
/*******************************************************************************
*	brief 	Initial PIB code
*	para1:	none
*	para2:	none
*	return: 0:PIB no error;1:PIB error
*******************************************************************************/
u8_t PibCodeInit(void)
{
	u8_t i;
	u8_t* pu8Ptr1;
	u8_t* pu8Ptr2;
	u16_t u16checksum;

	ReadFlash2Ram(IMAGE_PIB_STARTADDR, (u8_t*) &gtBootStruct.tPIBData, sizeof(sPIBStr_t));

	// check start pattern
	for(i = 0;i < 8;i++)
	{
		if(gtBootStruct.tPIBData.pu8StartPattern[i] != tDefaultPIB.pu8StartPattern[i])
			return 1;
	}

	// check stop pattern
	for(i = 0;i < 8;i++)
	{
		if(gtBootStruct.tPIBData.pu8StopPattern[i] != tDefaultPIB.pu8StopPattern[i])
			return 1;
	}

	// check PIB checksum
	pu8Ptr1 = (u8_t*) &gtBootStruct.tPIBData.pu16PIBVersion;
	pu8Ptr2 = (u8_t*) &gtBootStruct.tPIBData.pu8Checksum;
	u16checksum = gtBootStruct.tPIBData.pu8Checksum[0] + (gtBootStruct.tPIBData.pu8Checksum[1]<<8);

	while(pu8Ptr1 != pu8Ptr2)
	{
		u16checksum = u16checksum - *pu8Ptr1;
		pu8Ptr1++;
	}
	if(u16checksum != 0)
		return 1;

	// PIB no error
	return 0;
}
/*******************************************************************************
*	brief 	Check the boot password if exist or not
*	para1:	none
*	para2:	none
*	return: 1:exist;0:not exist
*******************************************************************************/
u8_t BootPasswordCheck(void)
{
	if(u16BootPassword == BOOT_PASSWORD)
		return 1;
	else
		return 0;
}
/*******************************************************************************
*	brief 	Write the boot password to flash
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
void WriteBootPassword(void)
{
	u16BootPassword = BOOT_PASSWORD;
}
/*******************************************************************************
*	brief 	Check the app password if exist or not
*	para1:	none
*	para2:	none
*	return: 1:exist;0:not exist
*******************************************************************************/
u8_t AppPasswordCheck(void)
{
	u8_t pu8Buffer[2];

	ReadFlash2Ram(PASSWORD_APP_STARTADDR, pu8Buffer, 2);

	if((pu8Buffer[0] == (APP_PASSWORD & 0xff)) && (pu8Buffer[1] == (APP_PASSWORD >> 8)))
		return 1;
	else
		return 0;
}
/*******************************************************************************
*	brief 	Write the app password to flash
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
void WriteAppPassword(void)
{
	u8_t pu8Buffer[2];

	pu8Buffer[0] = APP_PASSWORD & 0xff;
	pu8Buffer[1] = APP_PASSWORD >> 8;

	WriteRam2Flash(PASSWORD_APP_STARTADDR, pu8Buffer, 2);
}
/*******************************************************************************
*	brief 	Initial bootloader parameters
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
void BootloaderInit(void)
{
	gtBootStruct.u8State = Task_Idle;
	gtBootStruct.u32StartAddress = IMAGE_APP_STARTADDR;
	gtBootStruct.u32EndAddress = IMAGE_APP_ENDADDR;
	gtBootStruct.u8CountdownTimer = COUNTDOWN_TIME;
	gtBootStruct.u16FileCrc = 0xffff;
	gtBootStruct.tPriInform.u16McuBit = PRIMARY_MCU_BITS;
	gtBootStruct.tPriInform.u16ExistIDNum = PRIMARY_NUMBER;
	gtBootStruct.tSecInform.u16McuBit = SECONDARY_MCU_BITS;
	#ifdef BOOT_AREA
	gtBootStruct.tSecInform.u16Status.u16Bit.u1Mode = 1;
	#endif

	if(PibCodeInit())
		gtBootStruct.tPIBData = tDefaultPIB;

	#ifdef BOOT_AREA
	if(BootPasswordCheck())
	{
		u16BootPassword = 0;
	    gtBootStruct.nBootloaderFlag.u16Bit.u1BootStay = 1;
	}

	if(AppPasswordCheck())
	{
		gtBootStruct.nBootloaderFlag.u16Bit.u1AppExist = 1;
	}
	#endif

	#ifndef BOOT_AREA
	u16BootPassword = 0;
	#endif
}
/*******************************************************************************
*	brief 	Re-initial bootloader parameters when receive cmd F2h
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
void BootloaderReset(void)
{
	gtBootStruct.u8State = Task_Idle;
	gtBootStruct.nBootloaderFlag.u16Bit.u1EraseFalshExecuted = 0;
	gtBootStruct.nBootloaderFlag.u16Bit.u1WriteFalshExecuted = 0;
	gtBootStruct.nBootloaderFlag.u16Bit.u1VerifyFileExecuted = 0;
	gtBootStruct.nBootloaderFlag.u16Bit.u8ErrCounter = 0;

	gtBootStruct.u8McuResetTimer = 0;
	gtBootStruct.u8GoBootTimer = 0;

	gtBootStruct.u32StartAddress = IMAGE_APP_STARTADDR;
	gtBootStruct.u32EndAddress = IMAGE_APP_ENDADDR;
	gtBootStruct.u16AddrIndex = 0;

	gtBootStruct.u32ProgramBytes = 0;
	gtBootStruct.u16FileCrc = 0xffff;

	gtBootStruct.tSecInform.u16Status.u16All &= 0x8001;
}
/*******************************************************************************
*	brief 	Verify the code ID
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
void VerifyCodeID(void)
{
	u8_t i;

	for(i = 0;i < 12;i++)
	{
		if(gtBootStruct.pu8RxBuff[i+3] != gtBootStruct.tPIBData.pu8CodeID[i])
		{
			gtBootStruct.tSecInform.u16Status.u16Bit.u1CodeIDErr = 1;
			return;
		}
	}
	
	gtBootStruct.tSecInform.u16Status.u16Bit.u1CodeIDErr = 0;
}
/*******************************************************************************
*	brief 	Verify the password
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
void EnterBootMode(void)
{
	u32_t u32Temp;

	u32Temp = (u32_t)gtBootStruct.pu8RxBuff[3] + ((u32_t)gtBootStruct.pu8RxBuff[4] << 8) +			// calaculate password from system
	          ((u32_t)gtBootStruct.pu8RxBuff[5] << 16) + ((u32_t)gtBootStruct.pu8RxBuff[6] << 24);

	if(u32Temp == ENTERBOOT_PASSWORD)

	{
        #ifdef BOOT_AREA
		if(gtBootStruct.nBootloaderFlag.u16Bit.u1BootStay == 0)
		{
			ClrGoAppTimer();
			gtBootStruct.nBootloaderFlag.u16Bit.u1BootStay = 1;
		}
		#endif

		gtBootStruct.tSecInform.u16Status.u16Bit.u1PasswordErr = 0;
		#ifndef BOOT_AREA
		gtBootStruct.u8GoBootTimer = GOBOOT_TIME;
		#endif
	}
	else
	{
		gtBootStruct.tSecInform.u16Status.u16Bit.u1PasswordErr = 1;
	}
}
/*******************************************************************************
*	brief 	Erase App image area
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
void EraseFlash(void)
{
	u8_t i;
	u8_t u8PageNumber;
	u16_t u16Temp;
	u32_t u32StartAddr, u32EndAddr;

	u32StartAddr = (u32_t)gtBootStruct.pu8RxBuff[3] + ((u32_t)gtBootStruct.pu8RxBuff[4] << 8) +			// get app start address
	               ((u32_t)gtBootStruct.pu8RxBuff[5] << 16) + ((u32_t)gtBootStruct.pu8RxBuff[6] << 24);
	u32EndAddr = (u32_t)gtBootStruct.pu8RxBuff[7] + ((u32_t)gtBootStruct.pu8RxBuff[8] << 8) +			// get app end address
	               ((u32_t)gtBootStruct.pu8RxBuff[9] << 16) + ((u32_t)gtBootStruct.pu8RxBuff[10] << 24);

	u32StartAddr = u32StartAddr >> 1;      // transfer byte address to word address
	u32EndAddr = (u32EndAddr + 1) >> 1;	   // transfer byte address to word address

	if(u32StartAddr == IMAGE_APP_STARTADDR)
	{
		u16Temp = (u32EndAddr - u32StartAddr) % ERASE_PAGE_SIZE;
		u8PageNumber = (u32EndAddr - u32StartAddr)/ERASE_PAGE_SIZE;
		if(u16Temp != 0)
		{
			u8PageNumber += 1;
		}
		gtBootStruct.u32StartAddress = u32StartAddr;
		gtBootStruct.u32EndAddress = u32EndAddr;

		for(i = 0;i < u8PageNumber;i++)
		{
			EraseFlashPage(u32StartAddr);
			u32StartAddr += ERASE_PAGE_SIZE;
		}
		
		gtBootStruct.tSecInform.u16Status.u16Bit.u1EraseErr = 0;
	}
	else
	{
		gtBootStruct.tSecInform.u16Status.u16Bit.u1EraseErr = 1;
		gtBootStruct.nBootloaderFlag.u16Bit.u8ErrCounter++;
	}

	gtBootStruct.nBootloaderFlag.u16Bit.u1EraseFalshExecuted = 1;
}
/*******************************************************************************
*	brief 	Write new image to App image area
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
void WriteFlash(void)
{
#ifdef WRITE_FLASH_ROW

	u32_t u32StartAddr;

	if((gtBootStruct.nBootloaderFlag.u16Bit.u1EraseFalshExecuted == 1) &&
	   (gtBootStruct.tSecInform.u16Status.u16Bit.u1EraseErr == 0))
	{
		u32StartAddr = (u32_t)gtBootStruct.pu8RxBuff[3] + ((u32_t)gtBootStruct.pu8RxBuff[4] << 8) +			// get byte start address
					   ((u32_t)gtBootStruct.pu8RxBuff[5] << 16) + ((u32_t)gtBootStruct.pu8RxBuff[6] << 24);

		u32StartAddr = u32StartAddr >> 1;      // transfer byte start address to word start address

		if((u32StartAddr != gtBootStruct.u32StartAddress) || (u32StartAddr >= gtBootStruct.u32EndAddress))
		{
			gtBootStruct.tSecInform.u16Status.u16Bit.u1AddressErr = 1;
			gtBootStruct.nBootloaderFlag.u16Bit.u8ErrCounter++;
		}
		else
		{
			gtBootStruct.u16FileCrc = CalCRC16(gtBootStruct.u16FileCrc,&gtBootStruct.pu8RxBuff[7], TRANSMIT_BYTENUM, 0);
			if(u32StartAddr == PASSWORD_APP_STARTADDR)
			{
				//memset(&gtBootStruct.pu8RxBuff[7], 0xff, TRANSMIT_BYTENUM);
				memset(&gtBootStruct.pu8RxBuff[7], 0xff, 16);
			}
			memcpy(&gtBootStruct.pu8FlashBuff[gtBootStruct.u16AddrIndex*2], &gtBootStruct.pu8RxBuff[7], TRANSMIT_BYTENUM);

			u32StartAddr += TRANSMIT_WORDNUM;
			gtBootStruct.u16AddrIndex += TRANSMIT_WORDNUM;
			gtBootStruct.u32StartAddress += TRANSMIT_WORDNUM;
			gtBootStruct.u32ProgramBytes += TRANSMIT_BYTENUM;

			if(gtBootStruct.u16AddrIndex == WRITE_ROW_SIZE)
			{
				gtBootStruct.u16AddrIndex = 0x00;
				WriteFlashRow((u32StartAddr - WRITE_ROW_SIZE), &gtBootStruct.pu8FlashBuff[0]);

				if(VerifyFlashRow((u32StartAddr - WRITE_ROW_SIZE), &gtBootStruct.pu8FlashBuff[0]))
				{
					gtBootStruct.tSecInform.u16Status.u16Bit.u1FlashErr = 1;
					gtBootStruct.nBootloaderFlag.u16Bit.u8ErrCounter++;
				}
				else
				{
					gtBootStruct.tSecInform.u16Status.u16Bit.u1FlashErr = 0;
				}
			}

			gtBootStruct.tSecInform.u16Status.u16Bit.u1AddressErr = 0;
		}
		
		gtBootStruct.nBootloaderFlag.u16Bit.u1WriteFalshExecuted = 1;
	}
#else
	
	u8_t i, j;
	u32_t u32Temp, u32StartAddr;

	if((gtBootStruct.nBootloaderFlag.u16Bit.u1EraseFalshExecuted == 1) && 
	   (gtBootStruct.tSecInform.u16Status.u16Bit.u1EraseErr == 0))
	{
		u32StartAddr = (u32_t)gtBootStruct.pu8RxBuff[3] + ((u32_t)gtBootStruct.pu8RxBuff[4] << 8) +			// get byte start address
					   ((u32_t)gtBootStruct.pu8RxBuff[5] << 16) + ((u32_t)gtBootStruct.pu8RxBuff[6] << 24);

		u32StartAddr = u32StartAddr >> 1;      // transfer byte start address to word start address

		if((u32StartAddr < gtBootStruct.u32StartAddress) || (u32StartAddr >= gtBootStruct.u32EndAddress))      // check start address  range
		{
			gtBootStruct.tSecInform.u16Status.u16Bit.u1AddressErr = 1;
			gtBootStruct.nBootloaderFlag.u16Bit.u8ErrCounter++;
		}
		else
		{
			gtBootStruct.u16FileCrc = CalCRC16(gtBootStruct.u16FileCrc,&gtBootStruct.pu8RxBuff[7], TRANSMIT_BYTENUM, 0);
			gtBootStruct.u32ProgramBytes += TRANSMIT_BYTENUM;

			for(i = 0;i < TRANSMIT_INSNUM;i++)      // calculate the number of instruction
			{
				if((u32StartAddr + i*2) > gtBootStruct.u32EndAddress)
				{
					i += 1;
					break;
				}
			}

			for(j = 0;j < i;j++)
			{
				u32Temp = u32StartAddr + j*2;

				if(u32Temp != PASSWORD_APP_STARTADDR)
				{
					WriteFlashIns(u32Temp, &gtBootStruct.pu8RxBuff[7 + j*4], 4);

					if(VerifyFlashIns(u32Temp, &gtBootStruct.pu8RxBuff[7 + j*4], 4))
					{
						gtBootStruct.tSecInform.u16Status.u16Bit.u1FlashErr = 1;
						gtBootStruct.nBootloaderFlag.u16Bit.u8ErrCounter++;
					}
					else
					{
						gtBootStruct.tSecInform.u16Status.u16Bit.u1FlashErr = 0;
					}
				}

			}
			gtBootStruct.tSecInform.u16Status.u16Bit.u1AddressErr = 0;
		}
		
		gtBootStruct.nBootloaderFlag.u16Bit.u1WriteFalshExecuted = 1;
	}

#endif
}
/*******************************************************************************
*	brief 	Verify the hex file, include crc16 checksum and program bytes
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
void VerifyFile(void)
{
	u16_t u16Temp;
	u32_t u32Temp;

	if((gtBootStruct.nBootloaderFlag.u16Bit.u1WriteFalshExecuted == 1) &&
	   (gtBootStruct.tSecInform.u16Status.u16Bit.u1AddressErr == 0) &&
	   (gtBootStruct.tSecInform.u16Status.u16Bit.u1FlashErr == 0))
	{
		u32Temp = (u32_t)gtBootStruct.pu8RxBuff[3] + ((u32_t)gtBootStruct.pu8RxBuff[4] << 8) +			// calaculate program bytes from system
				  ((u32_t)gtBootStruct.pu8RxBuff[5] << 16) + ((u32_t)gtBootStruct.pu8RxBuff[6] << 24);

		u16Temp = (u16_t)gtBootStruct.pu8RxBuff[7] + ((u16_t)gtBootStruct.pu8RxBuff[8] << 8);			// calaculate file crc from system

		if((gtBootStruct.u32ProgramBytes == u32Temp) && (gtBootStruct.u16FileCrc == u16Temp))
		{
			gtBootStruct.tSecInform.u16Status.u16Bit.u1FileErr = 0;
		}
		else
		{
			gtBootStruct.tSecInform.u16Status.u16Bit.u1FileErr = 1;
			gtBootStruct.nBootloaderFlag.u16Bit.u8ErrCounter++;
		}
		
		gtBootStruct.nBootloaderFlag.u16Bit.u1VerifyFileExecuted = 1;
	}
}
/*******************************************************************************
*	brief 	Reset MCU reset timer
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
void McuReset(void)
{
	if(gtBootStruct.nBootloaderFlag.u16Bit.u8ErrCounter == 0)
	{
		gtBootStruct.u8McuResetTimer = MCURESET_TIME;
	}
}
/*******************************************************************************
*	brief 	Execute bootloader task
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
void BootloaderProcess(void)
{
	switch (gtBootStruct.u8State)
	{
		case Task_Idle:
			Nop();
			break;
		//----------------------------------------------------------------------
		case Task_VerifyCodeID:
			VerifyCodeID();
			gtBootStruct.u8State = Task_Idle;
			break;
		//----------------------------------------------------------------------
		case Task_CheckMcuType:
			Nop();
			gtBootStruct.u8State = Task_Idle;
			break;
		//----------------------------------------------------------------------
		case Task_EnterBootMode:
			BootloaderReset();
			EnterBootMode();
			gtBootStruct.u8State = Task_Idle;
			break;
		//----------------------------------------------------------------------
		case Task_EraseFlash:
			#ifdef BOOT_AREA
			EraseFlash();
			#endif
			gtBootStruct.u8State = Task_Idle;
			break;
		//----------------------------------------------------------------------
		case Task_WriteFlash:
			#ifdef BOOT_AREA
			WriteFlash();
			#endif
			gtBootStruct.u8State = Task_Idle;
			break;
		//----------------------------------------------------------------------
		case Task_ReadStatus:
			Nop();
			gtBootStruct.u8State = Task_Idle;
			break;
		//----------------------------------------------------------------------
		case Task_VerifyFile:
			#ifdef BOOT_AREA
			VerifyFile();
			#endif
			gtBootStruct.u8State = Task_Idle;
			break;
		//----------------------------------------------------------------------
		case Task_McuReset:
			#ifdef BOOT_AREA
			McuReset();
			#endif
			gtBootStruct.u8State = Task_Idle;
			break;
		//----------------------------------------------------------------------
		default:
			Nop();
			break;
	}

}
/*******************************************************************************
*	brief 	Force device to go to a specific flash address
*	para1:	none
*	para2:	none
*	return: none
*******************************************************************************/
void GotoFlashAddr(u32_t u32FlashAddr)
{
	asm("goto %0" : : "r"(u32FlashAddr));
}
/*******************************************************************************
*	brief 	After bootloader finished, delay to reset device
*	para1:	none
*	para2:	none
*	return: none
*   note:   this function is only used in boot project
*******************************************************************************/
#ifdef BOOT_AREA
void BootDoneReset(void)
{
	if(gtBootStruct.u8McuResetTimer != 0)
	{
		gtBootStruct.u8McuResetTimer--;
		if(gtBootStruct.u8McuResetTimer == 0)
		{
			if(gtBootStruct.nBootloaderFlag.u16Bit.u1EraseFalshExecuted == 0)
			{
				asm("RESET");
			}
			else
			{
				if((gtBootStruct.nBootloaderFlag.u16Bit.u1WriteFalshExecuted == 1) &&
				   (gtBootStruct.nBootloaderFlag.u16Bit.u1VerifyFileExecuted == 1))
				{
					WriteAppPassword();
					asm("RESET");
				}
			}
		}
	}
}
#endif
/*******************************************************************************
*	brief 	Delay to go to app area
*	para1:	none
*	para2:	none
*	return: none
*   note:   this function is only used in boot project
*******************************************************************************/
#ifdef BOOT_AREA
void GotoApp(void)
{
	if((gtBootStruct.nBootloaderFlag.u16Bit.u1BootStay == 0) && (gtBootStruct.nBootloaderFlag.u16Bit.u1AppExist == 1))
	{
		gtBootStruct.u8GoAppTimer++;
		if(gtBootStruct.u8GoAppTimer == GOAPP_TIME)
		{
			//-----------------------------------------
			// user should turn off all the peripherals
			// and INTs here, need to be modified
			//-----------------------------------------
			T1CONbits.TON = 0;
            IEC0bits.T1IE = 0;
			IFS0bits.T1IF = 0;               
            T4CONbits.TON = 0;
            IEC1bits.T4IE = 0;
            IFS1bits.T4IF = 0;
            IEC3bits.SI2C2IE = 0;
			I2C2CONbits.I2CEN = 0;
			IFS3bits.SI2C2IF = 0;
			INTCON2bits.ALTIVT = 0;
			//-----------------------------------------
			GotoFlashAddr(IMAGE_APP_RESETADDR);
		}
	}
}
#endif
/*******************************************************************************
*	brief 	Delay to go to boot area
*	para1:	none
*	para2:	none
*	return: none
*   note:   this function is only used in app project
*******************************************************************************/
#ifndef BOOT_AREA
void GotoBoot(void)
{
	if(gtBootStruct.u8GoBootTimer != 0)
	{
		gtBootStruct.u8GoBootTimer--;
		if(gtBootStruct.u8GoBootTimer == 0)
		{
			WriteBootPassword();
			asm("RESET");
		}
	}
}
#endif
/*******************************************************************************
* end of file
*******************************************************************************/
