#include <p24FJ64GA006.h>
#include "bms_Pin_Define.h"
#include "GenericTypeDefs.h"
#include "I2C.h"
#include "Battery_status.h"
#include "Charge_control.h"
#include "Discharge_control.h"
#include "Failure.h"
#include "FW_Config.h"
#include "main.h"
#include "PMBusData.h"
#include "PMBus_status.h"
#include <string.h>
#include "Battery_status.h"
#include "EEPROM.h"





void Failure_detect(void)
{
  if(EEPROM_Info.Ambient_OTP_Flag == 1)
  {
    if(BBU_Info.Ambient_Temp > Expect_Ambient_OT_Warning)
    {
       Warning_type.bits.Ambient_OT_Warning = 1;
       u8StatusP0Temp = (u8StatusP0Temp | Status_Temperature_bits_OT_Warning);
       u8StatusP1Temp = (u8StatusP1Temp | Status_Temperature_bits_OT_Warning); 
       u16StatusP0Word = (u16StatusP0Word | Status_Word_bits_Temperature);
       u16StatusP1Word = (u16StatusP1Word | Status_Word_bits_Temperature);
    }
    else if(BBU_Info.Ambient_Temp < Ambient_OT_Recover_Threshold)
    {
       Warning_type.bits.Ambient_OT_Warning = 0;
       Failure_type.bits.Ambient_OTP = 0;              
    }

    if(BBU_Info.Ambient_Temp > Expect_Ambient_OT_Protection)
    {
//     SystemControl.bits.Flag_Failure = 1;
      if(Charger.state_Charging == 0 && Discharger.state_Discharging == 0)
      {
       Failure_type.bits.Ambient_OTP = 1;
       u8StatusP0Temp = (u8StatusP0Temp | Status_Temperature_bits_OT_Fault);
       u8StatusP1Temp = (u8StatusP1Temp | Status_Temperature_bits_OT_Fault);
      }
              
    }
    
  } 
}

void Discharger_Failure_Detect(void)
{
   if(BBU_Info.Iout > Expect_Output_OC_Protection)
   {
     Failure_type.bits.Discharger_Output_OCP = 1;
   }  

   if(BBU_Info.Vout_12V > Expect_Output_OV_Protection)
   {
     Failure_type.bits.Discharger_Output_OVP = 1;
   }

   if(Cell_Info.Voltage < Discharging_Cell_Cutoff_Voltage)
   {
     Failure_type.bits.Discharger_Cell_UVP = 1;
   }

   if(BBU_Info.BusVoltage < Expect_Output_UV_Protection)
   {
     Failure_type.bits.Discharger_Output_UVP = 1;
   }

   if(Cell_Info.Voltage > Discharging_Cell_OV_Protection_Threshold)
   {
     Failure_type.bits.Discharger_Cell_OVP = 1;
   }

   if(BBU_Info.BUCK1_Temp >= Expect_Discharging_BUCK1_OT_Protection)
   {
     Failure_type.bits.Discharger_BUCK1_OTP = 1;
   }
   


   if(Cell_Info.Temp > Expect_Discharger_Cell_OT_Protection)
   {
     Failure_type.bits.Discharger_Cell_OTP = 1;
   }
   
/*
   if(Failure_type.bits.Discharger_Output_OCP == 0 && Failure_type.bits.Discharger_Output_OVP == 0 &&
      Failure_type.bits.Discharger_Cell_UVP == 0 && Failure_type.bits.Discharger_Output_UVP == 0 &&
      Failure_type.bits.Discharger_Cell_OVP == 0 && Failure_type.bits.Discharger_BUCK1_OTP == 0 &&
      Failure_type.bits.Discharger_BUCK2_OTP == 0 && Failure_type.bits.Discharger_BUCK3_OTP == 0 &&
      Failure_type.bits.Discharger_Cell_OTP == 0)
   {
      SystemControl.bits.Flag_Failure = 0;
      Idle_state_handler(); 
          
   }
*/
}

void Charger_Failure_Detect(void)
{
   if(BBU_Info.BusVoltage < Expect_Input_UV_Protection)                   // Bus�q���C���J�q��UV�O�@�I �i�J�T��R�q�Ҧ�
   {
      Failure_type.bits.Charger_Input_UVP = 1;                             
   }

   if(BBU_Info.BusVoltage > Expect_Input_OV_Protection)                   // Bus�q�������J�q��OV�O�@�I �i�J�T��R�q�Ҧ�
   {
      Failure_type.bits.Charger_Input_OVP = 1;
   }
    
   if(Cell_Info.Temp >= Expect_Charger_Cell_OT_Protection)                // �b�R�q�ɹq���ūװ���q���R�q����ū�
   {
      Failure_type.bits.Charger_Cell_OTP = 1;                              
   }
   else if(Cell_Info.Temp < Charging_Cell_OT_Recover_Threshold)
   {
      Failure_type.bits.Charger_Cell_OTP = 0; 
   }

   if(BBU_Info.BOOST_Temp > Expect_Charging_BOOST_OT_Protection)          // �b�R�q��BOOST�ū׹L��
   {
      Failure_type.bits.Charger_BOOST_OTP = 1;								 
   }


}

void Failure_Control(void)
{
  if(SystemControl.bits.Flag_Online_Charge == 1 || SystemControl.bits.Flag_Offline_Charge == 1)
  {
     Charger_Failure_Detect();
  }

  if(SystemControl.bits.Flag_Online_Discharge == 1 || SystemControl.bits.Flag_Offline_Discharge == 1)
  {
     Discharger_Failure_Detect();
  }
}

void Clear_Failure(void)
{
  memset(&Failure_type, 0, sizeof(Failure_type));
  SystemControl.bits.Flag_Failure = 0;
  I2C_State.Communication_Fail_Count = 0;
  TEST1 = 0;

}


