#include <p24FJ64GA006.h>
#include "bms_Pin_Define.h"
#include "GenericTypeDefs.h"
#include "I2C.h"
#include "Battery_status.h"
#include "Charge_control.h"
#include "Discharge_control.h"
#include "FW_Config.h"
#include "main.h"
#include "PMBusData.h"
#include "PMBus_status.h"


Discharger_T  Discharger;
u16_t Test_AD = 0;
u16_t Test_AD1 = 0;
u8_t  Discharger_OCP_Flag = 0;
u16_t Discharger_OCP_count = 0;
u8_t  Discharger_12V_Flag = 0;


void Enable_Discharger(void)               // Enable BUCK 
{
   DISCHG_EN1 = 1;                         // Enable BUCK module 1
   asm("NOP");
   DISCHG_EN2 = 1;                         // Enable BUCK module 2
//   TEST2 = 1;
   asm("NOP");
   ORFET_EN = 1;                           // Enable ORing FET driver

   Discharger.UVP_Delay_Flag = 1;

   u16StatusP0Word = (u16StatusP0Word & ~(Status_Word_bits_Off));
   u16StatusP0Word = (u16StatusP0Word & ~(Status_Word_bits_Off)); 

}

void Disable_Discharger(void)              // Disable BUCK
{
 
   DISCHG_EN1 = 0;                         // Disable BUCK module 1
   asm("NOP");
   DISCHG_EN2 = 0;                         // Disable BUCK module 2
//   TEST2 = 0;
   asm("NOP");
   ORFET_EN = 0;                           // Disable ORing FET driver

   Discharger.UVP_Delay_Flag = 0;

   u16StatusP0Word = (u16StatusP0Word | Status_Word_bits_Off);
   u16StatusP0Word = (u16StatusP0Word | Status_Word_bits_Off); 

}



void Online_Discharge_control(void)
{
  if(SystemControl.bits.AC_GOOD == 1)
  {
     SystemControl.bits.Flag_Online_Charge = 0;
  }
  SystemControl.bits.Flag_Online_Discharge = 1;
  Discharger_Run_Time();
  Discharger_Control();   
  
}

void Offline_Discharge_control(void)
{

  SystemControl.bits.Flag_Offline_Charge = 0;
  SystemControl.bits.Flag_Offline_Discharge = 1;
  Discharger_Run_Time();
  Discharger_Control();   
}

//********************* chosoe Discharger state***************************

void Discharger_Control(void)
{
    if(SystemControl.bits.Flag_Failure == 1)
    {
    }
    else
    {  
       Discharger_Warning_type_Detect();
       Discharger_Failure_type_Detect();

       if(Not_Reset_Failure_type.bits.Discharger_second_OVP == 1)
       {
          Disable_Discharger();
          SystemControl.bits.Flag_Not_Reset_Failure = 1;
          Discharger.state_Discharging = 0;
          Discharger.state_Failure = 1;
       }

       else if(Failure_type.bits.Discharger_Output_OCP == 1 || Failure_type.bits.Discharger_Output_OVP == 1 ||
          Failure_type.bits.Discharger_Cell_UVP == 1 || Failure_type.bits.Discharger_Output_UVP == 1 ||
          Failure_type.bits.Discharger_Cell_OVP == 1 || Failure_type.bits.Discharger_Cell_OTP == 1 || 
          Failure_type.bits.Discharger_BUCK1_OTP == 1)
       {
          Disable_Discharger();
          SystemControl.bits.Flag_Failure = 1;
          Discharger.state_Discharging = 0;
          Discharger.state_Failure = 1;
       }
   
       else if(Failure_type.bits.Discharger_Output_OCP == 0 && Failure_type.bits.Discharger_Output_OVP == 0 &&
               Failure_type.bits.Discharger_Cell_UVP == 0 && Failure_type.bits.Discharger_Output_UVP == 0 &&
               Failure_type.bits.Discharger_Cell_OVP == 0 && Failure_type.bits.Discharger_Cell_OTP == 0 &&
               Failure_type.bits.Discharger_BUCK1_OTP == 0)
       {
        
         Discharger.state_Discharging = 1;
         Discharger.state_Inhibit = 0;
         Discharger.state_Failure = 0;
       }

       
    }
}

/*******************************************************************************************/

void Discharger_Run_Time(void)
{
  if(Discharger.Run_Time_Warning == 1)
  {
    Discharger.Run_Time_Warning = 0;                        // �^���t�Ω�q�ɶ�3�����֨�F
    
  }

  if(Discharger.Run_Time_Limit == 1)
  {
    Discharger.Run_Time_Limit = 0;                          // ��q�ɶ���F3����
    
  }

}

/*********Find Failure type and stand Failure Flag and PMBus status update  *********/
void Discharger_Failure_type_Detect(void)
{

   if(BBU_Info.Iout > Expect_Output_OC_Protection)
   {
     Discharger_OCP_Flag = 1;
     if(Discharger_OCP_count == 99)
     {
       Failure_type.bits.Discharger_Output_OCP = 1;
       u8StatusP0Iout = (u8StatusP0Iout | Status_Iout_bits_Iout_OC_Fault);
       u8StatusP1Iout = (u8StatusP1Iout | Status_Iout_bits_Iout_OC_Fault);
       u16StatusP0Word = (u16StatusP0Word | Status_Word_bits_Iout);
       u16StatusP1Word = (u16StatusP1Word | Status_Word_bits_Iout);
       u16StatusP0Word = (u16StatusP0Word | Status_Word_bits_Iout_OC_Fault);
       u16StatusP1Word = (u16StatusP1Word | Status_Word_bits_Iout_OC_Fault);
     }
   }
   else
   {
     Discharger_OCP_Flag = 0;
     Discharger_OCP_count = 0;
   }
  
   if(BBU_Info.Vout_12V > Expect_Output_OV_Protection)
   {
     Failure_type.bits.Discharger_Output_OVP = 1;
     u8StatusP0Vout = (u8StatusP0Vout | Status_Vout_bits_Vout_OV_Fault);
     u8StatusP1Vout = (u8StatusP1Vout | Status_Vout_bits_Vout_OV_Fault);
     u16StatusP0Word = (u16StatusP0Word | Status_Word_bits_Vout);
     u16StatusP1Word = (u16StatusP1Word | Status_Word_bits_Vout);
   }

   if(BBU_Info.Vout_12V > Output_OV_Protection_Second_Threshold)
   {
     Not_Reset_Failure_type.bits.Discharger_second_OVP = 1;
     Failure_type.bits.Discharger_Output_OVP_Second = 1;
     u8StatusP0Vout = (u8StatusP0Vout | Status_Vout_bits_Vout_OV_Fault);
     u8StatusP1Vout = (u8StatusP1Vout | Status_Vout_bits_Vout_OV_Fault);
     u16StatusP0Word = (u16StatusP0Word | Status_Word_bits_Vout);
     u16StatusP1Word = (u16StatusP1Word | Status_Word_bits_Vout);
   }

   if(Cell_Info.Voltage < Discharging_Cell_Cutoff_Voltage)
   {    
     Failure_type.bits.Discharger_Cell_UVP = 1;
   }
 
   if(BBU_Info.Vout_12V < Expect_Output_UV_Protection && Discharger_12V_Flag == 1)
   {
      Failure_type.bits.Discharger_Output_UVP = 1;
      u8StatusP0Vout = (u8StatusP0Vout | Status_Vout_bits_Vout_UV_Fault);
      u8StatusP1Vout = (u8StatusP1Vout | Status_Vout_bits_Vout_UV_Fault);
      u16StatusP0Word = (u16StatusP0Word | Status_Word_bits_Vout);
      u16StatusP1Word = (u16StatusP1Word | Status_Word_bits_Vout);
   }

   if(BBU_Info.Pout > Expect_Output_OP_Protection)
   {
     Failure_type.bits.Power_Output_OP = 1;
     u8StatusP0Iout = (u8StatusP0Iout | Status_Iout_bits_Pout_OP_Fault);
     u8StatusP1Iout = (u8StatusP1Iout | Status_Iout_bits_Pout_OP_Fault);
     u16StatusP0Word = (u16StatusP0Word | Status_Word_bits_Iout);
     u16StatusP1Word = (u16StatusP1Word | Status_Word_bits_Iout);
   } 
   
   if(Cell_Info.Voltage > Discharging_Cell_OV_Protection_Threshold)
   {
     Failure_type.bits.Discharger_Cell_OVP = 1;
   }

   if(BBU_Info.BUCK1_Temp >= Expect_Discharging_BUCK1_OT_Protection)
   {
     Failure_type.bits.Discharger_BUCK1_OTP = 1;
     u8StatusP0Temp = (u8StatusP0Temp | Status_Temperature_bits_OT_Fault);
     u8StatusP1Temp = (u8StatusP1Temp | Status_Temperature_bits_OT_Fault);
     u16StatusP0Word = (u16StatusP0Word | Status_Word_bits_Temperature);
     u16StatusP1Word = (u16StatusP1Word | Status_Word_bits_Temperature);
   }


   if(Cell_Info.Temp > Expect_Discharger_Cell_OT_Protection)
   {
     Failure_type.bits.Discharger_Cell_OTP = 1;
     Failure_type.bits.Charger_BOOST_OTP = 1;
     u8StatusP0Temp = (u8StatusP0Temp | Status_Temperature_bits_OT_Fault);
     u8StatusP1Temp = (u8StatusP1Temp | Status_Temperature_bits_OT_Fault);
   }
   
}

/********* Find Warning type and update PMBus Status*/

void Discharger_Warning_type_Detect(void)
{
   if(BBU_Info.Iout > Expect_Output_OC_Warning)
   {
     Warning_type.bits.Iout_OC_Warning = 1;
     u8StatusP0Iout = (u8StatusP0Iout | Status_Iout_bits_Iout_OC_Warning);
     u8StatusP1Iout = (u8StatusP1Iout | Status_Iout_bits_Iout_OC_Warning);
   }

//   else if(BBU_Info.Iout < Output_OC_Recover_Threshold)
//   {
//     Warning_type.bits.Iout_OC_Warning = 0;
//     u8StatusP0Iout = (u8StatusP0Iout & ~(Status_Iout_bits_Iout_OC_Warning));
//     u8StatusP1Iout = (u8StatusP1Iout & ~(Status_Iout_bits_Iout_OC_Warning));
//   }
//------------------------------------------------------------------------------//
   if(BBU_Info.Pout > Expect_Output_OP_Warning)
   {
     Warning_type.bits.Pout_OP_Warning = 1;
     u8StatusP0Iout = (u8StatusP0Iout | Status_Iout_bits_Pout_OP_Warning);
     u8StatusP1Iout = (u8StatusP1Iout | Status_Iout_bits_Pout_OP_Warning);
   }
  
//   else if(BBU_Info.Pout < Output_OP_Recover_Threshold)
//   {
//     Warning_type.bits.Pout_OP_Warning = 0;
//     u8StatusP0Iout = (u8StatusP0Iout & ~(Status_Iout_bits_Pout_OP_Warning));
//     u8StatusP1Iout = (u8StatusP1Iout & ~(Status_Iout_bits_Pout_OP_Warning));
//   }
//------------------------------------------------------------------------------//
   if(BBU_Info.BUCK1_Temp > Expect_Discharging_BUCK1_OT_Warning)
   {
     Warning_type.bits.Discharger_BUCK1_OT_Warning = 1;    
   }
//   else if(BBU_Info.BUCK1_Temp < Discharging_BUCK1_OT_Recover_Threshold)
//   {
//     Warning_type.bits.Discharger_BUCK1_OT_Warning = 0;
//   }
 
   if(Warning_type.bits.Discharger_BUCK1_OT_Warning == 1)    
   {
     u8StatusP0Temp = (u8StatusP0Temp | Status_Temperature_bits_OT_Warning);
     u8StatusP1Temp = (u8StatusP1Temp | Status_Temperature_bits_OT_Warning);
     u16StatusP0Word = (u16StatusP0Word | Status_Word_bits_Temperature);
     u16StatusP1Word = (u16StatusP1Word | Status_Word_bits_Temperature);
   }
 

   if(Warning_type.bits.Iout_OC_Warning == 1 || Warning_type.bits.Pout_OP_Warning == 1)
   {
     u16StatusP0Word = (u16StatusP0Word | Status_Word_bits_Iout);
     u16StatusP1Word = (u16StatusP1Word | Status_Word_bits_Iout); 
   }
   
//   if(Warning_type.bits.Iout_OC_Warning == 0 && Warning_type.bits.Pout_OP_Warning == 0)
//   {
//     u16StatusP0Word = (u16StatusP0Word & ~(Status_Word_bits_Iout));
//     u16StatusP1Word = (u16StatusP1Word & ~(Status_Word_bits_Iout));
//   }

}


