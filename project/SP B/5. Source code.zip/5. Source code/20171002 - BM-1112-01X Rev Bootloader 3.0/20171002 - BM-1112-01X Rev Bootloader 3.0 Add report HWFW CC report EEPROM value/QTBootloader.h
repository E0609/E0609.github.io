/*******************************************************************************
* file				QTBootloader.h
* brief				The file includes the function of Quanta bootloader.
* note
* author			vincent.liu
* version			01
* section History	2016/03/ - 1st release
*******************************************************************************/
#ifndef QTBOOTLOADER_H
#define	QTBOOTLOADER_H

#include "FlashDriver.h"
/*******************************************************************************
* declare compile condition
*******************************************************************************/
#define BOOT_AREA
//#define BYPASS_SUPPORT

#define SIDE_NUMBER						2										// 2:secondary, 1:primary

#define BOOT_RXBUFF_LEN					40										// 40 bytes
#define BOOT_TXBUFF_LEN					40										// 40 bytes

#define TRANSMIT_BYTENUM				0x20									// 32 bytes, should be a multiple of "4", the max value is 256 bytes
#define TRANSMIT_WORDNUM				(TRANSMIT_BYTENUM >> 1)					// 16 words
#define TRANSMIT_INSNUM					(TRANSMIT_BYTENUM >> 2)					// 8 instructions

#define QUANTA_BTLDR_KEY				"InVe"
#define LITEON_BTLDR_KEY				"BM-1112-01X     "

#define IMAGE_APP_STARTADDR				0x00002C00
#define IMAGE_APP_ENDADDR				0x0000a800
#define IMAGE_APP_PAGENUMBER			((IMAGE_APP_ENDADDR - IMAGE_APP_STARTADDR) / ERASE_PAGE_SIZE)
#define IMAGE_APP_RESETADDR				0x00002E48

#define APP_PASSWORD					0xaa55
#define BOOT_PASSWORD					0xbb66
#define APP_PASSWORD_STARTADDR			0x00002E40								// flash address
#define BOOT_PASSWORD_STARTADDR			0x000027FE									// ram address

#define MCURESET_TIME					100										// 100ms/1ms
#define GOAPP_TIME						100										// 100ms/1ms
#define GOBOOT_TIME						100										// 100ms/1ms

#define BTLDR_KEY						0xf0
#define BTLDR_CMD_STATUS				0xf1
#define BTLDR_MEMORYBLOCK				0xf2
#define BTLDR_PRODUCTKEY				0xf3
#define BTLDR_IMAGECKECKSUM				0xf4

#define STATUS_CHKSUM_SUCCESSFUL		0x01
#define STATUS_MEMERR					0x02
#define STATUS_ALIGNERR					0x04
#define STATUS_KEYERR					0x08
#define STATUS_STARTERR					0x10
#define STATUS_PRODUCTKEYERR			0x20
#define STATUS_BOOTMODE					0x40
#define STATUS_PRGMBUSY					0x80

#define CMD_CLEARSTAT					0x00
#define CMD_RESETSEQ					0x01
#define CMD_BOOTPM						0x03
#if SIDE_NUMBER == 1
#define CMD_BOOTISP						0x12
#define CMD_BOOTISPBYPASS				0xff
#elif SIDE_NUMBER == 2
#define CMD_BOOTISP						0x02
#define CMD_BOOTISPBYPASS				0x12
#else
#define CMD_BOOTISP						0xff
#define CMD_BOOTISPBYPASS				0xff
#endif

#define KEYLOCK_DELAY					10000									// 10000ms/1ms

#define ENTERBOOTMODE_RDBACK_DELAY		1800									// 1800ms/1ms
#define ENTERAPPMODE_RDBACK_DELAY		800										// 800ms/1ms
#define VERIFYIMAGESUM_RDBACK_DELAY		10										// 10ms/1ms
/*******************************************************************************
* declare compile structure
*******************************************************************************/
//=====================================
//enum of the Quanta bootloader state
//=====================================
typedef enum
{
	Task_Idle,
	Task_VerifyBootKey,
	Task_VerifyProductKey,
	Task_ClearStatus,
	Task_RestartBoot,
	Task_EnterBootMode,
	Task_EnterAppMode,
	Task_WriteMemoryBlock,
	Task_VerifyImageSum
}eQTBtldrState_t;
//=====================================
//flag of Quanta bootloader application
//=====================================
typedef union
{
	struct
	{
		u16_t u1MapRxData			:1;
		u16_t u1BootStay			:1;
		u16_t u1AppExist			:1;
		u16_t u2ISPUnlock			:2;
        u16_t u1ImageSumError       :1;
		u16_t u2NA01				:2;
		u16_t u1BypassMode			:1;
		u16_t u1EraseFlashDone		:1;
		u16_t u1WriteFlashDone		:1;
		u16_t u1FlashError			:1;
		u16_t u4NA02				:4;
	} u16Bit;

	u16_t u16All;
}nQTBtldrFlag_t;
//=====================================
//structure of Quanta bootloader application
//=====================================
typedef struct
{
	u8_t u8RxIdx;
	u8_t u8RxLen;
	u8_t u8TxIdx;
	u8_t u8TxLen;

	u8_t* pu8RxDataPtr;
	u8_t* pu8TxDataPtr;
	u8_t pu8RxBuff[BOOT_RXBUFF_LEN];
	u8_t pu8TxBuff[BOOT_TXBUFF_LEN];
	
	u8_t u8State;
	u8_t u8McuResetTimer;
	u8_t u8GoAppTimer;
	u8_t u8GoBootTimer;
	u16_t u16ReadStatusTimer;
	u16_t u16KeyLockTimer;

	u16_t u16CheckSum;
    u16_t u16ImageSum;

	u32_t u32AddrIndex;

	nQTBtldrFlag_t nQTBtldrFlag;
}sQTBtldrStr_t;
//=====================================
//structure of Quanta bootloader commands
//=====================================
typedef struct
{
	u8_t pu8Key[4];
	u8_t u8Command;
	u8_t u8Status;
	u8_t pu8MemoryBlock[32];
	u8_t pu8ProductKey[16];
	u16_t u16ImageChecksum;
}sQTBtldrCmdStr_t;
/*******************************************************************************
* declare extern variable
*******************************************************************************/
extern sQTBtldrStr_t sQTBtldr;
extern sQTBtldrCmdStr_t sQTBtldrCmd;
/*******************************************************************************
* declare extern function
*******************************************************************************/
extern void QTBootloaderCommInit(void);
extern void QTBootloaderRxParse(void);
extern void QTBootloaderTxParse(void);
extern void QTBootloaderMapRxData(void);
extern void QTBootloaderInit(void);
extern void QTBootloaderProcess(void);
extern void KeyLock(void);
#ifdef BOOT_AREA
extern void BootDoneReset(void);
extern void GotoApp(void);
#else
extern void GotoBoot(void);
#ifdef BYPASS_SUPPORT
extern void ReadBackStatus(void);
#endif
#endif
/*******************************************************************************
* end of file
*******************************************************************************/

#endif
