/********************************************************************************
* file				PMBusData.h
*
* brief				The file includes the function and data structure/variables
*					for the PMBus protocol
* note
*
* author			slade.fang
*
* version			01
*
* section History	2014/09/01	-	1st release
********************************************************************************/
#ifndef __PMBUS_DATA_H__
#define __PMBUS_DATA_H__  

#include "PMBusApp.h"

#define USER_PMBUS_RDNUM 	1
#define USER_PMBUS_WRNUM	3
#define USER_PMBUS_WRLIMITNUM	0
#define USER_PMBUS_STNUM	1



//The data structures are used for PMBusApp.c, User must define for the application individually.
extern sPMBusCmdRdStr_t sPMBusRdCmd[USER_PMBUS_RDNUM];
extern sPMBusCmdWrStr_t sPMBusWrCmd[USER_PMBUS_WRNUM];
extern sPMBusCmdStatusStr_t sPMBusStatusCmd[USER_PMBUS_STNUM];
extern sPMBusCmdWrLimitStr_t sPMBusWrLimit[USER_PMBUS_WRLIMITNUM];

extern void PMBusTstInit(void);

extern u8_t PMBus_CurrPage;
extern u8_t u8ClrFaultP0;
extern u8_t u8ClrFaultP1;
extern u8_t pu8PgPlusWr[0];
extern u8_t pu8PgPlusRd[0];   
extern u8_t pu8MFRID[10];  
extern u8_t u8WriteProtect;
extern u16_t u16StatusP0Word;
extern u8_t u8StatusP0CML;
extern u8_t u8StatusP1CML;				
extern u16_t u16StatusMP0Word;		
extern u8_t u8StatusMP0CML;		
extern u8_t u8StatusMP1CML;	
extern u8_t pu8BBUCompatible[11];

   



#endif

