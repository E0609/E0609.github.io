/*******************************************************************************
* file				FlashDriver.h
* brief				The file includes the function of flash operation.
*					Include erase/read/write flash.
* note
* author			vincent.liu
* version			01
* section History	2014/10/22 - 1st release
*******************************************************************************/
#ifndef FLASHDRIVER_H
#define	FLASHDRIVER_H

#include "bms_Pin_Define.h"
#include "GenericTypeDefs.h"
/*******************************************************************************
* declare compile condition
*******************************************************************************/
#define WRITE_ROW_CMD			0x4001
#define WRITE_WORD_CMD			0x4003
#define ERASE_PAGE_CMD			0x4042

#define WRITE_ROW_SIZE			0x0080			// 128 words(256 bytes)
#define ERASE_PAGE_SIZE			0x0400			// 1024 words(2048 bytes)
/*******************************************************************************
* declare extern function
*******************************************************************************/
extern void EraseFlashPage(u32_t u32StartAddr);
extern void WriteRam2Flash(u32_t u32StartAddr, u8_t* pu8Buff, u16_t u16Length);
extern void WriteFlashIns(u32_t u32StartAddr, u8_t* pu8Buff, u16_t u16Length);
extern void WriteFlashRow(u32_t u32StartAddr, u8_t* pu8Buff);
extern void ReadFlash2Ram(u32_t u32StartAddr, u8_t* pu8Buff, u16_t u16Length);
extern void ReadFlashIns(u32_t u32StartAddr, u8_t* pu8Buff, u16_t u16Length);
extern u8_t ReadFlashIns_Check(u32_t u32StartAddr, u16_t u16Length);
extern u8_t VerifyFlashIns(u32_t u32StartAddr, u8_t* pu8Buff, u16_t u16Length);
extern u8_t VerifyFlashRow(u32_t u32StartAddr, u8_t* pu8Buff);
/*******************************************************************************
* end of file
*******************************************************************************/

#endif	/* FLASHDRIVER_H */


