#ifndef __main_h__
#define __main_h__

#include <p24FJ64GA006.h>
#include "bms_Pin_Define.h"	
#include "I2C.h"
#include "GenericTypeDefs.h"


void Initial_system(void);
void AD_Delay(unsigned int AD_Delay_conter);
void AD_start(void);
void Read_Battery_data(void);
void AD_initial(void);
void Read_AD(unsigned ADCH);
void Idle_state_handler(void);
extern void System_Delay(unsigned int delay_conter);




#define  I_ref_Duty OC1RS
#define  V_ref_Duty OC2RS
#define  Trim_CS_Duty OC3RS
#define  efficiency 92 

extern u8_t  EEPROM_count;
extern u8_t  EEPROM_10ms_Write;
extern u8_t  EEPROM_Write_count;
extern u8_t  I_ref_Softstart_Flag;
extern u16_t  Expect_I_ref_Duty;
extern u32_t Average_Voltage;
extern u16_t Voltage_ADC_Gain;
extern u8_t  Charger_Start_cnt;
extern u16_t Expect_Charge_Current;


typedef struct
{
   u16_t BusVoltage;
   u32_t Iout;
   u16_t Vout_12V;
   s16_t Ambient_Temp;
   s16_t BUCK1_Temp;
   s16_t BUCK2_Temp;
   s16_t BUCK3_Temp;
   s16_t BOOST_Temp;
   u32_t Pin;
   u32_t Pout;
   u32_t Iin;
   u32_t Average_Iout;
   u32_t Average_BUCK_Temp;
   u32_t Average_BOOST_Temp;
   u32_t Average_BusVoltage;
   
}BBU_Info_T;

typedef struct
{
   u16_t    Time_1ms;
   u16_t    Time_10ms;
   u16_t    Time_20ms;
   u16_t    Time_1s;
   u16_t    Time_1min;
   u16_t    Time_1hour;
   u16_t    Time_1day;
   u8_t     I2C_Time_40ms;
   u32_t    Time_Total_Minute;
   u32_t    Time_Minute;
   u8_t     Flag_1minute;

}System_Run_T;

typedef struct
{
   u32_t   Iout1;
   u32_t   Iout2;
   u32_t   Iout3;
   u32_t   Iout4;
   u32_t   Iout5;
   u32_t   Iout6;
   u32_t   Iout7;
   u32_t   Iout8;
   u32_t   Iout9;
   u32_t   Iout10;

}Average_Iout_T;

typedef struct
{
    u16_t  BUCK1;
    u16_t  BUCK2;
    u16_t  BUCK3;
    u16_t  BUCK4;
    u16_t  BUCK5;
	u16_t  BUCK6;
	u16_t  BUCK7;
    u16_t  BUCK8;
    u16_t  BUCK9;
    u16_t  BUCK10;
    u16_t  BOOST1;
 	u16_t  BOOST2;
	u16_t  BOOST3;
	u16_t  BOOST4;
	u16_t  BOOST5;
	u16_t  BOOST6;
	u16_t  BOOST7;
	u16_t  BOOST8;
	u16_t  BOOST9;
	u16_t  BOOST10;  
 
}Average_Temp_T;



extern Average_Temp_T Average_Temp;
extern Average_Iout_T Average_Iout;
extern System_Run_T  System_Run;
extern BBU_Info_T BBU_Info;
//extern BBU_mode_t BBU_mode;  


#endif
