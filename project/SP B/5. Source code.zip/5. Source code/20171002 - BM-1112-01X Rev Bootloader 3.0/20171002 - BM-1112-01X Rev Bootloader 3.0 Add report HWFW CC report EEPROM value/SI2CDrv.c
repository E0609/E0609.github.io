/********************************************************************************
* file				SI2CDrv.c
*
* brief				The file includes the setting of the I2C peripheral. The driver
*					is created for Microchip PIC32MX series and use interrupt. 
*					Other MCU needs to modify the source code.
*
* note
*
* author			slade.fang
*
* version			01
*
* section History	2014/09/01	-	1st release
********************************************************************************/

#include "GenericTypeDefs.h"
#include "SI2CDrv.h"
#include "SI2CMiddle.h"



//flag used for uart driver
typedef union
{
	struct
	{
		u16_t 	u1RxBuffFull	:1;		//the rx buff is full and the app must reset the buffer before use
		u16_t   u15NA	 		:15;
	}u16Bit;
	
	u16_t u16All;
}nSI2CFlag_t;

//the variable used for driver control
typedef struct
{
	u8_t 	pu8RxBuff[SI2C_RX_BUFF];
	u8_t 	u8RxIndex;
	
	u8_t* 	pu8TxBuff;
	u8_t 	u8TxIndex;
	u8_t 	u8TxLength;
	
	u16_t	u16RxOverflowErrCnt;
	u16_t	u16TxOverflowErrCnt;
	u16_t 	u16ClockHoldErrCnt;
	u16_t 	u16RxBuffOverCnt;
	
	nSI2CFlag_t	nFlag;
}sSI2CStrct_t;


sSI2CStrct_t sSI2CDrv;
u8_t u8SI2CCLKHoldTimer, u8SI2CCLKHoldChkCnt;




/*******************************************************************************
*   brief 	configure the register and the flag
*******************************************************************************/
void SI2CDrvInit(void)
{
    u8_t tmp;
    tmp = 0x50;
    if(BBS_A0 == 1) tmp |= 0x02;
	if(BBS_A1 == 1) tmp |= 0x01;
	if(BBS_A2 == 1) tmp |= 0x08;
    if(BBS_A3 == 1) tmp += 0x10;
    if(BBS_A4 == 1) 
    { 
      tmp -= 0x50;
      tmp += 0x08;
    }

    I2C2ADD = tmp;

	I2C2CON = 0xB340;

//    I2C2CONbits.GCEN = 1;
}

/*******************************************************************************
*   brief 	get the error counts of the driver, the items of error counts include 
*			rxOverflow and txOverflow. 
*	para1	eErrItem: which error wants to get.
*	return 	error counts
*******************************************************************************/
u16_t GetSI2CErrCnt(eSI2CErr_t eErrItem)
{
	
	if(eErrItem == RxOverflow)
	{
		return sSI2CDrv.u16RxOverflowErrCnt;
	}
	else if(eErrItem == TxOverflow)
	{
		return sSI2CDrv.u16TxOverflowErrCnt;
	}
	else if(eErrItem == ClockHold)
	{
		return sSI2CDrv.u16ClockHoldErrCnt;
	}
	else if(eErrItem == RxBuffOver)
	{
		return sSI2CDrv.u16RxBuffOverCnt;
	}
	else
	{
		return 0;
	}
}

/*******************************************************************************
*   brief 	clear the error counts of the driver, the items of error counts include 
*			parity error, frame error and over write error.
*	para1	eErrItem: which error wants to get.
*******************************************************************************/
void ClearSI2CErr(eSI2CErr_t eErrItem)
{
	if(eErrItem == RxOverflow)
	{
		sSI2CDrv.u16RxOverflowErrCnt = 0;
	}
	else if(eErrItem == TxOverflow)
	{
		sSI2CDrv.u16TxOverflowErrCnt = 0;
	}
	else if(eErrItem == ClockHold)
	{
		sSI2CDrv.u16ClockHoldErrCnt = 0;
	}
	else if(eErrItem == RxBuffOver)
	{
		sSI2CDrv.u16RxBuffOverCnt = 0;
	}
	else if(eErrItem == ErrItems)
	{
		sSI2CDrv.u16RxOverflowErrCnt = 0;
		sSI2CDrv.u16TxOverflowErrCnt = 0;
		sSI2CDrv.u16ClockHoldErrCnt = 0;
		sSI2CDrv.u16RxBuffOverCnt = 0;
	}
}

/*******************************************************************************
*   brief 	Start the tx transaction. Before start the tx transation, the user must
*			prepare the data and store in the tx buffer.
*	para1	pu8Buff: the buffer stored the data. 
*	para2	u16Length: the length needs to be transmit. 
*******************************************************************************/
void SI2CTxWrite(u8_t* pu8Buff, u16_t u16Length)
{
	
	sSI2CDrv.u8TxLength = u16Length;
	sSI2CDrv.pu8TxBuff = pu8Buff;
}

/*******************************************************************************
*   brief 	Get the SI2C driver received bytes. When the user(application) get the
*			rx bytes and uses for the application. It's the user's responsibility to
*			reset the driver rx buffer to avoid the rx buffer over flow.
*	para1	pu8Buff: the application's rx buffer to store the driver's received data. 
*	para2	u16BuffLimit: the bytes of the application's rx buffer. The driver's
*			rx data MUST not larger than the application's rx buffer to avoid the
*			data crash.
*	return	The bytes received of the driver
*******************************************************************************/
u8_t GetSI2CRxIdx(u8_t* pu8Buff, u16_t u16BuffLimit)
{
	u8_t i;
	u8_t u8TmpIndex;
	
	//to avoid u8RxIndex be changed in interrupt and cause CRC error
	u8TmpIndex = sSI2CDrv.u8RxIndex;
		
	//if driver rx index larger than the app buffer, return 0xff
	if((u8TmpIndex >= u16BuffLimit) || (sSI2CDrv.nFlag.u16Bit.u1RxBuffFull))
	{
		return 0xff;
	}
	
	for(i=0;i<=u8TmpIndex;i++)
	{
		*(pu8Buff+i) = *(sSI2CDrv.pu8RxBuff+i);
	}
	
	return u8TmpIndex;
}

/*******************************************************************************
*   brief 	Microchip Mx series I2C peripheral interrupt service routine
*   note	Only for Microchip MX series, change to other MCU maybe need to change
*			the ISR if the read/write interrupt patterns are not the same..
*******************************************************************************/
void SI2CISR(void)
{
//	u8_t u8TmpByte;
	
//	I2C2CONbits.SCLREL = 0;	
	if(I2C2STATbits.IWCOL)									//transmit overflow
	{
		if(sSI2CDrv.u16TxOverflowErrCnt < 0xffff)
		{
			sSI2CDrv.u16TxOverflowErrCnt += 1;
		}
		
//		i2cRegs->I2CxSTATCLR = _I2CSTAT_IWCOL_MASK;
               ResetSI2CDrv();
	}
	else if(I2C2STATbits.I2COV)							//receive overflow
	{
		if(sSI2CDrv.u16RxOverflowErrCnt < 0xffff)
		{
			sSI2CDrv.u16RxOverflowErrCnt += 1;
		}
		
            ResetSI2CDrv();
//		i2cRegs->I2CxSTATCLR = _I2CSTAT_I2COV_MASK;
	}
	else
	{
		
		if((I2C2STATbits.D_A == 0)&&(I2C2STATbits.R_W == 0))		//address write
		{
			sSI2CDrv.u8RxIndex = 0;
			SI2CMiddleInit();
			sSI2CDrv.pu8RxBuff[sSI2CDrv.u8RxIndex] = I2C2RCV;
			sSI2CDrv.u8RxIndex++;
            u8SI2CCLKHoldChkCnt = 0;
		}
		else if((I2C2STATbits.D_A == 0)&&(I2C2STATbits.R_W == 1))	//address read
		{
			sSI2CDrv.pu8RxBuff[sSI2CDrv.u8RxIndex] = I2C2RCV;			//From the data sheet, slave address not move to RCV, so it doesn't need to read. But how can we calculate PEC?
			sSI2CDrv.u8TxIndex = 0;
			//app parse read
			SI2CMiddleTxProcess();
            u8SI2CCLKHoldChkCnt = 0;
 
            if(sSI2CDrv.u8TxIndex >= sSI2CDrv.u8TxLength)
			{
				I2C2TRN = 0xff;
			}			
            else
            {            
			 I2C2TRN = *(sSI2CDrv.pu8TxBuff + sSI2CDrv.u8TxIndex);
			 sSI2CDrv.u8TxIndex++;
            }
		}
		else if((I2C2STATbits.D_A == 1)&&(I2C2STATbits.R_W == 0))		//data write												//data
		{
			sSI2CDrv.pu8RxBuff[sSI2CDrv.u8RxIndex] = I2C2RCV;

			//app parse write
			SI2CMiddleRxProcess();

			if(sSI2CDrv.u8RxIndex < (SI2C_RX_BUFF-1))
			{
				sSI2CDrv.u8RxIndex++;
			}
			else
			{
				sSI2CDrv.nFlag.u16Bit.u1RxBuffFull = 1;
				
				if(sSI2CDrv.u16RxBuffOverCnt < 0xffff)
				{
					sSI2CDrv.u16RxBuffOverCnt++;
				}
			}
		}
//		else													//data read
        else if((I2C2STATbits.D_A == 1)&&(I2C2STATbits.R_W == 1))
		{
			if(sSI2CDrv.u8TxIndex >= sSI2CDrv.u8TxLength)
			{
				I2C2TRN = 0xff;
			}
			else
			{
				I2C2TRN = *(sSI2CDrv.pu8TxBuff + sSI2CDrv.u8TxIndex);
				sSI2CDrv.u8TxIndex++;
			}
		}
	}
	
	I2C2CONbits.SCLREL = 1;							//release master clock
//	SI2C_INT_FLAG_CLR_REG = SI2C_INT_FLAG_MASK;					//clear the interrupt flag
}




/*******************************************************************************
*   brief 	Check Clock Hold Time not to exceed 25ms to avoid I2C Bus hang up
*   note	The function is used in main loop
*******************************************************************************/
void CheckClockHold(void)
{	
  if(I2C2STATbits.S == 1)
  {
	 if(u8SI2CCLKHoldTimer != SI2cCLKHold1ms)
	 {
		if(u8SI2CCLKHoldChkCnt < 6)										//the PM bus spec defined 25ms must release the bus
		{
			u8SI2CCLKHoldChkCnt++;
		}
		else
		{
//    		i2cRegs->I2CxCONSET = SI2C_CONFIG;								//disable I2C
           I2C2CONbits.I2CEN = 0;
		   sSI2CDrv.u16ClockHoldErrCnt++;
		   u8SI2CCLKHoldChkCnt = 0;
		   sSI2CDrv.u8RxIndex = 0;
           I2C2CONbits.I2CEN = 1;
//    	    i2cRegs->I2CxCONSET = SI2C_CONFIG | _I2CCON_ON_MASK;			//enable I2C
		}
        u8SI2CCLKHoldTimer = SI2cCLKHold1ms;
	  }
   }      
   else
   {
	  u8SI2CCLKHoldChkCnt = 0;
      u8SI2CCLKHoldTimer = SI2cCLKHold1ms;
   }
}

/*******************************************************************************
*   brief 	Reset the the PMBus driver if the rx buffer overwrite
*			
*******************************************************************************/
void ResetSI2CDrv(void)
{
	
	I2C2CONbits.SCLREL = 1;							//release master clock
//	SI2C_INT_FLAG_CLR_REG = SI2C_INT_FLAG_MASK;					//clear the interrupt flag
    IFS3bits.SI2C2IF = 0;
//	i2cRegs->I2CxCONSET = SI2C_CONFIG;							//disable I2C
	I2C2CONbits.I2CEN = 0;
    u8SI2CCLKHoldChkCnt = 0;
	sSI2CDrv.u8RxIndex = 0;
	sSI2CDrv.nFlag.u16Bit.u1RxBuffFull = 0;
//	i2cRegs->I2CxCONSET = SI2C_CONFIG | _I2CCON_ON_MASK;			//enable I2C
    I2C2CONbits.I2CEN = 1;
}



/*******************************************************************************
*   brief 	Check the slave I2C stop or not
*			
*	return	1: bus stop, 0: bus start
*******************************************************************************/
u8_t CheckBusStatus(void)
{
	
	if(I2C2STATbits.P)	
	{
		return 1;
	}
	else
	{
		return 0;	
	}
}



