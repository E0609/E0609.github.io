#include <p24FJ64GA006.h>
#include "bms_Pin_Define.h"
#include "PMBus_data_transfor.h"
#include "main.h"
#include "BBU_content.h"
#include "PMBusData.h" 
#include "PMBusAPP.h"
#include "FW_Config.h"
#include "EEPROM.h"
#include <string.h>


u8_t Charge_Current_Zero_Flag = 0;
u8_t Charge_Current_Standard_Flag = 0;
u8_t Charge_Current_Slow_Flag = 0;
u8_t Charge_Current_Fast_Flag = 0;
u8_t Charge_Current_Medium_Flag = 0;
u8_t Charge_Current_Medium_Fast_Flag = 0;
u8_t Old_Charge_Current_Select = 0;
u8_t Warning_Point_count = 0;

u16_t Expect_Charging_BOOST_OT_Warning = Charging_BOOST_OT_Warning_Threshold;
u16_t Expect_Charging_BOOST_OT_Protection = Charging_BOOST_OT_Protection_Threshold;
u16_t Expect_Discharging_BUCK1_OT_Warning = Discharging_BUCK1_OT_Warning_Threshold;
u16_t Expect_Discharging_BUCK1_OT_Protection = Discharging_BUCK1_OT_Protection_Threshold;
u16_t Expect_Ambient_OT_Warning = Ambient_OT_Warning_Threshold;
u16_t Expect_Ambient_OT_Protection = Ambient_OT_Protection_Threshold;
u16_t Expect_Input_UV_Warning = Input_UV_Warning_Threshold;
u16_t Expect_Input_UV_Protection = Input_UV_Protection_Threshold;
u16_t Expect_Input_OV_Warning = Input_OV_Warning_Threshold;
u16_t Expect_Input_OV_Protection = Input_OV_Protection_Threshold;
u16_t Expect_Input_OC_Warning = Input_OC_Warning_Threshold;
u16_t Expect_Input_OC_Protection = Input_OC_Protection_Threshold;
u32_t Expect_Input_OP_Warning = Input_OP_Warning_Threshold;
u32_t Expect_Input_OP_Protection;
u16_t Expect_Output_OV_Warning = Output_OV_Warning_Threshold;
u16_t Expect_Output_OV_Protection = Output_OV_Protection_First_Threshold;
u16_t Expect_Output_UV_Warning = Output_UV_Warning_Threshold;
u16_t Expect_Output_UV_Protection = Output_UV_Protection_Threshold;
s32_t Expect_Output_OC_Warning = Output_OC_Warning_Threshold;
s32_t Expect_Output_OC_Protection = Output_OC_Protection_Threshold;
s32_t Expect_Output_OP_Warning = Output_OP_Warning_Threshold;
s32_t Expect_Output_OP_Protection = Output_OP_Protection_Threshold;
u16_t Expect_Discharger_Cell_OT_Warning = Discharging_Cell_OT_Warning_Threshold;
u16_t Expect_Discharger_Cell_OT_Protection = Discharging_Cell_OT_Protection_Threshold;
u16_t Expect_Charger_Cell_OT_Warning = Charging_Cell_OT_Warning_Threshold;
u16_t Expect_Charger_Cell_OT_Protection = Charging_Cell_OT_Protection_Threshold;




BBU_content_T BBU_content;

 

void PMBus_data_update(void)
{
  u16_t tmp;
  s32_t tmp1;

 if(SystemControl.bits.AC_GOOD == 0)
 {
//********** Read Vin ************//
  tmp = Real_to_Literal (BBU_Info.BusVoltage, BusVoltage_gain);
  u16ReadVin = tmp;

//********** Read Iin ************//
  tmp = Real_to_Literal (BBU_Info.Iin, Iin_gain);
  u16ReadIin = tmp;

//********** Read Pin ************//
  tmp = Real_to_Literal (BBU_Info.Pin, BusPower_gain);
  u16ReadPin = tmp;

//********** Read Vout ***********//
  tmp = Real_To_Literal_ForVout(0);
  u16ReadVout = tmp;

//********** Read Iout ***********//
  tmp = Real_to_Literal (0, Iout_gain);
  u16ReadIout = tmp;
  
//********** Read Pout ***********//
  tmp = Real_to_Literal (0, BusPower_gain);
  u16ReadPout = tmp; 
 }


 else
 {
//********** Read Vin ************//
  tmp = Real_to_Literal (0, BusVoltage_gain);
  u16ReadVin = tmp;

//********** Read Iin ************//
  tmp = Real_to_Literal (0, Iin_gain);
  u16ReadIin = tmp;

//********** Read Pin ************//
  tmp = Real_to_Literal (0, BusPower_gain);
  u16ReadPin = tmp;

//********** Read Vout ***********//
  tmp = Real_To_Literal_ForVout(BBU_Info.BusVoltage);
  u16ReadVout = tmp;

//********** Read Iout ***********//
  tmp = Real_to_Literal (BBU_Info.Average_Iout, Iout_gain);
  u16ReadIout = tmp;
  
//********** Read Pout ***********//
  tmp = Real_to_Literal (BBU_Info.Pout, BusPower_gain);
  u16ReadPout = tmp; 
 }

//********** Read BUCK1 temp ************//
  tmp = Real_to_Literal (BBU_Info.BUCK1_Temp, 1);
  u16ReadTemp1 = tmp;

//********** Read BOOST1 temp ************//
  tmp = Real_to_Literal (BBU_Info.BOOST_Temp, 1);
  u16ReadTemp2 = tmp;

//********** Read Ambient Temp ***********//
  tmp = Real_to_Literal (BBU_Info.Ambient_Temp, 1);
  u16ReadTemp3 = tmp;

//********* Battery string Voltage ******//
  tmp = Real_to_Literal (Cell_Info.Voltage, CellVoltage_gain);
  u16BattVolt = tmp;

//********* Battery string Current ******//
  tmp = Real_to_Literal (Cell_Info.Current, CellCurrent_gain);
  u16BattCurr = tmp;

//********* Battery Temp *********//
  tmp = Real_to_Literal (Cell_Info.Temp, 1);
  u16BattTemp = tmp;

//********* Battery absoulte state of charge ********//
  tmp = Real_to_Literal (Cell_Info.ASOC, 1);
  u16BattASOC = tmp;

//********* Battery relative state of charge ********//
  tmp = Real_to_Literal (Cell_Info.RSOC, 1);
  u16BattRSOC = tmp; 

//********* Battery remaining capacity **********//
  tmp = Real_to_Literal (Cell_Info.RemainingCapacity, 1);
  u16BattCapacity = tmp;

//********* Battery cycle count ***********//
  tmp = Real_to_Literal (Cell_Info.CycleCount, 1);
  u16BattCycleCnt = tmp; 

//********* Battery Cell Min History *********//
  tmp = Real_to_Literal (Cell_Info.CellMinVoltageHis, CellVoltage_gain);
  u16CellVolMin = tmp;

//********* BMS Firmware Revision ***********//
  u16BMSFWRev = Cell_Info.FWRev; 

//********* 12V loss count ********//
  tmp = Real_to_Literal (Cell_Info.Voltage_Loss,1);
  u16VoltageLossCnt = tmp;

//********* Cycle Cnt offset **********//
  if(EEPROM_Info.Cycle_Cnt_Offset != 65535)
  {
   tmp = Real_to_Literal (EEPROM_Info.Cycle_Cnt_Offset,1);
   u16Cycle_Cnt_Offset = tmp;
  }

//********* Battery Run Time ************//
  tmp = Real_to_Literal (System_Run.Time_Total_Minute, 1);
  u16BBURunTime = tmp;

//********* Battery State of Health ***********//
  tmp = Real_to_Literal (Cell_Info.SOH, 1);
  u16BattSOH = tmp;

//********* Discharge Remain Time *************//  
  tmp = Real_to_Literal (Cell_Info.Discharge_Remain_Time, 1);
  u16DischargeRemainTime = tmp;
 

//********* Charge current select ***********//
  
 if(Old_Charge_Current_Select != u8ChargeCurrSelect)
 {
   if(u8ChargeCurrSelect == 0)
   {
     Expect_I_ref_Duty = Charge_Current_Zero;
     Expect_Charge_Current = Charge_Current_0A;

     Charge_Current_Zero_Flag = 1;
	 Charge_Current_Standard_Flag = 0;
	 Charge_Current_Slow_Flag = 0;
	 Charge_Current_Fast_Flag = 0;
     Charge_Current_Medium_Flag = 0;
     Charge_Current_Medium_Fast_Flag = 0;
   }
   else if(u8ChargeCurrSelect == 1)
   {
     Expect_I_ref_Duty = Charge_Current_Standard;
     Expect_Charge_Current = Charge_Current_1500mA;

     Charge_Current_Zero_Flag = 0;
 	 Charge_Current_Standard_Flag = 1;
	 Charge_Current_Slow_Flag = 0;
	 Charge_Current_Fast_Flag = 0;
     Charge_Current_Medium_Flag = 0;
     Charge_Current_Medium_Fast_Flag = 0;
   
   }
   else if(u8ChargeCurrSelect == 2)
   {
     Expect_I_ref_Duty = Charge_Current_Medium;
     Expect_Charge_Current = Charge_Current_1000mA;
 
     Charge_Current_Zero_Flag = 0;
	 Charge_Current_Standard_Flag = 0;
	 Charge_Current_Slow_Flag = 0;
	 Charge_Current_Fast_Flag = 1;
     Charge_Current_Medium_Flag = 0;
     Charge_Current_Medium_Fast_Flag = 0;
  
   }
   else if(u8ChargeCurrSelect == 3)
   {
     Expect_I_ref_Duty = Charge_Current_Slow;
     Expect_Charge_Current = Charge_Current_500mA;

     Charge_Current_Zero_Flag = 0;
	 Charge_Current_Standard_Flag = 0;
	 Charge_Current_Slow_Flag = 1;
	 Charge_Current_Fast_Flag = 0;
     Charge_Current_Medium_Flag = 0;
     Charge_Current_Medium_Fast_Flag = 0;
   }
   else if(u8ChargeCurrSelect == 4)
   {
     Expect_I_ref_Duty = Charge_Current_Fast;
     Expect_Charge_Current = Charge_Current_2000mA;

     Charge_Current_Zero_Flag = 0;
	 Charge_Current_Standard_Flag = 0;
	 Charge_Current_Slow_Flag = 0;
	 Charge_Current_Fast_Flag = 0;
     Charge_Current_Medium_Flag = 1; 
     Charge_Current_Medium_Fast_Flag = 0;   
   }
   else if(u8ChargeCurrSelect == 5)
   {
     Expect_I_ref_Duty = Charge_Current_Medium_Fast;
     Expect_Charge_Current = Charge_Current_1800mA;   

     Charge_Current_Zero_Flag = 0;
	 Charge_Current_Standard_Flag = 0;
	 Charge_Current_Slow_Flag = 0;
	 Charge_Current_Fast_Flag = 0;
     Charge_Current_Medium_Flag = 0;
     Charge_Current_Medium_Fast_Flag = 1;

   }  
   
   Old_Charge_Current_Select = u8ChargeCurrSelect;
 }
  
     

//********* State BBU ****************//
  if(Charger.state_Charging == 1)
  {
     u8StateBBU = 0x02;
  }
  else if(Charger.state_FullyCharge == 1)
  {
     u8StateBBU = 0x08;
  }

  else if(Charger.state_Inhibit == 1)
  {
     u8StateBBU = 0x01;
  }
  else if(SystemControl.bits.Flag_Idle_Mode == 1)
  {
     u8StateBBU = 0x10;
  }
  else if(Discharger.state_Discharging == 1)
  {
     u8StateBBU = 0x04;
  }

//********* Battery status ***********
    u16BatteryStatus = Cell_Info.BatteryStatus.Val;
    u16BattProtecStatus = Cell_Info.ProtectionStatus.Val;
    u16BattPFStatus = Cell_Info.PermanentFailureStatus.Val; 

    u32Protection_type =  Failure_type.val;        

//********* Output voltage **********//
    
  UpdateSTATUS_WORD(); 

//******** Protection and warning update *******//
  if(Warning_Point_count == 25)
  {
     Warning_Point_count = 0;
  }

  Warning_Point_count ++;

 switch(Warning_Point_count)
 {
   case 1:
//---------- Vout OV Fault ---------
  tmp = Literal_To_Real_ForVout(u16VoutOVFaultL);
  Expect_Output_OV_Protection = tmp;
    break;
 
   case 2:
//---------- Vout OV Warning ----------
  tmp = Literal_To_Real_ForVout(u16VoutOVWarnL);
  Expect_Output_OV_Warning = tmp;
    break;

   case 3:
//---------- Vout UV Fault ------------
  tmp = Literal_To_Real_ForVout(u16VoutUVFaultL);
  Expect_Output_UV_Protection = tmp;
    break;

   case 4:
//---------- Vout UV Warning -------------
  tmp = Literal_To_Real_ForVout(u16VoutUVWarnL);
  Expect_Output_UV_Warning = tmp;
    break;

   case 5:
//---------- Iout OC Fault ---------------
  tmp1 = Literal_to_Real (u16IoutOCFaultL, Iout_gain);
  Expect_Output_OC_Protection = tmp1;
    break;

   case 6:
//---------- Iout OC Warning -------------
  tmp1 = Literal_to_Real (u16IoutOCWarnL, Iout_gain);
  Expect_Output_OC_Warning = tmp1;
    break;

   case 7:
//---------- Pout OP Warning -------------
  tmp1 = Literal_to_Real (u16PoutOPWarnL, BusPower_gain);
  Expect_Output_OP_Warning = tmp1;
    break;

   case 8:
//---------- Pout OP Protection -----------
  tmp1 = Literal_to_Real (u16PoutOPFaultL, BusPower_gain);
  Expect_Output_OP_Protection = tmp1;
    break;

   case 9:
//---------- Input OV Protection ------------
  tmp1 = Literal_to_Real (u16VinOVFaultL, BusVoltage_gain);
  Expect_Input_OV_Protection = tmp1;
    break;

   case 10:
//---------- Input OV Warning ---------------
  tmp1 = Literal_to_Real (u16VinOVWarnL, BusVoltage_gain);
  Expect_Input_OV_Warning = tmp1;
    break;

   case 11:
//---------- Input UV Protection ------------
  tmp1 = Literal_to_Real (u16VinUVFaultL, BusVoltage_gain);
  Expect_Input_UV_Protection = tmp1;
    break;

   case 12:
//---------- Input UV Warning ---------------
  tmp1 = Literal_to_Real (u16VinUVWarnL, BusVoltage_gain);
  Expect_Input_UV_Warning = tmp1;
    break;

   case 13:
//---------- Input OC Protection ---------------
  tmp1 = Literal_to_Real (u16IinOCFaultL, Iin_gain);
  Expect_Input_OC_Protection = tmp1;
    break;

   case 14:
//---------- Input OC Warning ------------------
  tmp1 = Literal_to_Real (u16IinOCWarnL, Iin_gain);
  Expect_Input_OC_Warning = tmp1;
    break;

   case 15:
//---------- Input OP Warning ------------------
  tmp1 = Literal_to_Real (u16PinOPWarnL, BusPower_gain);
  Expect_Input_OP_Warning = tmp1;
    break;

   case 16:
//---------- BUCK OT Fault ---------------------
  tmp1 = Literal_to_Real (u16BuckOTFaultL, 1);
  Expect_Discharging_BUCK1_OT_Protection = tmp1;
    break;

   case 17:
//---------- BUCK OT Warning -------------------
  tmp1 = Literal_to_Real (u16BuckOTWarnL, 1);
  Expect_Discharging_BUCK1_OT_Warning = tmp1;
    break;

   case 18:
//---------- BOOST OT Fault --------------------
  tmp1 = Literal_to_Real (u16BoostOTFaultL, 1);
  Expect_Charging_BOOST_OT_Protection = tmp1;
    break;

   case 19:
//---------- BOOST OT Warning ------------------
  tmp1 = Literal_to_Real (u16BoostOTWarnL, 1);
  Expect_Charging_BOOST_OT_Warning = tmp1;
    break;

   case 20:
//---------- Ambient OT Fault ------------------
  tmp1 = Literal_to_Real (u16AmbientOTFaultL, 1);
  Expect_Ambient_OT_Protection = tmp1;
    break;

   case 21:
//---------- Ambient OT Warning ----------------
  tmp1 = Literal_to_Real (u16AmbientOTWarnL, 1);
  Expect_Ambient_OT_Warning = tmp1;
    break;

   case 22:
//---------- Discharge Cell OT Fault ------------
  tmp1 = Literal_to_Real (u16DischargeCellOTFaultL, 1);
  Expect_Discharger_Cell_OT_Protection = tmp1;
    break;

   case 23:
//---------- Discharge Cell OT Warning -----------
  tmp1 = Literal_to_Real (u16DischargeCellOTWarnL, 1);
  Expect_Discharger_Cell_OT_Warning = tmp1;
    break;

   case 24:
//---------- Charge Cell OT Fault ------------
  tmp1 = Literal_to_Real (u16ChargeCellOTFaultL, 1);
  Expect_Charger_Cell_OT_Protection = tmp1;
    break;

   case 25:
//---------- Charge Cell OT Warning -----------
  tmp1 = Literal_to_Real (u16ChargeCellOTWarnL, 1);
  Expect_Charger_Cell_OT_Warning = tmp1;
    break;

   default:
 
    break;
 }

 memcpy(pu8MFRSerial, pu8FactorySerial, sizeof(pu8FactorySerial));

}


void PMBus_need_update_data(void)
{
  if(BBU_content.flag == 1)
  {
     PMBus_data_update();
  }

}

