#include <p24FJ64GA006.h>
#include "bms_Pin_Define.h"
#include "GenericTypeDefs.h"
#include "I2C.h"
#include "CRC.h"
#include "PMBusData.h"
#include "EEPROM.h"
#include <string.h>



unsigned char I2C1_Buf = 0;
unsigned char data_out2;
unsigned char W_data2;
unsigned int fail_CNT = 0;
unsigned int total_CNT = 0;
unsigned char data_low = 0,data_high = 0, data_PEC = 0; 
u32_t Wait_ACK_cnt = 0;
u32_t Wait_NACK_cnt = 0;
u8_t Command_code;
u8_t TempBlockBuff[16];
u8_t BatteryBlockBuff[40];
u16_t I2CTest = 0;

I2C_State_t I2C_State;


//************************** I2C1 Master *************************** //
void I2C1_INIT(void)
{
  I2C1CONbits.I2CEN = 1;        //Enable I2C1
  I2C1CONbits.I2CSIDL = 0;      //Continues operating in idle mode
  I2C1CONbits.A10M = 0;
  I2C1CONbits.DISSLW = 1;
  
  I2C1STAT = 0;
  I2C1BRG = 157;                 //Fcy =16M  Baud rate =100k
  
 
}

//---------------- Reset I2C ----------------//
void I2C1_Reset(void)
{
   I2C1CONbits.I2CEN = 0;        //Disable I2C1
   asm("NOP");
   asm("NOP");

   I2C1CONbits.I2CEN = 1;        //Enable I2C1
   I2C1CONbits.I2CSIDL = 0;      //Continues operating in idle mode
   I2C1CONbits.A10M = 0;
   I2C1CONbits.DISSLW = 1;
  
   I2C1STAT = 0;
   I2C1BRG = 157;                 //Fcy =16M  Baud rate =100k


}

void I2C1_Idle(void)
{
    /* Wait until I2C Bus is Inactive */		// G8 s0905
    while((I2C1CONbits.SEN || I2C1CONbits.PEN || I2C1CONbits.RCEN || 
          I2C1CONbits.RSEN ||I2C1CONbits.ACKEN || I2C1STATbits.TRSTAT));	
}

void I2C1_Start(void)
{
  I2C1CONbits.SEN = 1;          //Start I2C
  asm("NOP");
  asm("NOP");
  while(I2C1CONbits.SEN == 1);	//wait hardware clear to 0						
}

void I2C1_Stop(void)
{
  I2C1CONbits.PEN = 1;          //stop I2C
  while(I2C1CONbits.PEN == 1);  //wait hardware clear to 0
}

void I2C1_Restart(void)
{
//  I2C1_Stop();
  I2C1_Idle();
  I2C1CONbits.RSEN = 1;          //Start I2C
  asm("NOP");
  asm("NOP");
  while(I2C1CONbits.RSEN == 1);	//wait hardware clear to 0
}

void I2C1_protect(void)
{
  I2C1_Stop();
  I2C_State.Communication_Fail = 1;
  I2C_State.Old_Communication = I2C_State.Communication_Fail;  
}

char I2C1_deliver( unsigned char W_data)
{

	if (W_data == 0xA0)
	{
		asm("NOP");
		asm("NOP");
	}
	
 I2C1TRN = W_data;                //deliver the W_data(maybe address or command)
 while(I2C1STATbits.TRSTAT == 1); //wait the sequence ready
// I2C1_Idle();
 asm("NOP");
 if(I2C1STATbits.ACKSTAT == 1)    //if not receive the ACK signal from slave device go to protect
 I2C1_protect();
 return 0;
}

unsigned char I2C1_receive(void)
{
 I2C1CONbits.RCEN = 1;            //Enable receive
 while(I2C1CONbits.RCEN);         //wait hardware clear to 0
 I2C1STATbits.I2COV = 0;          
 asm("NOP");
 asm("NOP");
 I2C1_Buf = I2C1RCV;              //I2C1RCV register is the data from slave device
 return I2C1_Buf;                 //I2C1_receive value equal I2C1_Buf
}

void I2C1_ACK(void)
{
 while(I2C1STATbits.TBF == 1);  
 I2C1CONbits.ACKDT = 0;
 I2C1CONbits.ACKEN = 1;
 asm("NOP");
 while(I2C1CONbits.ACKEN == 1)   //wait the ACK deliver,the timer to read I2C nead more time 
 {
   Wait_ACK_cnt ++;
   if(Wait_ACK_cnt > 60000)
   {
     I2C1_protect();
     I2C1_Reset();
     Wait_ACK_cnt = 0;
     return;
   }
 }

}

void I2C1_NACK(void)
{
 while(I2C1STATbits.TBF == 1); 
 I2C1CONbits.ACKDT = 1;
 I2C1CONbits.ACKEN = 1;
 asm("NOP");
 while(I2C1CONbits.ACKEN == 1)   //wait the ACK deliver,the timer to read I2C nead more time
 {
   Wait_NACK_cnt ++;
   if(Wait_NACK_cnt > 60000)
   {
     I2C1_protect();
     I2C1_Reset();
     Wait_NACK_cnt = 0;
     return;
   }
 }

}
//**********************************************************//
//          MCU(Mater) read data from slave(device)         //
//**********************************************************//

void I2C1_Read (unsigned char ADDR, unsigned char COMMAND)
{ 
 I2C1_Start();               //Start
 
 I2C1_deliver(ADDR|0x00);    //Battery Address and write

 I2CTest = ADDR;

 if(I2C_State.Communication_Fail == 1)
 {
    return;
 }
 
 I2C1_deliver(COMMAND);      //Battery Command code

 if(I2C_State.Communication_Fail == 1)
 {
    return;
 }
  
 Command_code = COMMAND;

 I2C1_Restart();               //Restart

 I2C1_deliver(ADDR|0x01);    //Battery Address and Read             
 
 if(I2C_State.Communication_Fail == 1)
 {
    return;
 }

 data_low = I2C1_receive();  //Receive the low data

 I2C1_ACK();                 //Deliver ACK

 if(I2C_State.Communication_Fail == 1)
 {
    return;
 }

 data_high = I2C1_receive(); //Receive the high data

 I2C1_ACK();                 //Deliver ACK

 if(I2C_State.Communication_Fail == 1)
 {
    return;
 }

 data_PEC = I2C1_receive(); //Receive the PEC
 
 I2C1_NACK();                //Deliver NACK

 if(I2C_State.Communication_Fail == 1)
 {
    return;
 }

 I2C1_Stop();                //Stop

 

 u16_t I2C1_Buff[6] = {ADDR, COMMAND, (ADDR|0x01), data_low, data_high};
 u8_t i;
 u8_t I2C1_CRC8;


 I2C1_CRC8 = 0;

 for(i=0;i<=4;i++)
 {
   CalCRC8(&I2C1_CRC8, I2C1_Buff[i]);
 }

 if(I2C1_CRC8 != data_PEC)
 {
    I2C_State.PEC_error = 1;
 }
 else
 {
    I2C_State.PEC_error = 0;
 }

}

//*********************************************************//
//          MCU(Master) Read block data to slave           //
//*********************************************************//
void I2C1_Block_Read(unsigned char ADDR, unsigned char COMMAND, unsigned char COUNT)
{
  u8_t I2C1_Buff[44]; 
  u8_t i;
 
  memset(I2C1_Buff, 0xFF ,sizeof(I2C1_Buff));
  memset(BatteryBlockBuff, 0x00, sizeof(BatteryBlockBuff));
  
  I2C1_Start();               //Start
 
  I2C1_deliver(ADDR|0x00);    //Battery Address and write

  I2C1_Buff[0] = ADDR;

  if(I2C_State.Communication_Fail == 1)
  {
     return;
  }
 
  I2C1_deliver(COMMAND);      //Battery Command code
  
  I2C1_Buff[1] = COMMAND;

  if(I2C_State.Communication_Fail == 1)
  {
     return;
  }
  
  Command_code = COMMAND;

  I2C1_Restart();               //Restart

  I2C1_deliver(ADDR|0x01);    //Battery Address and Read 

  I2C1_Buff[2] = (ADDR|0x01);            
 
  if(I2C_State.Communication_Fail == 1)
  {
     return;
  }
 
  I2C1_Buff[3] = I2C1_receive();      // byte count

  I2C1_ACK();
  asm("NOP");

  for(i = 0; i < COUNT; i ++)
  {
    BatteryBlockBuff[i] = I2C1_receive();

    I2C1_ACK();
    I2C1_Buff[i+4] = BatteryBlockBuff[i];     
    asm("NOP");

    if(I2C_State.Communication_Fail == 1)
    {
      return;
    }
  }

  data_PEC = I2C1_receive(); //Receive the PEC
 
  I2C1_NACK();                //Deliver NACK

  I2C1_Stop();                //Stop

 
  
  u8_t I2C1_CRC8;
  u8_t CRC_count;

  I2C1_CRC8 = 0;
  CRC_count = COUNT + 4;

  for(i=0;i<CRC_count;i++)
  {
    CalCRC8(&I2C1_CRC8, I2C1_Buff[i]);
  }

 if(I2C1_CRC8 != data_PEC)
 {
    I2C_State.PEC_error = 1;
 }
 else
 {
    I2C_State.PEC_error = 0;
 }

}

//*********************************************************//
//          MCU(Master) write data to slave(device)        //
//*********************************************************//

void I2C1_write(unsigned char ADDR, unsigned char COMMAND2, unsigned char DATA_low, unsigned char DATA_high)
{
 u16_t I2C1_Buff[4] = {ADDR, COMMAND2, DATA_low, DATA_high};
 u8_t i;
 u8_t I2C1_CRC8; 

 I2C1_Start();               //Start

 I2C1_deliver(ADDR|0x00);    //Battery Address and write

 asm("NOP");

 I2C1_deliver(COMMAND2);     //Battery command code

 asm("NOP");

 I2C1_deliver(DATA_low);     //Data byte low

 asm("NOP");

 I2C1_deliver(DATA_high);    //

 asm("NOP");

 I2C1_CRC8 = 0;

 for(i=0;i<=3;i++)
 {
   CalCRC8(&I2C1_CRC8, I2C1_Buff[i]);
 }

 I2C1_deliver(I2C1_CRC8);    //PEC

 asm("NOP");

 I2C1_Stop();

}


//*********************************************************//
//          MCU(Master) Block write data to slave(device)  //
//*********************************************************//

void I2C1_Block_Write(unsigned char ADDR, unsigned char COMMAND, unsigned char COUNT)
{
   

   I2C_State.Communication_Fail = 0;  

   I2C1_Start();               //Start

   I2C1_deliver(ADDR|0x00);    //Battery Address and write

   if(I2C_State.Communication_Fail == 1)
   {
      return;
   }

   asm("NOP");

   I2C1_deliver(COMMAND);     //Battery command code

   if(I2C_State.Communication_Fail == 1)
   {
      return;
   }

   asm("NOP");
      
   u8_t i = 0;
   for(i = 0; i < COUNT; i ++)
   {
       I2C1_deliver(TempBlockBuff[i]);     //Data byte low
       asm("NOP");
   }
 
   I2C1_Stop();

}


//************ EEPROM Read word ************//

void I2C1_EEPROM_Read(unsigned char ADDR, unsigned char COMMAND)
{
  I2C_State.Communication_Fail = 0;

  I2C1_Start();               //Start
 
  I2C1_deliver(ADDR|0x00);    //Battery Address and write

  I2CTest = ADDR;

  if(I2C_State.Communication_Fail == 1)
  {
     return;
  }
 
  I2C1_deliver(COMMAND);      //Battery Command code

  if(I2C_State.Communication_Fail == 1)
  {
     return;
  }
  
  Command_code = COMMAND;

  I2C1_Restart();               //Restart

  I2C1_deliver(ADDR|0x01);    //Battery Address and Read             
 
  if(I2C_State.Communication_Fail == 1)
  {
     return;
  }

  data_low = I2C1_receive();  //Receive the low data

  I2C1_ACK();                 //Deliver ACK

  data_high = I2C1_receive(); //Receive the high data

  I2C1_NACK();                //Deliver NACK

  I2C1_Stop();                //Stop

}

//************* EEPROM write word *****************//

void I2C1_EEPROM_Write(unsigned char ADDR, unsigned char COMMAND, unsigned char DATA_low, unsigned char DATA_high)
{
  I2C_State.Communication_Fail = 0;  

  I2C1_Start();               //Start

  I2C1_deliver(ADDR|0x00);    //Battery Address and write

  if(I2C_State.Communication_Fail == 1)
  {
     return;
  }

  asm("NOP");

  I2C1_deliver(COMMAND);     //Battery command code

  if(I2C_State.Communication_Fail == 1)
  {
     return;
  }

  asm("NOP");

  I2C1_deliver(DATA_low);     //Data byte low

  if(I2C_State.Communication_Fail == 1)
  {
     return;
  }

  asm("NOP");

  I2C1_deliver(DATA_high);    //

  if(I2C_State.Communication_Fail == 1)
  {
     return;
  }

  asm("NOP");

  I2C1_Stop();

}

//********************** EEPROM Block Write **********************

void I2C1_EEPROM_Block_Write(unsigned char ADDR,unsigned char COMMAND, unsigned char COUNT)
{
   I2C_State.Communication_Fail = 0;  

   I2C1_Start();               //Start

   I2C1_deliver(ADDR|0x00);    //Battery Address and write

   if(I2C_State.Communication_Fail == 1)
   {
      return;
   }

   asm("NOP");

   I2C1_deliver(COMMAND);     //Battery command code

   if(I2C_State.Communication_Fail == 1)
   {
      return;
   }

   asm("NOP");
      
   u8_t i = 0;
   for(i = 0; i < COUNT; i ++)
   {
       I2C1_deliver(TempBlockBuff[i]);     //Data byte low
       asm("NOP");
   }
 
   I2C1_Stop();

}  

//******************* EEPROM Block Read ************************//

void I2C1_EEPROM_Block_Read(unsigned char ADDR, unsigned char COMMAND, unsigned char COUNT)
{
  I2C_State.Communication_Fail = 0;

  Initial_Block_Buff();

  I2C1_Start();               //Start
 
  I2C1_deliver(ADDR|0x00);    //Battery Address and write

  if(I2C_State.Communication_Fail == 1)
  {
     return;
  }
 
  I2C1_deliver(COMMAND);      //Battery Command code

  if(I2C_State.Communication_Fail == 1)
  {
     return;
  }
  
  Command_code = COMMAND;

  I2C1_Restart();               //Restart

  I2C1_deliver(ADDR|0x01);    //Battery Address and Read             
 
  if(I2C_State.Communication_Fail == 1)
  {
     return;
  }

  u8_t i = 0;
  for(i = 0; i < COUNT-1; i ++)
  {
    TempBlockBuff[i] = I2C1_receive();  //Receive the low data

    I2C1_ACK();                 //Deliver ACK
  }

  TempBlockBuff[COUNT-1] = I2C1_receive(); //Receive the high data

  I2C1_NACK();                //Deliver NACK

  I2C1_Stop();                //Stop

}

//*********************** END I2C1 Master *************************//



void I2C_Delay(unsigned int I2C_Delay_CNT)
{
  unsigned int I2C_Delay = 0;
  for(I2C_Delay = 0;I2C_Delay < I2C_Delay_CNT;I2C_Delay++);
}

//****************** Initialize Temp Block Buffer ******************//

void Initial_Block_Buff(void)
{
  TempBlockBuff[0] = 0;
  TempBlockBuff[1] = 0;
  TempBlockBuff[2] = 0;
  TempBlockBuff[3] = 0;
  TempBlockBuff[4] = 0;
  TempBlockBuff[5] = 0;
  TempBlockBuff[6] = 0;
  TempBlockBuff[7] = 0;
  TempBlockBuff[8] = 0;
  TempBlockBuff[9] = 0;
  TempBlockBuff[10] = 0;
  TempBlockBuff[11] = 0;
  TempBlockBuff[12] = 0;
  TempBlockBuff[13] = 0;
  TempBlockBuff[14] = 0;
  TempBlockBuff[15] = 0;
 }



