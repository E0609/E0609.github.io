#include <p24FJ64GA006.h>
#include "bms_Pin_Define.h"
#include "GenericTypeDefs.h"
#include "I2C.h"
#include "Battery_status.h"
#include "PMBusData.h"
#include "PMBus_status.h"
#include "Failure.h"
#include "EEPROM.h"
#include <string.h>

u8_t EEPROM_Failure_count = 0;



u16_t EEPROM_demo = 0;

EEPROM_Info_T EEPROM_Info;

void EEPROM_Write(void)
{
  I2C1_EEPROM_Write(EEPROM_Address, EEPROM_Flag_Cmd, 0x01, 0x00);
  asm("NOP");
  asm("NOP");
  asm("NOP");
}
void EEPROM_Read(void)
{
  if(EEPROM_Info.Flag == 1)
  {
//-------------- Offline Vref Duty ----------//
    I2C1_EEPROM_Read(EEPROM_Address, EEPROM_Offline_Duty_Cmd);
    EEPROM_Info.Offline_Duty = (data_high<< 8 ) + data_low ;
    asm("NOP");
    asm("NOP");
  
    u16VrefOffline = EEPROM_Info.Offline_Duty;

//-------------- Online Vref Duty ------------//

    I2C1_EEPROM_Read(EEPROM_Address, EEPROM_Online_Duty_Cmd);
    EEPROM_Info.Online_Duty = (data_high<< 8) + data_low;
    asm("NOP");
    asm("NOP");

    u16VrefOnline = EEPROM_Info.Online_Duty;

//-------------- Trim Duty -----------------//

    I2C1_EEPROM_Read(EEPROM_Address, EEPROM_Trim_Duty_Cmd);
    EEPROM_Info.Trim_Duty = (data_high<< 8) + data_low;
    asm("NOP");
    asm("NOP");

    u16TrimDuty = EEPROM_Info.Trim_Duty;

//-----.--------- Voltage ADC Gain ------------//

    I2C1_EEPROM_Read(EEPROM_Address, EEPROM_Voltage_ADC_Cmd);
    EEPROM_Info.Voltage_ADC_Gain = (data_high<< 8) + data_low;
    asm("NOP");
    asm("NOP");
    Voltage_ADC_Gain = EEPROM_Info.Voltage_ADC_Gain;

  }

  if(EEPROM_Info.Failure_Flag == 1)
  {

//-------------- Last BBU protection type Low -----------//

    I2C1_EEPROM_Read(EEPROM_Address, EEPROM_Protect_type_Low_Cmd);
    EEPROM_Info.Protection_Type_Low = (data_high << 8) + data_low;
    asm("NOP");
    asm("NOP");

    u16LastProtectLow = EEPROM_Info.Protection_Type_Low;

//-------------- Last BBU protection type High ------------//

    I2C1_EEPROM_Read(EEPROM_Address, EEPROM_Protect_type_High_Cmd);
    EEPROM_Info.Protection_Type_High = (data_high << 8) + data_low;
    asm("NOP");
    asm("NOP");

    u16LastProtectHigh = EEPROM_Info.Protection_Type_High;
  }
}

void EEPROM_Control(void)
{
  if(EEPROM_10ms_Write == 1)
  {
   
    if(SystemControl.bits.Flag_Failure == 1 || SystemControl.bits.Flag_Not_Reset_Failure == 1)
    {
       EEPROM_Failure_Write();
       EEPROM_10ms_Write = 0;
    }

    if(u8Calibration == 1)
    {
      EEPROM_Calibration_Write();
      EEPROM_10ms_Write = 0;
    }
    
    if(u8Calibration == 3)
    {
      EEPROM_Battery_Write();
      EEPROM_10ms_Write = 0;
    }

    if(u8Calibration == 4)
    {
      EEPROM_Cycle_Cnt_Write();
      EEPROM_10ms_Write = 0;
    }
 
    if(u8Calibration == 6)
    {
      EEPROM_Ambient_OTP_Write();
      EEPROM_10ms_Write = 0;
    }

    if(u8Calibration == 7)
    {
      EEPROM_SerialNumber_Write();
      EEPROM_10ms_Write = 0;
    }

    if(u8Calibration == 8)
    {
      EEPROM_Failure_Write();
      EEPROM_10ms_Write = 0;

    }

    if(u8Calibration == 9)
    {
      EEPROM_BatteryNot_Write();
      EEPROM_10ms_Write = 0;

    }

  }

  

}

void EEPROM_Failure_Write(void)
{
   if(EEPROM_Failure_count != 4)
   {
     EEPROM_Failure_count ++;
   }
   
    switch(EEPROM_Failure_count)
    {
      case 1:
       EEPROM_Info.Protection_Type_Low_L = Failure_type.val;
       EEPROM_Info.Protection_Type_Low_H = (Failure_type.val >> 8);
       I2C1_EEPROM_Write(EEPROM_Address, EEPROM_Protect_type_Low_Cmd, EEPROM_Info.Protection_Type_Low_L, EEPROM_Info.Protection_Type_Low_H);
       asm("NOP");
       asm("NOP");
       asm("NOP");

         break;

      case 2:
       EEPROM_Info.Protection_Type_High_L = (Failure_type.val >> 16);
       EEPROM_Info.Protection_Type_High_H = (Failure_type.val >> 24);
       I2C1_EEPROM_Write(EEPROM_Address, EEPROM_Protect_type_High_Cmd, EEPROM_Info.Protection_Type_High_L, EEPROM_Info.Protection_Type_High_H);
       asm("NOP");
       asm("NOP");
       asm("NOP");

         break;

      case 3:
       I2C1_EEPROM_Write(EEPROM_Address, EEPROM_Failure_Flag_Cmd, 0x01, 0x00);
       asm("NOP");
       asm("NOP");
       asm("NOP");

      default:
         
          break;
   }

    
}

void EEPROM_Calibration_Write(void)
{
    if(EEPROM_count != 6)
    {
      EEPROM_count ++;
    } 
  
    switch(EEPROM_count)
    {
     case 1:
       
       EEPROM_Info.Offline_Duty_L = u16VrefOffline;
       EEPROM_Info.Offline_Duty_H = (u16VrefOffline >> 8);
       I2C1_EEPROM_Write(EEPROM_Address, EEPROM_Offline_Duty_Cmd, EEPROM_Info.Offline_Duty_L, EEPROM_Info.Offline_Duty_H);
       asm("NOP");
       asm("NOP");
       asm("NOP");
     
        break;
    

     case 2:
       EEPROM_Info.Online_Duty_L = u16VrefOnline;
       EEPROM_Info.Online_Duty_H = (u16VrefOnline >> 8);
       I2C1_EEPROM_Write(EEPROM_Address, EEPROM_Online_Duty_Cmd, EEPROM_Info.Online_Duty_L, EEPROM_Info.Online_Duty_H);
       asm("NOP");
       asm("NOP");
       asm("NOP");
     
        break;

     case 3:
       EEPROM_Info.Trim_Duty_L = u16TrimDuty;
       EEPROM_Info.Trim_Duty_H = (u16TrimDuty >> 8);
       I2C1_EEPROM_Write(EEPROM_Address, EEPROM_Trim_Duty_Cmd, EEPROM_Info.Trim_Duty_L, EEPROM_Info.Trim_Duty_H);
       asm("NOP");
       asm("NOP");
       asm("NOP");
  
        break;

     case 4:
       EEPROM_Info.Voltage_ADC_Gain_L = Voltage_ADC_Gain;
       EEPROM_Info.Voltage_ADC_Gain_H = (Voltage_ADC_Gain >> 8);
       I2C1_EEPROM_Write(EEPROM_Address, EEPROM_Voltage_ADC_Cmd, EEPROM_Info.Voltage_ADC_Gain_L, EEPROM_Info.Voltage_ADC_Gain_H);
       asm("NOP");
       asm("NOP");
       asm("NOP");
     
     case 5:
       EEPROM_Write();

     default:

        break; 
     
    }

   
}

void EEPROM_Battery_Write(void)
{
   I2C1_EEPROM_Write(EEPROM_Address, EEPROM_Read_Battery_Cmd, 0x01, 0x00);
   asm("NOP");
   asm("NOP");
   asm("NOP");

}


void EEPROM_Cycle_Cnt_Write(void)
{
   EEPROM_Info.Cycle_Cnt_Offset_L = Cell_Info.CycleCount;
   EEPROM_Info.Cycle_Cnt_Offset_H = (Cell_Info.CycleCount >> 8);
   I2C1_EEPROM_Write(EEPROM_Address, EEPROM_Cycle_Cnt_Cmd, EEPROM_Info.Cycle_Cnt_Offset_L, EEPROM_Info.Cycle_Cnt_Offset_H);
   asm("NOP");
   asm("NOP");
   asm("NOP");

}

void EEPROM_Ambient_OTP_Write(void)
{
   I2C1_EEPROM_Write(EEPROM_Address, EEPROM_Ambient_OTP_Cmd, 0x01, 0x00);
   asm("NOP");
   asm("NOP");
   asm("NOP");

}


void EEPROM_SerialNumber_Write(void)
{
  I2C1_EEPROM_Barcode_Block_Write(EEPROM_Address, EEPROM_SerialNumber_Cmd, 15);
  asm("NOP");
  asm("NOP");
  asm("NOP");

}

void EEPROM_BatteryNot_Write(void)
{
  I2C1_EEPROM_Write(EEPROM_Address, EEPROM_Read_Battery_Cmd, 0x00, 0x00);
  asm("NOP");
  asm("NOP");
  asm("NOP");

}

void EEPROM_Time_Minute_Write(void)
{
    if(System_Run.Flag_1minute == 1)
    {
       System_Run.Time_Total_Minute = System_Run.Time_Minute + EEPROM_Info.Time_Minute;
       Initial_Block_Buff();
       memcpy(TempBlockBuff, &System_Run.Time_Total_Minute, sizeof(System_Run.Time_Total_Minute));

       I2C1_EEPROM_Block_Write(EEPROM_Address, EEPROM_Time_Minute_Cmd, 4); 
    
       System_Run.Flag_1minute = 0;    
    }
    
}

void EEPROM_Time_Minute_Read(void)
{
   I2C1_EEPROM_Block_Read(EEPROM_Address, EEPROM_Time_Minute_Cmd, 4);
   memcpy(&EEPROM_Info.Time_Minute, TempBlockBuff, sizeof(EEPROM_Info.Time_Minute));
   
   if(EEPROM_Info.Time_Minute == 0xFFFFFFFF)
   {
      EEPROM_Info.Time_Minute = 0;
   }

}

//void EEPROM_Time_Minute

