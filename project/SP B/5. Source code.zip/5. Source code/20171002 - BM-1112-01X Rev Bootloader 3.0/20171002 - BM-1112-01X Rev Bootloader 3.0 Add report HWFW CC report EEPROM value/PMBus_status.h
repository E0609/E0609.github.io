#ifndef __PMBUS_STATUS_H__
#define __PMBUS_STATUS_H__


//---------- Status Word --------------//
#define Status_Word_bits_Vout          0x8000
#define Status_Word_bits_Iout          0x4000
#define Status_Word_bits_Input         0x2000
#define Status_Word_bits_Power_Good    0x0800
#define Status_Word_bits_Fans          0x0400
#define Status_Word_bits_Off           0x0040
#define Status_Word_bits_Iout_OC_Fault 0x0010
#define Status_Word_bits_Vin_UV_Fault  0x0008
#define Status_Word_bits_Temperature   0x0004
#define Status_Word_bits_CML           0x0002

//---------- Status BBU -------------- //
#define Status_BBU_bits_Other_Internal_Failure     0x80
#define Status_BBU_bits_Disharge_Remain_time_less  0x40
#define Status_BBU_bits_Battery_SOH_Low_Warning    0x20
#define Status_BBU_bits_Battery_Low_Warning        0x10          // ok
#define Status_BBU_bits_Battery_Low_Fault          0x08          // ok
#define Status_BBU_bits_BMS_Communication_loss     0x04          // ok
#define Status_BBU_bits_Battery_PF                 0x02          // ok
#define Status_BBU_bits_Battery_Bad                0x01


//---------- Status Vout --------------//
#define Status_Vout_bits_Vout_OV_Fault    0x80
#define Status_Vout_bits_Vout_OV_Warning  0x40
#define Status_Vout_bits_Vout_UV_Warning  0x20
#define Status_Vout_bits_Vout_UV_Fault    0x10

//---------- Status Iout --------------//
#define Status_Iout_bits_Iout_OC_Fault    0x80
#define Status_Iout_bits_Iout_OC_Warning  0x20
#define Status_Iout_bits_Pout_OP_Fault    0x02
#define Status_Iout_bits_Pout_OP_Warning  0x01

//---------- Status Input -------------//
#define Status_Input_bits_Vin_OV_Fault     0x80
#define Status_Input_bits_Vin_OV_Warning   0x40
#define Status_Input_bits_Vin_UV_Warning   0x20
#define Status_Input_bits_Vin_UV_Fault     0x10
#define Status_Input_bits_Unit_Off_For_Low_Input_Voltage  0x08
#define Status_Input_bits_Iin_OC_Fault     0x04
#define Status_Input_bits_Iin_OC_Warning   0x02
#define Status_Input_bits_Pin_OP_Warning   0x01

//---------- Status Temperature ---------//
#define Status_Temperature_bits_OT_Fault    0x80
#define Status_Temperature_bits_OT_Warning  0x40

//---------- Status CML -------------//
#define Status_CML_bits_Invalid_Cmd    0x80
#define Status_CML_bits_Invalid_data   0x40
#define Status_CML_bits_PEC_Fail       0x20


#endif
