/********************************************************************************
* file				PMBusData.c
*
* brief				The file includes the function and data structure/variables
*					for the PMBus protocol
*
* note
*
* author			slade.fang
*
* version			01
*
* section History	2014/09/01	-	1st release
********************************************************************************/

#include "PMBusApp.h"
#include "PMBusData.h"
#include "QTBootloader.h"


//Test data for PMBus protocol
u8_t PMBus_CurrPage;
u8_t u8ClrFaultP0;
u8_t u8ClrFaultP1;
u8_t pu8PgPlusWr[0];
u8_t pu8PgPlusRd[0];
u8_t pu8MFRModel[12];
u8_t u8WriteProtect;
u16_t u16StatusP0Word;			//command 79h, page0
u8_t u8StatusP0CML;				//command 7Eh, page0
u8_t u8StatusP1CML;				//command 7Eh, page1
u16_t u16StatusMP0Word;			//command 79h mask, page0
u8_t u8StatusMP0CML;			//command 7Eh mask, page0
u8_t u8StatusMP1CML;			//command 7Eh mask, page1
u8_t pu8BBUCompatible[11];







//The data structures are used for PMBusApp.c, User must define for the application.
//The example is for BBU 600Watt product
//define the read only command structure
sPMBusCmdRdStr_t sPMBusRdCmd[USER_PMBUS_RDNUM] = 
{
    {PMBusCmd_MFRSp44, 		PMBusCmdT_RdBlock,		PMBusDataT_NN_Block,13,	0,	pu8BBUCompatible,			pu8BBUCompatible},
};

//define the write(write or write-read) command structure
sPMBusCmdWrStr_t sPMBusWrCmd[USER_PMBUS_WRNUM] =
{
    {PMBusCmd_Page, 		PMBusCmdT_RdWrByte,		PMBusDataT_u8,		2,	2,	&u8CurrPage,			&u8CurrPage,			0,		0},
	{PMBusCmd_ClrFault, 	PMBusCmdT_SendByte,		PMBusDataT_NN_Block,0,	2,	&u8ClrFaultP0,			&u8ClrFaultP1,			3,		3},
    {PMBusCmd_MFRModel, 	PMBusCmdT_RdWrBlock,	PMBusDataT_NN_Block,13,	13,	pu8MFRModel,			pu8MFRModel,			0x9a,	0x9a},    
};
//define the status command structure
sPMBusCmdStatusStr_t sPMBusStatusCmd[USER_PMBUS_STNUM] =
{
  {PMBusCmd_StatusCML, 	PMBusCmdT_RdWrByte,		PMBusDataT_NN_Block,2,	2,	(u8_t*)&u8StatusP0CML,		(u8_t*)&u8StatusP1CML,			0x7e, 0x7e,	(u8_t*)&u8StatusMP0CML,			(u8_t*)&u8StatusMP1CML},
};

sPMBusCmdWrLimitStr_t sPMBusWrLimit[USER_PMBUS_WRLIMITNUM] =
{
	
};

//init the variables used in PMBus module before while(1) in main().
void PMBusTstInit(void)
{
    u8WriteProtect = 0x00;
	u8ClrFaultP0 = 0;
	u8ClrFaultP1 = 0;
    PMBus_CurrPage = 0;
    pu8MFRModel[0] = 'B';
	pu8MFRModel[1] = 'M';
	pu8MFRModel[2] = '-';
	pu8MFRModel[3] = '1';
	pu8MFRModel[4] = '1';
	pu8MFRModel[5] = '1';
	pu8MFRModel[6] = '2';
    pu8MFRModel[7] = '-';
    pu8MFRModel[8] = '0';
    pu8MFRModel[9] = '1';
    pu8MFRModel[10] = 'X';
    pu8BBUCompatible[0] = '-';
    pu8BBUCompatible[1] = '-';
    pu8BBUCompatible[2] = '-';
    pu8BBUCompatible[3] = '-';
    pu8BBUCompatible[4] = '-';
    pu8BBUCompatible[5] = '-';
    pu8BBUCompatible[6] = '-';
    pu8BBUCompatible[7] = '-';
    pu8BBUCompatible[8] = '0';
    pu8BBUCompatible[9] = '0';
    pu8BBUCompatible[10] = 0x00;
    
}

