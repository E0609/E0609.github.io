/*********************************************************************** 
 *    Author:         Jeff JH Hsiao                                    *
 *    Company:            Liteon                                       * 
 *    Filename:         BBU 1.1KW                                      *	
 *    Date:           6/23/2014                                        *
 *    File Version:   1.0                                              *
 *    Other Files Required: p24FJ64GA006.gld			               *
 *    Tools Used: MPLAB IDE    -> 8.92 up                              *
 *                C30 Compiler -> 3.01 up                              *
 *                                                                     *
 **********************************************************************/

//Include the appropriate header (.h) file, depending on device used
//Example (for PIC24FJ128GA010): #include <p24FJ128GA010.h>          

#include <p24FJ64GA006.h>
#include "bms_Pin_Define.h"	
#include "I2C.h"
#include "GenericTypeDefs.h"
#include "main.h"
#include <string.h>
#include "PMBusAPP.h"
#include "PMBusData.h"
#include "SI2CDrv.h"	
#include "PMBus_status.h"		
#include "FlashDriver.h"
#include "QTBootloader.h"
#include "SI2CMiddle.h"


//Configuration Bit Macros to define device config registers.
//Device header file contains usage details

_CONFIG1(JTAGEN_OFF & GCP_OFF & GWRP_OFF & BKBUG_OFF & COE_OFF & ICS_PGx1 & FWDTEN_OFF & WINDIS_OFF & FWPSA_PR32 & WDTPS_PS32768)
_CONFIG2(IESO_OFF & FNOSC_FRCPLL & FCKSM_CSDCMD & OSCIOFNC_OFF & POSCMOD_NONE) 


// Define constants here                            			     

#define CONSTANT1 10
#define CONSTANT2 20
#define V_ref_Initial_Duty 0
#define EEPROM_Address                    0xA0
#define EEPROM_Compatible_Cmd             0x60



/************* START OF GLOBAL DEFINITIONS ****************************/					

//Define global variables without attributes       									

u8_t  Time_100ms_count = 0;
u8_t  Time_100ms_Flag = 0;
u8_t  GotAddr = 0;
u16_t EEPROM_Info_HW_Compatible_Code = 0;



 


//Function prototype
  
void Initial_system(void);
void AD_data_type_transfor(void);
void System100ms(void);
void T1ISR(void);
void T4ISR(void);
void GetAddr(void);
void T5ISR(void);



Flag_t Flag;
SystemControl_t  SystemControl;
BBU_Info_T BBU_Info;
System_Run_T  System_Run;

//BBU_mode_t BBU_mode;

/************** END OF GLOBAL DEFINITIONS *****************************/


/************* START OF MAIN FUNCTION *********************************/

int main ( void )
{
	Initial_system();
    T1CONbits.TON = 1;                   // Timer 1 start count
    T4CONbits.TON = 1;                   // Timer 4 start count    
  
    
    SI2CDrvInit();                       // Initial SI2CDrv
     
    PMBusInit();
    PMBusTstInit();
    QTBootloaderInit();

    I2C1_EEPROM_Read(EEPROM_Address, EEPROM_Compatible_Cmd);
    EEPROM_Info_HW_Compatible_Code = (data_high<< 8) + data_low;
    pu8BBUCompatible[8] = data_high;
    pu8BBUCompatible[9] = data_low;
    asm("NOP");
    asm("NOP");
     
     
	while(1)
    {
        if(IFS0bits.T1IF == 1)
        {         
	         T1ISR();          
			     IFS0bits.T1IF = 0;
        }
       
        if(IFS1bits.T4IF == 1)
        {
          T4ISR();
			     IFS1bits.T4IF = 0;			
     	  }
  
        if(IFS3bits.SI2C2IF == 1)
    		{
        
    			//testpin = 1;
    			SI2CISR();
    			IFS3bits.SI2C2IF = 0;
    			//testpin = 0;
    		}         
   
        SI2CMiddleMapRxData();        
        QTBootloaderProcess();
    
        CheckClockHold();      
        
 	}
	
    return 0;
     
	//Add Code Here

}
/************* END OF MAIN FUNCTION ***********************************/
void T1ISR(void)
{
   Time_100ms_count ++;
   if(Time_100ms_count == 10)
   {
     Time_100ms_Flag = 1;
     Time_100ms_count = 0;

     if(GotAddr == 0)
     {
       GetAddr();
       GotAddr = 1;
     }
   }
 
/*****************************************/
   System_Run.Time_10ms++;
    if(System_Run.Time_10ms == 100)
    {
      System_Run.Time_10ms = 0;
      System_Run.Time_1s++;
      if(System_Run.Time_1s == 60)
      {
        System_Run.Flag_1minute = 1;
        System_Run.Time_1s = 0;
        System_Run.Time_1min++;
        System_Run.Time_Minute++;
        if(System_Run.Time_1min == 60)
        {
          System_Run.Time_1min = 0;
          System_Run.Time_1hour++;
          if(System_Run.Time_1hour == 24)
          {
            System_Run.Time_1hour = 0;
            System_Run.Time_1day++;
          }
        }
      }
    }

}

void T4ISR(void)
{
  if(System_Run.Time_1ms == 0)
  {
    System_Run.Time_1ms = 1;
  }
  else
  {
    System_Run.Time_1ms = 0;
  }
  
   BootDoneReset();
   GotoApp();
  
}

void GetAddr(void)
{
    u8_t tmp;
    tmp = 0x50;
    if(BBS_A0 == 1) tmp |= 0x02;
  	if(BBS_A1 == 1) tmp |= 0x01;
  	if(BBS_A2 == 1) tmp |= 0x08;
    if(BBS_A3 == 1) tmp += 0x10;
    if(BBS_A4 == 1) 
    { 
      tmp -= 0x50;
      tmp += 0x08;
    }

    I2C2ADD = tmp;
 
}


void System100ms(void)
{
  if(Time_100ms_Flag == 1)
  {
     Time_100ms_Flag = 0;
  }
}


/********* END OF INTERRUPT SERVICE ROUTINES **************************/
void Initial_system(void)
{ 
//--------------------- System signal I/O direction -----------------
   d_BBS_AC_GOOD = 1;
   d_BBS_PS_KILL = 1;
   d_BBS_ON = 1;
   d_BBS_A0 = 1;
   d_BBS_A1 = 1;
   d_BBS_A2 = 1;
   d_BBS_A3 = 1;
   d_BBS_A4 = 1;
   d_BBS_SDA = 1;
   d_BBS_SCL = 1;
//---------------------- Discharger I/O direction -----------------------------
   d_DISCHG_EN1 = 0;
   d_DISCHG_EN2 = 0;
   d_ORFET_EN = 0;
//---------------------- Charger I/O direction --------------------------------
   d_CHG_CONTROL = 0;
   d_CHG_EN = 0;
   d_CHG_MOS_IN = 0;
   d_CHG_MOS_OUT = 0;
//---------------------- BMS signal I/O direction ------------------------------
   d_SYS_PRES = 0;
//   d_ICELL_TOTAL = 1;
   d_BMS_SDA = 1;
   d_BMS_SCL = 1;
//---------------------- Current sharing signal I/O direction-------------------
   d_VREF = 0;
   d_TRIM_CS = 0;
   d_SHUTDOWN = 0;
   d_VOUT_HIGH = 0;
//   VOUT_HIGH = 0;
   d_CS_EN = 0;
//---------------------- Test signal I/O direction ---------------------
   d_TEST1 = 0;
   d_TEST2 = 0;
   d_TEST3 = 0;
   d_TEST4 = 0;
   
//----------------------------------------------------------
  OSCCONbits.COSC = 0;          // FRCPLL
  CLKDIVbits.DOZE = 0;          // Clock ratio -> 1:1
 

  AD1PCFG = 0xFC03;
//----------------------I2C_initial--------------------------
  I2C1_INIT();

//----------CLKDIV-----------	

  CLKDIVbits.RCDIV0 = 0;	    // Fosc = 4Mhz*4 -> PLL = 16MHz -> Fcy = Fosc/2 = 8MHz   
  CLKDIVbits.RCDIV1 = 0;
  CLKDIVbits.RCDIV2 = 0;   


//  RCONbits.SWDTEN = 1;        // Enable Watch Dog

//------------Timer 1---------------------
  
  IEC0bits.T1IE = 0;            // disable Timer1 interrupt
  IFS0bits.T1IF = 1;            // Clear Timer1 Interrupt Flag 
  IPC0bits.T1IP = 4;            // priority = 4


  T1CONbits.TCS = 0;            // Internal clock (Fosc/2)

  T1CONbits.TCKPS1 = 0;         // Clock prescale -> 01=8:1  10=64:1  11=264:1
  T1CONbits.TCKPS0 = 1;
  
  PR1 = 20000;                  // 1/16MHz*8*20000 = 10ms(12.5)

//----------------Timer 4----------------------

  IEC1bits.T4IE = 0;            // disable Timer1 interrupt
  IFS1bits.T4IF = 1;            // Clear Timer1 Interrupt Flag 
  IPC6bits.T4IP = 4;            //  priority = 5

  T4CONbits.TCS = 0;            // Internal clock (Fosc/2)

  T4CONbits.TCKPS1 = 0;         // Clock prescale -> 01=8:1  10=64:1  11=264:1
  T4CONbits.TCKPS0 = 1;
  
  PR4 = 2000;                   // 1/16MHz*8*2000 = 1ms(12.5)


//---------------SI2C BBS_Communication--------

  IEC3bits.SI2C2IE = 0;         // Disable SI2C2 interrupt
  IFS3bits.SI2C2IF = 0;         // Clear SI2C2 Interrupt Flag
  IPC12bits.SI2C2IP = 5;         // Priority = 4

  
     
}  // end Initial_system()



