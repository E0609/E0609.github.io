#include <p24FJ64GA006.h>
#include "bms_Pin_Define.h"
#include "GenericTypeDefs.h"
#include "I2C.h"
#include "Battery_status.h"
#include "PMBusData.h"
#include "PMBus_status.h"
#include "Failure.h"
#include "EEPROM.h"
#include <string.h>

u16_t Voltage_1x = 0, Voltage_2x = 0, Voltage_3x = 0;
u8_t Battery_count = 0;
u8_t Battery_count2 = 0;
u8_t Battery_Current_Read_Flag = 0;

Cell_Info_T Cell_Info;
/************ Battery Diagnostic **************/
void Battery_diagnostic(void)  //Ū���q����l���A
{
  
}

void Battery_MOS_control(void)
{

}

void Read_Battery_data(void)
{

  if(Battery_count == 4)
  {
    Battery_count = 0;
  }
  
  Battery_count++;

//  Battery_count = 2;
  switch(Battery_count)
  {
    case 1:
    I2C1_Read(Battery_Address,ReadBattery_Temperature);          // ReadBattery_Temperature
    if(I2C_State.PEC_error == 0 && I2C_State.Communication_Fail == 0)
    {
      Cell_Info.Temp = ((data_high<< 8 ) + data_low)/10;
    }
    asm("NOP");
    asm("NOP"); 

     break;

    case 2:
    I2C1_Read(Battery_Address,ReadBattery_Voltage);              // ReadBattery_Voltage
    if(I2C_State.PEC_error == 0 && I2C_State.Communication_Fail == 0)
    {
      Cell_Info.Voltage = ((data_high<< 8 ) + data_low)*2;
    }
    asm("NOP");
    asm("NOP");
    

      break;

    case 3:
    I2C1_Read(Battery_Address,ReadBattery_Current);              // ReadBattery_Current
    if(I2C_State.PEC_error == 0 && I2C_State.Communication_Fail == 0)
    {
      Cell_Info.Current = ((data_high<< 8 ) + data_low)*8;
      Battery_Current_Read_Flag = 1;
    }
	asm("NOP");
    asm("NOP");

      break;

    case 4:
    if(Battery_count2 == 13)
    {
      Battery_count2 = 0;    
    }
    Battery_count2++;
      switch(Battery_count2)
      {
        case 1:
        I2C1_Read(Battery_Address,ReadBattery_RemainingCapacity);
        if(I2C_State.PEC_error == 0 && I2C_State.Communication_Fail == 0)
        {  
          Cell_Info.RemainingCapacity = (data_high<< 8 ) + data_low;
        }
		asm("NOP");
        asm("NOP");
          break;

        case 2:
        I2C1_Read(Battery_Address,ReadBattery_RelativeStateOfCharge);
        if(I2C_State.PEC_error == 0 && I2C_State.Communication_Fail == 0)
        {
          Cell_Info.RSOC = (data_high<< 8 ) + data_low;
        }
        asm("NOP");
        asm("NOP");
          break;

        case 3:
        I2C1_Read(Battery_Address,ReadBattery_AbsoluteStateOfCharge);
        if(I2C_State.PEC_error == 0 && I2C_State.Communication_Fail == 0)
		{
          Cell_Info.ASOC = (data_high<< 8 ) + data_low;
        }      
		asm("NOP");
        asm("NOP");
          break;

        case 4:
        I2C1_Read(Battery_Address,ReadBattery_PFStatus);
        if(I2C_State.PEC_error == 0 && I2C_State.Communication_Fail == 0)
		{
		  Cell_Info.PermanentFailureStatus.Val = (data_high<< 8 ) + data_low;
        }      
		asm("NOP");
        asm("NOP");
          break;
           
        case 5:
        I2C1_Read(Battery_Address,ReadBattery_BatteryStatus);
        if(I2C_State.PEC_error == 0 && I2C_State.Communication_Fail == 0)
		{
		  Cell_Info.BatteryStatus.Val = (data_high<< 8 ) + data_low;
  		}      
		asm("NOP");
        asm("NOP");
          break;

        case 6:
        I2C1_Read(Battery_Address,ReadBattery_ProtectionStatus);
        if(I2C_State.PEC_error == 0 && I2C_State.Communication_Fail == 0)
		{
		  Cell_Info.ProtectionStatus.Val = (data_high<< 8 ) + data_low;
  		}      
		asm("NOP");
        asm("NOP");
          break;

        case 7:
        I2C1_Read(Battery_Address,ReadBattery_MinCellVoltageHistory);
        if(I2C_State.PEC_error == 0 && I2C_State.Communication_Fail == 0)
		{
		  Cell_Info.CellMinVoltageHis = (data_high<< 8 ) + data_low;
  		}
        asm("NOP");
        asm("NOP");
          break;

        case 8:
        I2C1_Read(Battery_Address,ReadBattery_FirmwareVersion);
        if(I2C_State.PEC_error == 0 && I2C_State.Communication_Fail == 0)
		{
		  Cell_Info.FWRev = (data_high<< 8 ) + data_low;
  		}
        asm("NOP");
        asm("NOP");
          break;

        case 9:
        I2C1_Read(Battery_Address,ReadBattery_12Vloss);
        if(I2C_State.PEC_error == 0 && I2C_State.Communication_Fail == 0)
		{
		  Cell_Info.Voltage_Loss = (data_high << 8 ) + data_low;
  		}
        asm("NOP");
        asm("NOP");
          break;

        case 10:
        I2C1_Read(Battery_Address,ReadBattery_CycleCount);
        if(I2C_State.PEC_error == 0 && I2C_State.Communication_Fail == 0)
		{
          Cell_Info.CycleCount = (data_high << 8 ) + data_low;
          if(EEPROM_Info.Cycle_Cnt_Offset != 65535)
          {
             Cell_Info.CycleCount = (Cell_Info.CycleCount - EEPROM_Info.Cycle_Cnt_Offset);
          }
          
  		}
        asm("NOP");
        asm("NOP");
          break;

        case 11:
        I2C1_Block_Read(Battery_Address, ReadBattery_ManufactureName, 4);
        if(I2C_State.PEC_error == 0 && I2C_State.Communication_Fail == 0)
		{
           memcpy(pu8BatteryName, TempBlockBuff, sizeof(TempBlockBuff));
        }
        asm("NOP");
        asm("NOP");
          break;

        case 12:
        I2C1_Read(Battery_Address, ReadBattery_StateOfHealth);
        if(I2C_State.PEC_error == 0 && I2C_State.Communication_Fail == 0)
		{
           Cell_Info.SOH = (data_high << 8 ) + data_low;
        }
        asm("NOP");
        asm("NOP");
          break;

        case 13:
        I2C1_Read(Battery_Address, ReadBattery_DischargeTime);
        if(I2C_State.PEC_error == 0 && I2C_State.Communication_Fail == 0)
		{
//           Cell_Info.Discharge_Remain_Time = (data_high << 8 ) + data_low;
        }
        asm("NOP");
        asm("NOP");
          break;          
      
        default:
 
          break;
        
      }   

  }  

}



void Battery_status(void)
{
   if(System_Run.I2C_Time_40ms == 1)
   {
     System_Run.I2C_Time_40ms = 0;
     if(I2C_State.Old_Communication == 1)
     {
       I2C_State.Communication_Fail_Count ++;
                 
       if(I2C_State.Communication_Fail_Count >= 250)
       {
          Failure_type.bits.BMS_Communication_loss = 1;
          if(Failure_type.val != 0)
          {
            SystemControl.bits.Flag_Failure = 1;
          }
       }

     }
     else
     {
       I2C_State.Communication_Fail_Count = 0;
       Failure_type.bits.BMS_Communication_loss = 0;
       
     }
      
     I2C_State.Communication_Fail = 0;
     
      Read_Battery_data();
     

   }


}


void Status_BBU_update(void)
{
//--------------------- Remaining Capacity status ---------------------//
   if(Cell_Info.RemainingCapacity < Cell_low_Capacity_Warning_Threshold)
   {
      Warning_type.bits.Cell_low_Capacity_Warning = 1;
      u8StatusP0BBU = u8StatusP0BBU | Status_BBU_bits_Battery_Low_Warning;
      u8StatusP1BBU = u8StatusP1BBU | Status_BBU_bits_Battery_Low_Warning;
   }
   
   else if(Cell_Info.RemainingCapacity > Cell_low_Capacity_Recover_Threshold)
   {
      Warning_type.bits.Cell_low_Capacity_Warning = 0;
      u8StatusP0BBU = (u8StatusP0BBU & ~(Status_BBU_bits_Battery_Low_Warning));
      u8StatusP1BBU = (u8StatusP1BBU & ~(Status_BBU_bits_Battery_Low_Warning));
   }
  
   if(Cell_Info.RemainingCapacity <= Cell_low_Capacity_Protection_Threshold)
   {
      Failure_type.bits.Cell_low_Capacity_Fault = 1;
      u8StatusP0BBU = u8StatusP0BBU | Status_BBU_bits_Battery_Low_Fault;
      u8StatusP1BBU = u8StatusP1BBU | Status_BBU_bits_Battery_Low_Fault;
   }

//-------------------- State of Health warning less than 60% -------------------//
   if(Cell_Info.SOH <= Battery_SOH_Warning_Threshold)
   {
      u8StatusP0BBU = u8StatusP0BBU | Status_BBU_bits_Battery_SOH_Low_Warning; 
      u8StatusP1BBU = u8StatusP1BBU | Status_BBU_bits_Battery_SOH_Low_Warning;
   }
   else
   {
      u8StatusP0BBU = (u8StatusP0BBU & ~(Status_BBU_bits_Battery_SOH_Low_Warning)); 
      u8StatusP1BBU = (u8StatusP1BBU & ~(Status_BBU_bits_Battery_SOH_Low_Warning)); 
   }

 //---------------- Discharge Remaining time less than 3 minute(180 Sec) --------------//  
   if(Cell_Info.Discharge_Remain_Time < Discharge_Remaining_Time_warning_Threshold && BBU_Info.Iout >= 500)
   {
     u8StatusP0BBU = u8StatusP0BBU | Status_BBU_bits_Disharge_Remain_time_less;
     u8StatusP1BBU = u8StatusP1BBU | Status_BBU_bits_Disharge_Remain_time_less;

   }
   else
   {
     u8StatusP0BBU = u8StatusP0BBU & ~(Status_BBU_bits_Disharge_Remain_time_less);
     u8StatusP1BBU = u8StatusP1BBU & ~(Status_BBU_bits_Disharge_Remain_time_less);
   }   

//------------------- BMS communication loss 10 sec ------------------//
   if(Failure_type.bits.BMS_Communication_loss == 1)
   {
      u8StatusP0BBU = u8StatusP0BBU | Status_BBU_bits_BMS_Communication_loss;
      u8StatusP1BBU = u8StatusP1BBU | Status_BBU_bits_BMS_Communication_loss;
      u16StatusP0Word = (u16StatusP0Word | Status_Word_bits_CML);
      u16StatusP1Word = (u16StatusP1Word | Status_Word_bits_CML);     
   }
   else
   {
      u8StatusP0BBU = (u8StatusP0BBU & ~(Status_BBU_bits_BMS_Communication_loss));
      u8StatusP1BBU = (u8StatusP1BBU & ~(Status_BBU_bits_BMS_Communication_loss));
      if(u8StatusP0CML == 0)
      {
       u16StatusP0Word = (u16StatusP0Word & ~(Status_Word_bits_CML));
       u16StatusP1Word = (u16StatusP1Word & ~(Status_Word_bits_CML));
      }
   }

//------------------- Cell Any PF appear -------------//
   if(Cell_Info.PermanentFailureStatus.Val != 0)
   {
      u8StatusP0BBU = u8StatusP0BBU | Status_BBU_bits_Battery_PF;
      u8StatusP1BBU = u8StatusP1BBU | Status_BBU_bits_Battery_PF;
      Failure_type.bits.Cell_PF = 1;
   }
   else
   {
      u8StatusP0BBU =(u8StatusP0BBU & ~(Status_BBU_bits_Battery_PF));
      u8StatusP1BBU =(u8StatusP1BBU & ~(Status_BBU_bits_Battery_PF));  
   }
   


}


