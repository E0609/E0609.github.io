#include <p24FJ64GA006.h>
#include "bms_Pin_Define.h"
#include "GenericTypeDefs.h"
#include "I2C.h"
#include "Battery_status.h"
#include "Charge_control.h"
#include "Discharge_control.h"
#include "Failure.h"
#include "FW_Config.h"
#include "main.h"
#include "PMBus_status.h"
#include "PMBusData.h"
#include "BBU_content.h"


//#define Charger_Voltage_mode

Charger_t Charger;

u8_t Charger_UVP_delay = 0;
u8_t Charger_OTP_delay = 0;
u8_t Charger_Test = 0;
u8_t Charger_OCP_Flag = 0;
u8_t Repeat = 15;
u8_t Repeat1 = 15;
u8_t Repeat2 = 15;
u8_t Repeat3 = 0;
u16_t Charger_OCP_count = 0;


void Initial_Charger(void)
{
  if(SystemControl.bits.Flag_Online_Mode == 1)
  {
    SystemControl.bits.Flag_Online_Discharge = 0;                         // Online mode�U ��q�X���k�s
    SystemControl.bits.Flag_Online_Charge = 1;                            // Online mode�U �R�q�X�Х߰_
  }
  else if(SystemControl.bits.Flag_Offline_Mode == 1) 
  {
    SystemControl.bits.Flag_Offline_Discharge = 0;                        // Offline mode�U ��q�X���k�s
    SystemControl.bits.Flag_Offline_Charge = 1;                           // Offline mode�U �R�q�X�Х߰_
  }
//  Charger.Condition_state = Charger_state_Initial;		                  // ��l���A�� state_Initial
  Charger.FullyCapacity_Setpoint = Battery_FullyCharge_Capacity;          // �R���e�q�]�w���q���R���e�q
  Charger.FullyVoltage_Setpoint = Battery_FullyCharge_Voltage;            // �R���q���]�w���q���R���q��
  Charger.BackCapacity_Setpoint = Battery_BackCharge_Capacity;
  Charger.BackCapacity_Setpoint = Battery_BackCharge_Voltage;
  Charger.FullyRSOC_Setpoint = Battery_FullyCharge_RSOC;
  Charger.BackRSOC_Setpoint = Battery_BackCharge_RSOC;
 
}


void Enable_Charger(void)
{
  Charger_Test = 1;                                      // Start step count to charge cap
}

void Disable_Charger(void)
{
  Charger_Test = 0;
  CHG_MOS_IN = 0;
  asm("NOP");
  CHG_EN = 1;                                             // disable charger IC
  asm("NOP");
//  CHG_MOS_OUT = 0;
  Charger_Start_cnt = 0;                                  // when charge off reset step count
}

//******************** Charger state app **********************

void Charger_state_set(u8_t state)                             // �i�J��Charge_control�ҧP�_��state 
{
   if(Charger.Condition_state == state)                    // If the state is same with last state return
       return;
   switch(state)
   {
     case Charger_state_Initial:

          Charger.state_Initial = 1;
          Charger.state_FullyCharge = 0;
          Charger.state_Charging = 0;
          Charger.state_Inhibit = 0;
       break;

     case Charger_state_FullyCharge:

          Disable_Charger();        
          Charger.state_Initial = 0;
          Charger.state_FullyCharge = 1;
          Charger.state_Charging = 0;
          Charger.state_Inhibit = 0;

       break;

     case Charger_state_Charging:

          Enable_Charger();                                     // Enable Charger

          Charger.state_Initial = 0;
          Charger.state_FullyCharge = 0;
          Charger.state_Charging = 1;
          Charger.state_Inhibit = 0;
       break;

     case Charger_state_Inhibit:

          I_ref_Duty = 0;                                      // Not turn off Charger IC just adjust Duty
          Charger.state_Initial = 0;
          Charger.state_FullyCharge = 0;
          Charger.state_Charging = 0;
          Charger.state_Inhibit = 1;
          System_Delay(20000);                                 // Delay time avoid Charging and Inhibit state change quickly
          System_Delay(20000);
          System_Delay(10000);
          System_Delay(10000);
  
       break;

     case Charger_state_Failure:

          Disable_Charger();
          

          SystemControl.bits.Flag_Failure = 1;
       

     default:

       break;
   }
   
   Charger.Condition_state = state;
}

//******************* Charger state choose *******************//                 // �P�_Charger�i�J���ؼҦ�
void Charge_control(void)
{
   switch(Charger.Condition_state)
  {
//--------------------------------------------------------------------------------------------------------------------     
     case Charger_state_Initial:

#ifndef Charger_Voltage_mode                                                     // �e�q�Ҧ�
        
       Charger_Failure_type_Detect();
       Charger_Warning_type_Detect();

       if(Warning_type.bits.Charger_out_regulation == 1 || Failure_type.bits.Ambient_OTP == 1)
       {
         Charger_state_set(Charger_state_Inhibit);
         break;
       }
       
       if(Failure_type.bits.Charger_Input_UVP == 1 || Failure_type.bits.Charger_Input_OVP == 1 ||
          Failure_type.bits.Charger_Input_OCP == 1)
       {
         Charger_state_set(Charger_state_Failure);
         break;
       }
  
       if(Cell_Info.RSOC >= Charger.BackRSOC_Setpoint)      
       {
         Charger_state_set(Charger_state_FullyCharge);                           // �q���Ѿl�e�q > �q���R���e�q �i�R���q�Ҧ�
         break;
       }

       if(Cell_Info.RSOC < Charger.BackRSOC_Setpoint)     
       {
         Charger_state_set(Charger_state_Charging);								 // �q���Ѿl�e�q < �q���R���e�q �i�R�q�Ҧ�
       } 
 
#endif

#ifdef Charger_Voltage_mode                                                      // �q���Ҧ�

       Charger_Failure_type_Detect();
       Charger_Warning_type_Detect();

       if(Warning_type.bits.Charger_out_regulation == 1 || Failure_type.bits.Ambient_OTP == 1)
       {
         Charger_state_set(Charger_state_Inhibit);
         break;
       }
       
       if(Failure_type.bits.Charger_Input_UVP == 1 || Failure_type.bits.Charger_Input_OVP == 1 ||
         Failure_type.bits.Charger_Input_OCP == 1)
       {
         Charger_state_set(Charger_state_Failure);
         break;
       }

       if(Cell_Info.Voltage >= Charger.FullyVoltage_Setpoint)
       {
          Charger_state_set(Charger_state_FullyCharge);                          // �q���ثe�q�� > �q���R���q�� �i�R���q�Ҧ�
          break;
       }

       if(Cell_Info.Voltage < Charger.FullyVoltage_Setpoint)     
       {
         Charger_state_set(Charger_state_Charging);								 // �q���Ѿl�e�q < �q���R���e�q �i�R�q�Ҧ�
       } 
#endif
       break;
//-----------------------------------------------------------------------------------------------------------
     case Charger_state_FullyCharge:

#ifndef Charger_Voltage_mode                                                     // �e�q�Ҧ�
     
       Charger_Failure_type_Detect();
       Charger_Warning_type_Detect();
       if(Cell_Info.RSOC < Charger.BackRSOC_Setpoint)
       {
          Charger_state_set(Charger_state_Charging);                             // �q���Ѿl�e�q < �q���R���e�q �i�R�q�Ҧ�
       }
       else if(Cell_Info.RemainingCapacity >= Charger.BackRSOC_Setpoint)
       {
          Charger_state_set(Charger_state_FullyCharge);                          // �q���Ѿl�e�q > �q���R���e�q �i�R���q�Ҧ�
       }
#endif

#ifdef Charger_Voltage_mode                                                      // �q���Ҧ�
       
       Charger_Failure_type_Detect();
       Charger_Warning_type_Detect();
       if(Cell_Info.Voltage < Charger.BackVoltage_Setpoint)
       {
          Charger_state_set(Charger_state_Charging);                             // �q���ثe�q�� < �q���R���q�� �i�R�q�Ҧ�
       }
       else if(Cell_Info.Voltage >= Charger.FullyVoltage_Setpoint)
          Charger_state_set(Charger_state_FullyCharge);                          // �q���ثe�q�� > �q���R���q�� �i�R���q�Ҧ�
#endif
       break;
//-----------------------------------------------------------------------------------------------------------
     case Charger_state_Charging:
      
       Charger_Failure_type_Detect();
       Charger_Warning_type_Detect();

       if(Battery_Current_Read_Flag == 1)
       {	
         if(Cell_Info.Current < (Expect_Charge_Current - 20))
         {
           Expect_I_ref_Duty = Expect_I_ref_Duty + 3;
         }

         if(Cell_Info.Current > (Expect_Charge_Current + 20)) 
         {
           Expect_I_ref_Duty = Expect_I_ref_Duty - 3;
         }
 
         if(Expect_I_ref_Duty >= 4300)
         {
           Expect_I_ref_Duty = 4300;
         }
         
         Battery_Current_Read_Flag = 0;
       }

#ifndef Charger_Voltage_mode                                                     // �e�q�Ҧ�
       
  
       Charger_Failure_type_Detect();
       Charger_Warning_type_Detect();
       if(Failure_type.bits.Charger_Input_UVP == 1 || Failure_type.bits.Charger_Input_OVP == 1 ||
          Failure_type.bits.Charger_Input_OCP == 1)
       {
          Charger_state_set(Charger_state_Failure);
           break;
       }

       else if(Failure_type.bits.Charger_Cell_OTP == 1 || Failure_type.bits.Charger_BOOST_OTP == 1 || 
               Warning_type.bits.Charger_out_regulation == 1 || Charge_Current_Zero_Flag == 1)
       {
          Charger_state_set(Charger_state_Inhibit);
           break;
       }

       else if(Cell_Info.RSOC >= Charger.FullyRSOC_Setpoint)
       {
          Charger_state_set(Charger_state_FullyCharge);                          // �q���Ѿl�e�q > �q���R���e�q �i�R���q�Ҧ�
           break;
       }
     
       else if(Failure_type.bits.Charger_Input_UVP == 0 && Failure_type.bits.Charger_Input_OVP == 0 && Failure_type.bits.Charger_Input_OCP == 0 &&
          Failure_type.bits.Charger_BOOST_OTP == 0 && Failure_type.bits.Charger_Cell_OTP == 0 && Warning_type.bits.Charger_out_regulation == 0)
       {
          Charger_state_set(Charger_state_Charging);
           break;
       }
    
       
       
#endif

#ifdef Charger_Voltage_mode                                                      // �q���Ҧ�

       Charger_Failure_type_Detect();
       Charger_Warning_type_Detect();	 

       if(Failure_type.bits.Charger_Input_UVP == 1 || Failure_type.bits.Charger_Input_OVP == 1 ||
          Failure_type.bits.Charger_Input_OCP == 1)
       {
          Charger_state_set(Charger_state_Failure);
           break;
       }

       else if(Failure_type.bits.Charger_Cell_OTP == 1 || Failure_type.bits.Charger_BOOST_OTP == 1 || 
               Warning_type.bits.Charger_out_regulation == 1 || Charge_Current_Zero_Flag == 1)
       {
          Charger_state_set(Charger_state_Inhibit);
           break;
       }

       else if(Cell_Info.Voltage >= Charger.FullyVoltage_Setpoint)
       {
          Charger_state_set(Charger_state_FullyCharge);                          // �q���ثe�q�� > �q���R���q�� �i�R���q�Ҧ�
 	       break;
       }
     
       else if(Failure_type.bits.Charger_Input_UVP == 0 && Failure_type.bits.Charger_Input_OVP == 0 && Failure_type.bits.Charger_Input_OCP == 0 &&
          Failure_type.bits.Charger_BOOST_OTP == 0 && Failure_type.bits.Charger_Cell_OTP == 0 && Warning_type.bits.Charger_out_regulation == 0)
       {
          Charger_state_set(Charger_state_Charging);
           break;
       }

       
#endif
       break;
//------------------------------------------------------------------------------------------------------------------------------

     case Charger_state_Inhibit:

       Charger_Failure_type_Detect();
       Charger_Warning_type_Detect();

       if(Failure_type.bits.Charger_Input_UVP == 1 || Failure_type.bits.Charger_Input_OVP == 1)
       {
          Charger_state_set(Charger_state_Failure);
           break;
       }
 
       if(BBU_Info.BusVoltage >= Charging_Regulation_Low && BBU_Info.BusVoltage <= Charging_Regulation_High)
       {
          Warning_type.bits.Charger_out_regulation = 0;
       }
       else
       {
          Warning_type.bits.Charger_out_regulation = 1;
       }
       
       
       if(Cell_Info.Temp < Charging_Cell_OT_Recover_Threshold)
       {
          Failure_type.bits.Charger_Cell_OTP = 0;
       }

       if(BBU_Info.BOOST_Temp < Charging_BOOST_OT_Recover_Threshold)
       {
          Failure_type.bits.Charger_BOOST_OTP = 0;
       }
        
       if(Failure_type.bits.Charger_Cell_OTP == 0 && Failure_type.bits.Charger_BOOST_OTP == 0 && Warning_type.bits.Charger_out_regulation == 0 &&
          Failure_type.bits.Charger_Input_UVP == 0 && Failure_type.bits.Charger_Input_OVP == 0 && Charge_Current_Zero_Flag == 0 && Failure_type.bits.Ambient_OTP == 0)
       {
 		  Charger_state_set(Charger_state_Initial);
       }
       else
       {
          Charger_state_set(Charger_state_Inhibit);
       }

      
       break;
//------------------------------------------------------------------------------------------------------------------------------
     default:

       break;   
  }   

}


    
    
void Stop_I_ref_PWM(void)
{
  // I_ref_Duty = 0;
}

void Start_I_ref_PWM(void)
{

}
/****************************************************************/
void Charger_Failure_type_Detect(void)
{
  switch(Charger.Condition_state)
  {
     case Charger_state_Initial:
       
         if(BBU_Info.BusVoltage < Expect_Input_UV_Protection)                   // Bus�q���C���J�q��UV�O�@�I �i�T��R�q�Ҧ�
         {
           Charger_UVP_delay++;
           if(Charger_UVP_delay == 10)
           {
            Failure_type.bits.Charger_Input_UVP = 1;   
            u8StatusP0Input = (u8StatusP0Input | Status_Input_bits_Vin_UV_Fault);
            u8StatusP1Input = (u8StatusP1Input | Status_Input_bits_Vin_UV_Fault);
            u8StatusP0Input = (u8StatusP0Input | Status_Input_bits_Unit_Off_For_Low_Input_Voltage);
            u8StatusP1Input = (u8StatusP1Input | Status_Input_bits_Unit_Off_For_Low_Input_Voltage);
            u16StatusP0Word = (u16StatusP0Word | Status_Word_bits_Input);
            u16StatusP1Word = (u16StatusP1Word | Status_Word_bits_Input);
            u16StatusP0Word = (u16StatusP0Word | Status_Word_bits_Vin_UV_Fault);
            u16StatusP1Word = (u16StatusP1Word | Status_Word_bits_Vin_UV_Fault);
           }
         }
         else
         {
           Charger_UVP_delay = 0;
         }

         if(BBU_Info.BusVoltage > Expect_Input_OV_Protection)              // Bus�q�������J�q��OV�O�@�I �i�T��R�q�Ҧ�
         {
          Failure_type.bits.Charger_Input_OVP = 1;
         }

         if(BBU_Info.Iin >= Expect_Input_OC_Protection)
         {
            Charger_OCP_Flag = 1;
            if(Charger_OCP_count == 9)
            {
              Failure_type.bits.Charger_Input_OCP = 1;
              u8StatusP0Input = (u8StatusP0Input | Status_Input_bits_Iin_OC_Fault);
              u8StatusP1Input = (u8StatusP1Input | Status_Input_bits_Iin_OC_Fault);
              u16StatusP0Word = (u16StatusP0Word | Status_Word_bits_Input);
              u16StatusP1Word = (u16StatusP1Word | Status_Word_bits_Input);
            }       
         }
         else
         {
            Charger_OCP_Flag = 0;
            Charger_OCP_count = 0;
         }
       
       break;

     case Charger_state_FullyCharge:

       break;

     case Charger_state_Charging:
       
         if(BBU_Info.BusVoltage < Expect_Input_UV_Protection)                   // Bus�q���C���J�q��UV�O�@�I �i�J�T��R�q�Ҧ�
         {
          Charger_UVP_delay++;
          if(Charger_UVP_delay == 10)
          { 
            Failure_type.bits.Charger_Input_UVP = 1;        
            u8StatusP0Input = (u8StatusP0Input | Status_Input_bits_Vin_UV_Fault);
            u8StatusP1Input = (u8StatusP1Input | Status_Input_bits_Vin_UV_Fault);
            u8StatusP0Input = (u8StatusP0Input | Status_Input_bits_Unit_Off_For_Low_Input_Voltage);
            u8StatusP1Input = (u8StatusP1Input | Status_Input_bits_Unit_Off_For_Low_Input_Voltage);
            u16StatusP0Word = (u16StatusP0Word | Status_Word_bits_Input);
            u16StatusP1Word = (u16StatusP1Word | Status_Word_bits_Input);
            u16StatusP0Word = (u16StatusP0Word | Status_Word_bits_Vin_UV_Fault);
            u16StatusP1Word = (u16StatusP1Word | Status_Word_bits_Vin_UV_Fault); 
          }                    
         }
         else
         {
           Charger_UVP_delay = 0;
         } 

         if(BBU_Info.BusVoltage > Expect_Input_OV_Protection)              // Bus�q�������J�q��OV�O�@�I �i�J�T��R�q�Ҧ�
         {
          Failure_type.bits.Charger_Input_OVP = 1;
         }
    
         if(Cell_Info.Temp > Expect_Charger_Cell_OT_Protection)                // �b�R�q�ɹq���ūװ���q���R�q����ū�
         {
            if(Cell_Info.Temp <= 120)
            {
              Failure_type.bits.Charger_Cell_OTP = 1;
              Failure_type.bits.Charger_BOOST_OTP = 1;
              u8StatusP0Temp = (u8StatusP0Temp | Status_Temperature_bits_OT_Fault);
              u8StatusP1Temp = (u8StatusP1Temp | Status_Temperature_bits_OT_Fault);
            }                                 
         }

         if(BBU_Info.Iin >= Expect_Input_OC_Protection)
         {
            Charger_OCP_Flag = 1;
            if(Charger_OCP_count == 9)
            {
              Failure_type.bits.Charger_Input_OCP = 1;
              u8StatusP0Input = (u8StatusP0Input | Status_Input_bits_Iin_OC_Fault);
              u8StatusP1Input = (u8StatusP1Input | Status_Input_bits_Iin_OC_Fault);
              u16StatusP0Word = (u16StatusP0Word | Status_Word_bits_Input);
              u16StatusP1Word = (u16StatusP1Word | Status_Word_bits_Input);
            }       
         }
         else
         {
            Charger_OCP_Flag = 0;
            Charger_OCP_count = 0;
         }
      

         if(BBU_Info.BOOST_Temp > Expect_Charging_BOOST_OT_Protection)     // �b�R�q��BOOST�ū׹L��
         {
          Failure_type.bits.Charger_BOOST_OTP = 1;
          u8StatusP0Temp = (u8StatusP0Temp | Status_Temperature_bits_OT_Fault);
          u8StatusP1Temp = (u8StatusP1Temp | Status_Temperature_bits_OT_Fault);								 
         }
    
       break;

     case Charger_state_Inhibit:

          if(BBU_Info.BusVoltage < Expect_Input_UV_Protection)                   // Bus�q���C���J�q��UV�O�@�I �i�J�T��R�q�Ҧ�
         {
          Charger_UVP_delay++;
          if(Charger_UVP_delay == 10)
          { 
            Failure_type.bits.Charger_Input_UVP = 1;        
            u8StatusP0Input = (u8StatusP0Input | Status_Input_bits_Vin_UV_Fault);
            u8StatusP1Input = (u8StatusP1Input | Status_Input_bits_Vin_UV_Fault);
            u8StatusP0Input = (u8StatusP0Input | Status_Input_bits_Unit_Off_For_Low_Input_Voltage);
            u8StatusP1Input = (u8StatusP1Input | Status_Input_bits_Unit_Off_For_Low_Input_Voltage);
            u16StatusP0Word = (u16StatusP0Word | Status_Word_bits_Input);
            u16StatusP1Word = (u16StatusP1Word | Status_Word_bits_Input);
            u16StatusP0Word = (u16StatusP0Word | Status_Word_bits_Vin_UV_Fault);
            u16StatusP1Word = (u16StatusP1Word | Status_Word_bits_Vin_UV_Fault); 
          }                    
         }
         else
         {
           Charger_UVP_delay = 0;
         } 

         if(BBU_Info.BusVoltage > Expect_Input_OV_Protection)              // Bus�q�������J�q��OV�O�@�I �i�J�T��R�q�Ҧ�
         {
          Failure_type.bits.Charger_Input_OVP = 1;
         }
    
         if(Cell_Info.Temp > Expect_Charger_Cell_OT_Protection)                // �b�R�q�ɹq���ūװ���q���R�q����ū�
         {
            if(Cell_Info.Temp <= 120)
            {
             Failure_type.bits.Charger_Cell_OTP = 1;
             Failure_type.bits.Charger_BOOST_OTP = 1;
             u8StatusP0Temp = (u8StatusP0Temp | Status_Temperature_bits_OT_Fault);
             u8StatusP1Temp = (u8StatusP1Temp | Status_Temperature_bits_OT_Fault);
            }                                 
         }

         
      

         if(BBU_Info.BOOST_Temp > Expect_Charging_BOOST_OT_Protection)     // �b�R�q��BOOST�ū׹L��
         {
          Failure_type.bits.Charger_BOOST_OTP = 1;
          u8StatusP0Temp = (u8StatusP0Temp | Status_Temperature_bits_OT_Fault);
          u8StatusP1Temp = (u8StatusP1Temp | Status_Temperature_bits_OT_Fault);								 
         }

      break;


  }

}


/****************************************************************/
void Charger_Warning_type_Detect(void)
{
  switch(Charger.Condition_state)
  {
     case Charger_state_Initial:

          if(BBU_Info.BusVoltage <= Charging_Regulation_High && BBU_Info.BusVoltage >= Charging_Regulation_Low)
          {
            Warning_type.bits.Charger_out_regulation = 0;
          }
          else
          {
            Warning_type.bits.Charger_out_regulation = 1;
          }
          
          if(BBU_Info.BusVoltage <= Expect_Input_UV_Warning)
          {
            Warning_type.bits.Vin_UV_Warning = 1;
            u8StatusP0Input = (u8StatusP0Input | Status_Input_bits_Vin_UV_Warning);
            u8StatusP1Input = (u8StatusP1Input | Status_Input_bits_Vin_UV_Warning);
          } 
//          else if(BBU_Info.BusVoltage > Input_UV_Recover_Threshold)
//          {
//            Warning_type.bits.Vin_UV_Warning = 0;
//            u8StatusP0Input = (u8StatusP0Input & ~(Status_Input_bits_Vin_UV_Warning));
//            u8StatusP1Input = (u8StatusP1Input & ~(Status_Input_bits_Vin_UV_Warning));
//          }
       
       break;

     case Charger_state_FullyCharge:

       break;

     case Charger_state_Charging:

          if(BBU_Info.BusVoltage <= Charging_Regulation_Hys_High && BBU_Info.BusVoltage >= Charging_Regulation_Hys_Low)
          {
            Warning_type.bits.Charger_out_regulation = 0;
          }
          else
          {
            Warning_type.bits.Charger_out_regulation = 1;
          }

          if(BBU_Info.BusVoltage <= Expect_Input_UV_Warning)
          {
            Warning_type.bits.Vin_UV_Warning = 1;
            u8StatusP0Input = (u8StatusP0Input | Status_Input_bits_Vin_UV_Warning);
            u8StatusP1Input = (u8StatusP1Input | Status_Input_bits_Vin_UV_Warning);
          } 
//          else if(BBU_Info.BusVoltage > Input_UV_Recover_Threshold)
//          {
//            Warning_type.bits.Vin_UV_Warning = 0;
//            u8StatusP0Input = (u8StatusP0Input & ~(Status_Input_bits_Vin_UV_Warning));
//            u8StatusP1Input = (u8StatusP1Input & ~(Status_Input_bits_Vin_UV_Warning));
//          }

          if(BBU_Info.Iin >= Expect_Input_OC_Warning )
          {
            Warning_type.bits.Iin_OC_Warning = 1;
            u8StatusP0Input = (u8StatusP0Input | Status_Input_bits_Iin_OC_Warning);
            u8StatusP1Input = (u8StatusP1Input | Status_Input_bits_Iin_OC_Warning);
          }
//          else if(BBU_Info.Iin < Input_OC_Recover_Threshold)
//          {
//            Warning_type.bits.Iin_OC_Warning = 0;
//            u8StatusP0Input = (u8StatusP0Input & ~(Status_Input_bits_Iin_OC_Warning));
//            u8StatusP1Input = (u8StatusP1Input & ~(Status_Input_bits_Iin_OC_Warning));
//          }

          if(BBU_Info.Pin >= Expect_Input_OP_Warning)
          {
            Warning_type.bits.Pin_OP_Warning = 1;
            u8StatusP0Input = (u8StatusP0Input | Status_Input_bits_Pin_OP_Warning);
            u8StatusP1Input = (u8StatusP1Input | Status_Input_bits_Pin_OP_Warning);
          }
//          else if(BBU_Info.Pin < Input_OP_Recover_Threshold)
//          {
//            Warning_type.bits.Pin_OP_Warning = 0;
//            u8StatusP0Input = (u8StatusP0Input & ~(Status_Input_bits_Pin_OP_Warning));
//            u8StatusP1Input = (u8StatusP1Input & ~(Status_Input_bits_Pin_OP_Warning));
//          }

          if(BBU_Info.BOOST_Temp >= Expect_Charging_BOOST_OT_Warning)
          {
            Warning_type.bits.Charger_BOOST_OT_Warning = 1;
          
            if(Warning_type.bits.Ambient_OT_Warning == 0 && Warning_type.bits.Discharger_BUCK1_OT_Warning == 0)
            {
              u8StatusP0Temp = (u8StatusP0Temp | Status_Temperature_bits_OT_Warning);
              u8StatusP1Temp = (u8StatusP1Temp | Status_Temperature_bits_OT_Warning);
              u16StatusP0Word = (u16StatusP0Word | Status_Word_bits_Temperature);
              u16StatusP1Word = (u16StatusP1Word | Status_Word_bits_Temperature);
            }          
          }
                

       break;

     case Charger_state_Inhibit:

         if(BBU_Info.BusVoltage <= Expect_Input_UV_Warning)
          {
            Warning_type.bits.Vin_UV_Warning = 1;
            u8StatusP0Input = (u8StatusP0Input | Status_Input_bits_Vin_UV_Warning);
            u8StatusP1Input = (u8StatusP1Input | Status_Input_bits_Vin_UV_Warning);
          } 
//          else if(BBU_Info.BusVoltage > Input_UV_Recover_Threshold)
//          {
//            Warning_type.bits.Vin_UV_Warning = 0;
//            u8StatusP0Input = (u8StatusP0Input & ~(Status_Input_bits_Vin_UV_Warning));
//            u8StatusP1Input = (u8StatusP1Input & ~(Status_Input_bits_Vin_UV_Warning));
//          }

          if(BBU_Info.Iin >= Expect_Input_OC_Warning )
          {
            Warning_type.bits.Iin_OC_Warning = 1;
            u8StatusP0Input = (u8StatusP0Input | Status_Input_bits_Iin_OC_Warning);
            u8StatusP1Input = (u8StatusP1Input | Status_Input_bits_Iin_OC_Warning);
          }
//          else if(BBU_Info.Iin < Input_OC_Recover_Threshold)
//          {
//            Warning_type.bits.Iin_OC_Warning = 0;
//            u8StatusP0Input = (u8StatusP0Input & ~(Status_Input_bits_Iin_OC_Warning));
//            u8StatusP1Input = (u8StatusP1Input & ~(Status_Input_bits_Iin_OC_Warning));
//          }

          if(BBU_Info.Pin >= Expect_Input_OP_Warning)
          {
            Warning_type.bits.Pin_OP_Warning = 1;
            u8StatusP0Input = (u8StatusP0Input | Status_Input_bits_Pin_OP_Warning);
            u8StatusP1Input = (u8StatusP1Input | Status_Input_bits_Pin_OP_Warning);
          }
//          else if(BBU_Info.Pin < Input_OP_Recover_Threshold)
//          {
//            Warning_type.bits.Pin_OP_Warning = 0;
//            u8StatusP0Input = (u8StatusP0Input & ~(Status_Input_bits_Pin_OP_Warning));
//            u8StatusP1Input = (u8StatusP1Input & ~(Status_Input_bits_Pin_OP_Warning));
//          }

          if(BBU_Info.BOOST_Temp >= Expect_Charging_BOOST_OT_Warning)
          {
            Warning_type.bits.Charger_BOOST_OT_Warning = 1;
            if(Warning_type.bits.Ambient_OT_Warning == 0 && Warning_type.bits.Discharger_BUCK1_OT_Warning == 0)
            {
              u8StatusP0Temp = (u8StatusP0Temp | Status_Temperature_bits_OT_Warning);
              u8StatusP1Temp = (u8StatusP1Temp | Status_Temperature_bits_OT_Warning);
              u16StatusP0Word = (u16StatusP0Word | Status_Word_bits_Temperature);
              u16StatusP1Word = (u16StatusP1Word | Status_Word_bits_Temperature);
            }         
          }
         

       break;

    }


    if(Warning_type.bits.Vin_UV_Warning == 1 || Warning_type.bits.Iin_OC_Warning == 1 || Warning_type.bits.Pin_OP_Warning == 1)
    {
      u16StatusP0Word = (u16StatusP0Word | Status_Word_bits_Input);
      u16StatusP1Word = (u16StatusP1Word | Status_Word_bits_Input);
    }    
         
}

