/*******************************************************************************
* file				BootLoader.h
* brief				The file includes the function of bootloader.
* note
* author			vincent.liu
* version			01
* section History	2014/10/27 - 1st release
*******************************************************************************/
#ifndef BOOTLOADER_H
#define	BOOTLOADER_H

#include "FlashDriver.h"
/*******************************************************************************
* declare compile condition
*******************************************************************************/
#define BOOT_AREA
//#define WRITE_FLASH_ROW

#define BOOTAPP_RX_BUFF				30											// 30 bytes
#define BOOTAPP_TX_BUFF				30											// 30 bytes

#define TRANSMIT_BYTENUM			0x10										// 16 bytes, should be a multiple of "4", the max value is 256 bytes
#define TRANSMIT_WORDNUM			(TRANSMIT_BYTENUM >> 1)						// 8 words
#define TRANSMIT_INSNUM				(TRANSMIT_BYTENUM >> 2)						// 4 instructions

#define DEVICE_TYPE					0x02										// PS unit
#define PRIMARY_MCU_TYPE			0x02
#define SECONDARY_MCU_TYPE			0x01
#define PRIMARY_NUMBER				1
#define SECONDARY_NUMBER			1
#define PRIMARY_MCU_BITS			0x0001										// ID1 & ID2 exist
#define SECONDARY_MCU_BITS			0x0001										// ID1 exist

#define COUNTDOWN_TIME				1											// ls/1s
#define MCURESET_TIME				30											// 3000ms/100ms
#define GOAPP_TIME					30											// 3000ms/100ms
#define GOBOOT_TIME					5											// 500ms/100ms
#define ENTERBOOT_PASSWORD			0x7b3a6cc0

#define IMAGE_MCU_RESETADDR			0x00000000
#define IMAGE_BOOT_RESETADDR		0x00000200
#define IMAGE_APP_RESETADDR		    0x00002E48

#define IMAGE_APP_STARTADDR			0x00002C00
#define IMAGE_APP_ENDADDR			0x0000a800
#define IMAGE_APP_PAGENUMBER		((IMAGE_APP_ENDADDR - IMAGE_APP_STARTADDR) / ERASE_PAGE_SIZE)
#define IMAGE_PIB_STARTADDR			0x00002E00

#define APP_PASSWORD				0xaa55
#define BOOT_PASSWORD				0xbb66
#define PASSWORD_APP_STARTADDR		0x00002E40
#define PASSWORD_BOOT_STARTADDR		0x00002E44
/*******************************************************************************
* declare compile structure
*******************************************************************************/
//=====================================
//enum of the bootloader state
//=====================================
typedef enum
{
	Task_Idle,
	Task_VerifyCodeID,
	Task_CheckMcuType,
	Task_EnterBootMode,
	Task_EraseFlash,
	Task_WriteFlash,
	Task_ReadStatus,
	Task_VerifyFile,
	Task_McuReset,
}eBootState_t;
//=====================================
//status flag for report
//=====================================
typedef union
{
	struct
	{
		u16_t u1CodeIDErr			:1;
		u16_t u1PasswordErr			:1;
		u16_t u1FileErr				:1;
		u16_t u1NA01				:1;
		u16_t u1AddressErr			:1;
		u16_t u1EraseErr			:1;
		u16_t u1FlashErr			:1;
		u16_t u1NA02				:1;
		u16_t u6NA03				:6;
		u16_t u1Busy			    :1;
		u16_t u1Mode			    :1;		// 0:App;1:Boot
	} u16Bit;

	struct
	{
		u8_t u8LowByte;
		u8_t u8HighByte;
	} u16Half;

	u16_t u16All;
}nStatusFlag_t;
//=====================================
//data structure primary ID & status
//=====================================
typedef struct
{
	u16_t u16McuBit;
	nStatusFlag_t u16Status[PRIMARY_NUMBER];
	u16_t u16ExistIDNum;
}sPriInformStr_t;
//=====================================
//data structure secondary ID & status
//=====================================
typedef struct
{
	u16_t u16McuBit;
	nStatusFlag_t u16Status;
}sSecInformStr_t;
//=====================================
//flag of bootloader application
//=====================================
typedef union
{
	struct
	{
		u16_t u1BootStay			:1;
		u16_t u1AppExist			:1;
		u16_t u1EraseFalshExecuted	:1;
		u16_t u1WriteFalshExecuted	:1;
		u16_t u1VerifyFileExecuted	:1;
		u16_t u3NA					:3;
		u16_t u8ErrCounter			:8;
	} u16Bit;

	u16_t u16All;
}nBootloaderFlag_t;
//=====================================
//data structure of PIB code
//=====================================
typedef struct
{
	u8_t  pu8StartPattern[8];
	u8_t  pu16PIBVersion[2];
	u8_t  pu8DeviceType[1];
	u8_t  pu8McuType[1];
	u8_t  pu8CodeID[12];
	u8_t  pu8StartAddr[4];
	u8_t  pu8EndAddr[4];
	u8_t  pu16EraseTime[2];
	u8_t  pu16ProgramTime[2];
	u8_t  pu16ProgramLength[2];
	u8_t  pu8BufFillVal[1];
	u8_t  pu8Reserved[11];
	u8_t  pu8Checksum[2];
	u8_t  pu8StopPattern[8];
}sPIBStr_t;
//=====================================
//structure of bootloader
//=====================================
typedef struct
{
	u8_t u8State;
	u8_t u8DeviceType;
	u8_t u8McuType;
	u8_t u8ModuleID;
	u8_t u8CountdownTimer;
	u8_t u8McuResetTimer;
	u8_t u8GoAppTimer;
	u8_t u8GoBootTimer;
	u8_t pu8RxBuff[BOOTAPP_RX_BUFF];
	u8_t pu8TxBuff[BOOTAPP_TX_BUFF];
	u8_t pu8FlashBuff[WRITE_ROW_SIZE*2];

	u16_t u16AddrIndex;
	u16_t u16FileCrc;

	u32_t u32StartAddress;
	u32_t u32EndAddress;
	u32_t u32ProgramBytes;

	nBootloaderFlag_t nBootloaderFlag;
	sPriInformStr_t tPriInform;
	sSecInformStr_t tSecInform;
	sPIBStr_t tPIBData;

}sBootloaderStr_t;
/*******************************************************************************
* declare extern variable
*******************************************************************************/
extern sBootloaderStr_t gtBootStruct;
/*******************************************************************************
* declare extern function
*******************************************************************************/
extern u8_t GetPriIDNum(void);
extern void BuildPriIDInform(void);
extern void BootComRxProcess(u8_t u8Cmd, u8_t* pu8DataBuff);
extern void BootComTxProcess(u8_t u8Cmd);
extern void ClrGoAppTimer(void);
extern void BootloaderInit(void);
extern void BootloaderProcess(void);
#ifdef BOOT_AREA
extern void BootDoneReset(void);
extern void GotoApp(void);
#else
extern void GotoBoot(void);
#endif
/*******************************************************************************
* end of file
*******************************************************************************/

#endif	/* BOOTLOADER_H */
