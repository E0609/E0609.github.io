#ifndef __Failure_H__
#define __Failure_H__

#include <p24FJ64GA006.h>
#include "bms_Pin_Define.h"
#include "GenericTypeDefs.h"
#include "I2C.h"
#include "Battery_status.h"
#include "Charge_control.h"
#include "Discharge_control.h"
#include "FW_Config.h"
#include "main.h"

void Failure_detect(void);
void Discharger_Failure_Detect(void);
void Charger_Failure_Detect(void);
void Failure_Control(void);
void Clear_Failure(void);

typedef union
{
   u32_t val;
   struct
   {
     unsigned  Charger_Input_OVP:1;                      // Charger Input Voltage Over Threshold 
     unsigned  Charger_Input_UVP:1;                      // Charger Input Voltage Under Threshold
     unsigned  Charger_Input_OCP:1;                      // Charger Input Current Over Threshold
     unsigned  Charger_Output_OVP:1;                     // Charger Output Voltage Over Threshold
     unsigned  Charger_Output_UVP:1;                     // Charger Output Voltage Under Threshold
     unsigned  Charger_OCP:1;                            
     unsigned  Charger_BOOST_OTP:1;                      // BOOST Temperature Over Threshold
     unsigned  Charger_Cell_OTP:1;                       // Cell Temperature Over Threshold
     unsigned  Discharger_Output_OVP:1;                  // Voltage before ORing FET Over Threshold
     unsigned  Discharger_Output_OVP_Second:1;           // Voltage before ORing FET Over second Threshold
     unsigned  Discharger_Output_UVP:1;                  // Voltage before ORing FET Under Threshold
     unsigned  Discharger_Output_OCP:1;                  // Output Current Over Threshold
     unsigned  Discharger_Input_OVP:1;                   // Battery Voltage Over Threshold
     unsigned  Discharger_Input_UVP:1;                   // Battery Voltage Under Threshold
     unsigned  Discharger_Input_OCP:1;                   // Battery Current Over Threshold
     unsigned  Discharger_Cell_OTP:1;                    // Cell Temperature Over Threshold
     unsigned  Discharger_Cell_OVP:1;                    // Cell Voltage Over Threshold
     unsigned  Discharger_Cell_UVP:1;                    // Cell Voltage Under Threshold
     unsigned  Discharger_Cell_OCP:1;                    // Cell Current Over Threshold
     unsigned  Discharger_BUCK1_OTP:1;                   // BUCK modual 1 Temperature Over Threshold
     unsigned  BusVoltage_OVP:1;                         // Bus Voltage Over Threshold
     unsigned  Ambient_OTP:1;
     unsigned  Discharger_Run_Time:1;                    // Discharger run time Over Threshold
     unsigned  Power_Fault:1;                            // If BBU at charge mode => charger hardware OVP, if at discharge mode => discharger hardware OVP
     unsigned  Power_Output_OP:1;                        // Discharger Output OP Fault
     unsigned  BMS_Communication_loss:1;                 // Communicate with BMS loss
     unsigned  Cell_low_Capacity_Fault:1;
     unsigned  Cell_PF:1;                                //                 
     unsigned  Reserved:4;
     
   }bits;
}Failure_type_t;


typedef union
{
  struct
  {
     unsigned Vin_UV_Warning:1;
     unsigned Iin_OC_Warning:1;
     unsigned Iout_OC_Warning:1;
     unsigned Pin_OP_Warning:1;
     unsigned Pout_OP_Warning:1;
     unsigned Ambient_OT_Warning:1;
     unsigned Discharger_BUCK1_OT_Warning:1;
     unsigned Discharger_BUCK2_OT_Warning:1;
     unsigned Discharger_BUCK3_OT_Warning:1;
     unsigned Charger_BOOST_OT_Warning:1;
     unsigned Cell_low_Capacity_Warning:1;
     unsigned Charger_out_regulation:1;

  }bits;
}Warning_type_t;


typedef union
{
   u32_t Val;
   struct
   {
     unsigned Discharger_second_OVP :1;


   }bits;


}Not_Reset_Failure_type_t;





extern Failure_type_t Failure_type;
extern Warning_type_t Warning_type;
extern Not_Reset_Failure_type_t Not_Reset_Failure_type;


#endif
